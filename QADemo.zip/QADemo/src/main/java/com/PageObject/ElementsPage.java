package com.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.utils.ReusableMethods;

public class ElementsPage extends ReusableMethods {

	public ElementsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class='avatar mx-auto white']/following::h5[contains(text(),'Elements')]")
	public static WebElement ElementsIcon;
	
	@FindBy(xpath="//span[contains(text(),'Text Box')]")
	public static WebElement textBox;
	
	@FindBy(id="userName")
	public static WebElement fullName;
	
	@FindBy(id="userEmail")
	public static WebElement userEmail;

	@FindBy(id="currentAddress")
	public static WebElement currentAddress;
	
	@FindBy(id="permanentAddress")
	public static WebElement permanentAddress;
	
	@FindBy(id="submit")
	public static WebElement submit;
	
	public void clickOnElementIcon() {
		jsClick(ElementsIcon);
	}

	public void selectTextBox() {
		jsClick(textBox);
	}
	

	public void enterUserNameandEmail(String name, String email) {
		sendKeysValue(fullName, name);
		sendKeysValue(userEmail,email);
		
	}
	public void enterAddress(String Address1,String Address2)
	{
		sendKeysValue(currentAddress, Address1);
		sendKeysValue(permanentAddress, Address2);
	}
	
	public void sumitTextForm()
	{
		jsClick(submit);
	}
	
	
}
