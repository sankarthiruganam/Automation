package com.PageObject;

import java.util.ArrayList;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverFactory.DriverManager;
import com.utils.ReusableMethods;

public class HandleMultipleWindows extends ReusableMethods {

	public HandleMultipleWindows(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[contains(text(),'Browser Windows')]/ancestor::li/span")
	public static WebElement browserWindow;

	@FindBy(xpath = "//*[contains(text(),'Alerts, Frame & Windows')]")
	public static WebElement alertFrame;
	
	@FindBy(xpath="//*[contains(text(),'New Tab')]")
	public static WebElement newTab;
	
	@FindBy(id="sampleHeading")
	public static WebElement sampleHeading;

	public void clickBrowserWindow() {
		jsClick(browserWindow);
	}

	public void clickAlertFrame() {
		jsClick(alertFrame);
	}

	public void handleNewTab() {
		jsClick(newTab);
		ArrayList<String> newTabs= new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(newTabs.get(1));
	//	DriverManager.getDriver().getWindowHandles().forEach(tab->DriverManager.getDriver().switchTo().window(tab));
		Assert.assertEquals(sampleHeading.getText(), "This is a sample page");		
	}
}
