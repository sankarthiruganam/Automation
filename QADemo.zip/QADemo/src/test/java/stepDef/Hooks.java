package stepDef;


import io.cucumber.java.After;
import io.cucumber.java.Before;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.driverFactory.DriverFactory;
import com.driverFactory.DriverManager;
 

public class Hooks {
	
	private WebDriver driver;
	private DriverFactory driverFactory;
	

	@Before(order= 1)
	public void launchBrowser() throws IOException
	{
		
		driverFactory = new DriverFactory();
		driver = driverFactory.getDriver();
		DriverManager.setDriver(driver);
		
	}
	@After(order=0)
	public void quitBrowser()
	{
		DriverManager.getDriver().quit();
	}
}
