package com.driverfactory;

import io.appium.java_client.AppiumDriver;

import java.util.logging.Level;
import java.util.logging.Logger;

public class DriverManager {

    private static final ThreadLocal<AppiumDriver> driver = new ThreadLocal<>();
    private static final Logger logger = Logger.getLogger(DriverManager.class.getName());

    private DriverManager() {}

    public static AppiumDriver<?> getDriver() {
        AppiumDriver<?> currentDriver = driver.get();
        if (currentDriver == null) {
            logger.log(Level.SEVERE, "AppiumDriver instance not initialized for this thread.");
        }
        return currentDriver;
    }

    public static void setDriver(AppiumDriver<?> driverIn) {
        driver.set(driverIn);
        logger.info("Driver set for thread: " + Thread.currentThread().getId());
    }

    public static void quit() {
        AppiumDriver<?> currentDriver = driver.get();
        if (currentDriver != null) {
            try {
                currentDriver.quit();
                logger.info("Driver quit for thread: " + Thread.currentThread().getId());
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error occurred while quitting the driver: " + e.getMessage());
            } finally {
                driver.remove();
            }
        } else {
            logger.warning("Driver instance is null. Quit operation skipped.");
        }
    }
}
