package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class AboutandLegel extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	LoginPage login =new LoginPage(DriverManager.getDriver());

	public AboutandLegel(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
/**********************Locators******************************/
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='About, button']")
	@AndroidFindBy(xpath = "//*[@text='About Us']")
	private MobileElement abt_txt_aboutmenuOld;

	@iOSXCUITFindBy(accessibility  ="About_us_Menu")
	@AndroidFindBy(xpath = "//*[@text='About Us']")
	private MobileElement abt_txt_aboutmenuNew;
	
	@iOSXCUITFindBy(xpath  = "//*[contains(@label,'RELEASE')]")
	@AndroidFindBy(xpath = "//*[contains(@text,'RELEASE')]")
	private MobileElement abt_txt_releaseno;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'BUILD')]")
	@AndroidFindBy(xpath = "//*[contains(@text,'BUILD')]")
	private MobileElement abt_txt_buildno;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'AUDIO ENGINE')]")
	@AndroidFindBy(xpath = "//*[contains(@text,'AUDIO ENGINE')]")
	private MobileElement abt_txt_autoengine;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'READER')]")
	@AndroidFindBy(xpath = "//*[contains(@text,'READER')]")
	private MobileElement abt_txt_readerversion;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\" Back\"]")
	@AndroidFindBy(xpath = "//*[@text='Back']")
	private MobileElement abt_btn_backbutton;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Back CTA']")
	@AndroidFindBy(id = "//*[@text='Back']")
	private MobileElement abt_btn_backbutton1;
		
	@iOSXCUITFindBy(accessibility = "About us heading")
	@AndroidFindBy(xpath = "//*[@text='About Us']")
	private MobileElement abt_txt_abouthdr;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeNavigationBar[@name='About']")
	@AndroidFindBy(xpath = "(//*[@text='About']")
	private MobileElement abt_txt_abouthdr1;
	
	public MobileElement getAbt_txt_abouthdr() {
		return abt_txt_abouthdr;
	}

	public MobileElement getAbt_txt_releaseno() {
		return abt_txt_releaseno;
	}

	public MobileElement getAbt_txt_buildno() {
		return abt_txt_buildno;
	}

	public MobileElement getAbt_txt_autoengine() {
		return abt_txt_autoengine;
	}

	public MobileElement getAbt_txt_readerversion() {
		return abt_txt_readerversion;
	}

	public MobileElement getAbt_txt_aboutmenuOld() {
		return abt_txt_aboutmenuOld;
	}
	

/****************** Action Methods **********************/
	
	public void clickAboutus() {
		ClickOnMobileElement(abt_txt_aboutmenuNew);
	}

	public void clickbackbutton() {
		if (isElementPresent(abt_btn_backbutton)) {
			ClickOnMobileElement(abt_btn_backbutton);
		} else if (isElementPresent(abt_btn_backbutton1)) {
			ClickOnMobileElement(abt_btn_backbutton1);
		}
	}
	
	public void clickonAbout() {
		if (isElementPresent(login.getLogo_btn_menu())) {
			ClickOnMobileElement(abt_txt_aboutmenuOld);	
			logger.info("About button clicked");
		}
		else if (isElementPresent(login.getLogo_btn_menu1())) {
			ClickOnMobileElement(abt_txt_aboutmenuNew);
			logger.info("About us button clicked");
		}
		else if (isElementPresent(login.getLogo_btn_menu2())) {
			ClickOnMobileElement(abt_txt_aboutmenuNew);
			logger.info("About us button clicked");
		}
	}
	
	public Boolean aboutScreenNavCheck() {
		boolean about = false;
		if(isElementPresent(abt_txt_abouthdr)) {
			about=true;
			logger.info("user is on new UI About screen");
		}
		if(isElementPresent(abt_txt_abouthdr1)) {
			about=true;
			logger.info("user is on new Old About screen");
		}
		return about;
	}
	
}
