package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Downloads extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(Downloads.class);

	public Downloads(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "btnDownload")
	@AndroidFindBy(xpath="//*[@resource-id = 'btnDownload']")
	private MobileElement download_btn;
	
	@iOSXCUITFindBy(accessibility = "DOWNLOADS")
	@AndroidFindBy(xpath="//*[@text = 'DOWNLOADS']")
	private MobileElement download_page;
	
	@iOSXCUITFindBy(accessibility = "Checkout_title_hours_diff_test_id")
	@AndroidFindBy(xpath="//*[@text = 'Checkout_title_hours_diff_test_id']")
	private MobileElement download_titleduedate;
	
	public MobileElement getDownload_page() {
		return download_page;
	}
	
	public MobileElement getTitleduedate() {
		return download_titleduedate;
	}
	
	/******************** Action methods *************************/

	public void clickDownloadsCta() {
		if (isElementPresent(download_btn)) {
			ClickOnMobileElement(download_btn);
		}
	}
	
	
}

