package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class FeaturedPrg extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	public FeaturedPrg(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
/**********************Locators******************************/
	
	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_READING_PROGRAM_TITLE']")
	private MobileElement libPg_lbl_featurePrograms;
	
	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_BUTTON_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='txt_feature_reading_program_wrap']")
	private MobileElement featurePrg_panner;
	
	@iOSXCUITFindBy(accessibility = "VIEW_PROGRAM_DETAILS")
	@AndroidFindBy(xpath = "//*[@resource-id='View Program Details']")
	private MobileElement featurePrg_panner_details;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"stack_title_touch_test_id\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='stack_title_touch_test_id'])[1]")
	private MobileElement titles_In_Featured_Reading_Program;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'Reading Program')]")
	@AndroidFindBy(xpath = "//*[@text='Reading Program']")
	private MobileElement programDetailsScreen;
	
	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement featurePrg_program_title;
	
	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[2]/android.view.View)[2]")
	private MobileElement libPg_lbl_featurePrgName;
	
	@iOSXCUITFindBy(accessibility = "VIEW_PROGRAM_DETAILS")
	@AndroidFindBy(xpath = "//*[@resource-id='VIEW_PROGRAM_DETAILS']")
	private MobileElement libPg_btn_viewPrgDetail;
	
	@iOSXCUITFindBy(accessibility = "book_of_the_month_header")
	@AndroidFindBy(xpath = "//*[@resource-id='book_of_the_month_header']")
	private MobileElement libPg_lbl_bookOfTheMonth;
	
	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='book_of_the_section']/android.widget.ImageView[@resource-id='cover_image']")
	private MobileElement libPg_img_bookOfTheMonthCoverImg;
	
	@iOSXCUITFindBy(accessibility = "book_of_the_month_author")
	@AndroidFindBy(xpath = "//*[@resource-id='book_of_the_month_author']")
	private MobileElement libPg_lbl_bookOfTheMonthAuthour;
	
	@iOSXCUITFindBy(accessibility = "view_book_details_btn")
	@AndroidFindBy(xpath = "//*[@resource-id='view_book_details_btn']")
	private MobileElement libPg_btn_viewbookdetail;
	
	@iOSXCUITFindBy(accessibility = "LIBRARY_AVAILABILITY")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_AVAILABILITY']")
	private MobileElement homePageCheck;

	@iOSXCUITFindBy(accessibility = "openProgram")
	@AndroidFindBy(xpath = "//*[@resource-id='openProgram']")
	private MobileElement openProgramSection;
	
	@iOSXCUITFindBy(accessibility = "See Featured ")
	@AndroidFindBy(xpath = "//*[@resource-id='See Featured ']")
	private MobileElement PrdDtPg_lbl_header;
	
	@iOSXCUITFindBy(accessibility = "FEATURE_CURATED_LIST_LINK")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_LINK']")
	private MobileElement libPg_btn_CarouselSeeAll;
		
	@iOSXCUITFindBy(accessibility = "txt_program_books_button")
	@AndroidFindBy(xpath = "//*[@resource-id='txt_program_books_button']")
	private MobileElement featured_program_details;
	
	@iOSXCUITFindBy(accessibility = "txt_program_books_button")
	@AndroidFindBy(xpath = "//*[@resource-id='txt_program_books_button']")
	private MobileElement PrgdtPg_lbl_header;
	
	public MobileElement getFeaturePrg_program_title()
	{
		return featurePrg_program_title;
	}
	
	public MobileElement getFeaturePrg_panner() {
		return featurePrg_panner;
	}

	public MobileElement verifyOpenProgramSection() {
		return openProgramSection;
	}
	public MobileElement getLibPg_lbl_featurePrograms() {
		return libPg_lbl_featurePrograms;
	}

	public MobileElement homePageCheck() {
		return homePageCheck;
	}

	public MobileElement getPrdDtPg_lbl_header() {
		return PrdDtPg_lbl_header;
	}

	public MobileElement getLibPg_btn_CarouselSeeAll() {
		return libPg_btn_CarouselSeeAll;
	}


	public MobileElement getLibPg_lbl_featurePrgName() {
		return libPg_lbl_featurePrgName;
	}

	public MobileElement getLibPg_btn_viewPrgDetail() {
		return libPg_btn_viewPrgDetail;
	}

	public MobileElement getLibPg_lbl_bookOfTheMonth() {
		return libPg_lbl_bookOfTheMonth;
	}

	public MobileElement getLibPg_img_bookOfTheMonthCoverImg() {
		return libPg_img_bookOfTheMonthCoverImg;
	}

	public MobileElement getLibPg_lbl_bookOfTheMonthAuthour() {
		return libPg_lbl_bookOfTheMonthAuthour;
	}

	public MobileElement getLibPg_btn_viewbookdetail() {
		return libPg_btn_viewbookdetail;
	}

/****************** Action Methods **********************/
	
	public void clickFeaturedprogramBanner()
	{
		if(isElementPresent(featurePrg_panner_details))
		{
			ClickOnMobileElement(featurePrg_panner_details);
		}
	}
	
	public void navigatetoprogram()
	{
		if(isElementPresent(featured_program_details))
		{
			ClickOnMobileElement(featured_program_details);
		}
	}
	
	public boolean featurePrgDisplay() {
		boolean featureDisplay = false;
		if (isElementPresent(libPg_lbl_featurePrograms)) {
			featureDisplay =true;
			logger.info("User is able to see feaured program");
		}
		return featureDisplay;
	}
	
	public boolean clickonFeaturePrgViewAllBtn() {
		boolean dtPgnav = false;
		ClickOnMobileElement(libPg_btn_viewPrgDetail);
		if (isElementPresent(PrgdtPg_lbl_header)) {
			dtPgnav = true;
		}
		return dtPgnav;
	}
	
	public boolean clickOnFeatureCarouselSeeAll() {
		boolean feature = false;
		if(isElementPresent(libPg_btn_CarouselSeeAll))
		{
		ClickOnMobileElement(libPg_btn_CarouselSeeAll);
		}
		if (isElementPresent(PrdDtPg_lbl_header)) {
			feature = true;
		}
		return feature;
	}
	
	public void featureBannerCheck() {
		for(int i = 0;i<=6;i++) {
			if(isElementPresent(featurePrg_panner)) {
				break;
			}
			else {
				swipeDown();
			}
		}
	}

	public void clickTitlesInFeaturedReadingProgram()
	{
		ClickOnMobileElement(titles_In_Featured_Reading_Program);
	}

	public MobileElement verifyProgramDetailsScreen() {
		return programDetailsScreen;

	}

}
