package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Holds extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(Holds.class);

    public Holds(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    /************************ Locators *************************/

    @iOSXCUITFindBy(accessibility = "btnHold")
    @AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
    private MobileElement holds_lbl;

    @iOSXCUITFindBy(accessibility = "HOLDS")
    @AndroidFindBy(xpath = "//*[@text='HOLDS']")
    private MobileElement holds_position_lbl;

    @iOSXCUITFindBy(accessibility = "btnHoldInfo0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnHoldInfo')]")
    private MobileElement holds_tooltip_lbl;

    @iOSXCUITFindBy(accessibility = "btnAlertOkay")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
    private MobileElement holds_tooltip_ok;

    @iOSXCUITFindBy(accessibility = "btnAlertOkay")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
    private MobileElement holds_clickOk_lbl;

    @iOSXCUITFindBy(accessibility = "Profiles_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id='Profiles_Menu']")
    private MobileElement clickProfile_lbl;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement clickProfileHam_lbl;

    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU']")
    private MobileElement clickMenu_lbl;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement clickEdit_lbl;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement clickBack_lbl;

    @iOSXCUITFindBy(accessibility = "sort_lbl_defaultlatest")
    @AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_defaultlatest']")
    private MobileElement sort_lbl_defaultlatest;

    @iOSXCUITFindBy(accessibility = "sort_lbl_latestadded")
    @AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_latestadded']")
    private MobileElement sort_lbl_latestadded;

    @iOSXCUITFindBy(accessibility = "sortTitles_lbl")
    @AndroidFindBy(xpath = "//*[@resource-id='sortTitles_lbl']")
    private MobileElement sortTitles_lbl;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement sort_lbl_viewTitles;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement ratingOption_lbl;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement ratingSelected_lbl;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement optionAtoZ_lbl;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement viewTitlesAtoZ_lbl;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "DUMMY")
    private MobileElement viewOptionSelected_lbl;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Holds')])[2]")
    @AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
    private MobileElement holds_lbl_footer;

    @iOSXCUITFindBy(accessibility = "imgPencilIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='imgPencilIcon']")
    private MobileElement edit_icon;

    @iOSXCUITFindBy(accessibility = "imgPencilIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='imgPencilIcon']")
    private MobileElement pencil_icon;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement myprofile_page;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"btnHoldInfo0\"]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnHoldInfo')]")
    private MobileElement tooltip_lbl;

    @iOSXCUITFindBy(accessibility = "btnAlertOkay")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnAlertOkay')]")
    private MobileElement tooltipAlertOk;

    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'ALERT_MESSAGE')]")
    private MobileElement tooltipAlertMsg;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
    private MobileElement description_lbl;

    @iOSXCUITFindBy(accessibility = "txtCheckoutHistory")
    @AndroidFindBy(xpath = "//*[@resource-id='txtCheckoutHistory']")
    private MobileElement checkout_lbl;

    @iOSXCUITFindBy(accessibility = "edit_profile_save")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
    private MobileElement save_btn;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement close_btn;

    @iOSXCUITFindBy(accessibility = "btnHold")
    @AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
    private MobileElement Holds_page;

    @iOSXCUITFindBy(accessibility = "mystuffListView0")
    @AndroidFindBy(xpath = "//*[@text='HOLDS']")
    private MobileElement hold_title;

    @iOSXCUITFindBy(accessibility = "//*[@content-desc='Filter, ']")
    @AndroidFindBy(xpath = "//*[@content-desc='Filter, ']")
    private MobileElement Filter_btn;

    @iOSXCUITFindBy(accessibility = "SORT_BY_RATING")
    @AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_RATING']")
    private MobileElement SORT_BY_RATING;

    @iOSXCUITFindBy(accessibility = "SORT_BY_ATOZ")
    @AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_ATOZ']")
    private MobileElement SORT_BY_ATOZ;

    @iOSXCUITFindBy(accessibility = "SORT_BY_LATEST_HOLD")
    @AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_LATEST_HOLD']")
    private MobileElement SORT_BY_LATEST_HOLD;

    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'checkout_title_test_id')]")
    private MobileElement holds_title;

    @iOSXCUITFindBy(accessibility = "Sort_icon_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='Sort_icon_test_id']")
    private MobileElement Holds_title_sort;

    @iOSXCUITFindBy(accessibility = "Filter_icon_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='Filter_icon_test_id']")
    private MobileElement Holds_Filter;

    @iOSXCUITFindBy(accessibility = "List_Grid_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
    private MobileElement Holds_gridView;

    @iOSXCUITFindBy(accessibility = "List_Grid_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
    private MobileElement Holds_listView;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
    private MobileElement click_MyShelf;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkout_flat_list_test_id\"]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup")
    private List<MobileElement> Holds_titles_hdr;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkout_flat_list_test_id\"]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']//*[contains(@resource-id,'viewGridContainer')]")
    private List<MobileElement> Holds_Gridview_titles_hdr;

    @iOSXCUITFindBy(accessibility = "txtNoDataFound")
    @AndroidFindBy(xpath = "//*[@text='You currently have no Holds.']")
    private MobileElement Holds_Notitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkout_flat_list_test_id\"]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Checkout_title_click_test_id')]")
    private List<MobileElement> Holds_Gridview_ImageTitle_hdr;

    @iOSXCUITFindBy(accessibility = "mystuffListView0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'mystuffListView')]")
    private MobileElement Holds_Position;

    @iOSXCUITFindBy(accessibility = "btnHoldInfo")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnHoldInfo')]")
    private MobileElement Holds_Tooltip;

    @iOSXCUITFindBy(accessibility = "btnAddToWishList")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnAddToWishList')]")
    private MobileElement Addtowishlist_PrimaryActionsbtn;

    @iOSXCUITFindBy(accessibility = "Download_handler_test_id0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Download_handler_test_id0')]")
    private MobileElement Holds_PrimaryActionsbtn;

    @iOSXCUITFindBy(accessibility = "Download_toggle_test_id0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Download_toggle_test_id0')]")
    private MobileElement Holds_SecondaryActionsbtn;

    @iOSXCUITFindBy(accessibility = "Download_handler_test_id0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Download_handler_test_id0')]")
    private MobileElement Placeonhold_avl;

    @iOSXCUITFindBy(accessibility = "DOWNLOAD")
    @AndroidFindBy(xpath = "//*[@resource-id='DOWNLOAD']")
    private MobileElement primary_button;

    @iOSXCUITFindBy(accessibility = "REMOVE_HOLD")
    @AndroidFindBy(xpath = "//*[@resource-id='REMOVE_HOLD']")
    private MobileElement RemoveHold_button;

    @iOSXCUITFindBy(accessibility = "ADD_TO_WISH_LIST")
    @AndroidFindBy(xpath = "//*[@resource-id='ADD_TO_WISH_LIST']")
    private MobileElement AddtoWishlistHold_button;

    @iOSXCUITFindBy(accessibility = "WISH_SUSPEND_NOW")
    @AndroidFindBy(xpath = "//*[@resource-id='WISH_SUSPEND_NOW']")
    private MobileElement SuspendNowHold_button;

    @iOSXCUITFindBy(accessibility = "REMOVE_WISHLIST")
    @AndroidFindBy(xpath = "//*[@resource-id='REMOVE_WISHLIST']")
    private MobileElement RemovewishlistHold_button;

    @iOSXCUITFindBy(accessibility = "Download_toggle_test_id0")
    @AndroidFindBy(xpath = "//*[@resource-id='Download_toggle_test_id0']")
    private MobileElement ActivateHold_button;

    @iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
    @AndroidFindBy(xpath = "//*[@resource-id='btnPurchaseRequest']")
    private MobileElement PurchaseRequest_button;

    @iOSXCUITFindBy(accessibility = "btnDownload")
    @AndroidFindBy(xpath = "//*[@resource-id='btnDownload']")
    private MobileElement btnDownload;

    @iOSXCUITFindBy(accessibility = "btnCheckoutHistory")
    @AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
    private MobileElement History_button;


    @iOSXCUITFindBy(xpath = "//*[@name='CheckoutView']//XCUIElementTypeOther[contains(@name,'link')]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='CheckoutView']//*[contains(@resource-id,'btn')]")
    private List<MobileElement> History_titles_hdr;


    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='CHECKOUT']")
    private MobileElement Checkout_button;

    public MobileElement getCheckout_button() {
        return Checkout_button;
    }

    public List<MobileElement> getHistory_titles_hdr() {
        return History_titles_hdr;
    }

    public MobileElement getHistory_button() {
        return History_button;
    }

    public MobileElement getPurchaseRequest_button() {
        return PurchaseRequest_button;
    }

    public MobileElement getActivateHold_button() {
        return ActivateHold_button;
    }

    public MobileElement getRemoveHold_button() {
        return RemoveHold_button;
    }

    public MobileElement getAddtoWishlistHold_button() {
        return AddtoWishlistHold_button;
    }

    public MobileElement getSuspendNowHold_button() {
        return SuspendNowHold_button;
    }

    public MobileElement getRemovewishlistHold_button() {
        return RemovewishlistHold_button;
    }

    public MobileElement getFilter_btn() {
        return Filter_btn;
    }

    public MobileElement getSORT_BY_RATING() {
        return SORT_BY_RATING;
    }

    public MobileElement getSORT_BY_ATOZ() {
        return SORT_BY_ATOZ;
    }

    public MobileElement getSORT_BY_LATEST_HOLD() {
        return SORT_BY_LATEST_HOLD;
    }

    public MobileElement getHolds_page() {
        return Holds_page;
    }

    public MobileElement getHolds_lbl_footer() {
        return holds_lbl_footer;
    }

    public MobileElement getEditIcon() {
        return edit_icon;
    }

    public MobileElement getPencilIcon() {
        return pencil_icon;
    }

    public MobileElement getMyProfile_page() {
        return myprofile_page;
    }

    public MobileElement getCheckout_lbl() {
        return checkout_lbl;
    }

    public MobileElement getTooltip() {
        return tooltip_lbl;
    }

    public MobileElement getTooltipAlertOk() {
        return tooltipAlertOk;
    }

    public MobileElement getTooltipAlertMsg() {
        return tooltipAlertMsg;
    }

    public MobileElement getViewDescription() {
        return description_lbl;
    }

    public MobileElement getSavebtn_option() {
        return save_btn;
    }

    public MobileElement getHolds_Position() {
        return Holds_Position;
    }

    public MobileElement getHolds_Tooltip() {
        return Holds_Tooltip;
    }

    public MobileElement getHolds_PrimaryActionsbtn() {
        return Holds_PrimaryActionsbtn;
    }

    public MobileElement getHolds_SecondaryActionsbtn() {
        return Holds_SecondaryActionsbtn;
    }

    public MobileElement getPlaceonhold_avl() {
        return Placeonhold_avl;
    }

    public MobileElement getHolds_Notitle() {
        return Holds_Notitle;
    }

    public MobileElement getholds_title() {
        return holds_title;
    }

    public MobileElement getHolds_title_sort() {
        return Holds_title_sort;
    }

    public MobileElement getHolds_Filter() {
        return Holds_Filter;
    }

    public MobileElement getHolds_gridView() {
        return Holds_gridView;
    }

    public MobileElement getHolds_listView() {
        return Holds_listView;
    }

    public List<MobileElement> getHolds_titles_hdr() {
        return Holds_titles_hdr;
    }

    public List<MobileElement> getHolds_Gridview_titles_hdr() {
        return Holds_Gridview_titles_hdr;
    }

    public List<MobileElement> getHolds_Gridview_ImageTitle_hdr() {
        return Holds_Gridview_ImageTitle_hdr;
    }

    /******************** Action methods *************************/

    public void clickHoldView() {
        if (isElementPresent(Holds_gridView)) {
            ClickOnMobileElement(Holds_gridView);
        } else {
            ClickOnMobileElement(Holds_listView);
        }
    }

    public void clickMyShelf() {
        if (isElementPresent(click_MyShelf)) {
            ClickOnMobileElement(click_MyShelf);
        }
    }

    public void clickdownLoad() {
        if (isElementPresent(btnDownload)) {
            ClickOnMobileElement(btnDownload);
        }
    }

    public void clickSecondarybutton() {
        if (isElementPresent(Holds_SecondaryActionsbtn)) {
            ClickOnMobileElement(Holds_SecondaryActionsbtn);
        }
        if (isElementPresent(Addtowishlist_PrimaryActionsbtn)) {
            ClickOnMobileElement(Addtowishlist_PrimaryActionsbtn);
        }
    }

    public void clickPurchaseRequest_button() {
        if (isElementPresent(PurchaseRequest_button)) {
            ClickOnMobileElement(PurchaseRequest_button);
        }
    }

    public void clickHistory_button() {

        ClickOnMobileElement(History_button);
    }

    public void clickprimaryoptions() {
        if (isElementPresent(Holds_PrimaryActionsbtn)) {
            ClickOnMobileElement(Holds_PrimaryActionsbtn);

        }
        if (isElementPresent(Addtowishlist_PrimaryActionsbtn)) {
            ClickOnMobileElement(Addtowishlist_PrimaryActionsbtn);
        }

    }

    public void ClickonHoldsGridview() {
        ClickOnMobileElement(Holds_gridView);
    }

    public void clickFilterHold() {
        ClickOnMobileElement(Filter_btn);
    }

    public void clickRatingHold() {
        ClickOnMobileElement(SORT_BY_RATING);
    }

    public void clickATOZHold() {
        ClickOnMobileElement(SORT_BY_ATOZ);
    }

    public void clickSortByLatestHold() {
        ClickOnMobileElement(SORT_BY_LATEST_HOLD);
    }

    public void clickMoreoptions() {
        if (isElementPresent(primary_button)) {
            ClickOnMobileElement(primary_button);
        }
    }

    public MobileElement getHold_title() {
        return hold_title;
    }

    public void clickHolds() {
        waitFor(3000);
        ClickOnMobileElement(holds_lbl);
    }

    public void clickHoldsPage() {
        ClickOnMobileElement(holds_lbl);
    }

    public void viewHoldsPosition() {
        if (isElementPresent(holds_position_lbl)) {
            ClickOnMobileElement(holds_position_lbl);
        }
    }

    public void viewTooltip() {
        ClickOnMobileElement(holds_tooltip_lbl);
    }

    public void clickTooltip() {
        if (isElementPresent(holds_tooltip_lbl)) {
            ClickOnMobileElement(holds_tooltip_lbl);
        }
    }

    public void clickTooltipOK() {
        if (isElementPresent(holds_tooltip_ok)) {
            ClickOnMobileElement(holds_tooltip_ok);
        }
    }

    public void clickOk() {
        if (isElementPresent(holds_clickOk_lbl)) {
            ClickOnMobileElement(holds_clickOk_lbl);
        }
    }

    public void clickProfile() {
        ClickOnMobileElement(clickProfile_lbl);
    }

    public void clickProfileHamberger() {
        ClickOnMobileElement(clickProfileHam_lbl);
    }

    public void clickMenu() {
        ClickOnMobileElement(clickMenu_lbl);
    }

    public void clickEdit() {
        ClickOnMobileElement(clickEdit_lbl);
    }

    public void clickBack() {
        ClickOnMobileElement(clickBack_lbl);
    }

    public void sortDefaultLatest() {
        ClickOnMobileElement(sort_lbl_defaultlatest);
    }

    public void sortLatestadded() {
        ClickOnMobileElement(sort_lbl_latestadded);
    }

    public void sortViewTitles() {
        ClickOnMobileElement(sort_lbl_viewTitles);
    }

    public void sortTitles() {
        ClickOnMobileElement(sortTitles_lbl);
    }

    public void ratingOption() {
        ClickOnMobileElement(ratingOption_lbl);
    }

    public void ratingSelected() {
        ClickOnMobileElement(ratingSelected_lbl);
    }

    public void optionAtoZ() {
        ClickOnMobileElement(optionAtoZ_lbl);
    }

    public void viewTitlesAtoZ() {
        ClickOnMobileElement(viewTitlesAtoZ_lbl);
    }

    public void viewOptionSelected() {
        ClickOnMobileElement(viewOptionSelected_lbl);
    }

    public void saveBtnOption() {
        if (isElementPresent(save_btn)) {
            ClickOnMobileElement(save_btn);
        }
    }

    public void closeBtnOption() {
        if (isElementPresent(close_btn)) {
            ClickOnMobileElement(close_btn);
        }
    }

    public void clickSuspendnow() throws Throwable {

        if (isElementPresent(RemoveHold_button)) {
            ClickOnMobileElement(RemoveHold_button);
        }
        if (isElementPresent(SuspendNowHold_button)) {
            ClickOnMobileElement(SuspendNowHold_button);
        }
    }

    public void clickRemoveHold() throws Throwable {
        if (isElementPresent(SuspendNowHold_button)) {
            ClickOnMobileElement(SuspendNowHold_button);

            WaitForMobileElement(primary_button);

            clickprimaryoptions();

            ClickOnMobileElement(RemoveHold_button);
        }
        if (isElementPresent(RemoveHold_button)) {
            ClickOnMobileElement(RemoveHold_button);
        }
    }

    public void clickAddtoWishlist() {
        if (isElementPresent(RemovewishlistHold_button)) {
            ClickOnMobileElement(RemovewishlistHold_button);
            WaitForMobileElement(primary_button);
            clickprimaryoptions();

            ClickOnMobileElement(AddtoWishlistHold_button);
        }
        ClickOnMobileElement(AddtoWishlistHold_button);
    }

    public void clickRemovewishlist() {
        if (isElementPresent(AddtoWishlistHold_button)) {
            ClickOnMobileElement(AddtoWishlistHold_button);

            WaitForMobileElement(Holds_PrimaryActionsbtn);
            clickprimaryoptions();

            ClickOnMobileElement(RemovewishlistHold_button);
        }
        if (isElementPresent(RemovewishlistHold_button)) {
            ClickOnMobileElement(RemovewishlistHold_button);
        }
    }

    public void clickActivateHold_button() {

        ClickOnMobileElement(ActivateHold_button);

        if (isElementPresent(RemoveHold_button)) {
            ClickOnMobileElement(RemoveHold_button);

//				clickprimaryoptions();
//				
//				ClickOnMobileElement(SuspendNowHold_button);

//				clickprimaryoptions();
//				
//				ClickOnMobileElement(ActivateHold_button);
        }

        if (isElementPresent(SuspendNowHold_button)) {
            ClickOnMobileElement(SuspendNowHold_button);
//				clickprimaryoptions();
//				
//				ClickOnMobileElement(ActivateHold_button);
        }

    }

    public void clickRemoveHoldTitle_button() {

        ClickOnMobileElement(ActivateHold_button);

        if (isElementPresent(RemoveHold_button)) {
            ClickOnMobileElement(RemoveHold_button);

//			clickprimaryoptions();
//			
//			ClickOnMobileElement(SuspendNowHold_button);

//			clickprimaryoptions();
//			
//			ClickOnMobileElement(ActivateHold_button);
        }

        if (isElementPresent(SuspendNowHold_button)) {
            ClickOnMobileElement(SuspendNowHold_button);
//			clickprimaryoptions();
//			
            ClickOnMobileElement(ActivateHold_button);

            ClickOnMobileElement(RemoveHold_button);
//			ClickOnMobileElement(ActivateHold_button);
        }

    }


}
