package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class InterestSurvey extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(InterestSurvey.class);

	public InterestSurvey(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Set Your Reading Interests\"]")
	@AndroidFindBy(xpath = "//*[@text='Set Your Reading Interests']")
	private MobileElement reading_Interests_hdr;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_TITLE']")
	private MobileElement reading_Interests_hdr1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_TOPICS']//*[contains(@resource-id,'INTEREST_SURVEY_TOPICS')]")
	public List<MobileElement> reading_topics;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" Juvenile Unselected\"]")
	@AndroidFindBy(xpath = "//*[@text='Juvenile']")
	private MobileElement options_juvenile;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" Adult Unselected\"]")
	@AndroidFindBy(xpath = "//*[@text='Adult']")
	private MobileElement options_adult;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" Young Adult Unselected\"]")
	@AndroidFindBy(xpath = "//*[@text='Set Your Reading Interests']")
	private MobileElement options_young_adult;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_SAVE")
	@AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_SAVE']")
	private MobileElement save_interests;

	@iOSXCUITFindBy(accessibility = "cancel")
	@AndroidFindBy(xpath = "//*[@text='cancel']")
	private MobileElement cancel_interests;
	
	@iOSXCUITFindBy(accessibility = "Back")
	@AndroidFindBy(xpath = "//*[@text='Back']")
	private MobileElement interests_back;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" Back\"]")
	@AndroidFindBy(xpath = "//*[@text='Back']")
	private MobileElement profile_hdr;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement profile_icon;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"ok_button\"])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
	private MobileElement confirmyes;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	private MobileElement alertmsg;

	public MobileElement getAlertmsg() {
		return alertmsg;
	}

	public MobileElement getReading_Interests_hdr1() {
		return reading_Interests_hdr1;
	}

	public MobileElement getProfile_hdr() {
		return profile_hdr;
	}

	public MobileElement getReading_Interests_hdr() {
		return reading_Interests_hdr;
	}

	public MobileElement getSave_interests() {
		return save_interests;
	}

	public MobileElement getOptions_juvenile() {
		return options_juvenile;
	}

	public MobileElement getOptions_young_adult() {
		return options_young_adult;
	}

	public MobileElement getOptions_adult() {
		return options_adult;
	}

	public void selectAgelevelgroup(String ageLevel) {
		switch (ageLevel) {
		case "adult":
			ClickOnMobileElement(options_adult);
			break;
		case "youngadult":
			ClickOnMobileElement(options_young_adult);
			break;
		case "juvenile":
			ClickOnMobileElement(options_juvenile);
			break;
		}
	}

	public void saveChanges() {
		ClickOnMobileElement(save_interests);
	}
	public void cancelChanges() {
		if(isElementPresent(cancel_interests))
		{
		ClickOnMobileElement(cancel_interests);
		}
	}

	public void interestback() {
		ClickOnMobileElement(interests_back);
	}

	public void clickEditprofile() {
		ClickOnMobileElement(profile_icon);
	}

	public void clickBack() {
		if (isElementPresent(profile_icon)) {
			ClickOnMobileElement(profile_icon);
		}
		if (isElementPresent(interests_back)) {
			ClickOnMobileElement(interests_back);
		}

	}

	public void clickprofileBack() {
		if (isElementPresent(profile_hdr)) {
			ClickOnMobileElement(profile_hdr);
		}
	}

	public void closeButton() {
		ClickOnMobileElement(profile_icon);

	}

	public void confirmpopup() {
		if (isElementPresent(confirmyes)) {
			ClickOnMobileElement(confirmyes);
		}
	}

}
