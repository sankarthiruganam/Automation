package pom.kidszone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class LoginPage extends CommonActions {

    public ThreadLocal<String> newUserName = ThreadLocal.withInitial(() -> "");

    public LoginPage(AppiumDriver driver) {

        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    // *********************************Locator********************************************//

    @iOSXCUITFindBy(accessibility = "loc_txtboxLibrarySearch")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_txtLibSearch')]")
    public MobileElement logo_txt_Search;

    @iOSXCUITFindBy(accessibility = "loc_btnlibrarySearch")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[@content-desc=\"Search\"]")
    public MobileElement logo_btn_search;

    @iOSXCUITFindBy(accessibility = "loc_btnMatchingLibrarySelect")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView")
    public List<MobileElement> logo_lbl_librariessearchresult;

    @iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
    @AndroidFindBy(id = "loc_txtLibraryId")
    private MobileElement signIn_txt_libId;

    @iOSXCUITFindBy(accessibility = "Done")
    @AndroidFindBy(id = "//*[@resource-id='Done']")
    public MobileElement logo_btn_Done;

    @iOSXCUITFindBy(accessibility = "loc_btnSignin")
    @AndroidFindBy(xpath = "(//*[@text = \"Sign In\"])[2]")
    private MobileElement logo_btn_signin;

    @iOSXCUITFindBy(accessibility = "No, Thanks")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"No, Thanksbutton, \"]")
    private MobileElement homesetPref_btn_Nothanks;

    @iOSXCUITFindBy(accessibility = "loc_msgSnackbarFailed")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_msgSnackbarFailed')]")
    private MobileElement error_Login_Page;

    @iOSXCUITFindBy(accessibility = "alertDismiss")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'alertDismiss')]")
    private MobileElement remindme_btn_Upgrade;

    @iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_CANCEL")
    @AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_CANCEL']")
    private MobileElement homesetPref_btn_Nothanks2;

    // @AndroidFindBy(id = "loc_txtSigninPin")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_txtSigninPin')]")
    @iOSXCUITFindBy(accessibility = "loc_txtboxSigninPIN")
    private MobileElement signIn_txt_libPwd;

    @iOSXCUITFindBy(accessibility = "MYLIBRARY")
    @AndroidFindBy(xpath = "//*[@resource-id='MYLIBRARY']")
    private MobileElement new_Footerlibrary;

    @iOSXCUITFindBy(accessibility = "My Library")
    @AndroidFindBy(xpath = "//*[contains(@text,'Library')]")
    private MobileElement old_Footerlibrary;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
    private MobileElement new_MyShelf;

    @iOSXCUITFindBy(accessibility = "MyShelf")
    @AndroidFindBy(xpath = "//*[@resource-id='MyShelf']")
    private MobileElement old_MyShelf;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Menu\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Menu\"]")
    private MobileElement logo_btn_menu;

    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Menu, \"]")
    private MobileElement logo_btn_menu1;

    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU']")
    private MobileElement logo_btn_menu2;

    @iOSXCUITFindBy(accessibility = "Profiles_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id='Profiles_Menu']")
    private MobileElement menuList_profile1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Profiles, button\"]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@content-desc=\"Legal\"])[1]")
    private MobileElement menuList_profile;

    @iOSXCUITFindBy(accessibility = "CloseCTA")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'alertDismiss')]")
    private MobileElement force_upgrade_popup;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Close to home page')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'btnBackIcon')]")
    private MobileElement close_interest;

    @AndroidFindBy(xpath = "//*[@text='Allow']")
    private MobileElement notification_confirm_popup;

    @iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_TITLE']")
    private MobileElement readingList_Title;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@text='Back']")
    private MobileElement readingList_Popup_Back;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Reading Interests')])[1]")
    @AndroidFindBy(xpath = "//*[@text='Reading Interests']")
    private MobileElement readingInterest_Heading;

    // ===================================================================================
    // 26/06/23

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Logout, button\"]")
    @AndroidFindBy(xpath = "//*[@text='Logout']")
    private MobileElement home_btn_Logout;

    @iOSXCUITFindBy(accessibility = "Sign_out_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id='Sign_out_Menu']")
    private MobileElement home_btn_Logout1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Yes\"]")
    @AndroidFindBy(xpath = "//*[@text='YES']")
    private MobileElement home_btn_Logout_Confirmation;

    @iOSXCUITFindBy(accessibility = "SIGNOUT_YES")
    @AndroidFindBy(xpath = "//*[@resource-id='SIGNOUT_YES']")
    private MobileElement home_btn_Logout_Confirmation1;

    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(id = "nav_menu")
    private MobileElement logo_txt_profile;

    @iOSXCUITFindBy(accessibility = "loc_txtLogoWelcome")
    @AndroidFindBy(id = "loc_txtLogoWelcome")
    private MobileElement logo_txt_Welcome;

    @iOSXCUITFindBy(accessibility = "loc_btnMatchingLibrarySelect")
    @AndroidFindBy(id = "values_text_vw")
    private List<MobileElement> logo_list_MatchingLibraries;

    @iOSXCUITFindBy(accessibility = "loc_txtLibraryNotFound")
    @AndroidFindBy(id = "error_text_view")
    private MobileElement logo_lbl_librarieserror;

    @iOSXCUITFindBy(accessibility = "loc_btnLibraryCloseSearch")
    @AndroidFindBy(id = "loc_btnLogoCloseSearch")
    public MobileElement logo_btn_close;

    @AndroidFindBy(id = "loc_txtLogoMatchingLibraries")
    public MobileElement logo_lbl_matchingLib;

    @iOSXCUITFindBy(accessibility = "loc_btnMatchingLibrarySelect")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView")
    private List<MobileElement> logo_lbl_libSearchResult;

    @iOSXCUITFindBy(xpath = "XCUIElementTypeTable/XCUIElementTypeCell[1]")
    @AndroidFindBy(id = "//*[@resource-id='dummy']")
    public MobileElement logo_txt_withoutPinLibrary;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,'alertDismiss')]")
    private MobileElement upgrade_popup_close;

    @iOSXCUITFindBy(accessibility = "loc_txtboxSigninPIN")
    // @AndroidFindBy(id = "loc_txtSigninPin")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_txtSigninPin')]")
    public MobileElement signIn_txt_libPin;

    @iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
    @AndroidFindBy(id = "loc_txtLibraryId")
    public MobileElement logo_txt_libraryId;

    @iOSXCUITFindBy(accessibility = "loc_txtboxSigninPIN")
    // @AndroidFindBy(id = "loc_txtSigninPin")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_txtSigninPin')]")
    private MobileElement logo_txt_libraryPin;

    @iOSXCUITFindBy(accessibility = "loc_btnSignin")
    @AndroidFindBy(id = "btn_login")
    private MobileElement logo_btn_login;

    @iOSXCUITFindBy(accessibility = "loc_msgSnackbarFailed")
    @AndroidFindBy(id = "error_text")
    private MobileElement logo_lbl_InvalidLoginError;

    @AndroidFindBy(id = "android:id/button2")
    public MobileElement logo_btn_errorPopClose;

    @iOSXCUITFindBy(accessibility = "loc_msgSnackbarFailed")
    @AndroidFindBy(id = "login_failed")
    private MobileElement logo_lbl_onlyIdLibInvalidloginError;

    @iOSXCUITFindBy(accessibility = "Card number should be alpha numeric characters, please enter valid card number")
    @AndroidFindBy(xpath = "//*[@text='Prefix Not Valid']")
    public MobileElement logo_lbl_invalidcardprefixLogin;

    @iOSXCUITFindBy(xpath = "dummy")
    @AndroidFindBy(xpath = "//*[@text='Whoops! It looks like your Prefix is invalid. Please try again']")
    private MobileElement login_lbl_invalidprefixerror;

    @iOSXCUITFindBy(accessibility = "No")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"No, \"]")
    private MobileElement home_btn_Logout_ConfirmationNo;

    @iOSXCUITFindBy(accessibility = "SIGNOUT_NO")
    @AndroidFindBy(xpath = "//*[@resource-id='SIGNOUT_NO']")
    private MobileElement home_btn_Logout_ConfirmationNo1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther[4]/XCUIElementTypeTextField")
    @AndroidFindBy(id = "fetv_lib_id")
    private MobileElement axis360_txt_libId;

    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(id = "fetv_lib_pin")
    private MobileElement axis360_txt_pin;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Login\"]")
    @AndroidFindBy(id = "btn_login")
    private MobileElement axis360_btn_login;

    @iOSXCUITFindBy(accessibility = "Profiles_Menu")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Profiles_Menu')]")
    private MobileElement menu_my_profile;

    @iOSXCUITFindBy(accessibility = "Username")
    @AndroidFindBy(xpath = "//*[@resource-id = 'username']")
    private MobileElement SSO_Username;

    @iOSXCUITFindBy(accessibility = "Password")
    @AndroidFindBy(xpath = "//*[@resource-id = 'password']")
    private MobileElement SSO_Password;

    @iOSXCUITFindBy(accessibility = "Log in")
    @AndroidFindBy(xpath = "//*[@text = 'Log in']")
    private MobileElement SSO_login;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeLink[@name=\"Continue\"]")
    @AndroidFindBy(xpath = "//*[@text = 'Continue']")
    private MobileElement SSO_login_continue;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id= 'txtTitle']")
    private MobileElement landingpage;

    @iOSXCUITFindBy(accessibility = "Preferences_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Preferences_Menu']")
    private MobileElement Preferences_Menu;

    @iOSXCUITFindBy(accessibility = "Help_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Help_Menu']")
    private MobileElement Help_Menu;

    @iOSXCUITFindBy(accessibility = "Patron_Support_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Patron_Support_Menu']")
    private MobileElement Patron_Support_Menu;

    @iOSXCUITFindBy(accessibility = "About_us_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'About_us_Menu']")
    private MobileElement About_us_Menu;
    @iOSXCUITFindBy(accessibility = "Privacy_Policy_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Privacy_Policy_Menu']")
    private MobileElement Privacy_Policy_Menu;

    @iOSXCUITFindBy(accessibility = "Terms & Conditions_Menu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Terms & Conditions_Menu']")
    private MobileElement term_Conditions;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='com.android.permissioncontroller:id/permission_allow_button']")
    private MobileElement boundlessAllow;

    public MobileElement getLogo_lbl_onlyIdLibInvalidloginError() {

        return logo_lbl_onlyIdLibInvalidloginError;
    }

    public MobileElement getHome_btn_Logout_Confirmation() {
        return home_btn_Logout_Confirmation;
    }

    public MobileElement getLogo_lbl_invalidprefixLogin() {
        return logo_lbl_invalidcardprefixLogin;
    }

    public List<MobileElement> getLogo_list_MatchingLibraries() {
        return logo_list_MatchingLibraries;
    }

    public MobileElement getLogo_txt_Welcome() {
        return logo_txt_Welcome;
    }

    public MobileElement getLogo_btn_login() {
        return logo_btn_login;
    }

    public MobileElement getLogo_lbl_librarieserror() {
        return logo_lbl_librarieserror;
    }

    public MobileElement getLogo_btn_menu() {
        return logo_btn_menu;
    }

    public MobileElement getLogo_btn_menu1() {
        return logo_btn_menu1;
    }

    public MobileElement getLogo_btn_menu2() {
        return logo_btn_menu2;
    }

    public MobileElement getSignIn_txt_libId() {
        return signIn_txt_libId;
    }

    public MobileElement getLogo_txt_libraryPin() {
        return logo_txt_libraryPin;
    }

    public MobileElement getLogo_btn_signin() {
        return logo_btn_signin;
    }

    public MobileElement getLogo_lbl_InvalidLoginError() {
        return logo_lbl_InvalidLoginError;
    }

    public List<MobileElement> getLogo_lbl_libSearchResult() {
        return logo_lbl_libSearchResult;
    }

    public MobileElement getLogin_lbl_invalidprefixerror() {
        return login_lbl_invalidprefixerror;
    }

    public MobileElement getLogo_txt_profile() {
        return logo_txt_profile;
    }

    public MobileElement getHome_btn_Logout_Confirmation1() {
        return home_btn_Logout_Confirmation1;
    }

    public MobileElement getAxis360_txt_libId() {
        return axis360_txt_libId;
    }

    public MobileElement getAxis360_txt_pin() {
        return axis360_txt_pin;
    }

    public MobileElement getHome_btn_Logout() {
        return home_btn_Logout;
    }

    public MobileElement getHome_btn_Logout1() {
        return home_btn_Logout1;
    }

    public MobileElement getReadingList_Title() {
        return readingList_Title;
    }

    public MobileElement boundlessAllow() {
        return boundlessAllow;
    }

    // *********************************Locator********************************************//

    public void notification_allow() {
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            waitFor(5000);
            if (isElementPresent(notification_confirm_popup))
                ClickOnMobileElement(notification_confirm_popup);
        }
    }

    public void navigate_PerferenceMenu() {
        ClickOnMobileElement(Preferences_Menu);
    }

    public void navigate_helpMenu() {
        ClickOnMobileElement(Help_Menu);
    }

    public void navigate_Patron_Support_Menu() {
        ClickOnMobileElement(Patron_Support_Menu);
    }

    public void navigate_Aboutus() {
        ClickOnMobileElement(About_us_Menu);
    }

    public void navigate_Privacy_Policy_Menu()
    {
        ClickOnMobileElement(Privacy_Policy_Menu);
    }
    public void navigate_termConditions()
    {
        ClickOnMobileElement(term_Conditions);
    }

    public MobileElement getError_Login_Page() {
        return error_Login_Page;
    }

    public void forceUpgrade() {
//		if (System.getProperty("platform").equalsIgnoreCase("IOS")) {
//		waitFor(5000);
//		if (isElementPresent(force_upgrade_popup)) {
//			ClickOnMobileElement(force_upgrade_popup);
//		}
//		if (isElementPresent(force_upgrade_popup)) {
//			ClickOnMobileElement(force_upgrade_popup);
//		}
//		}
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            waitFor(5000);
            if (isElementPresent(notification_confirm_popup))
                ClickOnMobileElement(notification_confirm_popup);
            logger.error("Welcome");
        }
    }

//	public void searchLibrary(String characters) throws InterruptedException {
//		
//		ClickOnMobileElement(logo_txt_Search);
//		SendKeysOnMobileElement(logo_txt_Search, characters);
//	}

    public void initiateSearch() {
        ClickOnMobileElement(logo_btn_search);
    }

    public void select_library() {
        int maxAttempts = 5;
        int waitTimeInSeconds = 2;
    
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            if (logo_lbl_librariessearchresult.size() > 0) {
                ClickOnMobileElement(logo_lbl_librariessearchresult.get(0));
                return; // Element is visible and clicked, no need for further attempts
            } else {
                // Wait for a short period (2 seconds)
                waitFor(waitTimeInSeconds * 1000);
            }
        }

        logger.error("Libraries list is not visible after " + (maxAttempts * waitTimeInSeconds) + " seconds.");
    }
    

    public void enterUserName(String userName) {
        ClickOnMobileElement(signIn_txt_libId);
        SendKeysOnMobileElement(signIn_txt_libId, userName);
    }

    public void clickSignInBtn() {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(logo_btn_Done)) {
                ClickOnMobileElement(logo_btn_Done);
            }
        }
        ClickOnMobileElement(logo_btn_signin);
    }

    public void handleNothankspopup() {
        if (isElementPresent(readingInterest_Heading)) {
            for (int i = 0; i < 10; i++) {
                if (isElementPresent(homesetPref_btn_Nothanks2)) {
                    break;
                } else {
                    swipeDown();
                }
            }
            ClickOnMobileElement(homesetPref_btn_Nothanks2);
        }
    }

    public void handleUpgradepopup() {
        if (isElementPresent(remindme_btn_Upgrade)) {
            swipeDown();
            ClickOnMobileElement(remindme_btn_Upgrade);
        }
    }

    public void enterPwd(String pwd) {
        ClickOnMobileElement(signIn_txt_libPwd);
        SendKeysOnMobileElement(signIn_txt_libPwd, pwd);
        swipeDown();
        hideMobileKeyboard();
    }

    public void clickmylibrary() {
        if (isElementPresent(new_Footerlibrary)) {
            ClickOnMobileElement(new_Footerlibrary);

        } else if (isElementPresent(old_Footerlibrary)) {
            ClickOnMobileElement(old_Footerlibrary);
        }
    }

    public void clickMyShelf() {
        if (isElementPresent(new_MyShelf)) {
            ClickOnMobileElement(new_MyShelf);

        } else if (isElementPresent(old_MyShelf)) {
            ClickOnMobileElement(old_MyShelf);
        }
    }

    public void loginwithId(String libraryid) {
        ClickOnMobileElement(signIn_txt_libId);
        SendKeysOnMobileElement(signIn_txt_libId, libraryid);
        if (System.getProperty("platform").equalsIgnoreCase("ios")) {
            ClickOnMobileElement(logo_btn_Done);
        }
        swipeDown();
        ClickOnMobileElement(logo_btn_signin);
    }

    public void clickFooterMenu() {
        // handleNothankspopup();
        if (isElementPresent(logo_btn_menu2)) {
            ClickOnMobileElement(logo_btn_menu2);
        } else if (isElementPresent(logo_btn_menu1)) {
            ClickOnMobileElement(logo_btn_menu1);
        } else if (isElementPresent(logo_btn_menu)) {
            ClickOnMobileElement(logo_btn_menu);
        }

    }

    public void clickMenuprofile() {

        if (isElementPresent(menuList_profile)) {

            ClickOnMobileElement(menuList_profile);
        }
        if (isElementPresent(menuList_profile1)) {
            ClickOnMobileElement(menuList_profile1);
        }

    }

    public void cancelViewInterest() {
        ClickOnMobileElement(homesetPref_btn_Nothanks2);
    }

    public void readingInterestPopupback() {
        if (isElementPresent(readingList_Title)) {
            ClickOnMobileElement(readingList_Popup_Back);
        }
    }

    public MobileElement readingInterestPopupHeading() {
        return readingList_Popup_Back;
    }

    public Boolean homePgNav() {
        Boolean homePagNav = false;
        if (isElementPresent(landingpage)) {
            homePagNav = true;
        } else {
            logger.info("User is not landing page");
        }
        return homePagNav;
    }

    public void searchmorethanthreeKeyword(String searchlibrary) {
        SendKeysOnMobileElement(logo_txt_Search, searchlibrary);
    }

    public void searchLibrary(String characters) {

        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			waitFor(5000);
//			if (isElementPresent(notification_confirm_popup))
//				ClickOnMobileElement(notification_confirm_popup);
//			if (isElementPresent(notification_confirm_popup))
//				ClickOnMobileElement(notification_confirm_popup);
        }
        ClickOnMobileElement(logo_txt_Search);
        SendKeysOnMobileElement(logo_txt_Search, characters);
    }

    public void logOut() {

        logger.info("logout out the screen");
        try {
            try {

                ClickOnMobileElement(homesetPref_btn_Nothanks);
                ClickOnMobileElement(logo_btn_menu);
                if (isElementPresent(logo_btn_menu)) {
                    ClickOnMobileElement(logo_btn_menu);
                } else if (isElementPresent(logo_btn_menu1)) {
                    ClickOnMobileElement(logo_btn_menu1);
                } else if (isElementPresent(logo_btn_menu2)) {
                    ClickOnMobileElement(logo_btn_menu2);
                }
                ClickOnMobileElement(home_btn_Logout1);
                ClickOnMobileElement(home_btn_Logout_Confirmation1);
            } catch (Exception e1) {
                logger.info("Set pref page is not displayed");
                ClickOnMobileElement(logo_btn_menu2);
                ClickOnMobileElement(home_btn_Logout1);
                ClickOnMobileElement(home_btn_Logout_Confirmation1);
            }

        } catch (Exception a) {
            try {

                ClickOnMobileElement(homesetPref_btn_Nothanks);
                if (isElementPresent(logo_btn_menu)) {
                    ClickOnMobileElement(logo_btn_menu);
                } else if (isElementPresent(logo_btn_menu1)) {
                    ClickOnMobileElement(logo_btn_menu1);
                } else if (isElementPresent(logo_btn_menu2)) {
                    ClickOnMobileElement(logo_btn_menu2);
                }
                ClickOnMobileElement(logo_btn_menu);
                ClickOnMobileElement(home_btn_Logout);
                ClickOnMobileElement(home_btn_Logout_Confirmation);
            } catch (Exception e) {
                logger.info("Set pref page is not displayed");
                if (isElementPresent(home_btn_Logout)) {
                    ClickOnMobileElement(home_btn_Logout);
                    if (isElementPresent(home_btn_Logout_Confirmation)) {
                        ClickOnMobileElement(home_btn_Logout_Confirmation);
                    }
                }
            }
        }
    }

    public Boolean libSuggestionAfterSearch() {
        Boolean listSize = true;
        if (logo_lbl_librariessearchresult.size() != 0) {
            logger.info("Size of the list : " + logo_lbl_librariessearchresult.size());
            logger.info("user able to see " + logo_lbl_librariessearchresult.size() + " suggetion ");
        } else {
            listSize = false;
            logger.info("Size of the list : " + logo_lbl_librariessearchresult.size());
            logger.info("User is not able to see suggeation after initiating search");
        }
        return listSize;
    }

    public void clearkeywords() {
        ClickOnMobileElement(logo_btn_close);
    }

    public Boolean suggestionKeywordCheck(String input) {
        Boolean keyword = true;
        if (logo_list_MatchingLibraries.size() != 0) {
            logger.info("Size of the list : " + logo_list_MatchingLibraries.size());
            logger.info("user able to see " + logo_list_MatchingLibraries.size() + " suggetion ");
        } else {
            keyword = false;
            logger.info("Size of the list : " + logo_list_MatchingLibraries.size());
            logger.info("User is not able to see suggestions");
        }
        return keyword;
    }

    public void clickmyprofile() {
        if (isElementPresent(menu_my_profile)) {
            ClickOnMobileElement(menu_my_profile);
        }
    }

    public void loginwithidandPin(String libraryid, String pin) {
        swipeDown();
        ClickOnMobileElement(logo_txt_libraryId);
        SendKeysOnMobileElement(logo_txt_libraryId, libraryid);
        if(isElementPresent(logo_txt_libraryPin)) {
            ClickOnMobileElement(logo_txt_libraryPin);
            SendKeysOnMobileElement(logo_txt_libraryPin, pin);
        }        
        if (System.getProperty("platform").equalsIgnoreCase("ios")) {
            ClickOnMobileElement(logo_btn_Done);
            ClickOnMobileElement(logo_btn_signin);
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            hideMobileKeyboard();
            ClickOnMobileElement(logo_btn_signin);

        }

    }

    public void closepopup() {
        if ((System.getProperty("platform").equalsIgnoreCase("android"))) {
            waitFor(2000);
            if (isElementPresent(upgrade_popup_close))
                ClickOnMobileElement(upgrade_popup_close);
            waitFor(2000);
            if (isElementPresent(upgrade_popup_close))
                ClickOnMobileElement(upgrade_popup_close);
        }
    }

    public void loginwithInvalidId(String libraryid) {
        SendKeysOnMobileElement(signIn_txt_libId, libraryid);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            ClickOnMobileElement(logo_btn_Done);
        }
        ClickOnMobileElement(logo_btn_signin);
    }

    public Boolean errorPopup() {
        Boolean suggestion = true;
        if (isElementPresent(logo_lbl_InvalidLoginError)) {
            logger.info("Error popup is avilable");
        } else {
            logger.info("Error popup is not avilable");
        }
        return suggestion;
    }

    public void enterPrefixLogin(String libraryid) {
        ClickOnMobileElement(signIn_txt_libId);
        String uniqueUserName = libraryid + RandomStringGenerate();
        newUserName.set(uniqueUserName);
        SendKeysOnMobileElement(signIn_txt_libId, uniqueUserName);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            ClickOnMobileElement(logo_btn_Done);
            ClickOnMobileElement(logo_btn_signin);
        } else {
            swipeDown();
            ClickOnMobileElement(logo_btn_signin);
        }
    }

    public void invalidLibraryidSearch(String libraryid) {
        SendKeysOnMobileElement(signIn_txt_libId, libraryid);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            ClickOnMobileElement(logo_btn_Done);
            ClickOnMobileElement(logo_btn_signin);
        } else {
            swipeDown();
            ClickOnMobileElement(logo_btn_signin);
        }
    }

    public void emptyLibraryidSearch() {
        swipeDown();
        ClickOnMobileElement(logo_btn_signin);
    }

    public void enterssopassword(String password) {
        WaitForMobileElement(SSO_Password);
        SendKeysOnMobileElement(SSO_Password, password);
        if (isElementPresent(logo_btn_Done)) {
            ClickOnMobileElement(logo_btn_Done);
        }
    }

    public void enterssoUsername(String username2) {
        WaitForMobileElement(SSO_Username);
        SendKeysOnMobileElement(SSO_Username, username2);
    }

    public void clickLogin() {
        ClickOnMobileElement(SSO_login);
    }

    public void clickContinue() {
        if (isElementPresent(SSO_login_continue)) {
            ClickOnMobileElement(SSO_login_continue);
        }
    }

    public void axis360UserLoginwithPin(String libId) {
        swipeDown();
        swipeDown();
        ClickOnMobileElement(axis360_txt_libId);
        SendKeysOnMobileElement(axis360_txt_libId, libId);
        ClickOnMobileElement(axis360_btn_login);
        try {
            ClickOnMobileElement(homesetPref_btn_Nothanks);
        } catch (Exception e) {
            logger.info("set pref page is not displayed");
        }
    }

    public void enterpinonly(String pin) {
        ClickOnMobileElement(logo_txt_libraryPin);
        SendKeysOnMobileElement(logo_txt_libraryPin, pin);
    }

    public void signInwithLibraryIdandPin(String libraryid, String pin) {
        ClickOnMobileElement(signIn_txt_libId);
        SendKeysOnMobileElement(signIn_txt_libId, libraryid + RandomStringGenerate());
        ClickOnMobileElement(signIn_txt_libPin);
        SendKeysOnMobileElement(signIn_txt_libPin, pin);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            ClickOnMobileElement(logo_btn_Done);
        } else {
            DriverManager.getDriver().hideKeyboard();
        }
        newUserName.set(signIn_txt_libId.getText());
        ClickOnMobileElement(logo_btn_signin);

    }

    public void skippedLibraryIdandPin(String libraryid, String pin) {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            SendKeysOnMobileElement(signIn_txt_libId, "");
            ClickOnMobileElement(logo_btn_Done);
            ClickOnMobileElement(logo_btn_signin);
        }
    }

    public Boolean searchLibSuggestion() {
        Boolean suggestion = true;
        if (logo_list_MatchingLibraries.size() != 0) {
            logger.info("User able to see matching libraries");
        } else {
            suggestion = false;
        }
        return suggestion;
    }

    public void navigateSearchResult() {
        for (int i = 0; i < logo_lbl_librariessearchresult.size(); i++) {
            logo_lbl_librariessearchresult.get(0).click();
        }
    }

    public Boolean viewNomatchingresults() {
        Boolean libmatchingresult = true;
        String nomatchingmessage = logo_lbl_librarieserror.getText();
        if (logo_lbl_librarieserror.isDisplayed()) {
            System.out.println(nomatchingmessage);
        } else {
            libmatchingresult = false;
            System.out.println("search message not displayed");
        }
        return libmatchingresult;
    }

    public Boolean logoutConfirmationPop() {
        Boolean display = true;
        if (isElementPresent(home_btn_Logout_Confirmation)) {
            display = true;
        } else if (isElementPresent(home_btn_Logout_Confirmation1)) {
            display = true;
        }
        return display;
    }

    public void clickSignOutNoBtn() {
        try {
            ClickOnMobileElement(home_btn_Logout_ConfirmationNo1);
        } catch (Exception e) {
            ClickOnMobileElement(home_btn_Logout_ConfirmationNo);
        }
    }

    public void clickSignOutYesBtn() {
        try {
            ClickOnMobileElement(home_btn_Logout_Confirmation1);
        } catch (Exception e) {
            ClickOnMobileElement(home_btn_Logout_Confirmation);
        }

    }

    public void clickSignout() {

        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(homesetPref_btn_Nothanks)) {
                ClickOnMobileElement(homesetPref_btn_Nothanks);
            }
            if (isElementPresent(logo_btn_menu1)) {
                ClickOnMobileElement(logo_btn_menu1);
                if (isElementPresent(home_btn_Logout1)) {
                    ClickOnMobileElement(home_btn_Logout1);

                } else if (isElementPresent(logo_btn_menu)) {
                    ClickOnMobileElement(logo_btn_menu);
                    if (isElementPresent(home_btn_Logout)) {
                        ClickOnMobileElement(home_btn_Logout);
                    }
                }
            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("android")) {
            try {
                if (isElementPresent(homesetPref_btn_Nothanks)) {
                    ClickOnMobileElement(homesetPref_btn_Nothanks);
                } else {
                    logger.info("Set pref page is not displayed");
                }
                ClickOnMobileElement(logo_btn_menu1);
                ClickOnMobileElement(home_btn_Logout1);
            } catch (Exception b) {
                if (isElementPresent(homesetPref_btn_Nothanks)) {
                    ClickOnMobileElement(homesetPref_btn_Nothanks);
                } else {
                    logger.info("Set pref page is not displayed");
                }
                ClickOnMobileElement(logo_btn_menu);
                ClickOnMobileElement(home_btn_Logout);
            }
        }

    }

    public void searchLibOrderCheck() {
        List<String> a = new ArrayList<>();
        List<String> b = new ArrayList<>();
        if (logo_list_MatchingLibraries.size() != 0) {
            for (int i = 0; i < logo_list_MatchingLibraries.size() - 1; i++) {
                String text = logo_list_MatchingLibraries.get(i).getText();
                a.add(text);
                b.add(text);
            }
            Collections.sort(b);
            for (int i = 0; i < logo_list_MatchingLibraries.size() - 1; i++) {
                if (a.get(i).equals(b.get(i))) {
                    logger.info("displayed in alphabatical order");
                }
            }
        }
    }

    public Boolean libSuggestionListSize() {
        Boolean listSize = true;
        if (logo_list_MatchingLibraries.size() <= 5 && logo_list_MatchingLibraries.size() != 0) {
            logger.info("Size of the list : " + logo_list_MatchingLibraries.size());
            logger.info("user able to see " + logo_list_MatchingLibraries.size() + " suggetion ");
        } else if (logo_list_MatchingLibraries.size() >= 5 && logo_list_MatchingLibraries.size() == 0) {
            listSize = false;
            logger.info("Size of the list : " + logo_list_MatchingLibraries.size());
            logger.info("User is able to see more than 5 suggestions");
        }
        return listSize;
    }

    public Boolean suggestionResultCheck() throws Exception {
        Boolean city = true;
        if (System.getProperty("platform").equalsIgnoreCase("android")) {
            MobileElement findElement = (MobileElement) DriverManager.getDriver()
                    .findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
                            + ".scrollIntoView(new UiSelector().text(\"CITY\"))"));
            if (isElementPresent(findElement)) {
                logger.info("User able to see City result for the given input");
            } else {
                city = false;
                logger.info("User not able to see City result for the given input");
            }
        } else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {

            scrollandCheck(logo_txt_withoutPinLibrary);
        }
        return city;
    }

    public void emptySearch() {
        ClickOnMobileElement(logo_txt_Search);
        logo_txt_Search.clear();
//		if (System.getProperty("platform").equalsIgnoreCase("android")) {
//			DriverManager.getDriver().executeScript("mobile: performEditorAction", ImmutableMap.of("action", "search"));
//		} else {
//			ClickOnMobileElement(logo_lbl_search);
//		}
    }

    public void clickBoundlessAllow() {
        ClickOnMobileElement(boundlessAllow);
    }

}
