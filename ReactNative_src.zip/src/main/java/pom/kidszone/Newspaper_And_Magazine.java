package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Newspaper_And_Magazine extends CommonActions {

    public Newspaper_And_Magazine(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public static final Logger logger = LoggerFactory.getLogger(ProfilePage.class);

    @iOSXCUITFindBy(accessibility = "third_party_header_PRESSRDR")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_header_PRESSRDR']")
    private MobileElement newspaperAndMagazineTitle;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Copy Available')]")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'Copy Available')])[1]")
    private MobileElement copies_Availble;

    @iOSXCUITFindBy(accessibility = "loc_txtPeoplesWaiting")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_txtPeoplesWaiting']")
    private MobileElement people_Waiting;

    @iOSXCUITFindBy(accessibility = "third_party_see_all_link_PRESSRDR")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement newspaperAndMagazineSeeAllLink;

    @iOSXCUITFindBy(accessibility = "third_party_see_all_link_PRESSRDR")
    @AndroidFindBy(xpath = "(//*[@resource-id='third_party_see_all_link_PRESSRDR'])[1]")
    private MobileElement newspaperSeeAllLink;

    @iOSXCUITFindBy(accessibility = "title page")
    @AndroidFindBy(xpath = "//*[@resource-id='reading-area']")
    private MobileElement eBookTitleScreen1;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Vertical scroll bar, 1 page\"]/ancestor::XCUIElementTypeWebView)[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='title page']")
    private MobileElement eBookTitleScreen2;

    @iOSXCUITFindBy(accessibility = "Back Button")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBack']")
    private MobileElement eBookTitleBackoption;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name='third_party_see_all_link_'])[1]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Publications see all, ')]")
    private MobileElement newspaperAndMagazineSeeAllLink_Article;

    @iOSXCUITFindBy(xpath = "(//*[@name='adp_card_title_text_bottom'])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='adp_card_title_text_bottom'])[1]")
    private MobileElement firstMagazine;
    @iOSXCUITFindBy(xpath = "//*[@label = 'Newspapers see all']")
    @AndroidFindBy(xpath = "//*[@content-desc = 'Newspapers see all, ']")
    private MobileElement newsPaperViewAll;

    @iOSXCUITFindBy(xpath = "//*[@label = 'Magazines see all']")
    @AndroidFindBy(xpath = "//*[@content-desc = 'Magazines see all, ']")
    private MobileElement magazinesViewAll;

    @iOSXCUITFindBy(accessibility = "third_party_see_all_link_PRESSRDR")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement newspaperAndMagazineInMyLibrary;

    @iOSXCUITFindBy(accessibility = "third_party_see_all_link_PRESSRDR")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement publicationSearchResult;

    @iOSXCUITFindBy(xpath = "//*[@label='Newspapers & Magazines']")
    @AndroidFindBy(xpath = "//*[contains(@text,'Newspapers & Magazines')]")
    private MobileElement newspaperAndMagazineAdvanceOption;

    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU']")
    private MobileElement clickMenu;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Relevance')])[2]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Relevance Radio Button')]")
    private MobileElement relevanceOption;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Popularity')])[2]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Popularity')]")
    private MobileElement popularityOption;
    
    @iOSXCUITFindBy(accessibility = "Profile Settings")
    @AndroidFindBy(xpath = "//*[@resource-id='Profile Settings']")
    private MobileElement profileSettings;
    
    @iOSXCUITFindBy(accessibility = "btnInsightAndBadgesDisplay")
    @AndroidFindBy(xpath = "//*[@resource-id='txtInsightAndBadgesDisplay']")
    private MobileElement insights_Badges;
    
    @iOSXCUITFindBy(accessibility = "insights_disabled_alert_no")
    @AndroidFindBy(xpath = "//*[@resource-id='insights_disabled_alert_no']")
    private MobileElement clickCancel;
    
    @iOSXCUITFindBy(accessibility = "insights_disabled_alert_yes")
    @AndroidFindBy(xpath = "//*[@resource-id='insights_disabled_alert_yes']")
    private MobileElement click_Disable;
    
    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
    private MobileElement alert_popup_title;
    
    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
    private MobileElement alert_popup_description;
    
    @iOSXCUITFindBy(accessibility = "insights_disabled_alert_yes")
    @AndroidFindBy(xpath = "//*[@resource-id='insights_disabled_alert_yes']")
    private MobileElement alert_popup_disable;
    
    @iOSXCUITFindBy(accessibility = "insights_disabled_alert_no")
    @AndroidFindBy(xpath = "//*[@resource-id='insights_disabled_alert_no']")
    private MobileElement alert_popup_cancel;
    
    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement myProfile;


    @iOSXCUITFindBy(xpath = "//*[@label='Featured Heading']")
    @AndroidFindBy(xpath = "//*[contains(@text,'Featured')]")
    private MobileElement featuredBanneer;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_Magazine')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_Magazine')])[1]")
    private MobileElement featuredBanneerTitles;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Newspapers see all, ')]")
    private MobileElement newspaperAndMagazineTier1SeeAllLink;

    @iOSXCUITFindBy(accessibility = "filter_cta")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
    private MobileElement refinerIcon1;

    @iOSXCUITFindBy(accessibility = "REFINE_ICON")
    @AndroidFindBy(xpath = "//*[@resource-id='REFINE_ICON']")
    private MobileElement refinerIcon2;

    @iOSXCUITFindBy(accessibility = "FEATURED_LIST_TOGGLE_outer")
    @AndroidFindBy(xpath = "//*[@resource-id='FEATURED_LIST_TOGGLE']")
    private MobileElement featuredListSection;

    @iOSXCUITFindBy(accessibility = "AVAILABLITY_LIST_TOGGLE_outer")
    @AndroidFindBy(xpath = "//*[@resource-id='AVAILABLITY_LIST_TOGGLE_outer']")
    private MobileElement availabilityDropDown;


    @iOSXCUITFindBy(accessibility = "RECENTLY_ADDED_LIST_TOGGLE_outer")
    @AndroidFindBy(xpath = "//*[@resource-id='RECENTLY_ADDED_LIST_TOGGLE_outer']")
    private MobileElement recentlyAddedDropDown;

    @iOSXCUITFindBy(accessibility = "RECENTLY_ADDED_LIST_0")
    @AndroidFindBy(xpath = "//*[@resource-id='RECENTLY_ADDED_LIST_0']")
    private MobileElement recentlyAddedOptionSelection;

    @iOSXCUITFindBy(accessibility = "AVAILABLITY_LIST1")
    @AndroidFindBy(xpath = "//*[@resource-id='AVAILABLITY_LIST1']")
    private MobileElement availabileNowOptionSelection;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"refiner_down_img\"])[2]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'refine_modal_header_text_country')]")
    private MobileElement countryRefinerOption;

    @iOSXCUITFindBy(accessibility = "refine_modal_header_text_country")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'refine_modal_header_text_country')]")
    private MobileElement countryRefinerUpImg;

    @iOSXCUITFindBy(accessibility = "Refiner_Language_toggle")
    @AndroidFindBy(xpath = "//*[@resource-id='Refiner_Language_toggle']")
    private MobileElement languageDropdown;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Refiner_Language_toggle\"]/parent::XCUIElementTypeOther//XCUIElementTypeOther[@name=\"radio_test_id_0\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='Refiner_Language_toggle']/following-sibling::android.view.ViewGroup//*[@resource-id='radio_test_id_0']")
    private MobileElement languageOption;

    @iOSXCUITFindBy(accessibility = "Refiner_Age Level_toggle")
    @AndroidFindBy(xpath = "//*[@resource-id='Refiner_Age Level_toggle']")
    private MobileElement ageLevelDropdown;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Refiner_Age Level_toggle\"]/parent::XCUIElementTypeOther//XCUIElementTypeOther[@name=\"radio_test_id_0\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='Refiner_Age Level_toggle']/following-sibling::android.view.ViewGroup//*[@resource-id='radio_test_id_0']")
    private MobileElement ageLevelOption;
    @iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_BUTTON_outer")
    @AndroidFindBy(xpath = "//*[@resource-id='txt_feature_reading_program_wrap']")
    private MobileElement featurePrg_panner;

    @iOSXCUITFindBy(accessibility = "VIEW_PROGRAM_DETAILS")
    @AndroidFindBy(xpath = "//*[@resource-id='VIEW_PROGRAM_DETAILS']")
    private MobileElement featurePrg_panner_details;

    @iOSXCUITFindBy(accessibility = "txt_program_books_button")
    @AndroidFindBy(xpath = "//*[@resource-id='txt_program_books_button']")
    private MobileElement featured_program_details;

    @iOSXCUITFindBy(accessibility = "txt_program_books_button")
    @AndroidFindBy(xpath = "//*[@resource-id='txt_program_books_button']")
    private MobileElement searchResultTitle;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[2]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[2]")
    private MobileElement eBookTitle;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Place Hold')]")
    @AndroidFindBy(xpath = "//*[@text='Place Hold']")
    private MobileElement placeHoldBtn;

    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
    private MobileElement confirmationPopupHeaderMessage;

    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
    private MobileElement confirmationPopupContent;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement back_btn;

    @iOSXCUITFindBy(accessibility = "ok_button")
    @AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
    private MobileElement ok_btn;

    @iOSXCUITFindBy(accessibility = "btnEmailNotifications")
    @AndroidFindBy(xpath = "//*[@resource-id='btnEmailNotifications']")
    private MobileElement emailNotification;

    @iOSXCUITFindBy(xpath = "//*[@label='Enable email notifications Information']")
    @AndroidFindBy(xpath = "//*[@content-desc='Enable email notifications Information, ']")
    private MobileElement emailNotificationToottip;
    
    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'dp_card_image_card_Newspaper')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'dp_card_image_card_Newspaper')])[1]")
    private MobileElement magazineTitle;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[contains(@content-desc,'entertainment publications from around the world')]")
    private MobileElement newPaperMagazineContentDesc;
    
    @iOSXCUITFindBy(accessibility = "countrytext")
	@AndroidFindBy(xpath = "//*[@resource-id='countrytext']")
	private MobileElement magazineCountry;
    
    @iOSXCUITFindBy(accessibility = "defaultcountrytext")
	@AndroidFindBy(xpath = "//*[@resource-id='defaultcountrytext']")
	private MobileElement magazineCountry1;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Newspapers & Magazines')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Newspapers & Magazines')]")
    private MobileElement newspaperandmagazine;
    
    @iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header']")
	private MobileElement newspaper_Magazine;
	
	@iOSXCUITFindBy(accessibility = "third_party_see_all_link")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link']")
	private MobileElement magazine_seeAll;

    @iOSXCUITFindBy(accessibility = "Done")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Done\"]")
    private MobileElement eAudioTitleMenuoption;

    @iOSXCUITFindBy(accessibility = "close player")
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Close\"]")
    private MobileElement eAudioClosePlayerBtn;

    @iOSXCUITFindBy(accessibility = "secondaryButtonTestId")
    @AndroidFindBy(xpath = "//*[@resource-id='secondaryButtonTestId']")
    private MobileElement secondaryDropDown;

    @iOSXCUITFindBy(xpath = "//*[@label='Return']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Return, \"]")
    private MobileElement returnBtn;

    @iOSXCUITFindBy(accessibility = "btnAlertOkay")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
    private MobileElement okayBtn;
    @iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
    private MobileElement tier2Title;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'International')]")
    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc=\"International\"]/android.view.ViewGroup/android.widget.ImageView")
    private MobileElement countryInternational;

    @iOSXCUITFindBy(accessibility = "third_party_refiner_pills")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_refiner_pills']")
    private MobileElement countryInternationalPill1;

    @iOSXCUITFindBy(accessibility = "ENGLISH ")
    @AndroidFindBy(xpath = "//*[contains(@text,'English')]")
    public MobileElement secondPill;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name,'SELECTED_REFINE_LIST_TEST_ID2')]/parent::XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'SELECTED_REFINE_LIST_TEST_ID2')]/parent::android.view.ViewGroup")
    public MobileElement secondPillInLibraryList;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name,'third_party_refiner_pills1')]/parent::XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'third_party_refiner_pills1')]/parent::android.view.ViewGroup")
    public MobileElement secondPillInThirdParty;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='third_party_refiner_pills_clearAll']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'Clear All Button')]")
    public MobileElement clearAllPill;

    @iOSXCUITFindBy(accessibility = "SELECTED_REFINE_LIST_TEST_ID")
    @AndroidFindBy(xpath = "//*[@resource-id='SELECTED_REFINE_LIST_TEST_ID']")
    private MobileElement countryInternationalPill2;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Algeria')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Algeria')]")
    private MobileElement countryAlgeria;

    @iOSXCUITFindBy(accessibility = "Refiner_search_cta")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Refiner_search_cta')]")
    private MobileElement refinerSearch1;

    @iOSXCUITFindBy(accessibility = "SEARCH_BUTTON_TEST_ID")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'SEARCH_BUTTON_TEST_ID')]")
    private MobileElement refinerSearch2;

    @iOSXCUITFindBy(accessibility = "third_party_refiner_pills_clearAll")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'third_party_refiner_pills_clearAll')]")
    private MobileElement clearAll1;

    @iOSXCUITFindBy(accessibility = "SELECTED_REFINE_LIST_TEST_ID_clearAll")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'SELECTED_REFINE_LIST_TEST_ID_clearAll')]")
    private MobileElement clearAll2;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'Search Heading,')])[1]")
    private MobileElement searchResultsPage;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Sort By Heading')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Sort By Heading')]")
    private MobileElement sortByDropdown;

    @iOSXCUITFindBy(xpath = "(//*[@name=\"adp_card_title_text_bottom\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='adp_card_title_text_bottom']")
    private MobileElement newPaperMagazineTitleTxtBottom;
	
	public MobileElement getNewspaper_Magazine() {
		return newspaper_Magazine;
		
	}

    public MobileElement getCopies_Availble() {
        return copies_Availble;
    }

    public MobileElement getpeople_Waiting() {
        return people_Waiting;
    }

    public void megazine_seeAll()
	{
		if(isElementPresent(magazine_seeAll))
		{
			ClickOnMobileElement(magazine_seeAll);
		}
	}

    
    public void selectNewsAndMagazineArticle()
    {
        for(int i=0;i<10;i++) {
            swipeDown();
            if(isElementPresent(firstMagazine)) {
                break;
            }
            else {
                swipeDown();
            }
        }
    	ClickOnMobileElement(newspaperAndMagazineSeeAllLink_Article);
    }
    
    public void selectNewsAndMagazineCategory()
    {

    	ClickOnMobileElement(newspaperandmagazine);
    }
    
    public void newspaperAndMagazineHeader() {
        for(int i=0;i<10;i++) {
            if(isElementPresent(newspaperAndMagazineTitle)) {
                swipeDown();
                break;
            }
            else {
                    swipeDown();
                }
            }
        }
        
     public void navigate_to_Insights_Badges() {
          for(int i=0;i<5;i++) {
              if(isElementPresent(insights_Badges)) {
                    swipeDown();
                    break;
               }
               else {
                        swipeDown();
                    }
                }
            }
        
    public void clickNewspaperAndMagazineSeeAllLink() {
        for(int i=0;i<10;i++) {
            if(isElementPresent(newspaperAndMagazineSeeAllLink)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newspaperAndMagazineSeeAllLink);
    }

    public MobileElement verifyFeaturedBanner() {
        return featuredBanneer;
    }

    public MobileElement verifyFeaturedBannerTitles() {
        return featuredBanneerTitles;
    }

    public void clickNewspaperAndMagazineTier1SeeAllLink() {
        for(int i=0;i<10;i++) {
            if(isElementPresent(newspaperAndMagazineTier1SeeAllLink)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newspaperAndMagazineTier1SeeAllLink);
    }

    public boolean verifyRefinerIcon() {
        boolean refineOption = false;
        if(isElementPresent(refinerIcon1)) {
            return refineOption = true;
        }
        else if(isElementPresent(refinerIcon2)) {
            return refineOption= true;
        }
        return refineOption;
    }

    public void clickRefinerIcon() {
        if(isElementPresent(refinerIcon1)) {
            ClickOnMobileElement(refinerIcon1);
        }
        else {
            ClickOnMobileElement(refinerIcon2);
        }
    }

    public void closeFeaturedListSection() {
        ClickOnMobileElement(featuredListSection);
    }

    public void selectAvailabilityOption() {
        ClickOnMobileElement(availabilityDropDown);
        ClickOnMobileElement(availabileNowOptionSelection);
        ClickOnMobileElement(availabilityDropDown);
    }

    public void selectRecentlyAddedOption() {
        ClickOnMobileElement(recentlyAddedDropDown);
        ClickOnMobileElement(recentlyAddedOptionSelection);
        ClickOnMobileElement(recentlyAddedDropDown);
    }

    public void clickLanguageOption() {
        ClickOnMobileElement(languageDropdown);
        ClickOnMobileElement(languageOption);
    }

    public void clickAgeLevelOption() {
        ClickOnMobileElement(ageLevelDropdown);
        ClickOnMobileElement(ageLevelOption);
    }

    public void clickCountryRefiner() {
        if(isElementPresent(countryRefinerOption)){
            ClickOnMobileElement(countryRefinerOption);
        }
        else {
            ClickOnMobileElement(countryRefinerUpImg);
        }
    }

    public void clickCountryInternational() {
        ClickOnMobileElement(countryInternational);
    }
    public void clickCountry() {
        ClickOnMobileElement(countryInternational);
    }

    public MobileElement verifyCountryRefinerOption() {
        return countryRefinerOption;
    }

    public MobileElement getFeaturePrg_panner() {
        return featurePrg_panner;
    }

    public MobileElement verifyFeaturedProgramDetailsBtn()
    {
        return featurePrg_panner_details;
    }
        
    public void clickMenu() {
        ClickOnMobileElement(clickMenu);
    }

    public void clickProfileSettings() {
        ClickOnMobileElement(profileSettings);
    }

    public MobileElement display_Insights_Badges() {
        return insights_Badges;
    }

    public MobileElement getAlert_popup_title() {
        return alert_popup_title;
    }

    public MobileElement getAlert_popup_description() {
        return alert_popup_description;
    }

    public MobileElement getAlert_popup_disable() {
        return alert_popup_disable;
    }

    public MobileElement getAlert_popup_cancel() {
        return alert_popup_cancel;
    }

    public MobileElement display_MyProfile() {
        return myProfile;
    }

    public MobileElement display_InsightsBadges() {
        return insights_Badges;
    }

    public void click_Insights_Badges() {
        ClickOnMobileElement(insights_Badges);
    }

    public void clickCancel() {
        ClickOnMobileElement(clickCancel);
    }

    public void click_Disable() {
        ClickOnMobileElement(click_Disable);
    }

    public MobileElement verifySeeAllLink()
    {
        return featured_program_details;
    }

    public void clickEBookTitle() {
        ClickOnMobileElement(eBookTitle);
    }

    public void clickPlaceHoldBtn() {
        waitFor(2000);
        if(isElementPresent(placeHoldBtn)) {
            ClickOnMobileElement(placeHoldBtn);
        }
    }

    public MobileElement verifyConfirmationPopupHeaderMessage() {
        return confirmationPopupHeaderMessage;
    }

    public MobileElement verifyConfirmationPopupContent() {
        return confirmationPopupContent;

    }

    public void clickNewsPaperViewAll() {
        for (int i = 0; i < 5; i++) {
            if (isElementPresent(newsPaperViewAll)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newsPaperViewAll);
    }

    public void clickmagazinesViewAll(){
        for (int i = 0; i < 5; i++) {
            if (isElementPresent(magazinesViewAll)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(magazinesViewAll);
    }

    public void clickBackBtn() {
        ClickOnMobileElement(back_btn);
    }

    public void verifyEmailNotificationPopup() {
        for(int i=0;i<5;i++) {
            if(isElementPresent(emailNotification)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(emailNotificationToottip);
    }

    public void clickOkBtn() {
        ClickOnMobileElement(ok_btn);
    }
    
    public void clickMagazineTitle() {
        for(int i=0;i<5;i++) {
            if(isElementPresent(firstMagazine)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(magazineTitle);
    }
    
    public MobileElement verifyCountry() {
		return magazineCountry;
	}
    
    public void verifyMagazineCountry() {
        if(isElementPresent(magazineCountry)) {
        	Assert.assertEquals(isElementPresent(magazineCountry), true);
        }
        else {
        	Assert.assertEquals(isElementPresent(magazineCountry1), true);
        }
    }

    public void clickNewspaperAndMagazineInMyLibraryScreen() {
        ClickOnMobileElement(newspaperAndMagazineInMyLibrary);
    }


    public void clickNewspaperAndMagazineAdvanceOption() {
        ClickOnMobileElement(newspaperAndMagazineAdvanceOption);
    }

    public void verifyPublicationSearchResult() {
        for(int i=0;i<5;i++) {
            if(isElementPresent(publicationSearchResult)) {
                break;
            }
            else {
                swipeDown();
            }
        }
    }

    public Boolean verifyIOSRelevanceOption() {
        Boolean defaultSelection = false;
            if (relevanceOption.getAttribute("label").contains("Relevance Radio Button.Selected")) {
                defaultSelection = true;
            }
        return defaultSelection;
    }

    public Boolean verifyAndroidRelevanceOption() {
        Boolean defaultSelection = false;
        if (relevanceOption.getAttribute("content-desc").contains("Relevance Radio Button.Selected")) {
            defaultSelection = true;
        }
        return defaultSelection;
    }

    public Boolean verifyIOSPopularityOption() {
        Boolean defaultSelection = false;
        if (popularityOption.getAttribute("label").contains("Popularity Radio Button.Selected")) {
            defaultSelection = true;
        }
        return defaultSelection;
    }
    public Boolean verifyAndroidPopularityOption() {
        Boolean defaultSelection = false;
        if (popularityOption.getAttribute("content-desc").contains("Popularity Radio Button.Selected")) {
            defaultSelection = true;
        }
        return defaultSelection;
    }
    public void returningTheeAudio() {
        ClickOnMobileElement(eAudioTitleMenuoption);
        ClickOnMobileElement(eAudioClosePlayerBtn);
        ClickOnMobileElement(secondaryDropDown);
        ClickOnMobileElement(returnBtn);
        ClickOnMobileElement(okayBtn);
    }
    public MobileElement tier2Title() {
        return tier2Title;

    }
    public boolean refinerSearch() {
        boolean refinerSearch =false;
        if(isElementPresent(refinerSearch1)) {
            return  refinerSearch = true;
        }
        else if(isElementPresent(refinerSearch2)) {
            return  refinerSearch = true;
        }
        return refinerSearch;
    }
    public void clickrefinerSearch() {
        if(isElementPresent(refinerSearch1)) {
            ClickOnMobileElement(refinerSearch1);
        }
        else {
            ClickOnMobileElement(refinerSearch2);
        }
    }

    public boolean verifyInternationalPill() {
        boolean refinerPills = false;
        if(isElementPresent(countryInternationalPill1)) {
            return refinerPills = true;
        }else if(isElementPresent(countryInternationalPill2)) {
            return refinerPills = true;
        }
        return refinerPills;
    }

    public MobileElement clearAllrefiner1() {
        return clearAll1;
    }

    public MobileElement clearAllrefiner2() {
        if (!isElementPresent(clearAll2)) {
            swipeleft(clearAll2);
        }
        return clearAll2;
    }

    public void clickClearAllPill() {
        if(isElementPresent(clearAll1)) {
            ClickOnMobileElement(clearAll1) ;
        } else if (isElementPresent(clearAll2)){
            ClickOnMobileElement(clearAll2) ;
        }
    }

    public void clickrefinerAlgeria() {
        ClickOnMobileElement(countryAlgeria);
    }
    public MobileElement verifySearchResultsPage() {
        return searchResultsPage;
    }

    public void clickNewspaperSeeAllLink() {
        for(int i=0;i<10;i++) {
            if(isElementPresent(newspaperSeeAllLink)) {
                swipeDown();
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newspaperSeeAllLink);
    }
    public boolean verifyeBookTitleScreen() {
        boolean eBookTitle = false;
        for(int i=0;i<15;i++) {
            if(isElementPresent(eBookTitleScreen1) || isElementPresent(eBookTitleScreen2)) {
                eBookTitle = true;
                break;
            }
            else {
                waitFor(1000);
            }
        }
        return eBookTitle;
    }
    public void returningTheeBook() {
        if(isElementPresent(eBookTitleScreen1)) {
            ClickOnMobileElement(eBookTitleScreen1);
        } else {
            ClickOnMobileElement(eBookTitleScreen2);
        }
        ClickOnMobileElement(eBookTitleBackoption);
        ClickOnMobileElement(secondaryDropDown);
        ClickOnMobileElement(returnBtn);
        ClickOnMobileElement(okayBtn);
    }

    public void clickSortBYDrpdwn() {
        ClickOnMobileElement(sortByDropdown);
    }
}
