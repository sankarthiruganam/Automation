package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Preference extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public Preference(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc='Preferences Menu, ']")
	private MobileElement preference_btn_preferencemenu;

	@iOSXCUITFindBy(accessibility = "Checkbox_Auto_Play")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Auto_Play']")
	private MobileElement preference_checkbox_autoplaytitle;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Logout, button\"]")
	@AndroidFindBy(xpath = "//*[@text='Logout']")
	private MobileElement home_btn_Logout;

	@iOSXCUITFindBy(accessibility = "Checkbox_Auto_Delete")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Auto_Delete']")
	private MobileElement preference_checkbox_deleteExpired;

	@iOSXCUITFindBy(accessibility = "Checkbox_Use_Cellular_Data")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Use_Cellular_Data']")
	private MobileElement preference_checkbox_cellularData;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement logo_btn_menu1;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(id = "//android.widget.FrameLayout[@content-desc=\"Menu\"]")
	private MobileElement logo_btn_menu;

	@iOSXCUITFindBy(accessibility = "Button_Save")
	@AndroidFindBy(xpath = "//*[@resource-id='Button_Save']")
	private MobileElement preference_btn_save;

	@iOSXCUITFindBy(accessibility = "Checkbox_Auto_Play")
	@AndroidFindBy(xpath = "//*[contains(@text,'Auto Play')]")
	private MobileElement preference_txt_autoplaytitle;

	@iOSXCUITFindBy(accessibility = "Title_Auto_Delete")
	@AndroidFindBy(xpath = "//*[@resource-id='Title_Auto_Delete']")
	private MobileElement preference_txt_deleteExpried;

	@iOSXCUITFindBy(accessibility = "Title_Use_Cellular_Data")
	@AndroidFindBy(xpath = "//*[contains(@text,'Use cellular data when downloading files?')]")
	private MobileElement preference_txt_cellularData;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "preferences_SOption")
	private List<MobileElement> preference_btn_preferenceoptions;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/icon")
	private List<MobileElement> preference_menu_footeroptions;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "list_item_textview")
	private List<MobileElement> preference_btn_adultpreferenceoptions;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	private MobileElement preference_toast_successfulToastmsg;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "Back CTA")
	private MobileElement preference_back_backcta;

	@iOSXCUITFindBy(accessibility = "alert_close")
	@AndroidFindBy(xpath = "//*[@resource-id='alert_close']")
	private MobileElement preference_toastmsg_closepopup;

	@iOSXCUITFindBy(accessibility = "Sign_out_Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Sign_out_Menu']")
	private MobileElement preference_btn_signout;

	@iOSXCUITFindBy(accessibility = "SIGNOUT_YES")
	@AndroidFindBy(xpath = "//*[@resource-id='SIGNOUT_YES']")
	private MobileElement preference_btn_signout_confirm;
	
	@iOSXCUITFindBy(accessibility = "Button_Confirm")
	@AndroidFindBy(xpath = "//*[@resource-id='Button_Confirm']")
	private MobileElement preference_confirmpopup;

	public MobileElement getPreference_checkbox_deleteExpired() {
		return preference_checkbox_deleteExpired;
	}

	public MobileElement getPreference_checkbox_cellularData() {
		return preference_checkbox_cellularData;
	}

	public MobileElement getPreference_txt_cellularData() {
		return preference_txt_cellularData;
	}

	public MobileElement getPreference_txt_deleteExpried() {
		return preference_txt_deleteExpried;
	}

	public MobileElement getPreference_btn_preferencemenu() {
		return preference_btn_preferencemenu;
	}

	public MobileElement getPreference_checkbox_autoplaytitle() {
		return preference_checkbox_autoplaytitle;
	}

	public MobileElement getLogo_btn_menu1() {
		return logo_btn_menu1;
	}

	public MobileElement getLogo_btn_menu() {
		return logo_btn_menu;
	}

	public List<MobileElement> getPreference_menu_footeroptions() {
		return preference_menu_footeroptions;
	}

	public List<MobileElement> getPreference_btn_adultpreferenceoptions() {
		return preference_btn_adultpreferenceoptions;
	}

	public MobileElement getPreference_toast_successfulToastmsg() {
		return preference_toast_successfulToastmsg;
	}

	public MobileElement getPreference_back_backcta() {
		return preference_back_backcta;
	}

	public MobileElement getPreference_toastmsg_closepopup() {
		return preference_toastmsg_closepopup;
	}

	public MobileElement getPreference_btn_signout() {
		return preference_btn_signout;
	}

	public List<MobileElement> getPreference_btn_preferenceoptions() {
		return preference_btn_preferenceoptions;
	}

	public MobileElement getPreference_txt_autoplaytitle() {
		return preference_txt_autoplaytitle;
	}

	public MobileElement getPreference_btn_save() {
		return preference_btn_save;
	}

	/************************* Action Methods ********************************/

	public void clickFooterMenu() {
		if (isElementPresent(logo_btn_menu)) {
			ClickOnMobileElement(logo_btn_menu);
		} else if (isElementPresent(logo_btn_menu1)) {
			ClickOnMobileElement(logo_btn_menu1);
		}
	}

	public void adultprofile_clickFooterMenu() {
		if (isElementPresent(preference_menu_footeroptions.get(0))) {
			ClickOnMobileElement(preference_menu_footeroptions.get(0));
		} else if (isElementPresent(logo_btn_menu1)) {
			ClickOnMobileElement(logo_btn_menu1);
		}
	}

	public void click_preferenceMenu() {
		if (preference_btn_preferencemenu.isDisplayed()) {
			ClickOnMobileElement(preference_btn_preferencemenu);
		} else {
			ClickOnMobileElement(preference_btn_adultpreferenceoptions.get(2));
		}
	}

	public void enable_autoplayAudiobook() {
		if (preference_checkbox_autoplaytitle.isSelected()) {
			logger.info("user is able to see enable option to auto play title");
		} else {
			ClickOnMobileElement(preference_checkbox_autoplaytitle);
		}
	}

	public void enable_cellulardata() {
		if (isElementPresent(preference_checkbox_cellularData)) {
			if (preference_checkbox_cellularData.isSelected()) {
				logger.info("user is able to see enable option to cellular data");
			} else {
				if (isElementPresent(preference_checkbox_cellularData)) {
					ClickOnMobileElement(preference_checkbox_cellularData);
				}
			}
		}
	}

	public void disable_cellulardata() {
		if (isElementPresent(preference_checkbox_cellularData)) {
			if (!preference_checkbox_cellularData.isSelected()) {
				ClickOnMobileElement(preference_checkbox_cellularData);
			} else {
				logger.info("user is able to see disable option to auto play title");
			}
		}
	}

	public void disable_autoplayAudiobook() {
		if (!preference_checkbox_autoplaytitle.isSelected()) {
			ClickOnMobileElement(preference_checkbox_autoplaytitle);
		} else {
			logger.info("user is able to see disable option to auto play title");
		}
	}

	public void enable_deleteExpireditems() {
		if (preference_checkbox_deleteExpired.isSelected()) {
			logger.info("user is able to see enable option to delete expired options");
		} else {
			ClickOnMobileElement(preference_checkbox_deleteExpired);
		}
	}

	public void preference_savebtn() {
		if (isElementPresent(preference_btn_save)) {
			ClickOnMobileElement(preference_btn_save);
//		ClickOnMobileElement(preference_toastmsg_closepopup);
		}
	}

	public void disable_deleteExpireditems() {
		if (!preference_checkbox_deleteExpired.isSelected()) {
			ClickOnMobileElement(preference_checkbox_deleteExpired);
		} else {
			logger.info("user is able to see disable option to delete expired items");
		}
	}

	public boolean save_successfultoastmsg() {
		boolean b = true;
		if (preference_toast_successfulToastmsg.isDisplayed()) {
			ClickOnMobileElement(preference_toastmsg_closepopup);
			logger.info("Your settings have been saved successfully toast msg displayed");
		} else {
			logger.info("Your settings have been saved successfully toast msg not displayed");
		}
		return b;
	}

	public void click_logout() {
		try {
			ClickOnMobileElement(preference_back_backcta);
			ClickOnMobileElement(preference_btn_signout);
		} catch (Exception e) {

		}
	}

	public void click_SignOut() {

		if (isElementPresent(preference_btn_signout)) {
			ClickOnMobileElement(preference_btn_signout);
			ClickOnMobileElement(preference_btn_signout_confirm);
		} else if (isElementPresent(home_btn_Logout)) {
			ClickOnMobileElement(home_btn_Logout);
		}
	}
	
	public void confirmpopup() {
		if (isElementPresent(preference_confirmpopup)) {
			ClickOnMobileElement(preference_confirmpopup);
		}
	}
}