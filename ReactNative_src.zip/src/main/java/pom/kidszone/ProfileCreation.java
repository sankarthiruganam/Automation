package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class ProfileCreation extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(ProfileCreation.class);
    ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
    MenuList menu = new MenuList(DriverManager.getDriver());

    public ProfileCreation(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public String displayname;

    /******************* Locators ******************************/

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    public MobileElement profile_title;

    @iOSXCUITFindBy(accessibility = "listItemUserProfileList0")
    @AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList0']")
    private MobileElement profile_txt_profile1;

    @iOSXCUITFindBy(accessibility = "listItemUserProfileList1")
    @AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList1']")
    private MobileElement profile_txt_profile2;

    @iOSXCUITFindBy(accessibility = "listItemUserProfileList2")
    @AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList2']")
    private MobileElement profile_txt_profile3;

    @iOSXCUITFindBy(accessibility = "listItemUserProfileList3")
    @AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList3']")
    private MobileElement profile_txt_profile4;

    @iOSXCUITFindBy(accessibility = "txtTitle")
//	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_title']")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement profile_txt_title;

    @iOSXCUITFindBy(accessibility = "user_profile_right_menu")
    @AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
    public MobileElement profile_txt_editProfile;

    @iOSXCUITFindBy(accessibility = "listItemUserProfileList4")
    @AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList4']")
    public MobileElement profile_txt_profile5;

    @iOSXCUITFindBy(accessibility = "user_profile_add_avatar")
    @AndroidFindBy(xpath = "//*[@resource-id='user_profile_add_avatar']")
    public MobileElement profile_txt_add;

    @iOSXCUITFindBy(accessibility = "btnSelectAvatar")
    @AndroidFindBy(xpath = "//*[@resource-id='btnSelectAvatar']")
    public MobileElement profile_btn_avatar;

    @iOSXCUITFindBy(accessibility = "btnUploadPhoto")
    @AndroidFindBy(xpath = "//*[@resource-id='btnUploadPhoto']")
    private MobileElement profile_btn_uploadphoto;

    @iOSXCUITFindBy(accessibility = "loc_edit_profile_name")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_name']")
    public MobileElement profile_txt_displayname;

    @iOSXCUITFindBy(accessibility = "btnDone")
    @AndroidFindBy(xpath = "//*[@resource-id='btnDone']")
    public MobileElement profile_btn_done;

    @iOSXCUITFindBy(accessibility = "txtProfileTypesTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtProfileTypesTitle']")
    public MobileElement profile_txt_addtitle;

    @iOSXCUITFindBy(accessibility = "btnYes")
    @AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
    public MobileElement profile_txt_deleteconfirm;

    @iOSXCUITFindBy(accessibility = "btnAddProfileYes")
    @AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
    public MobileElement profile_btn_addconfirm;

    @iOSXCUITFindBy(accessibility = "btnAddProfileNo")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"No, \"]")
    public MobileElement profile_btn_addconfirmNo;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"avatar_view\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='avatar_view'])[1]")
    public MobileElement profile_img_avatar;

    @iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'listItemUserProfileList')]")
    public List<MobileElement> manageProf_icon_edit;

    @iOSXCUITFindBy(accessibility = "edit_profile_avatar")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_avatar']")
    private MobileElement profile_lbl_editprofileavatar;

    @iOSXCUITFindBy(accessibility = "wrap_edit_profile_name")
    @AndroidFindBy(xpath = "//*[@resource-id='wrap_edit_profile_name']")
    private MobileElement profile_lbl_editprofiledisplayname;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'edit_profile_checkout_limit')]")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_checkout_limit']")
    private MobileElement profile_lbl_editcheckoutlimit;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'edit_profile_hold_limit')]")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_hold_limit']")
    private MobileElement profile_lbl_editholdlimit;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'edit_profile_recommendation_limit')]")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_recommendation_limit']")
    private MobileElement profile_lbl_editrecommendationlimit;

    @iOSXCUITFindBy(accessibility = "viewCheckoutHistory")
    @AndroidFindBy(xpath = "//*[@resource-id='viewCheckoutHistory']")
    private MobileElement profile_lbl_displycheckouthistory;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"edit_profile_dropdown\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_dropdown']")
    private MobileElement profile_lbl_editprofiledropdown;

    @iOSXCUITFindBy(accessibility = "edit_profile_save")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
    public MobileElement profile_btn_editprofilesave;

    @iOSXCUITFindBy(accessibility = "insights_disabled_alert_yes")
    @AndroidFindBy(xpath = "//*[@resource-id='insights_disabled_alert_yes']")
    public MobileElement profile_btn_disable;

    @iOSXCUITFindBy(accessibility = "edit_profile_delete_profilen")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_delete_profilen']")
    private MobileElement profile_txt_deleteprofile;

    @iOSXCUITFindBy(accessibility = "Done_button")
    @AndroidFindBy(id = "Done_button")
    private MobileElement profile_btn_submit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"ALERT_TITLE\"]")
    @AndroidFindBy(xpath = "//*[@text='Thank you. The profile is saved']")
    private MobileElement profile_txt_successmsg;

    @iOSXCUITFindBy(accessibility = "btnAddProfileYes")
    @AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
    public MobileElement profile_txt_saveconfirmyes;

    @iOSXCUITFindBy(accessibility = "btnYes")
    @AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
    public MobileElement profile_btn_saveconfirmyes;

    @iOSXCUITFindBy(accessibility = "profile_saved")
    @AndroidFindBy(xpath = "//*[@resource-id='profile_saved']")
    public MobileElement profile_btn_editsaveconfirmyes;

    @iOSXCUITFindBy(accessibility = "btnNo")
    @AndroidFindBy(xpath = "//*[@resource-id='btnNo']")
    public MobileElement profile_txt_saveconfirmno;

    @iOSXCUITFindBy(accessibility = "NUM_1_BTN")
    @AndroidFindBy(xpath = "//*[@resource-id='NUM_1_BTN']")
    public MobileElement profile_txt_profilein;

    @iOSXCUITFindBy(accessibility = "txtAddProfileTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtAddProfileTitle']")
    private MobileElement profile_txt_addprofiletitle;

    @iOSXCUITFindBy(accessibility = "kid_drop_down_item")
    @AndroidFindBy(xpath = "(//*[@resource-id='drop_down_item']/android.widget.TextView)[1]")
    private MobileElement profile_drp_kidprofile;

    @iOSXCUITFindBy(accessibility = "teen_drop_down_item")
    @AndroidFindBy(xpath = "(//*[@resource-id='drop_down_item']/android.widget.TextView)[2]")
    private MobileElement profile_drp_teenprofile;

   @iOSXCUITFindBy(accessibility = "btnBackIcon")
    // @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"btnBackIcon\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement profile_btn_backbtn;

    @iOSXCUITFindBy(accessibility = "edit_profile_security_question")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_security_question']")
    private MobileElement profile_btn_profilesequestion;

    @iOSXCUITFindBy(accessibility = "View_My_Interests")
    @AndroidFindBy(xpath = "//*[@resource-id='View_My_Interests']")
    private MobileElement profile_btn_viewinterests;

    @iOSXCUITFindBy(accessibility = "VIEW MY INTEREST")
    @AndroidFindBy(xpath = "//*[@resource-id='View_My_Interests']/android.widget.TextView")
    private MobileElement profile_btn_viewinterests1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"VIEW MY INTERESTS\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='View_My_Interests']/android.widget.TextView")
    private MobileElement profile_btn_viewinterests2;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkbox_one\"]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='checkbox_one']")
    private MobileElement profile_chk_checkouttitles;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkbox_two\"]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='checkbox_two']")
    private MobileElement profile_chk_checkouthistory;

    @iOSXCUITFindBy(accessibility = "checkbox_three")
    @AndroidFindBy(xpath = "//*[@resource-id='checkbox_three']")
    private MobileElement profile_chk_insightandBadges;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkbox_three\"]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Goals & Insights,Heading, \"]")
    private MobileElement profile_chk_insightandBadges2;

    @iOSXCUITFindBy(accessibility = "checkbox_four")
    @AndroidFindBy(xpath = "//*[@text='Set My Shelf page as my default landing page']")
    private MobileElement profile_chk_landingPage;

    @iOSXCUITFindBy(accessibility = "profile_saved")
    @AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
    private MobileElement profile_btn_updatedconfirm;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement intrestPg_btn_back;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement editprofile_btn_close;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"checkbox_three\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='btnInsightAndBadgesDisplay']/android.widget.CheckBox")
    private MobileElement Insight;

//    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @iOSXCUITFindBy(xpath = "//*[@name='btnBackIcon']")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement profileIcon;

    public MobileElement getProfile_title() {
        return profile_title;
    }

    public MobileElement getProfile_btn_backbtn() {
        return profile_btn_backbtn;
    }

    public MobileElement geteditprofile_btn_close() {
        return editprofile_btn_close;
    }

    public MobileElement getProfile_btn_viewinterests() {
        return profile_btn_viewinterests;
    }

    public MobileElement getProfile_btn_profilesequestion() {
        return profile_btn_profilesequestion;
    }

    public MobileElement getProfile_chk_insightandBadges() {
        return profile_chk_insightandBadges;
    }

    public MobileElement getProfile_btn_saveconfirmyes() {
        return profile_btn_saveconfirmyes;
    }

    public MobileElement getProfile_txt_addprofiletitle() {
        return profile_txt_addprofiletitle;
    }

    public MobileElement getProfile_txt_successmsg() {
        return profile_txt_successmsg;
    }

    public MobileElement getProfile_txt_deleteprofile() {
        return profile_txt_deleteprofile;
    }

    public MobileElement getProfile_lbl_displycheckouthistory() {
        return profile_lbl_displycheckouthistory;
    }

    public MobileElement getProfile_lbl_editcheckoutlimit() {
        return profile_lbl_editcheckoutlimit;
    }

    public MobileElement getProfile_lbl_editholdlimit() {
        return profile_lbl_editholdlimit;
    }

    public MobileElement getProfile_lbl_editrecommendationlimit() {
        return profile_lbl_editrecommendationlimit;
    }

    public MobileElement getProfile_lbl_editprofiledisplayname() {
        return profile_lbl_editprofiledisplayname;
    }

    public MobileElement getProfile_lbl_editprofileavatar() {
        return profile_lbl_editprofileavatar;
    }

    public MobileElement getProfile_txt_title() {
        return profile_txt_title;
    }

    public MobileElement getProfile_txt_addtitle() {
        return profile_txt_addtitle;
    }

    public MobileElement getProfile_btn_uploadphoto() {
        return profile_btn_uploadphoto;
    }

    public List<MobileElement> getProfile_list_pencilicon() {
        return manageProf_icon_edit;
    }

    /******************** Action methods ***********************/

    public void setDisplayName(String displayname) {
        ClickOnMobileElement(profile_txt_displayname);
        SendKeysOnMobileElement(profile_txt_displayname, displayname + RandomStringGenerate());
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            hideMobileKeyboard();
        } else {
            DriverManager.getDriver().navigate().back();
        }
    }

    public void selectAvatar() {
        if (isElementPresent(profile_btn_avatar)) {
            ClickOnMobileElement(profile_btn_avatar);
        }
        if (isElementPresent(profile_img_avatar)) {
            ClickOnMobileElement(profile_img_avatar);
        }
    }

    public void addProfileCta() {
        checkprofileCount();
        swipeDown();
        for (int i = 0; i < 4; i++) {
            if (isElementPresent(profile_txt_add)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(profile_txt_add);
    }

    public void checkprofileCount() {
        swipeDown();
        if (isElementPresent(profile_txt_profile5)) {
            logger.info("Already 5 profile avilable");
            WaitForMobileElement(profile_txt_editProfile);
            ClickOnMobileElement(profile_txt_editProfile);
            if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")) {
                ClickOnMobileElement(profile_txt_profile2);
            } else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")) {
                ClickOnMobileElement(profile_txt_profile2);
            } else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("Adult")) {
                ClickOnMobileElement(profile_txt_profile3);
            }
            if (System.getProperty("platform").equalsIgnoreCase("Android")) {
                MobileElement upcomingPrg = (MobileElement) DriverManager.getDriver()
                        .findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"

                                + ".scrollIntoView(new UiSelector().text(\"View My Interests\"))"));
            }
            for (int i = 0; i < 4; i++) {
                if (isElementPresent(profile_txt_deleteprofile)) {
                    break;
                } else {
                    swipeDown();
                }
            }
            ClickOnMobileElement(profile_txt_deleteprofile);
            ClickOnMobileElement(profile_txt_deleteconfirm);
        } else {
            logger.info("create more profile up to 5");
        }
    }

    public void clickDonebutton() {
        ClickOnMobileElement(profile_btn_done);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            ClickOnMobileElement(profile_btn_addconfirmNo);
        } else {

        }
    }

    public void clickBackbutton() {
//    	 WaitForMobileElement(profile_btn_backbtn);
         ClickOnMobileElement(profile_btn_backbtn);
//        if (isElementPresent(profile_btn_backbtn)) {
//        	System.out.println("inside back button if condition");
//            ClickOnMobileElement(profile_btn_backbtn);
//        }
    }

    public void clickEditprofile() {
        WaitForMobileElement(profile_txt_editProfile);
        ClickOnMobileElement(profile_txt_editProfile);
    }

    public void clickpenicon() {
        if (isElementPresent(profile_txt_profile1) && !profile_txt_profile1.getText().contains("Adult")) {
            ClickOnMobileElement(profile_txt_profile2);
        } else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")) {
            ClickOnMobileElement(profile_txt_profile2);
        } else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("Adult")) {
            ClickOnMobileElement(profile_txt_profile3);
        }
    }

    public void clickpeniconTeen() {
        ClickOnMobileElement(profile_txt_profile4);
    }

    public String editdisplayname(String updatedisplayname) {
        ClickOnMobileElement(profile_lbl_editprofiledisplayname);
        profile_lbl_editprofiledisplayname.clear();
        SendKeysOnMobileElement(profile_lbl_editprofiledisplayname, updatedisplayname);
        displayname = profile_lbl_editprofiledisplayname.getText();
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            hideMobileKeyboard();
        } else {
            DriverManager.getDriver().navigate().back();
        }
        swipeDown();
        swipeDown();
        swipeScreen("LEFT");
        ClickOnMobileElement(profile_btn_editprofilesave);
        if (isElementPresent(profile_btn_updatedconfirm)) {
            ClickOnMobileElement(profile_btn_updatedconfirm);
        }
        return displayname;
    }

    public void enter_setPin(String Pin) {
        if (isElementPresent(profile_txt_profilein)) {
            for (int i = 0; i < 4; i++) {
                ClickOnMobileElement(profile_txt_profilein);
            }
        } else {
            logger.info("Pin not available");
        }
    }

    public void clickSubmit() {
        ClickOnMobileElement(profile_btn_submit);
    }

    public void clickDeleteprofile() {
        WaitForMobileElement(profile_txt_deleteprofile);
        ClickOnMobileElement(profile_txt_deleteprofile);

    }

    public void deleteprofile(String confirm) {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (confirm.equalsIgnoreCase("yes")) {
                ClickOnMobileElement(profile_btn_saveconfirmyes);
            } else if (confirm.equalsIgnoreCase("No")) {
                ClickOnMobileElement(profile_txt_saveconfirmno);
            }
        } else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (confirm.equalsIgnoreCase("yes")) {
                ClickOnMobileElement(profile_btn_addconfirm);
            } else if (confirm.equalsIgnoreCase("Cancel")) {
                ClickOnMobileElement(profile_btn_addconfirmNo);
            }
        }
    }

    public void chooseProfile(String profileType) {
        if (profileType.contains("kid")) {
            if (isElementPresent(profile_txt_profile1) && !profile_txt_profile1.getText().contains("Adult")
                    && !profile_txt_profile1.getText().contains("Teen")) {
                ClickOnMobileElement(profile_txt_profile1);
            } else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")
                    && !profile_txt_profile2.getText().contains("Teen")) {
                ClickOnMobileElement(profile_txt_profile2);
            } else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("Adult")
                    && !profile_txt_profile3.getText().contains("Teen")) {
                ClickOnMobileElement(profile_txt_profile3);
            } else if (isElementPresent(profile_txt_profile4) && !profile_txt_profile4.getText().contains("Adult")
                    && !profile_txt_profile4.getText().contains("Teen")) {
                ClickOnMobileElement(profile_txt_profile4);
            } else if (isElementPresent(profile_txt_profile5) && !profile_txt_profile5.getText().contains("Adult")
                    && !profile_txt_profile5.getText().contains("Teen")) {
                ClickOnMobileElement(profile_txt_profile5);
            }
        } else if (profileType.contains("teen")) {
            if (isElementPresent(profile_txt_profile1) && !profile_txt_profile1.getText().contains("Adult")
                    && !profile_txt_profile1.getText().contains("Kid")) {
                ClickOnMobileElement(profile_txt_profile1);
            } else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")
                    && !profile_txt_profile2.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile2);
            } else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("Adult")
                    && !profile_txt_profile3.getText().contains("Kid")) {
                ClickOnMobileElement(profile_txt_profile3);
            } else if (isElementPresent(profile_txt_profile4) && !profile_txt_profile4.getText().contains("Adult")
                    && !profile_txt_profile4.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile4);
            } else if (isElementPresent(profile_txt_profile5) && !profile_txt_profile5.getText().contains("Adult")
                    && !profile_txt_profile5.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile5);
            }
        } else if (profileType.contains("adult")) {
            if (isElementPresent(profile_txt_profile1) && !profile_txt_profile1.getText().contains("teen")
                    && !profile_txt_profile1.getText().contains("Kid")) {
                ClickOnMobileElement(profile_txt_profile1);
            } else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("teen")
                    && !profile_txt_profile2.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile2);
            } else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("teen")
                    && !profile_txt_profile3.getText().contains("Kid")) {
                ClickOnMobileElement(profile_txt_profile3);
            } else if (isElementPresent(profile_txt_profile4) && !profile_txt_profile4.getText().contains("teen")
                    && !profile_txt_profile4.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile4);
            } else if (isElementPresent(profile_txt_profile5) && !profile_txt_profile5.getText().contains("teen")
                    && !profile_txt_profile5.getText().contains("kid")) {
                ClickOnMobileElement(profile_txt_profile5);
            }
        }
    }

    public void createProfileMore(String confirm) {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (confirm.equalsIgnoreCase("yes")) {
                ClickOnMobileElement(profile_txt_saveconfirmyes);
            } else if (confirm.equalsIgnoreCase("no")) {
                ClickOnMobileElement(profile_txt_saveconfirmno);
            }
        } else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (confirm.equalsIgnoreCase("yes")) {
                ClickOnMobileElement(profile_btn_addconfirm);
            } else if (confirm.equalsIgnoreCase("no")) {
                ClickOnMobileElement(profile_btn_addconfirmNo);
            }
        }

    }

    public void checkandchangeProfiletype(String profileType) {
        if (profileType.equalsIgnoreCase("kid to teen")) {
            if (isElementPresent(profile_lbl_editprofiledropdown)) {
                ClickOnMobileElement(profile_lbl_editprofiledropdown);
//			if(isElementPresent(profile_lbl_editprofiledropdown))
//			{
//			ClickOnMobileElement(profile_lbl_editprofiledropdown);	
//			}
                if (isElementPresent(profile_drp_teenprofile)) {
                    WaitForMobileElement(profile_drp_teenprofile);
                    ClickOnMobileElement(profile_drp_teenprofile);
                }

            } else if (profileType.equalsIgnoreCase("teen to kid")) {
                ClickOnMobileElement(profile_lbl_editprofiledropdown);
                waitFor(4000);
                ClickOnMobileElement(profile_drp_kidprofile);

            }
        }

    }


    public void clickInterestview() {
        for (int i = 0; i < 10; i++) {
            if (isElementPresent(profile_btn_viewinterests)) {
                break;
            } else {
                swipeDown();
                swipeDown();
            }
        }
        ClickOnMobileElement(profile_btn_viewinterests);

    }


    public void navBackfromIntrestPg() {
        if (isElementPresent(intrestPg_btn_back)) {
            ClickOnMobileElement(intrestPg_btn_back);
        }
    }

    public void selectCheckoutTitles() {
        if (isElementPresent(profile_chk_checkouttitles)) {
            ClickOnMobileElement(profile_chk_checkouttitles);
        }
    }

    public void selectCheckoutHistory() {
        if (isElementPresent(profile_chk_checkouthistory)) {
            ClickOnMobileElement(profile_chk_checkouthistory);
        }
    }

    public void selectInsightbadges() {
        waitFor(2000);
        if (isElementPresent(profile_chk_insightandBadges)) {
            ClickOnMobileElement(profile_chk_insightandBadges);
        } else if (isElementPresent(profile_chk_insightandBadges2)) {
            ClickOnMobileElement(profile_chk_insightandBadges2);

        }
    }

    public void clickonSaveCTA() {
        if (isElementPresent(profile_btn_editprofilesave)) {
            ClickOnMobileElement(profile_btn_editprofilesave);
        }
        if (isElementPresent(profile_btn_editsaveconfirmyes)) {
            ClickOnMobileElement(profile_btn_editsaveconfirmyes);
        }
    }

    public void enablemyShelfLanding() {
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(profile_chk_landingPage)) {
                if (profile_chk_landingPage.getAttribute("enabled").equalsIgnoreCase("true")) {
                    logger.info(" myShelf is set as landing page");
                    ClickOnMobileElement(profile_chk_landingPage);
                    if (isElementPresent(profile_chk_landingPage)) {
                        ClickOnMobileElement(profile_chk_landingPage);
                    }

                } else {
                    ClickOnMobileElement(profile_chk_landingPage);
                }
                ClickOnMobileElement(profile_btn_editprofilesave);
                if (isElementPresent(profile_btn_editsaveconfirmyes)) {
                    ClickOnMobileElement(profile_btn_editsaveconfirmyes);
                }

            } else {
                ClickOnMobileElement(profile_btn_backbtn);
            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (profile_chk_landingPage.getAttribute("checked").equalsIgnoreCase("true")) {
                logger.info(" myShelf is set as landing page");
                ClickOnMobileElement(profile_chk_landingPage);
                WaitForMobileElement(profile_chk_landingPage);
                if (isElementPresent(profile_chk_landingPage)) {
                    ClickOnMobileElement(profile_chk_landingPage);
                }
                ClickOnMobileElement(profile_chk_landingPage);
            } else {
                ClickOnMobileElement(profile_chk_landingPage);
            }
            ClickOnMobileElement(profile_btn_editprofilesave);
            if (isElementPresent(profile_btn_editsaveconfirmyes)) {
                ClickOnMobileElement(profile_btn_editsaveconfirmyes);
            }
        }

    }

    public void disablemyShelfLanding() {
        for (int i=0;i<5;i++)
        {
            if (isElementPresent(profile_chk_landingPage))
            {
                break;
            }
            swipeDown();
        }
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(profile_chk_landingPage)) {
                if (profile_chk_landingPage.getAttribute("enabled").equalsIgnoreCase("true")) {
                    logger.info(" myShelf  option is alrady disabled as landing page");
                    ClickOnMobileElement(profile_chk_landingPage);
                    ClickOnMobileElement(profile_chk_landingPage);
                } else {
                    ClickOnMobileElement(profile_chk_landingPage);
                }
            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (profile_chk_landingPage.getAttribute("checked").equalsIgnoreCase("false")) {
                logger.info(" myShelf  option is alrady disabled as landing page");
                ClickOnMobileElement(profile_chk_landingPage);
                if (isElementPresent(profile_chk_landingPage)) {
                    ClickOnMobileElement(profile_chk_landingPage);
                }
            } else {
                ClickOnMobileElement(profile_chk_landingPage);
            }
        }
        ClickOnMobileElement(profile_btn_backbtn);
        if (isElementPresent(profile_btn_editprofilesave)) {
            ClickOnMobileElement(profile_btn_editprofilesave);
        }
        if (isElementPresent(profile_btn_editsaveconfirmyes)) {
            ClickOnMobileElement(profile_btn_editsaveconfirmyes);
        }
    }

    public void enableAllOptionsinMyProfilePg() {
        for (int i=0;i<5;i++)
        {
            if (isElementPresent(profile_chk_insightandBadges))
            {
                break;
            }
            swipeDown();
        }
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(profile_chk_insightandBadges)) {
                if (profile_chk_insightandBadges.getAttribute("enabled").equalsIgnoreCase("true")
                        && profile_chk_checkouttitles.getAttribute("enabled").equalsIgnoreCase("true")
                        && profile_chk_checkouthistory.getAttribute("enabled").equalsIgnoreCase("true")) {
                    logger.info("all options are already disabled for profile");
                }
                if (profile_chk_insightandBadges.getAttribute("enabled").equalsIgnoreCase("false")) {
                    ClickOnMobileElement(profile_chk_insightandBadges);
                }
                if (profile_chk_checkouttitles.getAttribute("enabled").equalsIgnoreCase("false")) {
                    ClickOnMobileElement(profile_chk_checkouttitles);
                }
                if (profile_chk_checkouthistory.getAttribute("enabled").equalsIgnoreCase("false")) {
                    ClickOnMobileElement(profile_chk_checkouthistory);
                }
            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("true")
                    && profile_chk_checkouttitles.getAttribute("checked").equalsIgnoreCase("true")
                    && profile_chk_checkouthistory.getAttribute("checked").equalsIgnoreCase("true")) {
                logger.info("all options are already disabled for profile");
                ClickOnMobileElement(editprofile_btn_close);
                return;
            }
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("false")) {
                ClickOnMobileElement(profile_chk_insightandBadges);
            }
            if (profile_chk_checkouttitles.getAttribute("checked").equalsIgnoreCase("false")) {
                ClickOnMobileElement(profile_chk_checkouttitles);
            }
            if (profile_chk_checkouthistory.getAttribute("checked").equalsIgnoreCase("false")) {
                ClickOnMobileElement(profile_chk_checkouthistory);
            }
        }
        if (isElementPresent(profile_btn_editprofilesave)) {
            ClickOnMobileElement(profile_btn_editprofilesave);
        }
        if (isElementPresent(profile_btn_editsaveconfirmyes)) {
            ClickOnMobileElement(profile_btn_editsaveconfirmyes);
        }
    }

    public void disableAllOptionsinMyProfilePg() {
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            if (isElementPresent(profile_chk_insightandBadges)) {
                if (profile_chk_insightandBadges.getAttribute("enabled").equalsIgnoreCase("false")
                        && profile_chk_checkouttitles.getAttribute("enabled").equalsIgnoreCase("false")
                        && profile_chk_checkouthistory.getAttribute("enabled").equalsIgnoreCase("false")) {
                    logger.info("all options are already disabled for profile");
                }

                if (profile_chk_checkouttitles.getAttribute("enabled").equalsIgnoreCase("true")) {
                    ClickOnMobileElement(profile_chk_checkouttitles);
                }
                if (profile_chk_checkouthistory.getAttribute("enabled").equalsIgnoreCase("true")) {
                    ClickOnMobileElement(profile_chk_checkouthistory);
                }
                if (profile_chk_insightandBadges.getAttribute("enabled").equalsIgnoreCase("true")) {
                    ClickOnMobileElement(profile_chk_insightandBadges);
                }
            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("false")
                    && profile_chk_checkouttitles.getAttribute("checked").equalsIgnoreCase("false")
                    && profile_chk_checkouthistory.getAttribute("checked").equalsIgnoreCase("false")) {
                logger.info("all options are already disabled for profile");
                ClickOnMobileElement(editprofile_btn_close);
                return;
            }

            if (profile_chk_checkouttitles.getAttribute("checked").equalsIgnoreCase("true")) {
                ClickOnMobileElement(profile_chk_checkouttitles);
            }
            if (profile_chk_checkouthistory.getAttribute("checked").equalsIgnoreCase("true")) {
                ClickOnMobileElement(profile_chk_checkouthistory);
            }
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("true")) {
                ClickOnMobileElement(profile_chk_insightandBadges);
            }
        }
        if (isElementPresent(profile_btn_disable)) {
            ClickOnMobileElement(profile_btn_disable);
        }

        if (isElementPresent(profile_btn_editprofilesave)) {
            ClickOnMobileElement(profile_btn_editprofilesave);
        }
        if (isElementPresent(profile_btn_editsaveconfirmyes)) {
            ClickOnMobileElement(profile_btn_editsaveconfirmyes);
        }
        logger.info("save btn clicked");
        logger.info("save confirmation pop ok clicked");
    }

    public void enableInsight() {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            swipeDown();
            swipeDown();
            if (isElementPresent(Insight)) {
                if (Insight.getAttribute("value").contains("checkbox, checked, on")) {
                    logger.info("profile already selected");
                    ClickOnMobileElement(geteditprofile_btn_close());
                } else {
                    ClickOnMobileElement(Insight);
                    if (isElementPresent(profile_btn_editprofilesave)) {
                        ClickOnMobileElement(profile_btn_editprofilesave);
                    }
                    if (isElementPresent(profile_btn_editsaveconfirmyes)) {
                        ClickOnMobileElement(profile_btn_editsaveconfirmyes);
                    }
                }

            }
        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("true")) {
                logger.info("profile already selected");
                ClickOnMobileElement(geteditprofile_btn_close());
            } else {
                ClickOnMobileElement(profile_chk_insightandBadges);
                ClickOnMobileElement(profile_btn_editprofilesave);
                if (isElementPresent(profile_btn_editsaveconfirmyes)) {
                    ClickOnMobileElement(profile_btn_editsaveconfirmyes);
                }
            }
        }
    }

    public void disableInsight() {
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            swipeDown();
            swipeDown();
            if (isElementPresent(Insight)) {
                if (Insight.getAttribute("value").contains("not checked")) {
                    ClickOnMobileElement(Insight);
                    swipeDown();
                    swipeDown();
                    if (isElementPresent(profile_btn_editprofilesave)) {
                        ClickOnMobileElement(profile_btn_editprofilesave);
                    }
                    if (isElementPresent(profile_btn_editsaveconfirmyes)) {
                        ClickOnMobileElement(profile_btn_editsaveconfirmyes);
                    }
                } else {
                    ClickOnMobileElement(geteditprofile_btn_close());
                }

            }

        }
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            swipeDown();
            swipeDown();
            if (profile_chk_insightandBadges.getAttribute("checked").equalsIgnoreCase("true")) {
                logger.info("insight is already enabled for profile");
                ClickOnMobileElement(profile_chk_insightandBadges);
                swipeDown();
                swipeDown();
                ClickOnMobileElement(profile_btn_editprofilesave);
//			ClickOnMobileElement(profile_btn_editsaveconfirmyes);
            } else {
                ClickOnMobileElement(geteditprofile_btn_close());
            }
        }
    }


    public void clickProfile() {
//    	WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
//    	MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(profileIcon));
//		mobelement.click();
        ClickOnMobileElement(profileIcon);
    }

    public MobileElement profile_txt() {
        return profile_txt_editProfile;
    }
    

}
