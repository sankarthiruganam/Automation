package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class SecurityQuestion extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public SecurityQuestion(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(accessibility = "loc_dropRegisterSecurityQuest")
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/content']//android.widget.LinearLayout")
	private List<MobileElement> sec_drpd_question;

	@iOSXCUITFindBy(accessibility = "loc_dropRegisterSecurityQuest")
	@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"Security Question*\"]")
	private MobileElement sec_drpd;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Close page\"]")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/secQues_tvQuestions")
	public MobileElement sec_lbl_close;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterSecurityAns")
	@AndroidFindBy(xpath = "//android.widget.LinearLayout[@content-desc=\"Security Answer*\"]/android.widget.FrameLayout/android.widget.EditText")
	public MobileElement sec_txt_ans;

	public List<MobileElement> getSec_drpd_question() {
		return sec_drpd_question;
	}

	public MobileElement getSec_txt_ans() {
		return sec_txt_ans;
	}

	public MobileElement getSec_drpd() {
		return sec_drpd;
	}

	/***************************** Action methods *************************/

	public void selectSecurityQuestion() {
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			ClickOnMobileElement(sec_drpd);
			ClickOnMobileElement(sec_lbl_close);
			SendKeysOnMobileElement(sec_txt_ans, "elephant");
		} else {
			ClickOnMobileElement(sec_drpd);
			ClickOnMobileElement(sec_drpd_question.get(2));
			ClickOnMobileElement(sec_txt_ans);
			SendKeysOnMobileElement(sec_txt_ans,"elephant");
				DriverManager.getDriver().navigate().back();
				swipeDown();
		}

		
	}

}
