package pom.kidszone;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Tier1_LandingPage_VBookandVideo extends CommonActions {

	public Tier1_LandingPage_VBookandVideo(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/****************** Locators ******************/

	@iOSXCUITFindBy(accessibility = "third_party_header_VBOOKS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VBOOKS']")
	private MobileElement vBookCarouselInMyLibrary;

	@iOSXCUITFindBy(xpath = "//*[@label='All Videobooks see all']")
	@AndroidFindBy(xpath = "//*[@content-desc='All Videobooks see all, ']")
	private MobileElement allVideobooksSeeAll;

	@iOSXCUITFindBy(xpath = "//*[@name ='WidgetsCarousel']//*[@name='third_party_see_all_link_VBOOKS']")
	@AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_see_all_link_VBOOKS']")
	private MobileElement vBookSeeAllInMyLibrary;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='CategoryCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_category_card')])[1]")
	private MobileElement firstVBook;

	@iOSXCUITFindBy(xpath = "//*[@name ='ItemCarousel']//*[@name='third_party_see_all_link_VBOOKS']")
	@AndroidFindBy(xpath = "//*[@resource-id='ItemCarousel']//*[@resource-id='third_party_see_all_link_VBOOKS']")
	private MobileElement vBookCarouselSeeAll;
	
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_VBOOKS\"])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_see_all_link_VBOOKS']")
	private MobileElement vBookWidgetSeeAll;
	
	@iOSXCUITFindBy(accessibility = "The URL Link test See All")
	@AndroidFindBy(xpath = "//*[@resource-id='The URL Link test See All']")
	private MobileElement vBookSeeAllInMyLibrary_card;

	@iOSXCUITFindBy(xpath = "//*[@label='All Videos see all']")
	@AndroidFindBy(xpath = "//*[@content-desc='All Videos see all, ']")
	private MobileElement allVideosSeeAll;

	@iOSXCUITFindBy(accessibility = "Dummy_titleDetailPageVideo")
	@AndroidFindBy(xpath = "(//*[contains(@content-desc,'Video')])[1]")
	private MobileElement titleDetailPageVideo;
	
	@iOSXCUITFindBy(accessibility = "Dummy_checkoutAvailable")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]")
	private MobileElement checkoutAvailable;
	
	@iOSXCUITFindBy(accessibility = "Dummy_checkoutAvailable")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]")
	private MobileElement checkoutHistoryAvailable;
	
	@iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
	@AndroidFindBy(xpath = "//*[@resource-id='btnPurchaseRequest']")
	private MobileElement purchaseRequest_CTA;
	
	@iOSXCUITFindBy(accessibility = "btnCheckoutHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
	public MobileElement history_CTA;

	@iOSXCUITFindBy(accessibility = "btnDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='btnDownload']")
	public MobileElement download_CTA;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"CheckoutView\"]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
	public List<MobileElement> history_CTA1;
	
	@iOSXCUITFindBy(accessibility = "Dummy_titleDetailPagevBook")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy_titleDetailPagevBook']")
	private MobileElement titleDetailPagevBook;
	
	@iOSXCUITFindBy(accessibility = "third_party_see_all_link_VIDEOS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement seeAllTier2;
	
	@iOSXCUITFindBy(accessibility = "Dummy_videoCarouselInTier2")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header_\"]")
	private MobileElement videoCarouselInTier2;
	
	@iOSXCUITFindBy(accessibility = "Dummy_vBookCarouselInTier2")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header_']")
	private MobileElement vBookCarouselInTier2;
							 	
	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'third_party_see_all_link_VBOOKS')])")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_see_all_link_VBOOKS\"]")
	private MobileElement 	vBookSeeAllCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "third_party_header_VIDEOS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VIDEOS']")
	private MobileElement videoCarouselInMyLibrary;

	@iOSXCUITFindBy(xpath = "//*[@name ='WidgetsCarousel']//*[@name='third_party_see_all_link_VIDEOS']")
	@AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoSeeAllInMyLibrary;

	@iOSXCUITFindBy(xpath = "//*[@name ='WidgetsCarousel']//*[@name='third_party_see_all_link_VIDEOS']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='adp-category-text']")
	private MobileElement videoCategoryText;

	@iOSXCUITFindBy(xpath = "(//*[@name='third_party_see_all_link_VIDEOS'])[1]")
	@AndroidFindBy(xpath = "(//*[@name='third_party_see_all_link_VIDEOS'])[1]")
	private MobileElement popularVideosSeeAll;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'Video')])[5]")
	@AndroidFindBy(xpath = "(//*[contains(@label,'Video')])[5]")
	private MobileElement videosTitle;
	
	@AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoWidgetSeeAll;

	@iOSXCUITFindBy(xpath = "//*[@name ='ItemCarousel']//*[@name='third_party_see_all_link_VIDEOS']")
	@AndroidFindBy(xpath = "//*[@resource-id='ItemCarousel']//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoCarouselSeeAll;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,\"third_party_see_all_link_VIDEOS\")])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='third_party_see_all_link_VIDEOS'])[1]")
	private MobileElement videoSeeAllInTier1Screen;

	@iOSXCUITFindBy(accessibility = "third_party_see_all_link_VIDEOS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoSeeAllCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
	private MobileElement vBookCarouselInTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
	private MobileElement vBookTier1Title;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement vBookFeaturedTier2Title;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement videoFeaturedTier2Title;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement vBookCategoryTier2Title;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement videoCategoryTier2Title;

	@iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'tier_3_txtTitle')]")
	private MobileElement videoBookTitleInTier3;

	@iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'tier_3_txtTitle')]")
	private MobileElement vBookTitleInTier3;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement backIcon;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,\"adp_card_image\")])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image')])[1]")
	private MobileElement videoTitleCarouselTier1;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_VID')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
	private MobileElement videoSeriesTitleCarouselTier1;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_VBK')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
	private MobileElement vBookTitleCarouselTier1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"adp_card_image_card_VBK\")])[11]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
	private MobileElement vBookSeriesTitleCarouselTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Categories')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Categories')]")
	private MobileElement vBookCategoryTitleInTier1Header;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see_all_link_VBOOKS')]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_see_all_link_VBOOKS\"]")
	private MobileElement vBookCategorySeeAllTitleInTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see_all_link_VIDEOS')]")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoCategorySeeAllTitleInTier1;

	@iOSXCUITFindBy(xpath = "(//*[@name=\"third_party_header_VIDEOS\"])[2]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Categories')]")
	private MobileElement videoCategoryTitleInTier1Header;

	@iOSXCUITFindBy(accessibility = "LIBRARY_FILTER_FORMAT")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_FILTER_FORMAT']")
	private MobileElement formatDropDown;

	@iOSXCUITFindBy(accessibility = "filter_vBook_option_test_id")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'vBookunselected')]")
	private MobileElement vBookFormatOption;

	@iOSXCUITFindBy(accessibility = "filter_video_option_test_id")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Videounselected')]")
	private MobileElement videoFormatOption;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see_all_link_VBOOKS')]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_see_all_link_VBOOKS\"]")
	private MobileElement seeAll_Tier1Vbook;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see_all_link_VIDEOS')]")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement seeAll_Tier1Video;
	
	@iOSXCUITFindBy(accessibility = "Dummy_videoTitleCard")
	@AndroidFindBy(xpath = "(//*[contains(@content-desc,'Video')])[2]")
	private MobileElement videoTitleCard;
	
	@iOSXCUITFindBy(accessibility = "Dummy_vBookTitleCard")
	@AndroidFindBy(xpath = "(//*[contains(@content-desc,'Vbook')])[1]")
	private MobileElement vBookTitleCard;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"Vbook\"])[1]")
	private MobileElement vbookTitleIcon;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Checkout\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Checkout\"])[1]")
	private MobileElement vBookCheckoutCTAInTier1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Play\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Play\"])[1]")
	private MobileElement vBookPlayCTAInTier1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Resume\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Resume\"])[1]")
	private MobileElement vBookResumeCTAInTier1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_checkout_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Checkout\"])[1]")
	private MobileElement videoCheckoutCTAInTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_title_details_play_cta_')]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Play\"])[1]")
	private MobileElement videoPlayCTAInTier1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_resume_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Resume\"])[1]")
	private MobileElement videoResumeCTAInTier1;

	@iOSXCUITFindBy(accessibility = "StackCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='StackCarousel']")
	private MobileElement vBookStackCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "ItemCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='ItemCarousel']")
	private MobileElement vBookItemCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "CardCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='CardCarousel']")
	private MobileElement vBookCardCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "StackCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='StackCarousel']")
	private MobileElement videoStackCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "ItemCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='ItemCarousel']")
	private MobileElement videoItemCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "CardCarousel")
	@AndroidFindBy(xpath = "//*[@resource-id='CardCarousel']")
	private MobileElement videoCardCarouselInTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VID')]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
	private MobileElement videoTier1Title;

	@iOSXCUITFindBy(accessibility = "tier_1_txtTitle")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'tier_1_txtTitle')])[1]")
	private MobileElement videoTier1Heading;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VID')]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
	private MobileElement videoTitleIconInTier1;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
	private MobileElement vBookTitleIconInTier1;

	@iOSXCUITFindBy(xpath = "(//*[@name=\"third_party_header_VIDEOS\"])[3]")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VIDEOS']")
	private MobileElement videoCategoriesCarouselHeader;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header_VIDEOS\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='third_party_header_VIDEOS'])[1]")
	private MobileElement videoFeaturedCarouselHeader;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header_VBOOKS\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='third_party_header_VBOOKS'])[1]")
	private MobileElement vBookFeaturedCarouselHeader;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Categories')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Categories')]")
	private MobileElement vBookTitleCarouselHeader;


	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Categories')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Categories')]")
	private MobileElement videoTitleCarouselHeader;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='adp_card_category_card_'])[1]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_category_card')]")
	private List<MobileElement> videoCategoriesIcon;

	@iOSXCUITFindBy(accessibility = "adp_card_category_card_CHKEB")
	@AndroidFindBy(xpath = "//*[@resource-id='adp_card_category_card_CHKEB']")
	private MobileElement videoCategoriesName;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement vBookCategoriesInTier2;

	@iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
	private MobileElement videoCategoriesInTier2;
	
	@iOSXCUITFindBy(accessibility = "viewGridContainer0")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]")
	private MobileElement checkedout_title_available;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header_VBOOKS\"])[3]")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VBOOKS']")
	private MobileElement vBookCategoriesCarouselHeader;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_category_card')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_category_card')]")
	private List<MobileElement> vBookCategoriesIcon;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"adp_card_category_card\")])[1]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card')]")
	private MobileElement vBookCategoriesName;

	@iOSXCUITFindBy(accessibility = "third_party_intro")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_intro']")
	private MobileElement vBook_thirdParty_intro;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header_VIDEOS\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='third_party_header_VIDEOS'])[1]")
	private MobileElement featuredCarouselInTier1;

	@iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='more_LIBRARY_ADVANCE_SEARCH_BUTTON']")
	private MobileElement advance_serach_button;
	
	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement clickMenu;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@label,'adp_card_title_details_return_cta')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_title_details_return_cta')]")
	public MobileElement return_title;

	@iOSXCUITFindBy(accessibility = "adp_card_footer_title_text")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_footer_title_text')]")
	public MobileElement title_txt;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Renew')]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Renew\"]")
	private MobileElement renew_title;
	
	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_checkout_remove')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Remove\"])[1]")
	private MobileElement remove_title;

	@iOSXCUITFindBy(accessibility = "btnAlertOkay")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
	private MobileElement removalConfirmationPopup;
	
	@iOSXCUITFindBy(accessibility = "Profiles_Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Profiles_Menu']")
	private MobileElement clickProfiles;
	
	@iOSXCUITFindBy(accessibility = "txtProfileListType1")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListType1']")
	private MobileElement teenprofileSelection;

	@iOSXCUITFindBy(accessibility = "txtProfileListType2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListType2']")
	private MobileElement kidprofileSelection;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card')]")
	@AndroidFindBy(xpath = "//*[@resource-id = 'checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]")
	private MobileElement videoTitles_Checkedout;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'You have checked out')]")
	@AndroidFindBy(xpath = "//*[@resource-id = 'message_snackbar_view']")
	private MobileElement checkout_success_Toast_Message;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'You have returned')]")
	@AndroidFindBy(xpath = "//*[@resource-id = 'message_snackbar_view']")
	private MobileElement return_Toast_Message;
	
	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeStaticText[contains(@name,'has been renewed')]")
	@AndroidFindBy(xpath = "//*[@resource-id = 'message_snackbar_view']")
	private MobileElement renew_Toast_Message;
	
	@iOSXCUITFindBy(accessibility = "message_snackbar_view")
	@AndroidFindBy(xpath = "//*[@resource-id = 'message_snackbar_view']")
	private MobileElement remove_Checkout_History;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id = 'checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]")
	private MobileElement videoTitles_Checked1;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_checkout_card')]")
	private MobileElement title_Cover_Image;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id = 'Dummy_Name']")
	private MobileElement title_Cover_Name;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"AUTHOR\"]")
	private MobileElement title_Author_Name;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'Resume')]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Resume\"]")
	private MobileElement primary_Action_Resume;
	
	@iOSXCUITFindBy(xpath = "(//*[@label='Play'])[1]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Play\"]")
	private MobileElement primary_Action;

	@iOSXCUITFindBy(xpath = "(//*[@label='Play'])[1]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Play\"]")
	private MobileElement checkout_History_Primary_Action;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'Renew')]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Renew\"]")
	private MobileElement secondary_Action1;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Return\"]")
	private MobileElement secondary_Action2;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id = 'checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]")
	private MobileElement videoTitles_Checked2;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card')]")
	@AndroidFindBy(xpath = "//*[@resource-id = 'checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]")
	private MobileElement vBookTitles_Checkedout;
	
	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement myshelf_btn;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VID')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_checkout_card_VID')]")
	public List<MobileElement> title_Image;
	
	@iOSXCUITFindBy(accessibility = "Sort_icon_test_id_image")
	@AndroidFindBy(xpath = "//*[@resource-id='Sort_icon_test_id_image']")
	private MobileElement filter_option;
	
	@iOSXCUITFindBy(accessibility = "Filter_icon_test_id_image")
	@AndroidFindBy(xpath = "//*[@resource-id='Filter_icon_test_id_image']")
	private MobileElement sort_option;
	
	@iOSXCUITFindBy(accessibility = "Search_text_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Search_text_icon_test_id']")
	private MobileElement searchIcon_Checkouts;
	
	@iOSXCUITFindBy(accessibility = "Mystuff_internal_search_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Mystuff_internal_search_test_id']")
	private MobileElement search_keyword;
	
	@iOSXCUITFindBy(accessibility = "START_BY_LATEST")
	@AndroidFindBy(xpath = "//*[@resource-id='START_BY_LATEST']")
	private MobileElement sort_Recently_Checkedout;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Close')]")
	private MobileElement close_1stCheckout;
	
	@iOSXCUITFindBy(accessibility = "SORT_BY_ATOZ")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_ATOZ']")
	private MobileElement sort_AtoZ_Checkedout;
	
	@iOSXCUITFindBy(accessibility = "SORT_BY_RATING")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_RATING']")
	private MobileElement sort_Ratings_Checkedout;

	@iOSXCUITFindBy(accessibility = "SORT_BY_DUEDATE")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_DUEDATE']")
	private MobileElement sort_DueDate_Checkedout;
	
	@iOSXCUITFindBy(accessibility = "FILTER_FOR_ALL")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_ALL']")
	private MobileElement all_Filter_option;
	
	@iOSXCUITFindBy(accessibility = "READ_AS_EBOOK")
	@AndroidFindBy(xpath = "//*[@resource-id='READ_AS_EBOOK']")
	private MobileElement eBook_Filter_option;
	
	@iOSXCUITFindBy(accessibility = "READ_AS_AUDIO")
	@AndroidFindBy(xpath = "//*[@resource-id='READ_AS_AUDIO']")
	private MobileElement eAudio_Filter_option;
	
	@iOSXCUITFindBy(accessibility = "FILTER_FOR_VIDEO")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEO']")
	private MobileElement videos_Filter_option;
	
	@iOSXCUITFindBy(accessibility = "FILTER_FOR_VIDEOBOOK")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEOBOOK']")
	private MobileElement vBooks_Filter_option;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"adp_card_checkout_card_VID\")])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEOBOOK']")
	private MobileElement vBooksTitle;

	@iOSXCUITFindBy(accessibility = "(//XCUIElementTypeButton[contains(@name,\"adp_card_checkout_card_VBK\")])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEOBOOK']")
	private MobileElement videoTitle;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card')]")
	@AndroidFindBy(xpath = "(//android.widget.Button[contains(@resource-id,'adp_card_checkout')]/android.widget.TextView)[1]")
	private MobileElement checkout_Video;
	
	@iOSXCUITFindBy(accessibility = "FILTER_FOR_ALL")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_ALL']")
	private MobileElement filter_All;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'btnCheckout')]")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement checkout_CTA;
	
	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkout')]")
	private MobileElement video_checkout_CTA;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "(//*[@resource-id='third_party_header'])[1]/parent::android.view.ViewGroup/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup")
	private List<MobileElement> featuredTitlesInTier1;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VID')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_checkout_card_VID')]")
	private List<MobileElement> video_title;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VBK')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_checkout_card_VBK')]")
	private List<MobileElement> vBooks_title;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VBK')]")
	@AndroidFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VBK')]")
	private MobileElement latest_title_vbook_checkedout;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VID')]")
	@AndroidFindBy(xpath = "//*[contains(@name,'adp_card_checkout_card_VID')]")
	private MobileElement latest_title_video_checkedout;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Play')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Play')]")
	private MobileElement video_action_CTA1;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Resume')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Resume')]")
	private MobileElement video_action_CTA2;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Play')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Play')]")
	private MobileElement vBook_action_CTA1;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Resume')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Resume')]")
	private MobileElement vBook_action_CTA2;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@name,'Checkout')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkout')]")
	private MobileElement CheckOut_CTA;

	@iOSXCUITFindBy(accessibility = "third_party_see_all_link_VIDEOS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VIDEOS']")
	private MobileElement videoWidgetsSeeAllLinkInMyLibrary;


	@iOSXCUITFindBy(accessibility = "search icon")
	@AndroidFindBy(xpath = "//*[@content-desc='Search']")
	private MobileElement videoWidgetsSeeAllLinkInTier1;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'Videobooks see all')])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VBOOKS']")
	private MobileElement vBookWidgetsSeeAllLinkInMyLibrary;

	@iOSXCUITFindBy(accessibility = "search icon")
	@AndroidFindBy(xpath = "//*[@content-desc='Search']")
	private MobileElement vBookWidgetsSeeAllLinkInTier1;
	
	@iOSXCUITFindBy(accessibility = "REFINE_ICON")
	@AndroidFindBy(xpath = "//*[@resource-id=\"REFINE_ICON\"]")
	private MobileElement refineCTA;

	@iOSXCUITFindBy(accessibility = "filter_cta")
	@AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
	private MobileElement search_Refine_btn;

	@iOSXCUITFindBy(accessibility= "third_party_see_all_link_VBOOKS")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_VBOOKS']")
	private MobileElement featuredSeeAll;

	@iOSXCUITFindBy(accessibility = "tier_1_txtTitle")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'tier_1_txtTitle')]")
	private MobileElement Tier1Heading;

	/********************************** Methods **************************/

	
	
	public MobileElement getvBook_thirdParty_intro() {
		return vBook_thirdParty_intro;
	}

	public MobileElement getPrimary_Action_Resume() {
		return primary_Action_Resume;
	}


	public MobileElement getLatest_title_vbook_checkedout() {
		return latest_title_vbook_checkedout;
	}


	public MobileElement getLatest_title_video_checkedout() {
		return latest_title_video_checkedout;
	}


	public MobileElement checkVBookCarouselInMyLibrary() {
		for(int i=0;i<6;i++) {
			if(isElementPresent(vBookCarouselInMyLibrary)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		return vBookCarouselInMyLibrary;
	}

	public void clickallVideosSeeAll(){
		for(int i=0;i<10;i++) {
			if(isElementPresent(allVideosSeeAll)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(allVideosSeeAll);
	}

	public void clickAllVideobooksSeeAll(){
		for (int i = 0; i < 10; i++) {
			if (isElementPresent(allVideobooksSeeAll)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(allVideobooksSeeAll);

	}
	public MobileElement checkTitleDetailPageVideo() {
		return titleDetailPageVideo;
	}
	
	public MobileElement getvBookTier1Title() {
		return vBookTier1Title;
	}

	public MobileElement checkTitleDetailPagevBook() {
		return titleDetailPagevBook;
	}
	
	public MobileElement checkSeeAllTier2() {
		return seeAllTier2;
	}
	
	public MobileElement checkVideoCarouselInTier2() {
		return videoCarouselInTier2;
	}
	
	public MobileElement checkvBookCarouselInTier2() {
		return vBookCarouselInTier2;
	}
	
	public MobileElement checkVideoCarouselInMyLibrary() {
		return videoCarouselInMyLibrary;
	}

	public MobileElement checkVideoSeeAllCarouselInTier1() {
		for(int i=0;i<6;i++) {
			if(isElementPresent(videoSeeAllCarouselInTier1)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		return videoSeeAllCarouselInTier1;
	}

	public void clickVBookSeeAllCarouselInMyLibrary() {
		ClickOnMobileElement(vBookSeeAllCarouselInTier1);
	}

	public MobileElement checkVBookSeeAllCarouselInTier1() {
		for(int i=0;i<8;i++) {
			if(isElementPresent(vBookSeeAllCarouselInTier1)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		return vBookSeeAllCarouselInTier1;
	}

	public MobileElement checkVideo_action_CTA() {
		if(isElementPresent(video_action_CTA1)){
				return video_action_CTA1;
			}
		else {
			return video_action_CTA2;
		}
	}

	public MobileElement checkvBook_action_CTA() {
		if(isElementPresent(vBook_action_CTA1)) {
			return vBook_action_CTA1;
		}
		else {
			return vBook_action_CTA2;
		}
	}

	public void clickVideoSeeAllCarouselInMyLibrary() {
		ClickOnMobileElement(videoSeeAllCarouselInTier1);
	}

	public void clickSeeAllTier2() {
		ClickOnMobileElement(seeAllTier2);
	}

	public void clickVBookSeeAllInMyLibrary() {
		for(int i=0;i<5;i++) {
			if (isElementPresent(firstVBook)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(vBookSeeAllInMyLibrary);
	}
	
	public void clickVBookWidgetSeeAll() {
		if(isElementPresent(vBookWidgetSeeAll))
		{
		ClickOnMobileElement(vBookWidgetSeeAll);
		}
		else
		{
		ClickOnMobileElement(vBookSeeAllInMyLibrary_card);
		}
	}

	public void clickVBookCarouselSeeAll() {
		if(isElementPresent(vBookCarouselSeeAll))
		{
			ClickOnMobileElement(vBookCarouselSeeAll);
		}
		else
		{
			ClickOnMobileElement(vBookSeeAllInMyLibrary_card);
		}
	}

	public void clickVideoCarouselSeeAll() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(videoCarouselSeeAll)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(videoCarouselSeeAll);
	}

	public void clickVideoSeeAllInMyLibrary() {
		for (int i = 0; i < 6; i++) {
			if (isElementPresent(videoCategoryText)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(videoSeeAllInMyLibrary);
	}

	public void clickVideoWidgetSeeAll() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(videoWidgetSeeAll)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(videoWidgetSeeAll);
	}
	
	public void clickVideoSeeAllInTier1Screen() {
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(videoSeeAllInTier1Screen)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(videoSeeAllInTier1Screen);
	}

	public MobileElement checkVBookCarouselInTier1() {
		return vBookCarouselInTier1;
	}

	public MobileElement checkVBookTier1Title() {
		return vBookTier1Title;
	}

	public MobileElement checkFeaturedVBookTier2Title() {
		return vBookFeaturedTier2Title;
	}

	public MobileElement checkFeaturedVideoTier2Title() {
		return videoFeaturedTier2Title;
	}

	public MobileElement checkCategoryVBookTier2Title() {
		return vBookCategoryTier2Title;
	}

	public MobileElement checkCategoryVideoTier2Title() {
		return videoCategoryTier2Title;
	}

	public MobileElement checkVideoBookTitleInTier3() {
		return videoBookTitleInTier3;
	}

	public MobileElement checkVBookTitleInTier3() {
		return vBookTitleInTier3;
	}

	public void clickBackButton() {
		ClickOnMobileElement(backIcon);
	}

	public void clickVideoTitleCarouselTier1() {
		ClickOnMobileElement(videoTitleCarouselTier1);
	}

	public MobileElement getFirstVideo(){
		return videoSeriesTitleCarouselTier1;
	}
	public void clickVideoSeriesTitleCarouselTier1() {
		ClickOnMobileElement(videoSeriesTitleCarouselTier1);
	}

	public void clickVBookSeriesTitleCarouselTier1() {
		ClickOnMobileElement(vBookSeriesTitleCarouselTier1);
		waitFor(2000);
	}

	public void clickVBookTitleCarouselTier1() {
		ClickOnMobileElement(vBookTitleCarouselTier1);
	}

	public MobileElement checkVideoTier1Title() {
		return videoTier1Title;
	}

	public MobileElement checkVBookCategoryTitleInTier1Header() {
		return vBookCategoryTitleInTier1Header;
	}

	public MobileElement checkvBookCategorySeeAllTitleInTier1() {
		return vBookCategorySeeAllTitleInTier1;
	}

	public MobileElement checkVideoCategorySeeAllTitleInTier1() {
		return videoCategorySeeAllTitleInTier1;
	}

	public void clickvBookCategorySeeAllTitleInTier1() {
		ClickOnMobileElement(vBookCategorySeeAllTitleInTier1);
	}

	public void clickVideoCategorySeeAllTitleInTier1() {
		ClickOnMobileElement(videoCategorySeeAllTitleInTier1);
	}

	public MobileElement checkVideoCategoryTitleInTier1Header() {
		return videoCategoryTitleInTier1Header;
	}

	public MobileElement checkVBookTitleIcon() {
		return vBookTitleIconInTier1;
	}

	public MobileElement checkVideoTitleIcon() {
		return videoTitleIconInTier1;
	}
	
	public MobileElement checkvBookTitleIcon() {
		return vBookTitleIconInTier1;
	}
	
	public MobileElement check_All_Filter_option() {
		return all_Filter_option;
	}
	
	public MobileElement check_eBook_Filter_option() {
		return eBook_Filter_option;
	}
	
	public MobileElement check_eAudio_Filter_option() {
		return eAudio_Filter_option;
	}
	
	public MobileElement check_Videos_Filter_option() {
		return videos_Filter_option;
	}
	
	public MobileElement check_vBooks_Filter_option() {
		return vBooks_Filter_option;
	}

	public List<MobileElement> check_Video_title() {
		return video_title;
	}
	
	public List<MobileElement> check_vBooks_title() {
		return vBooks_title;
	}
	
	
	public void clickTitleDetailPageVideo() {
		ClickOnMobileElement(titleDetailPageVideo);
	}
	
	public void clickCheckoutAvailable() {
		ClickOnMobileElement(checkoutAvailable);
	}
	
	public void clickCheckoutHistoryAvailable() {
		ClickOnMobileElement(checkoutHistoryAvailable);
	}

	public List<MobileElement> checkCheckoutHistory() {
		return history_CTA1;
	}
	
	public void clickPurchaseRequest_CTA() {
		ClickOnMobileElement(purchaseRequest_CTA);
	}
	
	public void clickHistory_CTA() {
		ClickOnMobileElement(history_CTA);
	}

	public void clickDownload_CTA() {
		ClickOnMobileElement(download_CTA);
	}
	
	public void selectVBookTitles() {
		ClickOnMobileElement(formatDropDown);
		ClickOnMobileElement(vBookFormatOption);
	}

	public void selectVideoTitles() {
		ClickOnMobileElement(formatDropDown);
		ClickOnMobileElement(videoFormatOption);
	}
	
	public void clickseeAllTier1() {
		for(int i=0;i<4;i++) {
			if(isElementPresent(seeAll_Tier1Vbook)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(seeAll_Tier1Vbook);
	}
	
	public void clickseeAllTier1_vBook() {
		for(int i=0;i<4;i++) {
			if(isElementPresent(seeAll_Tier1Vbook)) {
				swipeDown();
				break;
			}
			else {
				swipeDown();
			}
		}
			ClickOnMobileElement(seeAll_Tier1Vbook);
		
		
	}
	
	public void clickseeAllTier1Video() {
		for(int i=0;i<8;i++) {
			if(isElementPresent(seeAll_Tier1Video)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(seeAll_Tier1Video);
	}
	
	public void clickVideoTitleCard() {
		ClickOnMobileElement(videoTitleCard);
	}
	
	public void clickvBookTitleCard() {
		ClickOnMobileElement(vBookTitleCard);
	}

	public MobileElement checkVBookCheckoutCTAInTier1() {
		return vBookCheckoutCTAInTier1;
	}

	public MobileElement clickVBookCheckoutCTAInTier1() {
		ClickOnMobileElement(vBookCheckoutCTAInTier1);
		return null;
	}

	public MobileElement checkVBookPlayCTAInTier1() {
		return vBookPlayCTAInTier1;
	}

	public MobileElement checkVBookResumeCTAInTier1() {
		return vBookResumeCTAInTier1;
	}

	public MobileElement checkVideoCheckoutCTAInTier1() {
		return videoCheckoutCTAInTier1;
	}

	public void clickVideoCheckoutCTAInTier1() {
		ClickOnMobileElement(videoCheckoutCTAInTier1);
	}

	public MobileElement checkVideoPlayCTAInTier1() {
		return videoPlayCTAInTier1;
	}

	public MobileElement checkVideoResumeCTAInTier1() {
		return videoResumeCTAInTier1;
	}

	public MobileElement checkVBookStackCarouselInTier1() {
		return vBookStackCarouselInTier1;
	}

	public MobileElement checkVBookItemCarouselInTier1() {
		return vBookItemCarouselInTier1;
	}

	public MobileElement checkVBookCardCarouselInTier1() {
		return vBookCardCarouselInTier1;
	}

	public MobileElement checkVideoStackCarouselInTier1() {
		return videoStackCarouselInTier1;
	}

	public MobileElement checkVideoItemCarouselInTier1() {
		return videoItemCarouselInTier1;
	}

	public MobileElement checkVideoCardCarouselInTier1() {
		return videoCardCarouselInTier1;
	}

	public MobileElement checkVideosCategoriesCarouselHeader() {
		for(int i=0;i<8;i++) {
			if(isElementPresent(videoCategoriesCarouselHeader)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		return videoCategoriesCarouselHeader;
	}

	public MobileElement checkVideosFeaturedCarouselHeader() {
		return videoFeaturedCarouselHeader;
	}

	public MobileElement checkVBookFeaturedCarouselHeader() {
		return vBookFeaturedCarouselHeader;
	}

	public MobileElement checkVBookTitleCarouselHeader() {
		return vBookTitleCarouselHeader;
	}

	public MobileElement checkVideosTitleCarouselHeader() {
		return videoTitleCarouselHeader;
	}

	public List<MobileElement> checkVideosCategoriesIcon() {
		return videoCategoriesIcon;
	}

	public MobileElement checkVideosCategoriesName() {
		return videoCategoriesName;
	}

	public MobileElement checkVBookCategoriesCarouselHeader() {
		for(int i=0;i<9;i++) {
			if(isElementPresent(vBookCategoriesCarouselHeader)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		return vBookCategoriesCarouselHeader;
	}

	public List<MobileElement> checkVBookCategoriesIcon() {
		return vBookCategoriesIcon;
	}

	public MobileElement checkVBookCategoriesName() {
		return vBookCategoriesName;
	}

	public MobileElement checkFeaturedCarouselInTier1() {
		return featuredCarouselInTier1;
	}

	public List<MobileElement> checkFeaturedTitlesInTier1() {
		return featuredTitlesInTier1;
	}
	
	public MobileElement checkVideoTitles_Checkedout() {
		return videoTitles_Checkedout;
	}
	
	public Boolean check_Checkout_Success_Toast_Message() {
		boolean checkoutToast = true;
			if(isElementPresent(checkout_success_Toast_Message)) {
				checkoutToast = true;
			}
			else {
				logger.info("Checkout Succes Message");
		}
		return checkoutToast;
	}
	
	public Boolean checkReturn_Toast_Message() {
		boolean returnToast = true;
		if(isElementPresent(return_Toast_Message)) {
			returnToast = true;
		}
		else {
			logger.info("Return Succes Message");
		}
		return returnToast;
	}
	
	public Boolean checkRenew_Toast_Message() {
		boolean renewToast = true;
		if(isElementPresent(renew_Toast_Message)) {
			renewToast = true;
		}
		else {
			logger.info("Return Succes Message");
		}
		return renewToast;
	}
	
	public Boolean checkRemove_Checkout_History() {
		boolean removeToast = true;
		if(isElementPresent(remove_Checkout_History)) {
			removeToast = true;
		}
		else {
			logger.info("Return Succes Message");
		}
		return removeToast;
	}
	
	public MobileElement checkVideoTitles_Checked1() {
		return videoTitles_Checked1;
	}
	
	public MobileElement title_Cover_Image() {
		return title_Cover_Image;
	}
	
	public MobileElement title_Cover_Name() {
		return title_Cover_Name;
	}
	
	public MobileElement title_Author_Name() {
		return title_Author_Name;
	}
	
	public MobileElement checkPrimary_Action() {
		return primary_Action;
	}

	public MobileElement checkCheckout_History_Primary_Action() {
		return remove_title;
	}
	
	public MobileElement checkSecondary_Action1() {
		return secondary_Action1;
	}
	
	public MobileElement checkSecondary_Action2() {
		return secondary_Action2;
	}
	
	public MobileElement checkVideoTitles_Checked2() {
		return videoTitles_Checked2;
	}
	
	public MobileElement checkvBookTitles_Checkedout() {
		return vBookTitles_Checkedout;
	}

	public void clickvBookCategoriesIcon() {
		for(int i=0;i<8;i++) {
			if(isElementPresent(vBookCategoriesIcon.get(0))) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(vBookCategoriesIcon.get(0));
	}

	public void clickVideoCategoriesIcon() {
		ClickOnMobileElement(videoCategoriesIcon.get(0));
	}

	public MobileElement checkvBookCategoriesInTier2() {
		return vBookCategoriesInTier2;
	}

	public MobileElement checkVideoCategoriesInTier2() {
		return videoCategoriesInTier2;
	}
	
	public MobileElement Checkedout_title_available() {
		return checkedout_title_available;
	}

	public MobileElement checkSort_Recently_Checkedout() {
		return sort_Recently_Checkedout;
	}
	
	public MobileElement checkSort_AtoZ_Checkedout() {
		return sort_AtoZ_Checkedout;
	}
	
	public MobileElement checkSort_Ratings_Checkedout() {
		return sort_Ratings_Checkedout;
	}

	public MobileElement checkSort_DueDate_Checkedout() {
		return sort_DueDate_Checkedout;
	}
	
	public void clickadvancedSearch() {
		ClickOnMobileElement(advance_serach_button);
	}
	
	public void clickMenu() {
		ClickOnMobileElement(clickMenu);
	}
	
	public void clickReturn_title() {
		ClickOnMobileElement(return_title);
	}
	
	public void clickRenew_title() {
		ClickOnMobileElement(renew_title);
	}
	
	public void clickRemove_title() {
		ClickOnMobileElement(remove_title);
	}

	public void clickRemovalConfirmationPopup() {
		ClickOnMobileElement(removalConfirmationPopup);
	}
	
	public void clickProfiles() {
		ClickOnMobileElement(clickProfiles);
	}
	
	public void teenprofileSelection() {
		ClickOnMobileElement(teenprofileSelection);
	}

	public void clickKidprofileSelection() {
		ClickOnMobileElement(kidprofileSelection);
	}
	
	public void clickMyShelf() {
		ClickOnMobileElement(myshelf_btn);
	}
	
	public void clickTitle_Image() {
		System.out.println("size : " + title_Image.size());
		ClickOnMobileElement(title_Image.get(0));
	}
	
	public void clickFilter_option() {
		ClickOnMobileElement(filter_option);
	}
	
	public void clickSort_option() {
		ClickOnMobileElement(sort_option);
	}
	
	public void clickSearchIcon_Checkouts() {
		ClickOnMobileElement(searchIcon_Checkouts);
	}	
	
	public void search_Keyword(String keyword) {
		SendKeysOnMobileElement(search_keyword, keyword);
		hideMobileKeyboard();
	}
	
	public void selectCheckout_CTA() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(CheckOut_CTA)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(CheckOut_CTA);
	}
	
	public void clickClose_1stCheckout() {
		ClickOnMobileElement(close_1stCheckout);
	}
	
	public void clickSort_Recently_Checkedout() {
		ClickOnMobileElement(sort_Recently_Checkedout);
	}
	
	public void clickFilter_Videos() {
		ClickOnMobileElement(videos_Filter_option);
	}
	
	public void clickFilter_vBooks() {
		ClickOnMobileElement(vBooks_Filter_option);
	}

	public MobileElement checkvBookTitle() {
		return vBooksTitle;
	}

	public MobileElement checkVideoTitle() {
		return vBooksTitle;
	}
	
	public void clickFilter_All() {
		ClickOnMobileElement(filter_All);
	}
	
	public void clickCheckout_Video() {
		ClickOnMobileElement(checkout_Video);
	}

	public MobileElement verifyCheckout_Video() {
		return checkout_Video;
	}
	
	public void clickVideos_option() {
		ClickOnMobileElement(videos_Filter_option);
	}
	
	public void clickvBook_option() {
		ClickOnMobileElement(vBooks_Filter_option);
	}
	
	public void clickPlay_Video() {
		if(isElementPresent(vBook_action_CTA1)) {
			ClickOnMobileElement(vBook_action_CTA1);
		}
		else {
			ClickOnMobileElement(vBook_action_CTA2);
		}
	}
	
	public void clickBack_Button() {
//		ClickOnMobileElement(backIcon);
//		driver.pressKey(new KeyEvent().withKey(AndroidKey.BACK));
		DriverManager.getDriver().navigate().back();
	}
	
	public void clickCheckout_CTA() {
		if(isElementPresent(CheckOut_CTA)) {
			waitFor(3000);
		ClickOnMobileElement(checkout_CTA);
	}
	}

	public void clickVideoWidgetsSeeAllLinkInMyLibrary() {
		ClickOnMobileElement(videoWidgetsSeeAllLinkInMyLibrary);
	}

	public void clickVideoWidgetsSeeAllLinkInTier1() {
		ClickOnMobileElement(videoWidgetsSeeAllLinkInTier1);
	}

	public void clickVBookWidgetsSeeAllLinkInMyLibrary() {
		for (int i = 0; i < 7; i++) {
			if (isElementPresent(vBookWidgetsSeeAllLinkInMyLibrary)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(vBookWidgetsSeeAllLinkInMyLibrary);
	}

	public void clickVBookWidgetsSeeAllLinkInTier1() {
		ClickOnMobileElement(vBookWidgetsSeeAllLinkInTier1);
	}


	
	public void clickRefineCTA() {
		ClickOnMobileElement(refineCTA);
	}
	
	public MobileElement RefineCTA() {
		return refineCTA;
	}

	public void clickRefine() {
		ClickOnMobileElement(search_Refine_btn);
	}

	public MobileElement videoTier1Heading() {
		return videoTier1Heading;
	}

	public void clickPopularVideosSeeAll() {
		for (int i=0; i<7; i++){
			if (isElementPresent(popularVideosSeeAll)){
				break;
			}else {
				swipeDown();
			}
		}
		ClickOnMobileElement(popularVideosSeeAll);
	}
	public void clickVideosTitle() {
		ClickOnMobileElement(videosTitle);
	}

	public void clickSeeall() {
		ClickOnMobileElement(featuredSeeAll);
	}
	public MobileElement FeaturedSeeAll() {
		return featuredSeeAll;
	}

	public MobileElement tier1Heading() {
		return Tier1Heading;
	}
}
