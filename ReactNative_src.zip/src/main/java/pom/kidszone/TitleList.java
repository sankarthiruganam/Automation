package pom.kidszone;

import java.util.List;

import com.driverfactory.DriverManager;
import io.appium.java_client.MobileBy;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class TitleList extends CommonActions {

//	BoundlessLogo boundless = new BoundlessLogo(DriverManager.getDriver());
//	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
//	LoginPage login = new LoginPage(DriverManager.getDriver());
//	SearchPage search = new SearchPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(Holds.class);

	public TitleList(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "BROWSE")
	@AndroidFindBy(xpath = "//*[@resource-id='BROWSE']")
	public MobileElement log_button_browse;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	public MobileElement browse_header;

	@AndroidFindBy(xpath = "//*[@resource-id='BROWSE_SUBJECT_LIST_TEST_ID']/descendant::android.widget.Button[contains(@content-desc,'On Press Subject')]//android.widget.TextView")
	public List<MobileElement> all_subjects_links;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	public MobileElement subject_title;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	public MobileElement back_btn_subject;

	@AndroidFindBy(xpath = "(//*[@resource-id='SELECTED_REFINE_LIST_TEST_ID']/descendant::android.view.ViewGroup)[1]/child::android.widget.TextView")
	public MobileElement filtered_title;

	@iOSXCUITFindBy(xpath = "Format,Heading, ")
	@AndroidFindBy(xpath = "//*[@resource-id='Format,Heading, ']")
	public MobileElement refiner_option;

	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_1']//android.widget.RadioButton")
	public MobileElement author_radio_btn;

	@iOSXCUITFindBy(accessibility = "SUBJECT_LIST_TEST_ID0")
	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID0']")
	public MobileElement subject_list_1;

	@iOSXCUITFindBy(accessibility = "VIEW_RESULT_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='VIEW_RESULT_BUTTON_TEST_ID']//android.widget.TextView")
	public MobileElement viewresult_btn;

	@iOSXCUITFindBy(accessibility = "CATEGORY_LIST_TEST_ID")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Categories,Heading, \"]")
	public MobileElement categories;

	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID']/descendant::android.view.ViewGroup[contains(@resource-id,'SUBJECT_LIST_TEST_ID')]//android.widget.TextView")
	public List<MobileElement> all_subjects_refiner;

	@iOSXCUITFindBy(accessibility = "SUBJECT_LIST_TEST_ID0")
	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID0']")
	public MobileElement selected_subject;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	public MobileElement btn_Back;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'Browse By Subject,Heading')]")
	public MobileElement browsebysubject_heading;

	@iOSXCUITFindBy(accessibility = "CANCEL_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='CANCEL_BUTTON_TEST_ID']")
	public MobileElement cancel_button_refiner;

	@iOSXCUITFindBy(accessibility = "MYLIBRARY")
	@AndroidFindBy(xpath = "//*[@resource-id='MYLIBRARY']")
	public MobileElement click_FooterLibrary;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[2]")
	public MobileElement click_TitleCard2;

	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[@text='Checkout']")
	public MobileElement click_Checkout1;

	@iOSXCUITFindBy(accessibility = "BROWSE")
	@AndroidFindBy(xpath = "//*[@resource-id='BROWSE']")
	private MobileElement Browse_btn;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"BROWSE_SUBJECT_LIST_ITEM_TEST_ID\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='BROWSE_SUBJECT_LIST_ITEM_TEST_ID'])[1]")
	public MobileElement YoungAdult_fiction_level1_btn;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"BROWSE_SUBJECT_LIST_ITEM_TEST_ID\"])[2]")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement YoungAdult_Nonfiction_level2_btn;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"TITLE_LIST_ITEM\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='TITLE_LIST_ITEM'])[1]")
	private MobileElement YoungAdult_fiction_title;

	@iOSXCUITFindBy(accessibility = "See Young Adult Fiction ")
	@AndroidFindBy(xpath = "(//*[@resource-id='TITLE_LIST_ITEM'])[1]")
	private MobileElement YoungAdult_fiction_level2_lbl;

	@iOSXCUITFindBy(xpath = "(//*[@name='CURATED_LIST_LINK'])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='CURATED_LIST_LINK'])[1]")
	private MobileElement seeAll_carousel;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"CURATED_LIST_CONTAINER\"]")
	@AndroidFindBy(xpath = "//*[@resource-id =\"CURATED_LIST_CONTAINER\"]")
	private MobileElement carouselTitles;

	@iOSXCUITFindBy(xpath = "SORT_LIST_TOGGLE")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_TOGGLE']")
	private MobileElement refineExpand;

	@iOSXCUITFindBy(accessibility = "BROWSE_SUBJECT_LIST_ITEM_TEST_ID")
	@AndroidFindBy(xpath = "(//*[@resource-id='BROWSE_SUBJECT_LIST_ITEM_TEST_ID'])[1]")
	private MobileElement Friction_level1_btn;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='TITLE_LIST_FLATLIST']//*[contains(@resource-id,'TITLE_LIST_ITEM')]")
	private List<MobileElement> Friction_level2_list;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "(//*[@resource-id='TITLE_LIST_ITEM']//*[contains(@resource-id,'recommendedTitle')])[1]")
	private MobileElement Friction_level2_btn;

	@iOSXCUITFindBy(accessibility = "REFINE_ICON")
	@AndroidFindBy(xpath = "//*[@resource-id='REFINE_ICON']")
	private MobileElement RefineIcon_btn;
	@iOSXCUITFindBy(accessibility = "SEARCH_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='SEARCH_BUTTON_TEST_ID']")
	private MobileElement search_btn;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_0")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_0']")
	private MobileElement AddedDate_btn;

	@iOSXCUITFindBy(accessibility = "COLLECTION_LIST_0")
	@AndroidFindBy(xpath = "//*[@resource-id='COLLECTION_LIST_0']")
	public MobileElement General_btn;

	@iOSXCUITFindBy(accessibility = "Young Adult Fiction")
	@AndroidFindBy(xpath = "//*[@text='Young Adult Fiction']")
	private MobileElement Friction_level1_page;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_0")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_0']")
	private MobileElement SortOption;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_3")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_3']")
	private MobileElement PublicationDate;

	@iOSXCUITFindBy(accessibility = "VIEW_RESULT_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='VIEW_RESULT_BUTTON_TEST_ID']")
	public MobileElement ViewResult;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_TOGGLE")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_TOGGLE']")
	private MobileElement SortByCollapse;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_TOGGLE")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_TOGGLE']")
	private MobileElement SortByExpand;

	@iOSXCUITFindBy(accessibility = "recommendedTitle0012462039TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='recommendedTitle0012462039TestId']")
	private MobileElement CuratedListBook;

	@iOSXCUITFindBy(accessibility = "CATEGORYLIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='CATEGORYLIST_TOGGLE_outer']")
	private MobileElement FeaturedCategories;

	@iOSXCUITFindBy(accessibility = "TOP 20")
	@AndroidFindBy(xpath = "//*[@text='TOP 20']")
	private MobileElement Top20;

	@iOSXCUITFindBy(accessibility = "Young Adult Fiction")
	@AndroidFindBy(xpath = "//*[@text='Young Adult Fiction']")
	private MobileElement Level2_page;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement BrowsePage;

	@iOSXCUITFindBy(accessibility = "SORT_LIST0")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST0']")
	private MobileElement AddedDate;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"General Purchase Request\"]/XCUIElementTypeOther[@name=\"COLLECTION_LIST_1\"]")
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@content-desc=\"Purchase Request, \"]")
	public MobileElement PurchaseRequest;

	@iOSXCUITFindBy(accessibility = "CATEGORYLIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Categories,Heading, \"]")
	private MobileElement CategoriesPage;

	@iOSXCUITFindBy(accessibility = "SUBJECTLIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Browse By Subject,Heading, \"]")
	private MobileElement RefinePage;

	@iOSXCUITFindBy(accessibility = "SUBJECT_LIST_TEST_ID0")
	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID0']")
	private MobileElement TittleList;

	@iOSXCUITFindBy(xpath = "(//*[@name='SUBJECT_LIST_TEST_ID0'])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID0']")
	private MobileElement fiction;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//*[@text='Sort By']")
	private MobileElement SortBy;

	@iOSXCUITFindBy(accessibility = "SUBJECT_LIST_TEST_ID0")
	@AndroidFindBy(xpath = "//*[@resource-id='SUBJECT_LIST_TEST_ID0']")
	private MobileElement CuratedList;

	@iOSXCUITFindBy(accessibility = "RESULT_COUNT_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='RESULT_COUNT_TEST_ID']")
	private MobileElement CuratedListEnabled;

	@iOSXCUITFindBy(accessibility = "CANCEL_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='CANCEL_BUTTON_TEST_ID']")
	private MobileElement Cancelbtn;

	@iOSXCUITFindBy(accessibility = "loc_btnShare")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnShare']")
	private MobileElement title_share_btn;

	@iOSXCUITFindBy(accessibility = "header_title")
	@AndroidFindBy(xpath = "//*[@resource-id='header_title']")
	private MobileElement alwaysAvilable_hdr;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"TITLE_LIST_ITEM\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='TITLE_LIST_ITEM'])[1]")
	private MobileElement title_list_level2;

	@iOSXCUITFindBy(accessibility = "REFINE_ICON")
	@AndroidFindBy(xpath = "//*[@resource-id='REFINE_ICON']")
	private MobileElement selected_refine_list;

	@iOSXCUITFindBy(accessibility = "CATEGORYLIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='CATEGORYLIST_TOGGLE_outer']")
	private MobileElement categoryList_toggle;

	@iOSXCUITFindBy(accessibility = "Reset,")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'RESET_BUTTON_TEST_ID')]")
	private MobileElement reset;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	private MobileElement view_Popup;

	@iOSXCUITFindBy(accessibility = "header_title")
	@AndroidFindBy(xpath = "//*[@resource-id='header_title']")
	private MobileElement view_AlwayAvailable;

	@iOSXCUITFindBy(accessibility = "header_title")
	@AndroidFindBy(xpath = "//*[@resource-id='header_title']")
	private MobileElement FeaturedContent;

	@iOSXCUITFindBy(accessibility = "header_title")
	@AndroidFindBy(xpath = "//*[@resource-id='header_title']")
	private MobileElement downloadButton;

	@iOSXCUITFindBy(accessibility = "btnAddToWishList")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAddToWishList']")
	private MobileElement addtoWishlist;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement back_Btn;

	@iOSXCUITFindBy(accessibility = "Sign_out_Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Sign_out_Menu']")
	private MobileElement click_Signout;

	@iOSXCUITFindBy(accessibility = "SIGNOUT_YES")
	@AndroidFindBy(xpath = "//*[@resource-id='SIGNOUT_YES']")
	private MobileElement click_SignoutYes;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement click_FooterMyShelf;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement click_FooterMenu;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header']")
	private MobileElement magazineNewspaper;

	@iOSXCUITFindBy(accessibility = "third_party_see_all_link")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link']")
	private MobileElement magazineSeeAll;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id='third_party_header']")
	private MobileElement listPageTier1;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement newspaperSeeAll;

	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.widget.TextView")
	private MobileElement thirdPartyDesc;

	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView")
	@AndroidFindBy(xpath = "//*[@text='Old Cars']")
	private MobileElement thirdPartyTitle;

	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.widget.Button/android.widget.ImageView")
	private MobileElement thirdPartyImage;

	@iOSXCUITFindBy(accessibility = "Download")
	@AndroidFindBy(xpath = "(//*[@resource-id='loc_btnDownload'])[1]")
	private MobileElement thirdPartyDownloadCTA;

	@iOSXCUITFindBy(accessibility = "Read Now")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Read Now\"]")
	private MobileElement thirdPartyReadNowCTA;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement clickNewspaper;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement continue_Btn;

	@iOSXCUITFindBy(accessibility = "Publication Date")
	@AndroidFindBy(xpath = "//*[@resource-id='Publication Date']")
	private MobileElement publicationDate_refine;

	@iOSXCUITFindBy(accessibility = "RESULT_COUNT_TEST_ID")
	@AndroidFindBy(xpath = "//*[@resource-id='RESULT_COUNT_TEST_ID']")
	private MobileElement result_count;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"TITLE_LIST_ITEM\"])")
	@AndroidFindBy(xpath = "//*[@resource-id='(//XCUIElementTypeButton[@name=\"TITLE_LIST_ITEM\"])']")
	private List<MobileElement> booktiltles;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"search_advance_search_page_theme_id\"]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"search_advance_search_page_theme_id\"]/android.widget.TextView")
	private MobileElement advancedSearchResults;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"CURATED_LIST_HEADER_TITLE\"])[3]")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"see Teen Only heading, \"]/android.widget.TextView")
	private MobileElement teenTitle;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"txtRecommendationInterestHeader\"]")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"see BASED ON YOUR INTERESTS heading, \"]/android.widget.TextView")
	private MobileElement clickMyShelfTitle;

	@iOSXCUITFindBy(accessibility = "COLLECTION_LIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Collections, collapsed, \"]")
	public MobileElement collectionsListExpandButton;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"CLEAR_BUTTON_TEST_ID\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Clear, \"]")
	public MobileElement clearButton;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"CURATED_LIST_CONTAINER\"])[1]/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"]")
	public MobileElement eBooktitle;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentAGERANGETestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"detailsContentAGERANGETestId\"]")
	public MobileElement ageRangeInTitleDetils;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Place Hold')]")
	@AndroidFindBy(xpath = "(//*[@text='Place Hold'])[1]")
	public MobileElement placeHoldCTA;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentAGERANGETestId\"]")
	@AndroidFindBy(xpath = "/android.view.ViewGroup[@content-desc=\"See Place Hold CTA, \"]")
	public MobileElement placeHoldPopup;

	@iOSXCUITFindBy(accessibility = "loc_btnDetailsTab")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_btnDetailsTab, \"]")
	public MobileElement titleDetilsSection;

	@iOSXCUITFindBy(accessibility = "Download")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Download']")
	public MobileElement NewsPaperDownloadCTA;

	@iOSXCUITFindBy(accessibility = "title_details_page_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id=\"title_details_page_test_id\"]")
	public MobileElement titleDetils;

	@AndroidFindBy(xpath = "//*[@text='NEWSPAPERS & MAGAZINES']")
	public MobileElement textSwipe;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'E book')]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]")
	private MobileElement titleitemselection;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
	private MobileElement searchResultScreenItem;

	@iOSXCUITFindBy(accessibility = "SELECTED_REFINE_LIST_TEST_ID")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='SELECTED_REFINE_LIST_TEST_ID']")
	public MobileElement selectedRefinerList;

	@iOSXCUITFindBy(accessibility = "SORT_LIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_TOGGLE_outer']")
	public MobileElement sortTitleList;

	@iOSXCUITFindBy(accessibility = "AVAILABLITY_LIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='AVAILABLITY_LIST_TOGGLE_outer']")
	public MobileElement availableTitleList;

	@iOSXCUITFindBy(accessibility = "COLLECTION_LIST_TOGGLE_outer")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Collections, collapsed, \"])[1]")
	public MobileElement collectionsTitleList;

	@iOSXCUITFindBy(accessibility = "checkout_title_test_id0")
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"checkout_title_test_id0\"])[1]")
	public MobileElement titleNAME;

	@iOSXCUITFindBy(accessibility = "RESULT_COUNT_TEST_ID")
	@AndroidFindBy(xpath="//*[@resource-id='RESULT_COUNT_TEST_ID']")
	private MobileElement result_Count;

	public MobileElement getResult_Count()
	{
		return result_Count;
	}

	public MobileElement getSortTitleList() {
		return sortTitleList;
	}

	public MobileElement getAvailableTitleList() {
		return availableTitleList;
	}

	public MobileElement getCollectionsTitleList() {
		return collectionsTitleList;
	}

	public MobileElement getCategories() {
		return categories;
	}

	public MobileElement getResult_count() {
		return result_count;
	}

	public MobileElement getClear_all() {
		return reset;
	}

	public MobileElement getViewPopup() {
		return view_Popup;
	}

	public MobileElement getAlwayAvailable() {
		return view_AlwayAvailable;
	}

	public MobileElement getFeaturedContent() {
		return FeaturedContent;
	}

	public MobileElement getDownloadButton() {
		return downloadButton;
	}

	public MobileElement getAddtoWishlist() {
		return addtoWishlist;
	}

	public MobileElement getSubject_list_1() {
		return subject_list_1;
	}

	public MobileElement getCategoryList_toggle() {
		return categoryList_toggle;
	}

	public MobileElement getSelected_refine_list() {
		return selected_refine_list;
	}

	public MobileElement getTitle_list_level2() {
		return title_list_level2;
	}

	public MobileElement getAlwaysAvilable_hdr() {
		return alwaysAvilable_hdr;
	}

	public MobileElement getSeeAll_carousel() {
		return seeAll_carousel;
	}

	public MobileElement checkcarousel() {
		return carouselTitles;
	}

	public MobileElement getTitle_share_btn() {
		return title_share_btn;
	}

	public MobileElement getYoungAdult_fiction_title() {
		return YoungAdult_fiction_title;
	}

	public MobileElement getYoungAdult_fiction_level2_lbl() {
		return YoungAdult_fiction_level2_lbl;
	}

	public MobileElement getYoungAdult_fiction_level1_btn() {
		return YoungAdult_fiction_level1_btn;
	}

	public MobileElement getYoungAdult_Nonfiction_level2_btn() {
		return YoungAdult_Nonfiction_level2_btn;
	}

	public MobileElement getCancelbtn() {
		return Cancelbtn;
	}

	public MobileElement getFriction_level1_btn() {
		return Friction_level1_btn;
	}

	public MobileElement getBrowse_btn() {
		return Browse_btn;
	}

	public List<MobileElement> getFriction_level2_list() {
		return Friction_level2_list;
	}

	public MobileElement getFriction_level2_btn() {
		return Friction_level2_btn;
	}

	public MobileElement getRefineIcon_btn() {
		return RefineIcon_btn;
	}

	public MobileElement getFriction_level1_page() {
		return Friction_level1_page;
	}

	public MobileElement getFeaturedCategories() {
		return FeaturedCategories;
	}

	public MobileElement getTop20() {
		return Top20;
	}

	public MobileElement getTitleLevel2() {
		return YoungAdult_fiction_title;
	}

	public MobileElement getBrowsePage() {
		return BrowsePage;
	}

	public MobileElement getAddedDate() {
		return AddedDate;
	}

	public MobileElement getThirdPartyDesc() {
		return thirdPartyDesc;
	}

	public MobileElement getClear() {
		return AddedDate;
	}

	public MobileElement getPurchaseRequest() {
		return PurchaseRequest;
	}

	public MobileElement getCategoriesPage() {
		return CategoriesPage;
	}

	public MobileElement getRefinePage() {
		return RefinePage;
	}

	public MobileElement getTittleList() {
		return TittleList;
	}

	public MobileElement getSortBy() {
		return SortBy;
	}

	public MobileElement getCuratedList() {
		return CuratedList;
	}

	public MobileElement getCuratedListEnabled() {
		return CuratedListEnabled;
	}

	public MobileElement getadvancedSearchResults() {
		return advancedSearchResults;
	}

	public MobileElement getLevel2() {
		return YoungAdult_fiction_level1_btn;
	}

	public MobileElement getMagazineNewspaper() {
		return magazineNewspaper;
	}

	public MobileElement getNewsPaperDownloadCTA() {
		return NewsPaperDownloadCTA;
	}

	public MobileElement getMagazineSeeAll() {
		return magazineSeeAll;
	}

	public MobileElement getlistPageTier1() {
		return listPageTier1;
	}

	public MobileElement getThirdPartyTitle() {
		return thirdPartyTitle;
	}

	public MobileElement getThirdPartyImage() {
		return thirdPartyImage;
	}

	public MobileElement getThirdPartyDownloadCTA() {
		return thirdPartyDownloadCTA;
	}

	public MobileElement getthirdPartyReadNowCTA() {
		return thirdPartyReadNowCTA;
	}

	// ===================================== Action methods
	// =====================================================

	public void clickAddedDate() {
		if (isElementPresent(AddedDate)) {
			ClickOnMobileElement(AddedDate);
		}
	}

	public void clickCancelbtn() {
		if (isElementPresent(Cancelbtn)) {
			ClickOnMobileElement(Cancelbtn);
		}
	}

	public void clickBrowse_btn() {
		if (isElementPresent(Browse_btn)) {
			ClickOnMobileElement(Browse_btn);
		}
	}

	public void reset() {
		if (isElementPresent(reset)) {
			ClickOnMobileElement(reset);
		}
	}

	public void searchResult()
	{
		if(isElementPresent(search_btn))
		{
			ClickOnMobileElement(search_btn);
		}
	}

	public void clickFriction_level2_btn() {
		if (isElementPresent(Friction_level2_btn)) {
			ClickOnMobileElement(Friction_level2_btn);
		}
	}

	public void clickFriction_level1_btn() {
		if (isElementPresent(Friction_level1_btn)) {
			ClickOnMobileElement(Friction_level1_btn);
		}
	}

	public void clickRefineIcon_btn() {
		if (isElementPresent(RefineIcon_btn)) {
			ClickOnMobileElement(RefineIcon_btn);
		}
	}

	public void clickCategory()
	{
		if(isElementPresent(fiction))
		{
			ClickOnMobileElement(fiction);
		}
	}

	public void clickColletionsExpandButton() {
		if (isElementPresent(collectionsListExpandButton)) {
			ClickOnMobileElement(collectionsListExpandButton);
		}
	}

	public void clickGeneral() {
		if (isElementPresent(General_btn)) {
			ClickOnMobileElement(General_btn);
		}
	}

	public void selectSortOption() {
		if (isElementPresent(SortOption)) {
			ClickOnMobileElement(SortOption);
		}
	}

	public void selectPublicationDate() {
		if (isElementPresent(PublicationDate)) {
			ClickOnMobileElement(PublicationDate);
		}
	}

	public void clickViewResult() {
		if (isElementPresent(ViewResult)) {
			ClickOnMobileElement(ViewResult);
		}
	}

	public void collapseSortBy() {
		if (isElementPresent(SortByCollapse)) {
			ClickOnMobileElement(SortByCollapse);
		}
	}

	public void expandSortBy() {
		if (isElementPresent(SortByExpand)) {
			ClickOnMobileElement(SortByExpand);
		}
	}

	public void clickCuratedList() {
		if (isElementPresent(CuratedListBook)) {
			ClickOnMobileElement(CuratedListBook);
		}
	}

	public void navigatetoYoungAdult_Fictionlevel1() {
		ClickOnMobileElement(YoungAdult_fiction_level1_btn);

	}

	public void navigatetoLevel2() {
		if (isElementPresent(YoungAdult_fiction_title)) {
			ClickOnMobileElement(YoungAdult_fiction_title);
		}
	}

	public void click_seeAllCarousel() {
		for (int i = 0; i < 15; i++) {
			if (isElementPresent(seeAll_carousel)) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(seeAll_carousel);
	}

	public void click_refineExpand() {
		if (isElementPresent(refineExpand)) {
			ClickOnMobileElement(refineExpand);
		}
	}

	public void collapseCategory() {
		if (isElementPresent(categoryList_toggle)) {
			ClickOnMobileElement(categoryList_toggle);
		}

	}

	public void removeDate() {
		if (isElementPresent(publicationDate_refine)) {

			ClickOnMobileElement(publicationDate_refine);
		}
	}

	public boolean clickFooterBrowse() {
		boolean match = false;
		try {
			if (isElementPresent(log_button_browse)) {
				ClickOnMobileElement(log_button_browse);
				match = true;
				logger.info("User clicked the browse button");
			}
		} catch (Exception e) {
			logger.info("Error while clicking the browse button : " + e.getMessage());
			match = false;
		}

		return match;

	}

	public void navigateLevel3Bookdetails() {
		if (isElementPresent(booktiltles.get(0))) {
			ClickOnMobileElement(booktiltles.get(0));
//			for (int i = 0; i < booktiltles.size(); i++) {
//				ClickOnMobileElement(booktiltles.get(i));
//				i = 2;
//				break;
//			}
		}
	}

	public boolean verifyBrowseHeader() {
		boolean match = false;
		waitFor(500);
		try {
			if (isElementPresent(browse_header)) {
				match = true;
				logger.info("User Verified the browse header");
			}
		} catch (Exception e) {
			logger.info("Error while verifing the browse header : " + e.getMessage());
			match = false;
		}

		return match;

	}

	public boolean selectSubject() {
		boolean match = false;
		try {
			waitFor(100);
			for (MobileElement mobileElement : all_subjects_links) {
				if (isElementPresent(mobileElement)) {
					logger.info("User cilcked the subject");
					ClickOnMobileElement(mobileElement);
					match = true;
				}
				break;
			}
		} catch (Exception e) {
			logger.info("Error while select the leval 1 subject : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public boolean verifySelectedSubject() {
		boolean match = false;
		waitFor(500);
		try {
			if (isElementPresent(selected_subject)) {
				match = true;

			}

		} catch (Exception e) {
			logger.info("Error while verifing subject title : " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean clickRefiner() {
		boolean match = false;
		try {
			if (isElementPresent(refiner_option)) {
				ClickOnMobileElement(refiner_option);
				logger.info("User clicked the refiner option");

				match = true;
			}

		} catch (Exception e) {
			logger.info("Error while clicking the refiner option : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public String verifySubjectsRefiner() {
		String selectedlevel1subject = null;
		try {
			for (MobileElement mobileElement : all_subjects_refiner) {
				if (isElementPresent(mobileElement)) {
					String subjectname = mobileElement.getText();
					logger.info("User selected the subject" + subjectname);
					selectedlevel1subject = subjectname;
				}
				break;
			}
		} catch (Exception e) {
			logger.info("Error while select the leval 1 subject : " + e.getMessage());
		}

		return selectedlevel1subject;
	}

	public boolean clickSubjectsinRefiner() {
		boolean match = false;
		try {
			for (MobileElement mobileElement : all_subjects_refiner) {
				if (isElementPresent(mobileElement)) {
					ClickOnMobileElement(mobileElement);
					logger.info("User clicked the subject");
					match = true;
				}
				break;
			}
		} catch (Exception e) {
			logger.info("Error while select the subject : " + e.getMessage());
			match = false;
		}

		return match;

	}

	public boolean clickAutorinSortBy() {
		boolean match = false;
		try {
			if (isElementPresent(author_radio_btn)) {
				ClickOnMobileElement(author_radio_btn);
				logger.info("User clicked the Author check box");
				match = true;
			}

		} catch (Exception e) {
			logger.info("Error while clicking author check box : " + e.getMessage());
			match = false;
		}
		return match;

	}

	public void cancelRefine() {
		if (isElementPresent(cancel_button_refiner)) {
			ClickOnMobileElement(cancel_button_refiner);
		}
	}

	public boolean verifyRefinerBackButton() {
		boolean match = false;
		try {
			if (isElementPresent(cancel_button_refiner)) {
				logger.info("Verified the cancel button");
				match = true;
			}

		} catch (Exception e) {
			logger.info("Error while verifing cancel button  : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public boolean clickViewResults() {
		boolean match = false;
		try {
			waitFor(500);
			do {
				swipeDown();
			} while (!(isElementPresent(viewresult_btn)));

			if (isElementPresent(viewresult_btn)) {
				ClickOnMobileElement(viewresult_btn);
				logger.info("User clicked the View Result button");
				match = true;
			}

		} catch (Exception e) {
			logger.info("Error while clicking view results button : " + e.getMessage());
			match = false;
		}
		return match;

	}

	public boolean verifyHeader() {
		boolean match = false;
		try {
			if (isElementPresent(selected_subject)) {
				match = true;
				logger.info("User verified the header");
			}

		} catch (Exception e) {
			logger.info("Error while verifing header : " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifyCategories() {
		boolean match = false;
		try {
			if (isElementPresent(categories)) {
				match = true;
				logger.info("User verified the categories");
			}

		} catch (Exception e) {
			logger.info("Error while verifing categories : " + e.getMessage());
			match = false;
		}
		return match;

	}

	public boolean verifyRefinerButton() {
		boolean match = false;
		try {
			if (isElementPresent(RefineIcon_btn)) {
				match = true;
				logger.info("User verified the refiner button");
			}
		} catch (Exception e) {
			logger.info("Error while verifing refiner button  : " + e.getMessage());
		}
		return match;
	}

	public String filteredTitle() {
		String title = null;
		try {
			if (isElementPresent(filtered_title)) {
				String text = filtered_title.getText();
				title = text;
				logger.info("user filterd by " + text);
			}
		} catch (Exception e) {
			logger.info("Error while filtered title  : " + e.getMessage());
		}

		return title;
	}

	public boolean clicktheSubject() {
		boolean match = false;
		try {
			if (isElementPresent(subject_list_1)) {
				ClickOnMobileElement(subject_list_1);
				match = true;
				logger.info("User subject one");
			}
		} catch (Exception e) {
			logger.info("Error while clicking subject   : " + e.getMessage());
		}
		return match;
	}

	public void scrollToElement(MobileElement element) {

		((JavascriptExecutor) DriverManager.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public boolean clickBacktoMenu() {
		boolean match;
		try {
			if (isElementPresent(btn_Back)) {
				ClickOnMobileElement(btn_Back);
				logger.info("Clicked Back to menu button");
			}
			match = true;
		} catch (Exception e) {
			logger.info("Error while Back to menu button " + e.getMessage());
			match = false;
		}
		return match;

	}

	public boolean verifyFilteredTitle() {
		boolean match = false;
		try {
			if (isElementPresent(filtered_title)) {
				match = true;
				logger.info("user able to view filterd options");
			}
		} catch (Exception e) {
			logger.info("Error verifing the filtered options  : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public boolean verifyBrowseBySubject() {
		boolean match = false;
		try {
			if (isElementPresent(browsebysubject_heading)) {
				match = true;
				logger.info("uverified the browse by subject");
			}
		} catch (Exception e) {
			logger.info("Error verifing the browse by subject : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public boolean verifytheListedSubject() {
		boolean match = false;
		try {
			if (isElementPresent(subject_list_1)) {
				match = true;
				logger.info("verified the listed subject");
			}
		} catch (Exception e) {
			logger.info("Error verifing the browse by subject : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public void clickFooterLibrary() {
		if (isElementPresent(click_FooterLibrary)) {
			ClickOnMobileElement(click_FooterLibrary);
		}
	}

	public void clickTitleCard() {
		if (isElementPresent(click_TitleCard2)) {
			ClickOnMobileElement(click_TitleCard2);
		}
	}

	public void clickCheckout() {
		waitFor(1000);
		swipeDown();
		for (int i=0;i<3;i++){
			if (isElementPresent(click_Checkout1)) {
				ClickOnMobileElement(click_Checkout1);
				break;
			}else {
				swipeDown();
			}
		}

	}

	public void clickAddtoWishlist() {
		if (isElementPresent(addtoWishlist)) {
			ClickOnMobileElement(addtoWishlist);
		}
	}

	public void clickBack() {
		if (isElementPresent(back_Btn)) {
			ClickOnMobileElement(back_Btn);
		}
	}

	public void clickFooterMenu() {
		if (isElementPresent(click_FooterMenu)) {
			ClickOnMobileElement(click_FooterMenu);
		}
	}

	public void clickMagazineNewspaper() {
		if (isElementPresent(magazineNewspaper)) {
			ClickOnMobileElement(magazineNewspaper);
		}
	}

	public void clickMagazineSeeAll() {
		if (isElementPresent(magazineSeeAll)) {
			ClickOnMobileElement(magazineSeeAll);
		}
	}

//	public void clickNewspaperSeeAll() {
//		if (isElementPresent(newspaperSeeAll)) {
//			ClickOnMobileElement(newspaperSeeAll);
//		}
//	}

	public void clickNewspaper() {
		if (isElementPresent(clickNewspaper)) {
			ClickOnMobileElement(clickNewspaper);
		}
	}

	public void clickContinue_Btn() {
		if (isElementPresent(continue_Btn)) {
			ClickOnMobileElement(continue_Btn);
		}
	}

	public void clickSignout() {
		if (isElementPresent(click_Signout)) {
			ClickOnMobileElement(click_Signout);
		}
	}

	public void clickSignoutYes() {
		if (isElementPresent(click_SignoutYes)) {
			ClickOnMobileElement(click_SignoutYes);
		}
	}

	public void clickFooterMyShelf() {
		if (isElementPresent(click_FooterMyShelf)) {
			ClickOnMobileElement(click_FooterMyShelf);
		}
	}

	public Boolean getTeenTitle() {

		Boolean la = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().textContains(\"TEEN ONLY\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Teen Title is displayed in adult profile");
			} else {
				la = false;
				logger.info("Teen Title is not displayed in adult profile");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			swipeDown();
			waitFor(10000);
			if (isElementPresent(teenTitle))
				ClickOnMobileElement(teenTitle);
		} else {
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(teenTitle);
		}

		return la;
	}

	public void myshelftitle() {
		if (isElementPresent(clickMyShelfTitle)) {
			ClickOnMobileElement(clickMyShelfTitle);
		}
	}

	public void titleDetails() {
		if (isElementPresent(titleDetilsSection)) {
			ClickOnMobileElement(titleDetilsSection);
		}
	}

	public void selectEBookTitle() {

		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().textContains(\"CHILDREN\"))"));
			if (isElementPresent(eBooktitle)) {
				ClickOnMobileElement(eBooktitle);
			}
		} else {
			swipeDown();
			swipeDown();
			waitFor(10000);
			if (isElementPresent(eBooktitle)) {
				ClickOnMobileElement(eBooktitle);
			}
		}
	}

	public void clickPlaceHoldCTA() {
		if (isElementPresent(placeHoldCTA)) {
			ClickOnMobileElement(placeHoldCTA);
		}
	}

	public void placeHoldAlertPopup() {
		if (isElementPresent(placeHoldPopup)) {
			ClickOnMobileElement(placeHoldPopup);
		}
	}

	public void clicktitleitem() {
		if (isElementPresent(searchResultScreenItem)) {
			ClickOnMobileElement(searchResultScreenItem);
		}
	}

	public void clickNewsPaperSeeAllLink() {

		if (isElementPresent(magazineNewspaper)) {
			ClickOnMobileElement(magazineSeeAll);
		}
	}

	public void clickTitleImage() {

		if (isElementPresent(thirdPartyImage)) {
			ClickOnMobileElement(thirdPartyImage);
		}
	}

	public void clickTitleDownloadCTA() {

		if (isElementPresent(thirdPartyDownloadCTA)) {
			ClickOnMobileElement(thirdPartyDownloadCTA);
			waitFor(8000);
		}
	}

	public void verifyRefinerSelectedList() {

		if (isElementPresent(selectedRefinerList)) {
			ClickOnMobileElement(selectedRefinerList);
		}
	}

//	public void searchTitleinTeen() {
//		String titleName = titleNAME.getText();
//		waitFor(2000);
//		clickCancelbtn();
//		boundless.clickProfiles();
//		boundless.verifyProfilesHeader();
//		waitFor(3000);
//		manage.teenprofileSelection();
//		login.handleNothankspopup();
//		waitFor(3000);
//		search.advanceSearch(titleName);
//	}

}
