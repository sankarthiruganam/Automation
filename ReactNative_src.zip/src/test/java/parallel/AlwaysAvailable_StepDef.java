package parallel;

import java.util.Iterator;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.ProfileCreation;

public class AlwaysAvailable_StepDef extends CommonActions{

	LoginPage login = new LoginPage(DriverManager.getDriver());
	AboutandLegel about= new AboutandLegel(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MenuList menu =new MenuList(DriverManager.getDriver());
	ManageProfile manage= new ManageProfile(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	/************************** 124466***************************/
	
	@And("user clicks about button")
    public void user_clicks_about_button() throws Throwable {
		login.clickFooterMenu();
		about.clickAboutus();
    }

    @And("user should be navigated to and view updated about screen and content")
    public void user_should_be_navigated_to_and_view_updated_about_screen_and_content() throws Throwable {
    	Assert.assertEquals(about.getAbt_txt_abouthdr().isDisplayed(), true);
    }

    @And("user should be able to view Release number")
    public void user_should_be_able_to_view_release_number() throws Throwable {
    	Assert.assertEquals(about.getAbt_txt_releaseno().isDisplayed(), true);
    }

    @And("user should be able to view the Build number")
    public void user_should_be_able_to_view_the_build_number() throws Throwable {
    	Assert.assertEquals(about.getAbt_txt_buildno().isDisplayed(), true);
    }

    @And("user should be able to view audio Engine and Reader versions for the application")
    public void user_should_be_able_to_view_audio_engine_and_reader_versions_for_the_application() throws Throwable {
    	for (int i = 0; i < 10; i++) {
        	swipeDown();
		}
    	swipeDown();
    	Assert.assertEquals(about.getAbt_txt_autoengine().isDisplayed(), true);
    	Assert.assertEquals(about.getAbt_txt_readerversion().isDisplayed(), true);
    }
    
    @And("user should be able to click on close cta and navigate back to the last screen")
    public void user_should_be_able_to_click_on_close_cta_and_navigate_back_to_the_last_screen() throws Throwable {
    	for (int i = 0; i < 19; i++) {
    		swipeUp();
		}
    	swipeUp();
    	about.clickbackbutton();
    //	Assert.assertEquals(menu.getMenu_txt_termsandconditions().isDisplayed(), true);
    	
    }
    @Given("user is in the about screen")
    public void user_is_in_the_about_screen() throws Throwable {
    	login.handleNothankspopup();
    	Assert.assertEquals(about.aboutScreenNavCheck(), true);
    }

    @When("user scroll down to the botton of the page")
    public void user_scroll_down_to_the_botton_of_the_page() throws Throwable {
    	for (int i = 0; i < 10; i++) {
        	swipeDown();
		}
    }

    @Then("user should be able to view the scroll up button to scroll up to the top of the page")
    public void user_should_be_able_to_view_the_scroll_up_button_to_scroll_up_to_the_top_of_the_page() throws Throwable {
    	for (int i = 0; i < 10; i++) {
    		swipeUp();
		}
    }
    
    @And("user click {string} profile")
    public void user_click_something_profile(String profileType) throws Throwable {
    	manage.teenprofileSelection();
    }
    
    @And("user click menu option")
    public void user_click_menu_option() throws Throwable {
    	login.clickFooterMenu();
    }

    @And("user click about option")
    public void user_click_about_option() throws Throwable {
    	menu.clickonAbout(); 	
    }
    
    @When("user clicks on terms and conditions")
    public void user_clicks_on_terms_and_conditions() throws Throwable {
//    	menu.clicklegal();
    	menu.clicktermsand_conditionss();
    }
    	
    @Then("user should be navigated to and view updated terms and conditions screen and content")
    public void user_should_be_navigated_to_and_view_updated_terms_and_conditions_screen_and_content() throws Throwable {
    	if(System.getProperty("platform").equalsIgnoreCase("iOS")) {
    		Assert.assertEquals(menu.termsAndConditionPgNavCheck(), true);
    		logger.info("Inside of Terms and condition");
    	}else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
    		Assert.assertEquals(menu.termsAndConditionPgNavCheck(), true);
    	}
    }

    @And("user is on menu page")
    public void user_is_on_menu_page() throws Throwable {
//    	Assert.assertEquals(login.getLogo_btn_menu().isDisplayed(), true);
    	login.clickFooterMenu();
    }
    
    @And("user click on privacy policy")
    public void user_click_on_privacy_policy() throws Throwable {
    	if(System.getProperty("platform").equalsIgnoreCase("iOS")) {
    		menu.clicklegal();
    		menu.clickprivacypolicy();
    	}else if(System.getProperty("platform").equalsIgnoreCase("Android")) {
    		menu.clickonPrivacy();
    		Assert.assertEquals(menu.privacyPgNavCheck(), true);
    	}
    }

    @And("user should be navigated to and view updated privacy policy screen and content")
    public void user_should_be_navigated_to_and_view_updated_privacy_policy_screen_and_content() throws Throwable {
    	if(System.getProperty("platform").equalsIgnoreCase("iOS")) {
	    	Assert.assertEquals(menu.privacyPolicy(), true);
	    	logger.info("Inside of Privacy and policy");
    	}else if(System.getProperty("platform").equalsIgnoreCase("Android")) {
    		Assert.assertEquals(menu.getMenu_txt_privacypolicy().isDisplayed(), true);
    	}	
    }
}	
