package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;

public class FeaturedProgram_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	MenuList menu = new MenuList(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyLibrary myLib = new MyLibrary(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());

	@Given("library libraryname has kidszone subscription")
	public void library_libraryname_has_kidszone_subscription() throws Throwable {
		logger.info("library libraryname has kidszone subscription");
	}

	@And("user is in logged by libraryid and pin")
	public void user_is_in_logged_by_libraryid_and_pin() throws Throwable {
//		login.handleNothankspopup();
		menu.clickMyLibrary();
	}

	@And("programs are enabled for the profile and library")
	public void programs_are_enabled_for_the_profile_and_library() throws Throwable {
		logger.info("program enabled for library");
	}

	@And("admin has not set featured program")
	public void admin_has_not_set_featured_program() throws Throwable {
		logger.info("admin has not set featured program");
	}

	@When("user navigates to the library screen")
	public void user_navigates_to_the_library_screen() throws Throwable {
		login.handleNothankspopup();
		myLib.clickMylibrary();
	}

	@Then("user should be able to view set featured program as banner based on profile with profile specific theme")
	public void user_should_be_able_to_view_set_featured_program_as_banner_based_on_profile_with_profile_specific_theme()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to collapse and expand the featured program accordion")
	public void user_should_be_able_to_collapse_and_expand_the_featured_program_accordion() throws Throwable {
		menu.clickaccordion();
	}

	@And("system should remember the expand or collapse accordion state set by the user")
	public void system_should_remember_the_expand_or_collapse_accordion_state_set_by_the_user() throws Throwable {
		menu.clickaccordionexpand();
		ClickOnMobileElement(myShelf.getMyShelf_lbl_footer());
		ClickOnMobileElement(menu.getMenu_btn_mylibrary());
		if (isElementPresent(menu.getMenu_btn_featuredprgViewDetail())) {
			logger.info("Prg is in expand state");
			Assert.assertEquals(isElementPresent(menu.getMenu_lbl_featuredprogramtiltle()), true);
		} else {
			logger.info("Prg is in collapse state");
		}
	}

	@And("system should load the featured program accordion in the state set by the user")
	public void system_should_load_the_featured_program_accordion_in_the_state_set_by_the_user() throws Throwable {
		logger.info("system should load the featured program accordion");
	}

	@Then("user should be able to view exiting functionality of the axis360 application")
	public void user_should_be_able_to_view_exiting_functionality_of_the_axis360_application() throws Throwable {
		logger.info("Library setting");
	}

	@Then("user should be able to navigate to featured program or my programs screen from cta's in the banner")
	public void user_should_be_able_to_navigate_to_featured_program_or_my_programs_screen_from_ctas_in_the_banner()
			throws Throwable {
		menu.clickonFeaturedPrgViewDetails();
	}

	@Then("user should view the featured program banner if state of the featured program is published")
	public void user_should_view_the_featured_program_banner_if_state_of_the_featured_program_is_published()
			throws Throwable {
		swipeDown();
		Assert.assertEquals(isElementPresent(menu.getMenu_lbl_featuredprogramtiltle()), true);
	}

	@And("User should view the featured program banner if state of the featured program is active")
	public void user_should_view_the_featured_program_banner_if_state_of_the_featured_program_is_active()
			throws Throwable {
		Assert.assertEquals(menu.getMenu_lbl_featuredprogramtiltle().isDisplayed(), true);
	}

	@And("user should view the featured program banner if state of the featured program is started only")
	public void user_should_view_the_featured_program_banner_if_state_of_the_featured_program_is_started_only()
			throws Throwable {
		Assert.assertEquals(menu.getMenu_lbl_featuredprogramtiltle().isDisplayed(), true);
	}

	@Then("user should not view the featured program banner if no featured program has been set")
	public void user_should_not_view_the_featured_program_banner_if_no_featured_program_has_been_set()
			throws Throwable {
		Assert.assertEquals(isElementPresent(menu.getMenu_txt_featuredprogrambanner()), false);
	}

	@Then("user should not view the featured program if not enabled for the profile")
	public void user_should_not_view_the_featured_program_if_not_enabled_for_the_profile() throws Throwable {
		Assert.assertEquals(isElementPresent(menu.getMenu_txt_featuredprogrambanner()), false);
	}

	@Then("user should not view the featured program banner if state of the featured program is Unpublished or Closed")
	public void user_should_not_view_the_featured_program_banner_if_state_of_the_featured_program_is_unpublished_or_closed()
			throws Throwable {
		Assert.assertEquals(isElementPresent(menu.getMenu_txt_featuredprogrambanner()), false);
	}

	@Then("user should be able to view quick navigation CTAs for the lists created to be featured in this section")
	public void user_should_be_able_to_view_quick_navigation_ctas_for_the_lists_created_to_be_featured_in_this_section()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myShelf.getLogo_txt_Hold()), true);
		Assert.assertEquals(isElementPresent(myShelf.getLogo_txt_Checkout()), true);
		logger.info("User able to see quick naviagation menu on top");
	}

	@Then("user should be able to display profile type as kid for {string}")
	public void user_should_be_able_to_display_profile_type_as_kid_for_new_updated_my_shelf_and_library_screen(
			String displaymsg) throws Throwable {
	}

	@Then("verify user should be able to display profile type as adult for {string}")
	public void verify_user_should_be_able_to_display_profile_type_as_adult_for_new_updated_my_shelf_and_library_screen(
			String displaymsg) throws Throwable {
	}

	@Then("verify user should be able to display profile type as teen for {string}")
	public void verify_user_should_be_able_to_display_profile_type_as_teen_for_new_updated_my_shelf_and_library_screen(
			String displaymsg) throws Throwable {
	}

	@Then("verify user should be able to display profile type as adult {string}")
	public void verify_user_should_be_able_to_display_profile_type_as_adult_current_axis360_home_screen(
			String displaymsg) throws Throwable {
	}

	@Then("verify user should be able to view profile type as adult {string}")
	public void verify_user_should_be_able_to_view_profile_type_as_adult_something(String displaymsg) throws Throwable {
	}

	@And("verify library screen should not applicable for profile type as kid, teen")
	public void verify_library_screen_should_not_applicable_for_profile_type_as_kid_teen() throws Throwable {
	}

	@Then("user should be able to display profile type as teen for {string}")
	public void user_should_be_able_to_display_profile_type_as_teen_for_something(String displaymsg) throws Throwable {
	}

	@Then("verify user should be able to display profile type as kid for {string}")
	public void verify_user_should_be_able_to_display_profile_type_as_kid_for_something(String displaymsg)
			throws Throwable {
	}

	@And("user should not enabled programs for the profile")
	public void user_should_not_enabled_programs_for_the_profile() throws Throwable {
	}

	@And("user should be enable programs for the library")
	public void user_should_be_enable_programs_for_the_library() throws Throwable {
	}

	@And("state of the featured program is unpublised or closed")
	public void state_of_the_featured_program_is_unpublised_or_closed() throws Throwable {
	}

	@And("User should view the featured program banner")
	public void userShouldViewTheFeaturedProgramBanner() {
		Assert.assertEquals(isElementPresent(menu.getMenu_lbl_featuredprgHeader()),true);
	}
	
	@Given("user should be able to view browse option in bottom navigation")
	public void user_should_be_able_to_view_browse_option_in_bottom_navigation() {
		Assert.assertEquals(isElementPresent(menu.getBrowse_Bottom_Navigation()),true);
	}

	@Given("user should be able to clicks the browse option from bottom navigation")
	public void user_should_be_able_to_clicks_the_browse_option_from_bottom_navigation() {
		menu.clickBrowse();
	}

	@Given("user should be able to view the sort option in right side of the page")
	public void user_should_be_able_to_view_the_sort_option_in_right_side_of_the_page() {
		menu.clickBrowseTitle();
		Assert.assertEquals(isElementPresent(menu.getSort_Option()),true);
	}

	@Given("user should not be able to view the sort options under the refine section")
	public void user_should_not_be_able_to_view_the_sort_options_under_the_refine_section() {
		menu.navigatetoRefine();
		Assert.assertEquals(isElementPresent(menu.getSort_Option()),false);
		waitFor(2000);
		menu.closeRefine();
		waitFor(2000);
	}

	@When("user should be able to click the sort option")
	public void user_should_be_able_to_click_the_sort_option() {
		menu.clickSortOption();
	}

	@Then("user should be able to view the sort options as dropdown")
	public void user_should_be_able_to_view_the_sort_options_as_dropdown() {
		Assert.assertEquals(isElementPresent(menu.getSort_By()),true);
	}

	@Then("user should be able to view the {string} and {string} and {string} and {string} and {string} and {string} options in dropdown")
	public void user_should_be_able_to_view_the_and_and_and_and_and_options_in_dropdown(String string, String string2, String string3, String string4, String string5, String string6) {
		Assert.assertEquals(isElementPresent(menu.getAdded_Date()),false);
		Assert.assertEquals(isElementPresent(menu.getSort_Author()),false);
		Assert.assertEquals(isElementPresent(menu.getPopularity()),false);
		Assert.assertEquals(isElementPresent(menu.getPublication_Date()),false);
		Assert.assertEquals(isElementPresent(menu.getReturn_Date()),false);
		Assert.assertEquals(isElementPresent(menu.getTitle()),false);
	}

	@Then("user selects Return date from the dropdown")
	public void user_selects_return_date_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user selects Popularity from the dropdown")
	public void user_selects_popularity_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user selects Publication Date from the dropdown")
	public void user_selects_publication_date_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user selects Added Date from the dropdown")
	public void user_selects_added_date_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user selects Title from the dropdown")
	public void user_selects_title_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user selects Author from the dropdown")
	public void user_selects_author_from_the_dropdown() {
		menu.clickReturn_Date();
		menu.clickSearch();
	}
	
	@Then("user should be able to view the titles sorted based on the Return date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_return_date() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should be able to view the titles sorted based on the Popularity")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_popularity() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should be able to view the titles sorted based on the Publication Date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_publication_date() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should be able to view the titles sorted based on the Added Date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_added_date() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should be able to view the titles sorted based on the Title")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_title() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should be able to view the titles sorted based on the Author")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_author() {
		Assert.assertEquals(isElementPresent(menu.getSearchResult()),true);
	}

	@Then("user should not be able to view the intermediate screen for browse")
	public void userShouldNotBeAbleToViewTheIntermediateScreenForBrowse() {
		Assert.assertEquals(isElementPresent(menu.getIntermediateScreen()),false);
	}

	@And("user should be able to view browse result page")
	public void userShouldBeAbleToViewBrowseResultPage() {
		Assert.assertEquals(isElementPresent(menu.getBrowse_Result_Page()),true);
	}

	@And("user should be able to view Refiners option at the right side of the page")
	public void userShouldBeAbleToViewRefinersOptionAtTheRightSideOfThePage() {
		Assert.assertEquals(isElementPresent(menu.getRefiners_Option()),true);
	}

	@And("user should be able to view the result screen with no pills by default")
	public void userShouldBeAbleToViewTheResultScreenWithNoPillsByDefault() {
		Assert.assertEquals(isElementPresent(menu.getResults_No_Pills()),true);
	}

	@And("user click on the Refiners option")
	public void userClickOnTheRefinersOption() {
		menu.clickonRefiner();
		waitFor(2000);
	}
}
