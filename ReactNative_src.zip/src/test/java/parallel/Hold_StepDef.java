package parallel;

import com.reusableMethods.CommonActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Hold;
import pom.kidszone.LoginPage;
import pom.kidszone.MyLibrary;
import pom.kidszone.ProfilePage;
import pom.kidszone.RegisterScreen;
import pom.kidszone.SearchPage;
import pom.kidszone.Tier1_LandingPage_VBookandVideo;
import pom.kidszone.Tier2_TitlelistPage_VBookandVideo;

public class Hold_StepDef extends CommonActions {

	Hold hold = new Hold(DriverManager.getDriver());
	MyLibrary library = new MyLibrary(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	ProfilePage profile =new ProfilePage(DriverManager.getDriver());
	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	Tier1_LandingPage_VBookandVideo videoAndVBookTier1 = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
	Tier2_TitlelistPage_VBookandVideo Tier2_TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(
			DriverManager.getDriver());
	SearchPage search = new SearchPage(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(Tier1_LandingPage_StepDef.class);

	@When("user should not be registered with email id")
	public void user_should_not_be_registered_with_email_id() {
		logger.info("User is not registered with email id");
		//Assert.assertEquals(isElementPresent(hold.getEmail_Not_Available()), false);
		 profile.adultProfileSelection();
		 waitFor(2000);
		 login.handleNothankspopup();
	}

	@When("user click the title to navigate to title details screen which is not available to checkout")
	public void user_click_the_title_to_navigate_to_title_details_screen_which_is_not_available_to_checkout() {
//	    profile.searchTitleHold();
//	    waitFor(5000);
	    hold.select_EBook();
	    waitFor(2000);
	}

	@When("user should be able to view title with primary and secondary CTA")
	public void user_should_be_able_to_view_title_with_primary_and_secondary_cta() {
		hold.remove_Hold();
		Assert.assertEquals(isElementPresent(hold.get_Primary_CTA()), true);
		Assert.assertEquals(isElementPresent(hold.get_Secondary_CTA()), true);
	}

	@When("user should be able to put the title on hold")
	public void user_should_be_able_to_put_the_title_on_hold() {
		hold.click_Primary_CTA();
	}
	
	@When("user should be able to remove hold to the title")
	public void user_should_be_able_to_remove_hold_to_the_title() {
		hold.remove_Program_Hold_CTA();
	}

	@Then("user should not get prompted to put their email id")
	public void user_should_not_get_prompted_to_put_their_email_id() {
		waitFor(3000);
		logger.info("User is not prompted to put their email id");
	}
	
	@When("^user should be able to put the title on hold wich is not available to checkout$")
    public void user_should_be_able_to_put_the_title_on_hold_wich_is_not_available_to_checkout() throws Throwable {
		hold.click_Program_Primary_CTA();
	}

    @And("^user clicks the program option from bottom navigation$")
    public void user_clicks_the_program_option_from_bottom_navigation() throws Throwable {
    	hold.clickPrograms();
    }

    @And("^user lands on my program tab$")
    public void user_lands_on_my_program_tab() throws Throwable {
    	hold.clickMyPrograms();
    }

    @And("^user navigates to open programs tab$")
    public void user_navigates_to_open_programs_tab() throws Throwable {
    	hold.clickOpenPrograms();
    }
    
    @And("^user clicks on program card to navigate program details screen$")
    public void user_clicks_on_program_card_to_navigate_program_details_screen() throws Throwable {
    	hold.clickProgram_Card();
    }
    
    @And("^user clicks on program card from open programs to navigate program details screen$")
    public void user_clicks_on_program_card_from_open_programs_to_navigate_program_details_screen() throws Throwable {
    	hold.clickOpenProgram_Card();
    	hold.select_OpenProgram_EBook();
    }

    @And("^user should be able to view title with primary CTA$")
    public void user_should_be_able_to_view_title_with_primary_cta() throws Throwable {
    	Assert.assertEquals(isElementPresent(hold.get_Program_Primary_CTA()), true);
    }

}
