package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;

public class InitiateSearch_StepDef {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@When("user enters the new  {string} and initiate search")
	public void user_enters_the_new_and_initiate_search(String libKeyword) {
		login.searchLibrary(libKeyword);
		login.initiateSearch();
	}

	@Then("user should be able to view search suggestions based on the {string}")
	public void user_should_be_able_to_view_search_suggestions_based_on_the_something(String keyword) throws Throwable {
//        login.suggestionKeywordCheck(keyword);
		login.libSuggestionAfterSearch();
	}

	@Then("user should be able to view  search results.")
	public void user_should_be_able_to_view_search_results() {
		Assert.assertTrue(login.libSuggestionAfterSearch());
	}

	@When("user updates search {string}")
	public void user_updates_search(String updatedKeyword) {
		login.clearkeywords();
		login.searchLibrary(updatedKeyword);
	}

	@Then("user should be able to view search suggestions based on updated {string}")
	public void user_should_be_able_to_view_search_suggestions_based_on_updated_something(String updatedKeyword)
			throws Throwable {
		System.out.println(updatedKeyword);
		login.suggestionKeywordCheck(updatedKeyword);
	}
	@Then("user should be able to view updated search results when user initiates search with updated keyword")
	public void user_should_be_able_to_view_updated_search_results_when_user_initiates_search_with_updated_keyword() {
		login.initiateSearch();
		login.libSuggestionAfterSearch();
		Assert.assertTrue(login.libSuggestionAfterSearch());
	}

	@When("clicks on close button")
	public void clicks_on_close_button() {
		login.clearkeywords();
	}

	@Then("the entire search box should get cleared")
	public void the_entire_search_box_should_get_cleared() {
		Assert.assertEquals(login.logo_txt_Search.getText().isEmpty(),false);
	}
}
