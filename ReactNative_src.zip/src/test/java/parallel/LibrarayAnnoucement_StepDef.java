package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.MyLibrary;
import pom.kidszone.Navigationbars;
import pom.kidszone.ProfileCreation;
import pom.kidszone.SearchPage;

public class LibrarayAnnoucement_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
	SearchPage search = new SearchPage(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@Given("user launch the app and selects the login with prefix authentication without password library")
	public void user_launch_the_app_and_selects_the_login_with_prefix_authentication_without_password_library_libraryname() {

	}

	@And("user click on login button after user enters kidszone subscription only using libraryid libraryid only")
	public void user_click_on_login_button_after_user_enters_kidszone_subscription_only_using_libraryid_libraryid_only() {

	}

	@And("library announcement section is disabled in admin")
	public void library_announcement_section_is_disabled_in_admin() {

	}

	@When("user lands on library screen")
	public void user_lands_on_library_screen() {
		logger.info("user lands on library screen");
	}

	@Then("user should not be able to view annnouncements if disabled in admin")
	public void user_should_not_be_able_to_view_annnouncements_if_disabled_in_admin() {

	}

	@When("user is in the library screen")
	public void user_is_in_the_library_screen() {

	}

	@Given("user is in the my library screen")
	public void user_is_in_the_my_library_screen() {

	}

	@When("announcement section is not displayed")
	public void announcement_section_is_not_displayed() {

	}

	@When("user_should_be_able_to_view_the_space_automatically_occupied_by_the_next_following_widget")
	public void user_should_be_able_to_view_the_space_automatically_occupied_by_the_next_following_widget() {

	}

//    Given logged in user and library has kidszone subscription "<libraryid>" and "<pin>"
//    When user is in the library screen
//    Then user should be able to view quick link in the my library screen
//    And quick links at the top will be fixed
//    And user should be able to view featured reading program
//    And user should be able to view announcement and book of the month
//    And user should be able to view featured list and always available
//    And user should be able view news paper and magazines
//    And user should be able to view the order of other components based on admin configuration
//    And user should be able to logout of the application
//    
	@Given("logged in user and library has kidszone subscription libraryid and pin")
	public void logged_in_user_and_library_has_kidszone_subscription_libraryid_and_pin(String libraryid, String pin) {

	}

	@Then("user should be able to view quick link in the my library screen")
	public void user_should_be_able_to_view_quick_link_in_the_my_library_screen() {

	}

	@And("quick links at the top will be fixed")
	public void quick_links_at_the_top_will_be_fixed() {

	}

	@And("user should be able to view featured reading program")
	public void user_should_be_able_to_view_featured_reading_program() {

	}

	@And("user should be able to view announcement and book of the month")
	public void user_should_be_able_to_view_announcement_and_book_of_the_month() {

	}

	@And("user should be able to view featured list and always available")
	public void user_should_be_able_to_view_featured_list_and_always_available() {

	}

	@And("user should be able view news paper and magazines")
	public void user_should_be_able_view_news_paper_and_magazines() {

	}

	@And("user should be able to view the order of other components based on admin configuration")
	public void user_should_be_able_to_view_the_order_of_other_components_based_on_admin_configuration() {

	}

	@And("user should be able to logout of the application")
	public void user_should_be_able_to_logout_of_the_application() {

	}

	// ********************************************* Pravin - 178056
	// **************************************************

	@Then("user should not view the always available carousel in the library screen")
	public void user_should_not_view_the_always_available_carousel_in_the_library_screen() {

		if (System.getProperty("platform").equalsIgnoreCase("Android")) {

			for (int i = 0; i <= 10; i++) {

				if (isElementPresent(mylibrary.getMyLib_lbl_alwaysAvlHeader())) {
					logger.info("Always avialble carousel is present");
					Assert.assertEquals(isElementPresent(mylibrary.getMyLib_lbl_alwaysAvlHeader()), false);
					break;
				} else {
					swipeDown();
				}

			}

//                MobileElement label = (MobileElement)DriverManager.getDriver().findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"ALWAYS AVAILABLE\").instance(0))"));
		}

		Assert.assertEquals(isElementPresent(mylibrary.getMyLib_lbl_alwaysAvlHeader()), false);

		logger.info("Always available carousel is not present");

	}

	@And("user click on advance search bar")
	public void user_click_on_advance_search_bar() {
		search.clickSearchIcon();

	}

	@And("user should not able to view always available option in advance search popup")
	public void user_should_not_able_to_view_always_available_option_in_advance_search_popup() {

		Assert.assertEquals(isElementPresent(mylibrary.getMyLib_lbl_alwaysAvlHeader()), false);

	}

	@And("user navigated to the results screen")
	public void user_navigated_to_the_results_Screen() {
		Assert.assertEquals(isElementPresent(search.getSearch_result()), true);

	}

	@And("user taps on the refine option")
	public void user_taps_on_the_refine_option() {

		search.clickRefiner();

	}

	@And("user should not be able to view always available carousel option under collection refine option")
	public void user_should_not_be_able_view_always_available_carousel_option_under_collection_refine_option() {

		Assert.assertEquals(isElementPresent(mylibrary.getMyLib_lbl_alwaysAvlHeader()), false);
		waitFor(3000);
		search.closerefiner();
		search.clickBack();
	}

}
