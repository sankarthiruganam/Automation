package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.Preference;
import pom.kidszone.ProfileCreation;
import pom.kidszone.SetParentPin;

public class MenuList_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	Preference preference = new Preference(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
    private Scenario scenario;
    

	/************************ 124458 ******************************/

//	@Given("user launch the app and select the library {string}")
//	public void user_launch_the_app_and_select_the_library(String library) {
//		login.searchLibrary(library);
//		login.initiateSearch();
//		login.select_library();
//	}

	@Before
    public void setup(Scenario scenario) {
        this.scenario = scenario;
    }

	@Given("user click on login button after user enters {string} and {string}")
	public void user_click_on_login_button_after_user_enters_and(String userName, String passWord) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		login.enterPwd(testData.getPassword());
		login.clickSignInBtn();
	}

	@And("user enters {string} for axis360 Library")
	public void user_enters_something_for_axis360_library(String libraryid) throws Throwable {
		login.axis360UserLoginwithPin(libraryid);
	}

	@Given("library has kidszone subscription")
	public void library_has_kidszone_subscription() {
		login.handleNothankspopup();
		logger.info("This libary is enabled with kidszone subscription");
	}

	@Given("user should be navigated to menu screen")
	public void user_should_be_navigated_to_menu_screen() {
	//	login.handleNothankspopup();
		logger.info("User is on Home page");
		login.clickFooterMenu();
	}

	@Given("user should be able to click on close cta")
	public void user_should_be_able_to_click_on_close_cta() {
		logger.info("Close btn is not displayed in Menu list");
	}

	@Given("navigate back to the last screen")
	public void navigate_back_to_the_last_screen() {

	}

	@Given("user should signout from the application")
	public void user_should_signout_from_the_application() {
		login.clickFooterMenu();
		login.logOut();
	}

	@Given("user should be able to view list of menu items")
	public void user_should_be_able_to_view_list_of_menu_items() {
		menu.menuListValidation();
	}

	@Given("user launch the app and selects the login with prefix auth without pin library {string}")
	public void user_launch_the_app_and_selects_the_login_with_prefix_auth_without_pin_library(String library) {
		if (isElementPresent(login.boundlessAllow())) {
			login.clickBoundlessAllow();
		}
		login.searchLibrary(library);
		login.initiateSearch();
		login.select_library();
	}

	@Given("user click on login button after user enters {string}")
	public void user_click_on_login_button_after_user_enters(String userName) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		hideMobileKeyboard();
		login.clickSignInBtn();
	}

	@Given("library has axis360 only subscription")
	public void library_has_axis360_only_subscription() {
		logger.info("User is on the Kidszone Newyork library");
	}

	@Given("user should not able to view Profiles option")
	public void user_should_not_able_to_view_profiles_option() {
		logger.info("user should not able to view Profiles option");
	}

	@And("user should be able to view Profiles option")
	public void user_should_be_able_to_view_profiles_option() throws Throwable {
		Assert.assertEquals(menu.profileOptDisplayCheck(), true);
		
	}

	/*************************** 124459 *************************************/

	@Given("user logged in")
	public void user_logged_in() {

	}

	@When("user clicks on profile in menu")
	public void user_clicks_on_profile_in_menu() {
		login.clickFooterMenu();
		menu.clickprofileMenu();
	}

	@Then("user should be prompted for parent pin validation")
	public void user_should_be_prompted_for_parent_pin_validation() {
		Assert.assertEquals(setPin.getSetParentPin_NumpadKeyOne().isDisplayed(), true);
		logger.info("System prompting for Parent pin");
	}

	@Then("user enters the parent pin")
	public void user_enters_the_parent_pin() {
		setPin.parentPin();
	}

	@Then("user should be navigated to profiles screen on successful validation of the parent pin")
	public void user_should_be_navigated_to_profiles_screen_on_successful_validation_of_the_parent_pin() {
		Assert.assertEquals(isElementPresent(profile.profile_txt()), true);
		logger.info("User is on profiel management page");
	}

	@And("library has axis360 subscirption only")
	public void library_has_axis360_subscirption_only() {

	}

	@And("user enters the parent pin parentpin")
	public void user_enters_the_parent_pin_parentpin() {

	}

	@When("user clicks on menu option")
	public void user_clicks_on_menu_option() {
		login.clickFooterMenu();
	}

	@Then("profile option should not display")
	public void profile_option_should_not_display() {
		Assert.assertEquals(login.getLogo_txt_profile().isDisplayed(), false);
		logger.info("User not able to see Profile option in menu list");
	}

	/**************************** 124693 *************************************/

	@Given("user click on login button after user enter kidszone subscription only {string} and {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_only_and(String userName,
			String password) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		login.enterPwd(testData.getPassword());
		swipeDown();
		login.clickSignInBtn();
	}
	
	@Given("user click on login button after user enter kidszone kid subscription only {string} and {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_kid_subscription_only_and(String userName,
			String password) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		login.enterPwd(testData.getPassword());
		swipeDown();
		login.clickSignInBtn();
		waitFor(2000);
		manage.kidprofileSelection();
		login.handleNothankspopup();
		}

	@Given("user is on menu screen")
	public void user_is_on_menu_screen() {
		login.clickFooterMenu();
	}

	@When("user clicks preferences menu list item")
	public void user_clicks_preferences_menu_list_item() {
		menu.clickonPreference();
	}

	@Then("user should be navitage to preferences screen")
	public void user_should_be_navitage_to_preferences_screen() {
		Assert.assertEquals(menu.preferenceNavCheck(), true);
		logger.info("User is on preference page");
	}

	/************************ 124694 ***************************/

	@When("user clicks help menu list item")
	public void user_clicks_help_menu_list_item() {
		menu.clickonHelp();
	}

	@Then("user should be able to click on help and navigate to help portal in web view")
	public void user_should_be_able_to_click_on_help_and_navigate_to_help_portal_in_web_view() {
		Assert.assertEquals(menu.helpPgNavCheck(), true);
	}

	@When("user clicks patron support menu list item")
	public void user_clicks_patron_support_menu_list_item() {
		menu.clickonPatronSupprot();
	}

	@Then("user should be able to click on patron support and navigate to particular screen")
	public void user_should_be_able_to_click_on_patron_support_and_navigate_to_particular_screen() {
		Assert.assertEquals(menu.patSupportPgNavCheck(), true);
	}

	@Given("library has kidszone subscription only")
	public void library_has_kidszone_subscription_only() {
		logger.info("user is on Kidszone only library");
	}

	@When("user clicks about menu list item")
	public void user_clicks_about_menu_list_item() {
		menu.clickonAbout();
	}

	@Then("user should be able to click on about and navigate to about screen")
	public void user_should_be_able_to_click_on_about_and_navigate_to_about_screen() {
		Assert.assertEquals(menu.aboutPgNavCheck(), true);
	}

	@When("user clicks legal menu list item")
	public void user_clicks_legal_menu_list_item() {
		menu.clicklegal();
		menu.clickonTermsAndCondition();
	}

	@Then("user should be able to click on legal and navigate to legal screen")
	public void user_should_be_able_to_click_on_legal_and_navigate_to_legal_screen() {
		Assert.assertEquals(menu.termsAndConditionPgNavCheck(), true);
	}

	@Given("library has kidszone and axis360 subscription")
	public void library_has_kidszone_and_axis360_subscription() {
		logger.info("User is on Kidszone and axis 360 user");
	}

	@Then("user should be able to view search bar and input keyword to initiate the search {string}")
	public void user_should_be_able_to_view_search_bar_and_input_keyword_to_initiate_the_search(
			String menu_txt_searchbar) throws Throwable {
		menu.checkSeachbar(true);
		menu.initiatehomesearch(menu_txt_searchbar);
	}

	@And("user should be able to click on advance search cta and view advance search options")
	public void user_should_be_able_to_click_on_advance_search_cta_and_view_advance_search_options() throws Throwable {
		menu.clickadvancesearch();
		logger.info("search is nt fully developed");
	}

	@And("verify the count of minimum input keyword required to initiate search")
	public void verify_the_count_of_minimum_input_keyword_required_to_initiate_search() throws Throwable {
		Assert.assertEquals(menu.checksearchcount(), true);
		logger.info("search keyword minium count avilable");
	}

	@And("verify the cancel cta should be available when user input keyword in search bar")
	public void verify_the_cancel_cta_should_be_available_when_user_input_keyword_in_search_bar() throws Throwable {
		logger.info("verify the cancel cta should be available when user input keyword");
	}
}
