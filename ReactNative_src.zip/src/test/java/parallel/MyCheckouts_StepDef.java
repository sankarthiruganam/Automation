package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyShelf;
import pom.kidszone.SetParentPin;


public class MyCheckouts_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/************************ 124492 **************************/
	@When("user lands on My Shelf screen")
	public void user_lands_on_my_shelf_screen() {
		myShelf.getMyShelf_lbl_footer().click();
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_footer()), true);
		logger.info("User lands on MyShelf page");
	}

	@Then("user should be able to view checked out titles section with profile based theme")
	public void user_should_be_able_to_view_checked_out_titles_section_with_profile_based_theme() {
		logger.info("theaming check");
	}

	@Then("user should able to view titles checked out by the user")
	public void user_should_able_to_view_titles_checked_out_by_the_user() {
		myShelf.verifyCheckedOutTitles();
	}

	@Then("user should able to click on the ebook title in focus and navigate to ereader")
	public void user_should_able_to_click_on_the_ebook_title_in_focus_and_navigate_to_ereader() {
		myShelf.clickebook();

	}

	@Then("user should able to click on the audio title in focus and navigate to audio player")
	public void user_should_able_to_click_on_the_audio_title_in_focus_and_navigate_to_audio_player() {
		myShelf.clickaudiobook();
	}

	@Then("user should view checked out titles section with text description {string} if no title has been checked out by the user")
	public void user_should_view_checked_out_titles_section_with_text_description_if_no_title_has_been_checked_out_by_the_user(
			String string) {
	}

	@Then("user should be able to view See All cta")
	public void user_should_be_able_to_view_see_all_cta() {
		myShelf.checkseeAll();
	}

	@Then("user should be redirected to checked out listing page upon clicking See All cta")
	public void user_should_be_redirected_to_checked_out_listing_page_upon_clicking_see_all_cta() {
		myShelf.checkseeAll();
	}

	@Then("user should be able to view no checked out titles section with profile based theme")
	public void user_should_be_able_to_view_no_checked_out_titles_section_with_profile_based_theme() {
		logger.info("user able to see the checkouts");
	}

}
