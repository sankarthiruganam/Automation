package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pom.kidszone.*;

public class MyLibrary_StepDef extends CommonActions {

    MyLibrary library = new MyLibrary(DriverManager.getDriver());
    LoginPage login = new LoginPage(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo videoAndVBookTier1 = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier2_TitlelistPage_VBookandVideo Tier2_TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(
            DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    ManageProfile manageProfile = new ManageProfile(DriverManager.getDriver());
    ProfilePage profilePage = new ProfilePage(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo tier1LandingPage = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    MenuList menu = new MenuList(DriverManager.getDriver());
    Hold hold = new Hold(DriverManager.getDriver());
    Holds holds = new Holds(DriverManager.getDriver());
    ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
    MyProgramScreen program = new MyProgramScreen(DriverManager.getDriver());
    public static final Logger logger = LoggerFactory.getLogger(Tier1_LandingPage_StepDef.class);

    @And("library should have video carousel configured in drupal,subscription to VBook collection third party,enabled in library admin")
    public void library_should_have_video_carousel_configured_in_drupalsubscription_to_vbook_collection_third_partyenabled_in_library_admin()
            throws Throwable {
        logger.info("Admin drupal - library should have video carousel configured");
    }

    @When("user selects the VBooks format from the bottom drawer")
    public void user_selects_the_vbooks_format_from_the_bottom_drawer() throws Throwable {
        library.click_vBook_BottomDrawer();
        waitFor(5000);
//		swipeDown();
//		swipeDown();
    }

    @And("user selects the Video format from the drop down")
    public void user_selects_the_video_format_from_the_drop_down() throws Throwable {
        library.click_Video_BottomDrawer();
        waitFor(5000);
//		swipeDown();
//		swipeDown();
//		swipeDown();
    }

    @Then("system should filter the titles based on the selected filter option")
    public void system_should_filter_the_titles_based_on_the_selected_filter_option() throws Throwable {
        for (int i = 0; i <= 7; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.Video_Carousel()), true);
        logger.info("Titles are filtered based on the selected filter option");
    }

    @And("user should be able to view video categories in the carousel format")
    public void user_should_be_able_to_view_video_categories_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        for (int i = 0; i <= 18; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
    }

    @And("user should be able to view vBook categories in the carousel format")
    public void user_should_be_able_to_view_vBook_categories_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        waitFor(3000);
        swipeDown();
        swipeDown();
        swipeDown();
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);
    }

    @And("user should view format bottom drawer with option eBook, eAudio, VBooks & Video")
    public void user_should_view_format_bottom_drawer_with_option_ebook_eaudio_vbooks_video() throws Throwable {
        waitFor(3000);
        login.clickmylibrary();
        library.clickFormat_Dropdown();
        Assert.assertEquals(isElementPresent(library.check_eBook_DropDown()), true);
        Assert.assertEquals(isElementPresent(library.check_eAudio__DropDown()), true);
        Assert.assertEquals(isElementPresent(library.check_vBook_BottomDrawer()), true);
        Assert.assertEquals(isElementPresent(library.check_Video_BottomDrawer()), true);
    }

    @And("user should be able to view titles specific to the selected format")
    public void user_should_be_able_to_view_titles_specific_to_the_selected_format() throws Throwable {
        Assert.assertEquals(isElementPresent(library.Video_Titles()), true);
    }

    @And("user should be able to view the font,colour text and alignment look and feel same as mocks")
    public void user_should_be_able_to_view_the_fontcolour_text_and_alignment_look_and_feel_same_as_mocks()
            throws Throwable {
        logger.info("Theme - font, text color checking");
    }

    @Then("user should be able to view VBook categories in the carousel format")
    public void user_should_be_able_to_view_vbook_categories_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);


    }

    @Then("user should be able to view the VBook categories in the carousel format")
    public void user_should_be_able_to_view_the_vbook_categories_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        for (int i = 0; i <= 14; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);

    }


    @Then("user should be able to view the video categories in the carousel format")
    public void user_should_be_able_to_view_the_video_categories_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        for (int i = 0; i <= 14; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);

    }

    @And("user should be able to view these VBooks with different publishers and each publisher covering with individual carousel configured in admin portal")
    public void user_should_be_able_to_view_these_vbooks_with_different_publishers_and_each_publisher_covering_with_individual_carousel_configured_in_admin_portal()
            throws Throwable {
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(library.check_vBook_Diff_Publishers())) {
                //swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.check_vBook_Diff_Publishers()), true);
    }

    @And("user should be able to view these videos with different publishers , each publisher covering with individual carousel configured in admin portal")
    public void user_should_be_able_to_view_these_videos_with_different_publishers_each_publisher_covering_with_individual_carousel_configured_in_admin_portal()
            throws Throwable {
        for (int i = 0; i <= 19; i++) {
            if (isElementPresent(library.check_videos_Diff_Publishers())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.check_videos_Diff_Publishers()), true);
    }

    @And("user should be able to view video categories in the carousel format Mr Billie,Checkers TV")
    public void user_should_be_able_to_view_video_categories_in_the_carousel_format_mr_billiecheckers_tv()
            throws Throwable {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(library.getPopularVideosSeeAll())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.video_Publisher()), true);
    }

    @And("user should be able to click on video Publishers to navigate to listing page Tier 2 Page")
    public void user_should_be_able_to_click_on_video_publishers_to_navigate_to_listing_page_tier_2_page()
            throws Throwable {
        swipeDown();
        library.check_videos_Diff_Publishers().click();
        waitFor(3000);
        Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
    }

    @And("user should be able to view  10 number of Videos Publishers in the carousel , as per set by Admin in Drupal")
    public void user_should_be_able_to_view_10_number_of_videos_publishers_in_the_carousel_as_per_set_by_admin_in_drupal()
            throws Throwable {
//		Assert.assertEquals(isElementPresent(library.video_Carousel_SeeAll()), true);
        for (int i = 0; i <= 15; i++) {
            if (isElementPresent(library.video_Publisher())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.video_Publisher()), true);
        logger.info("user should be able to view  10 number of Videos Publishers - no data");
    }

    @Then("user should be able to view video titles in the carousel format")
    public void user_should_be_able_to_view_video_titles_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
    }

    @And("user should be able to view 10  number of Videos titles  in the carousel , as per set by Admin in Drupal")
    public void user_should_be_able_to_view_10_number_of_videos_titles_in_the_carousel_as_per_set_by_admin_in_drupal()
            throws Throwable {
        Assert.assertEquals(isElementPresent(library.video_Carousel_SeeAll()), true);
        logger.info("user should be able to view  10 number of Videos titles");
    }

    @And("User should be able to view specific number of Videos title in the carousel as per drupal")
    public void user_should_be_able_to_view_specific_number_of_videos_title_in_the_carousel_as_per_drupal()
            throws Throwable {
        logger.info("number of Video titles in the carousel as per drupal");
    }

    @And("user should be able to view Video titles as per API response")
    public void user_should_be_able_to_view_video_titles_as_per_api_response() throws Throwable {
        logger.info("Video titles as per API response");
    }

    @And("user lands on Tier 1 listing page")
    public void user_lands_on_tier_1_listing_page() throws Throwable {
        Assert.assertEquals(isElementPresent(library.Tier1_listing_page()), true);
    }

    @And("user should able to view carousel type as stack carousel based on drupal configuration")
    public void user_should_able_to_view_carousel_type_as_stack_carousel_based_on_drupal_configuration()
            throws Throwable {
        logger.info("user view carousel type as stack carousel based on drupal ");
    }

    @And("user should able to view carousel type as item carousel based on drupal configuration")
    public void user_should_able_to_view_carousel_type_as_item_carousel_based_on_drupal_configuration()
            throws Throwable {
        logger.info("user view carousel type as item carousel based on drupal ");
    }

    @And("user should able to view carousel type as categories carousel based on drupal configuration")
    public void user_should_able_to_view_carousel_type_as_categories_carousel_based_on_drupal_configuration()
            throws Throwable {
        logger.info("user view carousel type as categories carousel based on drupal ");
    }

    @And("user should able to view carousel type as card carousel based on drupal configuration")
    public void user_should_able_to_view_carousel_type_as_card_carousel_based_on_drupal_configuration()
            throws Throwable {
        logger.info("user view carousel type as card carousel based on drupal ");
    }

    @And("User should be able to view  videos titles")
    public void user_should_be_able_to_view_videos_titles() throws Throwable {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.video_titles_page())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.video_titles_page()), true);
    }

    @And("user should be able to view videos title card with cover image with primary and secondary CTA")
    public void user_should_be_able_to_view_videos_title_card_with_cover_image_with_primary_and_secondary_cta()
            throws Throwable {
        Assert.assertEquals(isElementPresent(library.video_titles_page()), true);
    }

    @And("user should be able to click on videos title card")
    public void user_should_be_able_to_click_on_videos_title_card() throws Throwable {
        swipeDown();
        swipeDown();
        library.click_video_title_card();
    }

    @And("user should be view primary CTA as checkout")
    public void user_should_be_view_primary_cta_as_checkout() throws Throwable {
        Assert.assertEquals(isElementPresent(library.tier3_primary_CTA()), true);
    }

    @And("user should not able to view secondary CTA")
    public void user_should_not_able_to_view_secondary_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(library.tier3_secondary_CTA()), true);
    }

    @And("user should not able to view Wishlist and hold option")
    public void user_should_not_able_to_view_wishlist_and_hold_option() throws Throwable {
        Assert.assertEquals(isElementPresent(library.view_wishlist()), false);
        Assert.assertEquals(isElementPresent(library.view_hold()), false);
    }

    @And("user clicks on the vBook title in the my libary screen")
    public void userClicksOnTheVBookTitleInTheMyLibaryScreen() {
        waitFor(2000);
        library.click_vBook_title_card();
    }

    @And("user should be able to view left and right arrow on the respective sides of carousel")
    public void userShouldBeAbleToViewLeftAndRightArrowOnTheRespectiveSidesOfCarousel() {
        logger.info("user should be able to view left and right arrow on the respective sides of carousel");
    }

    @And("user should be able to select left and right arrow to swipe left and right side in the carousel")
    public void userShouldBeAbleToSelectLeftAndRightArrowToSwipeLeftAndRightSideInTheCarousel() {
        logger.info("user should be able to select left and right arrow to swipe left and right side in the carousel");
    }

    @And("user should able to land on vBook Tier {int} details screen")
    public void userShouldAbleToLandOnTierDetailsScreen(int arg0) {
        Assert.assertEquals(isElementPresent(library.verifyTier3Title()), true);
    }

    @And("user should be able to view specific number of Videos in the carousel based on drupal configuration")
    public void userShouldBeAbleToViewSpecificNumberOfVideosInTheCarouselBasedOnDrupalConfiguration() {
        logger.info("Able to View specific number of Videos in the carousel based on drupal configuration");
    }

    @And("user should able to land on video Tier {int} details screen")
    public void userShouldAbleToLandOnVideoTierDetailsScreen(int arg0) {
        Assert.assertEquals(isElementPresent(library.verifyTier3Title()), true);
    }

    @And("user should be able to view VBooks Widget based on order as defined by admin in Library Admin screen")
    public void userShouldBeAbleToViewVBooksWidgetBasedOnOrderAsDefinedByAdminInLibraryAdminScreen() {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(library.vBook_Publisher())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.vBook_Publisher()), true);
    }

    @And("user should be able to view VBook Widget as per API response")
    public void userShouldBeAbleToViewVBookWidgetAsPerAPIResponse() {
        logger.info("user should be able to view VBook Widget as per API response");
    }

    @Then("user should be able to view videos Widget based on order as defined by admin in Library Admin screen")
    public void userShouldBeAbleToViewVideosWidgetBasedOnOrderAsDefinedByAdminInLibraryAdminScreen() {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.video_Publisher())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.video_Publisher()), true);
    }

    @And("user should be able to view Video Widget as per API response")
    public void userShouldBeAbleToViewVideoWidgetAsPerAPIResponse() {
        logger.info("user should be able to view Video Widget as per API response");
    }

    @Then("system should filter the vBook titles based on the selected filter option")
    public void systemShouldFilterTheVBookTitlesBasedOnTheSelectedFilterOption() {
        for (int i = 0; i <= 7; i++) {
            if (isElementPresent(library.vBook_Diff_Publishers())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.vBook_Carousel()), true);
        logger.info("Titles are filtered based on the selected filter option");
        library.vBook_Carousel().click();
    }

    @And("user should be able to view vBook titles specific to the selected format")
    public void user_should_be_able_to_view_vBook_titles_specific_to_the_selected_format() throws Throwable {
        Assert.assertEquals(isElementPresent(library.vBook_Titles()), true);
    }

    @Then("user should be able to view VBook title in the carousel format")
    public void userShouldBeAbleToViewVBookTitleInTheCarouselFormat() {
        if (isElementPresent(library.checkVideoItemCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(library.checkVideoItemCarouselInTier1()), true);
        }
    }

    @Then("user should not able to view the more like this section in title details page for adult user with axis360 subscription$")
    public void user_should_not_able_to_view_the_more_like_this_section_in_title_details_page_for_adult_user_with_axis360_subscription()
            throws Throwable {
        search.clickTitleCover();
//		waitFor(2000);
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(search.getBtn_moreLikethis()), false);
    }

    @Then("user should be able to view 'Other Titles in Series' with series of titles that are associated to the title being viewed for adult user$")
    public void user_should_be_able_to_view_other_titles_in_series_with_series_of_titles_that_are_associated_to_the_title_being_viewed_for_adult_user()
            throws Throwable {
        search.clickTitleCover();
        waitFor(3000);
        for (int i = 0; i <= 7; i++) {
            if (isElementPresent(search.getTitle_series())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(search.getBtn_moreLikethis()), true);
        Assert.assertEquals(isElementPresent(search.getTitle_series()), true);
    }

    @And("user search the title {string} taps on the title")
    public void user_taps_on_any_of_the_title(String title) throws Throwable {
        search.globalSearch(title);
        hideMobileKeyboard();
//        search.click_Search_btn();
        search.clickSearch_Button();
    }

    @And("user should be able to view 'Other Titles in Series' section as carousel$")
    public void user_should_be_able_to_view_other_titles_in_series_section_as_carousel() throws Throwable {
        Assert.assertEquals(isElementPresent(search.getTitle_series()), true);
    }

    @And("user should be able to view only teen and kid age titles$")
    public void user_should_be_able_to_view_only_teen_and_kid_age_titles() throws Throwable {
        logger.info("Profile based title not scope in automation");
    }

    @And("user should not view adult titles$")
    public void user_should_not_view_adult_titles() throws Throwable {
        logger.info("Profile based title not scope in automation");
    }

    @Then("user should be able to view 'Titles Like This' section as carousel under 'More Like This' tab on title details screen for adult user with kidszone subscription$")
    public void user_should_be_able_to_view_titles_like_this_section_as_carousel_under_more_like_this_tab_on_title_details_screen_for_adult_user_with_kidszone_subscription()
            throws Throwable {
        waitFor(5000);
        search.clickTitleCover();
        waitFor(2000);
        for (int i = 0; i <= 4; i++) {
            if (isElementPresent(search.getTitle_likethis())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(search.getBtn_moreLikethis()), true);
        Assert.assertEquals(isElementPresent(search.getTitle_likethis()), true);

    }

    @Then("user should be able to view 'Titles Like This' section as carousel under 'More Like This' tab on title details screen for teen user with kidszone subscription$")
    public void user_should_be_able_to_view_titles_like_this_section_as_carousel_under_more_like_this_tab_on_title_details_screen_for_teen_user_with_kidszone_subscription()
            throws Throwable {
        waitFor(5000);
        search.clickTitleCover();
        for (int i = 0; i <= 4; i++) {
            if (isElementPresent(search.getTitle_likethis())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(search.getBtn_moreLikethis()), true);
    }

    @And("user should be able to view recommended titles based on the title being viewed$")
    public void user_should_be_able_to_view_recommended_titles_based_on_the_title_being_viewed() throws Throwable {
        Assert.assertEquals(isElementPresent(search.getTitle_series()), true);
    }

    @And("user should be able to view 'Title Like This' with recommended collection that are associated to that title$")
    public void user_should_be_able_to_view_title_like_this_with_recommended_collection_that_are_associated_to_that_title()
            throws Throwable {
        Assert.assertEquals(isElementPresent(search.getTitle_likethis()), true);
    }

    @And("user should be able to view enabled clear and search CTAs once they enter the keyword")
    public void userShouldBeAbleToViewEnabledClearAndSearchCTAsOnceTheyEnterTheKeyword() {
        Assert.assertEquals(search.clear_btn().isEnabled(), true);
        Assert.assertEquals(search.advance_search_btn().isEnabled(), false);
    }

    @And("user is able to enter a keyword {string} in advance search bar from landing screen")
    public void userIsAbleToEnterAKeywordInAdvanceSearchBarFromLandingScreen(String title) {
        search.searchkeyWord(title);
    }

    @And("user search on the magic library title {string} taps on the title")
    public void user_search_on_the_magic_taps_on_any_of_the_title(String title) throws Throwable {
        search.globalSearch(title);

    }

    @And("user should be able to click on VBooks Publishers to navigate to Tier{int} page")
    public void userShouldBeAbleToClickOnVBooksPublishersToNavigateToTierPage(int arg0) {
        swipeDown();
        library.clickvBookPublisher();
        Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
    }

    @When("user click on see all cta in {string} carousel and navigate to tier1 screen")
    public void user_click_on_see_all_cta_in_carousel_and_navigate_to_tier1_screen(String string) {
        library.clickNewsPaperMagazine();
    }

    @When("user click on see all cta in any carousel and navigate to tier2 screen")
    public void user_click_on_see_all_cta_in_any_carousel_and_naviagate_to_tier2_screen() {
        library.clickNewsPaperMagazineSeeAll();
    }

    @When("user search any keyword {string} and naviagate to search result screen")
    public void user_search_any_keyword_and_naviagate_to_search_result_screen(String text) {
        login.handleNothankspopup();
        search.advanceSearch(text);
        hideMobileKeyboard();
        search.click_Search_btn();
        waitFor(2000);
    }

    @Then("verify the {string} field availability on profile detail page")
    public void verify_the_field_availability_on_profile_detail_page(String string) {
        library.displayCheckoutHistory();
        waitFor(1000);
        Assert.assertEquals(isElementPresent(library.display_Checkout_History()), true);
    }

    @Then("user select the {string} checkbox")
    public void user_select_the_checkbox(String string) {
        library.clickDisplayCheckoutHistoryCheckbox();
    }

    @Then("user unselect the {string} checkbox and verify the alert popup")
    public void user_unselect_the_checkbox_and_verify_the_alert_popup(String string) {
        library.clickDisplayCheckoutHistoryCheckbox();
    }

    @Then("validate the Alert popup details \\(Title, Message description, Disable & cancel - CTA's)")
    public void validate_the_alert_popup_details_title_message_description_disable_cancel_cta_s() {
        waitFor(1000);
        Assert.assertTrue(isElementPresent(library.displayCheckoutPopupText()));
        Assert.assertEquals(library.displayCheckoutPopupContent().getText(), "Are you sure you want to disable checkout history? This will delete your history and cannot be restored.");
        Assert.assertEquals(library.displayCheckoutPopupDisable().getText(), "Disable");
        Assert.assertTrue(isElementPresent(library.displayCheckoutPopupCancel()));
    }

    @Then("user click {string} from the Alert poup")
    public void user_click_from_the_alert_poup(String string) {
        library.displayCheckoutPopupCancel().click();
    }

    @Then("again unselect the {string} checkbox and verify the alert popup")
    public void again_unselect_the_checkbox_and_verify_the_alert_popup(String string) {
        library.clickDisplayCheckoutHistoryCheckbox();
        Assert.assertTrue(isElementPresent(library.displayCheckoutPopupText()));
    }

    @Then("user clicks Disable from the alert popup")
    public void user_click_from_the_alert_popup() {
        library.displayCheckoutPopupDisable().click();
    }

    @When("user clicks preferences on the Menu list")
    public void user_clicks_preferences_on_the_menu_list() {
        library.clickPreferences();
    }

    @When("user should be able to view Deregister device")
    public void user_should_be_able_to_view_deregister_device() {
        Assert.assertEquals(isElementPresent(library.deregisterDevice()), true);
    }

    @When("user clicks on the Deregister device and should see the warning popup with message, No and Deregister buttons")
    public void user_clicks_on_the_deregister_device_and_should_see_the_warning_popup_with_message_no_and_deregister_buttons() {
        library.clickDeregisterDevice();
        Assert.assertEquals(library.deregisterWarningPopupContent().getText(), "Are you sure you want to deregister this device? Doing so will remove all downloaded Boundless titles from this device.");
        Assert.assertEquals(isElementPresent(library.deregisterWarningPopupYes()), true);
        Assert.assertEquals(isElementPresent(library.deregisterWarningPopupNo()), true);

    }

    @Then("user clicks on No option popup should be closed and stay on the same page")
    public void user_clicks_on_no_option_popup_should_be_closed_and_stay_on_the_same_page() {
        library.clickDeregisterPopupNo();
        Assert.assertEquals(isElementPresent(library.devicePreferencesHeading()), true);
    }

    @Then("user clicks on Deregister button downloaded titles should be removed")
    public void user_clicks_on_deregister_button_downloaded_titles_should_be_removed() {
        library.clickDeregisterDevice();
        library.clickDeregisterPopupYes();
    }

    @Then("user should be able to view eBook carousel with See all and click See all CTA")
    public void user_should_be_able_to_view_e_book_carousel_with_see_all_and_click_see_all_cta() {
        library.clickFormat_Dropdown();
        library.check_eBook_DropDown().click();
        waitFor(2000);
        library.clickEbookSeeAll();
    }

    @When("user is on the library page")
    public void user_is_on_the_library_page() {
        Assert.assertEquals(isElementPresent(library.libFormat()), true);
    }

    @When("user clicks on see all cta in {string} in search results")
    public void userClicksOnSeeAllCtaInInSearchResults(String arg0) {
        library.clickNewsPaperMagazineSeeAll();
    }

    @And("user selects the eAudio title and navigate to title details screen")
    public void userselectsTheEAudioTitleAndNavigateToTitleDetailsScreen() {
        library.clickAvailabilityDropDown();
        library.clickAvailableOption();
        waitFor(2000);
        library.clickFormat_Dropdown();
        library.click_eAudio_BootomDrawer();
        library.clickeAudioTitle();
        waitFor(2000);
    }

    @And("user clicks on the menu option in the reader screen")
    public void userClicksOnTheMenuOptionInTheReaderScreen() {
        library.clickMenuOption();
    }

    @And("user selects the eBook title and navigate to title details screen")
    public void userSelectsTheEBookTitleAndNavigateToTitleDetailsScreen() {
        library.clickAvailabilityDropDown();
        library.clickAvailableOption();
        waitFor(2000);
        library.clickFormat_Dropdown();
        library.click_eBook_BottomDrawer();
        library.clickeBookTitle();
        waitFor(2000);
    }

    @When("user clicks on the Browse tab from the bottom list")
    public void user_clicks_on_the_browse_tab_from_the_bottom_list() {
        library.clickLibraryBrowse();
    }

    @Then("user clicks the young adult fiction option")
    public void user_clicks_the_young_adult_fiction_option() {
        library.clickBrowseYoungAdultFiction();
    }

    @Then("user clicks on the refiner icon")
    public void user_clicks_on_the_refiner_icon() {
        library.clickRefiner();
        library.clickSortBy();
    }

    @Then("user click on the bottom menu option")
    public void user_click_on_the_bottom_menu_option() {
        library.clickMenuBottom();
    }

    @When("user searches for a keyword {string} and navigate to search results screen")
    public void user_searches_for_a_keyword_and_navigate_to_search_results_screen(String title) {
        search.searchkeyWord(title);
        search.click_Search_btn();
    }

    @And("user should be able to view video widgets in the my library screen")
    public void userShouldBeAbleToViewVideoWidgetsInTheMyLibraryScreen() {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Widget_Carousel())) {
//                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Widget_Carousel().isDisplayed(), true);
    }


    @And("user should be able to view vBook widgets in the My Library screen")
    public void userShouldBeAbleToViewVBookWidgetsInTheMyLibraryScreen() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Diff_Publishers())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Widget_Carousel().isDisplayed(), true);
    }

    @When("user tap advance search cta")
    public void user_tap_advance_search_cta() {
//        isElementPresent(library.advancedSearch());
        waitFor(3000);
//        Assert.assertEquals(isElementPresent(library.advancedSearchLib()), true);
        library.clickAdvancedSearch();
//        System.out.println("Advanced search has been clicked");
//        jsClick(advancedSearchLib);
    }

    @And("user should able to view bottom tray Navigation")
    public void user_should_able_to_view_bottom_tray_Navigation() {
        Assert.assertEquals(isElementPresent(library.getMyshelf()), true);
        Assert.assertEquals(isElementPresent(library.getLibrary()), true);
        Assert.assertEquals(isElementPresent(library.getMenu()), true);
        Assert.assertEquals(isElementPresent(library.getBrowse()), true);
        Assert.assertEquals(isElementPresent(library.getPrograms()), true);

    }

    @And("user should not able to view bottom tray Navigation")
    public void user_should_not_to_view_bottom_tray_Navigation() {
        Assert.assertEquals(isElementPresent(library.getMyshelf()), false);

    }

    @And("user navigates to listing page of resource hub")
    public void user_navigates_to_listing_page_of_resource_hub() {
        waitFor(2000);
        library.navigatetoLearnMore();
        Assert.assertEquals(isElementPresent(library.getHeader_learnMore()), true);

    }

    @And("user lands on manage profile screen")
    public void user_lands_on_manage_profile_screen() {
        waitFor(2000);
        library.clik_profileIcon();
        waitFor(2000);
        library.clik_profileIcon();
        waitFor(3000);

    }

    @And("user selects menu options")
    public void user_selects_menu_options() {
        login.clickFooterMenu();
    }

    @And("user lands on menu screen")
    public void user_lands_on_menu_screen() {
        waitFor(2000);
        Assert.assertEquals(isElementPresent(profilePage.profile_details_page()), true);
    }

    @And("user navigates to preference screen")
    public void user_navigates_to_preference_screen() {
        login.navigate_PerferenceMenu();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(profilePage.profile_details_page()), true);
    }

    @And("user navigates to help screen")
    public void user_navigates_to_help_screen() {
        library.clik_profileIcon();
        login.navigate_helpMenu();
    }

    @And("user navigates to patron support screen")
    public void user_navigates_to_patron_support_screen() {
        library.clik_profileIcon();
        login.navigate_Patron_Support_Menu();

    }

    @And("user navigates to About us screen")
    public void user_navigates_to_About_us_screen() {
        library.clik_profileIcon();
        login.navigate_Aboutus();
    }

    @And("user navigates to Privacy policy screen")
    public void user_navigates_to_Privacy_policy_screen() {
        library.clik_profileIcon();
        login.navigate_Privacy_Policy_Menu();

    }

    @And("user navigates to Terms and condition screen")
    public void user_navigates_to_Terms_and_condition_screen() {
        library.clik_profileIcon();
        login.navigate_termConditions();
    }

    @And("user selects pencil icon of adult profile")
    public void user_selects_pencil_icon_of_adult_profile() {
        manageProfile.editBtnClick();
        manageProfile.adultprofileSelection();
    }

    @And("user navigate to profile listing screen")
    public void user_navigate_to_profile_listing_screen() {
        Assert.assertTrue(login.homePgNav());
    }

    @And("user selects intrest survey")
    public void user_selects_intrest_survey() {
        profilePage.clickViewMyInterest();
    }

    @And("user lands on intrest survey screen")
    public void user_lands_on_intrest_survey_screen() {
        Assert.assertEquals(isElementPresent(login.getReadingList_Title()), true);

    }

    @And("user navigate to Thirdparty Tier1 screen")
    public void user_navigate_to_Thirdparty_Tier1_screen() {
        for (int i = 0; i < 8; i++) {
//            swipeDown();
            if (isElementPresent(library.getThirdparty_SeeAlllink())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.getThirdparty_SeeAlllink()), true);
    }

    @And("user navigate to Thirdparty Tier2 screen")
    public void user_navigate_to_Thirdparty_Tier2_screen() {
        waitFor(2000);
        library.click_seeAll_thirdParty();
        waitFor(4000);
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(library.getThirdparty_SeeAlllink())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.getThirdparty_SeeAlllink()), true);
    }

    @And("user navigate to Thirdparty Tier3 screen")
    public void user_navigate_to_Thirdparty_Tier3_screen() {
        library.tier3_detail_page();
    }

    @And("user is navigated to the eAudio Reader screen")
    public void userIsNavigatedToTheEAudioReaderScreen() {
        Assert.assertEquals(library.verifyMenuOption(), true);
    }

    @Then("user should be able to view video carousel with See all and click See all CTA")
    public void userShouldBeAbleToViewVideoCarouselWithSeeAllAndClickSeeAllCTA() {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
        library.video_Carousel_SeeAll().click();
    }

    @Then("user should be able to view vBook carousel with See all and click See all CTA")
    public void userShouldBeAbleToViewVBookCarouselWithSeeAllAndClickSeeAllCTA() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);
        library.vBook_Carousel().click();
    }

    @And("user clicks on the refiner icon in list screen")
    public void userClicksOnTheRefinerIconInListScreen() {
        library.clickRefinerBTN();
        waitFor(3000);
    }

    @And("user should not able to view boundless footer in bottom of view pages such as Library, My Shelf, Browse, Programs etc")
    public void userShouldNotAbleToViewBoundlessFooterInBottomOfViewPagesSuchAsLibraryMyShelfBrowseProgramsEtc() {
        tier1LandingPage.clickMyShelf();
        Assert.assertFalse(isElementPresent(library.boundlessLogoNew()));
        login.clickmylibrary();
        Assert.assertFalse(isElementPresent(library.boundlessLogoNew()));
        menu.clickBrowse();
        Assert.assertFalse(isElementPresent(library.boundlessLogoNew()));
        hold.clickPrograms();
        Assert.assertFalse(isElementPresent(library.boundlessLogoNew()));

    }

    @And("user click on Menu in the bottom navigation bar")
    public void userClickOnMenuInTheBottomNavigationBar() {
        holds.clickMenu();

    }

    @And("user should be able to view boundless footer in Menu page and system should say Boundless By Baker & Taylor")
    public void userShouldBeAbleToViewBoundlessFooterInMenuPageAndSystemShouldSayBoundlessByBakerTaylor() {
        Assert.assertTrue(isElementPresent(library.boundlessLogoNew()));
    }

    @And("user should be able to view boundless footer in About us screen and system should say Boundless By Baker & Taylor")
    public void userShouldBeAbleToViewBoundlessFooterInAboutUsScreenAndSystemShouldSayBoundlessByBakerTaylor() {
        Assert.assertTrue(isElementPresent(library.boundlessLogoNew()));
    }

    @And("user Clicks on back button to view the menu screen")
    public void userClicksOnBackButtonToViewTheMenuScreen() {
        profile.clickBackbutton();
    }

    @And("user should be able to view boundless footer in Terms & Condition screen and system should say Boundless By Baker & Taylor")
    public void userShouldBeAbleToViewBoundlessFooterInTermsConditionScreenAndSystemShouldSayBoundlessByBakerTaylor() {
        Assert.assertTrue(isElementPresent(library.boundlessLogoNew()));
    }

    @And("user clicks on Privacy Policy in Menu screen")
    public void userClicksOnPrivacyPolicyInMenuScreen() {
        menu.clickonPrivacy();
    }

    @And("user should be able to view boundless footer in Privacy Policy screen and system should say Boundless By Baker & Taylor")
    public void userShouldBeAbleToViewBoundlessFooterInPrivacyPolicyScreenAndSystemShouldSayBoundlessByBakerTaylor() {
        Assert.assertTrue(isElementPresent(library.boundlessLogoNew()));
    }

    @Then("user should be able to view book of the month widget")
    public void userShouldBeAbleToViewBookOfTheMonthWidget() {
        Assert.assertEquals(isElementPresent(library.bookOfTheMonthWidget()), true);
        Assert.assertEquals(isElementPresent(library.bookOfTheMonthText()), true);

    }

    @And("user should be able to view the multiple titles in stack jacket format")
    public void userShouldBeAbleToViewTheMultipleTitlesInStackJacketFormat() {

    }

    @And("user should be able to view title description below the title card")
    public void userShouldBeAbleToViewTitleDescriptionBelowTheTitleCard() {
        Assert.assertEquals(isElementPresent(library.bookOfTheMonthDesc()), true);
    }

    @And("user should be able to view switching title description every time the user scrolls left or right")
    public void userShouldBeAbleToViewSwitchingTitleDescriptionEveryTimeTheUserScrollsLeftOrRight() {
        Assert.assertEquals(isElementPresent(library.bookOfTheMonthDesc()), true);
        scroll(DriverManager.getDriver(),0.6,0.3,0.4,0.3);
        logger.info("Title has been swiped from left to right");
    }

    @And("user should be able to redirected to the respective title detail after tap on the title card")
    public void userShouldBeAbleToRedirectedToTheRespectiveTitleDetailAfterTapOnTheTitleCard() {
        library.clickBookOfTheMonthTitle();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(library.titleDetailsPage()), true);
    }

    @And("user should be able to view maximum {int} titles with all format types like ebook,eaudio,video and videobook in stack jacket format")
    public void userShouldBeAbleToViewMaximumTitlesWithAllFormatTypesLikeEbookEaudioVideoAndVideobookInStackJacketFormat(int arg0) {
        for (int i = 0; i < library.bookOfTheMonthTitleList().size(); i++) {
            logger.info("Books count "+i);
        }
    }

    @And("user should be able to view Video and VBook in format dropdown in library page")
    public void userShouldBeAbleToViewVideoVBookInFormatDropdownInLibraryPage() {
        library.libFormat().click();
        Assert.assertEquals(library.check_Video_BottomDrawer().isDisplayed(), true);
        Assert.assertEquals(library.check_vBook_BottomDrawer().isDisplayed(), true);
    }

    @And("user should select the Video in the dropdown")
    public void userShouldSelectTheVideoInTheDropdown() {
        library.click_Video_BottomDrawer();
    }

//    @And("user should be be able to view Videos in the library page")
//    public void userShouldBeBeAbleToViewVideosInTheLibraryPage() {
//        Assert.assertEquals(library.video_Carousel_Format().isDisplayed(), true);
//    }

    @And("user should select the vBook in the dropdown")
    public void userShouldSelectTheVBookInTheDropdown() {
        library.click_vBook_BottomDrawer();
    }

    @And("user should be be able to view vBooks in the library page")
    public void userShouldBeBeAbleToViewVBooksInTheLibraryPage() {
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);
    }
    @And("user should tap on Checkers Library Tv See All cta")
    public void userShouldTapOnCheckersLibraryTvSeeAllCta() {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        library.clickCheckersLibraryTVSeeAll();
    }

    @And("user should tap on Videobooks See All cta")
    public void userShouldTapOnVideobooksSeeAllCta() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        library.clickVideoBooksSeeAll();
    }

    @And("user should not be able to view see all cta displayed because of maximum {int} titles in stack jacket format")
    public void userShouldNotBeAbleToViewSeeAllCtaDisplayedBecauseOfMaximumTitlesInStackJacketFormat(int arg0) {
        logger.info("See all button will not show");
    }

    @When("user should select any video in popular Videos carousal")
    public void userShouldSelectAnyVideoInPopularVideosCarousal() {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
        library.click_video_title_card();
    }

    @Then("user should be able to see the CTAs as same as eBook and eAudio")
    public void userShouldBeAbleToSeeTheCTAsAsSameAsEBookAndEAudio() {
        Assert.assertTrue(isElementPresent(program.verifyPrimaryCTA()));
        Assert.assertTrue(isElementPresent(library.wishlistCTATier3()));
        Assert.assertTrue(isElementPresent(library.shareCTATier3()));
    }

    @And("user verify clicking on any CTAs will behave as same as eBook and eAudio")
    public void userVerifyClickingOnAnyCTAsWillBehaveAsSameAsEBookAndEAudio() {

    }

    @Then("user should tap on vbook carousal")
    public void userShouldTapOnVbookCarousal() {
        library.libFormat().click();
        library.click_Video_BottomDrawer();
    }
    @Then("user should tap on video carousal")
    public void userShouldTapOnVideoCarousal() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
    }

    @Then("user tap on advanced search for ebooks")
    public void userTapOnAdvancedSearchForEbooks() {
        library.clickAdvancedSearch();
        search.clickEbooksRadio();
        search.tapAvailableNowRadio();
    }


    @Then("user tap on advanced search for eAudio")
    public void userTapOnAdvancedSearchForEAudio() {
        library.clickAdvancedSearch();
        search.clickEaudioRadio();
        search.tapAvailableNowRadio();
    }


    @When("user should select any vBook in Videobook carousal")
    public void userShouldSelectAnyVBookInVideobookCarousal() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        for (int i = 0; i <= 10; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
        library.click_vBook_title_card();
    }

    @And("user click on the see All of featured newspaper and magazine")
    public void userClickOnTheSeeAllOfFeaturedNewspaperAndMagazine() {
        Assert.assertTrue(isElementPresent(library.featuredseeallThirdparty()));
        library.clickNewsPaperMagazineSeeAll();
    }

}
