package parallel;

import com.reusableMethods.CommonActions;
import io.appium.java_client.MobileElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

import java.util.NoSuchElementException;

public class MyShelf_StepDef extends CommonActions {

    LoginPage login = new LoginPage(DriverManager.getDriver());
    public static final Logger logger = LoggerFactory.getLogger(MyShelf_StepDef.class);

    MyLibrary library = new MyLibrary(DriverManager.getDriver());

    ProfilePage profile = new ProfilePage(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo tier1LandingPage = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier2_TitlelistPage_VBookandVideo tier2TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    MyShelf myShelf = new MyShelf(DriverManager.getDriver());
    TitleDetails details = new TitleDetails(DriverManager.getDriver());

    @When("^user is able to tap on checkout cta from mystuff screen and navigate to checkedout screen$")
    public void user_is_able_tap_on_checkout_cta_from_mystuff_screen_and_navigate_to_checkedout_screen() throws Throwable {
        tier1LandingPage.clickMyShelf();
        waitFor(5000);
        tier1LandingPage.clickCheckout_CTA();
    }

    @Then("^user should be able to view the action cta for the video and vbooks titles$")
    public void user_should_be_able_to_view_the_action_cta_for_the_video_and_vbooks_titles() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickVideos_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideo_action_CTA()), true);
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickvBook_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
    }

    @And("^library should have subscription to video and vbooks third party and video and vbooks carousel enabled by library admin$")
    public void library_should_have_subscription_to_video_and_vbooks_third_party_and_video_and_vbooks_carousel_enabled_by_library_admin() throws Throwable {
        logger.info("Admin settings - video and vbooks");
    }

    @And("^system should display cta based on the title status$")
    public void system_should_display_cta_based_on_the_title_status() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
        logger.info("Most of the checked out videos/ vbooks have the play cta");
    }

    @And("^user should be able to see the title checked out and not started watching the title$")
    public void user_should_be_able_to_see_the_title_checked_out_and_not_started_watching_the_title() throws Throwable {
        logger.info("video/ vbooks are in play status");
    }

    @And("^user should be able to see play as primary cta and return and renew are the secondary cta$")
    public void user_should_be_able_to_see_play_as_primary_cta_and_return_and_renew_are_the_secondary_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
    }

    @And("^user should be able to see the title checked out and started watching and exit without complete$")
    public void user_should_be_able_to_see_the_title_checked_out_and_started_watching_and_exit_without_complete() throws Throwable {
        tier1LandingPage.clickPlay_Video();

        tier1LandingPage.clickBack_Button();
    }

    @And("^user should be able to see resume as primary cta and return and renew are the secondary cta$")
    public void user_should_be_able_to_see_resume_as_primary_cta_and_return_and_renew_are_the_secondary_cta() throws Throwable {
        logger.info("see resume as primary cta and return and renew are the secondary cta");
    }

    @When("if user already saved some interest survey")
    public void if_user_already_saved_some_interest_survey() {
        login.readingInterestPopupback();
    }

    @When("user click on menu and select {string}")
    public void user_click_on_menu_and_select(String string) {
        tier1LandingPage.clickMyShelf();
    }

    @When("user click on {string} Cta in Based on interest carousal")
    public void user_click_on_cta_in_based_on_interest_carousal(String string) {
        waitFor(2000);
        myShelf.clickSeeAll();
//    	Assert.assertEquals(isElementPresent(myShelf.readingInterestSeeAll()),true);
//    	Assert.assertEquals(myShelf.readingInterestSeeAll().getText(),"see all");
//    	myShelf.readingInterestSeeAll().click();
    }

    @Then("verify navigate to title list screen")
    public void verify_naviagate_to_title_list_screen() {
        Assert.assertEquals(isElementPresent(myShelf.basedOnInterestTitle()), true);
    }

    @Then("user click on {string} cta navigate to interest survey screen")
    public void user_click_on_cta_navigate_to_interest_survey_screen(String string) {
        myShelf.clickEditPreferences();
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
    }

    @Then("user update the interest topic and click save cta")
    public void user_update_the_interest_topic_and_click_save_cta() {
        myShelf.clickReadingPreference();
        myShelf.clickReadingInterestSaveBTN();

    }

    @Then("user navigate to title list screen if interest topics have recommendation title")
    public void user_navigate_to_title_list_screen_if_interest_topics_have_recommendation_title() {
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
        profile.clickBack_Btn();
    }

    @Then("user update the interest topic and without save interest click on back")
    public void user_update_the_interest_topic_and_without_save_interest_click_on_back() {
        myShelf.clickReadingPreference();
        login.readingInterestPopupback();
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
    }

    @Then("user navigate to title list screen without change any title")
    public void user_navigate_to_title_list_screen_without_change_any_title() {
        logger.info("List displayed without any change");
    }

    @When("user clicks on the myshelf icon")
    public void user_clicks_on_the_myshelf_icon() {
        myShelf.clickMyShelf();
    }

    @When("user clicks on the checkouts pill")
    public void user_clicks_on_the_checkouts_pill() {
        myShelf.clickCheckout_CTA();
    }

    @Then("user clicks on the hold pill")
    public void user_clicks_on_the_hold_pill() {
        myShelf.clickmyShelfHoldBTN();
    }

    @Then("user clicks on the wishlist pill")
    public void user_clicks_on_the_wishlist_pill() {
        myShelf.clickwishlistBTN();
    }

    @Then("user clicks on the history pill")
    public void user_clicks_on_the_history_pill() {
        myShelf.clickrecommendation();
        myShelf.clickdownloadsBTN();
        myShelf.clickHistoryBTN();
    }

    @And("user clicks on the Recommendation pills")
    public void userClicksOnTheRecommendationPills() {
        myShelf.clickrecommendation();
        waitFor(3000);
    }

    @And("user clicks on the Download CTA")
    public void userClicksOnTheDownloadCTA() {
        myShelf.clickdownloadsBTN();
        waitFor(3000);
    }

    @And("user should be able to view the titles in my wishlist")
    public void userShouldBeAbleToViewTheTitlesInMyWishlist() {
        Assert.assertTrue(myShelf.getWishlistTitle().isDisplayed());
        myShelf.getWishlistTitle().click();
        logger.info("Title successfully added in wishlist");
    }

    @And("user removes the titles from checkouts screen")
    public void userRemovesTheTitlesFromCheckoutsScreen() {
        try {
            myShelf.clickholds();
            isElementPresent(myShelf.getHolds_page());
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.tapReturnTitle();
            myShelf.tapOK();
            logger.info("Titles removed from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No titles in checkout");
        }
    }

    @And("user should able to add the titles back to wishlist")
    public void userShouldAbleToAddTheTitlesBackToWishlist() {
        try {
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            details.clickWishList();
            details.getBackButton().click();
            details.clickWishList();
            Assert.assertTrue(myShelf.getWishlistTitle().isDisplayed());
            logger.info("Title successfully added in back to wishlist from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No Titles in checkout");
        }
    }

    @And("user removes the titles from checkouts screen and wishlist")
    public void userRemovesTheTitlesFromCheckoutsScreenAndWishlist() {
        try {
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            details.clickWishList();
            myShelf.tapOnSecondaryCTA();
            myShelf.tapReturnTitle();
            myShelf.tapOK();
            logger.info("Titles removed from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No titles in checkout and wishlist");
        }

    }

    @And("user verify the title count in myshelf checkout")
    public void userVerifyTheTitleCountInMyshelfCheckout() {
        WaitForMobileElement(myShelf.getCheckout_page());
        myShelf.clickCheckout();
        int pillsCount = myShelf.getCheckoutPillsCount();
        System.out.println(pillsCount);
        int titlesCount = myShelf.getCheckoutTitlesCount();
        System.out.println(titlesCount);
        Assert.assertEquals(pillsCount, titlesCount);
        logger.info("Checout pills and titles counts are equal");
    }

    @And("user should be able to return tha eBook title in title details screen")
    public void userShouldBeAbleToReturnThaEBookTitleInTitleDetailsScreen() {

      //      WaitForMobileElement(details.getBackButton());
      //      ClickOnMobileElement(details.getBackButton());
        WaitForMobileElement(details.getSecondaryDropdownCTA());
        swipeDown();
        myShelf.tapOnSecondaryCTA();
        myShelf.returnEBook();
        myShelf.tapOK();
        WaitForMobileElement(details.getCheckoutCTA());
        Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
        logger.info("eBook successfully returned");
    }

    @And("user should be able to return tha Video title in title details screen")
    public void userShouldBeAbleToReturnThaVideoTitleInTitleDetailsScreen() {
        WaitForMobileElement(details.getSecondaryDropdownCTA());
        swipeDown();
        myShelf.tapOnSecondaryCTA();
        myShelf.returnEBook();
        myShelf.tapOK();
        WaitForMobileElement(details.getCheckoutCTA());
        Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
        logger.info("eBook successfully returned");
    }

    @And("user should be able to return the eBook title in checkout screen")
    public void xuserShouldBeAbleToReturnTheEBookTitleInCheckoutScreen() {
        try {
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.returnEBook();
            myShelf.tapOK();
            if (isElementPresent(details.getSecondaryDropdownCTA())) {
                details.getBackButton().click();
            } else {
                details.getBackButton().click();
            }
            Assert.assertTrue(isDisplayed(myShelf.getNo_titleFound()));
            logger.info("No titles in myshelf checkout ");
        } catch (AssertionError e) {
            logger.info("Titles are already available in checkout screen");
            e.printStackTrace();
        }
    }

    @And("user should be able to return tha VBook title in title details screen")
    public void userShouldBeAbleToReturnTheVBookTitleInTitleDetailsScreen() {

        tier1LandingPage.title_Cover_Image().click();
        {
            WaitForMobileElement(tier1LandingPage.title_txt);
            for (int i = 0; i < 5; i++) {
                swipeDown();
                if (isElementPresent(tier1LandingPage.return_title)) {
                    break;
                } else {
                    swipeDown();
                }
            }
            ClickOnMobileElement(tier1LandingPage.return_title);
            WaitForMobileElement(tier1LandingPage.checkVBookCheckoutCTAInTier1());
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCheckoutCTAInTier1()), true);
            logger.info("Video Title successfully returned");


        }
    }
    @And("user should be able to return tha Videos title in title details screen")
    public void userShouldBeAbleToReturnTheVideoTitleInTitleDetailsScreen() {

        tier1LandingPage.title_Cover_Image().click();
        {
            WaitForMobileElement(tier1LandingPage.title_txt);
            for (int i = 0; i < 5; i++) {
                swipeDown();
                if (isElementPresent(tier1LandingPage.return_title)) {
                    break;
                } else {
                    swipeDown();
                }
            }
            ClickOnMobileElement(tier1LandingPage.return_title);
            WaitForMobileElement(tier1LandingPage.checkVBookCheckoutCTAInTier1());
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCheckoutCTAInTier1()), true);
            logger.info("Video Title successfully returned");


        }
    }

    @And("user should be able to return tha eAudio title in title details screen")
    public void userShouldBeAbleToReturnThaEAudioTitleInTitleDetailsScreen() {
        if (isElementPresent(details.getSecondaryDropdownCTA())) {
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.returnEAudio();
            myShelf.tapOK();
            WaitForMobileElement(details.getCheckoutCTA());
            Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
            logger.info("eAudio successfully returned");
        } else {
            myShelf.tapCheckedOutTitles();
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.returnEAudio();
            myShelf.tapOK();
            WaitForMobileElement(details.getCheckoutCTA());
            Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
            logger.info("eAudio successfully returned");
        }
    }

    @And("user open title form check out screen")
    public void userOpenTitleFormCheckOutScreen() {
        myShelf.clickCheckout();
        Assert.assertTrue(myShelf.getContinueBtn().isDisplayed());
        logger.info("Continue Primary CTA is displayed");
        myShelf.tapCheckedOutTitles();
    }

    @And("user download eBook form check out screen")
    public void userDownloadEBookFormCheckOutScreen() {
        myShelf.clickCheckout();
        myShelf.tapEBookDownload();
    }

    @And("user download eAudio form check out screen")
    public void userDownloadEAudioFormCheckOutScreen() {
        myShelf.clickCheckout();
        myShelf.tapEAudioDownload();
    }

    @And("user verify continue button is displayed")
    public void userVerifyContinueButtonIsDisplayed() {
        Assert.assertTrue(myShelf.getContinueBtn().isDisplayed());
    }

    @And("user tap on continue button and verify eBook reader is opened in myshelf checkout")
    public void userTapOnContinueButtonAndVerifyEBookReaderIsOpenedInMyshelfCheckout() {
        myShelf.tapContinueBtn();
        try {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
        } catch (Exception e) {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
            e.printStackTrace();
        }
    }

    @And("verify user should be able to renew the title and verify in myshelf checkout")
    public void verifyUserShouldBeAbleToRenewTheTitleAndVerifyInMyshelfCheckout() {
        if (isElementPresent(myShelf.getContinueBtn())) {
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapRenewCheckout();
            myShelf.tapOK();
        }
    }

    @And("verify user should not be should be able see the renew in secondary cta and tap on remove download")
    public void verifyUserShouldNotBeShouldBeAbleSeeTheRenewInSecondaryCtaAndtapOnRemoveDownload() {
        if (isElementPresent(myShelf.getContinueBtn())) {
            myShelf.tapTitleSecondaryCTA();
            logger.info("Renew CTA is not displayed");
            Assert.assertFalse(isElementPresent(myShelf.getRenewCheckout()));
            myShelf.tapRemoveDownload();
            myShelf.tapOK();
        }
    }

    @And("verify user should not be should be able see the renew in secondary cta and tap on add to wishlist cta")
    public void verifyUserShouldNotBeShouldBeAbleSeeTheRenewInSecondaryCtaAndTapOnAddToWishlistCta() {
        if (isElementPresent(myShelf.getContinueBtn())) {
            myShelf.tapTitleSecondaryCTA();
            logger.info("Renew CTA is not displayed");
            Assert.assertFalse(myShelf.getRenewCheckout().isDisplayed());
            myShelf.tapAddToWishlist();
        }
    }

    @And("verify user should be able to see the download primary cta")
    public void verifyUserShouldBeAbleToSeeTheDownloadPrimaryCta() {
        //myShelf.clickCheckout();
        if (isElementPresent(myShelf.getContinueBtn())) {
            Assert.assertTrue(myShelf.getDownloadCta().isDisplayed());
        }
    }

    @And("verify user should be able to continue reading by tapping on continue secondary cta")
    public void verifyUserShouldBeAbleToContinueReadingByTappingOnContinueSecondaryCta() {
        if (isElementPresent(myShelf.getContinueBtn())) {
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapReadOnline();
        }
    }

    @And("verify user should be able to add to wishlist in myshelf checkout")
    public void verifyUserShouldBeAbleToAddToWishlistInMyshelfCheckout() {
        myShelf.tapTitleSecondaryCTA();
        myShelf.tapAddToWishlist();
    }

    @And("verify user should be able to remove wishlist secondary cta")
    public void verifyUserShouldBeAbleToSeeTheRemoveWishlistSecondaryCta() {
        if (isElementPresent(myShelf.getContinueBtn())) {
            myShelf.tapTitleSecondaryCTA();
            Assert.assertTrue(myShelf.getRemoveWishlistCTA().isDisplayed());
            ClickOnMobileElement(myShelf.getRemoveWishlistCTA());
        }
    }

    @And("user should be able to return the title in myshelf checkout")
    public void userShouldBeAbleToReturnTheTitleInMyshelfCheckout() {
        myShelf.clickCheckout();
        myShelf.tapTitleSecondaryCTA();
        myShelf.tapEBookReturn();
        myShelf.tapOK();
    }

    @And("verify no titles in myshelf checkout")
    public void verifyNoTitlesInMyshelfCheckout() {
        try {
            WaitForMobileElement(myShelf.getNo_titleFound());
            Assert.assertTrue(myShelf.getNo_titleFound().isDisplayed());
            logger.info("No titles in myshelf checkout");
        } catch (NoSuchElementException e) {
            logger.info("No titles in myshelf checkout");
            e.printStackTrace();
        }

    }

    @And("user open eBook form check out screen")
    public void userOpenEBookFormCheckOutScreen() {
        myShelf.clickCheckout();
        myShelf.openEBook();
    }

    @And("user open eAudio form check out screen")
    public void userOpenEAudioFormCheckOutScreen() {
        myShelf.clickCheckout();
        myShelf.openEAudio();
    }

    @And("verify user should be able to to see the share title option in myshelf")
    public void verifyUserShouldBeAbleToToSeeTheShareTitleOptionInMyshelfCheckout() {
        try {
            WaitForMobileElement(myShelf.getContinueBtn());
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapShareTitle();
            WaitForMobileElement(myShelf.getShareOptions());
            Assert.assertTrue(myShelf.getShareOptions().isDisplayed());
            logger.info("Multiple share options are displayed");
        } catch (Exception e) {
            logger.info("Multiple share options are displayed");
            e.printStackTrace();
        }

    }

    @And("user download the eBooks from myshelf checkout")
    public void userDownloadTheEBooksFromMyshelfCheckout() {
        myShelf.clickCheckout();
        myShelf.tapContinueBtn();
        try {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
        } catch (NoSuchElementException e) {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
            e.printStackTrace();
        }
        myShelf.tapContinue2Btn();
        try {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
        } catch (NoSuchElementException e) {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
            e.printStackTrace();
        }
    }

    @And("user navigates to my shelf downloads screen")
    public void userNavigatesToMyShelfDownloadsScreen() {
        isElementPresent(myShelf.getWishlist_View());
        myShelf.clickwishlist();
        isElementPresent(myShelf.getPurchase_page());
        myShelf.getPurchase_page().click();
        myShelf.clickdownload();
    }

    @And("user should return the one titles form downloads and verify titles removed successfully")
    public void userShouldReturnTheOneTitlesFormDownloadsAndVerifyTitlesRemovedSuccessfully() {
        myShelf.tapTitleSecondaryCTA();
        myShelf.tapRemoveDownload();
        myShelf.tapOK();
    }

    int initialCheckoutTitlesCount;
    int initialWishlistCount;
    int initialHoldsCount;

    @And("user get the count of title in myshelf checkout and wishlist and holds")
    public void userGetTheCountOfTitleInMyshelfCheckoutAndWishlistAndHolds() {
        initialCheckoutTitlesCount = myShelf.getCheckoutPillsCount();
        initialWishlistCount = myShelf.getWishlistPillsCount();
        initialHoldsCount = myShelf.getHoldsPillsCount();
    }

    @And("user navigates to myshelf checkout history")
    public void userNavigatesToMyshelfCheckoutHistory() {
        myShelf.clickwishlist();
        isElementPresent(myShelf.getPurchase_page());
        myShelf.getPurchase_page().click();
        myShelf.clickdownload();
        myShelf.clickHistoryBTN();
    }

    int intialHistoryCount;

    @And("user verify the title count in myshelf checkout history")
    public void userVerifyTheTitleCountInMyshelfCheckoutHistory() {
        intialHistoryCount = myShelf.getHistoryPillsCount();
    }

    @And("user should add the any one title to wishlist")
    public void userAddedTheAnyOneTitleToWishlist() {
        myShelf.tapTitle2SecondaryCTA();
        myShelf.tapAddToWishlist();
    }

    @And("user should checkout the anyone title in myshelf checkout history")
    public void userShouldCheckoutTheAnyoneTitleInMyshelfCheckoutHistory() {
        try {
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapCheckoutSecondaryBtn();
        } catch (NoSuchElementException e) {
            myShelf.tapHoldsSecondaryBtn();
            e.printStackTrace();
            logger.info("titles are in place hold");
        }
    }

    @And("user verify added titles myshelf wishlist and remove from wishlist")
    public void userVerifyAddedTitlesMyshelfWishlist() {
        myShelf.clickdownload();
        ClickOnMobileElement(myShelf.getPurchase_page());
        myShelf.clickwishlist();
        int finalWishlistCount = myShelf.getWishlistPillsCount();
        Assert.assertTrue(initialWishlistCount != finalWishlistCount);
        logger.info("Titles successfully added in myshelf  checkout");
        myShelf.tapTitleSecondaryCTA();
        ClickOnMobileElement(myShelf.getRemoveWishlistCTA());
        logger.info("Titles are removed from wishlist");
    }

    @And("user should be able to verify that added on myshelf checkout and Remove the title")
    public void userShouldBeAbleToVerifyThatAddedOnMyshelfCheckoutAndRemoveTheTitle() {
        myShelf.clickholds();
        int finalHoldsPillsCount = myShelf.getHoldsPillsCount();
        if (finalHoldsPillsCount != initialHoldsCount) {
            Assert.assertTrue(finalHoldsPillsCount != initialHoldsCount);
            logger.info("Titles are to holds");
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapEBookReturn();
            myShelf.tapOK();
        } else {
            myShelf.clickCheckout();
            int finalCheckouPillsCount = myShelf.getCheckoutPillsCount();
            Assert.assertTrue(finalCheckouPillsCount != initialCheckoutTitlesCount);
            logger.info("Titles added to myshelf checkout");
            myShelf.tapTitleSecondaryCTA();
            myShelf.tapEBookReturn();
            myShelf.tapOK();
        }

    }

    @And("user open the title in myshelf checkout")
    public void userOpenTheTitleInMyshelfCheckout() {
        myShelf.tapCheckedOutTitles();
        WaitForMobileElement(details.gettitleDetails_lbl_title());
    }

    @And("user should add the the title to wishlist from checkout histroy screen")
    public void userShouldAddTheTheTitleToWishlist() {
        myShelf.tapTitleSecondaryCTA();
        myShelf.tapAddToWishlist();
    }

    @And("user verify primary and secondary CTA in deleted title")
    public void userVerifyPrimaryAndSecondaryCTAInDeletedTitle() {
        Assert.assertFalse(isElementPresent(details.getPrimaryCta()));
        Assert.assertFalse(isElementPresent(details.getSecondaryDropdownCTA()));
        logger.info("Primary and secondary cta's are not available for deleted titles");
    }

    @And("user open title form checkout history screen")
    public void userOpenTitleFormCheckoutHistoryScreen() {
        myShelf.tapCheckedOutTitles();
    }

    @And("user tap on continue button and verify eBook reader is opened in myshelf downloads and close the reader")
    public void userTapOnContinueButtonAndVerifyEBookReaderIsOpenedInMyshelfDownloadsAndCloseTheReader() {
        myShelf.tapContinueBtn();
        try {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
        } catch (Exception e) {
            WaitForMobileElement(details.getReaderBanner());
            Assert.assertTrue(details.getReaderBanner().isDisplayed());
            logger.info("eBook reader is successfully opened");
            ClickOnMobileElement(details.getReaderBanner());
            WaitForMobileElement(details.getReaderBackBtn());
            ClickOnMobileElement(details.getReaderBackBtn());
            e.printStackTrace();
        }
    }

    int user1InitialDownloadCount;

    @And("user get the count of title in myshelf downloads for first user")
    public void userGetTheCountOfTitleInMyshelfDownloadsForFirstUser() {
        user1InitialDownloadCount = myShelf.getDownloadPillsCount();
    }

    int user2InitialDownloadCount;

    @And("user get the count of title in myshelf downloads for second user")
    public void userGetTheCountOfTitleInMyshelfDownloadsForSecondUser() {
        user2InitialDownloadCount = myShelf.getDownloadPillsCount();
    }

    @And("user verify title count in myshelf downloads for first user")
    public void userVerifyTitleCountInMyshelfDownloadsForFirstUser() {
        int user1FinalDownloadCount = myShelf.getDownloadPillsCount();
        Assert.assertTrue(user1InitialDownloadCount == user1FinalDownloadCount);
        logger.info("Titles are successfully retained in downloads for user1");
    }

    @And("user verify title count in myshelf downloads for secondary user")
    public void userVerifyTitleCountInMyshelfDownloadsForSecondaryUser() {
        int user2FinalDownloadCount = myShelf.getDownloadPillsCount();
        Assert.assertTrue(user2InitialDownloadCount == user2FinalDownloadCount);
        logger.info("Titles are successfully retained in downloads for user2");
    }
}


