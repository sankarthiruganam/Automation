package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Holds;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;
import pom.kidszone.WishList;

public class Mystuff_allscreen_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
	WishList wishlist= new WishList(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);
	
	
	@Given("user tap on login button after user enter kidszone subscription only {string}")
	public void user_tap_on_login_button_after_user_enter_kidszone_subscription_only(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


	@When("user lands on My shelf page")
	public void user_lands_on_my_shelf_page() {
		login.handleNothankspopup();
		myshelf.clickMyself();
		Assert.assertEquals(myshelf.getMyShelf_lbl_footer().isDisplayed(), true);
		logger.info("User lands on MyShelf page");
	}
	@When("click on holds quick CTA")
	public void click_on_holds_quick_cta() {
		holds.clickHolds();
//  		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}
	@Then("user should be able to view holds screen with multiple titles on hold")
	public void user_should_be_able_to_view_holds_screen_with_multiple_titles_on_hold() {
		for (int i = 1; i <= holds.getHolds_Gridview_titles_hdr().size(); i++) {
			if (i == 1)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_Gridview_titles_hdr().get(i)), true);
		}
	}
	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks() {
		Assert.assertEquals(isElementPresent(holds.getHolds_PrimaryActionsbtn()), true);
		Assert.assertEquals(isElementPresent(holds.getHolds_SecondaryActionsbtn()), true);
		
	}
	@Then("user should be able to click on primary button {string} and suspend the hold temporarily for the title which is in on hold")
	public void user_should_be_able_to_click_on_primary_button_and_suspend_the_hold_temporarily_for_the_title_which_is_in_on_hold(String string) throws Throwable {
	    wishlist.clickprimaryoptions();
	    holds.clickSuspendnow();   
	}
	@Then("user should be able to click on {string} and remove the title from hold")
	public void user_should_be_able_to_click_on_and_remove_the_title_from_hold(String string) throws Throwable {
	
		wishlist.clickprimaryoptions();
	    holds.clickRemoveHold();
//		wishlist.clickSecondaryButton();
	}
	

	@Then("user should be able to click on {string} and add the title to the wishlist")
	public void user_should_be_able_to_click_on_and_add_the_title_to_the_wishlist(String string) {
		wishlist.clickprimaryoptions();
	    wishlist.clickaddtoWishList();
	}
	
	@When("user clicks on Checkout History")
	public void user_clicks_on_checkout_history() {
		myshelf.horizzondalView();
	}

	@Then("if title is added to wishlist then user should be able to click on {string} and remove the title from the wishlist")
	public void if_title_is_added_to_wishlist_then_user_should_be_able_to_click_on_and_remove_the_title_from_the_wishlist(String string) {
		wishlist.clickWishList();
		wishlist.clickprimaryoptions();
	    wishlist.clickremoveWishList();
	}
	
	@Then("user should be able to view holds screen with purchase request titles on hold")
	public void user_should_be_able_to_view_holds_screen_with_purchase_request_titles_on_hold() {
		waitFor(3000);
		for (int i = 1; i <= holds.getHolds_Gridview_titles_hdr().size(); i++) {
			if (i == 2)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_Gridview_titles_hdr().get(i)), true);
		}
	}
	
	@When("click on checkout quick CTA and no titles Downloaded")
	public void click_on_checkout_quick_cta_and_no_titles_downloaded() {
		logger.info("user should be able to view quick navigation CTAs as a carousel");
		Assert.assertEquals(isElementPresent(checkout.getMyShelf_lbl_checkouts()), true);
		checkout.navigateCheckout();
		
	}


	@Then("user should be able to view checkout screen")
	public void user_should_be_able_to_view_checkout_screen() {
	    
	}
	@Then("user should be able to view and perform primary and secondary actions for ebooks")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks() {
	    
	}
	@Then("user should be able to click on primary button {string} and navigate to ereader online and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_ereader_online_and_navigate_back_to_checkout_screen(String string) {
      wishlist.clickSecondaryButton();
	}
	@Then("user should be able to click on {string} and navigate to erader of the title to the last read and user navigate back to checkout screen")
	public void user_should_be_able_to_click_on_and_navigate_to_erader_of_the_title_to_the_last_read_and_user_navigate_back_to_checkout_screen(String string) {
		logger.info("user should be able to click on continue and navigate to erader of the title to the last read and user navigate back to checkout screen");
	}
	@Then("navigate back to checkout screen")
	public void navigate_back_to_checkout_screen() {
		login.handleNothankspopup();
		myshelf.getMyShelf_lbl_footer().click();
		checkout.navigateCheckout();
		logger.info("User lands on MyShelf page");
	}
	@Then("user should be able to click on {string} and renew the ebook and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_and_renew_the_ebook_and_navigate_back_to_checkout_screen(String string) {
	    wishlist.clickRenew_Checkout();
	}
	
	@Then("user should be able to view and perform primary and secondary actions for audiobooks")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_audiobooks() {
	   
	}


	@Then("user should be able to click on primary button {string} and navigate to audioplayer online and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_audioplayer_online_and_navigate_back_to_checkout_screen(String string) {
		wishlist.clickSecondaryButton();
	}
	@Then("user should be able to click on {string} and navigate to audio player of the title to the listened location")
	public void user_should_be_able_to_click_on_and_navigate_to_audio_player_of_the_title_to_the_listened_location(String string) {
		logger.info("user should be able to click on continue and navigate to audio player of the title to the listened location");
	}
	@Then("user navigate back to checkout screen")
	public void user_navigate_back_to_checkout_screen() {
		login.handleNothankspopup();
		myshelf.getMyShelf_lbl_footer().click();
		checkout.navigateCheckout();
		logger.info("User lands on MyShelf page");
	}
	@Then("user should be able to click on {string} and navigate to audioplayer online")
	public void user_should_be_able_to_click_on_and_navigate_to_audioplayer_online(String string) {
		logger.info("user should be able to if audio book avilable click on");
	    
	}
	@Then("user should be able to click on {string} and return the title and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_and_return_the_title_and_navigate_back_to_checkout_screen(String string) {
	   logger.info("user should be able to return title");
	}
	
	@When("click on checkout quick CTA")
	public void click_on_checkout_quick_cta() {
	    
	}


	@Then("user should be able to view checkout screen along with downloaded title")
	public void user_should_be_able_to_view_checkout_screen_along_with_downloaded_title() {
	   
	}
	@Then("user should be able to click on Primary button {string} and navigate to eareder for the downloaded title")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_eareder_for_the_downloaded_title(String string) {
	    
	}
	@Then("user should be able to click on primary button {string} and navigate to erader of the title to the last read")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_erader_of_the_title_to_the_last_read(String string) {
	   
	}
	@Then("user should be able to click on {string} cta to remove the downloaded titles")
	public void user_should_be_able_to_click_on_cta_to_remove_the_downloaded_titles(String string) {
	   
	}
	
	@Then("user should be able to click on primary button {string} and navigate to audioplayer online")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_audioplayer_online(String string) {
	   
	}


	@Then("user should be able to click on primary button {string} and navigate to audio player of the title to the listened location")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_audio_player_of_the_title_to_the_listened_location(String string) {
	   
	}
	
	@When("click on Purchase Requests quick CTA")
	public void click_on_purchase_requests_quick_cta() {
	    holds.clickPurchaseRequest_button();
	}


	@Then("user should be able to view purchase request screen with titles which is not available for checkouts")
	public void user_should_be_able_to_view_purchase_request_screen_with_titles_which_is_not_available_for_checkouts() {
	    
	}
	@Then("user should be able to click on primary button {string} and put title on hold")
	public void user_should_be_able_to_click_on_primary_button_and_put_title_on_hold(String string) {
	   holds.clickSecondarybutton();
	   
	}
	@Then("user navigate back to purchase request screen")
	public void user_navigate_back_to_purchase_request_screen() {
	    
	}
	@Then("user should be able to click on {string} and cancel the purchase request for the title")
	public void user_should_be_able_to_click_on_and_cancel_the_purchase_request_for_the_title(String string) {
	   
	}
	
	@Then("user should be able to view suspend hold titles in purchase request screen")
	public void user_should_be_able_to_view_suspend_hold_titles_in_purchase_request_screen() {
	   
	}


	@Then("user should be able to click on primary button {string} and resume the suspended hold for the title")
	public void user_should_be_able_to_click_on_primary_button_and_resume_the_suspended_hold_for_the_title(String string) {
		holds.clickActivateHold_button();
		
	}
	@Then("user should be able to click on {string} cta and to remove hold for the title")
	public void user_should_be_able_to_click_on_cta_and_to_remove_hold_for_the_title(String string) {
	   

	}
	@Then("And user should be able to click on {string} and cancel the purchase request for the title")
	public void and_user_should_be_able_to_click_on_and_cancel_the_purchase_request_for_the_title(String string) {
	    

	}

	@Then("user should be able to view purchase request screen with titles which is available for checkouts")
	public void user_should_be_able_to_view_purchase_request_screen_with_titles_which_is_available_for_checkouts() {
	   

	}


	@Then("user should be able to click on primary button {string} and to checkout the title")
	public void user_should_be_able_to_click_on_primary_button_and_to_checkout_the_title(String string) {
	  
	}
	
	@Then("user should be able to view activate hold titles in purchase request screen")
	public void user_should_be_able_to_view_activate_hold_titles_in_purchase_request_screen() {
	   
	}


	@Then("user should be able to click on primary button {string} and to remove hold for the title")
	public void user_should_be_able_to_click_on_primary_button_and_to_remove_hold_for_the_title(String string) {
	    
	}
	@Then("user should be able to click on {string} cta to activate the hold")
	public void user_should_be_able_to_click_on_cta_to_activate_the_hold(String string) {
	   
	}

	@When("click on History quick CTA")
	public void click_on_history_quick_cta() {
		holds.clickPurchaseRequest_button();
		holds.clickdownLoad();
		waitFor(2000);
//		horizontalSwipe(holds.getHistory_titles_hdr());
//		horizontalSwipe(holds.getHistory_titles_hdr());		
		holds.clickHistory_button();
	}
	@Then("user should be able to click on primary button {string} and remove the title from checkout history of the user")
	public void user_should_be_able_to_click_on_primary_button_and_remove_the_title_from_checkout_history_of_the_user(String string) {
	   holds.clickprimaryoptions();
	}
	
	@Then("user should be able to view and click on {string} action to remove the downloaded content for the title")
	public void user_should_be_able_to_view_and_click_on_action_to_remove_the_downloaded_content_for_the_title(String string) {
	  holds.clickSecondarybutton();
	}
	
	@Then("user should be able to view checkout history screen with copies not available titles which is already checkout and return")
	public void user_should_be_able_to_view_checkout_history_screen_with_copies_not_available_titles_which_is_already_checkout_and_return() {
		Assert.assertEquals(isElementPresent(checkout.getcheckoutsHistory()), true);
	}


	@Then("user should be able to click on secondary actions {string} and to put the titles on hold")
	public void user_should_be_able_to_click_on_secondary_actions_and_to_put_the_titles_on_hold(String string) {
		holds.clickSecondarybutton();
	}
	@Then("user should be able to click on secondary actions {string} and to add the titles to wishlist")
	public void user_should_be_able_to_click_on_secondary_actions_and_to_add_the_titles_to_wishlist(String string) {
		holds.clickSecondarybutton();
	}
	@Then("if user already the titles to wishlist and user should be able to click on secondary action {string}")
	public void if_user_already_the_titles_to_wishlist_and_user_should_be_able_to_click_on_secondary_action(String string) {
		 holds.clickRemovewishlist();
	}
	
	@When("click on download cta")
	public void click_on_download_cta() {
	   
	}


	@Then("user should be able to view download screen with ebook title checked out and downloaded")
	public void user_should_be_able_to_view_download_screen_with_ebook_title_checked_out_and_downloaded() {
	    
	}
	@Then("user should be able to view and perform primary actions for ebooks")
	public void user_should_be_able_to_view_and_perform_primary_actions_for_ebooks() {
	   
	}
	@Then("user should be able to click on primary button {string} and navigates to ereader screen")
	public void user_should_be_able_to_click_on_primary_button_and_navigates_to_ereader_screen(String string) {
	    
	}
	@Then("user should be able to view and click on secondary button {string} and to delete the download")
	public void user_should_be_able_to_view_and_click_on_secondary_button_and_to_delete_the_download(String string) {
	
	}
	@Then("user should be able to view and click on secondary button {string} and return the titles")
	public void user_should_be_able_to_view_and_click_on_secondary_button_and_return_the_titles(String string) {
	   
	}
	@Then("user should be able to view and click on secondary actions {string} and if titles is available to renew")
	public void user_should_be_able_to_view_and_click_on_secondary_actions_and_if_titles_is_available_to_renew(String string) {
	   
	}

	@Then("user should be able to view download screen with audio title checked out and downloaded")
	public void user_should_be_able_to_view_download_screen_with_audio_title_checked_out_and_downloaded() {
	   
	}


	@Then("user should be able to view and perform primary actions for audio")
	public void user_should_be_able_to_view_and_perform_primary_actions_for_audio() {
	    
	}
	
	@Then("user should be able to view holds screen with hold Suspended titles")
	public void user_should_be_able_to_view_holds_screen_with_hold_suspended_titles() {
		logger.info("user should be able to view holds screen with hold Suspended titles");
	}
	

//	@Given("user tap on login button after user enter kidszone and axis360 subscription only {string} and {string}")
//	public void user_tap_on_login_button_after_user_enter_kidszone_and_axis360_subscription_only_and(String string, String string2) {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}


	@When("click on wishlist quick CTA")
	public void click_on_wishlist_quick_cta() {
		myshelf.clickwishlist();
		logger.info("Tapped on wishlist cta and app lands on wishlist screen");
	}
	@Then("user should be able to view wishlist screen with title available")
	public void user_should_be_able_to_view_wishlist_screen_with_title_available() {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()),false);
	}
	@Then("user should be able to click on primary button {string} title available in the wishlist screen")
	public void user_should_be_able_to_click_on_primary_button_title_available_in_the_wishlist_screen(String string) {
		logger.info("user should be able to click on primary button title available in the wishlist screen");
	   // holds.clickprimaryoptions();
	}
	@Then("user navigate back to the wishlist screen")
	public void user_navigate_back_to_the_wishlist_screen() {
		myshelf.clickwishlist();
	}
	@Then("user should be able to click on {string} and remove the title from the Wishlist")
	public void user_should_be_able_to_click_on_and_remove_the_title_from_the_wishlist(String string) {
	    holds.clickRemovewishlist();
	}

	@Then("user should be able to view wishlist screen with title which the PPC titles not available for checkout")
	public void user_should_be_able_to_view_wishlist_screen_with_title_which_the_ppc_titles_not_available_for_checkout() {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()),true);
	}


	@Then("user should be able to view and perform primary actions for ebooks and audiobooks")
	public void user_should_be_able_to_view_and_perform_primary_actions_for_ebooks_and_audiobooks() {
		Assert.assertEquals(isElementPresent(holds.getHolds_PrimaryActionsbtn()), true);
		Assert.assertEquals(isElementPresent(holds.getHolds_SecondaryActionsbtn()), true);
	}
	@Then("user should be able to click on primary button {string} and remove the title from the Wishlist")
	public void user_should_be_able_to_click_on_primary_button_and_remove_the_title_from_the_wishlist(String string) {
//	    holds.clickprimaryoptions();
	    holds.clickRemovewishlist();
	}
	
	@Then("user should be able to view wishlist screen with title which is in suspended hold")
	public void user_should_be_able_to_view_wishlist_screen_with_title_which_is_in_suspended_hold() {
	    
	}


	@Then("user should be able to view primary cta {string} and to activate the hold")
	public void user_should_be_able_to_view_primary_cta_and_to_activate_the_hold(String string) {
		Assert.assertEquals(isElementPresent(holds.getHolds_SecondaryActionsbtn()), true);
	}
	@Then("user should be able to view and click on secondary cta {string}")
	public void user_should_be_able_to_view_and_click_on_secondary_cta(String string) {
	  holds.clickprimaryoptions();
	 
	}
	@Then("user should be able to view secondary cta {string} and remove the title from the Wishlist")
	public void user_should_be_able_to_view_secondary_cta_and_remove_the_title_from_the_wishlist(String string) {
	    holds.clickRemovewishlist();
	}
	
	@Then("user should be able to view wishlist screen with title which is {string}")
	public void user_should_be_able_to_view_wishlist_screen_with_title_which_is(String string) {
		Assert.assertEquals(isElementPresent(holds.getHolds_SecondaryActionsbtn()), true);
	}


	@Then("user should be able to click on primary button {string} and to remove the hold for the title")
	public void user_should_be_able_to_click_on_primary_button_and_to_remove_the_hold_for_the_title(String string) {
		Assert.assertEquals(isElementPresent(holds.getHolds_SecondaryActionsbtn()), true);
		holds.clickSecondarybutton();
	}

	@Then("user should be able to view wishlist screen with title which is available for place on hold")
	public void user_should_be_able_to_view_wishlist_screen_with_title_which_is_available_for_place_on_hold() {
		Assert.assertEquals(isElementPresent(holds.getPlaceonhold_avl()), true);
	}


	@Then("user should be able to view and click on secondary cta {string} and remove the title from the Wishlist")
	public void user_should_be_able_to_view_and_click_on_secondary_cta_and_remove_the_title_from_the_wishlist(String string) {
	   holds.clickprimaryoptions();
	   holds.clickRemovewishlist();
	}



	
}