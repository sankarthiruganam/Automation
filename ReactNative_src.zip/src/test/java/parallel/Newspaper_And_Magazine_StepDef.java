package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.MyLibrary;
import pom.kidszone.Newspaper_And_Magazine;
import pom.kidszone.SearchPage;
import pom.kidszone.Tier1_LandingPage_VBookandVideo;
import pom.kidszone.Tier3_LandingPage_VBookandVideo;

public class Newspaper_And_Magazine_StepDef extends CommonActions {

    Newspaper_And_Magazine newspaperAndMagazineSection = new Newspaper_And_Magazine(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo tier1LandingPage = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier3_LandingPage_VBookandVideo tier3LandingPage = new Tier3_LandingPage_VBookandVideo(DriverManager.getDriver());
    MyLibrary library = new MyLibrary(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    
    
    @And("user click on see all cta in Newspapers & Magazine carousel and navigate to tier{int} screen")
    public void userClickOnSeeAllCtaInNewspapersMagazineCarouselAndNavigateToTierScreen(int arg0) {
        newspaperAndMagazineSection.newspaperAndMagazineHeader();
        library.clickNewsPaperMagazine();
    }

    @When("user click the menu and click the profile")
    public void user_click_the_menu_and_click_the_profile() {
    	newspaperAndMagazineSection.clickMenu();
    	newspaperAndMagazineSection.clickProfileSettings();
    }

    @And("validate the checkout limit")
    public void validate_the_checkout_limit()
    {
        for(int i=0;i<4;i++)
        {
            if(isElementPresent(library.getCheckout_limit()))
            {
        break;
            }else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.getCheckout_limit()),true);
    }
    @Then("verify the Display Insights & Badges field availability on profile detail page")
    public void verify_the_display_insights_badges_field_availability_on_profile_detail_page() {
    	newspaperAndMagazineSection.navigate_to_Insights_Badges();
    	Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.display_Insights_Badges()), true);
    }

    @Then("user select the Display Insights & Badges checkbox")
    public void user_select_the_display_insights_badges_checkbox() {
    	newspaperAndMagazineSection.click_Insights_Badges();
    }

    @Then("user unselect the Display Insights & Badges checkbox and verify the alert popup")
    public void user_unselect_the_display_insights_badges_checkbox_and_verify_the_alert_popup() {
    	newspaperAndMagazineSection.click_Insights_Badges();
    }

    @Then("validate the Alert popup details Title, message description, Disable & cancel - CTA's")
    public void validate_the_alert_popup_details_title_message_description_disable_cancel_cta_s() {
        if(System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertEquals(newspaperAndMagazineSection.getAlert_popup_title().getText(), "Disable Insights & Badges");
        }else
        {
            Assert.assertEquals(newspaperAndMagazineSection.getAlert_popup_title().getText(), "Disable Insights & Badges. Heading.Disable Insights & Badges.Dialogue");
        }
    	Assert.assertEquals(newspaperAndMagazineSection.getAlert_popup_description().getText(), "Are you sure you want to Disable Insights & Badges? Upon selecting Save, this will turn off your reading and listening progress");
    	Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.getAlert_popup_disable()), true);
    	Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.getAlert_popup_cancel()), true);
    }

    @Then("user click cancel from the Alert poup")
    public void user_click_cancel_from_the_alert_poup() {
    	newspaperAndMagazineSection.clickCancel();
    }

    @And("user should view Feature banner on Landing page for Newspapers & Magazines")
    public void userShouldViewFeatureBannerOnLandingPageForNewspapersMagazines() {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifyFeaturedBanner()), true);
    }

    @And("user should view First Magazine \\(Highest Rank) then Newspaper \\(Highest rank) then Newspaper , in alternate fashion for all {int} Titles")
    public void userShouldViewFirstMagazineHighestRankThenNewspaperHighestRankThenNewspaperInAlternateFashionForAllTitles(int arg0) {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifyFeaturedBannerTitles()), true);
    }

    @And("user should view these {int} newspapers & magazines placed in alternate fashion")
    public void userShouldViewTheseNewspapersMagazinesPlacedInAlternateFashion(int arg0) {
        logger.info("Api Based Validation");
    }

    @And("user click on see all cta any carousel and naviagate to tier{int} screen")
    public void userClickOnSeeAllCtaAnyCarouselAndNaviagateToTierScreen(int arg0) {
        newspaperAndMagazineSection.clickNewspaperAndMagazineTier1SeeAllLink();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkFeaturedVBookTier2Title()), true);

    }

    @Then("user must be on same screen \\(My profile detail screen)")
    public void user_must_be_on_same_screen_my_profile_detail_screen() {
    	Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.display_MyProfile()), true);
    }

    @Then("again unselect the Display Insights & Badges checkbox and verify the alert popup")
    public void again_unselect_the_display_insights_badges_checkbox_and_verify_the_alert_popup() {
    	newspaperAndMagazineSection.click_Insights_Badges();
        if(System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertEquals(newspaperAndMagazineSection.getAlert_popup_title().getText(), "Disable Insights & Badges");
        }else
        {
            Assert.assertEquals(newspaperAndMagazineSection.getAlert_popup_title().getText(), "Disable Insights & Badges. Heading.Disable Insights & Badges.Dialogue");
        }
    }

    @Then("user click Disable from the alert popup")
    public void user_click_disable_from_the_alert_popup() {
    	newspaperAndMagazineSection.click_Disable();
    }

    @Then("Display Insights & Badges checkbox unselected")
    public void display_insights_badges_checkbox_unselected() {
    	Assert.assertEquals(newspaperAndMagazineSection.display_InsightsBadges().isSelected(), false);
    }
	@When("User should not see arrows in Native - as the half jacket indicates there is scrolling")
	public void user_should_not_see_arrows_in_native_as_the_half_jacket_indicates_there_is_scrolling() {
		logger.info("User not able to see the arrows in Native - Will be verified Manually");
	}

    @And("user should view filter select the default country as per the contact details")
    public void userShouldViewFilterSelectTheDefaultCountryAsPerTheContactDetails() {
        Assert.assertEquals(newspaperAndMagazineSection.verifyRefinerIcon(), true);
        newspaperAndMagazineSection.clickRefinerIcon();
        newspaperAndMagazineSection.verifyCountryRefinerOption();
    }

    @And("user select the Newspapers & Magazine from category section")
    public void userSelectTheNewspapersMagazineFromCategorySection() {
    	newspaperAndMagazineSection.selectNewsAndMagazineCategory();
    }

    @Then("user should not view see all option in featured banner")
    public void userShouldNotViewSeeAllOptionInFeaturedBanner() {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.getFeaturePrg_panner()), true);
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifyFeaturedProgramDetailsBtn()), true);
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifySeeAllLink()), false);
    }

    @When("user taps on the search result title")
    public void userTapsOnTheSearchResultTitle() {
        newspaperAndMagazineSection.clickEBookTitle();
    }

    @And("Validate available copies")
    public void Validate_available_copies() {
        waitFor(1000);
        swipeDown();
        if (isElementPresent(newspaperAndMagazineSection.getCopies_Availble())) {
            Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.getCopies_Availble()), true);
        } else  {
            Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.getpeople_Waiting()), true);
        }
    }
    @Then("user redirect to my library page")
    public void user_redirect_to_my_library_page() {

    }

    @Then("user clicks on the place hold cta")
    public void userClicksOnThePlaceHoldCta() {

        newspaperAndMagazineSection.clickPlaceHoldBtn();
    }

    @And("user should be able to view confirmation pop-up")
    public void userShouldBeAbleToViewConfirmationPopUp() {
        if(isElementPresent(newspaperAndMagazineSection.verifyConfirmationPopupHeaderMessage())) {
            if(System.getProperty("platform").equalsIgnoreCase("Android")) {
                Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupHeaderMessage().getText(), "Hold Confirmed");
                Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupContent().getText(), "If you would like to receive email notifications when Holds become available, please update your Profile Settings.");
            }else {
                Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupHeaderMessage().getText(), "Hold Confirmed. Heading.Hold Confirmed.Dialogue");
                Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupContent().getText(), "If you would like to receive email notifications when Holds become available, please update your Profile Settings.");

            }
            }
        }

    @And("user closes the reading interest pop-up")
    public void userClosesTheReadingInterestPopUp() {
        waitFor(2000);
        newspaperAndMagazineSection.clickBackBtn();
    }
    
    @And("user clicks article carousel See All CTA")
    public void user_clicks_article_carousel_See_All_CTA() {
        waitFor(2000);
        newspaperAndMagazineSection.selectNewsAndMagazineArticle();
    }

    @And("user able to view confirmation popup on clicking the hold toot tip")
    public void userAbleToViewConfirmationPopupOnClickingTheHoldTootTip() {
        newspaperAndMagazineSection.verifyEmailNotificationPopup();
        if(System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupContent().getText(),"Notify me via email whenever a Hold becomes available");
        }else {
            Assert.assertEquals(newspaperAndMagazineSection.verifyConfirmationPopupContent().getText(),"Notify me via email whenever a Hold becomes availableDialogue");
        }
        newspaperAndMagazineSection.clickOkBtn();
    }
    
    @When("user click on Newspapers & Magazine carousel in library screen")
    public void userClickOnNewspapersMagazineCarouselInLibraryScreen() {
        newspaperAndMagazineSection.newspaperAndMagazineHeader();
        newspaperAndMagazineSection.clickNewspaperAndMagazineInMyLibraryScreen();
    }

    @Then("user able to view Publications section")
    public void userAbleToViewPublicationsSection() {
        newspaperAndMagazineSection.verifyPublicationSearchResult();
    }

    @And("user should view the multiple country availability on listed for publication cards with three dot")
    public void userShouldViewTheMultipleCountryAvailabilityOnListedForPublicationCardsWithThreeDot() {
        logger.info("Unable to validate the country availability in the cards based on the dots ");
    }

    @And("user view ellipses {string} when the countries names are longer or more than one country name present for the publication")
    public void userViewEllipsesWhenTheCountriesNamesAreLongerOrMoreThanOneCountryNamePresentForThePublication(String arg0) {
        logger.info("Unable to validate the country availability in the cards");
    }

    @And("country names should be separated by {string} when more than one country is present for the publication on the Search Result page")
    public void countryNamesShouldBeSeparatedByWhenMoreThanOneCountryIsPresentForThePublicationOnTheSearchResultPage(String arg0) {
        logger.info("Unable to validate the country availability in the cards");
    }

    @And("selects the newspaper & magazine option in advance search")
    public void selectsTheNewspaperMagazineOptionInAdvanceSearch() {
        newspaperAndMagazineSection.clickNewspaperAndMagazineAdvanceOption();
        search.click_Search_btn();
    }

    @And("user should view sorted with the relevance by default in search result page")
    public void userShouldViewSortedWithTheRelevanceByDefaultInSearchResultPage() {
        library.verifyPublicationsSectionInTier2Screen();
        library.clickNewsPaperMagazineSearchRefiner();
        newspaperAndMagazineSection.clickSortBYDrpdwn();
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            Assert.assertEquals(newspaperAndMagazineSection.verifyIOSRelevanceOption(),true);
        }
        else {
            Assert.assertEquals(newspaperAndMagazineSection.verifyAndroidRelevanceOption(),true);
        }
    }

    @When("user should view sorted with the popularity by default in tier2 list screen")
    public void user_should_view_sorted_with_the_popularity_by_default_in_tier2_list_screen() {
        if(isElementPresent(library.verifyNewspaperSectionInTier2Screen())) {
            Assert.assertEquals(isElementPresent(library.verifyNewspaperSectionInTier2Screen()),true);
        }
        else {
            Assert.assertEquals(isElementPresent(library.verifyMagazineSectionInTier2Screen()),true);
        }
        library.clickNewsPaperMagazineSearchRefiner();
        newspaperAndMagazineSection.clickSortBYDrpdwn();
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            Assert.assertEquals(newspaperAndMagazineSection.verifyIOSPopularityOption(),true);
        }
        else {
            Assert.assertEquals(newspaperAndMagazineSection.verifyAndroidPopularityOption(),true);
        }
    }    
    
    @Then("user click on publication title navigate to detail screen")
    public void user_click_on_publication_title_navigate_to_detail_screen() {
        newspaperAndMagazineSection.clickMagazineTitle();
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleHeader()), true);
    }
    
    @Then("user should view the multiple country on publication detail screen if available")
    public void user_should_view_the_multiple_country_on_publication_detail_screen_if_available() {
        swipeDown();
    	newspaperAndMagazineSection.verifyMagazineCountry();
    }


    @And("user click on the checkout button of the eAudio Title")
    public void userclickOnTheCheckoutButtonOfTheEAudioTitle() {
        newspaperAndMagazineSection.clickPlaceHoldBtn();
        waitFor(5000);
    }

    @When("user click on the checkout button of the eBook Title")
    public void userClickOnTheCheckoutButtonOfTheEBookTitle() {
        newspaperAndMagazineSection.clickPlaceHoldBtn();
        waitFor(5000);
    }
    @And("user return the checked out eAudio Title")
    public void userReturnTheCheckedOutEAudioTitle() {
        newspaperAndMagazineSection.returningTheeAudio();
        waitFor(2000);
    }

    public void userClickOnTheCTAInNewsPaperAndMagazineCarousel() {
        newspaperAndMagazineSection.clickNewspaperAndMagazineSeeAllLink();
    }

    @And("user navigates to the tier one page")
    public void userNavigatesToTheTierPage() {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifyFeaturedBanner()), true);
    }

    @And("user clicks See All CTA in tier one")
    public void userClicksSeeAllCTAInTierOne() {
        newspaperAndMagazineSection.clickNewspaperAndMagazineTier1SeeAllLink();
    }

    @Then("user should navigate to the tier two page")
    public void userShouldNavigateToTheTierPage() {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.tier2Title()), true);
    }

    @And("user selects any refine option in the refine section")
    public void userSelectsAnyRefineOptionInTheRefineSection() {
        newspaperAndMagazineSection.clickRefinerIcon();
        newspaperAndMagazineSection.clickCountryRefiner();
        newspaperAndMagazineSection.clickCountryInternational();
        newspaperAndMagazineSection.clickrefinerAlgeria();
        waitFor(2000);
        newspaperAndMagazineSection.clickCountryRefiner();
        waitFor(2000);
    }

    @And("user clicks on the search CTA")
    public void userClicksOnTheSearchCTA() {
        newspaperAndMagazineSection.clickrefinerSearch();
    }

    @And("user should be able to view refiner pills for the selected refiners")
    public void userShouldBeAbleToViewRefinerPillsForTheSelectedRefiners() {
        Assert.assertEquals(newspaperAndMagazineSection.verifyInternationalPill(), true);
        waitFor(3000);
    }

    @And("user should be able to view clear all pill to remove all the filters")
    public void userShouldBeAbleToViewClearAllPillToRemoveAllTheFilters() {

        boolean isElement1Visible = isElementPresent(newspaperAndMagazineSection.secondPillInThirdParty);
        boolean isElement2Visible = isElementPresent(newspaperAndMagazineSection.secondPillInLibraryList);

        if (isElement1Visible || isElement2Visible) {
            if (isElement1Visible) {
                swipeRightToLeft(newspaperAndMagazineSection.secondPillInThirdParty);
            } else {
                swipeRightToLeft(newspaperAndMagazineSection.secondPillInLibraryList);
            }
        }
        newspaperAndMagazineSection.clickClearAllPill();
    }

    @And("user should not view default pill")
    public void userShouldNotViewDefaultPill() {
        if(isElementPresent(newspaperAndMagazineSection.clearAllrefiner1())) {
            Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.clearAllrefiner1()), false);
        } else if(isElementPresent(newspaperAndMagazineSection.clearAllrefiner2())){
            Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.clearAllrefiner2()), false);
        }
    }

    @And("user should navigate to the search result screen")
    public void userShouldNavigateToTheSearchResultScreen() {
        Assert.assertEquals(isElementPresent(newspaperAndMagazineSection.verifySearchResultsPage()), true);
    }

    @When("user click on the See All CTA in News paper and magazine carousel from search result screen")
    public void userClickOnTheSeeAllCTAInNewsPaperAndMagazineCarouselFromSearchResultScreen() {
        newspaperAndMagazineSection.clickNewspaperSeeAllLink();
    }

    @And("user clicks on the See All CTA in video Book carousel from search result screen")
    public void userClicksOnTheCTAInVideoBookCarouselFromSearchResultScreen() {
        search.click_vBook_SeeAll();
    }

    @When("user click on the See All CTA in vBook carousel")
    public void userClickOnTheSeeAllCTAInVBookCarousel() {
        tier1LandingPage.clickVideoSeeAllInMyLibrary();
    }

    @And("user selects multiple refine options in the refine section")
    public void userSelectsMultipleRefineOptionsInTheRefineSection() {
        newspaperAndMagazineSection.clickRefinerIcon();
        newspaperAndMagazineSection.clickAgeLevelOption();
        newspaperAndMagazineSection.clickLanguageOption();
    }

    @And("user selects any refine option in the eBook refine section")
    public void userSelectsAnyRefineOptionInTheEBookRefineSection() {
        newspaperAndMagazineSection.clickRefinerIcon();
        newspaperAndMagazineSection.closeFeaturedListSection();
        newspaperAndMagazineSection.selectAvailabilityOption();
        newspaperAndMagazineSection.selectRecentlyAddedOption();
    }

    @And("user is navigated to the eBook Reader Screen")
    public void userIsNavigatedToTheEBookReaderScreen() {
        Assert.assertEquals(newspaperAndMagazineSection.verifyeBookTitleScreen(),true);
    }

    @And("user return the checked out eBook Title")
    public void userReturnTheCheckedOutEBookTitle() {
        newspaperAndMagazineSection.returningTheeBook();
        waitFor(2000);
    }

    @And("user should redirect to the Newspaper and Magazines tier{int} page")
    public void userShouldRedirectToTheNewspaperAndMagazinesTierPage(int arg0) {
        library.clickNewsPaperMagazineSeeAll();
    }

    @And("user should redirect to Newspapers tire{int} page")
    public void userShouldRedirectToNewspapersTirePage(int arg0) {
        Assert.assertEquals(isDisplayed(newspaperAndMagazineSection.tier2Title()), true);
    }

    @And("user should click on back button")
    public void userShouldClickOnBackButton() {
        newspaperAndMagazineSection.clickBackBtn();

    }

    @And("user should be redirected to Magazines tire{int} page")
    public void userShouldBeRedirectedToMagazinesTirePage(int arg0) {
        newspaperAndMagazineSection.clickmagazinesViewAll();
        Assert.assertEquals(isDisplayed(newspaperAndMagazineSection.tier2Title()), true);
    }
}
