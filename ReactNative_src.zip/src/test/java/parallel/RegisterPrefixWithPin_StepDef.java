package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.RegisterScreen;

public class RegisterPrefixWithPin_StepDef extends CommonActions {

    RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
    LoginPage login = new LoginPage(DriverManager.getDriver());
    ManageProfile manage = new ManageProfile(DriverManager.getDriver());
    private Scenario scenario;

    public static final Logger logger = LoggerFactory.getLogger(RegisterPrefixWithPin_StepDef.class);

    @Before
    public void setup(Scenario scenario) {
        this.scenario = scenario;
    }
    
    @And("system redirects to the registration page")
    public void system_redirects_to_the_registration_page() throws Throwable {
        Assert.assertEquals(register.getRegister_lbl().isDisplayed(), true);
        Assert.assertEquals(login.newUserName, register.register_txt_CardName.getText());
        logger.info("User able to see the card name entered by default");
    }

    @And("user enters the {string} and {string}")
    public void user_enters_the_something_and_something(String username, String password) throws Throwable {
        register.enterUserNamePassword(username, password);
    }

    @And("user enters {string} and {string}")
    public void user_enters_something_and_something(String email, String displayname) throws Throwable {
        register.enterEmailandDisplayname(email, displayname);

    }

    @And("user clicks on the register button to complete registration")
    public void user_clicks_on_the_register_button_to_complete_registration() throws Throwable {
        register.completeRegistration();
    }

    @And("system allows the user to login into the app after successful registration")
    public void system_allows_the_user_to_login_into_the_app_after_successful_registration() throws Throwable {
        logger.info("login successfully");
    }

    @When("user selects enter the library password link in the login page")
    public void user_selects_enter_the_library_password_link_in_the_login_page() throws Throwable {

    }

    @Then("error message should appear for every mandatory field")
    public void error_message_should_appear_for_every_mandatory_field() throws Throwable {
        Assert.assertEquals(register.getLogin_txt_validationError().isDisplayed(), true);
    }

    @And("user skips {string} and {string}")
    public void user_skips_the_something_and_something(String email, String displayname) {
        register.skipEmailandDisplayname(email, displayname);
    }

    @When("user enters the {string} and clicks on sign in cta")
    public void user_enters_the_something_and_clicks_on_sign_in_cta(String libraryid) throws Throwable {
    	TestReaderPOJO testData = TestDataReader.getTestData(scenario, "");
//        register.enterLibraryId(libraryid);
    	register.enterLibraryId(testData.getLibraryId());
    }

    @When("user enters the Existing {string} and click on sign in")
    public void user_enters_the_existing_and_click_on_sign_in(String libraryid) {
        register.existingUserLibraryId(libraryid);
        register.clicksigin();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            register.faceIdPopHandle();
        }
    }

    @When("user enters the Existing {string} and {string} and clicks on sign in")
    public void user_enters_the_existing_and_and_clicks_on_sign_in(String libraryid, String pin) {
        login.loginwithidandPin(libraryid, pin);
    }

    @When("user enters the Existing {string} and {string} and clicks on sign in independent library")
    public void user_enters_the_existing_and_and_clicks_on_sign_in_independent_library(String libraryid, String pin) {
        login.loginwithidandPin(libraryid, pin);
//		if (System.getProperty("platform").equalsIgnoreCase("Android")){
//	    	register.faceIdPopHandle();
//	    }

    }

    @And("system throws the {string}  error")
    public void system_throws_the_something_error(String strArg1) throws Throwable {
//		Assert.assertEquals(register.getLogin_txt_validationError(), "value");
    }

    @When("user skips the {string} and clicks on sign in cta")
    public void user_skips_the_something_and_clicks_on_sign_in_cta(String libraryid) throws Throwable {
        register.clicksigin();
    }

    @Then("system throws the error")
    public void system_throws_the_error() throws Throwable {
//		Assert.assertEquals(register.getLogin_txt_validationError(), "value");
    }

    @And("select age group {string}")
    public void select_age_group(String agegrp) throws Throwable {
        register.selectAgegroup(agegrp);
    }

    @When("user enters the {string} and {string} clicks on sign in cta")
    public void user_enters_the_something_and_something_clicks_on_sign_in_cta(String libraryid, String pin)
            throws Throwable {
        login.signInwithLibraryIdandPin(libraryid, pin);
    }

    @Then("User should displays the error message")
    public void User_should_displays_the_error_message() throws Throwable {
        logger.info("user is able to view error message");
        /*
         * WaitForMobileElement(login.getLogo_lbl_invalidprefixLogin());
         * Assert.assertEquals(isElementPresent(login.getLogo_lbl_invalidprefixLogin()),
         * true);
         */
    }

    @When("user skips the {string} and {string} clicks on sign in cta")
    public void user_skips_the_something_and_something_clicks_on_sign_in_cta(String libraryid, String pin)
            throws Throwable {
        login.skippedLibraryIdandPin(libraryid, pin);
    }

    @Then("system shows the error message")
    public void system_shows_the_error_message() throws Throwable {
        if (isElementPresent(login.getLogo_lbl_InvalidLoginError())) {
            Assert.assertEquals(login.getLogo_lbl_InvalidLoginError().isDisplayed(), true);
        }
    }

    @When("user enter the valid prefix {string} with {string} and {string}")
    public void user_enter_the_valid_prefix_something_with_something_and_something(String prefix, String libraryid,
                                                                                   String pin) throws Throwable {
        login.signInwithLibraryIdandPin(libraryid, pin);
    }

    @Then("edit the card Number {string}")
    public void edit_the_card_Number(String cardnumber) throws Throwable {
        register.editCardNumber(cardnumber);
    }

    @Then("system should not show the error messages for the optional fields")
    public void system_should_not_show_the_error_messages_for_the_optional_fields() throws Throwable {
        // Assert.assertEquals(!register.reg_lbl_displayError.isDisplayed(), true);
        // Assert.assertEquals(!register.reg_lbl_emailError.isDisplayed(), true);
    }

    @And("user should be able to able to view the display name,email address")
    public void user_should_be_able_to_able_to_view_the_display_nameemail_address() throws Throwable {
        Assert.assertEquals(register.getNewregister_txt_DisplayName().isDisplayed(), true);
        Assert.assertEquals(register.getNewregister_txt_Email().isDisplayed(), true);
    }

    @And("clicks on the register cta")
    public void clicks_on_the_register_cta() throws Throwable {

        register.clickRegisterCTA();

    }

    @Then("user should able to view the register button enable mode")
    public void user_should_able_to_view_the_register_button_enable_mode() {
        Assert.assertEquals(register.getLibrary_btn_Register().isEnabled(), true);
    }

}
