package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pom.kidszone.*;

public class SetParentPin_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());

	/************** 109568 *********************/

	@When("user register a new user with {string} and {string} login type")
	public void user_register_a_new_user_with_id_and_pin_login_type(String userID, String pin) {
		register.enterPrefixandpin(userID, pin);
		Assert.assertEquals(register.getRegister_lbl().isDisplayed(), true);

	}

	@When("user clicks on register button to parent pin setup page")
	public void user_clicks_on_register_button_to_parent_pin_setup_page() {
		register.completeRegistration();
	}

	@When("user enters the four digit {string}")
	public void user_enters_the_four_digit(String pin) {
		setPin.setParentPin();
	}

	@When("user enters the confirm four digit {string}")
	public void user_enters_the_confirm_four_digit(String pin) {
		setPin.confirmParentPin();
		logger.info("Parent pin set sucessfully");
	}

	/*********************** 109570 ************************/

	@Then("user should see error message")
	public void user_should_see_error_message() {
		Assert.assertEquals(setPin.getSetParentPin_lbl_wrongPin().isDisplayed(), true);
	}
	
	/*********************** 109572 ************************/
	
	@When("user has entered the wrong parent pin multiple times")
	public void user_has_entered_the_wrong_parent_pin_multiple_times() {
		setPin.multiTimeWrongPin();
//	    setPin.wrongParentPin();
//	    setPin.wrongParentPin();
//	    setPin.wrongParentPin();
//	    waitFor(3000);
	}

	@Then("user navigate to reset pin screen")
	public void user_navigate_to_reset_pin_screen() {
	    Assert.assertEquals(setPin.getResetPin_lbl_header().isDisplayed(), true);
	    logger.info("User navogates to Reset pin page");
	}

	@Then("user click on reset pin cta")
	public void user_click_on_reset_pin_cta() {
	    setPin.resetPinClick();
	}

	@Then("user should see security question and answer screen")
	public void user_should_see_security_question_and_answer_screen() {
	    Assert.assertEquals(setPin.getResetPin_lbl_securityQuestion().isDisplayed(), true);
	}

	@Then("user enter answer and click submit cta")
	public void user_enter_answer_and_click_submit_cta() {
	    setPin.securityAnsforResetPin("red");  
	}

	@Then("user navigate set new pin on successful validation of security question")
	public void user_navigate_set_new_pin_on_successful_validation_of_security_question() {
	    Assert.assertTrue(setPin.getSetParentPinPg_lbl_header().isDisplayed());    
	}

	@Then("user should see the option to enter new pin and done")
	public void user_should_see_the_option_to_enter_new_pin_and_done() {
	    setPin.setParentPin();    
	}

	@Then("user should see the option to enter confirm pin and done")
	public void user_should_see_the_option_to_enter_confirm_pin_and_done() {
	    setPin.confirmParentPin();
	    logger.info("Pin reset success");
	}

	@Then("user enter wrong answer and click submit cta")
	public void user_enter_wrong_answer_and_click_submit_cta() {
		setPin.securityAnsforResetPin("Blue");  	    
	}

	@Then("user should see error message as Security answer not matched")
	public void user_should_see_error_message_as_security_answer_not_matched() {
	    Assert.assertEquals(setPin.getResetPin_btn_WrongSecAnsClose().isDisplayed(), true);
	}
	
	@Then("user close the pop message")
	public void user_close_the_pop_message() {
	   setPin.popCloseAfterPinReset();
	}
	
	@And("user should be able to be redirected to a screen where they can set a Four digit Parental PIN")
	public void userShouldBeAbleToBeRedirectedToAScreenWhereTheyCanSetAFourDigitParentalPIN() {
		setPin.setParentPin();
	}
	
	@And("system should redirect the user to PIN Confirmation page and ask the user to enter wrong pin")
	public void systemShouldRedirectTheUserToPINConfirmationPageAndAskTheUserToEnterWrongPin() {
		setPin.wrongParentPin();
	}

	@And("user enter the correct pin and pin is set successfully")
	public void userEnterTheCorrectPinAndPinIsSetSuccessfully() {

		setPin.setParentPin();;
		waitFor(2000);
		setPin.confirmParentPin();
		waitFor(2000);
		register.clickSaveButton();
	}
}
