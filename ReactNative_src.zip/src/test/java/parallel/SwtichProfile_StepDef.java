package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.ManageProfile;
import pom.kidszone.ProfileCreation;
public class SwtichProfile_StepDef {
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	ManageProfile manage= new ManageProfile(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(SwtichProfile_StepDef.class);
	
	@When("user navigates to the manage profile screen")
	public void user_navigates_to_the_manage_profile_screen() throws Throwable {
		Assert.assertEquals(profile.getProfile_txt_title().isDisplayed(), true);
	}

	@Then("user should be able to navigate back to manage profile page and able to switch another profile")
	public void user_should_be_able_to_navigate_back_to_manage_profile_page_and_able_to_switch_another_profile()
			throws Throwable {
		profile.clickBackbutton();
		manage.selectProfType("kid");
	}

	@And("user clicks on the profiles option")
	public void user_clicks_on_the_profiles_option() throws Throwable {
		manage.editBtnClick();
		manage.teenprofileSelection();
	}

	@And("user profile type is set as adult")
	public void user_profile_type_is_set_as_adult() throws Throwable {
		logger.info("user profile type is already set as adult");
	}

	@And("on successful validation, user should be able to view the library subscription of the selected profile")
	public void on_successful_validation_user_should_be_able_to_view_the_library_subscription_of_the_selected_profile()
			throws Throwable {

	}

	@And("user can view the check out limits")
	public void user_can_view_the_check_out_limits() throws Throwable {
		Assert.assertEquals(profile.getProfile_lbl_editcheckoutlimit().isDisplayed(), true);
	}

	@And("user can view the on hold limits")
	public void user_can_view_the_on_hold_limits() throws Throwable {
		Assert.assertEquals(profile.getProfile_lbl_editholdlimit().isDisplayed(), true);
	}

	@And("user can view the profile details")
	public void user_can_view_the_profile_details() throws Throwable {

	}

	@And("user can view the contents accessed")
	public void user_can_view_the_contents_accessed() throws Throwable {

	}

}
