package parallel;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;

import io.cucumber.java.Scenario;

public class TestDataReader {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static JsonNode testDataConfig;
    private static final String platform = System.getProperty("platform");
    static String env = null;

    static {
        try (FileReader fileReader = new FileReader("src/test/resources/Data/TestData.json")) {

            env = System.getenv("ENVIRONMENT");
            if (env == null) {
                env = System.getProperty("Environment");

            }
            // Read JSON data using ObjectMapper
            JsonNode configNode = objectMapper.readTree(fileReader);
            System.out.println("configNode: " + configNode);
            // Now you can work with the JSON data using Jackson
            System.out.println("platform======="+platform);
            testDataConfig = configNode.get("platforms").get(platform);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // public static TestReaderPOJO getTestData(Scenario scenario) {
    //     TypeFactory typeFactory = objectMapper.getTypeFactory();
    //     CollectionType collectionType = typeFactory.constructCollectionType(ArrayList.class, TestReaderPOJO.class);
    // 	System.out.println("platform : " + platform);
    //     String featureName = extractFeatureName(scenario).trim();
    //     System.out.println("featureName------"+featureName);
    //     System.out.println("test data config : " + testDataConfig);
    //     if (testDataConfig != null) {
    //         JsonNode featureNode = testDataConfig.get("features").get(featureName);
    //         System.out.println("featureNode : " + featureNode);
    //         if (featureNode != null) {
    //             try {
    //                 // Return the deserialized JSON as TestReaderPOJO
    //                 ArrayList<TestReaderPOJO> list = objectMapper.convertValue(featureNode, collectionType);
    //                 return list.get(0);
    //             } catch (Exception e) {
    //                 e.printStackTrace();
    //             }
    //         }
    //     }

    //     return null; // Return null if there was an issue
    // }


    public static TestReaderPOJO getTestData(Scenario scenario, String id) {
        TypeFactory typeFactory = objectMapper.getTypeFactory();
        CollectionType collectionType = typeFactory.constructCollectionType(ArrayList.class, TestReaderPOJO.class);
        System.out.println("platform : " + platform);
        String featureName = extractFeatureName(scenario).trim();
        System.out.println("featureName------"+featureName);
        System.out.println("test data config : " + testDataConfig);
        if (testDataConfig != null) {
            JsonNode featureNode = testDataConfig.get("features").get(featureName);
            System.out.println("featureNode : " + featureNode);
            if (featureNode != null) {
                try {
                    // Return the deserialized JSON as TestReaderPOJO
                    ArrayList<TestReaderPOJO> list = objectMapper.convertValue(featureNode, collectionType);
                    for(TestReaderPOJO scenarioTestData : list) {
                        String identifier = scenarioTestData.getId();
                        if(identifier.equalsIgnoreCase(id) && featureNode.asText().contains(env)) {
                            return scenarioTestData;
                        }
                    }
                    return list.get(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return null; // Return null if there was an issue
    }


    private static String extractFeatureName(Scenario scenario) {
        String uri = scenario.getUri().toString();
        String[] uriParts = uri.split("/");
        String featureFileName = uriParts[uriParts.length - 1];
        return featureFileName.substring(0, featureFileName.lastIndexOf("."));
    }
}


class TestReaderPOJO {

    @JsonProperty("QA")
    String QA;

    @JsonProperty("QA1")
    String QA1;

    @JsonProperty("UAT")
    String UAT;

    @JsonProperty("libraryid")
    String libraryid;

    @JsonProperty("password")
    String password;

    @JsonProperty("libraryname")
    String libraryname;

    @JsonProperty("id")
    String id;

    public TestReaderPOJO() {}

    TestReaderPOJO(String libraryid, String password, String libraryname, String id,String QA,String QA1,String UAT ) {
        this.libraryid = libraryid;
        this.password = password;
        this.libraryname = libraryname;
        this.id = id;
        this.QA1=QA1;
        this.UAT=UAT;
        this.QA=QA;
    }

    public String getLibraryName() {
        return libraryname;
    }

    public String getId() {
        return id;
    }

    private void setId(String id) {
        this.id = id;
    }

    public void setLibraryName(String libraryName) {
        this.libraryname = libraryName;
    }

    public String getLibraryId() {
        return libraryid;
    }

    public void setLibraryId(String libraryid) {
        this.libraryid = libraryid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getQA() {
        return QA;
    }

    public void setQA(String QA) {
        this.QA = QA;
    }

    public String getQA1() {
        return QA1;
    }

    public void setQA1(String QA1) {
        this.QA1 = QA1;
    }

    public String getUAT() {
        return UAT;
    }

    public void setUAT(String UAT) {
        this.UAT = UAT;
    }

}


