package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;

public class ViewSearchSuggestions_StepDef {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@When("user enter three or more {string}")
	public void user_enter_three_or_more_something(String keyword) throws Throwable {
		login.searchLibrary(keyword);
		login.initiateSearch();
	}

	@When("user enter three or more {string} and not initiated search")
	public void user_enter_three_or_more_and_not_initiated_search(String keyword) {
		login.searchLibrary(keyword);
	}

	@Then("user should be able to view search suggestions based on input characters")
	public void user_should_be_able_to_view_search_suggestions_based_on_input_characters() throws Throwable {
		login.searchLibSuggestion();
	}

	@And("user should be able to view 5 number of suggestions")
	public void user_should_be_able_to_view_5_number_of_suggestions() throws Throwable {
		login.libSuggestionListSize();
		System.out.println(login.libSuggestionListSize());
		Assert.assertTrue(login.libSuggestionListSize());
	}

	@And("system should suggest library name and city based on input characters")
	public void system_should_suggest_library_name_and_city_based_on_input_characters() throws Throwable {
		login.suggestionResultCheck();
		System.out.println(login.suggestionResultCheck());
		Assert.assertTrue(login.suggestionResultCheck());
	}

	@And("user should be able to view updated search suggestions as user updates the search characters {string}")
	public void user_should_be_able_to_view_updated_search_suggestions_as_user_updates_the_search_characters_something(
			String input1) throws Throwable {
		login.clearkeywords();
		login.searchLibrary(input1);
		login.searchLibSuggestion();
	}

	@And("user should not be able to view any suggestions when less than 3 characters are input {string}")
	public void user_should_not_be_able_to_view_any_suggestions_when_less_than_3_characters_are_input_something(
			String input2) throws Throwable {
		login.clearkeywords();
		login.searchLibrary(input2);
		Assert.assertEquals(login.getLogo_list_MatchingLibraries().size() == 0, true);
	}

	@And("user should not be able to view any suggestions when no search suggestions are found {string}")
	public void user_should_not_be_able_to_view_any_suggestions_when_no_search_suggestions_are_found_something(
			String input3) throws Throwable {
		login.searchLibrary(input3);
		Assert.assertEquals(login.getLogo_lbl_libSearchResult().size() == 0, true);
	}

	@When("user tries to perform empty search")
	public void user_tries_to_perform_empty_search() throws Throwable {
		login.emptySearch();
//		login.initiateSearch();
	}

	@When("user enters {string} bar in search text field and performs search")
	public void user_enters_something_bar_in_search_text_field_and_performs_search(String space) throws Throwable {
		login.searchLibrary("   s");
		login.initiateSearch();
	}

	@Then("search should not get initiated")
	public void search_should_not_get_initiated() throws Throwable {
		Assert.assertEquals(login.getLogo_list_MatchingLibraries().size() == 0, true);
		logger.info("search not initiated");
	}
}
