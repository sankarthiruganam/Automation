package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeletingProfile {

	Eyes eyes = EyesManager.getEyes();
	
	//197359
	
	@When("capture the screenshot of Cancel my Boundless Account CTA")
	public void capture_the_screenshot_of_cancel_my_boundless_account_cta() {
	    eyes.checkWindow("CancelmyBoundlessAccountCTA");
	}

	@Then("capture the screenshot of Delete profile CTA")
	public void capture_the_screenshot_of_delete_profile_cta() {
	    eyes.checkWindow("DeleteProfileCta");
	}

	@Then("capture the screenshot of profile list")
	public void capture_the_screenshot_of_profile_list() {
	    eyes.checkWindow("ProfileList");
	}

	@Given("capture the screenshot of profile landing screen with Admin, Teen and Kid profiles")
	public void capture_the_screenshot_of_profile_landing_screen_with_admin_teen_and_kid_profiles() {
	    eyes.checkWindow("AdminTeenKidProfiles");
	}
	
	//197362
	
	@Then("capture the screenshot of Add a Teen option")
	public void capture_the_screenshot_of_add_a_teen_option() {
	    eyes.checkWindow("AddTeenOption");
	}

	@Then("capture the screenshot of Add a Kid option")
	public void capture_the_screenshot_of_add_a_kid_option() {
	    eyes.checkWindow("AddKidOption");
	}

	@Then("capture the screenshot of profile screen without + icons")
	public void capture_the_screenshot_of_profile_screen_without_icons() {
	    eyes.checkWindow("ProfileScreenWithout+Icon");
	}

	@Then("capture the screenshot of fourth profile")
	public void capture_the_screenshot_of_fourth_profile() {
	    eyes.checkWindow("FourthProfile");
	}
}
