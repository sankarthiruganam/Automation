package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class EnterNewPin {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of Please add an email to enable your profile PIN popup")
	public void capture_the_screenshot_of_please_add_an_email_to_enable_your_profile_pin_popup() {
	    eyes.checkWindow("PleaseAddAnEmailToEnableYourProfilePinPopup");
	}

	@Given("capture the screenshot of Manage Profiles option")
	public void capture_the_screenshot_of_manage_profiles_option() {
	    eyes.checkWindow("ManageProfilesOption");
	}

	@Given("capture the screenshot of Enable pin for all profile checkbox")
	public void capture_the_screenshot_of_enable_pin_for_all_profile_checkbox() {
	    eyes.checkWindow("EnablePinForAllProfileCheckbox");
	}

	@Then("capture the screenshot of Profile PIN page")
	public void capture_the_screenshot_of_profile_pin_page() {
	    eyes.checkWindow("ProfilePINPage");
	}

	@Then("capture the screenshot of error messages as PINs you entered do not match.Please retry.")
	public void capture_the_screenshot_of_error_messages_as_pi_ns_you_entered_do_not_match_please_retry() {
	    eyes.checkWindow("ErrorMessage-PINYouEnteredDoNotMatch.PleaseRetry");
	}

	@Then("capture the screenshot of Profile Detail page")
	public void capture_the_screenshot_of_profile_detail_page() {
	    eyes.checkWindow("ProfileDetailPage");
	}

	@Then("capture the screenshot of Manage Profile page")
	public void capture_the_screenshot_of_manage_profile_page() {
	    eyes.checkWindow("ManageProfilePage");
	}
}
