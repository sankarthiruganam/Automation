package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfileTypeField {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of Manage Profile Page with Edit button")
	public void capture_the_screenshot_of_manage_profile_page_with_edit_button() {
	    eyes.checkWindow("EditButton");
	}

	@Then("capture the screenshot of General Adutl as Profile Type field")
	public void capture_the_screenshot_of_general_adutl_as_profile_type_field() {
	    eyes.checkWindow("GeneralAdult");
	}

	@Then("capture the screenshot of Teen \\({int}-{int}) as Profile Type field")
	public void capture_the_screenshot_of_teen_as_profile_type_field(Integer int1, Integer int2) {
	    eyes.checkWindow("Teen(12-18)");
	}

	@Then("capture the screenshot of Kid \\({int}-{int}) as Profile Type field")
	public void capture_the_screenshot_of_kid_as_profile_type_field(Integer int1, Integer int2) {
	    eyes.checkWindow("Kid(0-11)");
	}

	@Then("capture the screenshot of manage profile page")
	public void capture_the_screenshot_of_manage_profile_page() {
	    eyes.checkWindow("ManageProfilePage");
	}

	@Then("capture the screenshot of verbiage Kid \\({int}-{int}),Teen \\({int}-{int})")
	public void capture_the_screenshot_of_verbiage_kid_teen(Integer int1, Integer int2, Integer int3, Integer int4) {
	    eyes.checkWindow("VerbiageOfKid(0-11)Teen(12-18)");
	}
}
