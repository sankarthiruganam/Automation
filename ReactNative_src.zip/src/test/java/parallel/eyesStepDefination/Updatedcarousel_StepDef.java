package parallel.eyesStepDefination;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import pom.kidszone.SearchPage;
public class Updatedcarousel_StepDef {

	Eyes eyes = EyesManager.getEyes();
	public static final Logger logger = LoggerFactory.getLogger(Updatedcarousel_StepDef.class);
	SearchPage search = new SearchPage(DriverManager.getDriver());

	@Given("capture the screenshot of Also Available in the title")
	public void user_launch_the_app_and_select_the_library() throws InterruptedException {
	search.relatedItems().click();
	eyes.checkWindow("Alsoavilable");
	}

	@And("capture the screenshot of the Newspaper & Magazine Tier{int} screen")
	public void captureTheScreenshotOfTheNewspaperMagazineTierScreen(int arg0) {
		eyes.checkWindow("Newspaper & Magazine Tier1 screen");
	}

	@Then("capture the screenshot of the Newspaper & Magazine in Tier{int} screen")
	public void captureTheScreenshotOfTheNewspaperMagazineInTierScreen(int arg0) {
		eyes.checkWindow("Newspaper & Magazine Tier3 screen");
	}
}
