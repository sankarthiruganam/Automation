import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;

public class GenerateHtmlReport {

	public static void main(String[] args) {
		File reportOutputDirectory = new File("/Users/sankarthirugnan/Desktop/290820233");
		List<String> jsonFiles = new ArrayList<>();
		jsonFiles.add("/Users/sankarthirugnan/Desktop/29082023/1/cucumber.json");
		jsonFiles.add("/Users/sankarthirugnan/Desktop/29082023/2/cucumber.json");
		jsonFiles.add("/Users/sankarthirugnan/Desktop/29082023/3/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/30032023/3/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/30032023/4/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/Smoke/Android-224-grp1/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/Smoke/FailedCases/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/ResultsMobile/cucumber.json");
		String projectName = "KidsZone_AutomationReport";
		Configuration configuration = new Configuration(reportOutputDirectory, projectName);
	//	 configuration.setBuildNumber(buildNumber);
		 configuration.addClassifications("Platform", "Android");
		 configuration.addClassifications("DeviceName", "Samsung_Galaxy_S22_Ultra");
		 configuration.addClassifications("StartTime", "29-08-2023 22:57:36");
		 configuration.addClassifications("EndTime", "30-08-2023 04:45:46");
		 configuration.addClassifications("ExecutionTime", "14:11:50");
		 configuration.addClassifications("PlatformVersion", "12.0");
		 configuration.addClassifications("Build", "10.1.3.272");
//		configuration.addClassifications("Platform", "IOS");
//		configuration.addClassifications("DeviceName", "iPhone_14");
//		configuration.addClassifications("StartTime", "29-08-2023 21:23:29");
//		configuration.addClassifications("EndTime", "29-08-2023 05:00:38");
//		configuration.addClassifications("ExecutionTime", "16:22:51");
//		configuration.addClassifications("PlatformVersion", "16");
//		configuration.addClassifications("Build", "10.1.3.269");
		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		Reportable result = reportBuilder.generateReports();
	
		
		}
}
