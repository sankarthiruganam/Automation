import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LocatorValidate {

	WebDriver driver;
	WebDriverWait wait;
	static ExcelReader reader = new ExcelReader();

	
	
	@Before
	public void setup() throws InterruptedException, InvalidFormatException, IOException {

		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	@Test
	public void test() throws InterruptedException, InvalidFormatException, IOException {
		driver.get("https://simmer-b.kfc-digital.io/");
		driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M12.9 21.5')]")).click();
		
		List<Map<String, String>> testData = reader.getData("src/main/resources/Data/MobileData.xlsx", "Page");
		wait = new WebDriverWait(driver, 30);
		driver.get("https://autokidstexas.axis360qa4.baker-taylor.com/");
		Assert.assertTrue(driver.getPageSource().contains(testData.get(0).get("LoginPage")));
		driver.findElement(By.id("loginBtn")).click();
		System.out.println("11"+testData.get(1).get("LoginPage"));
		System.out.println("33"+testData.get(2).get("LoginPage"));
	//	Assert.assertTrue(driver.getPageSource().contains(testData.get(1).get("LoginPage")));
	//	Assert.assertTrue(driver.getPageSource().contains(testData.get(2).get("LoginPage")));
		driver.findElement(By.id("LogOnModel_UserName")).sendKeys("BTAuto");
		driver.findElement(By.id("LogOnModel_Password")).sendKeys("password");
//		
		driver.findElement(By.xpath("//*[@type=\"submit\"]")).click();
		driver.findElement(By.id("LibraryManagement")).click();
		driver.findElement(By.id("LibrarySearch")).click();
		// driver.quit();
		System.out.println("done");
	}

	public boolean isElementPresent(WebElement e) {
		boolean flag = true;
		try {
			wait.until(ExpectedConditions.visibilityOf(e)).isDisplayed();
			flag = true;
		} catch (Exception a) {
			flag = false;
		}
		return flag;
	}

}
