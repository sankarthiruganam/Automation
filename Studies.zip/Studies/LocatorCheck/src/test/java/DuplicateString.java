
public class DuplicateString {

	public static void main(String[] args) {

		String name = "sankar";

		char[] darray=name.toCharArray();
		System.out.println("The string is:" + name);
	    System.out.print("Duplicate Characters in above string are: ");
		
		for(int i=0;i<name.length();i++)
		{
			for (int j=i+1;j<name.length();j++)
			{
				if(darray[i]==darray[j])
				{
					System.out.print(darray[j]);
					break;
				}
			}
		}
	}
}
