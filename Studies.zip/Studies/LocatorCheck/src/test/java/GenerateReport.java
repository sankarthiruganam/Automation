import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;

public class GenerateReport 
{

	public static void main(String[] args) {
		File reportOutputDirectory = new File("/Users/sankarthirugnan/Desktop/00003022023");
		List<String> jsonFiles = new ArrayList<>();
		jsonFiles.add("/Users/sankarthirugnan/Downloads/cucumber.json");
		jsonFiles.add("/Users/sankarthirugnan/Downloads/Run2CucumberTest.json");
		jsonFiles.add("/Users/sankarthirugnan/Downloads/Run3CucumberTest.json");
		jsonFiles.add("/Users/sankarthirugnan/Downloads/Run4CucumberTest.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/30032023/3/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/30032023/4/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/Smoke/Android-224-grp1/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/Smoke/FailedCases/cucumber.json");
		// jsonFiles.add("/Users/sankarthirugnan/Desktop/29930/ResultsMobile/cucumber.json");
		String projectName = "KidsZone_AutomationReport";
		Configuration configuration = new Configuration(reportOutputDirectory, projectName);
		// configuration.setBuildNumber(buildNumber);
		// configuration.addClassifications("Platform", "Android");
		// configuration.addClassifications("DeviceName", "Samsung_Galaxy_S21");
		// configuration.addClassifications("StartTime", "12-04-2023 18:40:08");
		// configuration.addClassifications("EndTime", "12-04-2023 19:17:52");
		// configuration.addClassifications("ExecutionTime", "00:37:44");
		// configuration.addClassifications("PlatformVersion", "11.0");
		// configuration.addClassifications("Build", "10.1.1.77");
//		configuration.addClassifications("Platform", "IOS");
//		configuration.addClassifications("DeviceName", "iPhone_13_Pro_Max");
//		configuration.addClassifications("StartTime", "09-06-2023 00:05:23");
//		configuration.addClassifications("EndTime", "09-06-2023 01:16:45");
//		configuration.addClassifications("ExecutionTime", " 01:11:22");
//		configuration.addClassifications("PlatformVersion", "14");
//		configuration.addClassifications("Build", "10.1.3.25");	
		configuration.addClassifications("Platform", "Web");
		configuration.addClassifications("Before Suite", "October 18, 2023, 2:14 PM");
		configuration.addClassifications("After Suite", "October 18, 2023, 3:25 PM");
		configuration.addClassifications("Browser Name", " chrome");
		configuration.addClassifications("BrowserVersion", "116");
		configuration.addClassifications("System Info", "Windows OS");
		configuration.addClassifications("OS Version", "10.0");
		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		Reportable result = reportBuilder.generateReports();
	
		}
		}

