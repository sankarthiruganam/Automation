
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class Hello {

	public static void main(String[] args) throws AWTException, InterruptedException {
		
		Robot robot = new Robot();

	  for (int i = 0; i < 10000; i++) {
			Thread.sleep(30000);
			robot.keyPress(KeyEvent.VK_UP);
			robot.keyRelease(KeyEvent.VK_UP);

			Thread.sleep(30000);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			System.out.println("The value of " + i);

		}
		
		
		
	}

	}
