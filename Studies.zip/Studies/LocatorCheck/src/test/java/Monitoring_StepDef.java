import io.cucumber.java.en.Given;

public class Monitoring_StepDef {

//	MonitoringUrl monitoringUrl =new MonitoringUrl();
	
	@Given("user is logged in as admin {string} and {string}")
	public void user_is_logged_in_as_admin_and(String username, String password) {
	//	monitoringUrl.admin_login(username, password);    
	}
}
