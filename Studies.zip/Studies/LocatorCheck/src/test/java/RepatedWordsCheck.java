import java.util.HashSet;
import java.util.Scanner;

public class RepatedWordsCheck {
	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the String\n");
		String s = scn.nextLine();
		HashSet<String> hset = new HashSet<>();
		for (String word : s.split(" ")) {
			if (hset.contains(word)) {
				System.out.println("The word is dupilcate :" + word);
			} else {
				hset.add(word);
			}
		}
	}

}
