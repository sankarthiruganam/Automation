import java.util.HashSet;

public class RepeatWordCheck {
	public static void main(String[] args) {
		
		String s ="welcome to photon photon is a worst company";
		
		HashSet<String> hset=new HashSet<String>();
		for (String word : s.split(" ")) {
			if (hset.contains(word)) {
				System.out.println("The word is dupilcate :" + word);
			} else {
				hset.add(word);
			}
		}
		
	}

}
