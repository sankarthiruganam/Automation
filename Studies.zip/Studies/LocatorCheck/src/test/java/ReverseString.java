
public class ReverseString {

	public static void main(String[] args) {
		
		String name="sankar";
		String s="";
		
		for(int i=0;i<name.length();i++)
		{
			s=name.charAt(i)+s;
		}
		System.out.println(s);
	}
}
