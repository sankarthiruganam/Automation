$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "d8b487ac-5301-42a7-8659-eff3bac0a8d7",
    "feature": "Profile Creation API validation with BDD for get, post and Put methods",
    "scenario": "To verify if the user is able to create the profile using POST method",
    "start": 1695828856543,
    "end": 1695828861446,
    "group": 1,
    "content": "",
    "className": "passed",
    "tags": "@api,@post,"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});