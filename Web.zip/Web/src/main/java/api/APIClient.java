package api;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.utilities.Logger;

import api.MagicWall.GetTitlesResponse;
import api.curatedList.CuratedResponse;
import api.libraryComponents.ComponentResponse;
import api.magicWallList.FeaturedList;
import api.searchTitlev8.SearchTitleResponse;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APIClient {

	static Map<String, String> requestBody = new HashMap<>();
	static Map<String, String> queryParams = new HashMap<>();
	static Map<String, String> headers = new HashMap<>();


	public static <T> T makeRequest(String baseUrl, String endpoint, RequestMethod method, Object requestBody,
	                               Map<String, String> queryParams, Map<String, String> headers, Class<T> responseClass) throws JsonParseException, JsonMappingException, IOException {
	    RequestSpecification requestSpec = RestAssured.given().headers(headers).log().all();

	    if (queryParams != null) {
	        requestSpec.queryParams(queryParams);
	    }

	    if (requestBody != null) {
	        requestSpec.contentType(ContentType.JSON).body(requestBody);
	    }

	    Response response;

	    if (method == RequestMethod.GET) {
	        response = requestSpec.when().get(baseUrl + endpoint);
	    } else if (method == RequestMethod.POST) {
	        response = requestSpec.when().post(baseUrl + endpoint);
	    } else {
	        throw new IllegalArgumentException("Unsupported HTTP request method: " + method);
	    }

	    System.out.println("Response status code for : " + responseClass.getName() + " " + response.getStatusCode());
//	    System.out.println("Response body: " + response.getBody().asString());

	    if (response.getStatusCode() == 200) {
	        ObjectMapper objectMapper = new ObjectMapper();
	        return objectMapper.readValue(response.getBody().asString(), responseClass);
	    } else {
	        System.out.println("Response status line: " + response.getStatusLine());
	        throw new RuntimeException("API request failed with status code: " + response.getStatusCode());
	    }
	}

	public static <T> T makeRequest(String baseUrl, String endpoint, RequestMethod method, Object requestBody,
	                               Map<String, String> queryParams, Map<String, String> headers, TypeReference<T> responseType) throws JsonParseException, JsonMappingException, IOException {
	    RequestSpecification requestSpec = RestAssured.given().headers(headers).log().all();

	    if (queryParams != null) {
	        requestSpec.queryParams(queryParams);
	    }

	    if (requestBody != null) {
	        requestSpec.contentType(ContentType.JSON).body(requestBody);
	    }

	    Response response;

	    if (method == RequestMethod.GET) {
	        response = requestSpec.when().get(baseUrl + endpoint);
	    } else if (method == RequestMethod.POST) {
	        response = requestSpec.when().post(baseUrl + endpoint);
	    } else {
	        throw new IllegalArgumentException("Unsupported HTTP request method: " + method);
	    }

	    System.out.println("Response status code for : " + responseType.getType() + " " + response.getStatusCode());
//	    System.out.println("Response body: " + response.getBody().asString());

	    if (response.getStatusCode() == 200) {
	        ObjectMapper objectMapper = new ObjectMapper();
	        return objectMapper.readValue(response.getBody().asString(), responseType);
	    } else {
	        System.out.println("Response status line: " + response.getStatusLine());
	        throw new RuntimeException("API request failed with status code: " + response.getStatusCode());
	    }
	}


	public static SearchTitleResponse getSearchTitleResponse(String searchTerm, String searchType, String searchSort, String audienceDesc) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
			JsonNode searchTitleConfig = configNode.get("searchTitlev6");

			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();
			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});

			queryParams.put("searchTerm", searchTerm);
			queryParams.put("searchType", searchType);
			queryParams.put("SearchSort", searchSort);
			queryParams.put("audienceDesc", audienceDesc);
			
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});

			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			headers.put("Library", TokenManager.getLibPrefix());

			return makeRequest(baseUrl, endpoint, RequestMethod.GET, requestBody, queryParams, headers,
					SearchTitleResponse.class);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}
	
	public static SearchTitleResponse getSearchTitleResponse(String formatType, String searchTerm, String searchType, String searchSort, String audienceDesc, String collection, String language, String axisattribute, String profileType) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
			JsonNode searchTitleConfig = configNode.get("searchTitlev6");

			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();
			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			queryParams.put("formatType", formatType);
			queryParams.put("searchTerm", searchTerm);
			queryParams.put("searchType", searchType);
			queryParams.put("SearchSort", searchSort);
			queryParams.put("audienceDesc", audienceDesc);
			queryParams.put("collection", collection);
			queryParams.put("languagedesc", language);
			queryParams.put("axisattribute", axisattribute);
			queryParams.put("profileType", profileType);
			
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});		
//			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			headers.put("Library", TokenManager.getLibPrefix());
			
			SearchTitleResponse a = makeRequest(baseUrl, endpoint, RequestMethod.GET, requestBody, queryParams, headers,
					SearchTitleResponse.class);
			Logger.log("response with the collection type " + collection + " is: " + a.toString());
			return a;
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}
	
	public static SearchTitleResponse getThirdPartySearchTitleResponse(String formatType, String contentCollectionId, String searchTerm, String searchType, String searchSort, String audienceDesc, String language) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
//			System.out.println("configNode: " + configNode);
			JsonNode searchTitleConfig = configNode.get("thirdPartySearch");
//			System.out.println("searchTitleConfig: " + searchTitleConfig);

			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();
			System.out.println("baseUrl: " + baseUrl);
			System.out.println("endpoint: " + endpoint);
			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			queryParams.put("formatType", formatType);
			queryParams.put("contentCollectionId", contentCollectionId);
			queryParams.put("searchTerm", searchTerm);
			queryParams.put("searchType", searchType);
			queryParams.put("SearchSort", searchSort);
			queryParams.put("audienceDesc", audienceDesc);
			queryParams.put("languagedesc", language);
			
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			
			System.out.println("AuthToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			System.out.println("bearerToken: " + bearerToken);
			headers.put("Authorization", bearerToken);
//			headers.put("Library", TokenManager.getLibPrefix());
			headers.put("thirdparty", "true");

			return makeRequest(baseUrl, endpoint, RequestMethod.GET, requestBody, queryParams, headers,
					SearchTitleResponse.class);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}

	public static List<SearchTitleResponse> getBrowseSearchTitleResponse(String searchSort) {
		ObjectMapper objectMapper = new ObjectMapper();
		List<SearchTitleResponse> browseSearchResponses = new ArrayList<>();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
//			System.out.println("configNode: " + configNode);
			JsonNode searchTitleConfig = configNode.get("searchTitlev8");
//			System.out.println("searchTitleConfig: " + searchTitleConfig);

			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();
			System.out.println("baseUrl: " + baseUrl);
			System.out.println("endpoint: " + endpoint);
			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			queryParams.put("SearchSort", searchSort);
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			
			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			headers.put("Library", TokenManager.getLibPrefix());
			JsonNode bisacCodeNode = configNode
				    .get("searchTitlev8")
				    .get("requestBody")
				    .get("bisacCode");

			List<String> bisacCodeList = new ArrayList<>();
			if (bisacCodeNode != null && bisacCodeNode.isArray()) {
			    
				bisacCodeList = new ObjectMapper().convertValue(bisacCodeNode, new TypeReference<List<String>>() {});
			} else {
			    // Handle the case when "bisacCode" is missing or not an array
			}

			for (String bisacCode : bisacCodeList) {
				System.out.println("Bisac Code: " + bisacCode);

				Map<String, String> requestBody = new HashMap<>();
				requestBody.put("bisacCode", bisacCode);
				SearchTitleResponse browseResponse = makeRequest(baseUrl, endpoint, RequestMethod.POST, requestBody,
						queryParams, headers, SearchTitleResponse.class);
				browseSearchResponses.add(browseResponse);
			}

			return browseSearchResponses;

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}
	
	
	public static List<SearchTitleResponse> getBrowseSearchTitleResponse(String searchSort, String subject, String BisacCodes, String availability, String formatType, String ageLevel, String languageDesc, String collection) {
		ObjectMapper objectMapper = new ObjectMapper();
		List<SearchTitleResponse> browseSearchResponses = new ArrayList<>();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
//			System.out.println("configNode: " + configNode);
			JsonNode searchTitleConfig = configNode.get("searchTitlev8");
//			System.out.println("searchTitleConfig: " + searchTitleConfig);

			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();
			System.out.println("baseUrl: " + baseUrl);
			System.out.println("endpoint: " + endpoint);
//			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
//					new TypeReference<Map<String, String>>() {
//					});
		
			
			queryParams.put("pageSize", "20000");
			queryParams.put("searchType", "Subject");
			queryParams.put("searchTerm", "term");
			queryParams.put("SearchSort", searchSort);
			queryParams.put("availability", availability);
			queryParams.put("formatType", formatType);
			queryParams.put("audienceDesc", ageLevel);
			queryParams.put("languageDesc", languageDesc);
			queryParams.put("collection", collection);
			
			
			
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			
			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			headers.put("Library", TokenManager.getLibPrefix());
			JsonNode bisacCodeNode = configNode
				    .get("searchTitlev8")
				    .get("requestBody");
//				    .get("bisacCode");

			List<String> bisacCodeList = new ArrayList<>();
			if (bisacCodeNode != null && bisacCodeNode.isArray()) {
			    
				bisacCodeList = new ObjectMapper().convertValue(bisacCodeNode, new TypeReference<List<String>>() {});
			} else {
			    // Handle the case when "bisacCode" is missing or not an array
			}

//			for (String bisacCode : bisacCodeList) {
//				System.out.println("Bisac Code: " + bisacCode);

				Map<String, String> requestBody = new HashMap<>();
				requestBody.put("bisacCode",BisacCodes);
				System.out.println("bisacCode " + BisacCodes);
				SearchTitleResponse browseResponse = makeRequest(baseUrl, endpoint, RequestMethod.POST, requestBody,
						queryParams, headers, SearchTitleResponse.class);
				browseSearchResponses.add(browseResponse);
//			}

			return browseSearchResponses;

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}

	public static ComponentResponse getComponentResponse() {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);

			JsonNode searchTitleConfig = configNode.get("libraryComponent");
			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();

			Map<String, String> queryParams = objectMapper.convertValue(searchTitleConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});

			return makeRequest(baseUrl, endpoint, RequestMethod.GET, null, queryParams, headers,
					ComponentResponse.class);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}
	

	public static GetTitlesResponse getLibraryResponse(String profileType) {
		ObjectMapper objectMapper = new ObjectMapper();
		
		
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);
			
			JsonNode componentLibrary = configNode.get("magicWallCarousel");
			String baseUrl = componentLibrary.get("baseUrl").asText();
			String endpoint = componentLibrary.get("endpoint").asText();
			
			Map<String, String> queryParams = objectMapper.convertValue(componentLibrary.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			queryParams.put("profileType", profileType);
		
			Map<String, String> headers = objectMapper.convertValue(componentLibrary.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			
			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			headers.put("Library", TokenManager.getLibPrefix());
			
			return makeRequest(baseUrl, endpoint, RequestMethod.GET, bearerToken, queryParams, headers, 
					GetTitlesResponse.class);
		
			
			
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
		
		
	} 
	
	public static List<CuratedResponse> getCuratedResponse(String profileType, String profileId, String entityList) {
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);

			JsonNode curatedConfig = configNode.get("curatedList");
			String baseUrl = curatedConfig.get("baseUrl").asText();
			String endpoint = curatedConfig.get("endpoint").asText();
			
			Map<String, String> requestBody = objectMapper.convertValue(curatedConfig.get("requestBody"),
					new TypeReference<Map<String, String>>() {
					});
			
			queryParams.put("availability", "ALL");
			queryParams.put("format", "ALL");
			queryParams.put("profileType", profileType);
//
//			Map<String, String> queryParams = objectMapper.convertValue(curatedConfig.get("queryParams"),
//					new TypeReference<Map<String, String>>() {
//					});
			requestBody.put("profileId", profileId);
			requestBody.put("listId", entityList);
			
			Map<String, String> headers = objectMapper.convertValue(curatedConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
				
			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			
			return makeRequest(baseUrl, endpoint, RequestMethod.POST, requestBody, queryParams, headers,
	                new TypeReference<List<CuratedResponse>>() {
	                });
					

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
		
		
	}
	
public static FeaturedList getFeaturedListResponse(String paramCatagory, String profileType) {
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);

			JsonNode featuredConfig = configNode.get("magicWallList");
			String baseUrl = featuredConfig.get("baseUrl").asText();
			String endpoint = featuredConfig.get("endpoint").asText();

			Map<String, String> queryParams = objectMapper.convertValue(featuredConfig.get("queryParams"),
					new TypeReference<Map<String, String>>() {
					});
			queryParams.put("paramCatagory", paramCatagory);
			queryParams.put("profileType", profileType);
			
			Map<String, String> headers = objectMapper.convertValue(featuredConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			
			System.out.println("bearerToken: " + TokenManager.getToken());
			String bearerToken = "Bearer " + TokenManager.getToken();
			headers.put("Authorization", bearerToken);
			
			return makeRequest(baseUrl, endpoint, RequestMethod.GET, bearerToken, queryParams, headers, 
					FeaturedList.class);
					

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
		
		
	}
	

	public enum RequestMethod {
		GET, POST
	}
	
	 

}
