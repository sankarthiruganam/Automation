package api.MagicWall;

import java.util.List;


public class Authors {
	private Object author;
//	private List<Author> author;
	private Object narrator;
	
	  public Object getAuthor() {
	        return author;
	    }

	    public void setAuthor(Object author) {
	        this.author = author;
	    }
	public Object getNarrator() {
		return narrator;
	}
	public void setNarrator(Object narrator) {
		this.narrator = narrator;
	}
	

}
