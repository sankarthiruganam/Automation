package api.MagicWall;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Categories {
	
	@JsonProperty("catagory") 
	private List<Category> catagory;
//	private Object searchParameters;
	
	
	
	public List<Category> getCategory() {
		return catagory;
	}
	public void setCategory(List<Category> category) {
		this.catagory = category;
	}
//	public Object getSearchParameters() {
//		return searchParameters;
//	}
//	public void setSearchParameters(Object searchParameters) {
//		this.searchParameters = searchParameters;
//	}

}
