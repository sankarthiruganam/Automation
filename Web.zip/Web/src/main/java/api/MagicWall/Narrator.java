package api.MagicWall;

public class Narrator {

}
