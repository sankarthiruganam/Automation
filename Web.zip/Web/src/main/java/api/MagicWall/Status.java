package api.MagicWall;

public class Status {
	
	private String code;
	private String statusMessage;
	
	
	  public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getStatusMessage() {
			return statusMessage;
		}
		public void setStatusMessage(String statusMessage) {
			this.statusMessage = statusMessage;
		}

}
