package api.MagicWall;

public class TitleResponse {
	
	private TitleResult getTitleResult;
	

	public TitleResult getGetTitleResult() {
		return getTitleResult;
	}

	public void setGetTitleResult(TitleResult getTitleResult) {
		this.getTitleResult = getTitleResult;
	}

}
