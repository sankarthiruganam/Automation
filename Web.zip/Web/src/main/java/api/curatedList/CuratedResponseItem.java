package api.curatedList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CuratedResponseItem {
	private String isbn;
	private String itemId;
	private String libraryId;
	private String listId;
	private String title;
	private String author;
	private String narrator;
	private String formatType;
	private boolean isAvailable;
	private boolean isRTV;
	private boolean isRecommendable;
	private int totalQuantity;
	private int onOrderQuantity;
	private Object rtvFormats;
	private int activeHolds;
	private String listName;
	private int rank;
	private int sortOrder;
	private String sortField;
	private Object collectionType;
	private Object edition;
	private Object length;
	private List<String> axisAttribute;
	private Object runTime;
	private int fileSize;
	private String imageUrl;
	private boolean isHold;
	private String bookLength;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getLibraryId() {
		return libraryId;
	}

	public void setLibraryId(String libraryId) {
		this.libraryId = libraryId;
	}

	public String getListId() {
		return listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getNarrator() {
		return narrator;
	}

	public void setNarrator(String narrator) {
		this.narrator = narrator;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public boolean isRTV() {
		return isRTV;
	}

	public void setRTV(boolean isRTV) {
		this.isRTV = isRTV;
	}

	public boolean isRecommendable() {
		return isRecommendable;
	}

	public void setRecommendable(boolean isRecommendable) {
		this.isRecommendable = isRecommendable;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public int getOnOrderQuantity() {
		return onOrderQuantity;
	}

	public void setOnOrderQuantity(int onOrderQuantity) {
		this.onOrderQuantity = onOrderQuantity;
	}

	public Object getRtvFormats() {
		return rtvFormats;
	}

	public void setRtvFormats(Object rtvFormats) {
		this.rtvFormats = rtvFormats;
	}

	public int getActiveHolds() {
		return activeHolds;
	}

	public void setActiveHolds(int activeHolds) {
		this.activeHolds = activeHolds;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public Object getCollectionType() {
		return collectionType;
	}

	public void setCollectionType(Object collectionType) {
		this.collectionType = collectionType;
	}

	public Object getEdition() {
		return edition;
	}

	public void setEdition(Object edition) {
		this.edition = edition;
	}

	public Object getLength() {
		return length;
	}

	public void setLength(Object length) {
		this.length = length;
	}

	public List<String> getAxisAttribute() {
		return axisAttribute;
	}

	public void setAxisAttribute(List<String> axisAttribute) {
		this.axisAttribute = axisAttribute;
	}

	public Object getRunTime() {
		return runTime;
	}

	public void setRunTime(Object runTime) {
		this.runTime = runTime;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public boolean isHold() {
		return isHold;
	}

	public void setHold(boolean isHold) {
		this.isHold = isHold;
	}

	public String getBookLength() {
		return bookLength;
	}

	public void setBookLength(String bookLength) {
		this.bookLength = bookLength;
	}

}
