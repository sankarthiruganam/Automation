package api.enums;

public class GenericEnum {



	public enum Categories {

		Programming("COM051000"), Travel("TRV000000") , Body("OCC000000"), Activity("JUV054000"),
		Family("YAF018000#YAF020000#YAF027000"),Interior("ARC007000"),Comics("CGN000000"),
		Literary("CGN006000"),Humorous("CGN014000"),Color("ART007000"), Concepts("JUV009000"),
		Biography("YAN006000"),Action("YAF001000"),Holidays("JNF026000"),Fantasy("JUV037000");

		private final String description;

		Categories(String description) {
			this.description = description;
		}

		public String getDescription() {
			return description;
		}

	}
	
	
	public enum SearchParams {
		
		format("EBT", "ABT", "videobook", "video"),
		collection("REG"),
		collectionId("8c573edd-60c4-ed11-a8e0-000d3a4e28de", "7ed395cc-61c4-ed11-a8e0-000d3a4e28de"),
		axisattribute("RAL");
		
		private String eformatType;
		private String aformatType;
		private String videobook;
		private String video;
		private String params;
		private String vbCollectionId;
		private String vcollectionId;

		

		SearchParams(String eformatType, String aformatType, String videoBook, String video) {
			this.eformatType = eformatType;
			this.aformatType = aformatType;
			this.videobook = videoBook;
			this.video = video;
			
		}
		
		SearchParams(String vbCollectionId, String vcollectionId){
			this.vbCollectionId = vbCollectionId;
			this.vcollectionId = vcollectionId;
			
		}
		
		 SearchParams(String params) {
			this.params = params;
		}
		
		public String getEformatType() {
			return eformatType;
		}
		
		public String getAformatType() {
			return aformatType;
		}
		
		public String getParams() {
			return params;
		}
		
		public String getVideobook() {
			return videobook;
		}

		public String getVideo() {
			return video;
		}
		
		public String getVbCollectionId() {
			return vbCollectionId;
		}

		public String getVcollectionId() {
			return vcollectionId;
		}

			
	}

}
