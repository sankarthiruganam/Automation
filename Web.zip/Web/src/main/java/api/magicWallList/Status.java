package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Status {
	
	
	@JsonProperty("@xmlns")
	private String xmlns;
	@JsonProperty("code")
	private String code;
	@JsonProperty("statusMessage")
	private String statusMessage;
	
	public String getXmlns() {
		return xmlns;
	}
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

}
