package api.patronProfileInfo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PatronProfileInfo {
	
	@JsonProperty("defaultLandingPageID")
    private int defaultLandingPageID;

	@JsonProperty("highContrast")
    private boolean highContrast;

	@JsonProperty("invalidAttempts")
    private int invalidAttempts;

	@JsonProperty("isAutoCheckedout")
    private boolean isAutoCheckedout;

	@JsonProperty("isLocked")
    private boolean isLocked;

	@JsonProperty("isPrimary")
    private boolean isPrimary;

	@JsonProperty("isTrackingEnabled")
    private boolean isTrackingEnabled;

	@JsonProperty("numberOfRecommendations")
    private int numberOfRecommendations;

	@JsonProperty("parentalPin")
    private String parentalPin;

	@JsonProperty("profileEmail")
    private String profileEmail;

	@JsonProperty("profileId")
    private String profileId;

	@JsonProperty("profileImage")
    private String profileImage;

	@JsonProperty("profileName")
    private String profileName;

	@JsonProperty("profileTypeId")
    private String profileTypeId;

	@JsonProperty("profileTypeName")
    private String profileTypeName;

    // Getter and setter methods for each field

    public int getDefaultLandingPageID() {
        return defaultLandingPageID;
    }

    public void setDefaultLandingPageID(int defaultLandingPageID) {
        this.defaultLandingPageID = defaultLandingPageID;
    }

    public boolean isHighContrast() {
        return highContrast;
    }

    public void setHighContrast(boolean highContrast) {
        this.highContrast = highContrast;
    }

    public int getInvalidAttempts() {
        return invalidAttempts;
    }

    public void setInvalidAttempts(int invalidAttempts) {
        this.invalidAttempts = invalidAttempts;
    }

    public boolean isAutoCheckedout() {
        return isAutoCheckedout;
    }

    public void setAutoCheckedout(boolean isAutoCheckedout) {
        this.isAutoCheckedout = isAutoCheckedout;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean isLocked) {
        this.isLocked = isLocked;
    }

    public boolean isPrimary() {
        return isPrimary;
    }

    public void setPrimary(boolean isPrimary) {
        this.isPrimary = isPrimary;
    }

    public boolean isTrackingEnabled() {
        return isTrackingEnabled;
    }

    public void setTrackingEnabled(boolean isTrackingEnabled) {
        this.isTrackingEnabled = isTrackingEnabled;
    }

    public int getNumberOfRecommendations() {
        return numberOfRecommendations;
    }

    public void setNumberOfRecommendations(int numberOfRecommendations) {
        this.numberOfRecommendations = numberOfRecommendations;
    }

    public String getParentalPin() {
        return parentalPin;
    }

    public void setParentalPin(String parentalPin) {
        this.parentalPin = parentalPin;
    }

    public String getProfileEmail() {
        return profileEmail;
    }

    public void setProfileEmail(String profileEmail) {
        this.profileEmail = profileEmail;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getProfileTypeId() {
        return profileTypeId;
    }

    public void setProfileTypeId(String profileTypeId) {
        this.profileTypeId = profileTypeId;
    }

    public String getProfileTypeName() {
        return profileTypeName;
    }

    public void setProfileTypeName(String profileTypeName) {
        this.profileTypeName = profileTypeName;
    }
}

