package api.searchTitlev8;

public class Narrators {
    // This field can be either a single string or a list of strings
    private Object narrator;

    public Object getNarrator() {
        return narrator;
    }

    public void setNarrator(Object narrator) {
        this.narrator = narrator;
    }
}
