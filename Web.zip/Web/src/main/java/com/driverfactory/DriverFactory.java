package com.driverfactory;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

import com.driverfactory.manager.AndroidDriverManager;
import com.driverfactory.manager.ChromeDriverManager;
import com.driverfactory.manager.EdgeDriverManager;
import com.driverfactory.manager.FirefoxDriverManager;
import com.driverfactory.manager.IEDriverManager;
import com.driverfactory.manager.IOSDriverManager;
import com.driverfactory.manager.SafariDriverManager;

import exceptions.BrowserNotSupportedException;

public class DriverFactory {

	public WebDriver getDriver(Target target) {
		WebDriver driver;
	    String browser =System.getProperty("browser");
		BrowserList browserType = BrowserList.valueOf(browser.toUpperCase());
		Dimension dimension = new Dimension(980, 534);
		
		switch (browserType) {

		case CHROME:
			driver = new ChromeDriverManager().createDriver(target);
			driver.manage().window().maximize();
//			driver.manage().window().setSize(dimension);
			break;
		case FIREFOX:
			driver = new FirefoxDriverManager().createDriver(target);
			driver.manage().window().maximize();
			break;
		case EDGE:
			driver = new EdgeDriverManager().createDriver(target);
			driver.manage().window().maximize();
			break;
		case SAFARI:
			driver = new SafariDriverManager().createDriver(target);
			driver.manage().window().maximize();
			break;
		case IE:
			driver = new IEDriverManager().createDriver(target);
			driver.manage().window().maximize();
			break;
		case ANDROID:
			driver = new AndroidDriverManager().createDriver(target);
			break;
		case IOS:
			driver = new IOSDriverManager().createDriver(target);
			break;
		default:
			throw new BrowserNotSupportedException(browser);
		}
		return driver;
	}

	public enum BrowserList {
		CHROME, FIREFOX, EDGE, SAFARI, OPERA, IE, ANDROID, IOS
	}

	public enum Target {
		LOCAL, REMOTE
	}
	
}
