package pom.kidszone;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class AdminPrograms extends CommonAction {

	public static String cardNumber;

	public AdminPrograms(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	static ExcelReader reader = new ExcelReader();

	@FindBy(xpath = "//div[@class='icon_menu_programs']")
	private WebElement salesdemoLib_label_programsCTA;

	@FindBy(xpath = "//div[@class='create-program-cta']/button")
	private WebElement salesdemoLib_Btn_CreateprogramsCTA;

	@FindBy(xpath = "//span[text()='Save']")
	private WebElement salesdemoLib_Btn_SaveCTA;

	@FindBy(id = "mat-error-2")
	private WebElement salesdemoLib_errormsg_notselectProfiletype;

	@FindBy(id = "cp-enter-name")
	private WebElement salesdemoLib_input_programName;

	@FindBy(id = "cp-title-btn")
	private WebElement salesdemoLib_addprofileCTA;

	@FindBy(xpath = "//label[@role='heading']")
	private WebElement salesdemoLib_txt_searchResultscreen;

	@FindBy(id = "searchTerm")
	private WebElement salesdemoLib_input_searchResultscreen;

	@FindBy(id = "sch-rslt-title")
	private WebElement salesdemoLib_input_actualsearchResults;

	@FindBy(xpath = "//span[text()='Profile Type: Adult']")
	private WebElement filter_defaultAdultprofileType;

	@FindBy(xpath = "//*[@panelclass='select-option-overlay-pane']")
	private WebElement salesdemoLib_filterArrow;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	private List<WebElement> salesdemoLib_txt_listofProfiltTypes;

	@FindBy(xpath = "//img[@alt='reading program icon']")
	private List<WebElement> btn_existingprograms;

	@FindBy(xpath = "//h4[text()='Program Details']")
	private WebElement Nav_readingProgramScreen;

	@FindBy(xpath = "//label[text()='PROFILE TYPES']")
	private WebElement txt_profileDetails;

	@FindBy(xpath = "//mat-select[@id='cp-select-progtyp']")
	private WebElement dropdown_setProgramType;

	@FindBy(xpath = "//span[text()=' Books in Order']")
	private WebElement dropdown_option_setProgramType;

	@FindBy(xpath = "(//mat-icon[@role='button'])[1]")
	private WebElement calender_setStartDate;

	@FindBy(xpath = "(//mat-icon[@role='button'])[2]")
	private WebElement calender_setendDate;

	@FindBy(xpath = "//button[@aria-label='Next month']")
	private WebElement calender_setendDate_nextArrow;

	@FindBy(xpath = "//div[contains(@class, 'calendar-body-today')]/parent::td")
	private WebElement calender_setStartDate_currentDate;

	@FindBy(xpath = "//div[@class='mat-checkbox-inner-container']")
	private List<WebElement> checkbox_profileTypes;
	
	@FindBy(id = "mat-checkbox-1")
	private WebElement profiletype_all;
	
	@FindBy(xpath = "//*[@class='profile-type-sec']")
	private WebElement profileTypeTab;

	@FindBy(id = "mat-checkbox-2")
	private WebElement profiletype_Adult;

	@FindBy(id = "mat-checkbox-3")
	private WebElement profiletype_Teen;

	@FindBy(id = "mat-checkbox-3")
	private WebElement profiletype_kid;

	@FindBy(id = "pd-duplcate")
	private WebElement link_DublicateProgram;

	@FindBy(xpath = "//span[text()='Publish Program']")
	private WebElement btn_publishProgram;

	@FindBy(xpath = "//*[@id='mat-tab-label-0-2']/div")
	private WebElement btn_ActiveProgram;

	@FindBy(xpath = "//div[@id='mat-tab-label-0-1']")
	private WebElement btn_draftProgram;

	@FindBy(xpath = "//div[@id='mat-tab-label-0-3']")
	private WebElement btn_closedProgram;

	@FindBy(xpath = "//img[@alt='reading program icon']")
	private List<WebElement> img_listOfprograms;

	@FindBy(id = "pd-editprg")
	private WebElement link_editprogram;

	@FindBy(xpath = "//h2[text()='Create Reading Program']")
	private WebElement txt_createReadingProgm;

	@FindBy(xpath = "//h5[text()='Reading Program']")
	private WebElement txt_NavprofileDetailscreen;

	@FindBy(xpath = "//p[@class='profile-detail-text']")
	private WebElement txt_profiledetailscreen_profile;

	@FindBy(xpath = "//p[@class='small-para ng-star-inserted']")
	private List<WebElement> txt_profileenabled;

	@FindBy(xpath = "(//div[@class='mat-ripple mat-option-ripple'])")
	private List<WebElement> dropoption_profiltyTypeoption;

	@FindBy(xpath = "//*[@panelclass='select-option-overlay-pane']/div//div[2]")
	private WebElement view_filteroption;
	
	@FindBy(xpath = "//h4[text()='Add Titles ']")
	private WebElement txt_addTitle;

	@FindBy(xpath = "(//td[@class='mat-calendar-body-cell mat-focus-indicator ng-star-inserted'])[15]")
	private WebElement select_endDate;

	@FindBy(xpath = "//h2[text()='Edit Reading Program']")
	private WebElement txt_NaveditReadingProgram;

	@FindBy(xpath = "//*[@role='progressbar']")
	private WebElement progressbar;
	
	@FindBy(xpath = "//span[@class='mat-checkbox-label']")
	private List<WebElement> editprog_adultcheckbox;
	
	@FindBy(xpath = "//div[@class='icon_menu_home_selected']")
	private WebElement home_cta;
	
    @FindBy(xpath = "//div[text()='Settings']")
    private WebElement settings_cta;
    
    @FindBy(xpath = "//div[text()='Library Settings']")
    private WebElement library_settings_cta;
    
    @FindBy(xpath = "//li[text()='Library Settings']")
    private WebElement library_management_screen;

	public WebElement getProfileTypeTab() {
		return profileTypeTab;
	}
    
	public List<WebElement> getCheckbox_profileTypes() {
		return checkbox_profileTypes;
	}

	public WebElement getLibrary_management_screen() {
		return library_management_screen;
	}

	public WebElement getLibrary_settings_cta() {
		return library_settings_cta;
	}

	public WebElement getSettings_cta() {
		return settings_cta;
	}

	public WebElement getHome_cta() {
		return home_cta;
	}

	public WebElement getTxt_NavprofileDetailscreen() {
		return txt_NavprofileDetailscreen;
	}

	public WebElement getTxt_profiledetailscreen_profile() {
		return txt_profiledetailscreen_profile;
	}

	public WebElement getTxt_createReadingProgm() {
		return txt_createReadingProgm;
	}

	public WebElement getTxt_NaveditReadingProgram() {
		return txt_NaveditReadingProgram;
	}

	public WebElement getSalesdemoLib_errormsg_notselectProfiletype() {
		return salesdemoLib_errormsg_notselectProfiletype;
	}

	public WebElement getSalesdemoLib_Btn_CreateprogramsCTA() {
		return salesdemoLib_Btn_CreateprogramsCTA;
	}

	public WebElement getNav_readingProgramScreen() {
		return Nav_readingProgramScreen;
	}

	public WebElement getFilter_defaultAdultprofileType() {
		return filter_defaultAdultprofileType;
	}

	public WebElement getSalesdemoLib_filterArrow() {
		return salesdemoLib_filterArrow;
	}

	public WebElement getSalesdemoLib_input_actualsearchResults() {
		return salesdemoLib_input_actualsearchResults;
	}

	public WebElement getSalesdemoLib_txt_searchResultscreen() {
		return salesdemoLib_txt_searchResultscreen;
	}

	public void click_programsCTA() {
		ClickOnWebElement(salesdemoLib_label_programsCTA);
	}

	public void click_drafprogram() {
		jsClick(btn_draftProgram);
		isElementPresent(salesdemoLib_Btn_CreateprogramsCTA);
		Logger.log("system should navigate to draftprogram screen");
	}

	public void click_createProgramCTA() {
		waitFor(2000);
		visibilityWait(salesdemoLib_Btn_CreateprogramsCTA);
		jsClick(salesdemoLib_Btn_CreateprogramsCTA);
		waitFor(2000);
		
	}

	public void click_SaveCTA() {
		javascriptScroll(salesdemoLib_Btn_SaveCTA);
		ClickOnWebElement(salesdemoLib_Btn_SaveCTA);
	}

	public boolean notSee_profileTypeOption() {
		javascriptScroll(txt_addTitle);
		boolean b = false;
		if (isElementPresent(txt_profileDetails)) {
			b = true;
			System.out.println("user should not see profile type option");
		}
		return b;

	}

	public void progressbar() {
		visibilityWait(progressbar);
		inVisibilityWait(progressbar);
		
	}

	public void click_addTitle() {
		javascriptScroll(salesdemoLib_addprofileCTA);
//		waitFor(2000);
		visibilityWait(salesdemoLib_addprofileCTA);
		ClickOnWebElement(salesdemoLib_addprofileCTA);
	}

	public boolean errormsg_notProfileSelected() {
		javascriptScroll(salesdemoLib_Btn_CreateprogramsCTA);
		boolean b = true;
		isElementPresent(salesdemoLib_errormsg_notselectProfiletype);
		return b;
	}
	
	public boolean not_seeprofileType() { 
		boolean b = false;
	if (isElementPresent(txt_profiledetailscreen_profile)) {
		b=true;
		System.out.println("user is not able to see profile type option");
	}
	return b;
		
	}

	public void view_programEnabled() {
		for (int i = 0; i < txt_profileenabled.size(); i++) {
			if (isElementPresent(txt_profileenabled.get(i))) {
				Logger.log(" user should view programs enabled for all profiles");
			}
		}

	}

	public void enter_searchTitles() {
		SendKeysOnWebElement(salesdemoLib_input_searchResultscreen, "Theme");
		waitFor(2000);
	}

	public void clickfilter_viewProfileTypes() {
		visibilityWait(salesdemoLib_filterArrow);
		jsClick(salesdemoLib_filterArrow);
		waitFor(2000);
		for (int i = 0; i < salesdemoLib_txt_listofProfiltTypes.size(); i++) {
			isElementPresent(salesdemoLib_txt_listofProfiltTypes.get(i));
		}
		
		/*
		//ClickOnWebElement(salesdemoLib_filterArrow);
		isElementPresent(dropoption_profiltyTypeall);
		try {
			isElementPresent(dropoption_profileTypeadult);
		} catch (Exception e) {
			e.printStackTrace();
		}
//		isElementPresent(dropoption_profileTypeadult);
		isElementPresent(dropoption_profileTypeTeen);
		isElementPresent(dropoption_profileTypekid);
		*/
	}

	public void selectDropdown_profiletypeAll() {
		//progressbar();
		visibilityWait(dropoption_profiltyTypeoption.get(0));
		jsClick(dropoption_profiltyTypeoption.get(0));
		//ClickOnWebElement(dropoption_profiltyTypeall);
	}

	public void selectDropdown_profileTypeadult() {
		for (int i = 0; i < dropoption_profiltyTypeoption.size(); i++) {
			if (dropoption_profiltyTypeoption.get(1).getText().contains("Adult")) {
				ClickOnWebElement(dropoption_profiltyTypeoption.get(i));
				waitFor(2000);
			}
		}
		
		
	}

	public void selectDropdown_profileTypeTeen() {	
		visibilityWait(dropoption_profiltyTypeoption.get(1));
		jsClick(dropoption_profiltyTypeoption.get(1));
	}

	public void selectDropdown_profileTypekid() {
		visibilityWait(dropoption_profiltyTypeoption.get(2));
		jsClick(dropoption_profiltyTypeoption.get(2));
	}
	
	
	public void dropdown_notshowing_adultprofileType() {
		for (int i = 0; i < dropoption_profiltyTypeoption.size(); i++) {
			if (!dropoption_profiltyTypeoption.get(i).getText().contains("Adult")) {
				Logger.log(" user should not view adult profile type in filter option");
			}
		}
		}

	public void click_editPrograms() {
		int size = btn_existingprograms.size();
		int randamnumber = ThreadLocalRandom.current().nextInt(0, size);
		btn_existingprograms.get(randamnumber).click();
	}

	public boolean view_profileDetails() {
		javascriptScroll(txt_profileDetails);
		boolean b = true;
		isElementPresent(txt_profileDetails);
		return b;
	}

	public void click_profileTypes() {
		javascriptScroll(txt_profileDetails);
		int size = checkbox_profileTypes.size();
		int randamnumber = ThreadLocalRandom.current().nextInt(0, size);
		checkbox_profileTypes.get(randamnumber).click();
	}

	public void click_duplicateProgram() {
		jsClick(link_DublicateProgram);
		waitFor(2000);
	}

	public void enter_programName() {
		SendKeysOnWebElement(salesdemoLib_input_programName, "program1" + RandomStringGenerate());
		waitFor(2000);

	}

	public void enter_ProgramName(String programName) {
		ClickOnWebElement(salesdemoLib_input_programName);
		SendKeysOnWebElement(salesdemoLib_input_programName, programName + RandomStringGenerate());
		waitFor(2000);
	}

	public void enter_setProgramType() {
		javascriptScroll(dropdown_setProgramType);
		ClickOnWebElement(dropdown_setProgramType);
		try {
			ClickOnWebElement(dropdown_option_setProgramType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void program_startDate() {
		ClickOnWebElement(calender_setStartDate);
		visibilityWait(calender_setStartDate_currentDate);
		jsClick(calender_setStartDate_currentDate);
		// ClickOnWebElement(calender_setStartDate_currentDate);

	}

	public void program_endDate() {
		ClickOnWebElement(calender_setendDate);
		waitFor(2000);
		for (int i = 5; i >= 0; i--) {
			ClickOnWebElement(calender_setendDate_nextArrow);
		}
		waitFor(2000);
	}

	public void click_endDate() {
		isElementPresent(select_endDate);
		try {
			jsClick(select_endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_profileTypeAll() {
		javascriptScroll(txt_profileDetails);
		ClickOnWebElement(profiletype_all);
		waitFor(2000);
	}

	public void click_profileTypeAdult() {
		javascriptScroll(txt_profileDetails);
		ClickOnWebElement(profiletype_Adult);
		waitFor(2000);
	}

	public void click_profileTypeTeen() {
		javascriptScroll(txt_profileDetails);
		ClickOnWebElement(profiletype_Teen);
		waitFor(2000);
	}

	public void click_profileTypeKid() {
		javascriptScroll(txt_profileDetails);
		ClickOnWebElement(profiletype_kid);
		waitFor(2000);
	}

	public void not_selectprofileType() {
		javascriptScroll(txt_profileDetails);
		ClickOnWebElement(profiletype_all);
		waitFor(1000);
		ClickOnWebElement(profiletype_all);
	}

	public void click_publishProgm() {
		ClickOnWebElement(btn_publishProgram);
		waitFor(2000);

	}

	public void click_ActiveProgram() {
		visibilityWait(btn_ActiveProgram);
		waitFor(2000);
		jsClick(btn_ActiveProgram);
		waitFor(2000);
		//ClickOnWebElement(btn_ActiveProgram);

	}

	public void select_alreadyCreatedprograms() {
		/*
		int size = img_listOfprograms.size();
		int randamnumber = ThreadLocalRandom.current().nextInt(0, size);
		img_listOfprograms.get(randamnumber).click();
		*/
		jsClick(img_listOfprograms.get(0));
		//ClickOnWebElement(img_listOfprograms.get(0));
		waitFor(3000);

	}

	public void click_editProgram() {
		jsClick(link_editprogram);
		waitFor(2000);
	}
	
	public void notShowing_adultOption() {
		for (int i = 0; i < editprog_adultcheckbox.size(); i++) {
			if (!editprog_adultcheckbox.get(i).getText().equalsIgnoreCase("Adult")) {
				Logger.log(" user should not showing adult type option");
			}
		}
	}
	public boolean view_AdultprofileTypes() {
		boolean b=true;
		for (int i = 0; i < editprog_adultcheckbox.size(); i++) {
			if (editprog_adultcheckbox.get(i).getText().equalsIgnoreCase("Adult")) {
				Logger.log(" user should view programs enabled for all profiles");
			}
		}
		return true;
	}
	
	public void click_home_cta() {
		ClickOnWebElement(home_cta);

	}
	
	public void click_settings_cta() {
		ClickOnWebElement(settings_cta);
		ClickOnWebElement(library_settings_cta);

	}
	
	public boolean library_management_screen() {
		boolean b=true;
		isElementPresent(library_management_screen);
		return b;

	}
	
	
	
}

