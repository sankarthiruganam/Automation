package pom.kidszone;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Login extends CommonAction {

	static ExcelReader reader = new ExcelReader();
//	Profile profile = new Profile(DriverManager.getDriver());

	public Login(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "LogOnModel_UserName")
	private WebElement txt_userName_Textfield;

	@FindBy(id = "LogOnModel_Password")
	private WebElement txt_password_Textfield;

	@FindBy(id = "loc_btnLogin")
	private WebElement btn_signin;

	@FindBy(id = "loc_btnLogin")
	private WebElement btn_LoginOnlyId;

	@FindBy(id = "loginBtn")
	private WebElement btn_login_Button;

	@FindBy(id = "loginBtnMobile")
	private WebElement btn_login_Button_Mobile;

	@FindBy(id = "appBannerCloseBtn")
	private WebElement common_PopUp;

	@FindBy(id = "loc_linkSignOut")
	private WebElement link_SignOut;

	@FindBy(xpath = "//*[@class='profile-details']")
	public static List<WebElement> profileDetails;

	@FindBy(xpath = "//div[@class='profile-details']//following-sibling::p")
	private List<WebElement> manageProf_lbl_profType;

	@FindBy(xpath = "(//div[@role='button'])")
	private List<WebElement> manageProf_pencilIcon_editProfile;

	@FindBy(id = "closeButton")
	private WebElement btn_CloseOverlay;

	@FindBy(id = "loc_linkEdit")
	private WebElement manageProf_edit_button;

	@FindBy(id = "loc_btnHamburgerMenu")
	private WebElement link_hamburgerMenu;

	@FindBy(id = "loc_linkMyShelf")
	private WebElement link_myShelf;

	@FindBy(xpath = "//button[@aria-label='Navigation Menu']")
	private WebElement link_old_hamburgerMenu;

	@FindBy(id = "loc_profiles")
	private WebElement link_Profiles;

	@FindBy(id = "loc_textalertcontent")
	private WebElement alert_PopUpMessage;

	@FindBy(id = "toggle")
	private WebElement btn_menu;

	@FindBy(xpath = "//*[@svgicon='kz-hamburger']")
	private WebElement hamMenuNew;

	@FindBy(xpath = "//a[text()='PROFILES']")
	private WebElement adult_profileMenu;

	@FindBy(xpath = "//*[@class='alert-dialog ng-star-inserted']/*[@aria-label='Close']")
	private WebElement readPopUpclose;

	@FindBy(xpath = "(//*[@class='kz-custom-container-secondary'])[1]")
	private WebElement libraryPage;

	@FindBy(xpath = "//button[normalize-space()='Yes']")
	private WebElement Btn_Yes;

	@FindBy(id = "loginBtn")
	private WebElement logInButton;

	@FindBy(id = "loc_txtProfiles")
	private WebElement profilePage;

	@FindBy(xpath = "//button[@type='button']")
	private WebElement closePopUp;

	@FindBy(id = "loc_linkAdultEditProfile")
	private WebElement Edit_adultprofile;

	@FindBy(xpath = "//a[@class='pullText-bottom app-msg-text']")
	private WebElement DontRemindMe_popup;

	@FindBy(id = "loc_linkMyShelf")
	private WebElement Myshelf_menu;

	@FindBy(xpath = "//div[@class='mat-tab-links']")
	private WebElement Myshelf_navigationbar;

	@FindBy(id = "loc_profileImg")
	public static WebElement avatarHearder;

	@FindBy(xpath = "//*[@class='profile-user-list']")
	public static WebElement profileListDropDown;

	@FindBy(xpath = "(//*[@class='kz-user-adult profile-image'])[1]")
	public static WebElement primaryProfileDropDown;

	@FindBy(xpath = "(//*[@class='kz-user-teen profile-image'])[1]")
	public static WebElement teenProfileDropDown;

	@FindBy(id = "loc_linkBrowserBySubject")
	private WebElement browse;

	@FindBy(xpath = "//section[@class='kz-drawer-inner-container drawer-subnav-container ng-star-inserted']")
	public static WebElement browse_level1;

	@FindBy(xpath = "//div[@class='refiner-sec kz-browse-refiner']")
	public static WebElement browse_refiner;

	@FindBy(xpath = "//a[@class='nav-item ng-star-inserted']")
	public static WebElement browse_searchResult_breadcrumb;

	@FindBy(xpath = "//div[@class='title-list']")
	public static WebElement browse_searchResultPage;

	@FindBy(xpath = "//div[@class='mat-checkbox-inner-container']")
	public static List<WebElement> Refiner_noselection;

	@FindBy(xpath = "//div[@class='mat-tab-link']")
	public static WebElement browse_pills;

	@FindBy(xpath = "//*[@aria-label='Breadcrumb']")
	public static WebElement browse_breadcrumb;

	@FindBy(id = "loc_dropdwnBrowseBySubject")
	public static WebElement RefinerAsBrowse;

	@FindBy(xpath = "//label[@for='loc_txtYOUNG ADULT FICTION-input']")
	public static WebElement browse_adultFiction;

	@FindBy(xpath = "//label[@for='loc_txtYOUNG ADULT NONFICTION-input']")
	public static WebElement browse_adultNonFiction;

	@FindBy(id = "loc_dropdwnBrowseBySubject")
	public static WebElement Refiner_categories;

	@FindBy(xpath = "//*[@id='loc_dropdwnFeaturedCategories']/following::li")
	public static List<WebElement> browse_CategoryOptions;

	@FindBy(xpath = "//*[@class='title-list-container']")
	public static WebElement Refiner_Results;

	@FindBy(xpath = "//h2[contains(text(),' SORT BY')]")
	public static WebElement Refiner_SortBy;

	@FindBy(xpath = "//*[contains(text(),' FORMAT')]")
	public static WebElement Refiner_Format_dropdwn;

	@FindBy(xpath = "//*[contains(text(),' Availability')]")
	public static WebElement Refiner_Availability_dropdwn;

	@FindBy(xpath = "//*[contains(text(),' Language')]")
	public static WebElement Refiner_Language_dropdwn;

	@FindBy(xpath = "//*[contains(text(),' AGE LEVEL')]")
	public static WebElement Refiner_AgeLevel_dropdwn;

	@FindBy(id = "loc_dropdwnRelease Date")
	public static WebElement Refiner_ReleaseDate_dropdwn;

	@FindBy(id = "loc_dropdwnRecently Added")
	public static WebElement Refiner_RecentlyAdded_dropdwn;

	@FindBy(xpath = "//*[contains(text(),' FORMAT')]/following::mat-checkbox")
	public static List<WebElement> Refiner_Format_options;

	@FindBy(xpath = "//*[contains(text(),' Availability')]/following::mat-checkbox")
	public static List<WebElement> Refiner_Availability_options;

	@FindBy(xpath = "//*[contains(text(),' Language')]/following::mat-checkbox")
	public static List<WebElement> Refiner_Language_options;

	@FindBy(xpath = "//*[contains(text(),' AGE LEVEL')]/following::mat-checkbox")
	public static List<WebElement> Refiner_AgeLEvel_options;

	@FindBy(xpath = "//*[@id='loc_dropdwnRelease Date']/following::mat-checkbox")
	public static List<WebElement> Refiner_ReleaseDate_options;

	@FindBy(xpath = "//*[@id='loc_dropdwnRelease Date']/following::mat-checkbox")
	public static List<WebElement> Refiner_RecentlyAdded_options;

	@FindBy(xpath = "//label[@for='loc_txtYAF024000-input']//div[@class='mat-checkbox-inner-container']")
	public static WebElement category_historical;
	
	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	public static List<WebElement> tilesList ;
	
	@FindBy(xpath = "//label[@for='loc_txtYAF025000-input']//div[@class='mat-checkbox-inner-container']")
	public static WebElement category_holiday;

	@FindBy(xpath = "//label[@for='loc_txtYAF026000-input']//div[@class='mat-checkbox-inner-container']")
	public static WebElement category_horror;

	@FindBy(xpath = "//*[@class='result-count ng-star-inserted']")
	public static WebElement Results_count;

	@FindBy(xpath = "//img[contains(@src,'97')]")
	public static List<WebElement> Results_TitleISBN;

	@FindBy(id = "loc_dropdwnFormat")
	public static WebElement Format_dropdwn;

	@FindBy(xpath = "//*[@for='loc_txteBook-input']")
	public static WebElement ebook_format;

	@FindBy(xpath = "//*[@for='loc_txteAudio-input']")
	public static WebElement eAudio_format;

	public WebElement getBtn_login_Button() {
		return btn_login_Button;
	}

	public WebElement getProfilePage() {
		return profilePage;
	}

	public WebElement getLink_Profiles() {
		return link_Profiles;
	}

	/***********************************************************************************************************/

	public void closePopUp() {
		waitFor(2000);
		jsClick(closePopUp);
		waitFor(2000);
	}

	public void idlogin(String id) {
		javascriptScroll(txt_userName_Textfield);
		SendKeysOnWebElement(txt_userName_Textfield, id);
		ClickOnWebElement(txt_userName_Textfield);
		jsClick(btn_LoginOnlyId);
		preferenceScreen_popup();
		readInAppClose();
		// WaitForWebElement(libraryPage);
	}

	public void logInClick() {
		visibilityWait(btn_login_Button);
//		javascriptScroll(logIn);
		jsClick(btn_login_Button);
		visibilityWait(btn_signin);
		// WaitForWebElement(loginSubmit);
	}

	public void readInAppClose() {
		try {
			waitFor(2000);
			ClickOnWebElement(readPopUpclose);
		} catch (Exception e) {
			Logger.log("Read In Our App Pop-Up is not displayed");
		}
	}

	public void login_withoutPin(String loginid) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid);
		waitFor(2000);
		jsClick(btn_signin);
	}

	public void already_signeduser_prefixloginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid);
		SendKeysOnWebElement(txt_password_Textfield, pin);
		waitFor(2000);
		jsClick(btn_signin);
	}

	public void enter_loginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		SendKeysOnWebElement(txt_password_Textfield, pin);
		ClickOnWebElement(btn_signin);
	}

	public void enter_loginIdonly(String loginid) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		ClickOnWebElement(btn_LoginOnlyId);
		waitFor(2000);
	}

	public void click_loginPage() {

		System.out.println(btn_login_Button.isDisplayed());

		if (btn_login_Button.isDisplayed()) {
			System.out.println("Execution happening on the Web browser, so app banner is not present");
			waitFor(5000);
			jsClick(btn_login_Button);
		} else {
			System.out.println("Execution happening on the mobile browser, so app banner is present");
			if (common_PopUp.isDisplayed()) {
				waitFor(5000);
				jsClick(common_PopUp);
			} else {

				System.out.println("Pop up is not displayed");

			}
			waitFor(5000);
			jsClick(btn_login_Button_Mobile);
		}
	}

	public void handlePopUp() {
		try {
			if (isElementPresent(common_PopUp)) {

				ClickOnWebElement(common_PopUp);
				Logger.log("Close button is clicked");

			} else {

				Logger.log("Close button is not displayed in the application");
			}

		} catch (Exception e) {
//			e.printStackTrace();
			Logger.log("Close button is not displayed in the application");
		}

	}

	public void Login_ssoUrl() throws IOException {
		DriverManager.getDriver().get(getData("SSO"));
	}

	public void Login_PrefixWithPin() throws IOException {
		DriverManager.getDriver().get(getData("prefixWithPin"));
	}

	public void Login_PrefixWithoutPin() throws IOException {
		DriverManager.getDriver().get(getData("prefixWithoutPin"));
	}

	public void Login_AxisOnly() throws IOException {
		DriverManager.getDriver().get(getData("AxisonlyprefixWithoutPin"));
	}

	public void Login_cleverSSO() throws IOException {
		DriverManager.getDriver().get(getData("cleverSSO"));
	}

	public void Login_texas() throws IOException {
		DriverManager.getDriver().get(getData("idAndPassword"));
	}

	public void login_manualnyc() throws IOException {
		DriverManager.getDriver().get(getData("manualnyc"));
	}

	public void login_BTAdmin() throws IOException {
		DriverManager.getDriver().get(getData("BTadmin"));
	}

	public void login_LMaxis360Sales() throws IOException {
		DriverManager.getDriver().get(getData("LMaxis360Sales"));
	}

	public void login_LMidAndPassword() throws IOException {
		DriverManager.getDriver().get(getData("LMidAndPassword"));
	}

	public void Login_LMprefixWithPin() throws IOException {
		DriverManager.getDriver().get(getData("LMprefixWithPin"));
	}

	public void Login_LMprefixWithoutPin() throws IOException {
		DriverManager.getDriver().get(getData("LMprefixWithoutPin"));
	}

	public void Login_Salesdemo() throws IOException {
		DriverManager.getDriver().get(getData("Salesdemo"));
	}

//	public void app_launch(String loginType) throws Exception {
//		if (loginType.equalsIgnoreCase("idAndPassword")) {
//			DriverManager.getDriver().get(getData("idAndPassword"));
//		} else if (loginType.equalsIgnoreCase("prefixWithPin")) {
//			DriverManager.getDriver().get(getData("prefixWithPin"));
//		} else if (loginType.equalsIgnoreCase("prefixWithoutPin")) {
//			DriverManager.getDriver().get(getData("prefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("AxisonlyprefixWithoutPin")) {
//			DriverManager.getDriver().get(getData("AxisonlyprefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("SSO")) {
//			DriverManager.getDriver().get(getData("SSO"));
//		} else if (loginType.equalsIgnoreCase("cleverSSO")) {
//			DriverManager.getDriver().get(getData("cleverSSO"));
//		} else if (loginType.equalsIgnoreCase("LMidAndPassword")) {
//			DriverManager.getDriver().get(getData("LMidAndPassword"));
//		} else if (loginType.equalsIgnoreCase("LMprefixWithoutPin")) {
//			DriverManager.getDriver().get(getData("LMprefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("LMprefixWithPin")) {
//			DriverManager.getDriver().get(getData("LMprefixWithPin"));
//		} else if (loginType.equalsIgnoreCase("LMaxis360Sales")) {
//			DriverManager.getDriver().get(getData("LMaxis360Sales"));
//		} else if (loginType.equalsIgnoreCase("manualnyc")) {
//			DriverManager.getDriver().get(getData("manualnyc"));
//		}
//
//		//waitFor(5000);
//	}

	public void select_Kidprofile() {
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (profileDetails.get(i).getText().contains("Kid")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			}
		}
		preferenceScreen_popup();
	}

	public void select_Teenprofile() {
		waitFor(2000);
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Teen")) {
				WaitForWebElement(manageProf_pencilIcon_editProfile.get(i));
				jsClick(manageProf_pencilIcon_editProfile.get(i));
			}
			waitFor(5000);
		}
		preferenceScreen_popup();
	}

	public void click_Teenprofile() {
		waitFor(2000);
		WaitForWebElement(manageProf_pencilIcon_editProfile.get(2));
		jsClick(manageProf_pencilIcon_editProfile.get(2));
		waitFor(3000);
		preferenceScreen_popup();
	}

	public void click_Kid() {
		waitFor(2000);
		WaitForWebElement(manageProf_pencilIcon_editProfile.get(3));
		jsClick(manageProf_pencilIcon_editProfile.get(3));
		waitFor(3000);
		preferenceScreen_popup();
	}

	public void preferenceScreen_popup() {
		try {

			ClickOnWebElement(btn_CloseOverlay);

		} catch (Exception e) {

			Logger.log("Set Preferences Pop up is not displayed");
		}
	}

	public void click_manageProf_Edit_button() {
		jsClick(manageProf_edit_button);
	}

	public void click_HamburgerMenu() {

		isElementPresent(link_hamburgerMenu);
		jsClick(link_hamburgerMenu);
		waitFor(2000);

	}

	public void click_NewMenu() {
		javascriptScroll(link_hamburgerMenu);
		jsClick(link_hamburgerMenu);
		WaitForWebElement(link_myShelf);
	}

	public void click_Profiles() {
		waitFor(2000);
		jsClick(link_Profiles);
		// ClickOnWebElement(link_Profiles);
		waitFor(6000);
	}

	public void click_MenuOnly() {
		waitFor(6000);
		if (isElementPresent(btn_menu)) {
			jsClick(btn_menu);
		} else if (isElementPresent(hamMenuNew)) {
			jsClick(hamMenuNew);
		}

	}

	public void click_SignOut() {
		waitFor(2000);
		jsClick(link_SignOut);
		WaitForWebElement(alert_PopUpMessage);
	}

	public void menu_adultProfile() {
		visibilityWait(adult_profileMenu);
		jsClick(adult_profileMenu);
		waitFor(2000);
	}

	public void select_Adultprofile() {
		visibilityWait(Edit_adultprofile);
		jsClick(Edit_adultprofile);
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Primary")) {
				WaitForWebElement(manageProf_pencilIcon_editProfile.get(i));
				jsClick(manageProf_pencilIcon_editProfile.get(i));
				waitFor(5000);
			}
		}
		preferenceScreen_popup();
	}

	public void click_Adultprofile() {
		//waitFor(3000);
		visibilityWait(Edit_adultprofile);
		jsClick(Edit_adultprofile);
		waitFor(3000);
	}

	public void sign_Out() {
		click_HamburgerMenu();
		click_SignOut();
		jsClick(Btn_Yes);
		WaitForWebElement(logInButton);
	}

	public void select_Kidprofilewithpenicon() {
		jsClick(manageProf_edit_button);
		visibilityWait(manageProf_pencilIcon_editProfile.get(5));
		jsClick(manageProf_pencilIcon_editProfile.get(5));
		preferenceScreen_popup();
	}

	public void select_Teenprofilewithpenicon() {
		visibilityWait(manageProf_pencilIcon_editProfile.get(3));
		jsClick(manageProf_pencilIcon_editProfile.get(3));
		preferenceScreen_popup();
	}

	public void select_Adultprofilewithpenicon() {
		visibilityWait(manageProf_pencilIcon_editProfile.get(1));
		jsClick(manageProf_pencilIcon_editProfile.get(1));
		preferenceScreen_popup();
	}

	public void handle_dontRemindMePopup() {
		try {
			if (System.getProperty("browser").equalsIgnoreCase("android")) {
				jsClick(DontRemindMe_popup);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("Close button is not displayed in the application");
		}
	}

	public void click_Myshelf() {
		visibilityWait(Myshelf_menu);
		jsClick(Myshelf_menu);
		visibilityWait(Myshelf_navigationbar);

	}

	public void clickProfileAvatar() {
		jsClick(avatarHearder);
		visibilityWait(profileListDropDown);
	}

	public void clickTeenDropDown() {
		javascriptScroll(teenProfileDropDown);
		jsClick(teenProfileDropDown);
		waitFor(5000);
		preferenceScreen_popup();
	}

	public void click_browse() {
		jsClick(browse);

	}

	public void verify_RefinerNoselection() {
		boolean b = true;
		for (int i = 0; i < Refiner_noselection.size(); i++) {
			if (!Refiner_noselection.get(i).isSelected()) {
				b = true;
			} else {
				b = false;
			}

		}

	}

	public void click_browseRefiner() {
		if (isElementPresent(RefinerAsBrowse)) {
			javascriptScroll(browse_adultFiction);
			jsClick(browse_adultFiction);
			visibilityListWait(browse_CategoryOptions);
		}

	}

	public void verify_MultiSelectOptions(String options) {
		switch (options) {
		case "browse":
			Assert.assertEquals(browse_adultFiction.isDisplayed(), true);
			Assert.assertEquals(browse_adultNonFiction.isDisplayed(), true);
			break;
		case "categories":
			visibilityWait(Refiner_categories);
			Assert.assertTrue(isElementPresent(Refiner_categories));
			waitFor(2000);
			break;
		case "Format":
			Assert.assertTrue(isElementPresent(Refiner_Format_dropdwn));
			break;
		case "Availability":
			Assert.assertTrue(isElementPresent(Refiner_Availability_dropdwn));
			break;
		case "language":
			Assert.assertTrue(isElementPresent(Refiner_Language_dropdwn));
			break;
		case "age level":
			Assert.assertTrue(isElementPresent(Refiner_AgeLevel_dropdwn));
			break;
		case "release date":
			Assert.assertTrue(isElementPresent(Refiner_ReleaseDate_dropdwn));
			break;
		case "recently added":
			Assert.assertTrue(isElementPresent(Refiner_RecentlyAdded_dropdwn));
			break;
		}

	}

	public void select_Categories() {
		System.out.println("browse category options" + browse_CategoryOptions.get(0).getText());
		visibilityWait(browse_CategoryOptions.get(0));
		jsClick(browse_CategoryOptions.get(0));
		waitFor(2000);
	}

	public void multiSelect_Categories() {
		jsClick(browse_CategoryOptions.get(1));
	}

	public void select_Format() {
		if (isElementPresent(Refiner_Format_dropdwn)) {
			jsClick(Refiner_Format_dropdwn);
			waitFor(2000);
			jsClick(Refiner_Format_options.get(0));
		}

	}

	public void multiSelect_Format() {
		jsClick(Refiner_Format_options.get(1));
	}

	public void select_Availability() {
		if (isElementPresent(Refiner_Availability_dropdwn)) {
			jsClick(Refiner_Availability_dropdwn);
			waitFor(2000);
			jsClick(Refiner_Availability_options.get(0));
		}

	}

	public void multiSelect_Availability() {
		jsClick(Refiner_Availability_options.get(1));
	}

	public void select_Language() {
		if (isElementPresent(Refiner_Language_dropdwn)) {
			jsClick(Refiner_Language_dropdwn);
			waitFor(2000);
			jsClick(Refiner_Language_options.get(0));
		}

	}

	public void multiSelect_Language() {
		jsClick(Refiner_Language_options.get(1));
	}

	public void select_AgeLevel() {
		if (isElementPresent(Refiner_AgeLevel_dropdwn)) {
			jsClick(Refiner_AgeLevel_dropdwn);
			waitFor(2000);
			jsClick(Refiner_AgeLEvel_options.get(0));
		}

	}

	public void multiSelect_AgeLevel() {
		jsClick(Refiner_AgeLEvel_options.get(1));
	}

	public void select_ReleaseDate() {
		if (isElementPresent(Refiner_ReleaseDate_dropdwn)) {
			jsClick(Refiner_ReleaseDate_dropdwn);
			waitFor(2000);
			jsClick(Refiner_ReleaseDate_options.get(0));
		}

	}

	public void multiSelect_ReleaseDate() {
		jsClick(Refiner_ReleaseDate_options.get(1));
	}

	public void select_RecentlyAdded() {
		if (isElementPresent(Refiner_RecentlyAdded_dropdwn)) {
			jsClick(Refiner_RecentlyAdded_dropdwn);
			waitFor(2000);
			jsClick(Refiner_RecentlyAdded_options.get(0));
		}

	}

	public void multiSelect_RecentlyAdded() {
		jsClick(Refiner_RecentlyAdded_options.get(1));
	}

	public void select_Category() {

		javascriptScroll(category_historical);
		jsClick(category_historical);
		visibilityWait(category_holiday);
		jsClick(category_holiday);
		visibilityWait(category_horror);
		jsClick(category_horror);
		
		visibilityWait(Refiner_Results);

	}
	
	public int get_CategoryCounts() {
		visibilityWait(Results_count);
		String RES_count = Results_count.getText();
		String ExtCount=RES_count.replaceAll("[^0-9]", "");
		int totalCount=Integer.parseInt(ExtCount);
		return totalCount;

	}

	public int get_CategoryEbookCount() {
		visibilityWait(Results_count);
		String RES_count = Results_count.getText();
		String ExtCount = RES_count.replaceAll("[^0-9]", "");
		int Count = Integer.parseInt(ExtCount);
		return Count;

	}


	public List<String> get_TitlesISBN() {
		List<String> isbnList = new ArrayList<String>();
		int maxRetries = 3;
		int retries = 0;

		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 30);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete';"));
		while (retries < maxRetries) {
			try {
				for (int i = 0; i < Results_TitleISBN.size(); i++) {
					String srcImageText = Results_TitleISBN.get(i).getAttribute("src");
					// Regular expression pattern to match the ISBN
					Pattern pattern = Pattern.compile("/(\\d{13})/");
					Matcher matcher = pattern.matcher(srcImageText);
					String isbn = "";
					if (matcher.find()) {
						isbn = matcher.group(1);
					} else {
						System.out.println("ISBN not found in the src attribute.");
					}
					isbnList.add(isbn);
				}
				break;

			} catch (StaleElementReferenceException e) {
				System.out.println("Retry count : " + retries);
				retries++;
				isbnList = new ArrayList<String>();
			}

		}
		return isbnList;
	}

	public void click_FormatDropdwn_ebook() {
		javascriptScroll(Format_dropdwn);
		jsClick(Format_dropdwn);
		visibilityWait(ebook_format);
		jsClick(ebook_format);
		waitFor(2000);

	}

	public void click_FormatDropdwn_eAudio() {

		jsClick(ebook_format);
		waitFor(2000);

		visibilityWait(eAudio_format);
		jsClick(eAudio_format);
		waitFor(2000);

	}
	
	
	
}
