package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class MyLibrary_Guest extends CommonAction {

	Holds holds = new Holds(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());

	public MyLibrary_Guest(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_txtAvailability")
	private WebElement teenUserTheme;

	@FindBy(id = "skip-nav")
	private WebElement adultUserTheme;

	@FindBy(xpath = "//*[@class='kz-logo']")
	private WebElement libraryLogo;

	@FindBy(xpath = "//*[@class='footer-brand-logo']")
	private WebElement boundLessLogo;

	@FindBy(xpath = "//*[@class='logo-container']")
	private WebElement axisLogo;

	@FindBy(xpath = "//*[contains(text(),'All Rights Reserved')]")
	private WebElement copyRights;

	@FindBy(xpath = "//span[contains(text(),'Advanced Search')]")
	private WebElement advancedSearch;

	@FindBy(xpath = "//*[@class='kz-search-main']")
	private WebElement searchBar;

	@FindBy(xpath = "//*[@aria-labelledby='search-title']")
	private WebElement advancedSearchTab;

	@FindBy(xpath = "(//*[@svgicon='kz-close'])[2]")
	private WebElement closeAdvanceSearch;

	@FindBy(xpath = "")
	private WebElement tagLine;

	@FindBy(xpath = "//*[@class='login-inner-box-content']")
	private WebElement logInPopOldUi;

	@FindBy(id = "loc_labelNew")
	private WebElement newCTA;

	@FindBy(id = "loc_labelTrending")
	private WebElement trendCTA;

	@FindBy(id = "loc_labelSurprise Me!")
	private WebElement supriseCTA;

	@FindBy(xpath = "")
	private WebElement newCTAPage;

	@FindBy(xpath = "")
	private WebElement trendCTAPage;

	@FindBy(xpath = "")
	private WebElement supriseCTAPage;

	@FindBy(xpath = "")
	private WebElement readNowCTA;

	@FindBy(xpath = "")
	private WebElement magazineCarosel;

	@FindBy(xpath = "(//*[contains(text(),'Always Available')]/following-sibling::div//*[@class='kz-card-image ng-star-inserted'])")
	private List<WebElement> alwaysAvailTitles;

	@FindBy(xpath = "(//*[@class='kz-title-carousel ng-star-inserted'])//*[contains(text(),'Always Available')]")
	private WebElement alwaysAvailCarosel;

	@FindBy(xpath = "//*[@class='primary-action ng-star-inserted']")
	private List<WebElement> primaryCTA;

	@FindBy(xpath = "(//*[@class='primary-action ng-star-inserted'])[1]")
	private WebElement primaryCTA1;

	@FindBy(xpath = "(//*[contains(text(),'Always Available ')]/following::*[@class='link see-all-text ng-star-inserted'])[1]")
	private WebElement seeAllCTA;

	@FindBy(xpath = "(//*[@class='kz-filter-select'])[1]")
	private WebElement availablityFilter;

	@FindBy(xpath = "(//*[@class='kz-filter-select'])[2]")
	private WebElement formatFilter;

	@FindBy(xpath = "(//*[@svgicon='kz-filter-down-arrow'])[2]")
	private WebElement formatDropdown;

	@FindBy(xpath = "//span[contains(text(),'eBook')]")
	private WebElement eBook;

	@FindBy(xpath = "//span[contains(text(),'Audio')]")
	private WebElement audioBook;

	@FindBy(xpath = "((//*[@class='kz-custom-container-secondary'])[1]//following::*[@class='mat-card-image card-image'])[1]")
	private WebElement eBookTitles;

	@FindBy(xpath = "(//*[@class='kz-carousel'])[2]")
	private WebElement curatedList;

	@FindBy(xpath = "(//*[@class='kz-carousel'])[2]//*[@class='carousel-cell ng-star-inserted']")
	private List<WebElement> curatedListTitles;

	@FindBy(xpath = "(//*[@class='kz-custom-container-secondary'])[1]//following::*[@class='carousel-arrow carousel-arrow-prev']")
	private WebElement leftCarosel;

	@FindBy(xpath = "(//*[@class='kz-custom-container-secondary'])[1]//following-sibling::*[@class='carousel-arrow carousel-arrow-next']")
	private WebElement rightCarosel;

	@FindBy(xpath = "(//*[@class='ui-carousel-items-content'])[1]//*[@class='ng-star-inserted']")
	private List<WebElement> magazinesCaroselTitles;

	@FindBy(xpath = "//*[contains(text(),'AutoQA2Texas')]/following::span[1][@class='description-text']")
	private WebElement briefDescription;

	@FindBy(xpath = "((//*[@class='kz-custom-container-secondary'])[1]//following::*[@class='mat-card-image card-image'])[1]")
	private WebElement titleCard;

	@FindBy(xpath = "((//*[@class='kz-card-image ng-star-inserted'])[1]//following::*[@class='mat-card-image card-image'])[1]")
	private WebElement titleCardInListScreen;

	@FindBy(xpath = "(//*[@class='titledetails-bookwrapper'])")
	private WebElement titleDetailsPage;

	@FindBy(xpath = "//div[@class='kz-featured']")
	private WebElement featuredListSection;

	@FindBy(xpath = "//*[@class='book-of-month-col']")
	private WebElement featuredTitleSection;

	@FindBy(xpath = "//*[@class='announcements-col ng-star-inserted']")
	private WebElement announcementSection;

	@FindBy(id = "sub-frame-error")
	private WebElement announceLink;

	@FindBy(xpath = "//div[@class='announcements-col ng-star-inserted']")
	private WebElement announceImage;

	@FindBy(xpath = "//*[@class='announcements-para four-ellipsis']")
	private WebElement announceContent;

	@FindBy(xpath = "//*[@class='titledetails-bookwrapper']")
	private WebElement featuredTitlePage;

	@FindBy(xpath = "(//*[@class='img-responsive'])[1]")
	private WebElement featuredCoverImage;

	@FindBy(id = "kz-bookofmonth")
	private WebElement featuredTitleName;

	@FindBy(xpath = "//*[@class='book-of-month-para']")
	private WebElement featuredTitleDescription;

	@FindBy(xpath = "//*[contains(text(),'feature lists')]")
	private WebElement featureTitleListPage;

	@FindBy(xpath = "//*[@class='mylib-category-header']")
	private WebElement featureTitleListPageOldUi;

	@FindBy(xpath = "//*[@class='link see-all-text']")
	private WebElement seeAllFeaturedList;

	@FindBy(xpath = "//*[@aria-label='See all Featured']")
	private WebElement seeAllFeaturedListOldUi;

	@FindBy(xpath = "//*[@class='carousel-title'][contains(text(),'Featured')]")
	private WebElement featuredListOldUi;

	@FindBy(id = "featured-accordion")
	private WebElement featuredPrograms;

	@FindBy(xpath = "(//*[contains(text(),'Featured')]//..//..//div[@class='poster-main-sec'])[1]")
	private WebElement featuredTiltleOldUi;

	@FindBy(xpath = "(//*[@class='menu-link'])[1]")
	private WebElement homeFooter;

	@FindBy(xpath = "(//*[@class='kz-filter-select'])[1]")
	private WebElement homePage;

	@FindBy(xpath = "(//*[@class='menu-link'])[2]")
	private WebElement privacyFooter;

	@FindBy(xpath = "//*[contains(text(),'KnowledgePoint School Privacy Statement')]")
	private WebElement privacyFooterPage;

	@FindBy(xpath = "(//*[@class='menu-link'])[3]")
	private WebElement termsFooter;

	@FindBy(xpath = "(//*[contains(text(),'End User License Agreement')])[1]")
	private WebElement termsFooterPage;

	@FindBy(id = "toggle")
	private WebElement hamOldUi;

	@FindBy(xpath = "//*[@class='menu-container']")
	private WebElement hamDrawerOldUi;

	@FindBy(xpath = "//*[@class='form-control']")
	private WebElement searchBarOldUi;

	@FindBy(xpath = "(//*[@class='footer-links'])[1]")
	private WebElement homeFooterOldUi;

	@FindBy(xpath = "(//*[@class='footer-links'])[2]")
	private WebElement privacyFooterOldUi;

	@FindBy(xpath = "(//*[@class='footer-links'])[3]")
	private WebElement termsFooterOldUi;

	@FindBy(xpath = "(//*[@svgicon='kz-close'])[1]")
	private WebElement closeHam;

	@FindBy(id = "nav-close")
	private WebElement closeOldHam;

	@FindBy(id = "divFooter")
	private WebElement footerOldUi;

	@FindBy(xpath = "(//*[contains(text(),'Always Available')]/following::div[@class='ui-carousel-items-content'])[1]")
	private WebElement alwaysAvailOldUi;

	@FindBy(xpath = "(//*[contains(text(),'Always Available')]/following::div[@class='poster-main-sec'])[1]")
	private WebElement alwaysAvailTitleOldUi;

	@FindBy(xpath = "//*[@aria-label='See all always available']")
	private WebElement seeAllAlwaysOldUi;

	@FindBy(xpath = "//*[@aria-labelledby='loc_txtAvailability']")
	private WebElement availablityAll;

	@FindBy(xpath = "(//*[contains(text(),'Available Now')])")
	private WebElement availablityNow;

	@FindBy(xpath = "//*[@aria-labelledby='loc_txtFormat']")
	private WebElement formatAll;

	@FindBy(xpath = "//*[@class='homepage-filterArea ng-star-inserted']//mat-form-field[1]//div[2]")
	private WebElement availabilityOldUi;

	@FindBy(xpath = "(//*[contains(text(),'Available Now')])[2]")
	private WebElement availabilityNowOldUi;

	@FindBy(xpath = "//*[@class='homepage-filterArea ng-star-inserted']//mat-form-field[2]//div[2]")
	private WebElement formatOldUi;

	@FindBy(xpath = "//*[contains(text(),'eBook')]")
	private WebElement eBookOldUi;

	@FindBy(xpath = "(//h2[@class='title'])[1]")
	private WebElement titleName;

	@FindBy(xpath = "(//button[@class='ui-carousel-next ui-button ui-widget ui-state-default ui-corner-all'])[1]")
	private WebElement rightCaroselOldUi;

	@FindBy(xpath = "(//*[@class='mylibrary-container container'])")
	private WebElement alwaysAvailListPageOldUi;

	@FindBy(id = "loc_labelAlways Available")
	private WebElement alwaysAvailListPage;

	@FindBy(xpath = "(//*[@class='btn-primary btn-primary-blue ng-star-inserted'])[2]")
	private WebElement primaryCtaTiltleList;

	@FindBy(xpath = "(//*[@class='container-fliud'])")
	private WebElement titleDetailsOldUi;

	@FindBy(id = "loc_btnHamburgerMenu")
	private WebElement hamMenuNewUi;

	@FindBy(id = "loc_linkLibrary")
	private WebElement libraryNewUi;

	@FindBy(id = "loc_linkCheckouts")
	private WebElement checkOutsNewUi;

	@FindBy(id = "loc_txtCheckouts")
	private WebElement checkoutPage;

	public List<WebElement> getCuratedListTitles() {
		return curatedListTitles;
	}

	public WebElement getBoundLessLogo() {
		return boundLessLogo;
	}

	public WebElement getFeaturedTitlePage() {
		return featuredTitlePage;
	}

	public WebElement getFeaturedListOldUi() {
		return featuredListOldUi;
	}

	public WebElement getSeeAllFeaturedListOldUi() {
		return seeAllFeaturedListOldUi;
	}

	public List<WebElement> getPrimaryCTA() {
		return primaryCTA;
	}

	public WebElement getTitleDetailsOldUi() {
		return titleDetailsOldUi;
	}

	public WebElement geteBook() {
		return eBook;
	}

	public WebElement getAudioBook() {
		return audioBook;
	}

	public WebElement getFeaturedTitleSection() {
		return featuredTitleSection;
	}

	public WebElement getFeatureTitleListPageOldUi() {
		return featureTitleListPageOldUi;
	}

	public WebElement getFeatureTitleListPage() {
		return featureTitleListPage;
	}

	public WebElement getSeeAllFeaturedList() {
		return seeAllFeaturedList;
	}

	public WebElement getRightCaroselOldUi() {
		return rightCaroselOldUi;
	}

	public WebElement getAvailabilityOldUi() {
		return availabilityOldUi;
	}

	public WebElement getTitleName() {
		return titleName;
	}

	public WebElement getFormatOldUi() {
		return formatOldUi;
	}

	public WebElement getAvailablityAll() {
		return availablityAll;
	}

	public WebElement getFormatAll() {
		return formatAll;
	}

	public WebElement getSeeAllAlwaysOldUi() {
		return seeAllAlwaysOldUi;
	}

	public WebElement getAlwaysAvailTitleOldUi() {
		return alwaysAvailTitleOldUi;
	}

	public WebElement getAlwaysAvailOldUi() {
		return alwaysAvailOldUi;
	}

	public WebElement getFooterOldUi() {
		return footerOldUi;
	}

	public WebElement getAxisLogo() {
		return axisLogo;
	}

	public WebElement getCopyRights() {
		return copyRights;
	}

	public WebElement getLogInPopOldUi() {
		return logInPopOldUi;
	}

	public WebElement getHamOldUi() {
		return hamOldUi;
	}

	public WebElement getHamDrawerOldUi() {
		return hamDrawerOldUi;
	}

	public WebElement getSearchBarOldUi() {
		return searchBarOldUi;
	}

	public WebElement getSeeAllCTA() {
		return seeAllCTA;
	}

	public WebElement getAvailablityFilter() {
		return availablityFilter;
	}

	public WebElement getTermsFooterPage() {
		return termsFooterPage;
	}

	public WebElement getPrivacyFooterPage() {
		return privacyFooterPage;
	}

	public WebElement getHomePage() {
		return homePage;
	}

	public WebElement getHomeFooter() {
		return homeFooter;
	}

	public WebElement getPrivacyFooter() {
		return privacyFooter;
	}

	public WebElement getTermsFooter() {
		return termsFooter;
	}

	public WebElement getFeaturedPrograms() {
		return featuredPrograms;
	}

	public WebElement getAnnounceContent() {
		return announceContent;
	}

	public WebElement getAnnounceLink() {
		return announceLink;
	}

	public WebElement getAnnouncementSection() {
		return announcementSection;
	}

	public WebElement getFeaturedListSection() {
		return featuredListSection;
	}

	public WebElement getTitleDetailsPage() {
		return titleDetailsPage;
	}

	public WebElement getBriefDescription() {
		return briefDescription;
	}

	public List<WebElement> getMagazinesCaroselTitles() {
		return magazinesCaroselTitles;
	}

	public WebElement getCuratedList() {
		return curatedList;
	}

	public WebElement getFormatFilter() {
		return formatFilter;
	}

	public WebElement getFormatDropdown() {
		return formatDropdown;
	}

	public List<WebElement> getAlwaysAvailTitles() {
		return alwaysAvailTitles;
	}

	public WebElement getAlwaysAvailCarosel() {
		return alwaysAvailCarosel;
	}

	public WebElement getMagazineCarosel() {
		return magazineCarosel;
	}

	public WebElement getNewCTAPage() {
		return newCTAPage;
	}

	public WebElement getTrendCTAPage() {
		return trendCTAPage;
	}

	public WebElement getSupriseCTAPage() {
		return supriseCTAPage;
	}

	public WebElement getNewCTA() {
		return newCTA;
	}

	public WebElement getTrendCTA() {
		return trendCTA;
	}

	public WebElement getSupriseCTA() {
		return supriseCTA;
	}

	public WebElement getTagLine() {
		return tagLine;
	}

	public WebElement getLibraryLogo() {
		return libraryLogo;
	}

	public WebElement getTeenUserTheme() {
		return teenUserTheme;
	}

	public WebElement getAdultUserTheme() {
		return adultUserTheme;
	}

	public WebElement getAdvancedSearch() {
		return advancedSearch;
	}

	public WebElement getSearchBar() {
		return searchBar;
	}

	public WebElement getAdvancedSearchTab() {
		return advancedSearchTab;
	}

	public void waitForNewUI() {
		visibilityWait(teenUserTheme);
	}

	public void waitForOldUI() {
		WaitForWebElement(adultUserTheme);
	}

	public void clickHomeCTA() {
		javascriptScroll(homeFooter);
		ClickOnWebElement(homeFooter);
		visibilityWait(homePage);
//		javascriptScroll(homeFooter);
//		WaitForWebElement(homeFooter);
	}

	public void clickPrivacyCTA() {
		javaScriptScrollToEnd();
		javascriptScroll(privacyFooter);
		ClickOnWebElement(privacyFooter);
		WaitForWebElement(privacyFooterPage);
	}

	public void clickTermsCTA() {
		javaScriptScrollToEnd();
		javascriptScroll(termsFooter);
		ClickOnWebElement(termsFooter);
		WaitForWebElement(termsFooterPage);
	}

	public void clickAdvanceSearch() {
		javascriptScroll(advancedSearch);
		jsClick(advancedSearch);
		WaitForWebElement(advancedSearchTab);
	}

	public void closeAdvanceSearch() {
		javascriptScroll(closeAdvanceSearch);
		jsClick(closeAdvanceSearch);
		WaitForWebElement(advancedSearch);
	}

	public void clickLogInCta() {
		javascriptScroll(holds.getLogIn());
		jsClick(holds.getLogIn());
		WaitForWebElement(holds.getLoginSubmit());
		Logger.log("User prompted for Log-In");
	}

	public void clickNewCTA() {
		javascriptScroll(newCTA);
		ClickOnWebElement(newCTA);
		WaitForWebElement(newCTAPage);
	}

	public void clickTrendCTA() {
		javascriptScroll(trendCTA);
		ClickOnWebElement(trendCTA);
		WaitForWebElement(trendCTAPage);
	}

	public void clickSurpriseCTA() {
		javascriptScroll(supriseCTA);
		ClickOnWebElement(supriseCTA);
		WaitForWebElement(supriseCTAPage);
	}

	public void navigateBack() {
		waitFor(2000);
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(homePage);
	}

	public void clickReadNowCTA() {
		javascriptScroll(readNowCTA);
		ClickOnWebElement(readNowCTA);
		WaitForWebElement(holds.getLoginSubmit());
		Logger.log("User prompted for Log-In");
	}

	public void clickPrimaryCTA() {
		if (isElementPresent(primaryCtaTiltleList)) {
			jsClick(primaryCtaTiltleList);
			WaitForWebElement(holds.getLoginSubmit());
		} else {
			WaitForWebElement(primaryCTA.get(0));
			for (int j = 0; j < primaryCTA.size(); j++) {
				javascriptScroll(primaryCTA.get(j));
				jsClick(primaryCTA.get(j));
				WaitForWebElement(holds.getLoginSubmit());
				if (isElementPresent(holds.getLoginSubmit())) {
					break;
				}
			}
		}

		Logger.log("User prompted for Log-In");
	}

	public void clickSeeAllCTA() {
		WaitForWebElement(seeAllCTA);
		ClickOnWebElement(seeAllCTA);
		WaitForWebElement(alwaysAvailListPage);
		Assert.assertTrue(alwaysAvailListPage.isDisplayed());
	}

	public void clickFormatDropDown() {
		javascriptScroll(formatDropdown);
		jsClick(formatDropdown);
		WaitForWebElement(audioBook);
		waitFor(2000);
		isElementPresent(eBook);
		isElementPresent(audioBook);
		Logger.log("User able to see eBook and Audio book format in dropdown");
	}

	public void addEbook() {
		jsClick(eBook);
//      WaitForListWebElement(primaryCTA);
//		waitFor(3000);
		WaitForWebElement(eBookTitles);
	}

	public void clickTitle() {
		javascriptScroll(titleCard);
		jsClick(titleCard);
		// ClickOnWebElement(titleCard);
		WaitForWebElement(titleDetailsPage);
	}

	public void clickTitleCardList() {
		javascriptScroll(titleCardInListScreen);
		jsClick(titleCardInListScreen);
		// ClickOnWebElement(titleCard);
		WaitForWebElement(titleDetailsPage);
	}

	public void caroselAbsenceAvailable() {
		if (isElementPresent(alwaysAvailCarosel)) {
			for (int i = 0; i < alwaysAvailTitles.size(); i++) {
				Assert.assertTrue(alwaysAvailTitles.get(i).isDisplayed());
			}
		} else {
			Assert.assertFalse(isElementPresent(alwaysAvailTitles.get(0)));
		}
	}

	public void caroselAbsenceMagazine() {
		if (isElementPresent(magazineCarosel)) {
			for (int i = 0; i < magazinesCaroselTitles.size(); i++) {
				Assert.assertEquals(magazinesCaroselTitles.get(i).isDisplayed(), true);
			}
		} else {
			Logger.log("Carosel list title are not available if carosel is not available");
		}
	}

	public void featuredTitle() {
		Assert.assertTrue(isElementPresent(featuredCoverImage));
		Assert.assertTrue(isElementPresent(featuredTitleName));
		Assert.assertTrue(isElementPresent(featuredTitleDescription));
	}

	public void featuredTitlePage() {
		javascriptScroll(featuredCoverImage);
		jsClick(featuredCoverImage);
		// ClickOnWebElement(featuredCoverImage);
		WaitForWebElement(featuredTitlePage);
	}

	public void featuredTitleAbsence() {
		if (isElementPresent(featuredTitleSection)) {
			featuredTitle();
		} else {
			Logger.log("Featured titles are not available if No Featured titles are set by library admin");
		}
	}

	public void featuredListAbsence() {
		if (isElementPresent(featuredListSection)) {
			Logger.log("Featured titles are available if Featured titles are set by library admin");
		} else {
			Logger.log("Featured titles are not available if No Featured titles are set by library admin");
		}
	}

	public void clickLogInOldUi() {
		WaitForWebElement(holds.getLogIn());
		jsClick(holds.getLogIn());
		WaitForWebElement(logInPopOldUi);
	}

	public void clickHamOldUi() {
		WaitForWebElement(hamOldUi);
		ClickOnWebElement(hamOldUi);
		WaitForWebElement(hamDrawerOldUi);
	}

	public void closeHam() {
		visibilityWait(closeHam);
		javascriptScroll(closeHam);
		jsClick(closeHam);
	}

	public void closeOldHam() {
		javascriptScroll(closeOldHam);
		ClickOnWebElement(closeOldHam);
	}

	public void clickOldHome() {
		javascriptScroll(homeFooterOldUi);
		ClickOnWebElement(homeFooterOldUi);
		WaitForWebElement(availabilityOldUi);
	}

	public void clickOldPrivacy() {
		javascriptScroll(privacyFooterOldUi);
		ClickOnWebElement(privacyFooterOldUi);
		WaitForWebElement(privacyFooterPage);
	}

	public void clickOldTerms() {
		javascriptScroll(termsFooterOldUi);
		ClickOnWebElement(termsFooterOldUi);
		WaitForWebElement(termsFooterPage);
	}

	public void footerLinksOldUi() {
		javaScriptScrollToEnd();
		isElementPresent(homeFooterOldUi);
		isElementPresent(privacyFooterOldUi);
		isElementPresent(termsFooterOldUi);
	}

	public void clickAvailabilityOldUi() {
		jsClick(availabilityOldUi);
		WaitForWebElement(availabilityNowOldUi);
		isElementPresent(availabilityNowOldUi);
	}

	public void clickFormatOldUi() {
		jsClick(formatOldUi);
		WaitForWebElement(eBook);
		isElementPresent(eBook);
		isElementPresent(audioBook);
	}

	public void caroselLeftRight() {
		javascriptScroll(titleCard);
//		WaitForWebElement(rightCarosel);
//		ClickOnWebElement(rightCarosel);
//		WaitForWebElement(leftCarosel);
//		isElementPresent(leftCarosel);
//		jsClick(leftCarosel);
	}

	public void clickTitleOldUi() {
		WaitForWebElement(alwaysAvailTitleOldUi);
		ClickOnWebElement(alwaysAvailTitleOldUi);
		WaitForWebElement(titleDetailsOldUi);
	}

	public void clickTitlePrimaryCta() {
		WaitForWebElement(titleDetailsPage);
		if (isElementPresent(primaryCTA1)) {
			jsClick(primaryCTA1);
		} else if (isElementPresent(primaryCtaTiltleList)) {
			ClickOnWebElement(primaryCtaTiltleList);
		}
		WaitForWebElement(holds.getLoginSubmit());
	}

	public void announceImageOrLink() {
		if (isElementPresent(announceImage)) {
			Logger.log("User able to see announcement image");
		} else if (isElementPresent(announceLink)) {
			Logger.log("User able to see announcement link");
		}
	}

	public void clickFeaturedTitleOldUi() {
		javascriptScroll(seeAllFeaturedList);
		jsClick(seeAllFeaturedList);
		WaitForWebElement(featureTitleListPageOldUi);
	}

	public void featuredTitleAbsenceOldUi() {
		if (isElementPresent(featuredListSection)) {
			isElementPresent(featuredTiltleOldUi);
		} else {
			Logger.log("User not able to see featured list section if disabled from library admin");
		}
	}

	public void clickHamNew() {
		javascriptScroll(hamMenuNewUi);
		jsClick(hamMenuNewUi);
		WaitForWebElement(libraryNewUi);
	}

	public void clickCheckOuts() {
		WaitForWebElement(checkOutsNewUi);
		ClickOnWebElement(checkOutsNewUi);
		WaitForWebElement(checkoutPage);
	}

	public void clickAvailability() {
		WaitForWebElement(availablityAll);
		jsClick(availablityAll);
		WaitForWebElement(availablityNow);
		jsClick(availablityNow);
		waitFor(5000);
	}
}
