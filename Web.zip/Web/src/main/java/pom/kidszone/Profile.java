package pom.kidszone;

import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Profile extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	Login login = new Login(DriverManager.getDriver());
	
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());

	public Profile(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(),'Adult')]")
	public static WebElement label_adult;

	@FindBy(id = "loc_cancelbtn")
	public static WebElement cancelBtn;

	@FindBy(id = "loc_profileImg")
	public static WebElement profileIcon;

	@FindBy(id = "teen")
	public static WebElement label_Teen;

	@FindBy(id = "loc_linkTeenEditProfile")
	public static WebElement teenProfile;

	@FindBy(id = "loc_linkKidEditProfile")
	public static WebElement kidProfile;

	@FindBy(id = "kid")
	public static WebElement label_kid;

	@FindBy(xpath = "//h2[text()='Register']")
	public static WebElement reg_registrationpopupheading;

	@FindBy(id = "RegisterModel_UserName")
	private WebElement reg_Libraryid;

	@FindBy(id = "RegisterModel_Password")
	private WebElement reg_password;

	@FindBy(id = "RegisterModel_SecurityQuestion_button")
	private WebElement reg_SecurityQues;

	@FindBy(id = "RegisterModel_SecurityAnswer")
	public static WebElement reg_SecurityAnswer;

	@FindBy(id = "RegisterModel_DisplayName")
	public WebElement reg_DisplayName;

	@FindBy(id = "RegisterModel_Email")
	private WebElement reg_EmailAddress;

	@FindBy(xpath = "//button[text()='Register']")
	private WebElement reg_registerButton;

	@FindBy(id = "lnkShowRegPwd")
	private WebElement admin_Regpassword;

	@FindBy(id = "RegistrationPassword")
	public static WebElement RegistrationPassword;

	@FindBy(id = "loc_linkEdit")
	private WebElement editButton;

	@FindBy(id = "loc_txtProfiles")
	public static WebElement Nav_profileManagementPage;

	@FindBy(id = "add-profile-button")
	public static WebElement Manageprofile_plusIcon;

	@FindBy(id = "loc_btnAddaTeen")
	public static WebElement Createprofile_label_AddaTeen;
	
	@FindBy(id = "loc_btnUploadPhoto")
	public static WebElement uploadphoton_AddaTeen;

	@FindBy(id = "loc_btnAddaKid")
	public static WebElement Createprofile_label_AddaKid;

	@FindBy(id = "loc_txtDisplayName")
	public static WebElement Createprofile_input_displayName;

	@FindBy(id = "loc_btnDone")
	public static WebElement Createprofile_donebtn;
	
	@FindBy(id = "loc_btnSave")
	public static WebElement Createprofile_Savebtn;

	@FindBy(id = "loc_btnSubmit")
	public static WebElement setPinDoneButton;

	@FindBy(xpath = "//*[@class='kz-pin-password']//following::p")
	public static WebElement errorMgrWrongPin;

	@FindBy(xpath = "")
	public static WebElement resetPinCTA;

	@FindBy(xpath = "//*[@class='kz-title']//p")
	public static WebElement resetPinScreen;

	@FindBy(xpath = "//*[@svgicon='close']")
	public static WebElement closeResetPinScreen;

	@FindBy(xpath = "//*[@class='doneBtn resetPin active ng-star-inserted']")
	public static WebElement resetScreenSendPinCTA;

	@FindBy(xpath = "//div[@class='profile-details']//following-sibling::p")
	public static List<WebElement> manageProf_lbl_profType;

	@FindBy(xpath = "//p[@title='Adult']")
	public static WebElement Nav_profileManagementPage_Adult;

	@FindBy(xpath = "//p[@title='Admin']")
	public static WebElement profileManagementPage_defaultprofile_admin;

	@FindBy(xpath = "(//*[contains(text(),' Primary ')])[1]")
	public static WebElement generalProfile;

	@FindBy(id = "loc_linkAdultEditProfile")
	public static WebElement profileManagementPage_defaultprofile_adminprofileicon;

	@FindBy(xpath = "(//*[contains(text(),' Teen ')])[1]")
	public static WebElement profileManagementPage_defaultprofile_teen;

	@FindBy(xpath = "//p[@title='Tester']")
	public static WebElement profileManagementPage_adult_displayname;

	@FindBy(id = "loc_linkTeenEditProfile")
	public static WebElement profileManagementPage_defaultprofile_teenProfileicon;

	@FindBy(id = "loc_linkKidEditProfile")
	public static WebElement profileManagementPage_defaultprofile_kidProfileicon;

	@FindBy(xpath = "(//*[contains(text(),' Kid ')])[1]")
	public static WebElement profileManagementPage_defaultprofile_kid;

	@FindBy(xpath = "//*[@class='kz-main kz-pro-edit-section']")
	public static WebElement profilePage;

	@FindBy(xpath = "//div[@class='kz-main kz-profile-section']")
	public static WebElement profileListPage;

	@FindBy(id = "edit-icon-focus")
	private List<WebElement> editIcon;

	@FindBy(id = "edit-icon-focus")
	private WebElement editIconProfile;

	@FindBy(id = "loc_linkCancel")
	private WebElement cancelIcon;

	@FindBy(id = "loc_linkDeleteProfile")
	private WebElement deleteButton;

	@FindBy(id = "loc_btnSave")
	private WebElement saveButton;

	@FindBy(xpath = "(//*[@id='loc_srInputHint']//following-sibling::*)[1]")
	public static WebElement errorMsgInvalidOtp;

	@FindBy(xpath = "//div[@class='kz-pro-edit-img']")
	public static WebElement profileEditSection;

	@FindBy(xpath = "//*[@class='profile-details']")
	public static List<WebElement> profileDetails;

	@FindBy(xpath = "//*[@svgicon='kz-profile-user']")
	public static List<WebElement> profilesListed;

	@FindBy(id = "pintogglefalse-input")
	public static WebElement enableProfilePin;

	@FindBy(id = "pintoggletrue-input")
	public static WebElement disableProfilePin;

	@FindBy(xpath = "pintogglefalse-input")
	public WebElement disableProfilePin_toggle;

	@FindBy(id = "pintoggletrue-input")
	public static WebElement AlreadyEnablePin;

	@FindBy(xpath = "//span[contains(text(),'Enable My Profile PIN ')]")
	public static WebElement Enablepin_txt;

	@FindBy(xpath = "//*[@class='enable_pin']")
	public static WebElement enablePINText;

	@FindBy(id = "loc_txtDisplayName")
	private WebElement displayName;

	@FindBy(xpath = "//*[@class='kz-main kz-profile-pin']")
	private WebElement profileMgmtPinPopUp;

	@FindBy(id = "alert-dialog-title")
	public static WebElement deleteProfilePopUp;

	@FindBy(xpath = "//*[@class='kz-main kz-profile-pin']")
	public static WebElement disablePinPopUp;

	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement deleteConfirmOk;


	@FindBy(xpath = "//*[@class='kz-toast-msg']")
	private WebElement failureMsg;

	@FindBy(xpath = "//*[@aria-labelledby='Set Pin Dialog']")
	private WebElement pinAttemptPopUp;

	@FindBy(xpath = "//input[@inputmode='numeric']")
	private List<WebElement> pinPlaceHolder;

	@FindBy(id = "email-input")
	public static WebElement myprofilepage_email;

	@FindBy(xpath = " //span[contains(text(),'Add same email as adult ')]")
	public static WebElement Teenprofile_email;

	@FindBy(xpath = "//*[@class='parent-email']")
	public static WebElement parentEmail_Teen;

	@FindBy(xpath = "//input[@aria-label='Security Answer']")
	public static List<WebElement> myprofile_securityAns_input;

	@FindBy(xpath = "//input[@aria-label='Security Answer']")
	public static WebElement teenprofile_securityAns_input;

	@FindBy(xpath = "//*[contains(@class,'kz-main kz-profile-pin')]")
	public static WebElement profilePin_popup;

	@FindBy(xpath = "//input[@inputmode='numeric']")
	private List<WebElement> txtfield_profileManagementPin;

	@FindBy(xpath = "//span[contains(text(),'Auto checkout available Holds' )]")
	public static WebElement AutomaticallyCheckout_checkbox;
	
	@FindBy(xpath = "//button[@aria-label='Auto checkout info']")
	public static WebElement AutomaticallyCheckout_tooltip;
	
	@FindBy(xpath = "//button[@aria-label='Auto checkout info']")
	public static WebElement AutomaticallyCheckout_disableState;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-no-info-icon'])[1]")
	public static WebElement AutomaticallyCheckout_Tooltip;

	@FindBy(xpath = "//mat-icon[@svgicon='kz-no-info-icon']")
	public static WebElement manageProf_tooltip;

	@FindBy(xpath = "//*[contains(text(),'What is your favourite animal?')]")
	public static WebElement securityQues;

	@FindBy(xpath = "//*[@svgicon='kz-back-arrow']")
	public static WebElement backIcon;

	@FindBy(id = "loc_txtAvailability")
	public static WebElement libraryPage;
	
	@FindBy(id = "loc_btnSelectAvator")
	public static WebElement selectAvatar;
	
	@FindBy(id = "loc_txtAddaTeen")
	public static WebElement addTeenPage;

	@FindBy(id = "loc_txtAddaProfile")
	public static WebElement addProfilePage;

	@FindBy(xpath = "//*[@class='kz-main kz-add-avatar']")
	public static WebElement avatarPage;

	@FindBy(xpath = "//*[@class='kz-edit-icon']")
	public static WebElement profilePageEditIcon;

	@FindBy(xpath = "")
	public static WebElement profileVerbiage;

	@FindBy(xpath = "//*[@role='alert']")
	public static WebElement invalidEmailIDVerb;
	
	@FindBy(xpath = "//*[@role='alert']")
	public static WebElement axiskids_invalidEmailIDVerb;

	@FindBy(xpath = "//*[contains(text(),'Auto checkout')]")
	public static WebElement autoCheckoutCheckBox;

	@FindBy(id = "kz-email-desc")
	public static WebElement emailDescription;

	@FindBy(xpath = "//*[@placeholder='Security Answer']")
	public static WebElement securityAnswer;

	@FindBy(xpath = "//*[contains(text(),'Enable email notification')]")
	public static WebElement enableEmailNotifyCheckBox;

	@FindBy(id = "alert-dialog-title")
	public static WebElement errorAlertEmailPopUp;

	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement errorAlertEmailPopUpCloseCTA;

	@FindBy(xpath = "")
	public static WebElement wrongOtpAlert;

	@FindBy(xpath = "")
	public static WebElement emailNotifyForWrongOtp;

	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement closeAlertEmailPopUp;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement autoCheckToolTipTxt;

	@FindBy(xpath = "//mat-icon[@svgicon='close']")
	public static WebElement pinpopup_closeIcon;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement noEmailAlertPopUp;

	@FindBy(xpath = "//*[contains(text(),'Set My Shelf as my home page')]")
	public static WebElement myShelfAsHome;

	@FindBy(id = "ngInput")
	public static WebElement pin_mismatch_errormsg;

	@FindBy(xpath = "//mat-dialog-container[@role='dialog']")
	public static WebElement Disablepinpopup;

	@FindBy(xpath = "//div[contains(text(),'Are you sure you want to disable PIN for this profile?')]")
	public static WebElement Disablepin_content;

	@FindBy(id = "alert-dialog-title")
	public static WebElement saveAlertPopUp;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement saveAlertPopUpTxt;

	@FindBy(id = "loc_cancelbtn")
	public static WebElement saveAlertPopUpCancel;

	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement saveAlertPopUpLeave;

	@FindBy(xpath = "//button[contains(text(),'Forgot PIN')]")
	public static WebElement forgotPINCTA;

	@FindBy(xpath = "(//*[contains(text(),'Add same email as primary profile')])//preceding::div[@class='mat-checkbox-background']")
	public static WebElement sameAsAdultEmailCheckBox;

	@FindBy(xpath = "(//*[@svgicon='kz-no-info-icon'])[1]")
	public static WebElement autoCheckToolTip;

	@FindBy(xpath = "//div[@class='kz-pro-edit-img']")
	public static WebElement profile_details;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement Leavepagepopup_content;

	@FindBy(xpath = "//button[contains(text(),'Send email')]")
	public static WebElement sendmail_forgetpin;
	
	@FindBy(id = "loc_linkDeleteAccount")
	public static WebElement CancelMyBoundlessAccount;
	
	
	@FindBy(xpath = "//*[contains(text(),'Add an Adult')]")
	public static WebElement AddanAdult_addProfile;
	
	@FindBy(id = "upload-photo-button")
	public static WebElement upload_photo;
	
	@FindBy(xpath = "(//*[@class='avatar-select ng-star-inserted'])[1]")
	public static WebElement avatar_img;
	
	@FindBy(xpath = "//*[contains(text(),' Auto checkout available Holds ')]")
	public static WebElement Autocheckout;
	
	@FindBy(xpath = "//*[contains(text(),' Enable email notifications ')]")
	public static WebElement Email_notication;
	
	@FindBy(xpath = "//*[contains(text(),' Display Checkout History ')]")
	public static WebElement checkoutHistory;
	
	@FindBy(xpath = "//*[contains(text(),' Display Insights & Badges')]")
	public static WebElement insightsAndBadges;
	
	@FindBy(xpath = "//*[contains(text(),' Set My Shelf as my home page')]")
	public static WebElement Myshelf_Homepage;
	
	@FindBy(xpath = "(//span[@aria-hidden='true'])[2]")
	public static WebElement PrimaryEmail_enable;
	
	@FindBy(xpath = "(//span[@aria-hidden='true'])[2]")
	public static WebElement PrimaryEmail_disabled;
	
	@FindBy(id = "loc_textParentalEmail")
	public static WebElement ParentEmail;
	
    @FindBy(xpath = "//*[@class='adultwrapper teen']")
    public static WebElement Teen_DetailsScreen;

    @FindBy(xpath = "//*[@class='adultwrapper kid']")
    public static WebElement kid_DetailsScreen;
    
    @FindBy(xpath = "//*[@class='kz-toast-msg']")
    public WebElement sucessMsg;

	public WebElement getSucessMsg() {
		return sucessMsg;
	}

	public WebElement getDeleteButton() {
		return deleteButton;
	}

	public WebElement getCancelIcon() {
		return cancelIcon;
	}

	public List<WebElement> getEditIcon() {
		return editIcon;
	}

	public void clickEditIcon() {
		javascriptScroll(editButton);
		jsClick(editButton);
		WaitForWebElement(editIcon.get(0));
		WaitForWebElement(cancelIcon);
	}

	public void clickBackIcon() {
		visibilityWait(backIcon);
		jsClick(backIcon);
		waitFor(2000);
	}

	public boolean view_RegistrationPopup() {
		boolean b = true;
		waitFor(2000);
		visibilityWait(reg_registerButton);
		javascriptScroll(reg_registerButton);
		reg_Libraryid.isDisplayed();
		//reg_SecurityQues.isDisplayed();
		//reg_SecurityAnswer.isDisplayed();
		reg_DisplayName.isDisplayed();
		reg_EmailAddress.isDisplayed();
		return b;
	}

	public boolean view_RegistrationPopupwithpassword() {
		boolean b = true;
		waitFor(2000);
		javascriptScroll(reg_registerButton);
		reg_Libraryid.isDisplayed();
		reg_password.isDisplayed();
		reg_SecurityQues.isDisplayed();
		reg_SecurityAnswer.isDisplayed();
		reg_DisplayName.isDisplayed();
		reg_EmailAddress.isDisplayed();
		return b;
	}

	public void click_adminPassword() {
		visibilityWait(admin_Regpassword);
		javascriptScroll(admin_Regpassword);
		jsClick(admin_Regpassword);
		visibilityWait(RegistrationPassword);
	}

	public void Enter_Newuserpassword(String password) {
		SendKeysOnWebElement(RegistrationPassword, password);
		jsClick(reg_registerButton);
		WaitForWebElement(reg_registrationpopupheading);

	}

	public void clickDeleteButton() {
		javascriptScroll(deleteButton);
		jsClick(deleteButton);
		WaitForWebElement(deleteConfirmOk);
		//jsClick(deleteConfirmOk);
		// WaitForWebElement(profileMgmtPinPopUp);
	}

	public void Enter_SecurityAns(String SecurityAnswer) {
		javascriptScroll(reg_SecurityAnswer);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		jsClick(reg_registerButton);
		waitFor(2000);
	}
	
	public void Enter_DisplayName(String DisplayName) {
		javascriptScroll(reg_DisplayName);
		SendKeysOnWebElement(reg_DisplayName, DisplayName+RandomStringGenerate());
		jsClick(reg_registerButton);
		waitFor(2000);

	}

	public void enterEmailandSecurity(String security, String email) {
		javascriptScroll(reg_SecurityAnswer);
		SendKeysOnWebElement(reg_SecurityAnswer, security);
		javascriptScroll(reg_EmailAddress);
		SendKeysOnWebElement(reg_EmailAddress, email);
		waitFor(2000);
		jsClick(reg_registerButton);
		waitFor(2000);
	}

	public void create_TeenProfile(String newteenprofile) {
		visibilityWait(Manageprofile_plusIcon);
		jsClick(Manageprofile_plusIcon);
		WaitForWebElement(Createprofile_label_AddaTeen);
		jsClick(Createprofile_label_AddaTeen);
		SendKeysOnWebElement(Createprofile_input_displayName, newteenprofile);
		javascriptScroll(Createprofile_Savebtn);
		jsClick(Createprofile_Savebtn);
	}

	public void create_KidProfile(String NewKidprofile) {
		visibilityWait(Manageprofile_plusIcon);
		jsClick(Manageprofile_plusIcon);
		jsClick(Createprofile_label_AddaKid);
		SendKeysOnWebElement(Createprofile_input_displayName, NewKidprofile);
		javascriptScroll(Createprofile_Savebtn);
		jsClick(Createprofile_Savebtn);
	}

	public void clickCancel() {
		WaitForWebElement(cancelIcon);
		jsClick(cancelIcon);
		inVisibilityWait(profilePageEditIcon);
		WaitForWebElement(profileManagementPage_defaultprofile_adminprofileicon);
	}

	public void enterPin(String pin) {
		waitFor(2000);
		for (int i = 0; i < pin.length(); i++) {
			char s = pin.charAt(i);
			String s1 = new StringBuilder().append(s).toString();
			SendKeysOnWebElement(pinPlaceHolder.get(i), s1);
		}
		waitFor(2000);
	}

	public void click_submit() {
		visibilityWait(setPinDoneButton);
		jsClick(setPinDoneButton);
	}

	public void setProfilePin(String pin) {
		if (isElementPresent(disableProfilePin_toggle)) {
			Logger.log("Pin Has already enabled");
		} else {
			ClickOnWebElement(enableProfilePin);
			if (isElementPresent(profileMgmtPinPopUp)) {
				WaitForWebElement(profileMgmtPinPopUp);
				enterPin(pin);
				ClickOnWebElement(setPinDoneButton);
				enterPin(pin);
				ClickOnWebElement(setPinDoneButton);
				WaitForWebElement(disableProfilePin);
			}
		}
	}

	public void enableProfilePin(String pin) {
		jsClick(enableProfilePin);
		WaitForWebElement(profileMgmtPinPopUp);
		enterPin(pin);
		jsClick(setPinDoneButton);
		enterPin(pin);
		jsClick(setPinDoneButton);
		WaitForWebElement(disableProfilePin);
	}

	public void enableKidPin(String pin) {
		clickEditIcon();
		login.select_Kidprofile();
		if (isElementPresent(profileEditSection)) {
			setProfilePin(pin);
		} else if (isElementPresent(profileMgmtPinPopUp)) {
			enterPin(pin);
			jsClick(setPinDoneButton);
		}
//		WaitForWebElement(profileEditSection);
	}

	public void deleteProfile(String message) {
		waitFor(2000);
		javascriptScroll(deleteConfirmOk);
		jsClick(deleteConfirmOk);
		WaitForWebElement(sucessMsg);
		Assert.assertTrue(sucessMsg.getText().contains("Success!"));
		Assert.assertTrue(sucessMsg.getText().contains(message));
	}

	public void deleteProfile() {
		javascriptScroll(deleteConfirmOk);
		jsClick(deleteConfirmOk);
		WaitForWebElement(sucessMsg);
		Assert.assertTrue(sucessMsg.getText().contains("Success!"));
	}

	public void createKidProfileWithPin(String Kid) {
		if (isElementPresent(kidProfile)) {
			Logger.log("Patron already has kid profile");
		} else {
			create_KidProfile(Kid);
		}
	}

	public boolean view_DefaultProfiles_withoutDisplayName() {
		visibilityWait(profileManagementPage_defaultprofile_adminprofileicon);
		boolean b = true;
		profileManagementPage_defaultprofile_adminprofileicon.isDisplayed();
		profileManagementPage_defaultprofile_teenProfileicon.isDisplayed();
		profileManagementPage_defaultprofile_kidProfileicon.isDisplayed();
		return b;
	}

	public void Enter_RegDetails_IdWithpassword(String username, String password, String SecurityAnswer,
			String DisplayName) {
		javascriptScroll(reg_registerButton);
		visibilityWait(reg_Libraryid);
		SendKeysOnWebElement(reg_Libraryid, username + RandomStringGenerate());
		SendKeysOnWebElement(reg_password, password);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		SendKeysOnWebElement(reg_DisplayName, DisplayName);
		waitFor(2000);
		jsClick(reg_registerButton);
	}

	public void Enter_RegDetailswithEmail(String SecurityAns, String DisplayName, String Email) {
		javascriptScroll(reg_registerButton);
		visibilityWait(reg_Libraryid);
		// SendKeysOnWebElement(reg_Libraryid, username+ RandomStringGenerate());
		// SendKeysOnWebElement(reg_password, password);
		//WaitForWebElement(securityQues);
		waitFor(2000);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAns);
		waitFor(2000);
		SendKeysOnWebElement(reg_DisplayName, DisplayName);
		waitFor(2000);
		SendKeysOnWebElement(reg_EmailAddress, Email);
		waitFor(3000);
		jsClick(reg_registerButton);
		waitFor(3000);

	}
	
	public void nyc_enter_RegDetailswithEmail(String DisplayName, String Email) {
		javascriptScroll(reg_registerButton);
		visibilityWait(reg_Libraryid);
		SendKeysOnWebElement(reg_DisplayName, DisplayName+RandomStringGenerate());
		waitFor(2000);
		SendKeysOnWebElement(reg_EmailAddress, Email);
		waitFor(3000);
		jsClick(reg_registerButton);
		waitFor(3000);

	}

	public void Enter_RegDetailsWithoutpassword(String SecurityAns, String DisplayName) {
		javascriptScroll(reg_registerButton);
		visibilityWait(reg_Libraryid);
		// SendKeysOnWebElement(reg_Libraryid, username+ RandomStringGenerate());
		// SendKeysOnWebElement(reg_password, password);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAns);
		SendKeysOnWebElement(reg_DisplayName, DisplayName);
		waitFor(3000);
		jsClick(reg_registerButton);
		waitFor(3000);
	}

	public void View_AdultNameFielf(String AdultName) {
		String DisplayName = "Tester";
		if (profileManagementPage_adult_displayname.getText().equalsIgnoreCase(DisplayName)) {
			Logger.log("user should be able to view 'tester' value in the Name field");
		} else {
			Logger.log("user not able to view 'tester' value in the Name field");
		}
	}

	public void deleteProfileRestrict() {
		WaitForWebElement(failureMsg);
		Assert.assertTrue(failureMsg.getText().contains("Failure!"));
	}

	public void clickProfile() {
		visibilityWait(profileIcon);
		javascriptScroll(profileIcon);
		jsClick(profileIcon);
		visibilityWait(profilePage);
	}

	public void clickDisablePin() {
		javascriptScroll(disableProfilePin);
		jsClick(disableProfilePin);
		waitFor(3000);
		// visibilityWait(disablePinPopUp);
		// visibilityWait(errorAlertEmailPopUp);
	}

	public void clickCancelBtn() {
		waitFor(2000);
		jsClick(cancelBtn);
		waitFor(3000);
	}

	public void disablePinOK() {
		visibilityWait(deleteConfirmOk);
		jsClick(deleteConfirmOk);
		waitFor(2000);
	}

	public void edit_Adultprofile() {
		visibilityWait(editIcon.get(0));
		jsClick(editIcon.get(0));
		visibilityWait(myprofilepage_email);

	}

	public void view_EmailAndSecurityAns(String Email, String Securityanswer) {
		visibilityWait(myprofilepage_email);
		Assert.assertTrue(myprofilepage_email.isDisplayed());
		SendKeysOnWebElement(myprofilepage_email, Email);
		Assert.assertTrue(teenprofile_securityAns_input.isDisplayed());
	}

	public void click_EnableprofilePin() {
		visibilityWait(enableProfilePin);
		javascriptScroll(enableProfilePin);
		jsClick(enableProfilePin);
		waitFor(2000);
		// visibilityWait(disableProfilePin);
	}

	public void click_EnableprofilePin(String pin) {
		if (isElementPresent(enableProfilePin)) {
			javascriptScroll(enableProfilePin);
			jsClick(enableProfilePin);
//			visibilityWait(disableProfilePin);
		} else if (isElementPresent(disableProfilePin)) {
			jsClick(disableProfilePin);
			WaitForWebElement(profileMgmtPinPopUp);
			disableProcess(pin);
			disablePinOK();
			click_SaveBtn();
			WaitForWebElement(enableProfilePin);
			jsClick(enableProfilePin);
		}
	}

	public void enterTeenProfile(String pin) {
		if (isElementPresent(profileMgmtPinPopUp)) {
			enterPin(pin);
			jsClick(setPinDoneButton);
			waitFor(2000);
		} else {
			waitFor(2000);
			
		}
	}

	public void Enter_setPin(String Pin) {
		waitFor(2000);
		javascriptScroll(txtfield_profileManagementPin.get(0));
		String pin = Pin;
		for (int i = 0; i < pin.length(); i++) {
			char s = pin.charAt(i);
			String s1 = new StringBuilder().append(s).toString();
			SendKeysOnWebElement(txtfield_profileManagementPin.get(i), s1);
		}
		waitFor(4000);
	}

	public void click_SaveBtn() {
		visibilityWait(saveButton);
		javascriptScroll(saveButton);
		jsClick(saveButton);
	}

	public void click_AddEmailOrSecurityAnsPopup() {
		visibilityWait(deleteProfilePopUp);
		jsClick(deleteConfirmOk);
		waitFor(2000);
	}

	public void enterDisplayName(String name) {
		javascriptScroll(displayName);
		SendKeysOnWebElement(displayName, name + RandomStringGenerate());
		waitFor(2000);
		String nameDisplayed = displayName.getText();
		waitFor(2000);
		javascriptScroll(saveButton);
		jsClick(saveButton);
		WaitForWebElement(search.getSuccess_msg());
		waitFor(2000);
		Assert.assertEquals(displayName.getText().contains(nameDisplayed), true);
	}

	public void disableProcess(String pin) {
		waitFor(2000);
		enterPin(pin);
		jsClick(setPinDoneButton);
		inVisibilityWait(setPinDoneButton);
	}

	public void changeDispName() {
		javascriptScroll(displayName);
		String existingName = displayName.getText();
		waitFor(2000);
		SendKeysOnWebElement(displayName, existingName + RandomStringGenerate());
		waitFor(3000);
		String nameDisplayed = displayName.getText();
		waitFor(2000);
		Assert.assertEquals(displayName.getText().contains(nameDisplayed), true);
	}

	public void Edit_DisplayName() {
		javascriptScroll(displayName);
		String existingName = displayName.getText();
		waitFor(2000);
		SendKeysOnWebElement(displayName, existingName + RandomStringGenerate());
		waitFor(3000);
	}

	public void clickSaveProfile() {
		javascriptScroll(saveButton);
		jsClick(saveButton);
		WaitForWebElement(search.getSuccess_msg());
		waitFor(2000);
	}

	public void clickPlusIcon() {
		visibilityWait(Manageprofile_plusIcon);
		javascriptScroll(Manageprofile_plusIcon);
		jsClick(Manageprofile_plusIcon);
		WaitForWebElement(Createprofile_label_AddaTeen);
	}

	public void clickAddATeen() {
		visibilityWait(Createprofile_label_AddaTeen);
		jsClick(Createprofile_label_AddaTeen);
		waitFor(2000);
		visibilityWait(addTeenPage);
	}

	public void clickAddAKid() {
		WaitForWebElement(Createprofile_label_AddaKid);
		jsClick(Createprofile_label_AddaKid);
		//WaitForWebElement(addProfilePage);
		waitFor(2000);
	}

	public void clickAvatar() {
		visibilityWait(selectAvatar);
		jsClick(selectAvatar);
		WaitForWebElement(avatarPage);
	}

	public void clickEditProfileAvatar() {
		WaitForWebElement(profilePageEditIcon);
		jsClick(profilePageEditIcon);
		WaitForWebElement(avatarPage);
	}

	public void enterEmailID(String email) {
		waitFor(2000);
		SendKeysOnWebElement(myprofilepage_email, email);
		waitFor(3000);
	}

	public void autoCheckOut() {
		waitFor(2000);
		if (autoCheckoutCheckBox.isSelected()) {
			Logger.log("Auto Checkout already enabled");
		} else {
			jsClick(autoCheckoutCheckBox);
		}
		waitFor(2000);
	}

	public void enableEmailNotify() {
		waitFor(2000);
		if (enableEmailNotifyCheckBox.isSelected()) {
			Logger.log("Enable Email Notification already enabled");
		} else {
			jsClick(enableEmailNotifyCheckBox);
		}
		waitFor(2000);
	}

	public void clickEmailNotify() {
//		disableEmailNotify();
		waitFor(2000);
		visibilityWait(enableEmailNotifyCheckBox);
		javascriptScroll(enableEmailNotifyCheckBox);
		jsClick(enableEmailNotifyCheckBox);
		waitFor(2000);
	}

	public void disableEmailNotify() {
		waitFor(2000);
		if (enableEmailNotifyCheckBox.isSelected()) {
			waitFor(2000);
			jsClick(enableEmailNotifyCheckBox);
			Logger.log("Enable Email Notification disabled");
		} else {
			Logger.log("Enable Email Notification already disabled");
		}
		waitFor(2000);
	}

	public void clickAutoCheckoutToolTip(String verbiage) {
		visibilityWait(autoCheckToolTip);
		javascriptScroll(autoCheckToolTip);
		jsClick(autoCheckToolTip);
	}

	public void click_closeIcon() {
		visibilityWait(pinpopup_closeIcon);
		jsClick(pinpopup_closeIcon);
		waitFor(2000);
	}

	public void Already_DisabledPin(String pin) {
		javascriptScroll(enableProfilePin);
		click_EnableprofilePin();
		waitFor(2000);
		Enter_setPin(pin);
		click_submit();
		click_SaveBtn();
		waitFor(3000);
	}

//		javascriptScroll(AutomaticallyCheckout_Tooltip);
//		jsClick(AutomaticallyCheckout_Tooltip);
//		WaitForWebElement(autoCheckToolTipTxt);
//		Assert.assertEquals(autoCheckToolTipTxt.getText().contains(verbiage), true);
//	}

	public void click_AutocheckoutTooltip(String verbiage) {
		javascriptScroll(AutomaticallyCheckout_tooltip);
		jsClick(AutomaticallyCheckout_tooltip);
		visibilityWait(autoCheckToolTipTxt);
		Assert.assertEquals(autoCheckToolTipTxt.getText().contains(verbiage), true);
		waitFor(2000);
		jsClick(closeAlertEmailPopUp);
		waitFor(2000);

	}
	
	
	public boolean verify_DisableStateAutocheckout() {
		boolean b=true;
		Assert.assertEquals(AutomaticallyCheckout_disableState.isDisplayed(), true);
		System.out.println("Teen and kid is able to view the disable state for auto checkout");
		return b;
	}
	public void clickEnablePinWOEmail() {
		javascriptScroll(enableProfilePin);
		jsClick(enableProfilePin);
		WaitForWebElement(noEmailAlertPopUp);
	}

	public void closeEmailAlertPopUp() {
		javascriptScroll(closeAlertEmailPopUp);
		jsClick(closeAlertEmailPopUp);
		waitFor(3000);
	}

	public void inValidPinTwoTimes(String pin) {
		for (int i = 0; i < 2; i++) {
			enterPin(pin);
			jsClick(setPinDoneButton);
			waitFor(2000);
			Assert.assertEquals(errorMgrWrongPin.isDisplayed(), true);
			WaitForWebElement(failureMsg);
			if (i == 0) {
				Assert.assertEquals(errorMgrWrongPin.getText().contains("Two more attempt left"), true);
			} else if (i == 1) {
				Assert.assertEquals(errorMgrWrongPin.getText().contains("One more attempt left"), true);
			}
		}
	}

	public void inValidPinThreeTimes(String pin) {
		for (int i = 0; i < 3; i++) {
			enterPin(pin);
			jsClick(setPinDoneButton);
			waitFor(2000);
			WaitForWebElement(failureMsg);
			if (i == 0) {
				Assert.assertEquals(errorMgrWrongPin.getText().contains("Two more attempt left"), true);
			} else if (i == 1) {
				Assert.assertEquals(errorMgrWrongPin.getText().contains("One more attempt left"), true);
			} else if (i == 2) {
				Assert.assertEquals(resetScreenSendPinCTA.isDisplayed(), true);
			}
		}
	}

	public void correctPinNav(String pin) {
		enterPin(pin);
		jsClick(setPinDoneButton);
		waitFor(2000);
	}

	public void clickResetPinCta() {
		waitFor(2000);
		jsClick(resetPinCTA);
		waitFor(2000);
	}

	public void clickSendPinCta() {
		waitFor(2000);
		jsClick(resetScreenSendPinCTA);
		waitFor(2000);
	}

	public void clickForgotPinCta() {
		waitFor(2000);
		jsClick(forgotPINCTA);
		waitFor(2000);
	}

	public void inValidOtp(String pin) {
		waitFor(2000);
		enterPin(pin);
		jsClick(setPinDoneButton);
		WaitForWebElement(errorMsgInvalidOtp);
		waitFor(2000);
	}

	public void closeResetPinScreen() {
		waitFor(2000);
		jsClick(closeResetPinScreen);
		waitFor(2000);
	}

	public void clickSameAsAdult() {
		visibilityWait(profileEditSection);
		waitFor(2000);
		if (isElementPresent(parentEmail_Teen)) {
			for (int i = 0; i < 2; i++) {
				waitFor(2000);
				jsClick(sameAsAdultEmailCheckBox);
			}
		} else {
			jsClick(sameAsAdultEmailCheckBox);
			waitFor(2000);
		}
	}

	public void verifySameAsAdult() {
//		String emailAdult = myprofilepage_email.getText();
//		waitFor(2000);
//		login.click_HamburgerMenu();
//		login.click_Profiles();
//		waitFor(2000);
//		login.click_Teenprofile();
//		WaitForWebElement(profileIcon);
//		clickProfile();
		waitFor(2000);
		clickSameAsAdult();
		waitFor(2000);
//		Assert.assertTrue(sameAsAdultEmailCheckBox.isSelected());
		Assert.assertEquals(isElementPresent(parentEmail_Teen), true);
		// Assert.assertTrue(parentEmail_Teen.getText() != null);
	}

	public void Enter_RegDetailswithoutEmailOldUI(String SecurityAnswer, String PIN) {
		WaitForWebElement(reg_password);
		SendKeysOnWebElement(reg_password, PIN);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		waitFor(2000);
		jsClick(reg_registerButton);
	}

	public void click_AdultProfile() {
		WaitForWebElement(profileManagementPage_defaultprofile_adminprofileicon);
		jsClick(profileManagementPage_defaultprofile_adminprofileicon);
		login.preferenceScreen_popup();
	}

	public void Enter_RegDetailsOldUI(String displayNmae, String SecurityAnswer, String PIN) {
		WaitForWebElement(reg_password);
		SendKeysOnWebElement(reg_password, PIN);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		SendKeysOnWebElement(reg_DisplayName, displayNmae);
		waitFor(2000);
		jsClick(reg_registerButton);
	}

	public void enter_invalidPin_Unlimited(String incorrectpin) {
		for (int i = 0; i < 10; i++) {
			enterPin(incorrectpin);
			click_submit();
		}
		waitFor(2000);
	}
	
	public void enterKidProfile(String pin) {
		if (isElementPresent(profileMgmtPinPopUp)) {
			enterPin(pin);
			jsClick(setPinDoneButton);
			waitFor(2000);
		} else {
			waitFor(2000);
			
		}
	}
	
	public void Enters_RegistrationDetails(String SecurityAns, String DisplayName) {
                javascriptScroll(reg_Libraryid);
                SendKeysOnWebElement(reg_SecurityAnswer, SecurityAns);
               SendKeysOnWebElement(reg_DisplayName, DisplayName);
               jsClick(reg_registerButton);
               waitFor(2000);

	}
	
	public void Enter_RegDetailsOldUIWithEmail(String displayNmae, String SecurityAnswer, String PIN, String Email) {
		WaitForWebElement(reg_password);
		SendKeysOnWebElement(reg_password, PIN);
		waitFor(2000);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		SendKeysOnWebElement(reg_EmailAddress, Email);
		SendKeysOnWebElement(reg_DisplayName, displayNmae);
		waitFor(2000);
		jsClick(reg_registerButton);		
        }
	

	public void Enter_RegDetailsOldUIWithoutEmail(String displayNmae, String SecurityAnswer, String PIN) {
		WaitForWebElement(reg_password);
		SendKeysOnWebElement(reg_password, PIN);
		waitFor(2000);
		SendKeysOnWebElement(reg_SecurityAnswer, SecurityAnswer);
		SendKeysOnWebElement(reg_DisplayName, displayNmae);
		waitFor(2000);
		javascriptScroll(reg_registerButton);
		jsClick(reg_registerButton);		
        }
	
	
	public static void click_CancelBoundlessAccountCta() {
		javascriptScroll(CancelMyBoundlessAccount);
		jsClick(CancelMyBoundlessAccount);
		jsClick(deleteConfirmOk);

	}
	
	public void enter_ProfileDetails(String displayName, String Email) {
		ClickOnWebElement(Createprofile_input_displayName);
		SendKeysOnWebElement(Createprofile_input_displayName, displayName+RandomStringGenerate());
		ClickOnWebElement(myprofilepage_email);
		SendKeysOnWebElement(myprofilepage_email, Email);

	}
	
	public void enter_KidprofileDetails(String displayName) {
		ClickOnWebElement(Createprofile_input_displayName);
		SendKeysOnWebElement(Createprofile_input_displayName, displayName+RandomStringGenerate());
		waitFor(2000);

	}
	
	
	public void click_AddanAdultProfile() {
		jsClick(AddanAdult_addProfile);
		visibilityWait(profile_details);

	}
	
	public void click_Editicon() {
	jsClick(editIconProfile);
	visibilityWait(avatarPage);

	}
	
	public void enter_DisplayName(String displayName) {
		SendKeysOnWebElement(Createprofile_input_displayName, displayName);
		waitFor(2000);

	}
	
	public void profileDetails_verbiage(String verbiage) {
		if (checkoutHistory.getText().contains(verbiage)) {
			Assert.assertTrue(checkoutHistory.isDisplayed());
		}else if (insightsAndBadges.getText().contains(verbiage)) {
			Assert.assertTrue(insightsAndBadges.isDisplayed());
		}else if (Myshelf_Homepage.getText().contains(verbiage)) {
			Assert.assertTrue(Myshelf_Homepage.isDisplayed());
		}
		
	}

}
