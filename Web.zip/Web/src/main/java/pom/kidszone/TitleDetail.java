package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;

public class TitleDetail extends CommonAction {

	public TitleDetail(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//*[@class='mat-card-image card-image'])[1]")
	private WebElement titleCard;

	@FindBy(xpath = "(//*[@class='mat-card-image card-image'])")
	private List<WebElement> titleCardCoverImage;

	@FindBy(xpath = "(//*[@class='card-link ng-star-inserted'])")
	private List<WebElement> titleCardLibPage;

	@FindBy(xpath = "//*[@class='breadcrumb kz-breadcrumb']")
	private WebElement breadcrumbTitleDetail;

	@FindBy(xpath = "//*[@class='titledetails-bookwrapper']")
	private WebElement titleDetailPage;

	@FindBy(xpath = "//h2[contains(text(),'Also Available')]")
	private WebElement alsoAvailableCarousel;

	@FindBy(xpath = "//*[contains(text(),'Related Items')]")
	private WebElement relatedItems;
	
	@FindBy(xpath = "//*[contains(text(),'More Like This')]")
	private WebElement moreLikeThis;

	@FindBy(xpath = "//*[@placeholder='Search for content']")
	private WebElement searchBar;

	@FindBy(xpath = "//button[@class='kz-searchButton']")
	private WebElement searchButton;

	@FindBy(xpath = "//h2[contains(text(),'Other Titles Like This')]")
	private WebElement titleLikeThis;

	@FindBy(xpath = "//h2[contains(text(),'Other Titles Like This')]/following::*[1]")
	private WebElement titleLikeThisCarousel;

	@FindBy(xpath = "//h2[contains(text(),'Titles in This Series')]")
	private WebElement otherTitles;

	@FindBy(xpath = "//h2[contains(text(),'Titles in This Series')]/following::*[1]")
	private WebElement otherTitleCarousel;

	@FindBy(id = "loc_linkBrowserBySubject")
	private WebElement browseBySubject;

	@FindBy(id = "loc_txtyoung adult fiction")
	private WebElement youngAdultSection;

	@FindBy(xpath = "(//*[@class='mat-card-image card-image'])[1]")
	private WebElement titleCardInTitleList;

	@FindBy(xpath = "//*[@class='btn-primary-blue btn-full-width btn-review']")
	private WebElement writeReviewButton;

	public WebElement getWriteReviewButton() {
		return writeReviewButton;
	}

	@FindBy(xpath = "//*[@class='kz-alert-dialog']")
	private WebElement reviewPopUp;

	@FindBy(xpath = "//*[contains(text(),'You already submitted')]")
	private WebElement reviewSubmitted;

	@FindBy(xpath = "//*[@class='okBtn disabledBtn ng-star-inserted']")
	private WebElement submitButton;

	@FindBy(xpath = "//span[contains(text(),'Place Hold')]")
	private List<WebElement> placeHold;

	@FindBy(xpath = "//div[@class='kz-card-image ng-star-inserted']")
	private List<WebElement> titleImage;

	@FindBy(xpath = "//button[@aria-label='more option']")
	private WebElement moreOption_TitleDetailPage;

	@FindBy(xpath = "//button[contains(text(),' Add to Wishlist ')]")
	private WebElement wishlist_secondaryCta;

	@FindBy(xpath = "//button[contains(text(),' Share ')]")
	private WebElement Share_secondaryCta;

	@FindBy(xpath = "//span[contains(text(),'Place Hold')]")
	private WebElement PlaceHold_Cta;

	@FindBy(xpath = "//span[contains(text(),'place hold')]")
	private List<WebElement> placeHold_OldUI;
	
	@FindBy(xpath = "(//span[contains(text(),'Place Hold')])[2]")
	private WebElement titleDetails_PlaceHold_Cta;

	@FindBy(id = "alert-dialog-title")
	private WebElement hold_Alertbox;

	@FindBy(id = "alert-heading")
	private WebElement holdConfirmed_header;

	@FindBy(id = "loc_textalertcontent")
	private WebElement holdConfirmed_Textmsg;

	@FindBy(id = "loc_btnHamburgerMenu")
	private WebElement hamburgerMenu_NewUI;

	@FindBy(id = "loc_linkPrograms")
	private WebElement programsFromMenu_NewUI;

	@FindBy(id = "loc_txtactivePrograms")
	private WebElement activePrograms;

	@FindBy(xpath = "//*[contains(text(),'AutomationProgram1 ')]")
	private WebElement automationProgram;

	@FindBy(id = "breadcrumb-link-2")
	public WebElement programDetailPage;

	@FindBy(id = "loc_linkMyShelf")
	private WebElement MyShelffromMenu;

	@FindBy(id = "loc_labelWishlist")
	private WebElement whishlistFromMyStuff;

	@FindBy(xpath = "//*[contains(text(),' Remove from Wishlist ')]")
	private WebElement RemoveWishlistSecondaryCta;

	@FindBy(xpath = "//*[@class='spinner-loader']")
	public static WebElement spinnerLoading;

	@FindBy(id = "toggle")
	private WebElement hamburgerMenu_OldUI;

	@FindBy(xpath = "//a[text()='PROGRAMS']")
	private WebElement programsFromMenu_OldUI;

	@FindBy(xpath = "//*[@class='mat-card mat-focus-indicator kz-card ng-star-inserted']")
	private List<WebElement> titleCard_LibPage;
	
	@FindBy(xpath = "//*[@class='kz-custom-container-secondary']//div[@class='book-ribbon ng-star-inserted']")
	private List<WebElement> mylib_NewPlaceHold;
	
	@FindBy(xpath = "")
	private WebElement alternateCarousel;
	
	@FindBy(id = "loc_TxtFeaturedReadingProgram")
	public static WebElement library_FeaturedProgram;
	
	@FindBy(xpath = "(//div[@class='kz-card-image ng-star-inserted'])[1]")
	public WebElement firstTitle_FeaturedProgram;
	
	@FindBy(id = "loc_btnJoinProgram")
	public static WebElement joinProgramCta;
	
	@FindBy(id = "loc_btnLeaveProgram")
	public static WebElement leaveProgramCta;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement Cta_Ok;

	public WebElement getAlternateCarousel() {
		return alternateCarousel;
	}
	
	public WebElement getAlsoAvailableCarousel() {
		return alsoAvailableCarousel;
	}

	public WebElement getActivePrograms() {
		return activePrograms;
	}

	public WebElement getHold_Alertbox() {
		return hold_Alertbox;
	}

	public WebElement getHoldConfirmed_header() {
		return holdConfirmed_header;
	}

	public WebElement getHoldConfirmed_Textmsg() {
		return holdConfirmed_Textmsg;
	}

	public WebElement getPlaceHold_Cta() {
		return PlaceHold_Cta;
	}

	public WebElement getReviewSubmitted() {
		return reviewSubmitted;
	}

	public WebElement getBreadcrumbTitleDetail() {
		return breadcrumbTitleDetail;
	}

	public WebElement getOtherTitles() {
		return otherTitles;
	}

	public WebElement getOtherTitleCarousel() {
		return otherTitleCarousel;
	}

	public WebElement getTitleLikeThis() {
		return titleLikeThis;
	}

	public WebElement getTitleLikeThisCarousel() {
		return titleLikeThisCarousel;
	}

	public WebElement getTitleCard() {
		return titleCard;
	}

	public WebElement getTitleDetailPage() {
		return titleDetailPage;
	}

	public WebElement getRelatedItems() {
		return relatedItems;
	}

	public void clickRelatedItems() {
		WaitForWebElement(relatedItems);
		jsClick(relatedItems);
		WaitForWebElement(alsoAvailableCarousel);
	}
	
	public void clickMoreLikeThis() {
		visibilityWait(moreLikeThis);
		javascriptScroll(moreLikeThis);
		jsClick(moreLikeThis);
		WaitForWebElement(titleLikeThis);
	}

	public void clickTitleCard() {
		WaitForWebElement(titleCard);
		jsClick(titleCard);
		WaitForWebElement(titleDetailPage);
	}

	public void clickBrowseBySubject() {
		jsClick(browseBySubject);
		WaitForWebElement(youngAdultSection);
		javascriptScroll(youngAdultSection);
		jsClick(youngAdultSection);
		WaitForWebElement(titleCardInTitleList);
	}

	public void clickTitleCardInTitleList() {
		javascriptScroll(titleCardInTitleList);
		ClickOnWebElement(titleCardInTitleList);
		WaitForWebElement(titleDetailPage);
	}

	public void clickWriteAReview() {
		javascriptScroll(writeReviewButton);
		ClickOnWebElement(writeReviewButton);
		WaitForWebElement(reviewPopUp);
	}

	public void clickAndNavigateToDetailsPage() {
		for (int i = 0; i < titleCardLibPage.size(); i++) {
			if (titleCardLibPage.get(i).getText().equalsIgnoreCase("Place Hold")) {
				System.out.println(titleCardLibPage.get(i));
				javascriptScroll(titleImage.get(i));
				jsClick(titleImage.get(i));
				break;
			}
		}
		WaitForWebElement(titleDetailPage);
	}

	public void secondaryCtaInDetailsPage() {
		WaitForWebElement(moreOption_TitleDetailPage);
		jsClick(moreOption_TitleDetailPage);
		Assert.assertTrue(wishlist_secondaryCta.isDisplayed());
		Assert.assertTrue(Share_secondaryCta.isDisplayed());
	}

	public void click_placeonhold() {
		waitFor(3000);
		jsClick(titleDetails_PlaceHold_Cta);
		waitFor(3000);

	}

	public void click_holdCtaOldUI() {
		for (int i = 0; i < placeHold_OldUI.size(); i++) {
			if (placeHold_OldUI.get(i).getText().equalsIgnoreCase("place hold")) {
				jsClick(placeHold_OldUI.get(i));
				break;
			}

		}

	}

	public void click_holdCtaNewUI() {
		javascriptScroll(placeHold.get(1));
		for (int i = 0; i < placeHold.size(); i++) {
			if (placeHold.get(i).getText().equalsIgnoreCase("Place Hold")) {
				jsClick(placeHold.get(i));
				break;
			}
		}
		waitFor(2000);
	}

	
	public void click_WaitListForPlaceHold() {
        for (int i = 0; i < mylib_NewPlaceHold.size(); i++) {
            if (mylib_NewPlaceHold.get(i).getText().equalsIgnoreCase("Waitlist")) {
                jsClick(mylib_NewPlaceHold.get(i));
                break;
            }
        }
        visibilityWait(titleDetails_PlaceHold_Cta);
        jsClick(titleDetails_PlaceHold_Cta);
        waitFor(2000);

 

    }
	public void click_programsFromMenuNewUI() {
		jsClick(hamburgerMenu_NewUI);
		jsClick(programsFromMenu_NewUI);

	}

	public void click_programsFromMenuOldUI() {
		jsClick(hamburgerMenu_OldUI);
		jsClick(programsFromMenu_OldUI);

	}

	public void click_activeProgram() {
		WaitForWebElement(automationProgram);
		jsClick(automationProgram);
		WaitForWebElement(programDetailPage);

	}

	public void viewHoldAsPrimaryCta() {
		for (int i = 0; i < titleCard_LibPage.size(); i++) {
			if (titleCard_LibPage.get(i).getText().equalsIgnoreCase("Place Hold")) {
				Assert.assertTrue(placeHold.get(i).isDisplayed());
				break;
			}
		}
	}

	public void AddHoldtitleToWishlist() {
		for (int i = 0; i < placeHold.size(); i++) {
			if (placeHold.get(i).getText().equalsIgnoreCase("Place Hold")) {
				ClickOnWebElement(moreOption_TitleDetailPage);
				ClickOnWebElement(wishlist_secondaryCta);
				break;
			}
		}
	}

	public void NavToMyShelfScreen() {
		ClickOnWebElement(hamburgerMenu_NewUI);
		ClickOnWebElement(MyShelffromMenu);

	}

	public void click_WhishlistCtainMyStuffPage() {
		WaitForWebElement(whishlistFromMyStuff);
		jsClick(whishlistFromMyStuff);
	}

	public void validateWhishlistSecondaryCta() {
		waitFor(2000);
		org.junit.Assert.assertTrue(PlaceHold_Cta.isDisplayed());
		ClickOnWebElement(moreOption_TitleDetailPage);
		Assert.assertTrue(RemoveWishlistSecondaryCta.isDisplayed());
	}

	public void titleSearch(String QAtitle, String UATtitle) {
//		waitFor(2000);
//		javascriptScroll(searchBar);
//		SendKeysOnWebElement(searchBar, title);
//		waitFor(2000);
//		jsClick(searchButton);
//		visibilityWait(titleCard);
		//inVisibilityWait(spinnerLoading);
		
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, QAtitle);
			waitFor(2000);
			jsClick(searchButton);
			visibilityWait(titleCard);
		}else if(System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, UATtitle);
			waitFor(2000);
			jsClick(searchButton);
			visibilityWait(titleCard);
			}
			
		}
		
	

}
