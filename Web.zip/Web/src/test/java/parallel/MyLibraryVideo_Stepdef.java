package parallel;

import java.util.List;
import java.util.Map;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.SearchResults_Vbooks;

import org.junit.Assert;

public class MyLibraryVideo_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());
	SearchResults_Vbooks search= new SearchResults_Vbooks(DriverManager.getDriver());

	/*******************************************************/

	@Given("library should have Video carousel configured in drupal,subscription to Video third party and Video carousel enabled in library admin")
	public void library_should_have_video_carousel_configured_in_drupal_subscription_to_video_third_party_and_video_carousel_enabled_in_library_admin() {
		Logger.log("user should enabled the video configured in drupal,library admin and third party");
	}

	@When("user lands on my library page")
	public void user_lands_on_my_library_page() {
		visibilityWait(video.getLibraryPage());
		Assert.assertTrue(video.getLibraryPage().isDisplayed());
	}

	@Then("user should be able to view Video categories in the carousel format")
	public void user_should_be_able_to_view_video_categories_in_the_carousel_format() {
		Assert.assertTrue(video.view_videoCarouselFormat());
	}

	@Then("user should able to view carousel type as item carousel based on drupal configuration")
	public void user_should_able_to_view_carousel_type_as_item_carousel_based_on_drupal_configuration() {
		Assert.assertTrue(video.getLib_videoCarousel_itemCarouselType().isDisplayed());
	}

	@Then("user should able to view carousel type as card carousel based on drupal configuration")
	public void user_should_able_to_view_carousel_type_as_card_carousel_based_on_drupal_configuration() {
		javascriptScroll(video.getLib_videoCarousel_CardCarouselType());
		Assert.assertTrue(video.getLib_videoCarousel_CardCarouselType().isDisplayed());
		//Assert.assertTrue(video.getLib_vBookCarousel_CardCarouselType().isDisplayed());
	}

	@When("user should be navigate to library page")
	public void user_should_be_navigate_to_library_page() {
		login.preferenceScreen_popup();
		Assert.assertTrue(video.getLibraryPage().isDisplayed());
	}
	@Then("user navigates to library page")
	public void user_navigates_to_library_page() {
		login.preferenceScreen_popup();
		Assert.assertTrue(video.getLibraryPage().isDisplayed());
	}
	@When("user should be navigate to VBooks title tier {int} page")
	public void user_should_be_navigate_to_v_books_title_tier_page(Integer int1) {
		video.clickVBookSeeAll();
		Assert.assertTrue(video.getvBookTier1Page().isDisplayed());
	}

	@Then("user should be able to view list of  carousel")
	public void user_should_be_able_to_view_list_of_carousel() {
		Assert.assertTrue(video.getvBookTier1Carousel().isDisplayed());
	}

	@Then("user should be able to view the carousel type as Item Carousel")
	public void user_should_be_able_to_view_the_carousel_type_as_item_carousel() {
		Assert.assertTrue(video.getLib_videoCarousel_itemCarouselType().isDisplayed());
	}

	@Then("user should be able to view the carousel type as Card Carousel")
	public void user_should_be_able_to_view_the_carousel_type_as_card_carousel() {
		Assert.assertTrue(video.getTier1Carousel().isDisplayed());
		Logger.log("User able to view carousel as Item or Card in Tier page");
	}

	@When("Admin has configured the blocks in Drupal")
	public void admin_has_configured_the_blocks_in_drupal() {
		Logger.log("Admin configured the blocks in Drupal");
	}

	@Then("user should be able to view the action CTA")
	public void user_should_be_able_to_view_the_action_cta() {
		Assert.assertTrue(video.getPrimaryCTA().isDisplayed());
	}

	@Then("user should be able to view video title in the carousel format")
	public void user_should_be_able_to_view_video_title_in_the_carousel_format() {
		Assert.assertTrue(video.view_videoCarouselFormat());
	}

	@Then("user should be able to view videos title card with cover image with primary")
	public void user_should_be_able_to_view_videos_title_card_with_cover_image_with_primary() {
		video.view_coverimgAndprimaryCTA();
	}

	@Then("user should be able to click on videos title card")
	public void user_should_be_able_to_click_on_videos_title_card() {
		video.click_videoTitleCard();
	}

	@Then("user lands on tier {int} details page")
	public void user_lands_on_tier_details_page(Integer int1) {
		Assert.assertTrue(video.getLib_videoCarousel_Nav_Tier3Detailspage().isDisplayed());
	}

	@Then("user should be view primary CTA as checkout")
	public void user_should_be_view_primary_cta_as_checkout() {
		search.clickCheckoutVBookLibPage();
		//Assert.assertTrue(video.getLib_videoCarousel_PrimaryCTAasCheckout().isDisplayed());
	}

	@Then("user click checkout the video and not started watching the video")
	public void user_click_checkout_the_video_and_not_started_watching_the_video() {
		javascriptScroll(video.videoTitleCard.get(1));
		jsClick(video.videoTitleCard.get(1));
		video.click_CheckoutAsprimaryCTA();
	}

	@Then("user able to view primary CTA as Play")
	public void user_able_to_view_primary_cta_as_play() {
		search.verify_PlayCTA();
//		javascriptScroll(video.getLib_videoCarousel_PrimaryCTAasPlay());
//		Assert.assertTrue(video.getLib_videoCarousel_PrimaryCTAasPlay().isDisplayed());
	}

	@Then("user click checkout the video and start watching the video and exist the player")
	public void user_click_checkout_the_video_and_start_watching_the_video_and_exist_the_player() {
		if (video.getLib_videoCarousel_PrimaryCTAasCheckout().isDisplayed()) {
			video.click_CheckoutAsprimaryCTA();
			video.click_PlayCTA();
		} else {
			video.click_PlayCTA();
		}

	}

	@Then("user should able to view the primary CTA as Resume")
	public void user_should_able_to_view_the_primary_cta_as_resume() {
	   if (isElementPresent(video.getLib_videoCarousel_ResumeCTA())) {
		   Logger.log("Primary CTA has Resume");
	}else {
		Logger.log("Primary CTA has play or Checkout");
	}
	}

	@When("user should be able to navigate videos level {int} page")
	public void user_should_be_able_to_navigate_videos_level_page(Integer int1) {
		video.Click_level1page();
	}

	@Then("user should be able to view title Carousels based on the configuration in Drupal")
	public void user_should_be_able_to_view_title_carousels_based_on_the_configuration_in_drupal() {
		javascriptScroll(video.getLib_videoCarousel_tier1_titleCarousel());
		Assert.assertTrue(isElementPresent(video.getLib_videoCarousel_tier1_titleCarousel()));
		Logger.log("User able to see the Title carousels based on the configuration in Drupal");
	}

	@Then("user should be able to view featured carousel as per configured by admin in the Drupal")
	public void user_should_be_able_to_view_featured_carousel_as_per_configured_by_admin_in_the_drupal() {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_Featuredcarousel().isDisplayed());
	}

	@Then("user should be able to view Categories carousel as per configured by admin in the Drupal")
	public void user_should_be_able_to_view_categories_carousel_as_per_configured_by_admin_in_the_drupal() {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_categoryCarousel().isDisplayed());
	}

	@Then("user should be able to view other carousels as per configured by admin in the Drupal")
	public void user_should_be_able_to_view_other_carousels_as_per_configured_by_admin_in_the_drupal() {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_othercarousel().isDisplayed());
		Logger.log("User able to view other carousels as per configured by admin in Drupal");
	}

	@Then("system should display the CTA based on the title status")
	public void system_should_display_the_cta_based_on_the_title_status() {
		Logger.log("Title displayed the Primary CTA based on title availability");
	}

	@Then("user should be able to view checkout as primary action from title detail page")
	public void user_should_be_able_to_view_checkout_as_primary_action_from_title_detail_page() {
		video.clickTitleDetail();
		Assert.assertTrue(video.getTitleDetailPage().isDisplayed());
	}

	@Then("user should be able to view secondary action")
	public void user_should_be_able_to_view_secondary_action() {
		video.view_PlaySecondaryCTA();
		Logger.log("tier3 page should be shown Secondary CTA for the VBooks");
	}

	@Then("user should be able to view play as primary action after checked Out")
	public void user_should_be_able_to_view_play_as_primary_action_after_checked_out() {
		video.playAsprimaryCTA_AfterCheckedout();
	}

	@Then("user should be able to click play to watch the player")
	public void user_should_be_able_to_click_play_to_watch_the_player() {
		video.clickPlayButton();
		video.switchTabAndInspect();
	}

	@Then("user should be able to click resume to watching and exit the player")
	public void user_should_be_able_to_click_resume_to_watching_and_exit_the_player() {
		Logger.log("user able to see the Resume as Primary CTA");
	}

	@When("user should be navigate to video and vbooks title tier {int} page")
	public void user_should_be_navigate_to_video_and_vbooks_title_tier_page(Integer int1) {
		Assert.assertTrue(video.getTier1Carousel().isDisplayed());
	}

	@Then("user should be able to view carousels in Tier {int} page for vBooks based")
	public void user_should_be_able_to_view_carousels_in_tier_page_for_v_books_based(Integer int1) {
		Assert.assertTrue(video.getTier1Carousel().isDisplayed());
	}

	@Then("user should be able to view the carousels configuration by 3rd party drupal admin")
	public void user_should_be_able_to_view_the_carousels_configuration_by_3rd_party_drupal_admin() {
		Logger.log("Carousels are configured in 3rd party Drupal admin");
	}

	@Then("user should be able to view categories in the Tier {int} screen")
	public void user_should_be_able_to_view_categories_in_the_tier_screen(Integer int1) {
		Assert.assertTrue(video.getCategoryTier1().isDisplayed());
	}

	@Then("user should be able to view categories in the carousel format")
	public void user_should_be_able_to_view_categories_in_the_carousel_format() {
		Assert.assertTrue(video.getCategoryCarousel().isDisplayed());
	}

	@Then("user should be able to view categories with name and icon")
	public void user_should_be_able_to_view_categories_with_name_and_icon() {
		Assert.assertTrue(video.getCategoryName().isDisplayed());
		Assert.assertTrue(video.getCategoryIcon().isDisplayed());
	}

	@When("user can navigate to video title tier {int} page")
	public void user_can_navigate_to_video_title_tier_page(Integer int1) {
		video.Click_level1page();
	}

	@Then("user should be able to view categories in the Tier {int} page")
	public void user_should_be_able_to_view_categories_in_the_tier_page(Integer int1) {
		javascriptScroll(video.Lib_videoCarousel_tier1_category);
		Assert.assertTrue(video.Lib_videoCarousel_tier1_category.isDisplayed());
	}

	@Then("user should be able to view the categories in carousel format")
	public void user_should_be_able_to_view_the_categories_in_carousel_format() {
		Assert.assertTrue(video.Lib_videoCarousel_tier1_categoryCarouseformatl.isDisplayed());
	}

	@Then("user should be able to view categories as Mr.Billie and checkers TV")
	public void user_should_be_able_to_view_categories_as_mr_billie_and_checkers_tv() {
		javascriptScroll(video.Lib_videoCarousel_tier1_categoryMrBillie);
		Assert.assertTrue(video.Lib_videoCarousel_tier1_categoryMrBillie.isDisplayed());
		Assert.assertTrue(video.Lib_videoCarousel_tier1_categoryCheckersTV.isDisplayed());
	}

	@Then("user should be able to view the categories icon which is shared by B&T")
	public void user_should_be_able_to_view_the_categories_icon_which_is_shared_by_b_t() {
//		Assert.assertTrue(video.Lib_videoCarousel_tier1_categoryCarouselIcon.isDisplayed());
		Logger.log("User able to view the categories icon which is shared by B&T");
	}

	@Then("user should be able to view carousels in Tier {int} page for video based")
	public void user_should_be_able_to_view_carousels_in_tier_page_for_video_based(Integer int1) {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_titleCarousel().isDisplayed());
	}

	@Then("user should be able to view series as a carousel")
	public void user_should_be_able_to_view_series_as_a_carousel() {
		Assert.assertTrue(video.Lib_videoCarousel_tier1_seriesCarousel.isDisplayed());
	}

	@Then("the carousel should be The Reading Road Trip, The Reading Road Trip: Full STEAM AHEAD and Snoozer's Storytime Adventures")
	public void the_carousel_should_be_the_reading_road_trip_the_reading_road_trip_full_steam_ahead_and_snoozer_s_storytime_adventures() {

	}

	@Then("user should be able to view titles listed in sorting order based on Popularity")
	public void user_should_be_able_to_view_titles_listed_in_sorting_order_based_on_popularity() {

	}

	@Then("user should be able to view titles listed in sorting order based on publication date")
	public void user_should_be_able_to_view_titles_listed_in_sorting_order_based_on_publication_date() {

	}

	@Given("library should have video carousel configured in drupal")
	public void library_should_have_video_carousel_configured_in_drupal() {
		Logger.log("Library have Video Carousel configured in Drupal");
	}

	@Given("library should have subscription to Video collection third party")
	public void library_should_have_subscription_to_video_collection_third_party() {
		Logger.log("Library have Video Collection in third party");
	}

	@Given("library should have video carousel enabled in library admin")
	public void library_should_have_video_carousel_enabled_in_library_admin() {
		Logger.log("Library have Video Carousel enabled in admin");
	}

	@When("user should be navigate to video title tier {int} page")
	public void user_should_be_navigate_to_video_title_tier_page(Integer int1) {
		video.clickVideoSeeAll();
	}

	@Then("user should be able to view list of carousel in tier {int} page")
	public void user_should_be_able_to_view_list_of_carousel_in_tier_page(Integer int1) {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_categoryCarousel().isDisplayed());
	}

	@Then("user should be able to view carousels in the Tier {int} page configured in 3rd party drupal admin")
	public void user_should_be_able_to_view_carousels_in_the_tier_page_configured_in_3rd_party_drupal_admin(
			Integer int1) {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_categoryCarousel().isDisplayed());
	}

	@Then("user should be able to view each carousels with specified logic configured in Drupal admin portal")
	public void user_should_be_able_to_view_each_carousels_with_specified_logic_configured_in_drupal_admin_portal() {
		Logger.log("User able to view each carousels with specified logic configured in Drupal in Admin Portal");
	}

	@Then("user should be able to view categories with name and icons")
	public void user_should_be_able_to_view_categories_with_name_and_icons() {
		Assert.assertTrue(video.getCategoryName().isDisplayed());
		Assert.assertTrue(video.getCategoryIcon().isDisplayed());
	}

	@Then("user should be able to view title available icon with Blue color background icon")
	public void user_should_be_able_to_view_title_available_icon_with_blue_color_background_icon() {
		Logger.log("User verified the UI manually for available title with blue coloured background icon");
	}

	@Then("user should be able to view title unavailable icon with Grey color background icon")
	public void user_should_be_able_to_view_title_unavailable_icon_with_grey_color_background_icon() {
		Logger.log("User verified the UI manually for the unavailable title with grey coloured background icon");
	}

	@Then("user should be able to view title with default image if that particular VBooks doesn't have any title cover")
	public void user_should_be_able_to_view_title_with_default_image_if_that_particular_v_books_doesn_t_have_any_title_cover() {
		Logger.log("User verified the UI manually for the title with default image if that particular books doesn't have any titleS");

	}

	@Then("user should be able to view title with default image if that particular videos doesn't have any title cover")
	public void user_should_be_able_to_view_title_with_default_image_if_that_particular_videos_doesn_t_have_any_title_cover() {
		Logger.log("UI validation");
	}
	@Then("user should be able to view the video title image if image is available for video title")
	public void user_should_be_able_to_view_the_video_title_image_if_image_is_available_for_video_title() {
	   visibilityWait(video.getTitleImageTier3());
	   Assert.assertTrue(video.getTitleImageTier3().isDisplayed());
	}
	
	@Given("user should be able to view video categories in carousel format")
	public void user_should_be_able_to_view_video_categories_in_carousel_format() {
		vbook.formatFilter.isDisplayed();
	}
	@Given("user should view format dropdown with option eBook, eAudio, VBooks & Video")
	public void user_should_view_format_dropdown_with_option_e_book_e_audio_v_books_video() {
		 vbook.View_FormatOptions(); 
	}

	@When("user selects the videos format from the dropdown")
	public void user_selects_the_videos_format_from_the_dropdown() {
	   vbook.select_videos() ;
	}

	@Then("System should filter the titles based on the selected filter option are default as available now")
	public void system_should_filter_the_titles_based_on_the_selected_filter_option_are_default_as_available_now() {
		 Assert.assertTrue(vbook.getAvailability_AvailableNow_dropdwn().isDisplayed());
	}
	
	@Then("user should be able to view Video categories carousel as per API response")
	public void user_should_be_able_to_view_video_categories_carousel_as_per_api_response() {
		Logger.log("Dependent on API response");
	}

	@Then("user should be able to view left and right arrow on the respective sides of carousel")
	public void user_should_be_able_to_view_left_and_right_arrow_on_the_respective_sides_of_carousel() {
		javascriptScroll(video.getVideoCarousel_nextButton());
		Assert.assertTrue(video.getVideoCarousel_nextButton().isDisplayed());
	}

	@Then("user should be able to select left and right arrow to swipe left and right side in the carousel")
	public void user_should_be_able_to_select_left_and_right_arrow_to_swipe_left_and_right_side_in_the_carousel() {
		video.click_VideoCarouselLeftRightButton();
	}

	@Then("user should be able to view specific number of Videos categories in the carousel as per drupal")
	public void user_should_be_able_to_view_specific_number_of_videos_categories_in_the_carousel_as_per_drupal() {
	    Logger.log("Dependent on Drupal config");
	}

	@Then("user should be able click on any video categories")
	public void user_should_be_able_click_on_any_video_categories() {
	    vbook.clickMrBillie();
	}

	@Then("user lands on Tier {int} listing page")
	public void user_lands_on_tier_listing_page(Integer int1) {
	    Assert.assertTrue(vbook.getTier2Page().isDisplayed());
	}
	
	@Then("user should be able click on see all CTA")
	public void user_should_be_able_click_on_see_all_cta() {
	    video.clickVideoSeeAll();
	}

	@Then("user lands on Tier {string} listing page")
	public void user_lands_on_tier_listing_page(String string) {
	    Assert.assertTrue(video.getTier1_Breadcrumb().isDisplayed());
	}
	
	@Then("user should be able to view video widgets with categories in the carousel format")
	public void user_should_be_able_to_view_video_widgets_with_categories_in_the_carousel_format() {
		Assert.assertTrue(video.getCategoryName().isDisplayed());
		Assert.assertTrue(video.getCategoryName2().isDisplayed());
	}
	
	@When("user started watching and exit from checkout Video title")
	public void user_started_watching_and_exit_from_checkout_video_title() {
	    Logger.log("Cannot be automated");
	}
	
	@Then("user should be able to view videos title card with cover image")
	public void user_should_be_able_to_view_videos_title_card_with_cover_image() {
		jsClick(video.Lib_videoCarousel_videotitleCoverimg);
	}
//	
//	@When("user clicks on vbook widget See All CTA")
//	public void user_clicks_on_vbook_widget_see_all_cta() {
//	   video.click_vbookWidgetSeeAll();
//	}
	
	@Then("user clicks on video widget See All CTA after selected format")
	public void user_clicks_on_video_widget_see_all_cta_after_selected_format() {
	   video.click_afterFormatSelected_videoWidgetSeeAll();
	}
	
	@When("user clicks on video widget See All CTA")
	public void user_clicks_on_video_widget_see_all_cta() {
	   video.click_videoWidgetSeeAll();
	}
	
}
