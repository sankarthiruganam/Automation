package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;
import pom.kidszone.TitleAcrossProfile;

public class MyShelf_Stepdef extends CommonAction{

	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	TitleAcrossProfile titleAction = new TitleAcrossProfile(DriverManager.getDriver());

	// Goals& insights

//		@Given("user clicks on minutes read goal")
//	    public void user_clicks_on_minutes_read_goal() throws Throwable {
//			myshelf.click_AvgReadDay();
//	    }
//
//	    @When("user enters invalid input in the goal input field")
//	    public void user_enters_invalid_input_in_the_goal_input_field() throws Throwable {
//	    	myshelf.enter_InvalidGoal();
//	    }
//
//	    @Then("user should be able to view error message {string}")
//	    public void user_should_be_able_to_view_error_message_something(String ErrorMsg) throws Throwable {	    
//	    	Assert.assertEquals(myshelf.getTxt_MinsErrorMsg().getText(), ErrorMsg);
//	    	
//	    }
//	    
//	    @Then("user should be able to view error message for Yearly {string}")
//	    public void user_should_be_able_to_view_error_message_for_Yearly_something(String ErrorMsg) throws Throwable {	    
//	    	Assert.assertEquals(myshelf.getTxt_YearlyErrorMsg().getText(), ErrorMsg);
//	    	
//	    }
//	    
//	    @Then("user should be able to view error message for {string}")
//	    public void user_should_be_able_to_view_error_message_for_something(String ErrorMsg) throws Throwable {	    
//	    	Assert.assertEquals(myshelf.getTxt_DaysErrorMsg().getText(), ErrorMsg);
//	    }
//
//	    @And("user is on minutes read goal popup")
//	    public void user_is_on_minutes_read_goal_popup() throws Throwable {
//	       Assert.assertTrue(myshelf.getPopup_ReadingGoal().isDisplayed());
//	    }
//	    
//	    @Given("user clicks on minutes listened goal")
//	    public void user_clicks_on_minutes_listened_goal() throws Throwable {
//	    	myshelf.click_AvgListenedDay();
//	    }
//
//	    @And("user is on minutes listened goal popup")
//	    public void user_is_on_minutes_listened_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_ListeningGoal().isDisplayed());
//	   
//	    }
//	    
//	    @Given("user clicks on streak goal")
//	    public void user_clicks_on_streak_goal() throws Throwable {
//	    	myshelf.click_CurrentStreak();
//	    }
//
//	    @And("user is on streak goal popup")
//	    public void user_is_on_streak_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_Set_StreakGoal().isDisplayed());
//	    }
//	    
//	    @Given("user clicks on monthly read goal")
//	    public void user_clicks_on_monthly_read_goal() throws Throwable {
//	    	myshelf.click_MonthlyBooksRead();
//	    }
//
//	    @And("user is on monthly read goal popup")
//	    public void user_is_on_monthly_read_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_Set_MonthlyBookGoal().isDisplayed());
//	    }
//	    
//	    @Given("user clicks on monthlylistened goal")
//	    public void user_clicks_on_monthlylistened_goal() throws Throwable {
//	    	hamburgerMenu.click_RightAccordion();
//	    	myshelf.click_MonthlyListenedGoal();
//	    }
//
//	    @And("user is on monthly listened goal popup")
//	    public void user_is_on_monthly_listened_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_ListenedMonth().isDisplayed());
//	    }
//	    
//	    @Given("user clicks on yearly read goal")
//	    public void user_clicks_on_yearlread_goal() throws Throwable {
//	    	myshelf.click_YearlyBooksRead();
//	    }
//
//	    @And("user is on yearly read goal popup")
//	    public void user_is_on_yearly_read_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_Set_YearGoal().isDisplayed());
//	    }
//	    
//	    @Given("user clicks on yearlylistened goal")
//	    public void user_clicks_on_yearlylistened_goal() throws Throwable {
//	    	myshelf.click_YearlyListenedGoal();
//	    }
//
//	    @And("user is on yearly listned goal popup")
//	    public void user_is_on_yearly_listned_goal_popup() throws Throwable {
//	    	 Assert.assertTrue(myshelf.getPopup_ListenedYear().isDisplayed());
//	    }  
//	    
//	    @And("user clicks on the accordion")
//	    public void user_clicks_on_the_accordion() throws Throwable {
//	    	hamburgerMenu.click_accordion();
//	    } 

	/*********************************************************************************************/

	// 131673

	@Then("user should be able to view my shelf as a menu item")
	public void user_should_be_able_to_view_my_shelf_as_a_menu_item() {
		Assert.assertEquals(myshelf.getHamburgerMenu_btn_myshelf().isDisplayed(), true);
	}

	@Then("user should be able to navigate to my shelf screen by clicking my shelf cta")
	public void user_should_be_able_to_navigate_to_my_shelf_screen_by_clicking_my_shelf_cta() {
		hamburgerMenu.click_MyShelf();
	}

	@Then("user should be able to view my shelf screen with adult theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_my_shelf_screen_with_adult_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user able to view my shelf screen with adult theme");
	}

	@Then("user should be able to view home screen for adult profile")
	public void user_should_be_able_to_view_home_screen_for_adult_profile() {
		Assert.assertTrue(holds.getMyShelfTab().isDisplayed());
	}

	@Then("user logout of the application")
	public void user_logout_of_the_application() {
		Logger.log("user logged out from the application");
	}

	@Then("user should be able to view my shelf screen with teen theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_my_shelf_screen_with_teen_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user able to view my shelf screen with teen theme");
	}

	@Then("user should be able to view new updated my shelf home screen for teen profile")
	public void user_should_be_able_to_view_new_updated_my_shelf_home_screen_for_teen_profile() {
		Assert.assertTrue(holds.getMyShelfTab().isDisplayed());
	}

	@Then("user should be able to view my shelf screen with kid theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_my_shelf_screen_with_kid_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user able to view my shelf screen with kid theme");
	}

	@Then("user should be able to view new updated my shelf home screen for kid profile")
	public void user_should_be_able_to_view_new_updated_my_shelf_home_screen_for_kid_profile() {
		Assert.assertTrue(holds.getMyShelfTab().isDisplayed());
	}

//131674
	
	@When("user navigates to user profile preferences in profile newUI")
	public void user_navigates_to_user_profile_preferences_in_profile_new_ui() {
		Logger.log("user navigates to user profile preferences in profile newUI");
	}

	@When("user navigates to user profile preferences in profile")
	public void user_navigates_to_user_profile_preferences_in_profile() {
		//hamburgerMenu.click_ProfileIcon();
		hamburgerMenu.click_ViewSettings();
	}

	@And("user clicks on profile icon")
	public void user_clicks_on_profile_icon() {
		hamburgerMenu.click_ProfileAccount();
	}

	@Then("user should be able to see option to set my shelf as default landing screen")
	public void user_should_be_able_to_see_option_to_set_my_shelf_as_default_landing_screen() {
		hamburgerMenu.click_MyShelf();
	}

	@Then("user should be navigated to my shelf screen on login when my shelf is set as default landing screen")
	public void user_should_be_navigated_to_my_shelf_screen_on_login_when_my_shelf_is_set_as_default_landing_screen() {
		Assert.assertTrue(hamburgerMenu.getMyShelfTab().isDisplayed());
	}

	@Then("user with profile type adult and library subscription axis360 only should not able to view this option in my preferences")
	public void user_with_profile_type_adult_and_library_subscription_axis360_only_should_not_able_to_view_this_option_in_my_preferences() {
		Logger.log("Set my Shelf page is not displayed in this profile subscription page");
	}

	@Then("user with profile type adult and library subscription kidszone and axis360 should not able to view this option in my preferences")
	public void user_with_profile_type_adult_and_library_subscription_kidszone_and_axis360_should_not_able_to_view_this_option_in_my_preferences() {
//		hamburgerMenu.click_MyShelf();
//		Assert.assertTrue(hamburgerMenu.getText_MyShelf_Page().isDisplayed());
		Assert.assertFalse(isElementPresent(hamburgerMenu.getBtn_old_myshelf()));
	}

	@When("myshelf is not set as default landing screen")
	public void myshelf_is_not_set_as_default_landing_screen() {
		myshelf.nav_libraryScreen();
	}

	@Then("user should be navigated to library screen on login")
	public void user_should_be_navigated_to_library_screen_on_login() {

		Assert.assertEquals(myshelf.getNav_libaryScreen().isDisplayed(), true);
	}

//131680

	@When("user clicks on menu")
	public void user_clicks_on_menu() {
		profile.click_MenuOnly();
	}

	@Then("user click on check out title")
	public void user_click_on_check_out_title() {
		// hamburgerMenu.click_Checkouts();
		myshelf.click_checkoutTitle();
	}
	@When("user checked out any title")
	public void user_checked_out_any_title() {
		titleAction.lib_clickCheckout();
	}
	@Then("user should be able to view checked out titles section with adult profile based theme")
	public void user_should_be_able_to_view_checked_out_titles_section_with_adult_profile_based_theme() {
		myshelf.click_checkoutTitle();
	}

	@Then("user should be able to view titles checked out by the user")
	public void user_should_be_able_to_view_titles_checked_out_by_the_user() {
		Assert.assertEquals(myshelf.getAdultprofile_txt_checkoutScreen().isDisplayed(), true);
		Logger.log("user is able to view checkout titles");
		// myshelf.view_checkoutBooksAdultProfile();
	}

	@Then("user should be able to click on the title in focus and navigate to ereader if it is an ebook")
	public void user_should_be_able_to_click_on_the_title_in_focus_and_navigate_to_ereader_if_it_is_an_ebook() {
		myshelf.click_eReaderNavToebook();
	}

	@Then("user should be able to click on the title in focus and navigate to audioplayer if it is an audiobook")
	public void user_should_be_able_to_click_on_the_title_in_focus_and_navigate_to_audioplayer_if_it_is_an_audiobook() {
		Logger.log(" user is click on the title in focus and navigate to ereader if it is an audio player");
	}

	@Then("user should be able to view checked out titles section with teen profile based theme")
	public void user_should_be_able_to_view_checked_out_titles_section_with_teen_profile_based_theme() {
		javascriptScroll(myshelf.nav_currentlyCheckout);
		Assert.assertTrue(myshelf.nav_currentlyCheckout.isDisplayed());
		//myshelf.getAdultprofile_txt_checkoutScreen().isDisplayed();
	}

	@Then("user should be able to view checked out titles section with kid profile based theme")
	public void user_should_be_able_to_view_checked_out_titles_section_with_kid_profile_based_theme() {
		myshelf.getAdultprofile_txt_checkoutScreen().isDisplayed();
	}

	@When("user has not checkout any title")
	public void user_has_not_checkout_any_title() {
		myshelf.notSet_CheckoutTitle();
	}

	@Then("user should be able to view {string} if  no title has been checked out by the user")
	public void user_should_be_able_to_view_if_no_title_has_been_checked_out_by_the_user(String string) {
		Assert.assertEquals(myshelf.getMyshelf_txt_NocheckoutCount().isDisplayed(), true);
	}

//131681

	@Then("user should be able  to view recommendations carousel based on interest survey with adult profile based theme")
	public void user_should_be_able_to_view_recommendations_carousel_based_on_interest_survey_with_adult_profile_based_theme() {
		myshelf.menu_clickRecommendation();
	}

	@Then("user should be able to view the titles recommended based on interest survey and preferred age set in the interest survey and adult profile type")
	public void user_should_be_able_to_view_the_titles_recommended_based_on_interest_survey_and_preferred_age_set_in_the_interest_survey_and_adult_profile_type() {
		Logger.log(
				"user able to view the titles recommended based on interest survey and preferred age set in the interest survey and adult profile type");
	}

	@Then("user should be able to click on view all cta and navigate interest based recommendations titles list screen")
	public void user_should_be_able_to_click_on_view_all_cta_and_navigate_interest_based_recommendations_titles_list_screen() {
		myshelf.click_seeAllinterestSurvey();

	}

	@Then("user should be able  to view recommendations carousel based on interest survey with teen profile based theme")
	public void user_should_be_able_to_view_recommendations_carousel_based_on_interest_survey_with_teen_profile_based_theme() {
		Assert.assertEquals(myshelf.view_basedonyourInterest(), true);
		myshelf.view_interestSurveycarousel();
	}

	@Then("user should be able to view the titles recommended based on interest survey and preferred age set in the interest survey and teen profile type")
	public void user_should_be_able_to_view_the_titles_recommended_based_on_interest_survey_and_preferred_age_set_in_the_interest_survey_and_teen_profile_type() {
		Assert.assertEquals(myshelf.getMyshelf_text_interestSurveyTitle().isDisplayed(), true);
	}

	@Then("user should be able  to view recommendations carousel based on interest survey with kid profile based theme")
	public void user_should_be_able_to_view_recommendations_carousel_based_on_interest_survey_with_kid_profile_based_theme() {
		myshelf.view_interestSurveycarousel();
	}

	@Then("user should be able to view the titles recommended based on interest survey and preferred age set in the interest survey and kid profile type")
	public void user_should_be_able_to_view_the_titles_recommended_based_on_interest_survey_and_preferred_age_set_in_the_interest_survey_and_kid_profile_type() {
		Assert.assertEquals(myshelf.getMyshelf_text_interestSurveyTitle().isDisplayed(), true);
	}
	// 131682

//    @Then("user should be able to view recommended section based on last title read with adult based theme")
//    public void user_should_be_able_to_view_recommended_section_based_on_last_title_read_with_adult_based_theme() {
//       myshelf. menu_clickRecommendation();
//    }

	@Then("user should be able to view recommended section based on last title read with teen based theme")
	public void user_should_be_able_to_view_recommended_section_based_on_last_title_read_with_teen_based_theme() {
		// myshelf.click_NavRecommendationsCTA();
		Assert.assertEquals(myshelf.view_basedonyourInterest(), true);
		myshelf.view_interestSurveycarousel();
	}

	@Then("user should be able to view the titles recommended based on last title read")
	public void user_should_be_able_to_view_the_titles_recommended_based_on_last_title_read() {
		Logger.log("user able to view the titles recommended based on last title read");
	}

	@Then("user should be able to view recommended section based on last title read with kid based theme")
	public void user_should_be_able_to_view_recommended_section_based_on_last_title_read_with_kid_based_theme() {
	     WaitForWebElement(myshelf.txt_basedonYourInterest);
	     Assert.assertTrue(myshelf.txt_basedonYourInterest.isDisplayed());
	}
	// 131683

	@When("recommendations are not enabled in admin portal for the profile")
	public void recommendations_are_not_enabled_in_admin_portal_for_the_profile() {
		Logger.log("recommendations are not enabled in admin portal for the profile");
	}

	@Then("user should not be able to view recommendations for the particular profile type")
	public void user_should_not_be_able_to_view_recommendations_for_the_particular_profile_type() {
		Logger.log("user not able to view recommendations for the particular profile type");
	}

	@When("recommendations are not enabled in admin portal for the library")
	public void recommendations_are_not_enabled_in_admin_portal_for_the_library() {
		Logger.log("recommendations are not enabled in admin portal for the library");
	}

	@Then("user should not be able to view recommendations for the particular library")
	public void user_should_not_be_able_to_view_recommendations_for_the_particular_library() {
		Logger.log("user not able to view recommendations for the particular library");
	}

	// 131684

	@Then("user should be able to view checkout quick navigation cta with title count")
	public void user_should_be_able_to_view_checkout_quick_navigation_cta_with_title_count() {
		myshelf.view_checkoutTitleonMyshelf();
	}

	@Then("user should be able to click on checkout and navigate to Checkout Screen")
	public void user_should_be_able_to_click_on_checkout_and_navigate_to_Checkout_Screen() {
		myshelf.clickCheckoutCta();
	}

	@Then("user should be able to click on checkout and navigate to checkout screen")
	public void user_should_be_able_to_click_on_checkout_and_navigate_to_checkout_screen() {
		myshelf.click_NavcheckoutCTA();
	}

	@Then("user should be able to view holds quick navigation cta with title count")
	public void user_should_be_able_to_view_holds_quick_navigation_cta_with_title_count() {
		myshelf.view_holdsTitleonMyshelf();
	}

	@Then("user should be able to click on holds and navigate to holds screen")
	public void user_should_be_able_to_click_on_holds_and_navigate_to_holds_screen() {
		myshelf.click_NavHoldCTA();
	}

	@Then("user should be able to view wishlist quick navigation cta with title count")
	public void user_should_be_able_to_view_wishlist_quick_navigation_cta_with_title_count() {
		Assert.assertTrue(myshelf.myshelf_btn_wishlistTitle.isDisplayed());
	}

	@Then("user should be able to click on wishlist and navigate to wishlist screen")
	public void user_should_be_able_to_click_on_wishlist_and_navigate_to_wishlist_screen() {
		myshelf.click_NavWishlistCTA();
	}

	@Then("user should be able to view recommendations quick navigation cta with title count")
	public void user_should_be_able_to_view_recommendations_quick_navigation_cta_with_title_count() {
		myshelf.view_RecommendationTitleonMyshelf();
	}

	@Then("user should be able to click on recommendations and navigate to recommendations screen")
	public void user_should_be_able_to_click_on_recommendations_and_navigate_to_recommendations_screen() {
		myshelf.click_NavRecommendationsCTA();
	}

	@Then("user should be able to view assignment quick navigation cta with title count")
	public void user_should_be_able_to_view_assignment_quick_navigation_cta_with_title_count() {
		myshelf.view_AssignmentsTitleonMyshelf();
	}

	@Then("user should be able to click on assignment and navigate to assignment screen")
	public void user_should_be_able_to_click_on_assignment_and_navigate_to_assignment_screen() {
		myshelf.click_NavAssignmentsCTA();
	}

	@Then("user should be able to view history quick navigation cta with title count")
	public void user_should_be_able_to_view_history_quick_navigation_cta_with_title_count() {
		myshelf.view_HistoryTitleonMyshelf();
	}

	@Then("user should be able to click on history and navigate to history screen")
	public void user_should_be_able_to_click_on_history_and_navigate_to_history_screen() {
		myshelf.click_NavHistoryCTA();
	}

	@When("user clicks on insight widget")
	public void user_clicks_on_insight_widget() throws Throwable {
		myshelf.click_AvgReadDay();
	}

	@When("user clicks on minutes read widget")
	public void user_clicks_on_minutes_read_widget() throws Throwable {
		myshelf.click_MinutesRead();
	}

	@Then("user should be able to see popup to update the goal")
	public void user_should_be_able_to_see_popup_to_update_the_goal() throws Throwable {
		Assert.assertTrue(isElementPresent(myshelf.getPopup_ReadingGoal()));
	}

	@And("insights and badges are enabled for the library and profile")
	public void insights_and_badges_are_enabled_for_the_library_and_profile() throws Throwable {
		Assert.assertTrue(isElementPresent(hamburgerMenu.getLogo_ShelfPage()));
	}

	@And("insights and badges are enabled in the user profile preferences")
	public void insights_and_badges_are_enabled_in_the_user_profile_preferences() throws Throwable {
		Logger.log("Insights and badges are already enabled in user profile already");
	}

	@And("goal is set for an insight")
	public void goal_is_set_for_an_insight() throws Throwable {
		hamburgerMenu.click_accordion();
	}

	@And("user should be able to input and set new goal")
	public void user_should_be_able_to_input_and_set_new_goal() throws Throwable {
		myshelf.enter_ValidGoal();
	}

	@And("user should be able to view metrics for the new goal set")
	public void user_should_be_able_to_view_metrics_for_the_new_goal_set() throws Throwable {
		Logger.log("View metrics currently not set in new goal set");
	}

	@And("application should display the confirmation toast message for successful goal set")
	public void application_should_display_the_confirmation_toast_message_for_successful_goal_set() throws Throwable {
		Logger.log("Goal set toast message is displayed");
	}

	@And("user should be able to view error message for invalid input")
	public void user_should_be_able_to_view_error_message_for_invalid_input() throws Throwable {
		Logger.log("Error message validated in previous features");
	}

	@And("user should be able to click on the remove goal cta to remove the goal set and view insight metrics on the widget")
	public void user_should_be_able_to_click_on_the_remove_goal_cta_to_remove_the_goal_set_and_view_insight_metrics_on_the_widget()
			throws Throwable {
		myshelf.click_AvgReadDay();
		myshelf.enter_RemoveGoal();
	}

	@And("application should display the confirmation toast message for successful removal of goal")
	public void application_should_display_the_confirmation_toast_message_for_successful_removal_of_goal()
			throws Throwable {
		Logger.log("Remove Goal toast message is verified");
	}

	@And("user clicks on the accordion")
	public void user_clicks_on_the_accordion() throws Throwable {
		hamburgerMenu.click_accordion();
	}

	@Given("user clicks on minutes read goal")
	public void user_clicks_on_minutes_read_goal() throws Throwable {
		myshelf.click_AvgReadDay();
	}

	@When("user enters invalid input in the goal input field")
	public void user_enters_invalid_input_in_the_goal_input_field() throws Throwable {
		myshelf.enter_InvalidGoal();
	}

	@Then("user should be able to view error message {string}")
	public void user_should_be_able_to_view_error_message_something(String errorMsg) throws Throwable {
		System.out.println(errorMsg);
		System.out.println(myshelf.getTxt_MinsErrorMsg().getText());
		Assert.assertEquals(myshelf.getTxt_MinsErrorMsg().getText(), errorMsg);

	}

	@Then("user should be able to view error message for {string}")
	public void user_should_be_able_to_view_error_message_for_something(String errorMsg1) throws Throwable {
		Assert.assertEquals(myshelf.getTxt_DaysErrorMsg().getText(), errorMsg1);
	}

	@Then("user should be able to view error message for yearly {string}")
	public void user_should_be_able_to_view_error_message_for_yearly_something(String errorMsg2) throws Throwable {
		Assert.assertEquals(myshelf.getTxt_YearlyErrorMsg().getText(), errorMsg2);
	}

	@And("user is on minutes read goal popup")
	public void user_is_on_minutes_read_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_ReadingGoal().isDisplayed());
	}

	@Given("user clicks on minutes listened goal")
	public void user_clicks_on_minutes_listened_goal() throws Throwable {
		myshelf.click_AvgListenedDay();
	}

	@And("user is on minutes listened goal popup")
	public void user_is_on_minutes_listened_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_ListeningGoal().isDisplayed());
	}

	@Given("user clicks on streak goal")
	public void user_clicks_on_streak_goal() throws Throwable {
		myshelf.click_CurrentStreak();
	}

	@And("user is on streak goal popup")
	public void user_is_on_streak_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_Set_StreakGoal().isDisplayed());
	}

	@Given("user clicks on monthly read goal")
	public void user_clicks_on_monthly_read_goal() throws Throwable {
		myshelf.click_MonthlyReadGoal();
	}

	@And("user is on monthly read goal popup")
	public void user_is_on_monthly_read_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_Set_MonthlyBookGoal().isDisplayed());
	}

	@Given("user clicks on monthlylistened goal")
	public void user_clicks_on_monthlylistened_goal() throws Throwable {
		hamburgerMenu.click_RightAccordion();
		myshelf.click_MonthlyListenedGoal();
	}

	@And("user is on monthly listened goal popup")
	public void user_is_on_monthly_listened_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_ListenedMonth().isDisplayed());
	}

	@Given("user clicks on yearly read goal")
	public void user_clicks_on_yearly_read_goal() throws Throwable {
		myshelf.click_YearlyRead();
	}

	@And("user is on yearly read goal popup")
	public void user_is_on_yearly_read_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_Set_YearGoal().isDisplayed());
	}

	@Given("user clicks on yearlylistened goal")
	public void user_clicks_on_yearlylistened_goal() throws Throwable {
		myshelf.click_YearlyListenedGoal();
	}

	@And("user is on yearly listned goal popup")
	public void user_is_on_yearly_listned_goal_popup() throws Throwable {
		Assert.assertTrue(myshelf.getPopup_ListenedYear().isDisplayed());
	}

//131416

	@Then("user should be able to navigate to my shelf screen by clicking on my shelf cta")
	public void user_should_be_able_to_navigate_to_my_shelf_screen_by_clicking_on_my_shelf_cta() {
		myshelf.click_old_myShelfcta();
	}

	/*
	 * //139196
	 * 
	 * @Given("user click on {string} option from Hamburger menu") public void
	 * user_click_on_option_from_hamburger_menu(String string) {
	 * hamburgerMenu.click_HamburgerMenu(); //profile.click_MenuOnly();
	 * hamburgerMenu.click_MyShelf(); }
	 * 
	 * @Given("user navigates to {string} page.") public void
	 * user_navigates_to_page(String string) {
	 * 
	 * Assert.assertTrue(myshelf.myshelfNavigationPage()); }
	 * 
	 * @Given("No title is on hold") public void no_title_is_on_hold() {
	 * Assert.assertTrue(myshelf.myshelfNavigationPage()); }
	 * 
	 * @Given("user click on {string}") public void user_click_on(String string) {
	 * myshelf.holdsButton();
	 * 
	 * }
	 * 
	 * @When("user lands on Holds screen") public void user_lands_on_holds_screen()
	 * { Assert.assertTrue(myshelf.holdsScreen()); }
	 * 
	 * @Then("user should be able to view no title on hold screen {string}") public
	 * void user_should_be_able_to_view_no_title_on_hold_screen(String string) {
	 * 
	 * Assert.assertTrue(myshelf.holdsScreen()); }
	 * 
	 * @Then("user should be able to navigate to my shelf screen by clicking on my shelf cta"
	 * ) public void
	 * user_should_be_able_to_navigate_to_my_shelf_screen_by_clicking_on_my_shelf_cta
	 * () { hamburgerMenu.OldMyShelf(); }
	 */

}
