package parallel;

import java.util.List;

import java.util.Map;
import org.junit.Assert;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Myprog;
import pom.kidszone.Myprograms;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Myprog_Stepdef extends CommonAction{

	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	Myprograms myprogram = new Myprograms(DriverManager.getDriver());
	Myprog prog = new Myprog(DriverManager.getDriver());
	
	
	@When("user lands on programs tab and select active programs")
	public void user_lands_on_programs_tab_and_select_active_programs() {
		myprogram.select_activeProg();
	}

	@When("user is on active program details screen")
	public void user_is_on_active_program_details_screen() {
		Assert.assertTrue(isElementPresent(myprogram.progDetailScreen_readinglist));
	}

	@When("user taps on leave program cta")
	public void user_taps_on_leave_program_cta() {
		//myprogram.view_leaveProgram();
		myprogram.click_leaveProg();
	}

	@Then("system should be prompted with leave program confirmation message")
	public void system_should_be_prompted_with_leave_program_confirmation_message() {
		Assert.assertTrue(isElementPresent(prog.getLeaveprog_confirmationMsg()));
		Assert.assertTrue(isElementPresent(prog.getLeaveprog_cancelCTA()));
		Assert.assertTrue(isElementPresent(prog.getLeaveprog_OkCTA()));
	}
	@Then("user should tap {string} cta")
	public void user_should_tap_cta(String string) {
	  prog.click_yesCTA();
	}

	@Then("user should be able to receive leave success toast message and navigate to my programs screen")
	public void user_should_be_able_to_receive_leave_success_toast_message_and_navigate_to_my_programs_screen() {
	   Assert.assertTrue(prog.getSuccess_toastmsg().isDisplayed());
	}
	
	@Then("user should tap on {string} cta")
	public void user_should_tap_on_cta(String string) {
	    prog.click_cancelCTA();
	}
	
	@Then("user should stay on program overview screen by clicking cancel")
	public void user_should_stay_on_program_overview_screen_by_clicking_cancel() {
	    Logger.log("user stayed on program overview screen by clicking cancel");
	}
	
	//140542
	
	@When("user lands on program details screen for X out of Y upcoming program that user has enrolled in")
	public void user_lands_on_program_details_screen_for_x_out_of_y_upcoming_program_that_user_has_enrolled_in() {
		myprogram.click_openProgram();
		prog.click_upcomingXYprog();
	}
	@Then("user should be able to click on xy title and navigate to title details screen")
	public void user_should_be_able_to_click_on_xy_title_and_navigate_to_title_details_screen() {
	   prog.click_xytitle();
	}

	@Then("user should be able to view the action cta for the title on program details screen only once program has started")
	public void user_should_be_able_to_view_the_action_cta_for_the_title_on_program_details_screen_only_once_program_has_started() {
	   prog.validate_title_details_screen();
	}
	
	//140543
	
	@When("user clicks on books in order program and lands in program details screen of that program for that user has not enrolled in")
	public void user_clicks_on_books_in_order_program_and_lands_in_program_details_screen_of_that_program_for_that_user_has_not_enrolled_in() {
	  Logger.log("user clicks on books in order program and lands in program details screen of that program for that user has not enrolled in");
	}
	
	//140547
	
	@When("user should be able to view the CTA enabled for the first title at start of the program")
    public void user_should_be_able_to_view_the_cta_enabled_for_the_first_title_at_start_of_the_program() {
        prog.ctaEnabledOrDisabled();
    }

    @When("user should be able to view the CTA disabled for the titles next in order")
    public void user_should_be_able_to_view_the_cta_disabled_for_the_titles_next_in_order() {
        prog.ctaEnabledOrDisabled();
    }
    
    @When("user should be able to view reading list titles as a grid view")
    public void user_should_be_able_to_view_reading_list_titles_as_a_grid_view() {
        Logger.log("user able to view reading list titles as a grid view");
    }
    
    @Then("user should be able to view title cover image for the titles with title format icon")
    public void user_should_be_able_to_view_title_cover_image_for_the_titles_with_title_format_icon() {
       prog.view_coverimgAndformatIcon();
    }
    
    //140536
    
    @When("adult user click on programs to navigated to programs screen")
    public void adult_user_click_on_programs_to_navigated_to_programs_screen() {
    	prog.click_programsAdult();
    }

    @When("adult user select open programs tab and select upcoming program")
    public void adult_user_select_open_programs_tab_and_select_upcoming_program() {
       prog.select_programAdult();
    }

    @Then("adult user should be able to view Program Name, program description if available and program start date and program End date and program Type")
    public void adult_user_should_be_able_to_view_program_name_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
    	Assert.assertEquals(isElementPresent(prog.magicLib_progName), true);
    }

    @Then("adult user should be able to view number of participants for the program")
    public void adult_user_should_be_able_to_view_number_of_participants_for_the_program() {
    	Assert.assertEquals(isElementPresent(prog.magicLib_noOFparticipants), true);
    }

    @Then("adult user should be able to view join program cta")
    public void adult_user_should_be_able_to_view_join_program_cta() {
    	Assert.assertEquals(isElementPresent(prog.magicLib_joinPrg), true);
    }
}


