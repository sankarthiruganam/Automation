package parallel;

import java.util.List;
import java.util.Map;
import org.junit.Assert;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Myprog;
import pom.kidszone.Myprograms;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Myprograms_Stepdef extends CommonAction {

	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	Myprograms myprogram = new Myprograms(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	Myprog prog = new Myprog(DriverManager.getDriver());

//131685

	@Then("user should be able to view program carousels")
	public void user_should_be_able_to_view_program_carousels() {
		myprogram.view_myprogramsonMyshelfscreen();
		// myprogram.click_programs();
		// Assert.assertTrue(myprogram.getView_programcarousel().isDisplayed());
	}

	@Then("user should be able to view list of programs user has joined and are active")
	public void user_should_be_able_to_view_list_of_programs_user_has_joined_and_are_active() {
		myprogram.view_listofProgramsActive();
	}

	@Then("user should be able to view {int} number of programs in the carousel")
	public void user_should_be_able_to_view_number_of_programs_in_the_carousel(Integer int1) {
		myprogram.view_tenNumberofProgram();
	}

	@Then("user should be able to click on view all and navigate to my programs screen")
	public void user_should_be_able_to_click_on_view_all_and_navigate_to_my_programs_screen() {
		// myprogram.click_viewAllcta();
	}

	@Then("user should see the programs in carousel sorted in order with programs with latest end date first")
	public void user_should_see_the_programs_in_carousel_sorted_in_order_with_programs_with_latest_end_date_first() {
		Logger.log(
				"User able to see the programs in carousel sorted in order with programs with latest end date first");
	}

	// 125297 -Myprofile

	@When("user clicks on view settings on my profile popup")
	public void user_clicks_on_view_settings_on_my_profile_popup() {
		myprogram.click_myProfilePopup();
		myprogram.click_viewSetting();
	}

	@When("user should be able to navigate to my profile screen")
	public void user_should_be_able_to_navigate_to_my_profile_screen() {
		myprogram.click_myProfilePopup();
		myprogram.click_viewSetting();
		// Assert.assertTrue(myprogram.getProfileSetting_displayName().isDisplayed());
	}

	@Then("kid user should be able to enable display checkout history")
	public void kid_user_should_be_able_to_enable_display_checkout_history() {
		myprogram.enable_displayCheckoutHistory();
	}

	@Then("kid user should be able to disable display checkout history")
	public void kid_user_should_be_able_to_disable_display_checkout_history() {
		myprogram.disable_displaycheckoutHistory();
	}

	@Then("user should be able to view available profile information pre populated")
	public void user_should_be_able_to_view_available_profile_information_pre_populated() {
		Assert.assertEquals(myprogram.getProfile_information_prepopulated().isDisplayed(), true);
		Logger.log("user able to view available profile information");
	}

	@When("user click edit profile")
	public void user_click_edit_profile() {
		profile.getManageProf_edit_button().click();
		profile.getManageProf_pencilIcon_editProfile().get(2).click();
	}

	@Then("user should view profile type and security questions and answers")
	public void user_should_view_profile_type_and_security_questions_and_answers() {
		myprogram.view_secutityQuesAndansw();
	}

	@Then("user should be able to view profile avatar and display name")
	public void user_should_be_able_to_view_profile_avatar_and_display_name() {
		WaitForWebElement(myprogram.getProfileSetting_avatar());
		Assert.assertTrue(myprogram.getProfileSetting_avatar().isDisplayed());
	}

	@And("user should be able to view automatically checkout titles on hold")
	public void user_should_be_able_to_view_automatically_checkout_titles_on_hold() {
		Assert.assertEquals(myprogram.getProfileSetting_AutocheckoutHolds().isDisplayed(), true);
	}

	@Then("user should be able to view display checkout history")
	public void user_should_be_able_to_view_display_checkout_history() {
		Assert.assertTrue(myprogram.getProfileSetting_checkoutHistory().isDisplayed());
	}

	@Then("user should be able to view display insights and badges fields")
	public void user_should_be_able_to_view_display_insights_and_badges_fields() {
		Assert.assertTrue(myprogram.getProfileSetting_insightsAndBadges().isDisplayed());
	}

	@Then("user should be able to view interest survey cta and click on cta to navigate to interest survey screen")
	public void user_should_be_able_to_view_interest_survey_cta_and_click_on_cta_to_navigate_to_interest_survey_screen() {
		myprogram.click_viewMycheckouts();

	}

	// 125299

	@When("teen user clicks on view settings on my profile popup")
	public void teen_user_clicks_on_view_settings_on_my_profile_popup() {
		myprogram.click_avatar();
		// myprogram.click_myProfilePopup();
	}

	@Then("user clicks on view settings on my profile popup newUI")
	public void user_clicks_on_view_settings_on_my_profile_popup_new_ui() {
		Logger.log("User clicks on view settings on my profile popup newUI");
	}

	// 125299

//	@Then("user is on profile screen")
//	public void user_is_on_profile_screen() {
//		myprogram.click_avatar();
//	}

	@Then("user should be able to enable automatically checkout titles on hold")
	public void user_should_be_able_to_enable_automatically_checkout_titles_on_hold() {
		myprogram.click_viewSetting();

	}

	@Then("user should be able to enable display checkout history")
	public void user_should_be_able_to_enable_display_checkout_history() {
		// myprogram.click_viewSetting();
		myprogram.enable_displayCheckoutHistory();
	}

	@Then("user should be able to enable display insights and badges fields")
	public void user_should_be_able_to_enable_display_insights_and_badges_fields() {
		myprogram.enable_insightAndBadges();
	}

	@Then("user should be able to click save cta to save updated changes")
	public void user_should_be_able_to_click_save_cta_to_save_updated_changes() {
		profile.editProfile_save();
		// myprogram.click_updateSetting();
	}

	@Then("user should not be able to edit profile type if user has kids or teen profile mapped")
	public void user_should_not_be_able_to_edit_profile_type_if_user_has_kids_or_teen_profile_mapped() {
		Logger.log("user is not be able to edit profile type if user has kids or teen profile mapped");
		// Assert.assertTrue(profile.editProfile_profiletype.isDisplayed());

	}

	@Then("user should be able to disable display checkout history")
	public void user_should_be_able_to_disable_display_checkout_history() {
//		myprogram.click_viewSetting();
		myprogram.disable_displaycheckoutHistory();
	}

	@Then("user should be able to disable display insights and badges fields")
	public void user_should_be_able_to_disable_display_insights_and_badges_fields() {
		myprogram.disable_insightBadges();
	}

	// 140521

	@Given("programs are enabled for the library and user profile type")
	public void programs_are_enabled_for_the_library_and_user_profile_type() {
		Logger.log("programs are enabled for the library and user profile type ");
	}

	@Then("user click on programs to navigated to programs screen")
	public void user_click_on_programs_to_navigated_to_programs_screen() {
		myprogram.click_programinHambergermenu();
	}

	@Then("user should land on My programs tab in programs screen by default")
	public void user_should_land_on_my_programs_tab_in_programs_screen_by_default() {
		myprogram.verify_myprogramtab_default();
	}

	@Then("user should be able to view My programs and open programs tabs")
	public void user_should_be_able_to_view_my_programs_and_open_programs_tabs() {
		Assert.assertEquals(myprogram.view_programs(), true);
	}

	@Then("user should be able to view My programs and open programs screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_my_programs_and_open_programs_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log(
				"user able to view my program and open program theme based on profile types and library subscription ");
	}

	// 140520

	@When("user lands on my program screen")
	public void user_lands_on_my_program_screen() {
		Assert.assertEquals(myprogram.view_programs(), true);
	}

	@When("user click on open program")
	public void user_click_on_open_program() {
		myprogram.click_openProgram();
	}

	@Then("user should not be able to view program card for the upcoming program enrolled in with theme rendered based on user profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_upcoming_program_enrolled_in_with_theme_rendered_based_on_user_profile_and_library_subscription() {
		Logger.log(
				"user able to view program card for the upcoming program enrolled in with theme rendered based on user profile ");
		// myprogram.view_upcomingProgram();
	}

	@Then("user should be able to view {string},{string} if available, start date and end date for the program")
	public void user_should_be_able_to_view_if_available_start_date_and_end_date_for_the_program(String string,
			String string2) {

		myprogram.view_programTitleAndDiscription();
		myprogram.view_programDiscriptionAndDate();
	}

	@Then("user should be able to view cover image of the titles stacked for the titles in the program")
	public void user_should_be_able_to_view_cover_image_of_the_titles_stacked_for_the_titles_in_the_program() {
		myprogram.view_progCoverimg();
	}

	@Then("user should be able to view number of participants for the program")
	public void user_should_be_able_to_view_number_of_participants_for_the_program() {
		myprogram.view_numberOfparticipants();
	}

	@Then("user should be able to click on program and navigate to program details screen")
	public void user_should_be_able_to_click_on_program_and_navigate_to_program_details_screen() {
		myprogram.click_ongoingProg();
		// myprogram.click_programNavtoProgDetailsScreen();
	}

	@Given("user has upcoming program enrolled in")
	public void user_has_upcoming_program_enrolled_in() {
		Logger.log("user has upcoming program enrolled in");
	}

	@When("user has ongoing program enrolled in")
	public void user_has_ongoing_program_enrolled_in() {
		myprogram.getTxt_activeProgram().isDisplayed();
		Logger.log("user has ongoing program enrolled in");
	}

	@Then("user should not be able to view program card for the ongoing program enrolled in with theme rendered based on user profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_ongoing_program_enrolled_in_with_theme_rendered_based_on_user_profile_and_library_subscription() {
		Logger.log(
				"user is not able to view program card for the ongoing program enrolled in with theme rendered based on user profile and library subscription");
	}

	@Then("user should be able to view overall progress of the program as a progress bar")
	public void user_should_be_able_to_view_overall_progress_of_the_program_as_a_progress_bar() {
		Assert.assertTrue(myprogram.view_overAllprogressPercentage());
		Logger.log("user able to view overall progress of the program as a progress bar");
	}

	@Then("user should be able to view top banner {string} for the program ongoing program")
	public void user_should_be_able_to_view_top_banner_for_the_program_ongoing_program(String string) {
		Assert.assertTrue(myprogram.view_programStarted());
		Logger.log("user able to view top banner ");
	}

	@Then("user should be able to view top banner {string} for the program that is ending in {int} hours")
	public void user_should_be_able_to_view_top_banner_for_the_program_that_is_ending_in_hours(String string,
			Integer int1) {
		Logger.log("user able to view top banner Ends today for the program that is ending in 24 hours");
	}

	// 140512

	@Given("user has no closed program")
	public void user_has_no_closed_program() {
		Logger.log("user has no closed program ");
	}

	@Then("user should not be able to view closed programs section")
	public void user_should_not_be_able_to_view_closed_programs_section() {
		Assert.assertEquals(isElementPresent(myprogram.myprogram_txt_closedProgram), false);
		// Assert.assertFalse(myprogram.not_viewClosedProgram());
	}

	// 140513

	@Then("user should not be able to view program card for the closed program enrolled in with theme rendered based on user profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_closed_program_enrolled_in_with_theme_rendered_based_on_user_profile_and_library_subscription() {
		Logger.log("user is not able to view program card for the closed program enrolled in with theme ");
	}

	@Then("user should be able to view delete CTA on closed program cards")
	public void user_should_be_able_to_view_delete_cta_on_closed_program_cards() {
		Assert.assertTrue(myprogram.view_removeCTA());
		Logger.log("user is able to view delete CTA on closed program cards");
	}

	@When("user have closed program")
	public void user_have_closed_program() {
		myprogram.view_closedProgram();
		// myprogram.view_closedProgram();
		Logger.log("user have closed program");
	}

	@And("user should be able to view 'Program Name','Program Description' if available, start date and end date for the closed program")
	public void user_should_be_able_to_view_program_nameprogram_description_if_available_start_date_and_end_date_for_the_closed_program()
			throws Throwable {
		// Assert.assertTrue(myprogram.getPopup_closedProgram_txt().isDisplayed());
		javascriptScroll(myprogram.closedProgram_startDate);
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_startDate));
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_EndDate));
	}

	@And("user should be able to view number of participants for the closed program")
	public void user_should_be_able_to_view_number_of_participants_for_the_closed_program() throws Throwable {
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_numberOfparticipants));
	}

	@And("user should be able to view cover image of the titles stacked for the titles in the closed program")
	public void user_should_be_able_to_view_cover_image_of_the_titles_stacked_for_the_titles_in_the_closed_program()
			throws Throwable {
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_coverimg));
	}

	@And("user should be able to view the program progress as a progress bar at the time of closure of the closed program")
	public void user_should_be_able_to_view_the_program_progress_as_a_progress_bar_at_the_time_of_closure_of_the_closed_program()
			throws Throwable {
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_programprogress));
	}

	@And("user should be able to view top banner 'not completed' for the closed program with progress less than 100 percentage")
	public void user_should_be_able_to_view_top_banner_not_completed_for_the_closed_program_with_progress_less_than_100_percentage()
			throws Throwable {
		Assert.assertTrue(isElementPresent(myprogram.closedProgram_progressbar));
	}

//    @And("user should be able to view top banner {string} for the closed program with progress less than 100%")
//    public void user_should_be_able_to_view_top_banner_something_for_the_closed_program_with_progress_less_than_100(String strArg1) throws Throwable {
//    	
//    }

	@And("user should be able to click on closed program and navigate to program details screen")
	public void user_should_be_able_to_click_on_closed_program_and_navigate_to_program_details_screen()
			throws Throwable {
		myprogram.click_closedProgram();
	}

	// 140514

	@Given("programs are enabled for the library")
	public void programs_are_enabled_for_the_library() {
		Logger.log("programs are enabled for the library");
	}

	@When("user clicks on delete CTA")
	public void user_clicks_on_delete_cta() {
		myprogram.view_closedProgram();
		myprogram.click_deleteCTA();
	}

	@Then("system should remove user from the closed program")
	public void system_should_remove_user_from_the_closed_program() {
		Assert.assertTrue(isElementPresent(myprogram.removeProg_popup));
		Logger.log("user should be able to remove the closed program");
		// Assert.assertFalse(myprogram.getMyprogram_program_closedProgram().isDisplayed());
	}

	@Then("user should to view the program in the closed program section")
	public void user_should_to_view_the_program_in_the_closed_program_section() {
		// Assert.assertTrue(myprogram.getMyprogram_program_closedProgram().isDisplayed());
	}

	// 140519

	@When("user has no program to be displayed on my programs screen")
	public void user_has_no_program_to_be_displayed_on_my_programs_screen() {
		Assert.assertFalse(myprogram.not_viewProgramonMyprogram());
	}

	@Then("user should be able to view screen for no program to be displayed for the user in the my programs tab")
	public void user_should_be_able_to_view_screen_for_no_program_to_be_displayed_for_the_user_in_the_my_programs_tab() {
		Assert.assertTrue(myprogram.getMyprogram_noprograms().isDisplayed());
	}

	// 140517

	@When("user has not enrolled in any active program")
	public void user_has_not_enrolled_in_any_active_program() {
		Logger.log("user has not enrolled in any active program");
	}

	@Then("user should not be able to view active programs section")
	public void user_should_not_be_able_to_view_active_programs_section() {
		Assert.assertFalse(myprogram.not_viewProgramonMyprogram());
	}

	// 131518

	@Then("user should be able to view overall progress of the program on the program card")
	public void user_should_be_able_to_view_overall_progress_of_the_program_on_the_program_card() {
		Assert.assertTrue(myprogram.getOverAllprogress().isDisplayed());
	}

	@Then("user should be able to view progress calculated based on completion of the titles in the reading program")
	public void user_should_be_able_to_view_progress_calculated_based_on_completion_of_the_titles_in_the_reading_program() {
		Assert.assertTrue(myprogram.view_overAllprogressPercentage());
	}

	@Then("application should not update the program progress once program has closed")
	public void application_should_not_update_the_program_progress_once_program_has_closed() {
		// Assert.assertFalse(myprogram.getOverAllprogress().isDisplayed());
	}

	// 140515

	@Then("user should be able to view my programs screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_my_programs_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log(
				"user is able to view my programs screen with theme rendered based on library subscription and user profile type");

	}

	@Then("user should be able to view list of programs only that user has participated in or participating in")
	public void user_should_be_able_to_view_list_of_programs_only_that_user_has_participated_in_or_participating_in() {
		myprogram.view_listOfprogramsparticipated();
	}

	@Then("user should be able to view active ongoing and upcoming programs that user is participating in listed under active programs section")
	public void user_should_be_able_to_view_active_ongoing_and_upcoming_programs_that_user_is_participating_in_listed_under_active_programs_section() {
		// Assert.assertTrue(isElementPresent(myprogram.myprogram_program_ActiveprogramSection));
		Logger.log("user is able to view active program section");

	}

	@Then("user should be able to view closed programs that user has participated in listed under closed programs section")
	public void user_should_be_able_to_view_closed_programs_that_user_has_participated_in_listed_under_closed_programs_section() {
		// myprogram.navigateDown_scroll();
		// Assert.assertTrue(isElementPresent(myprogram.myprogram_program_closedProgramSection));
		myprogram.verify_programSection();

	}

	@Then("user should be able to view each program displayed as a card with card theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_each_program_displayed_as_a_card_with_card_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user is able to view each program displayed as a card with card theme");
	}

	@Then("user should not be able to view programs that user is participating or participated in but have been un-published")
	public void user_should_not_be_able_to_view_programs_that_user_is_participating_or_participated_in_but_have_been_un_published() {
		Logger.log(
				"user is not able to view programs that user is participating or participated in but have been un-published");
	}

	@Then("user should not be able to view the programs that user left")
	public void user_should_not_be_able_to_view_the_programs_that_user_left() {
		Logger.log("user is not able to view the programs that user left");
	}

	@Then("user should be able to view programs sorted with latest end date first within each section")
	public void user_should_be_able_to_view_programs_sorted_with_latest_end_date_first_within_each_section() {
		Logger.log("user is able to view programs sorted with latest ");
	}

	@Then("application should load {int} programs at a time and lazy load as user scrolls down")
	public void application_should_load_programs_at_a_time_and_lazy_load_as_user_scrolls_down(Integer int1) {
		Logger.log("application should load programs at a time and lazy load as user scrolls down");
		myprogram.click_closedProgram();
	}

	@Then("user should be able to click on programs card and navigate to program details screen")
	public void user_should_be_able_to_click_on_programs_card_and_navigate_to_program_details_screen() {
		myprogram.click_programNavtoProgDetailsScreen();
	}

//131413

	@When("user select adult profile")
	public void user_select_adult_profile() {
		profile.editAdultProfile();
	}

	// 131414

	@When("user navigates to interest survey screen and popup")
	public void user_navigates_to_interest_survey_screen_and_popup() {
		Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
	}

	@Then("user should be able to view interest survey screen with kid theme and topics when profile type is kid and library has kids zone subscription")
	public void user_should_be_able_to_view_interest_survey_screen_with_kid_theme_and_topics_when_profile_type_is_kid_and_library_has_kids_zone_subscription() {
		Logger.log("user should be able to view interest survey screen with kid theme");
	}

	@Then("user should be able to view interest survey screen with teen theme and topics when profile type is teen and library has kids zone subscription")
	public void user_should_be_able_to_view_interest_survey_screen_with_teen_theme_and_topics_when_profile_type_is_teen_and_library_has_kids_zone_subscription() {
		Logger.log("user is able to view interest survey screen with teen theme");
	}

	@Then("user should be able to view interest survey screen with adult theme  and topics when profile type is adult and library has kidszone and axis {int} subscription")
	public void user_should_be_able_to_view_interest_survey_screen_with_adult_theme_and_topics_when_profile_type_is_adult_and_library_has_kidszone_and_axis_subscription(
			Integer int1) {
		Logger.log("user is able to view interest survey screen with adult theme");
	}

	// 131415

	@Given("user clicks on my profile icon")
	public void user_clicks_on_my_profile_icon() {
		myprogram.click_myProfilePopup();
	}

	@Given("recommendations are enabled in bakerandtaylor admin for the library")
	public void recommendations_are_enabled_in_bakerandtaylor_admin_for_the_library() {
		Logger.log("recommendations are enabled in bakerandtaylor admin for the library");
	}

	@Then("user should be able to view interest topics for adults")
	public void user_should_be_able_to_view_interest_topics_for_adults() {
		Assert.assertTrue(myprogram.view_interestTopics_Adult());
	}

	@Then("user should be able to view preferred age level options kid and teen and adult")
	public void user_should_be_able_to_view_preferred_age_level_options_kid_and_teen_and_adult() {
		Assert.assertTrue(myprogram.preferedAgeAndProfileTypeAdultaxis360Only());
	}

	// 131416

	@Then("user should be able to view interest topics for teen")
	public void user_should_be_able_to_view_interest_topics_for_teen() {
		Assert.assertTrue(myprogram.interestTopics_kidAndteen());
	}

	@Then("user should be able to view preferred age level options kid and teen")
	public void user_should_be_able_to_view_preferred_age_level_options_kid_and_teen() {
		Assert.assertTrue(myprogram.preferedAgeAndProfileTypeAdult());
	}

	@Then("user should be able to select all the age level options and save")
	public void user_should_be_able_to_select_all_the_age_level_options_and_save() {
		myprogram.ageLevelOptions();

	}

	@Then("user should select the topics and select the teen option only and tap on save button")
	public void user_should_select_the_topics_and_select_the_teen_option_only_and_tap_on_save_button() {
		myprogram.teenProfileOnly();
	}

	@Then("user should be able to do swipe left to right and right to left on the carousel")
	public void user_should_be_able_to_do_swipe_left_to_right_and_right_to_left_on_the_carousel() {
		myprogram.swipeLeftRight();
	}

	@When("user should select the topics and select the kid option only and tap on save button")
	public void user_should_select_the_topics_and_select_the_kid_option_only_and_tap_on_save_button() {
		myprogram.kidTopicsInAdult();
	}

//131417

	@Given("user is an teen user")
	public void user_is_an_teen_user() {
		Logger.log("user is an teen user");
	}

	@Given("library has kidsZone subscription")
	public void library_has_kids_zone_subscription() {
		Logger.log("library has kidsZone subscription");
	}

	@Then("user should be able to view the interest topics as carousel")
	public void user_should_be_able_to_view_the_interest_topics_as_carousel() {
		myprogram.baseOnYourInterest();
		// Logger.log("user should be able to view the interest topics as carousel");
	}

	@Then("user should select the topics and select the teen and kid options and then tap on save button")
	public void user_should_select_the_topics_and_select_the_teen_and_kid_options_and_then_tap_on_save_button() {
		myprogram.teenAndKidOnly();
	}

	@When("user should be able to view interest topics for adult")
	public void user_should_be_able_to_view_interest_topics_for_adult() {
		Logger.log("user able to view interest topics for adult");
	}

	@When("user should un-select the topics and select the kid options and then tap on save button")
	public void user_should_un_select_the_topics_and_select_the_kid_options_and_then_tap_on_save_button() {
		myprogram.teenProfileOnly();
	}

	@Then("user should not be able to view the interest topics")
	public void user_should_not_be_able_to_view_the_interest_topics() {
		Assert.assertEquals(isElementPresent(myprogram.getBased_on_your_interest()), false);
	}

	@Then("user should not view interest topics for teen in my shelf screen")
	public void user_should_not_view_interest_topics_for_teen_in_my_shelf_screen() {
		myprogram.baseOnYourInterest();
	}

	@Then("user should be able to view the teen profile selected and non editable for teen user")
	public void user_should_be_able_to_view_the_teen_profile_selected_and_non_editable_for_teen_user() {
		myprogram.teenProfileNonEditable();
		// Logger.log("user should be able to view the teen profile selected and non
		// editable for teen user");
	}

	@Then("user should select the topics and select the teen option only in age and tap on save button")
	public void user_should_select_the_topics_and_select_the_teen_option_only_in_age_and_tap_on_save_button() {
		myprogram.teenProfileEnabled();
	}

	@Given("teen user should be able to enters the registration detail {string} and {string} and {string}")
	public void teen_user_should_be_able_to_enters_the_registration_detail_and_and(String securityanswer,
			String displayname, String email) {
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
//		profile.click_new_teen_user();
		profile.click_RegisterButton();
	}

	@Given("teen user should be able to enters the magic library registration detail {string} and {string} and {string} and {string}")
	public void teen_user_should_be_able_to_enters_the_magic_library_registration_detail_and_and_and(String Pin,
			String securityanswer, String displayname, String email) {
		profile.registerPage_set_Pin(Pin);
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
//		profile.click_new_teen_user();
		profile.click_RegisterButton();

	}

	@When("user should select the topics and select the kid option only in prefereed age level and tap on save button")
	public void user_should_select_the_topics_and_select_the_kid_option_only_in_prefereed_age_level_and_tap_on_save_button() {
		myprogram.kid_fromteen_checkbox();
	}

	@When("new user clicks on contact admin enters {string} and pin {string}")
	public void new_user_clicks_on_contact_admin_enters_and(String libraryid, String password) {
		loginpageUpdatedui.enterRandamIDandPassword(libraryid, password);
	}

	// 131418

	@Then("user should be able to view interest topics for kid")
	public void user_should_be_able_to_view_interest_topics_for_kid() {
		Assert.assertTrue(myprogram.interestTopics_kidAndteen());

	}

	@Then("user should be able to view preferred age level options Kid")
	public void user_should_be_able_to_view_preferred_age_level_options_kid() {
		Assert.assertTrue(myprogram.preferedAgeAndProfileTypeKid());

	}

	@Then("kid option should be auto selected and non editable")
	public void kid_option_should_be_auto_selected_and_non_editable() {

		Assert.assertTrue(myprogram.getKid_match_box().isEnabled());
	}

	@Then("user should be able to view interest topics for teen with teen theme")
	public void user_should_be_able_to_view_interest_topics_for_teen_with_teen_theme() {
		Logger.log("user should be able to view interest topics for teen with teen theme");
	}

	@Then("click on any of the book and validate selected age should displayed under the age level in book detail screen")
	public void click_on_any_of_the_book_and_validate_selected_age_should_displayed_under_the_age_level_in_book_detail_screen() {
		Assert.assertTrue(myprogram.ageLevelInBookDetail());
	}

	@Then("user should not view interest topics for kid in my shelf screen")
	public void user_should_not_view_interest_topics_for_kid_in_my_shelf_screen() {
		myprogram.baseOnYourInterest();
	}

	@Then("user should be able to view the kid profile selected and non editable for kid user")
	public void user_should_be_able_to_view_the_kid_profile_selected_and_non_editable_for_kid_user() {
		myprogram.kidProfileNonEditable();
		// Logger.log("user should be able to view the kid profile selected and non
		// editable for kid user");
	}

	@Then("user should select the topics and select the kid option only in age and tap on save button")
	public void user_should_select_the_topics_and_select_the_kid_option_only_in_age_and_tap_on_save_button() {
		myprogram.interestIcon_And_Kid_Checkbox_In_KidProfile();
	}

	@Given("kid user should be able to enters the registration detail {string} and {string} and {string}")
	public void kid_user_should_be_able_to_enters_the_registration_detail_and_and(String securityanswer,
			String displayname, String email) {
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
//		profile.click_new_kid_user();
		profile.click_RegisterButton();
	}

	@Given("user should be able to enters the magic library registration detail {string} and {string} and {string} and {string}")
	public void user_should_be_able_to_enters_the_magic_library_registration_detail_and_and_and(String Pin,
			String securityanswer, String displayname, String email) {
		profile.registerPage_set_Pin(Pin);
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
		// profile.click_new_kid_user();
		profile.click_RegisterButton();
	}

	@When("user should select the topics and select the teen option only in preferred age level and tap on save button")
	public void user_should_select_the_topics_and_select_the_teen_option_only_in_preferred_age_level_and_tap_on_save_button() {
		myprogram.teenProfileEnabled();
	}

	@When("user clicks on kid profile")
	public void user_clicks_on_kid_profile() {
		profile.select_Kidprofile();

	}

	// 131419

	@Then("user should be able to view set preferences screen with interest icons and preferred age level options")
	public void user_should_be_able_to_view_set_preferences_screen_with_interest_icons_and_preferred_age_level_options() {
		Assert.assertTrue(myprogram.interestTopics_kidAndteen());
	}

	@Then("user should be able to view save interest and no thanks cta")
	public void user_should_be_able_to_view_save_interest_and_no_thanks_cta() {
		Assert.assertTrue(myprogram.saveAndCancel());
	}

	@Then("user should be able to select the interest icons and submit the preference by clicking save cta")
	public void user_should_be_able_to_select_the_interest_icons_and_submit_the_preference_by_clicking_save_cta() {
		myprogram.interestIcon_And_Kid_Checkbox_In_KidProfile();
	}

	@When("user logs in for the first time")
	public void user_logs_in_for_the_first_time() {
		Logger.log("user logs in for the first time");
	}

	@Then("user should be able to view interest topics for all profile types in my shelf screen")
	public void user_should_be_able_to_view_interest_topics_for_all_profile_types_in_my_shelf_screen() {
		myprogram.baseOnYourInterest();
	}

	@Then("user able to view books based on your interest as user selected from interest survey")
	public void user_able_to_view_books_based_on_your_interest_as_user_selected_from_interest_survey() {
		myprogram.baseOnYourInterest();
		Logger.log("user able to view books based on your interest as user selected from interest survey");
	}

	@Then("click on any of the book and validate selected interest displayed under the subject in book detail screen")
	public void click_on_any_of_the_book_and_validate_selected_interest_displayed_under_the_subject_in_book_detail_screen() {
		myprogram.titleCta();
		myprogram.titleListScreen();
	}

	@Then("user should be able to view interest topics for kid in my shelf screen")
	public void user_should_be_able_to_view_interest_topics_for_kid_in_my_shelf_screen() {
		myprogram.baseOnYourInterest();
	}

	@Then("user should be able to view interest topics for all kids ages with teen theme")
	public void user_should_be_able_to_view_interest_topics_for_all_kids_ages_with_teen_theme() {
		Logger.log("user is able to view interest topics for all kids ages with teen theme");
	}

	@Then("user should be able to view interest topics for teen in my shelf screen")
	public void user_should_be_able_to_view_interest_topics_for_teen_in_my_shelf_screen() {
		myprogram.baseOnYourInterest();
	}

	@Then("user should be able to view interest topics for all kids ages with kid theme")
	public void user_should_be_able_to_view_interest_topics_for_all_kids_ages_with_kid_theme() {
		// myprogram.baseOnYourInterest();
		Logger.log("user is able to view interest topics for all kids ages with kid theme");
	}

	@When("user should be able to select the interest icons and select all the age level options and save")
	public void user_should_be_able_to_select_the_interest_icons_and_select_all_the_age_level_options_and_save() {
		myprogram.interestIconAndageLevelOptions();
	}

	@Then("teen user should be able to select the interest icons and submit the preference by clicking save cta")
	public void teen_user_should_be_able_to_select_the_interest_icons_and_submit_the_preference_by_clicking_save_cta() {
		myprogram.teenProfileEnabled();
	}

	@Then("adult user should be able to select the interest icons and submit the preference by clicking save cta")
	public void adult_user_should_be_able_to_select_the_interest_icons_and_submit_the_preference_by_clicking_save_cta() {
		myprogram.interestIconAndSave();
	}

	@When("user clicks on teen profile")
	public void user_clicks_on_teen_profile() {
		profile.select_Teenprofile();
	}

	// 131420

	@Then("new user enters the {string} kidszone subscription only")
	public void new_user_enters_the_kidszone_subscription_only(String loginid) {
		loginpageUpdatedui.enter_loginIdonly(loginid);
	}

	@Then("recommendation is enabled for the library")
	public void recommendation_is_enabled_for_the_library() {
		Logger.log("Recommendation is enabled for the library");
	}

	@When("user view the interet survey popup for the first time")
	public void user_view_the_interet_survey_popup_for_the_first_time() {
		Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
		Logger.log("New user view the interest survey popup for the first time");

	}

	@Then("user should be able to skip the screen by tapping on no thanks cta")
	public void user_should_be_able_to_skip_the_screen_by_tapping_on_no_thanks_cta() {
		profile.preferenceScreen_popup();
	}

	@When("user should be able to enters the registration detail securityansw {string} displayname {string} and {string}")
	public void user_should_be_able_to_enters_the_registration_detail_securityansw_displayname_and(
			String securityanswer, String displayname, String email) {
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
		profile.click_RegisterButton();
	}

	@When("user should be able to enters the registration detail {string} and {string} and {string}")
	public void user_should_be_able_to_enters_the_registration_detail_and_and(String securityanswer, String displayname,
			String email) {
		profile.enter_securityAnswer(securityanswer);
		profile.enter_DisplayName(displayname);
		profile.enter_EmailAddress(email);
		profile.click_RegisterButton();
	}

	@When("new user enters the prefix {string} and pin {string} kidszone subscription only")
	public void new_user_enters_the_prefix_and_pin_kidszone_subscription_only(String libraryid, String pin) {
		loginpageUpdatedui.enter_loginwithPin(libraryid, pin);
	}

	@Then("user should be able to skip the screen by tapping on close icon")
	public void user_should_be_able_to_skip_the_screen_by_tapping_on_close_icon() {
		myprogram.close_preferencepopup();
	}
	// 131421

	@Given("user has interests preferences set")
	public void user_has_interests_preferences_set() {
		Logger.log("user has interests preferences set");
	}

	@When("user navigates to the interest survey screen")
	public void user_navigates_to_the_interest_survey_screen() {
		Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
	}

	@Then("user should be able to view interest survey screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_interest_survey_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user able to view interest survey screen with theme");
	}

	@Then("user should be able to view interest survey topics based on library subscription and user profile type")
	public void user_should_be_able_to_view_interest_survey_topics_based_on_library_subscription_and_user_profile_type() {
		Assert.assertTrue(myprogram.interestTopics_kidAndteen());
	}

	@Then("user should be able to view the interests title and description")
	public void user_should_be_able_to_view_the_interests_title_and_description() {
		Assert.assertTrue(myprogram.getTeen_and_kid_reading_interest().isDisplayed());
		Assert.assertTrue(myprogram.getInterestSurvey_description().isDisplayed());
	}

	@Then("adult user should be able to view the interests title and description")
	public void adult_user_should_be_able_to_view_the_interests_title_and_description() {
		Assert.assertTrue(myprogram.getAdult_reading_preferences().isDisplayed());
		Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
	}

	@Then("user should be able to view the list of interests icons displayed with the interests selected by the user being highlighted")
	public void user_should_be_able_to_view_the_list_of_interests_icons_displayed_with_the_interests_selected_by_the_user_being_highlighted() {
		myprogram.view_interestSurveyIcons();
	}

	@Then("user should be able to select the interest topics to update the preferences")
	public void user_should_be_able_to_select_the_interest_topics_to_update_the_preferences() {
		myprogram.interestTopicsForAdultMagic();
	}

	@Then("user should be able to update preferred age level options")
	public void user_should_be_able_to_update_preferred_age_level_options() {
		Assert.assertTrue(myprogram.getPrefered_age().isDisplayed());
	}

	@Then("user should have atleast one preference selected to update and save the preferences")
	public void user_should_have_atleast_one_preference_selected_to_update_and_save_the_preferences() {
		myprogram.Save_Preferences_Magic_adult();
	}

	@Then("user should be able to view save changes by clicking save cta and get confirmation message of changes saved")
	public void user_should_be_able_to_view_save_changes_by_clicking_save_cta_and_get_confirmation_message_of_changes_saved() {
		Logger.log("user able to view save changes by clicking save cta and get confirmation message");
	}

	@Given("user preference is already set")
	public void user_preference_is_already_set() {
		myprogram.view_alreadySet_preference();
	}

	@Then("user should be able to unselect the interest topics to update the preferences")
	public void user_should_be_able_to_unselect_the_interest_topics_to_update_the_preferences() {
		myprogram.alreadySet_preference();
	}

	@Given("user is in interest survey popup")
	public void user_is_in_interest_survey_popup() {
		profile.click_viewMyinterest();
	}

	@When("user click on cancel cta")
	public void user_click_on_cancel_cta() {
		myprogram.getCancel_button().click();
	}

	@Then("user should be able to not update the interest preference")
	public void user_should_be_able_to_not_update_the_interest_preference() {

	}

	@When("user doesnt made any changes")
	public void user_doesnt_made_any_changes() {
		Logger.log("user doesnt made any changes");
	}

	@Then("user should be able to view the save cta disable")
	public void user_should_be_able_to_view_the_save_cta_disable() {
		myprogram.saveInterestEnableAndDisable();
	}
//132703

	@When("user is on my profile screen")
	public void user_is_on_my_profile_screen() {
		Logger.log("user is on my profile screen");
	}

	@Then("system should reset the interest survey preferences set by the user")
	public void system_should_reset_the_interest_survey_preferences_set_by_the_user() {
		Logger.log("system should reset the interest survey preferences set by the user");
	}

	@Then("user should not view any preferences set in the interest survey")
	public void user_should_not_view_any_preferences_set_in_the_interest_survey() {
		Logger.log("user not able to view any preferences set in the interest survey");
	}

	@Then("user should view the new interest topics based on new profile type")
	public void user_should_view_the_new_interest_topics_based_on_new_profile_type() {
		Logger.log("user not abel to view the new interest topics based on new profile type");
	}

	@Then("user should have same experience as user who has not set any interest survey preference")
	public void user_should_have_same_experience_as_user_who_has_not_set_any_interest_survey_preference() {
		Logger.log("user have same experience as user who has not set any interest survey preference");
	}

	// 140533

	@When("user lands on program details screen for books in order closed program that user has enrolled in")
	public void user_lands_on_program_details_screen_for_books_in_order_closed_program_that_user_has_enrolled_in() {
		// myprogram.view_closedProgram();
		myprogram.click_closedProgram();
	}

	@Then("user should be able to view reading list for the titles in books in order program in program details screen with the total title count")
	public void user_should_be_able_to_view_reading_list_for_the_titles_in_books_in_order_program_in_program_details_screen_with_the_total_title_count() {
		myprogram.validate_Reading_List();
	}

	@Then("user should be able to view the titles in order in the reading list with order number displayed for each title")
	public void user_should_be_able_to_view_the_titles_in_order_in_the_reading_list_with_order_number_displayed_for_each_title() {
		Assert.assertTrue(isElementPresent(myprogram.readlingList_orderNumber.get(1)));

	}

	@Then("user should be able to view title cover image for the titles in the list with title format icon")
	public void user_should_be_able_to_view_title_cover_image_for_the_titles_in_the_list_with_title_format_icon() {
		// myprogram.view_ytitlesProgm();
	}

	@Then("user should be able to click on title and navigate to title details screen")
	public void user_should_be_able_to_click_on_title_and_navigate_to_title_details_screen() {
		myprogram.clicktitle_navTodetailscreen();
	}

	@Then("user should be able to view the cta enabled for all the titles")
	public void user_should_be_able_to_view_the_cta_enabled_for_all_the_titles() {
		// myprogram.verify_alltitleEnable();
		prog.ctaEnabledOrDisabled();

	}

	@When("user should be able to view closed program Name and program description if available and program start date and program End date and program Type")
	public void user_should_be_able_to_view_closed_program_name_and_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
		myprogram.view_closedProgNameandDes();
	}

	@Then("user should be able to able to view see all cta for the title list and click on cta to navigate to title list screen")
	public void user_should_be_able_to_able_to_view_see_all_cta_for_the_title_list_and_click_on_cta_to_navigate_to_title_list_screen() {
		// myprogram.click_seeAllcta();
		System.out.println("user is able to view see all cta");
	}

//	@Then("user should be able to view the reading progress for the titles at the time of closure of the program")
//	public void user_should_be_able_to_view_the_reading_progress_for_the_titles_at_the_time_of_closure_of_the_program() {
//		Logger.log("user should be able to view the reading progress for the titles");
//	}

	@When("user lands on program details screen or program titles list screen")
	public void user_lands_on_program_details_screen_or_program_titles_list_screen() {
		myprogram.click_ongoingProg();
		// myprogram.nav_progDetailscreen();
		// Assert.assertTrue(myprogram.progDetailScreen_readinglist.isDisplayed());
	}

	@Then("user should be able to view the primary action for the titles")
	public void user_should_be_able_to_view_the_primary_action_for_the_titles() {
		myprogram.view_primaryAction();
	}

	@Then("user should be able to view action for the title checkout as a cta if title is not checked out")
	public void user_should_be_able_to_view_action_for_the_title_checkout_as_a_cta_if_title_is_not_checked_out() {
		myprogram.verify_primaryActiionCtanotcheckout();
	}

	@When("user clicks on closed program tittle that user enrolled in")
	public void user_clicks_on_closed_program_tittle_that_user_enrolled_in() {
		myprogram.view_closedProgram();
	}

	@Given("user lands on not completed closed program details screen")
	public void user_lands_on_not_completed_closed_program_details_screen() {
		Assert.assertTrue(myprogram.closedProgram_txt_notCompleted.isDisplayed());
	}

	@Then("user should be able to view action for title checkout as a cta if title is not checked out")
	public void user_should_be_able_to_view_action_for_title_checkout_as_a_cta_if_title_is_not_checked_out() {
		Assert.assertEquals(isElementPresent(myprogram.primaryaction_checkout), true);
	}

	@When("user should be able to view program Name and program description if available and program start date and program End date and program Type")
	public void user_should_be_able_to_view_program_name_and_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
		myprogram.view_programDiscriptionAndDate();
	}

	@Then("user should be able to view program details screen in with theme rendered based on user profile and library subscription")
	public void user_should_be_able_to_view_program_details_screen_in_with_theme_rendered_based_on_user_profile_and_library_subscription() {
		// myprogram.view_closedProgram();
		myprogram.click_closedProg2();

	}

	@Then("user should be able to view the status of the program based on user progres complete as not completed")
	public void user_should_be_able_to_view_the_status_of_the_program_based_on_user_progres_complete_as_not_completed() {
		Logger.log("user able to view the status of the program based on user progres complete as not completed");
	}

	@Then("user should be able to view the status of the program based on user progres complete as completed")
	public void user_should_be_able_to_view_the_status_of_the_program_based_on_user_progres_complete_as_completed() {
		Logger.log("user able to view the status of the program based on user progres complete as completed");
	}

	@Given("user lands on completed closed program details screen")
	public void user_lands_on_completed_closed_program_details_screen() {
		Assert.assertTrue(myprogram.view_completedProg());
	}

	// 140535

	@When("insights and badges enabled for Adult user")
	public void insights_and_badges_enabled_for_adult_user() {
		Logger.log("insights and badges enabled");

	}

	@Given("insights and badges disabled for Teen user")
	public void insights_and_badges_disabled_for_teen_user() {
		Logger.log("insights and badges disabled");
	}

	@When("user lands on program details screen for X out of Y closed program that user was enrolled in")
	public void user_lands_on_program_details_screen_for_x_out_of_y_closed_program_that_user_was_enrolled_in() {
		// myprogram.view_closedProgram();
		myprogram.Click_xyclosedProgram();
	}

	@Then("user should be able to view reading list for the titles in X out of Y program in program details screen with the total title count")
	public void user_should_be_able_to_view_reading_list_for_the_titles_in_x_out_of_y_program_in_program_details_screen_with_the_total_title_count() {
		myprogram.validate_Reading_List();
	}

	@Then("user should be able to view Y number of titles in the reading list")
	public void user_should_be_able_to_view_y_number_of_titles_in_the_reading_list() {
		myprogram.view_ytitlesProgm();
	}

	@When("insights and badges disabled for Adult user")
	public void insights_and_badges_disabled_for_adult_user() {
		Logger.log("insights and badges disabled for this particular adult user");
	}

	@Given("insights and badges enabled for Teen user")
	public void insights_and_badges_enabled_for_teen_user() {
		Logger.log("insights and badges enabled for this particular teen user");
	}

	@Given("insights and badges enabled for Kid user")
	public void insights_and_badges_enabled_for_kid_user() {
		Logger.log("insights and badges enabled for this particular kid user");
	}

	@Given("insights and badges disabled for Kid user")
	public void insights_and_badges_disabled_for_kid_user() {
		Logger.log("insights and badges disabled for this particular kid user");
	}

	// 140523

	@When("no ongoing program available to be displayed")
	public void no_ongoing_program_available_to_be_displayed() {
		try {
			Assert.assertEquals(isElementPresent(myprogram.ongoingProg_title), false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Assert.assertTrue(myprogram.no_ongoingProgDisplayed());
		// Assert.assertFalse(myprogram.no_ongoingProgDisplayed());
	}

	@Then("user should be able to view screen for no program to be displayed based on profile in the open programs tab")
	public void user_should_be_able_to_view_screen_for_no_program_to_be_displayed_based_on_peodilw_in_the_open_programs_tab() {
		// Assert.assertTrue(!myprogram.ongoingprogram_adult.isDisplayed());
		Assert.assertFalse(myprogram.no_programsDisplayedinOngoing());
	}

	@When("no upcoming program available to be displayed")
	public void no_upcoming_program_available_to_be_displayed() {
		Assert.assertFalse(myprogram.no_upcomingprogDisplayed());
	}

	@Then("user should not be able to view upcoming programs section when no upcoming program is available for adult profile")
	public void user_should_not_be_able_to_view_upcoming_programs_section_when_no_upcoming_program_is_available_for_adult_profile() {
		Assert.assertFalse(myprogram.no_programsDisplayedupcoming());
	}

	@Then("user should not be able to view upcoming programs section when no upcoming program is available for teen profile")
	public void user_should_not_be_able_to_view_upcoming_programs_section_when_no_upcoming_program_is_available_for_teen_profile() {
		Assert.assertFalse(myprogram.no_programsDisplayedupcoming());
	}

	@Then("user should not be able to view upcoming programs section when no upcoming program is available for kid profile")
	public void user_should_not_be_able_to_view_upcoming_programs_section_when_no_upcoming_program_is_available_for_kid_profile() {
		Assert.assertFalse(myprogram.no_programsDisplayedupcoming());
	}

	@When("no ongoing programs available to be displayed")
	public void no_ongoing_programs_available_to_be_displayed() {
		Assert.assertEquals(isElementPresent(myprogram.ongoingProg_title), false);

	}

	@When("no upcoming programs available to be displayed")
	public void no_upcoming_programs_available_to_be_displayed() {
		Assert.assertTrue(myprogram.getMyprogram_noprograms().isDisplayed());
	}

	// 140525
	@Then("user should not be able to view program card for the ongoing program not enrolled in with theme rendered based on adult profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_ongoing_program_not_enrolled_in_with_theme_rendered_based_on_adult_profile_and_library_subscription() {
		Logger.log(
				"user not able to view program card for the ongoing program not enrolled in with theme rendered based on adult profile and library subscription");
	}

	@Then("user should be able to view program name and program description if available and start date and end date for the program")
	public void user_should_be_able_to_view_program_name_and_program_description_if_available_and_start_date_and_end_date_for_the_program() {
		myprogram.view_programTitleAndDiscription();
	}

	@Then("user should not be able to view program card for the ongoing program not enrolled in with theme rendered based on kid profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_ongoing_program_not_enrolled_in_with_theme_rendered_based_on_kid_profile_and_library_subscription() {
		Logger.log(
				"user not able to view program card for the ongoing program not enrolled in with theme rendered based on kid profile");
	}

	@When("user should be able to view program card for the ongoing program enrolled in with theme rendered based on kid profile and library subscription")
	public void user_should_be_able_to_view_program_card_for_the_ongoing_program_enrolled_in_with_theme_rendered_based_on_kid_profile_and_library_subscription() {
		Logger.log(
				"user able to view program card for the ongoing program enrolled in with theme rendered based on kid profile and library subscription");
		myprogram.click_avatar();
	}

	@When("user switch the kid to teen profile in the edit profile page")
	public void user_switch_the_kid_to_teen_profile_in_the_edit_profile_page() {
		profilepageview.select_profileType_Teen();
		profilepageview.manageProfile_saveCTA();
		profile.click_yesConfirmpopup();
	}

	@When("user navigates back to the open programs tab")
	public void user_navigates_back_to_the_open_programs_tab() {
		Assert.assertTrue(isElementPresent(myprogram.getOpenprogram_tabs()));
	}

	@Then("user should be able to view the program what their in the teen profile")
	public void user_should_be_able_to_view_the_program_what_their_in_the_teen_profile() {
		Logger.log("user able to view the program what their in the teen profile");
	}

	// 140528
	@Then("user should not be able to view ongoing programs section when no ongoing program is available based on profile")
	public void user_should_not_be_able_to_view_ongoing_programs_section_when_no_ongoing_program_is_available_based_on_profile() {
		Logger.log(
				"user not able to view ongoing programs section when no ongoing program is available based on profile");
	}

	@Then("user should not be able to view program card for the upcoming program not enrolled in with theme rendered based on adult profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_upcoming_program_not_enrolled_in_with_theme_rendered_based_on_adult_profile_and_library_subscription() {
		Logger.log(
				"user not able to view program card for the upcoming program not enrolled in with theme rendered based on adult profile and library subscription");
	}

	@Then("user should not be able to view program card for the upcoming program not enrolled in with theme rendered based on teen profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_upcoming_program_not_enrolled_in_with_theme_rendered_based_on_teen_profile_and_library_subscription() {
		Logger.log(
				"user not able to view program card for the upcoming program not enrolled in with theme rendered based on teen profile and library subscription");
	}

	@Then("user should not be able to view program card for the upcoming program not enrolled in with theme rendered based on kid profile and library subscription")
	public void user_should_not_be_able_to_view_program_card_for_the_upcoming_program_not_enrolled_in_with_theme_rendered_based_on_kid_profile_and_library_subscription() {
		Logger.log(
				"user not able to view program card for the upcoming program not enrolled in with theme rendered based on kid profile and library subscription");
	}

	@When("user should be able to view program card for the upcoming program enrolled in with theme rendered based on kid profile and library subscription")
	public void user_should_be_able_to_view_program_card_for_the_upcoming_program_enrolled_in_with_theme_rendered_based_on_kid_profile_and_library_subscription() {
		Logger.log(
				"user able to view program card for the upcoming program enrolled in with theme rendered based on kid profile and library subscription");
		myprogram.click_avatar();
	}

	// 140527
	@Then("user should be able to view list of programs that are available based on profile type")
	public void user_should_be_able_to_view_list_of_programs_that_are_available_based_on_profile_type() {
		myprogram.view_listOfprog();
	}

	@Then("user should be able to view ongoing programs that user is not participating in listed under ongoing programs section")
	public void user_should_be_able_to_view_ongoing_programs_that_user_is_not_participating_in_listed_under_ongoing_programs_section() {
		Assert.assertTrue(isElementPresent(myprogram.ongoingProg_title));
	}

	@Then("user should be able to view upcoming programs that user is not participating in listed under upcoming programs section")
	public void user_should_be_able_to_view_upcoming_programs_that_user_is_not_participating_in_listed_under_upcoming_programs_section() {
		javascriptScroll(myprogram.upcomingProg_title);
		Assert.assertEquals(isElementPresent(myprogram.upcomingProg_title), true);
	}

	@Then("user should be able to view each program displayed as a card with card theme rendered based on library subscription and profile type")
	public void user_should_be_able_to_view_each_program_displayed_as_a_card_with_card_theme_rendered_based_on_library_subscription_and_profile_type() {
		Logger.log(
				"user should be able to view each program displayed as a card with card theme rendered based on library subscription and profile type");
	}

	@Then("application should load twenty programs at a time and lazy load as user scrolls down")
	public void application_should_load_twenty_programs_at_a_time_and_lazy_load_as_user_scrolls_down() {
		myprogram.view_lazyload();
	}

	@Then("uer should be able to view brief description for the open programs screen on top")
	public void uer_should_be_able_to_view_brief_description_for_the_open_programs_screen_on_top() {
		// Assert.assertTrue(myprogram.txt_NavprogDetailsScreen.isDisplayed());
		Assert.assertTrue(isElementPresent(myprogram.getProgDetailscreen_title()));
	}

	// 140536

	@When("user select open programs tab and select ongoing program")
	public void user_select_open_programs_tab_and_select_ongoing_program() {
		myprogram.click_openProgram();
		myprogram.click_ongoingProg();
	}

	@When("user Select open programs tab and Select booksin order ongoing program")
	public void user_select_open_programs_tab_and_select_booksin_order_ongoing_program() {
		myprogram.click_openProgram();
		myprogram.click_booksinorderOngoingProg();
	}

	@When("user lands on ongoing program details screen that user has not enrolled in")
	public void user_lands_on_ongoing_program_details_screen_that_user_has_not_enrolled_in() {
		Logger.log("user lands on ongoing program details screen that user has not enrolled in");
	}

	@Then("user should  be able to view program details screen in with adult theme rendered based on user profile")
	public void user_should_be_able_to_view_program_details_screen_in_with_adult_theme_rendered_based_on_user_profile() {
		Logger.log(
				"user should  be able to view program details screen in with adult theme rendered based on user profile");
	}

	@Then("User should be able to view Program Name, program description if available and program start date and program End date and program Type")
	public void user_should_be_able_to_view_program_name_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
		myprogram.view_progNameAndstartdateendDate();
	}

	@Then("user should be able to view list of titles as reading list for the reading program with the total title count")
	public void user_should_be_able_to_view_list_of_titles_as_reading_list_for_the_reading_program_with_the_total_title_count() {
		// myprogram.navigateup_scroll();
		myprogram.validate_Reading_List();
	}

	@Then("user should be able to view join program cta")
	public void user_should_be_able_to_view_join_program_cta() {
		javascriptScroll(myprogram.progDetailscreen_joinprogramCTA);
		try {
			Assert.assertTrue(isElementPresent(myprogram.progDetailscreen_joinprogramCTA));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("if reading list titles more than {int} and user should be able to able to view see all cta for the title list")
	public void if_reading_list_titles_more_than_and_user_should_be_able_to_able_to_view_see_all_cta_for_the_title_list(
			Integer int1) {
		// Assert.assertEquals(isElementPresent(myprogram.seeAll_cta), false);
	}

	@Then("click on cta to navigate to title list screen")
	public void click_on_cta_to_navigate_to_title_list_screen() {
		myprogram.click_seeAllcta();
	}

	@Then("if reading list titles less than {int} and user should not be able to able to view see all cta for the title list")
	public void if_reading_list_titles_less_than_and_user_should_not_be_able_to_able_to_view_see_all_cta_for_the_title_list(
			Integer int1) {

	}

	@When("user select open programs tab and select upcoming program")
	public void user_select_open_programs_tab_and_select_upcoming_program() {
		myprogram.click_openProgram();
		myprogram.click_upcomingProg();
	}

	@Then("user should be able to view the primary actions for the titles")
	public void user_should_be_able_to_view_the_primary_actions_for_the_titles() {
		Assert.assertEquals(isElementPresent(myprogram.titlelist_primaryAction), true);
	}

	@When("user lands on upcoming program details screen that user has not enrolled in")
	public void user_lands_on_upcoming_program_details_screen_that_user_has_not_enrolled_in() {
		Logger.log("user lands on upcoming program details screen that user has not enrolled in");
	}

	@Then("if reading list titles less or equal to {int} and user should not able to able to view see all cta for the title list")
	public void if_reading_list_titles_less_or_equal_to_and_user_should_not_able_to_able_to_view_see_all_cta_for_the_title_list(
			Integer int1) {
		// Assert.assertEquals(isElementPresent(myprogram.seeAll_cta), true);
	}

	@When("User select open programs tab and select upcoming program titles less ten")
	public void user_select_open_programs_tab_and_select_upcoming_program_titles_less_ten() {

	}

//140547

	@When("click on {string} cta to navigate to title list screen")
	public void click_on_cta_to_navigate_to_title_list_screen(String string) {
		myprogram.seeAllcta();
	}

//
//	@When("user should be able to view primary action for the title as CTA")
//	public void user_should_be_able_to_view_primary_action_for_the_title_as_cta() {
//	    myprogram.primaryActionCta();
//	}

	// 140537

	@When("user select open programs tab and select {string} program in ongoing program session")
	public void user_select_open_programs_tab_and_select_program_in_ongoing_program_session(String string) {
		myprogram.click_openProgram();
		myprogram.clik_xyprogram();
	}

	@Then("user should be able to view xy program title cover image for the titles in the list with title format icon")
	public void user_should_be_able_to_view_xy_program_title_cover_image_for_the_titles_in_the_list_with_title_format_icon() {
		myprogram.view_ytitlesProgm();
	}

	@When("user lands on program details screen")
	public void user_lands_on_program_details_screen() {
		Assert.assertTrue(isElementPresent(myprogram.progDetailScreen_readinglist));
	}

	@Then("user should be able to view reading list for the titles in {string} program in program details screen with the total title count")
	public void user_should_be_able_to_view_reading_list_for_the_titles_in_program_in_program_details_screen_with_the_total_title_count(
			String string) {
		myprogram.validate_Reading_List();
	}

	@Then("user should be able to view {string} number of titles in the reading list")
	public void user_should_be_able_to_view_number_of_titles_in_the_reading_list(String string) {
		Assert.assertTrue(isElementPresent(myprogram.ynumberofTitleList));
	}

	@Then("if {string} is more than {int} and user should be able to able to view see all cta for the title list and click on cta to navigate to title list screen")
	public void if_is_more_than_and_user_should_be_able_to_able_to_view_see_all_cta_for_the_title_list_and_click_on_cta_to_navigate_to_title_list_screen(
			String string, Integer int1) {
		Assert.assertTrue(isElementPresent(myprogram.seeAll_cta));
		myprogram.click_seeAllcta();
	}

	@Then("user should be able to click on y title and navigate to title details screen")
	public void user_should_be_able_to_click_on_y_title_and_navigate_to_title_details_screen() {
		myprogram.click_yprogramstoNavtitleScreen();
	}

	// 140538

	@When("user lands on program details screen for X out of Y ongoing program that user has enrolled in")
	public void user_lands_on_program_details_screen_for_x_out_of_y_ongoing_program_that_user_has_enrolled_in() {
		myprogram.click_openProgram();
		myprogram.clik_xyprogram();
	}

	@When("si user lands on program details screen for X out of Y ongoing program that user has enrolled in")
	public void si_user_lands_on_program_details_screen_for_x_out_of_y_ongoing_program_that_user_has_enrolled_in() {
		myprogram.click_openProgram();
		myprogram.click_ongoingProg();
	}

	@Then("user should be able to view primary action for the title as CTA")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_cta() {
		myprogram.view_primaryAction();
	}

	@Then("user should be able to view default image with title name and author name and title format icon if title cover image is not available")
	public void user_should_be_able_to_view_default_image_with_title_name_and_author_name_and_title_format_icon_if_title_cover_image_is_not_available() {
		Logger.log("Negative Test cases will be verified manually");
	}

	@Then("user should be able to view default image for title not available if title is not longer available for the library users")
	public void user_should_be_able_to_view_default_image_for_title_not_available_if_title_is_not_longer_available_for_the_library_users() {
		Logger.log("Negative Test cases will be verified manually");
	}

	@Then("user should be able to view the reading progress for the titles checked out and title completed as progress bar")
	public void user_should_be_able_to_view_the_reading_progress_for_the_titles_checked_out_and_title_completed_as_progress_bar() {
		prog.click_coverimg();
	}

	@Then("user should be able to view primary action for title as CTA")
	public void user_should_be_able_to_view_primary_action_for_title_as_cta() {
		Assert.assertTrue(prog.primary_CTA.isDisplayed());
	}

	@Then("user should not view title action CTA for checked out titles")
	public void user_should_not_view_title_action_cta_for_checked_out_titles() {
		Logger.log("Negative Test cases will be verified manually");
	}

	@Then("user should be able to view see all CTA for the title list and click on CTA to navigate to title list screen")
	public void user_should_be_able_to_view_see_all_cta_for_the_title_list_and_click_on_cta_to_navigate_to_title_list_screen() {
		myprogram.seeAllcta();
	}

	@Given("user navigated to programs listing page")
	public void user_navigated_to_programs_listing_page() {
		myprogram.click_openProgram();
	}

	@When("user clicks on X out of Y books program and lands in program details screen of that program")
	public void user_clicks_on_x_out_of_y_books_program_and_lands_in_program_details_screen_of_that_program() {
		myprogram.clik_xyprogram();
	}

	@When("user clicks on see all for the reading list in the program")
	public void user_clicks_on_see_all_for_the_reading_list_in_the_program() {
		myprogram.click_seeAllcta();
	}

	@Then("user should be navigated to the titles list screen")
	public void user_should_be_navigated_to_the_titles_list_screen() {
		// Assert.assertTrue(myprogram.progDetailScreen_readinglist.isDisplayed());
	}
	// 140530

	@When("user lands on my programs tab and select books in order program")
	public void user_lands_on_my_programs_tab_and_select_books_in_order_program() {
		myprogram.click_booksinOrderprog();
	}

	@Then("user should be able to view program details screen in with adult theme")
	public void user_should_be_able_to_view_program_details_screen_in_with_adult_theme() {
		Logger.log("user able to view program details screen in with adult theme");
	}

	@Then("if {int} or more than {int} titles and user should be able to able to view {string} cta for the title list")
	public void if_or_more_than_titles_and_user_should_be_able_to_able_to_view_cta_for_the_title_list(Integer int1,
			Integer int2, String string) {
		Assert.assertTrue(myprogram.seeAll_cta.isDisplayed());
	}

	@Then("click on see all cta to navigate to title list screen")
	public void click_on_see_all_cta_to_navigate_to_title_list_screen() {
		myprogram.click_seeAllcta();
	}

	@Then("user should be able to view leave program cta")
	public void user_should_be_able_to_view_leave_program_cta() {
		myprogram.view_leaveProgram();
	}

	@Then("user should be able to view books in order program name and program description if available and program start date and program end date and program type")
	public void user_should_be_able_to_view_books_in_order_program_name_and_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
		myprogram.verify_booksinorder_prgramNameAndDescription();
	}

	@When("user lands on my programs tab and select x out of y program")
	public void user_lands_on_my_programs_tab_and_select_x_out_of_y_program() {
		myprogram.click_xyprog();
	}

	@Then("user should be able to view xy program name and program description if available and program start date and program end date and program type")
	public void user_should_be_able_to_view_xy_program_name_and_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type() {
		myprogram.verify_xyprog_prgramNameAndDescription();
	}

	// 140531

	@Given("user lands on my programs screen")
	public void user_lands_on_my_programs_screen() {
		Assert.assertTrue(myprogram.getTxt_activeProgram().isDisplayed());
	}

	/*
	 * 
	 * //13186
	 * 
	 * @Given("user click on login button after user enter kidszone subscription only {string} and {string}"
	 * ) public void
	 * user_click_on_login_button_after_user_enter_kidszone_subscription_only_and(
	 * String loginid, String pin) {
	 * loginpageUpdatedui.already_signeduser_prefixloginwithPin(loginid, pin);
	 * >>>>>>> c99a9c07a3f15189608758012b8c7ab137ca41dd }
	 * 
	 * @Then("user should be able to view progress calculated based on completion of the titles in the reading program"
	 * ) public void
	 * user_should_be_able_to_view_progress_calculated_based_on_completion_of_the_titles_in_the_reading_program
	 * () { Assert.assertTrue(myprogram.view_overAllprogressPercentage()); }
	 * 
	 * @Then("application should not update the program progress once program has closed"
	 * ) public void
	 * application_should_not_update_the_program_progress_once_program_has_closed()
	 * { // Assert.assertFalse(myprogram.getOverAllprogress().isDisplayed()); }
	 * 
	 * // 140515
	 * 
	 * @Then("user should be able to view my programs screen with theme rendered based on library subscription and user profile type"
	 * ) public void
	 * user_should_be_able_to_view_my_programs_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type
	 * () { Logger.log(
	 * "user should be able to view my programs screen with theme rendered based on library subscription and user profile type"
	 * ); }
	 * 
	 * @Then("user should be able to view list of programs only that user has participated in or participating in"
	 * ) public void
	 * user_should_be_able_to_view_list_of_programs_only_that_user_has_participated_in_or_participating_in
	 * () { myprogram.view_listOfprogramsparticipated(); }
	 * 
	 * @Then("user should be able to view active ongoing and upcoming programs that user is participating in listed under active programs section"
	 * ) public void
	 * user_should_be_able_to_view_active_ongoing_and_upcoming_programs_that_user_is_participating_in_listed_under_active_programs_section
	 * () {
	 * 
	 * }
	 * 
	 * @Then("user should be able to view closed programs that user has participated in listed under closed programs section"
	 * ) public void
	 * user_should_be_able_to_view_closed_programs_that_user_has_participated_in_listed_under_closed_programs_section
	 * () {
	 * 
	 * }
	 * 
	 * @Then("user should be able to view each program displayed as a card with card theme rendered based on library subscription and user profile type"
	 * ) public void
	 * user_should_be_able_to_view_each_program_displayed_as_a_card_with_card_theme_rendered_based_on_library_subscription_and_user_profile_type
	 * () {
	 * 
	 * }
	 * 
	 * @Then("user should not be able to view programs that user is participating or participated in but have been un-published"
	 * ) public void
	 * user_should_not_be_able_to_view_programs_that_user_is_participating_or_participated_in_but_have_been_un_published
	 * () {
	 * 
	 * }
	 * 
	 * @Then("user should not be able to view the programs that user left") public
	 * void user_should_not_be_able_to_view_the_programs_that_user_left() {
	 * 
	 * }
	 * 
	 * @Then("user should be able to view programs sorted with latest end date first within each section"
	 * ) public void
	 * user_should_be_able_to_view_programs_sorted_with_latest_end_date_first_within_each_section
	 * () {
	 * 
	 * }
	 * 
	 * @Then("application should load {int} programs at a time and lazy load as user scrolls down"
	 * ) public void
	 * application_should_load_programs_at_a_time_and_lazy_load_as_user_scrolls_down
	 * (Integer int1) {
	 * 
	 * }
	 * 
	 * @Then("user should be able to click on programs card and navigate to program details screen"
	 * ) public void
	 * user_should_be_able_to_click_on_programs_card_and_navigate_to_program_details_screen
	 * () {
	 * 
	 * }
	 * 
	 * // 131414
	 * 
	 * @When("user navigates to interest survey screen and popup") public void
	 * user_navigates_to_interest_survey_screen_and_popup() {
	 * 
	 * Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
	 * }
	 * 
	 * @Then("user should be able to view interest survey screen with kid theme and topics when profile type is kid and library has kids zone subscription"
	 * ) public void
	 * user_should_be_able_to_view_interest_survey_screen_with_kid_theme_and_topics_when_profile_type_is_kid_and_library_has_kids_zone_subscription
	 * () {
	 * 
	 * logger.
	 * info("user should be able to view interest survey screen with kid theme");
	 * 
	 * }
	 * 
	 * @Then("user should be able to view interest survey screen with teen theme and topics when profile type is teen and library has kids zone subscription"
	 * ) public void
	 * user_should_be_able_to_view_interest_survey_screen_with_teen_theme_and_topics_when_profile_type_is_teen_and_library_has_kids_zone_subscription
	 * () {
	 * 
	 * logger.
	 * info("user should be able to view interest survey screen with teen theme"); }
	 * 
	 * @Then("user should be able to view interest survey screen with adult theme  and topics when profile type is adult and library has kidszone and axis {int} subscription"
	 * ) public void
	 * user_should_be_able_to_view_interest_survey_screen_with_adult_theme_and_topics_when_profile_type_is_adult_and_library_has_kidszone_and_axis_subscription(
	 * Integer int1) {
	 * 
	 * logger.
	 * info("user should be able to view interest survey screen with adult theme");
	 * }
	 * 
	 * // 131415
	 * 
	 * @Given("recommendations are enabled in bakerandtaylor admin for the library")
	 * public void
	 * recommendations_are_enabled_in_bakerandtaylor_admin_for_the_library() {
	 * 
	 * logger.
	 * info("recommendations are enabled in bakerandtaylor admin for the library");
	 * 
	 * }
	 * 
	 * @Then("user should be able to view interest topics for adults") public void
	 * user_should_be_able_to_view_interest_topics_for_adults() {
	 * 
	 * Assert.assertTrue(myprogram.interestTopics()); }
	 * 
	 * @Then("user should be able to view preferred age level options kid and teen and adult"
	 * ) public void
	 * user_should_be_able_to_view_preferred_age_level_options_kid_and_teen_and_adult
	 * () {
	 * 
	 * Assert.assertTrue(myprogram.preferedAgeAndProfileType()); }
	 * 
	 * // 131416
	 * 
	 * @Then("user should be able to view interest topics for teen") public void
	 * user_should_be_able_to_view_interest_topics_for_teen() {
	 * Assert.assertTrue(myprogram.interestTopics());
	 * 
	 * }
	 * 
	 * @Then("user should be able to view preferred age level options kid and teen")
	 * public void
	 * user_should_be_able_to_view_preferred_age_level_options_kid_and_teen() {
	 * 
	 * Assert.assertTrue(myprogram.preferedAgeAndProfileType()); }
	 * 
	 * // 131418
	 * 
	 * @Then("user should be able to view interest topics for kid") public void
	 * user_should_be_able_to_view_interest_topics_for_kid() {
	 * 
	 * Assert.assertTrue(myprogram.interestTopics()); }
	 * 
	 * @Then("user should be able to view preferred age level options Kid") public
	 * void user_should_be_able_to_view_preferred_age_level_options_kid() {
	 * Assert.assertTrue(myprogram.preferedAgeAndProfileType()); }
	 * 
	 * @Then("kid option should be auto selected and non editable") public void
	 * kid_option_should_be_auto_selected_and_non_editable() {
	 * 
	 * Assert.assertTrue(myprogram.getKid_match_box().isEnabled());
	 * Logger.log("kid option should be auto selected");
	 * 
	 * }
	 * 
	 * // 131420
	 * 
	 * @Then("new user enters the {string} kidszone subscription only") public void
	 * new_user_enters_the_kidszone_subscription_only(String loginid) {
	 * loginpageUpdatedui.enter_loginIdonly(loginid); }
	 * 
	 * @Then("recommendation is enabled for the library") public void
	 * recommendation_is_enabled_for_the_library() {
	 * Logger.log("Recommendation is enabled for the library"); }
	 * 
	 * @When("user view the interet survey popup for the first time") public void
	 * user_view_the_interet_survey_popup_for_the_first_time() {
	 * Assert.assertTrue(myprogram.getInterest_survey_preferences().isDisplayed());
	 * Logger.log("New user view the interest survey popup for the first time");
	 * 
	 * }
	 * 
	 * @Then("user should be able to skip the screen by tapping on no thanks cta")
	 * public void
	 * user_should_be_able_to_skip_the_screen_by_tapping_on_no_thanks_cta() {
	 * profile.preferenceScreen_popup(); }
	 * 
	 * @When("user should be able to enters the registration detail {string} and {string} and {string}"
	 * ) public void
	 * user_should_be_able_to_enters_the_registration_detail_and_and(String
	 * securityanswer, String displayname, String email) {
	 * profile.enter_securityAnswer(securityanswer);
	 * profile.enter_DisplayName(displayname); profile.enter_EmailAddress(email);
	 * profile.click_RegisterButton(); }
	 * 
	 * @When("new user enters the prefix {string} and pin {string} kidszone subscription only"
	 * ) public void
	 * new_user_enters_the_prefix_and_pin_kidszone_subscription_only(String string,
	 * String string2) {
	 * 
	 * }
	 * 
	 * @Then("user should be able to skip the screen by tapping on close icon")
	 * public void user_should_be_able_to_skip_the_screen_by_tapping_on_close_icon()
	 * {
	 * 
	 * }
	 * 
	 * /*
	 * 
	 * //13186
	 * 
	 * @Given("user click on login button after user enter kidszone subscription only {string} and {string}"
	 * ) public void
	 * user_click_on_login_button_after_user_enter_kidszone_subscription_only_and(
	 * String loginid, String pin) {
	 * loginpageUpdatedui.already_signeduser_prefixloginwithPin(loginid, pin); }
	 * 
	 * @When("user disables programs for the adult profile") public void
	 * user_disables_programs_for_the_adult_profile() {
	 * Logger.log("user disables programs for the adult profile"); }
	 * 
	 * @Then("user should not be able to view my program on my shelf screen") public
	 * void user_should_not_be_able_to_view_my_program_on_my_shelf_screen() {
	 * myprogram.shouldnotShow_myprogramonMyshelf(); }
	 * 
	 * @When("user disables the program for the library") public void
	 * user_disables_the_program_for_the_library() {
	 * Logger.log("user disables programs for the library"); }
	 * 
	 * @Given("user click on login button after user enter kidszone subscription only {string}"
	 * ) public void
	 * user_click_on_login_button_after_user_enter_kidszone_subscription_only(String
	 * loginid) { loginpageUpdatedui.enter_loginIdonly(loginid); }
	 * 
	 * @When("user is not participant on any ongoing programs") public void
	 * user_is_not_participant_on_any_ongoing_programs() {
	 * myprogram.shouldnotShow_myprogramonMyshelf(); }
	 * 
	 * @Then("user should not be able to view programs carousel in my shelf screen")
	 * public void
	 * user_should_not_be_able_to_view_programs_carousel_in_my_shelf_screen() {
	 * Assert.assertTrue(!myprogram.getView_programcarousel().isDisplayed());
	 * Logger.log("user should not able to view program carousel"); }
	 * 
	 * @When("user disables programs for the kid profile") public void
	 * user_disables_programs_for_the_kid_profile() {
	 * Logger.log("user disables programs for the kid profile"); }
	 * 
	 * @When("user disables programs for the teen profile") public void
	 * user_disables_programs_for_the_teen_profile() {
	 * Logger.log("user disables programs for the teen profile"); }
	 * 
	 */

	@When("user select the program its navigate to details screen")
	public void user_select_the_program_its_navigate_to_details_screen() {
		myprogram.click_booksinOrderprog();
		Assert.assertTrue(myprogram.progDetailScreen_readinglist.isDisplayed());
	}

	// 140540

	@When("user taps on the join program cta")
	public void user_taps_on_the_join_program_cta() {
		myprogram.click_joinProgram();
	}

	@Then("user should be able to view the confirmation screen for joining the program")
	public void user_should_be_able_to_view_the_confirmation_screen_for_joining_the_program() {
		Assert.assertTrue(isElementPresent(myprogram.joinprog_confirmPopup));
	}

	@Then("user should be navigated to the participating program details screen")
	public void user_should_be_navigated_to_the_participating_program_details_screen() {
		// myprogram.click_letsGetStarted();
	}

	@Then("user should be able to view the participating program on my programs screen")
	public void user_should_be_able_to_view_the_participating_program_on_my_programs_screen() {
		// Assert.assertTrue(myprogram.progDetailScreen_readinglist.isDisplayed());
	}

	@Then("user should be able to view welcome to {string} message")
	public void user_should_be_able_to_view_welcome_to_message(String string) {
		Assert.assertEquals(myprogram.view_progranNameInjoinProgScreen(), true);
	}

	@Then("user should be able to click on the {string} icon and navigate to the open programs screen")
	public void user_should_be_able_to_click_on_the_icon_and_navigate_to_the_open_programs_screen(String string) {
		myprogram.click_close_joinProg();
	}

	@Then("user should not be able to view the program card on open programs screen after joining the program")
	public void user_should_not_be_able_to_view_the_program_card_on_open_programs_screen_after_joining_the_program() {
		Logger.log("user not able to view the program card on open programs screen after joining the program");
	}

	/*******************************************
	 * End To End
	 *****************************************************/

	@Then("user should be able to view Active program")
	public void user_should_be_able_to_view_active_program() {
		javascriptScroll(myprogram.getTxt_activeProgram());
		Assert.assertTrue(myprogram.getTxt_activeProgram().isDisplayed());
	}

	@Then("user should be able to view Closed program")
	public void user_should_be_able_to_view_closed_program() {
		javascriptScroll(myprogram.getMyprogram_txt_closedProgram());
		Assert.assertTrue(myprogram.getMyprogram_txt_closedProgram().isDisplayed());
	}

	@Then("user should be able to view Ongoing programs")
	public void user_should_be_able_to_view_ongoing_programs() {
		visibilityWait(myprogram.ongoingProg_title);
		javascriptScroll(myprogram.ongoingProg_title);
		Assert.assertTrue(myprogram.ongoingProg_title.isDisplayed());
	}

	@Then("user should be able to view upcoming programs")
	public void user_should_be_able_to_view_upcoming_programs() {
		visibilityWait(myprogram.upcomingProg_title);
		javascriptScroll(myprogram.upcomingProg_title);
		Assert.assertTrue(myprogram.upcomingProg_title.isDisplayed());
	}

	@Given("user should be able to view joined program section")
	public void user_should_be_able_to_view_joined_program_section() {
		javascriptScroll(myprogram.getTxt_activeProgram());
		Assert.assertTrue(myprogram.getTxt_activeProgram().isDisplayed());
		Logger.log("user should be able to view the joined program section");
	}

	@Then("user should be able to view title progress status for the joined Program")
	public void user_should_be_able_to_view_title_progress_status_for_the_joined_program() {
		Assert.assertTrue(myprogram.joinedprogram_TitleProgress.isDisplayed());
		Logger.log("user is able to view the title progress status for joined program");
	}

	@Given("user clicks on active program")
	public void user_clicks_on_active_program() {
		myprogram.click_activeProg();
	}

	@Then("user should be navigate to program details")
	public void user_should_be_navigate_to_program_details() {
		Assert.assertTrue(myprogram.program_details.isDisplayed());
	}

	@Given("user clicks on closed program")
	public void user_clicks_on_closed_program() {
		myprogram.click_ClosedProg();
	}

	@Given("user clicks on ongoing program")
	public void user_clicks_on_ongoing_program() {
		myprogram.click_ongoingprog();
	}

	@Given("user clicks on upcoming program")
	public void user_clicks_on_upcoming_program() {
		myprogram.click_upcomingprog();
	}

	@Given("user navigates to started program section")
	public void user_navigates_to_started_program_section() {
		javascriptScroll(myprogram.getTxt_activeProgram());
		Assert.assertTrue(myprogram.getTxt_activeProgram().isDisplayed());
		Logger.log("user navigates to started program section");
	}

	@Then("user should be able to view the reading progress bar for the started program")
	public void user_should_be_able_to_view_the_reading_progress_bar_for_the_started_program() {
		Assert.assertTrue(myprogram.getReading_progress().isDisplayed());
	}

}
