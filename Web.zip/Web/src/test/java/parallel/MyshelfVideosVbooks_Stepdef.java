package parallel;

import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;
import java.util.Map;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.MyshelfvideosVbooks;

import org.junit.Assert;

public class MyshelfVideosVbooks_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	MyshelfvideosVbooks myshelfpage = new MyshelfvideosVbooks(DriverManager.getDriver());
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());
	
	Eyes eyes = EyesManager.getEyes();

	/*******************************************************/

	@Given("library should have subscription to video and vbooks third party and video and vbooks carousel enabled by library admin")
	public void library_should_have_subscription_to_video_and_vbooks_third_party_and_video_and_vbooks_carousel_enabled_by_library_admin() {
		Logger.log("Library have the subscription to video and vbook carousel enabled in library admin");
	}

	@Given("user have checked out titles")
	public void user_have_checked_out_titles() {
//		visibilityWait(myshelfpage.mystuff_Checkoutas_Titles);
		WaitForWebElement(myshelfpage.mystuff_Checkoutas_Titles);
		Assert.assertTrue(myshelfpage.mystuff_Checkoutas_Titles.isDisplayed());
		Logger.log("user already have checked out titles in my stuff");
	}

	@When("user is able tap on checkout cta from mystuff screen")
	public void user_is_able_tap_on_checkout_cta_from_mystuff_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
	}

	@Then("user should be able to view two sections eBook and eAudio and videos and vbooks")
	public void user_should_be_able_to_view_two_sections_e_book_and_e_audio_and_videos_and_vbooks() {
		myshelfpage.checkoutScreenValidation();
	}

	@Then("user should be able to view video titles checkedout in videos and vbooks section")
	public void user_should_be_able_to_view_video_titles_checkedout_in_videos_and_vbooks_section() {
		Logger.log("User able to view titles checkedout in videos and vbooks section");
	}

	@Then("user should be able to view each video title listed as card in grid view")
	public void user_should_be_able_to_view_each_video_title_listed_as_card_in_grid_view() {
		visibilityWait(myshelfpage.vBookSecCheckoutGrid);
		if (myshelfpage.vBookSecCheckoutGrid.isDisplayed()) {
			Assert.assertTrue(myshelfpage.vBookSecCheckoutGrid.isDisplayed());
			// Assert.assertTrue(myshelfpage.videoSecCheckoutGrid.isDisplayed());
			Logger.log("user should be able to view each video and vbook title are grid view by default");
		}

	}

//	@Then("user should be able to view titles as list view by default")
//	public void user_should_be_able_to_view_titles_as_list_view_by_default() {
//
//	}

	@Then("user should be able to view the titles sorted by latest title checkedout first by default")
	public void user_should_be_able_to_view_the_titles_sorted_by_latest_title_checkedout_first_by_default() {
		Logger.log("User able to view the titles sorted by latest title checkedout first by default");
	}

	@Then("user should b able to know filter and sort options not applicable for videos and vbooks")
	public void user_should_b_able_to_know_filter_and_sort_options_not_applicable_for_videos_and_vbooks() {

	}

	@Then("user should be able to view four sections eBook, eAudio, videos and vbooks")
	public void user_should_be_able_to_view_four_sections_e_book_e_audio_videos_and_vbooks() {
		myshelfpage.checkoutScreenValidation();
	}

	@Then("user should be able to view checked out video titles in videos and vbooks section")
	public void user_should_be_able_to_view_checked_out_video_titles_in_videos_and_vbooks_section() {

	}

	@Then("user should be able to view the title cover image,title due date like checkout expiry or return date and primary cta")
	public void user_should_be_able_to_view_the_title_cover_image_title_due_date_like_checkout_expiry_or_return_date_and_primary_cta() {
		myshelfpage.checkoutScreenTitleValidation();
	}

	@Then("user should be able to view filter and sort options in my stuff screen")
	public void user_should_be_able_to_view_filter_and_sort_options_in_my_stuff_screen() {
		visibilityWait(myshelfpage.getFilterOptions());
		Assert.assertTrue(myshelfpage.getFilterOptions().isDisplayed());
		Assert.assertTrue(myshelfpage.getSortButton().isDisplayed());
	}

	@Then("user should be able to view titles as grid view by default")
	public void user_should_be_able_to_view_titles_as_grid_view_by_default() {
		Logger.log("User able to view the title in Grid View by default");
	}

	@Given("user should be able to select the Video by clicking checkout cta")
	public void user_should_be_able_to_select_the_video_by_clicking_checkout_cta() {
		video.click_checkoutCTALibpage();
	}

	@Given("user checked out the Video Title and navigate to my self screen")
	public void user_checked_out_the_video_title_and_navigate_to_my_self_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
	}

	@When("user is in the My Shelf Screen")
	public void user_is_in_the_my_shelf_screen() {
		Assert.assertTrue(myshelfpage.Menu_myshlftabs.isDisplayed());
	}

	@Then("user should be able to view checked out titles section")
	public void user_should_be_able_to_view_checked_out_titles_section() {
		visibilityWait(myshelfpage.myshlf_CurrrentlyCheckout);
		javascriptScroll(myshelfpage.myshlf_CurrrentlyCheckout);
		Assert.assertTrue(myshelfpage.myshlf_CurrrentlyCheckout.isDisplayed());
	}

	@Then("user should be able to view the Currently checked-out carousel")
	public void user_should_be_able_to_view_the_currently_checked_out_carousel() {
		Assert.assertTrue(myshelfpage.CurrentlyCheckout_Carousel.isDisplayed());
	}

	@Then("user should be able to view Video title as part of the Currently checked out carousel")
	public void user_should_be_able_to_view_video_title_as_part_of_the_currently_checked_out_carousel() {

	}

	@Then("user singout view hamburger menu")
	public void user_singout_view_hamburger_menu() {
		login.click_HamburgerMenu();
		login.sign_Out();
	}

	@Given("User should be able to select the VBooks by clicking checkout cta")
	public void user_should_be_able_to_select_the_v_books_by_clicking_checkout_cta() {
		vbook.click_vbookcheckoutCTALibpage();
	}

	@Given("user checked out the VBooks Title and navigate to my self screen")
	public void user_checked_out_the_v_books_title_and_navigate_to_my_self_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
	}

	@Given("user have a VBook checkout")
	public void user_have_a_v_book_checkout() {
		Logger.log("user have a VBook checkout");
	}

	@When("user navigates to my stuff screen")
	public void user_navigates_to_my_stuff_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();

	}

	@When("user clicks on history pills")
	public void user_clicks_on_history_pills() {
		myshelfpage.Click_CheckoutHistory();
		Assert.assertTrue(myshelfpage.Nav_mystuffScreen.isDisplayed());
		Assert.assertTrue(myshelfpage.mystuff_checkouthistory.isDisplayed());
	}

	@Then("user should able to view primary CTA as Play")
	public void user_should_able_to_view_primary_cta_as_play() {
		Assert.assertTrue(myshelfpage.playas_primaryCTA.isDisplayed());
	}

	@Then("user click on secondary CTA")
	public void user_click_on_secondary_cta() {
		myshelfpage.click_playSecondaryCTADropdown();
	}

	@Then("user able to view secondary CTA options as Return and renew")
	public void user_able_to_view_secondary_cta_options_as_return_and_renew() {
		Assert.assertTrue(myshelfpage.playSecondaryCTA_Renew.isDisplayed());
		Assert.assertTrue(myshelfpage.playSecondaryCTA_Return.isDisplayed());
	}

	@Given("user have a VBook checkout and played then VBook")
	public void user_have_a_v_book_checkout_and_played_then_v_book() {
		Logger.log("user have a VBook checkout and played then VBook");
	}

	@Then("user should able to view primary CTA as Resume")
	public void user_should_able_to_view_primary_cta_as_resume() {
		myshelfpage.click_ResumeSecondaryCTADropdown();
	}
	
	@Then("user is able to view primary cta as resume")
	public void user_is_able_to_view_primary_cta_as_resume() {
	  Assert.assertTrue(myshelfpage.resumeAs_primaryCTA.isDisplayed());
	}
	
	@When("user clicks on checkout pills")
	public void user_clicks_on_checkout_pills() {
		myshelfpage.click_checkoutMyshelfpage();
		Assert.assertTrue(myshelfpage.Nav_mystuffScreen.isDisplayed());
		Assert.assertTrue(myshelfpage.mystuff_checkout.isDisplayed());
	}

	@Then("user should be able to view titles as grid view and sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_as_grid_view_and_sorted_by_latest_title_checked_out_first_by_default() {
		Assert.assertTrue(myshelfpage.vBookSecCheckoutGrid.isDisplayed());
		Assert.assertTrue(myshelfpage.videoSecCheckoutGrid.isDisplayed());
	}

	@Then("user should be able to click on title image and navigate to title detail screen")
	public void user_should_be_able_to_click_on_title_image_and_navigate_to_title_detail_screen() {
		myshelfpage.clickTitleCoverImage();
	}

	@Given("user have a video checkout")
	public void user_have_a_video_checkout() {
		Logger.log("user have a video checkout");
	}

	@Given("user have a video checkout and played then video")
	public void user_have_a_video_checkout_and_played_then_video() {
		Logger.log("user have a video checkout and played then video");
	}

	@Given("user have a video checkout and video was expired")
	public void user_have_a_video_checkout_and_video_was_expired() {
		Logger.log("user have a video checkout and video was expired");
	}

	@Then("user should able to view primary CTA as Remove")
	public void user_should_able_to_view_primary_cta_as_remove() {
		Assert.assertTrue(myshelfpage.removeAs_primaryCTA.isDisplayed());
	}

	@Then("user able to view secondary CTA options as Checkout")
	public void user_able_to_view_secondary_cta_options_as_checkout() {
		Assert.assertTrue(myshelfpage.Checkoutas_SecondaryCTA.isDisplayed());
	}

	@Given("user have a VBook checkout and Vbook was expired")
	public void user_have_a_v_book_checkout_and_vbook_was_expired() {
		Logger.log("user have a video checkout and video was expired");
	}

	@Given("user navigate to tier {int} page from library screen")
	public void user_navigate_to_tier_page_from_library_screen(Integer int1) {
		vbook.click_vbookcheckoutCTALibpage();
	}

	@Given("user tap to checkout in any titles from tiers screens")
	public void user_tap_to_checkout_in_any_titles_from_tiers_screens() {
		Logger.log("user tap to checkout in any titles from tier 1,2,3 screens");
	}

	@Given("user navigate to checkout category pills from Myshelf screen")
	public void user_navigate_to_checkout_category_pills_from_myshelf_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
	}

	@When("user can be view titles in My Stuff checkouts screen")
	public void user_can_be_view_titles_in_my_stuff_checkouts_screen() {
		Assert.assertTrue(myshelfpage.mystuff_Checkoutas_Titles.isDisplayed());
	}

	@Then("user can be view sort features with order based on A-Z,Recently checkedout and ratings")
	public void user_can_be_view_sort_features_with_order_based_on_a_z_recently_checkedout_and_ratings() {
		myshelfpage.click_MystuffSort_dropdwn();

	}

	@Then("user can be view only those titles based on selection from the sort dropdown")
	public void user_can_be_view_only_those_titles_based_on_selection_from_the_sort_dropdown() {
		myshelfpage.click_sortOptions();

	}

	@Then("user can be view search feature with keyword with existing functionality")
	public void user_can_be_view_search_feature_with_keyword_with_existing_functionality() {
		myshelfpage.click_SearchIcon();
	}

	@Then("user should be retrieve the titles which match the search keyword")
	public void user_should_be_retrieve_the_titles_which_match_the_search_keyword() {
//		Assert.assertTrue(myshelfpage.Mystuff_searchResultsTitle.isDisplayed());
	}

	@Then("user can be view list option in checkout search screen from My stuff")
	public void user_can_be_view_list_option_in_checkout_search_screen_from_my_stuff() {
//		Assert.assertTrue(myshelfpage.Mystuff_searchResults_Listview.isDisplayed());
	}

	@Then("user can be view filter feature with the dropdown options for All,ebook,eaudio,vbook and video")
	public void user_can_be_view_filter_feature_with_the_dropdown_options_for_all_ebook_eaudio_vbook_and_video() {
		myshelfpage.view_FilterOptions();
	}

	@Then("user should be able to view {string} titles selected by default upon landing on the checkout screen")
	public void user_should_be_able_to_view_titles_selected_by_default_upon_landing_on_the_checkout_screen(
			String string) {
		visibilityWait(myshelfpage.Mystuff_Filter_All);
		Assert.assertTrue(myshelfpage.Mystuff_Filter_All.isDisplayed());
	}

	@When("user can be view titles in My Stuff history screen")
	public void user_can_be_view_titles_in_my_stuff_history_screen() {
		Assert.assertTrue(myshelfpage.mystuff_Checkoutas_Titles.isDisplayed());
	}

	@Then("user can be view list option in history sort screen from My stuff")
	public void user_can_be_view_list_option_in_history_sort_screen_from_my_stuff() {

	}

	@Given("user navigate to checkout category pills from Myshelf history screen")
	public void user_navigate_to_checkout_category_pills_from_myshelf_history_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.Click_CheckoutHistory();

	}

	@Then("user can be view list option in history search screen from My stuff")
	public void user_can_be_view_list_option_in_history_search_screen_from_my_stuff() {

	}

	@Then("user should be able to view {string} titles selected by default upon landing on the history screen")
	public void user_should_be_able_to_view_titles_selected_by_default_upon_landing_on_the_history_screen(
			String string) {
		Assert.assertTrue(myshelfpage.Mystuff_Filter_All.isSelected());
	}

	@When("user can be view titles in My Stuff screen on each category")
	public void user_can_be_view_titles_in_my_stuff_screen_on_each_category() {

	}

	@Then("user can be view Sort,search filter feature titles for All,ebook,eaudio,vbook and video")
	public void user_can_be_view_sort_search_filter_feature_titles_for_all_ebook_eaudio_vbook_and_video() {

	}

	@Then("user should NOT be able to view any grid option for Checkout and history screen")
	public void user_should_not_be_able_to_view_any_grid_option_for_checkout_and_history_screen() {

	}

	@Then("user can be view list option in Checkout and history screen from My stuff")
	public void user_can_be_view_list_option_in_checkout_and_history_screen_from_my_stuff() {

	}

	/******************************************/

	@Then("user can be view combined section for eBook & eAudio,video and VBooks")
	public void user_can_be_view_combined_section_for_e_book_e_audio_video_and_v_books() {
		myshelfpage.view_CombaindSectioninMystuff();
	}

	@Then("user can be view titles listed as list view by default")
	public void user_can_be_view_titles_listed_as_list_view_by_default() {
		Assert.assertTrue(myshelfpage.mystuff_checkout_ListViewDefault.isDisplayed());
	}

	@Then("user can be view titles in checkout screen last read order by default")
	public void user_can_be_view_titles_in_checkout_screen_last_read_order_by_default() {
		Logger.log("user can be view titles in checkout screen last read order by default");
	}

	@Then("user can be view title cover image and title name and Author name on card")
	public void user_can_be_view_title_cover_image_and_title_name_and_author_name_on_card() {
//		Assert.assertTrue(myshelfpage.Mystuff_titleName.isDisplayed());
		Assert.assertTrue(myshelfpage.Mystuff_coverimg.isDisplayed());
	}

	@Then("user can be view title due date for checkout expiry and return date")
	public void user_can_be_view_title_due_date_for_checkout_expiry_and_return_date() {
		myshelfpage.view_title_ExpirydateAndRenewDate();
	}

	@Then("user can be view primary action for the title as a button")
	public void user_can_be_view_primary_action_for_the_title_as_a_button() {
		Assert.assertTrue(myshelfpage.primaryCTAMyStuff.isDisplayed());
	}

//	@Then("user can be view reading progress of the title as a progress bar as static")
//	public void user_can_be_view_reading_progress_of_the_title_as_a_progress_bar_as_static() {
//		Logger.log("user can be view reading progress of the title as a progress bar as static");
//	}
//
//	@Then("user can be view reading progress percentage on the card for checkout only")
//	public void user_can_be_view_reading_progress_percentage_on_the_card_for_checkout_only() {
//		Logger.log("user can be view reading progress percentage on the card for checkout only");
//	}

	@Then("user should be redirected to title detail page from checkout screen")
	public void user_should_be_redirected_to_title_detail_page_from_checkout_screen() {
		myshelfpage.clickTitleCoverImage();
	}

	@Then("user should be able to view titles as list view and sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_as_list_view_and_sorted_by_latest_title_checked_out_first_by_default() {
		Logger.log("By Default Titles are displayed in List View and sorted by latest title");
	}

	@Then("user can be view titles in checkout screen last listened order by default")
	public void user_can_be_view_titles_in_checkout_screen_last_listened_order_by_default() {

	}

	@Then("user can be view titles in checkout screen played latest title checked out order by default")
	public void user_can_be_view_titles_in_checkout_screen_played_latest_title_checked_out_order_by_default() {

	}

	@Then("user should be redirected to title detail page from history screen")
	public void user_should_be_redirected_to_title_detail_page_from_history_screen() {

	}
	
/*************************************VisualUI*********************************************************************************************/
	
	@Then("capture the screenshot of Video titles in grid view")
	public void capture_the_screenshot_of_video_titles_in_grid_view() {
	    eyes.checkWindow("VideoTitleInGridView");
	}

	@Then("capture the screenshot of title cover image and title name and Author name on card")
	public void capture_the_screenshot_of_title_cover_image_and_title_name_and_author_name_on_card() {
	    eyes.checkWindow("TitleCoverImageTitleNameAuthorName");
	}

	@Then("capture the screenshot of title cover image and title name and primary cta")
	public void capture_the_screenshot_of_title_cover_image_and_title_name_and_primary_cta() {
	    eyes.checkWindow("TitleCoverImageTitleNamePrimaryCTA");
	}

	@Then("capture the screenshot of filter and sort options in my stuff screen")
	public void capture_the_screenshot_of_filter_and_sort_options_in_my_stuff_screen() {
	    eyes.checkWindow("FilterAndSortOptionInMyShelfScreen");
	}

	@Then("capture the screenshot of combined section for eBook & eAudio,video and VBooks")
	public void capture_the_screenshot_of_combined_section_for_e_book_e_audio_video_and_v_books() {
	    eyes.checkWindow("CombinedSectionForEBookEeAudio,VideAndVBooks");
	}

	@Then("capture the screenshot of checkedout screen")
	public void capture_the_screenshot_of_checkedout_screen() {
	    eyes.checkWindow("CheckedoutScreen");
	}

	@Then("capture the screenshot of play as primary cta and return and renew are the secondary cta")
	public void capture_the_screenshot_of_play_as_primary_cta_and_return_and_renew_are_the_secondary_cta() {
	    eyes.checkWindow("PlayAsPrimaryCtaAndReturnAndRenewAsSecondaryCTA");
	}

	@Then("capture the screenshot of checked out titles section in My shelf screen")
	public void capture_the_screenshot_of_checked_out_titles_section_in_my_shelf_screen() {
	    eyes.checkWindow("CheckedoutScreenInMyShelfScreen");
	}

	@Then("capture the screenshot of primary CTA as Remove")
	public void capture_the_screenshot_of_primary_cta_as_remove() {
	    eyes.checkWindow("PrimaryCtaRemove");
	}

	

}
