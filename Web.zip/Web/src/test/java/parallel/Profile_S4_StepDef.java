package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyshelfvideosVbooks;
import pom.kidszone.Profile;
import pom.kidszone.ProfileS4;

public class Profile_S4_StepDef extends CommonAction {

	Profile old = new Profile(DriverManager.getDriver());
	ProfileS4 profileNew = new ProfileS4(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	MyshelfvideosVbooks myshelf = new MyshelfvideosVbooks(DriverManager.getDriver());

	@Then("user should be able to view Primary value in the Name field")
	public void user_should_be_able_to_view_primary_value_in_the_name_field() {
		Assert.assertTrue(old.generalProfile.isDisplayed());
	}

	@Then("user should be able to view {string} {string} {string} as the default display name under the avatars")
	public void user_should_be_able_to_view_as_the_default_display_name_under_the_avatars(String string, String string2,
			String string3) {
		Assert.assertTrue(old.generalProfile.isDisplayed());
		Assert.assertTrue(old.profileManagementPage_defaultprofile_teen.isDisplayed());
		Assert.assertTrue(old.profileManagementPage_defaultprofile_kid.isDisplayed());
	}

	@Then("user should be able to view profile icons for each profile type within the avatars")
	public void user_should_be_able_to_view_profile_icons_for_each_profile_type_within_the_avatars() {
		visibilityWait(profileNew.profileIcon.get(1));
		Assert.assertEquals(profileNew.profileIcon.size(), 3);
		Logger.log("User Able to View all three Profile Icons");
	}

	@Then("user should be able to view profile avatars in square shape")
	public void user_should_be_able_to_view_profile_avatars_in_square_shape() {
		Logger.log("User Able to View all three Profile Avatars in Square Shape");
	}

	@Then("user should be able to view profile avatar images with the profile type mentioned on a banner at all time at the bottom right corner")
	public void user_should_be_able_to_view_profile_avatar_images_with_the_profile_type_mentioned_on_a_banner_at_all_time_at_the_bottom_right_corner() {
		Assert.assertTrue(profileNew.primaryBottom.isDisplayed());
		Assert.assertTrue(profileNew.teenBottom.isDisplayed());
		Assert.assertTrue(profileNew.kidBottom.isDisplayed());
	}

	@Then("user should be able to NOT view back button CTAs for the first time they land on the profile homepage after registeration")
	public void user_should_be_able_to_not_view_back_button_ct_as_for_the_first_time_they_land_on_the_profile_homepage_after_registeration() {
		Assert.assertFalse(isElementPresent(old.backIcon));
	}

	@Then("user should be able to view {string} CTA at the center of the page below the profiles avatar")
	public void user_should_be_able_to_view_cta_at_the_center_of_the_page_below_the_profiles_avatar(String text) {
		Assert.assertTrue(profileNew.manageProfileIcon.isDisplayed());
		Assert.assertEquals(profileNew.manageProfileIcon.getText().contains(text), true);
	}

	@Then("user should be able to view link {string} cta")
	public void user_should_be_able_to_view_link_cta(String text) {
		javascriptScroll(profileNew.learnMoreAbout);
		Assert.assertTrue(profileNew.learnMoreAbout.isDisplayed());
		Assert.assertEquals(profileNew.learnMoreAbout.getText().contains(text), true);
		profileNew.clickLearMore();
		Assert.assertTrue(profileNew.aboutProfilePopUp.isDisplayed());
	}

	@Given("user should be able to view the profile avatar on the Header as a square shape 36X36 size")
	public void user_should_be_able_to_view_the_profile_avatar_on_the_header_as_a_square_shape_36x36_size() {
		Logger.log("Avatar Size will be verified Manually");
	}

	@Then("user should be able to view dropdown menu with all created profiles")
	public void user_should_be_able_to_view_dropdown_menu_with_all_created_profiles() {
		Assert.assertTrue(profileNew.teenProfileDropDown.isDisplayed());
		visibilityWait(profileNew.kidProfileDropDown);
		Assert.assertTrue(profileNew.kidProfileDropDown.isDisplayed());
	}

	@Then("user should be able to view any created profile in dropdown")
	public void user_should_be_able_to_view_any_created_profile_in_dropdown() {
		Logger.log("User able to view Profiles");
	}

	@Then("user should be able to view logout")
	public void user_should_be_able_to_view_logout() {
		Assert.assertTrue(profileNew.signOutDropDown.isDisplayed());
	}

	@Then("user should be able to view Manage Profiles")
	public void user_should_be_able_to_view_manage_profiles() {
		Assert.assertTrue(profileNew.manageProfileDropDown.isDisplayed());
	}

	@Then("user should be able to view Profile Settings option")
	public void user_should_be_able_to_view_profile_settings_option() {
		Assert.assertTrue(profileNew.settingsDropDown.isDisplayed());
	}

	@Given("user not set the my shelf as home screen")
	public void user_not_set_the_my_shelf_as_home_screen() {
		Logger.log("User not set the My Shelf as Home Screen");
	}

	@Given("user set the my shelf as home screen")
	public void user_set_the_my_shelf_as_home_screen() {
		Logger.log("User is already set the My Shelf as Home Screen");
	}

	@Then("user should not be able to redirect to my library screen")
	public void user_should_not_be_able_to_redirect_to_my_library_screen() {
		Assert.assertFalse(isElementPresent(old.libraryPage));
	}

	@Then("user should be able to redirect to the myshelf screen")
	public void user_should_be_able_to_redirect_to_the_myshelf_screen() {
		WaitForWebElement(profileNew.myShelfPage);
		Assert.assertTrue(profileNew.myShelfPage.isDisplayed());
	}

	@When("user clicks kid profile for old UI")
	public void user_clicks_kid_profile_for_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
		profileNew.click_Kidprofile();
		waitFor(2000);
		
	}

	@When("user clicks teen profile for old UI")
	public void user_clicks_teen_profile_for_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
		profileNew.click_Teenprofile();
		waitFor(2000);
	}
	
	@Then("user clicks on adult profile for old UI")
	public void user_clicks_on_adult_profile_for_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
	}

	@When("user clicks on hamburger menu option")
	public void user_clicks_on_hamburger_menu_option() {
		login.click_NewMenu();
	}

	@Then("user should not be able to view profile option")
	public void user_should_not_be_able_to_view_profile_option() {
		Assert.assertFalse(isElementPresent(login.getLink_Profiles()));
	}

	@Then("user should be able to click any profile under the dropdown")
	public void user_should_be_able_to_click_any_profile_under_the_dropdown() {
		profileNew.clickTeenDropDownwithPin();
	}

	@Then("user should not be able to view the {string}")
	public void user_should_not_be_able_to_view_the(String string) {
		Assert.assertFalse(isElementPresent(old.profilePin_popup));
	}

	@Then("user should be able to navigated to the home page")
	public void user_should_be_able_to_navigated_to_the_home_page() {
		WaitForWebElement(old.libraryPage);
		Assert.assertTrue(old.libraryPage.isDisplayed());
	}

	@Then("user should not be able to view the profile which they are on in the dropdown for Primary")
	public void user_should_not_be_able_to_view_the_profile_which_they_are_on_in_the_dropdown_for_primary() {
		old.click_closeIcon();
		profileNew.clickProfileAvatar();
		Assert.assertFalse(isElementPresent(profileNew.primaryProfileDropDown));
	}

	@Then("user should be able to view the enter the Pin screen")
	public void user_should_be_able_to_view_the_enter_the_pin_screen() {
		WaitForWebElement(old.profilePin_popup);
		Assert.assertTrue(old.profilePin_popup.isDisplayed());
	}

	@When("user clicks on cancel CTA from the profile list page")
	public void user_clicks_on_cancel_cta_from_the_profile_list_page() {
	   old.clickCancel();
	}

	@Then("user should be able to navigate to the manage profile screen")
	public void user_should_be_able_to_navigate_to_the_manage_profile_screen() {
		Assert.assertTrue(old.profileListPage.isDisplayed());
	}

	@Then("user should be able to view the created profiles in profile list screen")
	public void user_should_be_able_to_view_the_created_profiles_in_profile_list_screen() {
		Assert.assertTrue(old.teenProfile.isDisplayed());
		Assert.assertTrue(old.kidProfile.isDisplayed());
	}

	@Then("user should be able to view {string} cta")
	public void user_should_be_able_to_view_cta(String string) {
		Assert.assertTrue(profileNew.addProfileCTA.isDisplayed());
	}

	@Then("user should be able to navigate to the my profile screen")
	public void user_should_be_able_to_navigate_to_the_my_profile_screen() {
		Assert.assertTrue(old.profileEditSection.isDisplayed());
	}

	@Then("user should be able to view the profile details in my profile screen")
	public void user_should_be_able_to_view_the_profile_details_in_my_profile_screen() {
		Assert.assertTrue(old.profileEditSection.isDisplayed());
	}

	@Then("user should be able to edit the profile details in my profile screen")
	public void user_should_be_able_to_edit_the_profile_details_in_my_profile_screen() {
		Assert.assertTrue(old.profileEditSection.isDisplayed());
	}

	@Then("user should be able to view the signout cta")
	public void user_should_be_able_to_view_the_signout_cta() {
		Assert.assertTrue(profileNew.signOutDropDown.isDisplayed());
	}

	@Then("user should be able to click on the sign out cta to logout")
	public void user_should_be_able_to_click_on_the_sign_out_cta_to_logout() {
		profileNew.clicksignOutDropDown();
	}

	@Then("user logout from the application")
	public void user_logout_from_the_application() {
		Logger.log("User Log out from the application");
	}

	@Then("user should be able to click any kid profile under the dropdown")
	public void user_should_be_able_to_click_any_kid_profile_under_the_dropdown() {
		profileNew.clickKidDropDownwithPin();
	}

	@When("user deletes the {string} profile if maximum profiles reached")
	public void user_deletes_the_profile_if_maximum_profiles_reached(String name) {
		//profileNew.deleteProfileIfMaximum(name);
		profileNew.deleteProfile_max();
	}

	@When("user click the add profile icon")
	public void user_click_the_add_profile_icon() {
		profileNew.clickAddProfile();
	}

	@When("user select the kid profile")
	public void user_select_the_kid_profile() {
		profileNew.clickAddKid();
	}

	@When("user enter the profile name {string} and click save cta")
	public void user_enter_the_profile_name_and_click_save_cta(String name) {
		profileNew.createKid(name);
	}

	@Then("user should be able to view the newly created kid profile with profile type")
	public void user_should_be_able_to_view_the_newly_created_kid_profile_with_profile_type() {
		Logger.log("User able to view the created profile in Profile");
	}

	@Then("profile PIN will not be mandatory to create a profile")
	public void profile_pin_will_not_be_mandatory_to_create_a_profile() {
		Logger.log("User created profile without PIN");
	}

	@Then("user logged out of the application")
	public void user_logged_out_of_the_application() {

	}

//	@Given("user clicks on Primary Profile")
//	public void user_clicks_on_primary_profile() {
//	login.select_Adultprofilewithpenicon();
//
//	}
//
//	@Given("user clicks on Teen Profile")
//	public void user_clicks_on_teen_profile() {
//	login.click_Teenprofile();
//
//	}
//
//	@Given("user clicks on Kid Profile")
//	public void user_clicks_on_kid_profile() {
//	login.select_Kidprofilewithpenicon();
//
//	}

	@Given("user navigates into the profile landing screen")
	public void user_navigates_into_the_profile_landing_screen() {
		visibilityWait(old.Nav_profileManagementPage);
		old.Nav_profileManagementPage.isDisplayed();
	}

	@Given("user click on the manage profile pin cta")
	public void user_click_on_the_manage_profile_pin_cta() {
		old.clickEditIcon();
	}

	@When("user selects the profile")
	public void user_selects_the_profile() {
		old.edit_Adultprofile();
	}

	@When("user navigate into the profile details screen")
	public void user_navigate_into_the_profile_details_screen() {
		visibilityWait(old.profile_details);
		Assert.assertTrue(old.profile_details.isDisplayed());
	}

	@When("user changes the settings in the profile details page")
	public void user_changes_the_settings_in_the_profile_details_page() {
		old.Edit_DisplayName();
	}

	@When("user click on back cta without saving the changes")
	public void user_click_on_back_cta_without_saving_the_changes() {
		old.clickBackIcon();
	}

	@When("user should be able view the popup {string}")
	public void user_should_be_able_view_the_popup(String verbiage) {
		Assert.assertEquals(old.Leavepagepopup_content.getText().contains(verbiage), true);
	}

	@When("user should be able to view {string} and {string} cta")
	public void user_should_be_able_to_view_and_cta(String string, String string2) {
		Assert.assertTrue(old.saveAlertPopUpLeave.isDisplayed());
		Assert.assertTrue(old.cancelBtn.isDisplayed());
	}

	@When("user selects the cancel cta on the popup")
	public void user_selects_the_cancel_cta_on_the_popup() {
		visibilityWait(old.cancelBtn);
		jsClick(old.cancelBtn);

	}

	@Then("popup should be dismissed")
	public void popup_should_be_dismissed() {
		inVisibilityWait(old.Leavepagepopup_content);

	}

	@When("systen should be displays the enter profile pin popup")
	public void systen_should_be_displays_the_enter_profile_pin_popup() {
		Assert.assertTrue(old.profilePin_popup.isDisplayed());
	}

	@When("user selects the forgot pin cta in the popup")
	public void user_selects_the_forgot_pin_cta_in_the_popup() {
		old.clickForgotPinCta();
	}

	@Then("user should be able to view Forgot Profile pin prompt which will have send email CTA")
	public void user_should_be_able_to_view_forgot_profile_pin_prompt_which_will_have_send_email_cta() {
		visibilityWait(old.sendmail_forgetpin);
		jsClick(old.sendmail_forgetpin);
		waitFor(3000);
	}

	@Then("user should be able to view the one-time prompt received on the registered email ID.")
	public void user_should_be_able_to_view_the_one_time_prompt_received_on_the_registered_email_id() {
		Assert.assertTrue(profileNew.emailid_resetpin.isDisplayed());
	}

	@Then("user should be able to view notification that lets them know they will receive an email for  if they input the wrong one time PIN {string}")
	public void user_should_be_able_to_view_notification_that_lets_them_know_they_will_receive_an_email_for_if_they_input_the_wrong_one_time_pin(
			String Pin) {
		old.Enter_setPin(Pin);
	}

	@Then("user should be able to view pop up {string} that lets them know they will receive an email for reset PIN if they input the wrong PINs")
	public void user_should_be_able_to_view_pop_up_that_lets_them_know_they_will_receive_an_email_for_reset_pin_if_they_input_the_wrong_pi_ns(
			String string) {

	}

	@Then("user should be able to receive an email {string} from library giving them one time PIN reset new PIN")
	public void user_should_be_able_to_receive_an_email_from_library_giving_them_one_time_pin_reset_new_pin(
			String string) {

	}

	@Given("user navigates to the Profile Settings page")
	public void user_navigates_to_the_profile_settings_page() {
		visibilityWait(old.profile_details);
		Assert.assertTrue(old.profile_details.isDisplayed());
	}

	@Given("user enable the pin {string} and {string}")
	public void user_enable_the_pin_and(String pin, String confirmpin) {
		javascriptScroll(profileNew.universal_Toggle);
		jsClick(profileNew.universal_Toggle);
		waitFor(2000);
		old.click_EnableprofilePin();
		old.Enter_setPin(pin);
		old.click_submit();
		old.Enter_setPin(confirmpin);
		old.click_submit();
		old.click_SaveBtn();
	}

	@When("user disables the PIN")
	public void user_disables_the_pin() {
		old.clickDisablePin();
	}

	@When("user enter the pin {string} and click done cta")
	public void user_enter_the_pin_and_click_done_cta(String confirmpin) {
		old.Enter_setPin(confirmpin);
		old.click_submit();
		old.click_SaveBtn();
	}

	@When("user able to view the confirmation popup")
	public void user_able_to_view_the_confirmation_popup() {
		visibilityWait(old.errorAlertEmailPopUp);
		Assert.assertTrue(old.errorAlertEmailPopUp.isDisplayed());
	}

	@When("user tap on the Yes cta on the popup and click save cta")
	public void user_tap_on_the_yes_cta_on_the_popup_and_click_save_cta() {
		old.disablePinOK();
	}

	@Then("user able to Enables it again, the Enabling process starts from Scratch.")
	public void user_able_to_enables_it_again_the_enabling_process_starts_from_scratch() {
		old.click_EnableprofilePin();
	}

	@Then("system should displays the enter profile pin popup")
	public void system_should_displays_the_enter_profile_pin_popup() {
		visibilityWait(profileNew.createNewPin_popup);
		Assert.assertEquals(profileNew.createNewPin_popup.isDisplayed(), true);
	}

	@Then("user enters the pin {string} and confirm pin {string} both are match")
	public void user_enters_the_pin_and_confirm_pin_both_are_match(String newpin, String Newconfirmpin) {
		old.Enter_setPin(newpin);
		old.click_submit();
		old.Enter_setPin(Newconfirmpin);
		old.click_submit();

	}

	@Then("user able to create the profile pin successfullye")
	public void user_able_to_create_the_profile_pin_successfullye() {
		old.click_SaveBtn();
	}

	@Then("system SHOULD NOT remember the old PIN once disabled.")
	public void system_should_not_remember_the_old_pin_once_disabled() {
		Logger.log("System should not remember the old pin once disabled");
	}

	@Then("user should be able to view the first popup {string}")
	public void user_should_be_able_to_view_the_first_popup(String verbiage) {
		visibilityWait(old.errorAlertEmailPopUp);
		Assert.assertEquals(profileNew.disablepopup_content.getText().equalsIgnoreCase(verbiage), true);
	}

	@Then("user tap on the Yes cta on the popup")
	public void user_tap_on_the_yes_cta_on_the_popup() {
		old.disablePinOK();
	}

	@Then("user would be prompted to enter PIN to confirm the action")
	public void user_would_be_prompted_to_enter_pin_to_confirm_the_action() {
		Assert.assertEquals(profileNew.disablepopup_input_disablepin.isDisplayed(), true);
	}

	@Given("user selects the enable profile pin toggle cta")
	public void user_selects_the_enable_profile_pin_toggle_cta() {
		old.click_EnableprofilePin();
	}

	@Then("system should show the create profile pin popup with done cta")
	public void system_should_show_the_create_profile_pin_popup_with_done_cta() {
		visibilityWait(profileNew.createNewPin_popup);
		Assert.assertEquals(profileNew.createNewPin_popup.isDisplayed(), true);
		Assert.assertTrue(old.setPinDoneButton.isDisplayed());
	}

	@Then("user enter the pin {string} and confirm pin {string}")
	public void user_enter_the_pin_and_confirm_pin(String pin, String confirmpin) {
		old.Enter_setPin(pin);
		old.click_submit();
		old.Enter_setPin(confirmpin);
		old.click_submit();
	}

	@Then("user should be able to view the entered pin less than a second")
	public void user_should_be_able_to_view_the_entered_pin_less_than_a_second() {
		Logger.log("user should be able to view the entered pin less than a second");
	}

	@Then("user should be able to view the enable Done cta")
	public void user_should_be_able_to_view_the_enable_done_cta() {
		Assert.assertTrue(isElementPresent(old.AlreadyEnablePin));
	}

	@When("user enters wrong PIN {string}")
	public void user_enters_wrong_pin(String wrongpin) {
		old.Enter_setPin(wrongpin);
		old.click_submit();
	}

	@Then("user should not be able to view toast messages instead see inline errors within the pop up box")
	public void user_should_not_be_able_to_view_toast_messages_instead_see_inline_errors_within_the_pop_up_box() {
		visibilityWait(profileNew.wrongpin_content);
		Assert.assertEquals(profileNew.wrongpin_content.isDisplayed(), true);
	}

	@Then("user should be able to see {string} as profile type in my profile screen")
	public void user_should_be_able_to_see_as_profile_type_in_my_profile_screen(String type) {
		Assert.assertTrue(profileNew.profileAgeRange.isDisplayed());
		Assert.assertTrue(profileNew.profileAgeRange.getText().contains(type));
	}
	
	@Then("user should be able to view {string} checkout limit,hold limit,purchase request limit")
	public void user_should_be_able_to_view_checkout_limit_hold_limit_purchase_request_limit(String profiletype) {
	   profileNew.verify_profileDetails(profiletype);
	}

	@When("user clicks on Primary profile in dropdown")
	public void user_clicks_on_primary_profile_in_dropdown() {
		profileNew.clickPrimaryDropDown();
	}

	@When("user clicks on Teen profile in dropdown")
	public void user_clicks_on_teen_profile_in_dropdown() {
		profileNew.clickTeenDropDown();
	}

	@Then("user clicks on Kid profile in dropdown")
	public void user_clicks_on_kid_profile_in_dropdown() {
		profileNew.clickKidDropDown();
	}

	@Then("user should be able to view {string} same size and shape as avatar")
	public void user_should_be_able_to_view_same_size_and_shape_as_avatar(String string) {
		Assert.assertTrue(profileNew.addProfileCTA.isDisplayed());
	}

	@Then("user should be able to view the back cta")
	public void user_should_be_able_to_view_the_back_cta() {
		Assert.assertTrue(profileNew.backCta_manageProfScreen.isDisplayed());
	}

	@When("user clicks on the Profiles option in Old UI menu screen")
	public void user_clicks_on_the_profiles_option_in_old_ui_menu_screen() {
		login.click_HamburgerMenu();
		login.menu_adultProfile();
	}

	@When("user clicks the manage profile in dropdown")
	public void user_clicks_the_manage_profile_in_dropdown() {
		profileNew.clickManageProfDropDown();
	}

	@Then("user should not be able to view {string} cta")
	public void user_should_not_be_able_to_view_cta(String string) {
		Logger.log("Add profile is not shown for teen or kid profiles");
	}

	@Then("user should be able to view {string} in dropdown")
	public void user_should_be_able_to_view_in_dropdown(String string) {
		Assert.assertTrue(profileNew.manageProfileDropDown.isDisplayed());
	}

	@Then("user should be able to view {string} available in dropdown")
	public void user_should_be_able_to_view_available_in_dropdown(String string) {
		Assert.assertTrue(profileNew.settingsDropDown.isDisplayed());
	}

	@Then("user should be able to view Logout option")
	public void user_should_be_able_to_view_logout_option() {
		Assert.assertTrue(profileNew.signOutDropDown.isDisplayed());
	}

	@Then("user should not be able to view teen profile which they are on in the dropdown")
	public void user_should_not_be_able_to_view_teen_profile_which_they_are_on_in_the_dropdown() {
		Assert.assertFalse(isElementPresent(profileNew.teenProfileDropDown));
	}

	@Then("user should be able to click any profile other than teen profile under the dropdown")
	public void user_should_be_able_to_click_any_profile_other_than_teen_profile_under_the_dropdown() {
		profileNew.clickKidDropDownwithPin();
	}

	@Then("teen user should be able to view dropdown menu with all created profiles")
	public void teen_user_should_be_able_to_view_dropdown_menu_with_all_created_profiles() {
		Assert.assertTrue(profileNew.primaryProfileDropDown.isDisplayed());
		Assert.assertTrue(profileNew.kidProfileDropDown.isDisplayed());
	}

	@Then("user enters the {string} in the field")
	public void user_enters_the_in_the_field(String pin) {
		old.Enter_setPin(pin);
		old.click_submit();
	}

	@Then("user should be able to click any created profile in dropdown")
	public void user_should_be_able_to_click_any_created_profile_in_dropdown() {
		profileNew.clickTeenDropDownwithPin();
	}

	@Then("kid user should be able to view the created profiles in the dropdown")
	public void kid_user_should_be_able_to_view_the_created_profiles_in_the_dropdown() {
		Assert.assertTrue(profileNew.primaryProfileDropDown.isDisplayed());
		Assert.assertTrue(profileNew.teenProfileDropDown.isDisplayed());
	}

	@Then("user should not be able to view kid profile which they are on in the dropdown")
	public void user_should_not_be_able_to_view_kid_profile_which_they_are_on_in_the_dropdown() {
		Assert.assertFalse(isElementPresent(profileNew.kidProfileDropDown));
	}

	@Then("user create a teen profile if no teen profile available")
	public void user_create_a_teen_profile_if_no_teen_profile_available() {
		profileNew.createTeenIfUnavailable("Teen");
	}

	@Then("user create a kid profile if no kid profile available")
	public void user_create_a_kid_profile_if_no_kid_profile_available() {
		profileNew.createKidIfUnavailable("Kid");
	}

	@Then("system to check if the  email is set up, if NO, then user should NOT be able to set PIN")
	public void system_to_check_if_the_email_is_set_up_if_no_then_user_should_not_be_able_to_set_pin() {
		visibilityWait(old.myprofilepage_email);
		Assert.assertEquals(old.myprofilepage_email.getText().contains(""), false);
	}

	@Then("user should be able to view a prompt to add mandatory data I.e. Email before they can set a PIN")
	public void user_should_be_able_to_view_a_prompt_to_add_mandatory_data_i_e_email_before_they_can_set_a_pin() {
		old.click_EnableprofilePin();
		visibilityWait(profileNew.withoutEmail_enablepin_verbiage);
		Assert.assertTrue(profileNew.withoutEmail_enablepin_verbiage.isDisplayed());
		Logger.log("user is able to view the email is mandatory data");

	}

	@When("user should be able to view the {string} checkbox")
	public void user_should_be_able_to_view_the_checkbox(String verbiage) {
		visibilityWait(profileNew.universal_Toggle);
		javascriptScroll(profileNew.universal_Toggle);
		Assert.assertTrue(profileNew.universal_Toggle.getText().contains(verbiage));
	}

	@Then("user should be able to enable the {string} checkbox")
	public void user_should_be_able_to_enable_the_checkbox(String string) {
		jsClick(profileNew.universal_Toggle);
		waitFor(2000);
		Logger.log("user is enabled the universal toggle");
	}

	@Then("user should be able to save the changes by clicking the {string} CTA")
	public void user_should_be_able_to_save_the_changes_by_clicking_the_cta(String string) {
		old.click_SaveBtn();
	}

	@Then("user clicks on back CTA")
	public void user_clicks_on_back_cta() {
//		DriverManager.getDriver().navigate().back();
//		waitFor(2000);
		old.clickBackIcon();
	}
	
	@Then("user clicks on browser back CTA")
	public void user_clicks_on_browser_back_cta() {
		//DriverManager.getDriver().navigate().back();
		old.click_closeIcon();
		old.clickBackIcon();
		waitFor(2000);
	}

	@Then("user should be able to view the {string} toggle button in active state")
	public void user_should_be_able_to_view_the_toggle_button_in_active_state(String string) {
		javascriptScroll(old.Enablepin_txt);
		Assert.assertTrue(old.Enablepin_txt.isDisplayed());
	}

	@Given("user is disabled state if the {string} checkbox")
	public void user_is_disabled_state_if_the_checkbox(String string) {
		javascriptScroll(profileNew.universal_Toggle);
		waitFor(2000);
		Assert.assertEquals(profileNew.universal_Toggle.isDisplayed(), true);
		waitFor(3000);
	}

	@Then("user should able to view {string} toggle button in the disabled state")
	public void user_should_able_to_view_toggle_button_in_the_disabled_state(String string) {
		Assert.assertFalse(isElementPresent(old.Enablepin_txt));
	}

	@When("user switch the adult to teen profile in the profile landing screen")
	public void user_switch_the_adult_to_teen_profile_in_the_profile_landing_screen() {
		profileNew.click_Teenprofile();
	}

	@When("user enter the unlimited incorrect pin {string} attempts profile pin")
	public void user_enter_the_unlimited_incorrect_pin_attempts_profile_pin(String incorrectpin) {
		old.enter_invalidPin_Unlimited(incorrectpin);
	}

	@Then("user should be able to allow to enter the {string} unlimited PIN attempts for the profile")
	public void user_should_be_able_to_allow_to_enter_the_unlimited_pin_attempts_for_the_profile(String incorrectpin) {
		old.enter_invalidPin_Unlimited(incorrectpin);
		Logger.log("user should be able to allow to enter the incorrectpin unlimited pin attempts");
	}

	@Then("user should be able to see inline error within the pop up instead stating {string} verbiage")
	public void user_should_be_able_to_see_inline_error_within_the_pop_up_instead_stating_verbiage(
			String inlineErrormsg) {
		visibilityWait(profileNew.wrongpin_content);
		Assert.assertEquals(profileNew.wrongpin_content.getText().equalsIgnoreCase(inlineErrormsg), true);
	}

	@Then("user should have an option to use {string} CTA in the pop up at any point if required")
	public void user_should_have_an_option_to_use_cta_in_the_pop_up_at_any_point_if_required(String string) {
		Assert.assertTrue(profileNew.forgetpin_CTA.isDisplayed());
	}

	@Given("user already set the profile pin for the kid profile")
	public void user_already_set_the_profile_pin_for_the_kid_profile() {
		visibilityWait(old.profilePin_popup);
		Logger.log("Pin Enable already in kid profile");
	}

	@When("user enters the pin {string} and click submit cta")
	public void user_enters_the_pin_and_click_submit_cta(String Pin) {
		old.enterPin(Pin);
		old.click_submit();
	}

	@When("user disable the profile pin toggle")
	public void user_disable_the_profile_pin_toggle() {
		javaScriptScrollToEnd();
		old.clickDisablePin();
		old.disablePinOK();
	}

	@When("user navigate into the enter profile pin screen")
	public void user_navigate_into_the_enter_profile_pin_screen() {
		visibilityWait(profileNew.disable_pinpopup);
	}

	@When("user switch the adult profile to teen profile")
	public void user_switch_the_adult_profile_to_teen_profile() {
		// DriverManager.getDriver().navigate().back();
		waitFor(2000);
		old.clickEditIcon();
		profileNew.click_Teenprofile();
	}

	@Then("system should show the enter profile {string} popup with done cta")
	public void system_should_show_the_enter_profile_popup_with_done_cta(String pin) {
		old.click_EnableprofilePin();
		old.enterPin(pin);
		Assert.assertTrue(isElementPresent(old.setPinDoneButton));
	}

	@Then("user tap on the cancel cta on the popup")
	public void user_tap_on_the_cancel_cta_on_the_popup() {
		old.click_closeIcon();
		waitFor(2000);
		javaScriptScrollToEnd();
		old.clickDisablePin();
		old.clickCancelBtn();
	}

	@Then("user should not be able to view the prompted to enter PIN to confirm the action")
	public void user_should_not_be_able_to_view_the_prompted_to_enter_pin_to_confirm_the_action() {
		Assert.assertTrue(isElementPresent(old.AlreadyEnablePin));

	}

	@Then("user should be able to enable the {string} toggle button and enter {string}")
	public void user_should_be_able_to_enable_the_toggle_button_and_enter(String string, String pin) {
		javascriptScroll(profileNew.email_checkbox);
		jsClick(profileNew.email_checkbox);
		jsClick(old.Enablepin_txt);
		old.enterPin(pin);
		old.click_submit();
		old.enterPin(pin);
		old.click_submit();
	}

	@Then("kid user should be able to enable the {string} toggle button and enter {string}")
	public void kid_user_should_be_able_to_enable_the_toggle_button_and_enter(String string, String pin) {
		jsClick(old.Enablepin_txt);
		old.enterPin(pin);
		old.click_submit();
		old.enterPin(pin);
		old.click_submit();
	}

	@When("user select the Teen profile")
	public void user_select_the_teen_profile() {
		profileNew.click_AddTeen();
	}

	@Then("user should be able to view the newly created teen profile with profile type")
	public void user_should_be_able_to_view_the_newly_created_teen_profile_with_profile_type() {
		Logger.log("User able to view the created profile in Profile");
	}

	@When("user reached the profile limit {string}")
	public void user_reached_the_profile_limit(String string) {
		profileNew.createTeenIfUnavailable(string);
	}

	@Then("user should not be able to view the add profile icon")
	public void user_should_not_be_able_to_view_the_add_profile_icon() {
		Assert.assertFalse(isElementPresent(profileNew.addProfileCTA));
	}

	@Then("user clicks on leave page cta")
	public void user_clicks_on_leave_page_cta() {
		DriverManager.getDriver().navigate().back();
		jsClick(old.deleteConfirmOk);
	}
	
	//197381
	
		@Then("adult user enables universal pin for all profiles")
		public void adult_user_enables_universal_pin_for_all_profiles() {
			jsClick(profileNew.universal_Toggle);
			old.click_SaveBtn();
			old.clickBackIcon();
		}
		
		@Then("teen user enable the pin {string} and {string}")
		public void teen_user_enable_the_pin_and(String pin, String confirmpin) {
			old.click_EnableprofilePin();
			old.Enter_setPin(pin);
			old.click_submit();
			old.Enter_setPin(confirmpin);
			old.click_submit();
			old.click_SaveBtn();
		}
		
		@Then("user enables same email as adult checkbox")
		public void user_enables_same_email_as_adult_checkbox() {
		    old.clickSameAsAdult();
		}
		
		@When("user enable the pin in OldUI {string} and {string}")
		public void user_enable_the_pin_in_old_ui_and(String pin, String confirmpin) {
			old.click_EnableprofilePin();
			old.Enter_setPin(pin);
			old.click_submit();
			old.Enter_setPin(confirmpin);
			old.click_submit();
			old.click_SaveBtn();
		}
		
		@Then("user enables universal pin for all profiles")
		public void user_enables_universal_pin_for_all_profiles() {
			jsClick(profileNew.universal_Toggle);
			//old.click_SaveBtn();
		}
		
		@Then("user closes the pin popup")
		public void user_closes_the_pin_popup() {
		    //login.closePopUp();
			old.click_closeIcon();
		}
		

		@Then("Teen user should be able to click any created profile in dropdown")
		public void teen_user_should_be_able_to_click_any_created_profile_in_dropdown() {
			profileNew.clickKidDropDownwithPin();
		}
		
		@When("user switch to other profile and search the title")
		public void user_switch_to_other_profile_and_search_the_title() {
			String get_videosAndVbookTitleName = myshelf.get_videosAndVbookTitleName();
			profileNew.clickProfileAvatar();
			profileNew.clickKidDropDown();
			myshelf.searchtitle(get_videosAndVbookTitleName);
		}
}
