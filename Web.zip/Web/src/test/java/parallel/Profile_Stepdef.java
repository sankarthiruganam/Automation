package parallel;

import java.util.List;
import java.util.Map;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Profile;
import pom.kidszone.ProfileS4;

import org.junit.Assert;

public class Profile_Stepdef extends CommonAction {
	private static final String DisplayName = null;
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	Profile profile = new Profile(DriverManager.getDriver());
	ProfileS4 profileNew = new ProfileS4(DriverManager.getDriver());

	/*******************************************************/
	
	@When("user closes the preference pop up")
	public void user_closes_the_preference_pop_up() {
	    login.preferenceScreen_popup();
	}
	
	
	@Given("user enters the new libraryid {string} and click on Sign in button")
	public void user_enters_the_new_libraryid_and_click_on_sign_in_button(String loginid) {
		login.enter_loginIdonly(loginid);
	}

	@Then("user should not able to view the profile selection in the registration screen")
	public void user_should_not_able_to_view_the_profile_selection_in_the_registration_screen() {
		visibilityWait(profile.reg_registrationpopupheading);
		Assert.assertEquals(isElementPresent(profile.label_adult), false);
		Assert.assertEquals(isElementPresent(profile.label_Teen), false);
		Assert.assertEquals(isElementPresent(profile.label_kid), false);
	}

	@Then("user should be able to view registration screen with {string} {string} {string} {string} and {string} fields")
	public void user_should_be_able_to_view_registration_screen_with_and_fields(String string, String string2,
			String string3, String string4, String string5) {
		Assert.assertTrue(profile.view_RegistrationPopup());
	}

	@Given("user enters the new libraryid {string} and pin {string} click on sign in button")
	public void user_enters_the_new_libraryid_and_pin_click_on_sign_in_button(String loginid, String pin) {
		login.enter_loginwithPin(loginid, pin);
	}

	@Then("user should be able to view registration screen with {string} {string} {string} {string} {string} and {string} fields")
	public void user_should_be_able_to_view_registration_screen_with_and_fields(String string, String string2,
			String string3, String string4, String string5, String string6) {
		Assert.assertTrue(profile.view_RegistrationPopupwithpassword());
	}

	@Given("user clicks on {string} CTA in sign in screen")
	public void user_clicks_on_cta_in_sign_in_screen(String string) {
		profile.click_adminPassword();
	}

	@Given("user enters the  {string} and click on register button")
	public void user_enters_the_and_click_on_register_button(String password) {
		profile.Enter_Newuserpassword(password);
	}

	@When("user submitting the registation form with {string} field value and displayame field is left blank")
	public void user_submitting_the_registation_form_with_field_value_and_displayame_field_is_left_blank(
			String DisplayName) {
		WaitForWebElement(profile.reg_DisplayName);
		profile.Enter_DisplayName(DisplayName);
	}

	@When("user entering the Security answer {string} and emaiID {string} in emailID field and clicking the register button")
	public void user_entering_the_security_answer_and_emai_id_in_email_id_field_and_clicking_the_register_button(
			String SecurityAnswer, String email) {
		profile.enterEmailandSecurity(SecurityAnswer, email);
	}

//	@When("user submitting the registation form with {string} and emailID \"test@autoexp.com\"field value and displayame field is left blank")
//	public void user_submitting_the_registation_form_with_and_email_id_test_autoexp_com_field_value_and_displayame_field_is_left_blank(String string) {
//
//	}

	@Then("user should be navigated to profile landing screen and able to view the Admin, Teen and Kid profiles created by default")
	public void user_should_be_navigated_to_profile_landing_screen_and_able_to_view_the_admin_teen_and_kid_profiles_created_by_default() {
		visibilityWait(profile.Nav_profileManagementPage);
		Assert.assertTrue(profile.view_DefaultProfiles_withoutDisplayName());
	}

	@Then("user should be able to view Teen profile with Teen as the Title name")
	public void user_should_be_able_to_view_teen_profile_with_teen_as_the_title_name() {
		visibilityWait(profile.profileManagementPage_defaultprofile_teen);
		Assert.assertTrue(profile.profileManagementPage_defaultprofile_teen.isDisplayed());
	}

	@Then("user should be able to view Kid profile with Kid as the Title name")
	public void user_should_be_able_to_view_kid_profile_with_kid_as_the_title_name() {
		visibilityWait(profile.profileManagementPage_defaultprofile_kid);
		Assert.assertTrue(profile.profileManagementPage_defaultprofile_kid.isDisplayed());
	}

	@Then("user should be able to view Admin value in the Name field")
	public void user_should_be_able_to_view_admin_value_in_the_name_field() {
		visibilityWait(profile.profileManagementPage_defaultprofile_admin);
		Assert.assertTrue(profile.profileManagementPage_defaultprofile_admin.isDisplayed());
	}

	@Then("user clicks on + icon and enter the {string} and save the profile")
	public void user_clicks_on_icon_and_enter_the_and_save_the_profile(String newteenprofile) {
		profile.create_TeenProfile(newteenprofile);

	}

	@Then("user should be see the fourth profile in the profile screen")
	public void user_should_be_see_the_fourth_profile_in_the_profile_screen() {
		int size = profile.manageProf_lbl_profType.size();
		if (size == 4) {
			Logger.log("user should be see the fourth profile in the profile screen");
		}
	}

	@Then("user user clicks on + icon and enter the {string} and save the profile")
	public void user_user_clicks_on_icon_and_enter_the_and_save_the_profile(String NewKidprofile) {
		profile.create_KidProfile(NewKidprofile);
		// profile.clickCancelBtn();
	}

	@Then("user should not able to see + icon after fifth profile creation in profile screen")
	public void user_should_not_able_to_see_icon_after_fifth_profile_creation_in_profile_screen() {
		Assert.assertEquals(isElementPresent(profile.Manageprofile_plusIcon), false);
		Logger.log("user is not able to view 5th profile");
	}

	@Then("user should be able to view {string} value in the Name field")
	public void user_should_be_able_to_view_value_in_the_name_field(String AdultName) {
		profile.View_AdultNameFielf(AdultName);
	}

	@Then("user should not able to see + icon after fifth profile creation")
	public void user_should_not_able_to_see_icon_after_fifth_profile_creation() {
		visibilityWait(profile.manageProf_tooltip);
		Assert.assertEquals(isElementPresent(profile.Manageprofile_plusIcon), false);
		Logger.log("user is not able to view 5th profile");
	}

	@When("user submitting the registation form with {string} and {string} field value and display name field is left blank")
	public void user_submitting_the_registation_form_with_and_field_value_and_display_name_field_is_left_blank(
			String SecurityAnswer, String PIN) {
		profile.Enter_RegDetailswithoutEmailOldUI(SecurityAnswer, PIN);
	}

	@When("user submitting the registation form with {string} {string} and {string} field value")
	public void user_submitting_the_registation_form_with_and_field_value(String displayNmae, String SecurityAnswer,
			String PIN) {
		profile.Enter_RegDetailsOldUI(displayNmae, SecurityAnswer, PIN);
	}

	@Given("user clicks on the {string} section in the popup")
	public void user_clicks_on_the_section_in_the_popup(String string) {
		profile.click_adminPassword();
	}

	@Given("user provides the {string} and click on register button")
	public void user_provides_the_and_click_on_register_button(String password) {
		profile.Enter_Newuserpassword(password);
	}

	@When("user submitting the registation form with {string} {string} {string} and {string} field value")
	public void user_submitting_the_registation_form_with_and_field_value(String username, String password,
			String SecurityAnswer, String DisplayName) {
		profile.Enter_RegDetails_IdWithpassword(username, password, SecurityAnswer, DisplayName);
	}

	@Given("user clicks on the Profiles option in the menu screen")
	public void user_clicks_on_the_profiles_option_in_the_menu_screen() {
		login.click_HamburgerMenu();
		login.click_Profiles();
	}

	@When("user is on profile screen")
	public void user_is_on_profile_screen() {
		Assert.assertTrue(login.getProfilePage().isDisplayed());
	}

	@When("user clicks on edit option")
	public void user_clicks_on_edit_option() {
		profile.clickEditIcon();
	}

	@Then("user should be able to view edit icon on all the profiles")
	public void user_should_be_able_to_view_edit_icon_on_all_the_profiles() {
		WaitForWebElement(profile.getEditIcon().get(0));
		Assert.assertEquals(profile.getEditIcon().size(), profileNew.profilesIconsListed.size());
//		Assert.assertTrue(profile.getEditIcon().get(0).isDisplayed());
	}

	@Then("user should be able to view cancel option")
	public void user_should_be_able_to_view_cancel_option() {
		Assert.assertTrue(profile.getCancelIcon().isDisplayed());
		waitFor(2000);
	}

	@Then("user select the first teen profile")
	public void user_select_the_first_teen_profile() {
		profileNew.click_Teenprofile();
	}

	@Then("user should be navigated to profile details screen")
	public void user_should_be_navigated_to_profile_details_screen() {
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
	}

	@Then("user clicks on the delete profile cta")
	public void user_clicks_on_the_delete_profile_cta() {
		profile.clickDeleteButton();
	}

	@Then("user provides the {string} in pin screen")
	public void user_provides_the_in_pin_screen(String pin) {
		profile.click_EnableprofilePin();
		profile.enterPin(pin);
		ClickOnWebElement(profile.setPinDoneButton);
	}

	@Then("user should be see restricted from deleting the first teen profile")
	public void user_should_be_see_restricted_from_deleting_the_first_teen_profile() {
		profile.deleteProfileRestrict();
	}

	@Then("user select the first kid profile")
	public void user_select_the_first_kid_profile() {
		// login.select_Kidprofile();
		profileNew.click_Kidprofile();
	}

	@Then("user should be see restricted from deleting the first kid profile")
	public void user_should_be_see_restricted_from_deleting_the_first_kid_profile() {
		profile.deleteProfileRestrict();
		login.closePopUp();
	}

	@Then("user select the teen profile oldUI")
	public void user_select_the_teen_profile_old_ui() {
	}

	@Then("user provide the {string} in the pin screen")
	public void user_provide_the_in_the_pin_screen(String pin) {
		profile.click_EnableprofilePin();
		profile.enterPin(pin);
		jsClick(profile.setPinDoneButton);
		profile.enterPin(pin);
		jsClick(profile.setPinDoneButton);
		ClickOnWebElement(profile.cancelBtn);
		login.preferenceScreen_popup();
		WaitForWebElement(profile.profileEditSection);
	}

	@Then("user should be see restricted from deleting the new teen profile")
	public void user_should_be_see_restricted_from_deleting_the_new_teen_profile() {
		profile.deleteProfileRestrict();
	}

	@Then("user click on cancel button and disabled the edit icon")
	public void user_click_on_cancel_button_and_disabled_the_edit_icon() {
		profile.clickCancel();
	}

	@Then("user create a {string} kid profile with pin enabled if kid profile is not there")
	public void user_create_a_kid_profile_with_pin_enabled_if_kid_profile_is_not_there(String Kid) {
		profile.createKidProfileWithPin(Kid);
		// profile.enableKidPin();
	}

	@Then("user create a {string} kid profile with pin {string} enabled if kid profile is not there")
	public void user_create_a_kid_profile_with_pin_enabled_if_kid_profile_is_not_there(String kid, String pin) {
		profile.createKidProfileWithPin(kid);
//		profile.enableKidPin(pin);
	}

	@Then("user select the new kid profile")
	public void user_select_the_new_kid_profile() {
		login.select_Kidprofile();
	}

	@Then("user should be see the first kid profile deleted in profile screen")
	public void user_should_be_see_the_first_kid_profile_deleted_in_profile_screen() {
		Assert.assertTrue(profile.deleteProfilePopUp.isDisplayed());
	}

	@Then("user should be able to view the toast message {string}")
	public void user_should_be_able_to_view_the_toast_message(String string) {
		profile.deleteProfile(string);
	}

	@Then("user should be navigates into the profile list screen")
	public void user_should_be_navigates_into_the_profile_list_screen() {
		visibilityWait(profile.profileListPage);
		Assert.assertTrue(profile.profileListPage.isDisplayed());
	}

	@Then("user should be see the new kid profile deleted in profile screen")
	public void user_should_be_see_the_new_kid_profile_deleted_in_profile_screen() {
		Assert.assertTrue(profile.deleteProfilePopUp.isDisplayed());
	}

	@Then("user should be see restricted from deleting the new kid profile")
	public void user_should_be_see_restricted_from_deleting_the_new_kid_profile() {
		profile.deleteProfileRestrict();
	}

	@Then("user should be see the first teen profile deleted in profile screen")
	public void user_should_be_see_the_first_teen_profile_deleted_in_profile_screen() {
		Assert.assertTrue(profile.deleteProfilePopUp.isDisplayed());
	}

	@Then("user select the new teen profile")
	public void user_select_the_new_teen_profile() {
		login.select_Teenprofile();
	}

	@Then("user should be see the new teen profile deleted in profile screen")
	public void user_should_be_see_the_new_teen_profile_deleted_in_profile_screen() {
		Assert.assertTrue(profile.deleteProfilePopUp.isDisplayed());
	}

//	@When("user is on profile detail screen")
//    public void user_is_on_profile_detail_screen() throws Throwable {
//		login.click_HamburgerMenu();
//		login.click_Profiles();
//		profile.clickEditIcon();
//		profile.edit_Adultprofile();
//    }

	@Given("user Enter the and {string} and {string}")
	public void user_enter_the_and_and(String DisplayName, String Email) {
		//profile.Enter_RegDetailswithEmail(SecurityAns, DisplayName, Email);
		profile.nyc_enter_RegDetailswithEmail(DisplayName,  Email);
//		profile.clickEditIcon();
//		profile.edit_Adultprofile();
	}

	@Given("user Enter the {string} and {string}")
	public void user_enter_the_and(String SecurityAns, String DisplayName) {
		profile.Enter_RegDetailsWithoutpassword(SecurityAns, DisplayName);
		profile.clickEditIcon();
		profile.edit_Adultprofile();
	}

	@Then("user should be able to view set PIN option")
	public void user_should_be_able_to_view_set_pin_option() {
		visibilityWait(profile.enableProfilePin);
		Assert.assertTrue(profile.enableProfilePin.isDisplayed());
	}

	@Given("user click on profile icon")
	public void user_click_on_profile_icon() {
		profile.clickProfile();
	}

	@Then("user should be able to view set PIN as optional and not mandatory for all three profiles")
	public void user_should_be_able_to_view_set_pin_as_optional_and_not_mandatory_for_all_three_profiles() {
		Logger.log("user should be able to view set PIN as optional and not mandatory for all three profiles");
	}

	@Then("system to check if the security question AND email is set up, if YES, then user should be able to set PIN")
	public void system_to_check_if_the_security_question_and_email_is_set_up_if_yes_then_user_should_be_able_to_set_pin() {
		visibilityWait(profile.myprofilepage_email);
		// Assert.assertTrue(!profile.myprofilepage_email.getText().contains(""));
//		Assert.assertEquals(profile.myprofilepage_email.getText().contains(""), false);
		// profile.view_EmailAndSecurityAns();
	}

//	@Then("user should be able to be redirected to a screen where they can set a {int} digit PIN")
//	public void user_should_be_able_to_be_redirected_to_a_screen_where_they_can_set_a_digit_pin(Integer int1) {
//		profile.click_EnableprofilePin();
//	}

	@Then("user should be able to be redirected to a screen where they can set a {int} digit PIN")
	public void user_should_be_able_to_be_redirected_to_a_screen_where_they_can_set_a_digit_pin(Integer int1) {
		profile.click_EnableprofilePin();

	}

	@Then("system should redirect the user to PIN Confirmation page and ask the user to enter the {string} again to enter {string} whether the matches with the already entered PIN")
	public void system_should_redirect_the_user_to_pin_confirmation_page_and_ask_the_user_to_enter_the_again_to_enter_whether_the_matches_with_the_already_entered_pin(
			String Pin, String confirmpin) {
		profile.Enter_setPin(Pin);
		profile.click_submit();
		profile.Enter_setPin(confirmpin);
		profile.click_submit();

	}

	@Then("system should redirect the user to PIN Confirmation page and ask the user to enter the {string} again to enter {string} whether the matches")
	public void system_should_redirect_the_user_to_pin_confirmation_page_and_ask_the_user_to_enter_the_again_to_enter_whether_the_matches(
			String Pin, String ConfirmPIN) {
		profile.click_EnableprofilePin();
		profile.Enter_setPin(Pin);
		profile.click_submit();
		profile.Enter_setPin(ConfirmPIN);
		profile.click_submit();
		profile.click_SaveBtn();
		waitFor(3000);
		profile.clickDisablePin();
		profile.disablePinOK();
		profile.Enter_setPin(ConfirmPIN);
		profile.click_submit();
	}

	@Then("system should throw error message if the PIN doesn't match")
	public void system_should_throw_error_message_if_the_pin_doesn_t_match() {
		visibilityWait(profile.pin_mismatch_errormsg);
		Assert.assertEquals(isElementPresent(profile.pin_mismatch_errormsg), true);
		Logger.log("system should throw error message if the PIN doesn't match");
		profile.click_closeIcon();
	}

	@Then("user should be able to click on browser back button to navigate back to previous screen to re-enter the PIN again")
	public void user_should_be_able_to_click_on_browser_back_button_to_navigate_back_to_previous_screen_to_re_enter_the_pin_again() {
		profile.clickBackIcon();
	}

	@Then("user should be able to edit email at a later time once PIN is set but can't leave it blank")
	public void user_should_be_able_to_edit_email_at_a_later_time_once_pin_is_set_but_can_t_leave_it_blank() {

	}

	@Then("user should be able to edit security question at a later time once PIN is set but can't leave it blank")
	public void user_should_be_able_to_edit_security_question_at_a_later_time_once_pin_is_set_but_can_t_leave_it_blank() {

	}

	@Then("{string} Option should be Editable for the Adult profile")
	public void option_should_be_editable_for_the_adult_profile(String string) {
		visibilityWait(profile.AutomaticallyCheckout_checkbox);
		Assert.assertTrue(profile.AutomaticallyCheckout_checkbox.isDisplayed());

	}

	@Then("{string}  button should have info icon with tooltip")
	public void button_should_have_info_icon_with_tooltip(String string) {
		visibilityWait(profile.AutomaticallyCheckout_Tooltip);
		Assert.assertTrue(profile.AutomaticallyCheckout_Tooltip.isDisplayed());

	}

	@Then("system to check if the security question AND email is set up, if NO, then user should NOT be able to set PIN")
	public void system_to_check_if_the_security_question_and_email_is_set_up_if_no_then_user_should_not_be_able_to_set_pin() {
		visibilityWait(profile.myprofilepage_email);
		Assert.assertTrue(profile.myprofilepage_email.getText().contains(""));
	}

	@When("system to check if the security question AND email is set up, if NO, then kid user should NOT be able to set PIN")
	public void system_to_check_if_the_security_question_and_email_is_set_up_if_no_then_kid_user_should_not_be_able_to_set_pin() {
		visibilityWait(profile.myprofilepage_email);
		Assert.assertEquals(isElementPresent(profile.myprofilepage_email), false);
	}

	@Then("user should be able to view a prompt to add mandatory data I.e. Email and Security question before they can set a PIN")
	public void user_should_be_able_to_view_a_prompt_to_add_mandatory_data_i_e_email_and_security_question_before_they_can_set_a_pin() {
		profile.clickEnablePinWOEmail();
//		profile.closeEmailAlertPopUp();
	}

	@Then("No Email alert PopUp should have the verbiage {string}")
	public void no_email_alert_pop_up_should_have_the_verbiage(String verbiage) {
		Assert.assertTrue(profile.noEmailAlertPopUp.getText().contains(verbiage));
		profile.closeEmailAlertPopUp();
		jsClick(profile.deleteConfirmOk);
		profile.click_SaveBtn();
	}

	@Then("kid user No Email alert PopUp should have the verbiage {string}")
	public void kid_user_no_email_alert_pop_up_should_have_the_verbiage(String verbiage) {
		Assert.assertTrue(profile.noEmailAlertPopUp.getText().contains(verbiage));
		jsClick(profile.deleteConfirmOk);
		profile.click_SaveBtn();
	}

	@Then("user should be enter {string} ,{string} and {string}")
	public void user_should_be_enter_and(String Email, String Securityanswer, String string3) {
		jsClick(profile.deleteConfirmOk);
		profile.view_EmailAndSecurityAns(Email, Securityanswer);

	}

	@Then("user tap on the save cta and system should displays the success prompt toast message")
	public void user_tap_on_the_save_cta_and_system_should_displays_the_success_prompt_toast_message() {
		profile.click_SaveBtn();

	}

	@Then("system to check if the security question AND email is set up for the teen profile, if YES, then user should be able to set PIN in the Teen profile detail screen")
	public void system_to_check_if_the_security_question_and_email_is_set_up_for_the_teen_profile_if_yes_then_user_should_be_able_to_set_pin_in_the_teen_profile_detail_screen() {
		visibilityWait(profile.Teenprofile_email);
		String text = profile.Teenprofile_email.getText();
		System.out.println(text);
		Assert.assertEquals(profile.Teenprofile_email.getText(), text);
	}

	@Then("system to check if the security question AND email is set up for the adult profile, if YES, then user should be able to set PIN in the Teen profile detail screen")
	public void system_to_check_if_the_security_question_and_email_is_set_up_for_the_adult_profile_if_yes_then_user_should_be_able_to_set_pin_in_the_teen_profile_detail_screen() {
		visibilityWait(profile.myprofilepage_email);
		Assert.assertTrue(!profile.myprofilepage_email.getText().contains(""));
	}

	@Then("user should be able to view a notification popup  to add mandatory data I.e. Email and Security question for the adult profile before they can set a PIN in the Kid manage profile screen")
	public void user_should_be_able_to_view_a_notification_popup_to_add_mandatory_data_i_e_email_and_security_question_for_the_adult_profile_before_they_can_set_a_pin_in_the_kid_manage_profile_screen() {
		profile.click_AddEmailOrSecurityAnsPopup();
	}

	@Then("{string} Option should be Editable for the teen profile")
	public void option_should_be_editable_for_the_teen_profile(String string) {
		javascriptScroll(profile.AutomaticallyCheckout_checkbox);
		Assert.assertTrue(profile.AutomaticallyCheckout_checkbox.isEnabled());
	}

	@Then("teen user should not view the Email, Security Question and Answer fields")
	public void teen_user_should_not_view_the_email_security_question_and_answer_fields() {
		Assert.assertEquals(isElementPresent(profile.Teenprofile_email), true);
		Logger.log("Teen user not view the Email, only view parent email");
		Assert.assertEquals(isElementPresent(profile.teenprofile_securityAns_input), false);
		Logger.log("Teen user not view the Security Question");

	}

	@Then("system to check if the security question AND email is set up for the adult profile, if NO, then user should NOT be able to set PIN")
	public void system_to_check_if_the_security_question_and_email_is_set_up_for_the_adult_profile_if_no_then_user_should_not_be_able_to_set_pin() {

	}

	@Then("user should be able to view a notification popup  to add mandatory data I.e. Email and Security question for the adult profile before they can set a PIN in the teen manage profile screen")
	public void user_should_be_able_to_view_a_notification_popup_to_add_mandatory_data_i_e_email_and_security_question_for_the_adult_profile_before_they_can_set_a_pin_in_the_teen_manage_profile_screen() {

	}

	@Then("system to check if the security question AND email is set up for the adult profile, if YES, then user should be able to set PIN in the kid profile detail screen")
	public void system_to_check_if_the_security_question_and_email_is_set_up_for_the_adult_profile_if_yes_then_user_should_be_able_to_set_pin_in_the_kid_profile_detail_screen() {

	}

	@Then("{string} Option should be Editable for the kid profile")
	public void option_should_be_editable_for_the_kid_profile(String string) {
		Assert.assertEquals(profile.AutomaticallyCheckout_checkbox.isDisplayed(), true);
		Logger.log("Automatically Checkout checkbox is not editable for a kid profile");
	}

	@Then("kid user should not view the Email, Security Question and Answer fields")
	public void kid_user_should_not_view_the_email_security_question_and_answer_fields() {

	}

	@Given("user tap on teen option")
	public void user_tap_on_teen_option() {
		login.select_Teenprofile();
	}

	@Given("user already set the profile pin for the teen profile")
	public void user_already_set_the_profile_pin_for_the_teen_profile() {
		WaitForWebElement(profile.profilePin_popup);
		Logger.log("Pin Enable already in Teen profile");
	}

	@When("user enable the {string} flag from my profile screen")
	public void user_enable_the_flag_from_my_profile_screen(String string) {
		profile.verifySameAsAdult();
	}

	@Then("teen user should be able to view the adult email id in the check box")
	public void teen_user_should_be_able_to_view_the_adult_email_id_in_the_check_box() {
		Logger.log("user able to view the same email as adult in email ID placeholder");
	}

	@Then("user should be able to enable the email notification for the teen user using adult mail id")
	public void user_should_be_able_to_enable_the_email_notification_for_the_teen_user_using_adult_mail_id() {
		profile.enableEmailNotify();
	}

	@Then("teen user should be able to view their notification to adult mail id")
	public void teen_user_should_be_able_to_view_their_notification_to_adult_mail_id() {
		Logger.log("Email Verification will be done manually");
	}

	@Given("user clicks on Adult profile")
	public void user_clicks_on_adult_profile() {
		profile.click_AdultProfile();
	}

	@When("user tap on kid option")
	public void user_tap_on_kid_option() {
		login.select_Kidprofile();
	}
	
	@Given("user enters the profile pin {string}")
	public void user_enters_the_profile_pin(String pin) {
		profile.enterPin(pin);
		ClickOnWebElement(profile.setPinDoneButton);
		waitFor(2000);
	}
	
	@Given("user enters the registration details for {string} and {string}")
     public void user_enters_the_registration_details_for_and(String SecurityAns, String DisplayName) {
        profile.Enters_RegistrationDetails(SecurityAns, DisplayName);
     }
	
	@Given("user enters the registration details for pin {string} {string} and {string} and {string}")
	public void user_enters_the_registration_details_for_pin_and_and(String displayNmae, String SecurityAnswer, String PIN, String Email) {
		profile.Enter_RegDetailsOldUIWithEmail(displayNmae, SecurityAnswer,PIN,Email );
	}
	
	@Given("user enters the registration details for pin without email id {string} {string} and {string}")
	public void user_enters_the_registration_details_for_pin_without_email_id_and(String displayNmae, String SecurityAnswer, String PIN) {
		profile.Enter_RegDetailsOldUIWithoutEmail(displayNmae,SecurityAnswer,PIN);
	}
	
	
	@When("user should be able to view {string} cta next to save button")
	public void user_should_be_able_to_view_cta_next_to_save_button(String string) {
	    Assert.assertTrue(profile.CancelMyBoundlessAccount.isDisplayed());
	}

   @Then("user should be able to click the {string} cta next to save button")
	public void user_should_be_able_to_click_the_cta_next_to_save_button(String string) {
	    profile.click_CancelBoundlessAccountCta();
	}
   
   @Given("primary user should have entered email id")
   public void primary_user_should_have_entered_email_id() {
	   Logger.log("Primary user have email id");
   }

   @Then("user should be ale to view the {string} checkbox is enabled state to check if the primary user have the email")
   public void user_should_be_ale_to_view_the_checkbox_is_enabled_state_to_check_if_the_primary_user_have_the_email(String string) {
       visibilityWait(profile.PrimaryEmail_enable);
       Assert.assertTrue(profile.PrimaryEmail_enable.isDisplayed());
   }

   @Then("user should be able to check the checkbox")
   public void user_should_be_able_to_check_the_checkbox() {
       jsClick(profile.PrimaryEmail_enable);
       Logger.log("user should be ablt to check the checkbox");
       
   }

   @Then("user should be able to view the the primary user mail id in the email box")
   public void user_should_be_able_to_view_the_the_primary_user_mail_id_in_the_email_box() {
      visibilityWait(profile.ParentEmail);
      Assert.assertTrue(profile.ParentEmail.isDisplayed());
   }

   @Given("primary user should not have entered email id")
   public void primary_user_should_not_have_entered_email_id() {
	   Logger.log("Primary user don't have entered email id");
   }

   @Then("user should be able to view the {string} checkbox is disabled state to check if the primary user don't have the email")
   public void user_should_be_able_to_view_the_checkbox_is_disabled_state_to_check_if_the_primary_user_don_t_have_the_email(String string) {
	   visibilityWait(profile.PrimaryEmail_disabled);
       Assert.assertTrue(profile.PrimaryEmail_disabled.isDisplayed());
   }

   @Then("user should not able to check the checkbox")
   public void user_should_not_able_to_check_the_checkbox() {
	   Logger.log("user should not able to check the checkbox");
   }
   
   
   @Given("user should navigate to the Add profile screen")
	public void user_should_navigate_to_the_add_profile_screen() {
	  Assert.assertEquals(profile.addProfilePage.isDisplayed(), true);
	}

	@Given("user should view the {string} and {string} CTA")
	public void user_should_view_the_and_cta(String teen, String kid) {
		visibilityWait(profile.Createprofile_label_AddaTeen);
	 Assert.assertEquals(profile.Createprofile_label_AddaTeen.getText().contains(teen), true);  
	 Assert.assertEquals(profile.Createprofile_label_AddaKid.getText().contains(kid), true);
	}

	@When("user clicks on the Add a Teen CTA")
	public void user_clicks_on_the_add_a_teen_cta() {
	   profile.clickAddATeen();
	}

	@When("user should navigate to the Teen's profile setting screen")
	public void user_should_navigate_to_the_teen_s_profile_setting_screen() {
		visibilityWait(profile.Teen_DetailsScreen);
	   Assert.assertTrue(profile.Teen_DetailsScreen.isDisplayed());
	}
	
	@Then("user should able to view the {string} with {string} and {string} CTA")
	public void user_should_able_to_view_the_with_and_cta(String verbiage, String cancel, String LeavePage) {
		Assert.assertEquals(profile.Leavepagepopup_content.getText().contains(verbiage), true);
		Assert.assertTrue(profile.cancelBtn.getText().contains(cancel));
		Assert.assertTrue(profile.deleteConfirmOk.getText().contains(LeavePage));
	}
	

  @When("user clicks on the {string} CTA")
  public void user_clicks_on_the_cta(String string) {
   jsClick(profile.cancelBtn);
	   
  }
  
  @When("user should be able to fill the details like {string} and {string} click on Save")
  public void user_should_be_able_to_fill_the_details_like_and_click_on_save(String displayName, String Email) {
	   profile.enter_ProfileDetails(displayName, Email);
	   profile.click_SaveBtn();
  }
  
  @When("user enters the display name {string}")
  public void user_enters_the_display_name(String displayName) {
	   profile.enter_KidprofileDetails(displayName);
  }

  @Then("user by clicking on Cancel system should stay back in same page")
  public void user_by_clicking_on_cancel_system_should_stay_back_in_same_page() {
  Assert.assertTrue(profile.profileEditSection.isDisplayed());
	   
  }

  @Then("user should navigate to the previous page")
  public void user_should_navigate_to_the_previous_page() {
  
	   
  } 
  
  @When("user clicks on the Add a Kid CTA")
  public void user_clicks_on_the_add_a_kid_cta() {
   profile.clickAddAKid();
  }

  @When("user should navigate to the Kid's profile setting screen")
  public void user_should_navigate_to_the_kid_s_profile_setting_screen() {
    Assert.assertTrue(profile.kid_DetailsScreen.isDisplayed());
  }
  
  @When("User click add profile icon")
  public void user_click_add_profile_icon() {
    profile.clickPlusIcon();
  }

  @When("User should view the add a profile screen page")
  public void user_should_view_the_add_a_profile_screen_page() {
     visibilityWait(profile.AddanAdult_addProfile);
     Assert.assertTrue(profile.AddanAdult_addProfile.isDisplayed());
  }

  @When("User click the {string} cta")
  public void user_click_the_cta(String string) {
    profile.click_AddanAdultProfile();
  }

  @When("User should view the adult profile detail page for newly added adult profile")
  public void user_should_view_the_adult_profile_detail_page_for_newly_added_adult_profile() {
     Assert.assertTrue(profile.profile_details.isDisplayed());
  }

  @When("User click the profile icon edit icon")
  public void user_click_the_profile_icon_edit_icon() {
     profile.click_Editicon();
  }

  @When("User should get the avatars page")	
  public void user_should_get_the_avatars_page() {
    Assert.assertEquals(profile.avatarPage.isDisplayed(), true);
  }

  @When("User click the upload photo cta from avatar page and select the photos")
  public void user_click_the_upload_photo_cta_from_avatar_page_and_select_the_photos() {
	   Assert.assertTrue(isElementPresent(profile.upload_photo));
    
  }

  @When("System should display the newly added profile picture")
  public void system_should_display_the_newly_added_profile_picture() {
    jsClick(profile.avatar_img);
    visibilityWait(profile.profile_details);
  }

  @When("User should enter the valid display name {string}")
  public void user_should_enter_the_valid_display_name(String displayName) {
	   profile.enter_DisplayName(displayName);
  }

  @When("User should view the {string} cta should be dissabled")
  public void user_should_view_the_cta_should_be_dissabled(String Autocheckout) {
	  javascriptScroll(profile.Autocheckout);
	   Assert.assertEquals(profile.Autocheckout.getText().contains(Autocheckout), true);
  }

  @When("User shoul enable the checkbox of {string} checkbox with information icon")
  public void user_shoul_enable_the_checkbox_of_checkbox_with_information_icon(String EmailNotification) {
	   Assert.assertEquals(profile.Email_notication.getText().contains(EmailNotification), true);
  }

  @When("User should be navigated to enable email notifications information overlay with okay button")
  public void user_should_be_navigated_to_enable_email_notifications_information_overlay_with_okay_button() {
    jsClick(profile.Email_notication);
    visibilityWait(profile.errorAlertEmailPopUpCloseCTA);
    jsClick(profile.errorAlertEmailPopUpCloseCTA);
  }

  @When("User should view the {string} cta")
  public void user_should_view_the_cta(String verbiage) {
    profile.profileDetails_verbiage(verbiage);
  }

  @When("User click save button and get the {string} message")
  public void user_click_save_button_and_get_the_message(String string) {
     profile.click_SaveBtn();
     visibilityWait(profile.sucessMsg);
     Assert.assertTrue(profile.sucessMsg.isDisplayed());
  }
  


}
