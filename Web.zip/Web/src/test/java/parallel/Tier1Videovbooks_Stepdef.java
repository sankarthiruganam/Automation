package parallel;

import java.util.List;
import java.util.Map;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.MyshelfvideosVbooks;
import pom.kidszone.SearchResults_Vbooks;
import pom.kidszone.Tier1_Videobooks;
import pom.kidszone.Tier3_Videobooks;

import org.junit.Assert;

public class Tier1Videovbooks_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	Tier3_Videobooks tier3 = new Tier3_Videobooks(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	MyshelfvideosVbooks myshelf = new MyshelfvideosVbooks(DriverManager.getDriver());
	Tier1_Videobooks tier1 = new Tier1_Videobooks(DriverManager.getDriver());
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());

	/*******************************************************/

	@When("user should be navigate to video tier {int} screen")
	public void user_should_be_navigate_to_video_tier_screen(Integer int1) {
		if (int1 == 1) {
			video.clickVideoSeeAll();
		} else if (int1 == 2) {
			video.click_SeeAllTier1Video();
		}
	}

	@Then("user should be able to view Tier {int} page with Feature hero banner with colored background")
	public void user_should_be_able_to_view_tier_page_with_feature_hero_banner_with_colored_background(Integer int1) {
		tier1.verify_featuredBannerBackgroundColor();
	}

	@Then("user should be able to view specific number of video cards in the hero banner as per configured by admin")
	public void user_should_be_able_to_view_specific_number_of_video_cards_in_the_hero_banner_as_per_configured_by_admin() {

	}

	@Then("user should be able to view videos in the carousel format")
	public void user_should_be_able_to_view_videos_in_the_carousel_format() {
		visibilityWait(video.getLib_videoCarousel_CardCarouselType());
		javascriptScroll(video.getLib_videoCarousel_CardCarouselType());
		Assert.assertTrue(video.getLib_videoCarousel_CardCarouselType().isDisplayed());
	}

	@Then("User should be able to view these Videos with different categories")
	public void user_should_be_able_to_view_these_Videos_with_different_categories() {
		visibilityWait(tier1.mylibrary_categoryies_video);
		// javascriptScroll(tier1.mylibrary_categoryies_video);
		Assert.assertTrue(isElementPresent(tier1.mylibrary_categoryies_video));
		waitFor(2000);
	}

	@Then("User should be able to view each category covering with individual carousel configured in admin portal")
	public void user_should_be_able_to_view_each_category_covering_with_individual_carousel_configured_in_admin_portal() {
		Logger.log("User should be able to view each category covering with individual carousel");
	}

	@Then("User should be able to be able to view specific number of Vbooks in the carousel set by Admin in My library Management Admin page")
	public void user_should_be_able_to_be_able_to_view_specific_number_of_vbooks_in_the_carousel_set_by_admin_in_my_library_management_admin_page() {
		Logger.log(
				"User should be able to be able to view specific number of Vbooks in the carousel set by Admin in My library Management Admin page");
	}

	@Then("User should be able to view left & right arrow to swipe left & right side in the carousel")
	public void user_should_be_able_to_view_left_right_arrow_to_swipe_left_right_side_in_the_carousel() {
		tier1.view_LeftAndRightArrowinVideoCarousel();
	}

	@Then("User should be navigate to listing page after click See All able to click on see all to navigate to listing page")
	public void user_should_be_navigate_to_listing_page_after_click_see_all_able_to_click_on_see_all_to_navigate_to_listing_page() {
		video.clickVideoSeeAll();
	}

	@When("user should be able to view video title tier {int} page")
	public void user_should_be_able_to_view_video_title_tier_page(Integer int1) {
		video.clickVideoSeeAll();
		Assert.assertTrue(video.getLib_videoCarousel_tier1_Featuredcarousel().isDisplayed());
		Logger.log("User navigates to video title tier1 page");

	}

	@Then("user should be able to view categories in the Tier {int} page in carousel format")
	public void user_should_be_able_to_view_categories_in_the_tier_page_in_carousel_format(Integer int1) {
		visibilityWait(tier1.Tier1_category_carousel);
		javascriptScroll(tier1.Tier1_category_carousel);
		Assert.assertTrue(tier1.Tier1_category_carousel.isDisplayed());
	}

	@Then("user should be able to view the categories with see all option")
	public void user_should_be_able_to_view_the_categories_with_see_all_option() {
		visibilityWait(tier1.Tier1_categorycarousel_SeeAllCTA);
		javascriptScroll(tier1.Tier1_categorycarousel_SeeAllCTA);
		Assert.assertTrue(tier1.Tier1_categorycarousel_SeeAllCTA.isDisplayed());
	}

	@Then("user can navigate to Tier {int} page after clicking see all option")
	public void user_can_navigate_to_tier_page_after_clicking_see_all_option(Integer int1) {
		tier1.click_categoryCarousel_SeeAllCTA();

	}

	@Then("user should be able to view the tier2 categories icon which is shared by B&T")
	public void user_should_be_able_to_view_the_tier2_categories_icon_which_is_shared_by_b_t() {
		visibilityWait(tier1.tier2_videos_categoryIcon);
		Assert.assertTrue(tier1.tier2_videos_categoryIcon.isDisplayed());
	}

	@Then("user should be able to view categories in the Tier {int} page in the carousel format")
	public void user_should_be_able_to_view_categories_in_the_tier_page_in_the_carousel_format(Integer int1) {
		visibilityWait(tier1.Tier1_category_carousel);
		javascriptScroll(tier1.Tier1_category_carousel);
		Assert.assertTrue(tier1.Tier1_category_carousel.isDisplayed());
	}

	@Then("user should be able to view the carousels with see all option")
	public void user_should_be_able_to_view_the_carousels_with_see_all_option() {
		visibilityWait(tier1.Tier1_categorycarousel_SeeAllCTA);
		javascriptScroll(tier1.Tier1_categorycarousel_SeeAllCTA);
		Assert.assertTrue(tier1.Tier1_categorycarousel_SeeAllCTA.isDisplayed());
	}

	@Then("user navigate to Tier {int} page from clicking see all option")
	public void user_navigate_to_tier_page_from_clicking_see_all_option(Integer int1) {
		video.clickVideoSeeAll();
	}

	@Then("user navigate to Tier two page from clicking see all option")
	public void user_navigate_to_tier_two_page_from_clicking_see_all_option() {
		video.click_SeeAllTier1Video();
	}

	@When("user should be able to view vBookss level {int} page")
	public void user_should_be_able_to_view_v_bookss_level_page(Integer int1) {
		vbook.click_vbookSeeAllCTA();
	}

	@Then("user should be able to view Tier {int} page with Feature hero banner in the top as per configured by admin in Drupal")
	public void user_should_be_able_to_view_tier_page_with_feature_hero_banner_in_the_top_as_per_configured_by_admin_in_drupal(
			Integer int1) {
		visibilityWait(tier1.Featuredbanner_tier1);
		javascriptScroll(tier1.Featuredbanner_tier1);
		Assert.assertTrue(tier1.Featuredbanner_tier1.isDisplayed());
	}

	/************* 182723 ******/
	@Then("user should be able to view specific number of vBooks cards in the hero banner with carousel format configured by admin")
	public void user_should_be_able_to_view_specific_number_of_v_books_cards_in_the_hero_banner_with_carousel_format_configured_by_admin() {
		Logger.log(
				"user should be able to view specific number of vBooks cards in the hero banner with carousel format configured by admin");
	}

	@Then("user should be able to view vBooks titles sorted based on popularity or publication date")
	public void user_should_be_able_to_view_v_books_titles_sorted_based_on_popularity_or_publication_date() {
		Logger.log("user should be able to view vBooks titles sorted based on popularity or publication date");
	}

	@Then("user should be able to view vBooks titles sorted by publication latest date first when popularity metrics are not available or popularity index is same")
	public void user_should_be_able_to_view_v_books_titles_sorted_by_publication_latest_date_first_when_popularity_metrics_are_not_available_or_popularity_index_is_same() {
		Logger.log(
				"user should be able to view vBooks titles sorted by publication latest date first when popularity metrics are not available or popularity index is same");
	}

	@Then("user should be able to view vBooks titles carousel with maximum limit is {int}")
	public void user_should_be_able_to_view_v_books_titles_carousel_with_maximum_limit_is(Integer int1) {
		Logger.log("user should be able to view vBooks titles carousel with maximum limit is 10");
	}

	@Then("user should be able to view category featured hero banner should be confirmed by B&T")
	public void user_should_be_able_to_view_category_featured_hero_banner_should_be_confirmed_by_b_t() {
		Logger.log("user should be able to view category featured hero banner should be confirmed by B&T");
	}

	/********************/

	@When("user should be able to view VBook title tier {int} page")
	public void user_should_be_able_to_view_v_book_title_tier_page(Integer int1) {
		vbook.click_vbookSeeAllCTA();
	}

	@Then("user should be able to view Tier {int} page with Feature hero banner in the top")
	public void user_should_be_able_to_view_tier_page_with_feature_hero_banner_in_the_top(Integer int1) {
		Assert.assertTrue(video.getLib_videoCarousel_tier1_Featuredcarousel().isDisplayed());
		Logger.log("User navigates to video title tier1 page");
	}

	@Then("user should be able to view Hero banner background image as per configured by admin")
	public void user_should_be_able_to_view_hero_banner_background_image_as_per_configured_by_admin() {
		tier1.verify_featuredBannerBackgroundColor();
	}

	@Then("user should be able to view default title image if the Video title image is not available")
	public void user_should_be_able_to_view_default_title_image_if_the_video_title_image_is_not_available() {
		Logger.log("user should be able to view default title image if the Video title image is not available");
	}

	@Then("user should be able to view the Videos Title Icon for the video title")
	public void user_should_be_able_to_view_the_videos_title_icon_for_the_video_title() {
		javascriptScroll(video.videoIconTier3);
		visibilityWait(video.videoIconTier3);
		Assert.assertTrue(video.videoIconTier3.isDisplayed());
	}

	@Then("user should be able to view the grey background icon for unavailable Video title")
	public void user_should_be_able_to_view_the_grey_background_icon_for_unavailable_video_title() {
		Logger.log("UI validation");
	}

	@Then("user should be able to view the blue background icon for available Video title")
	public void user_should_be_able_to_view_the_blue_background_icon_for_available_video_title() {
		Logger.log("UI validation");
	}

	@Then("user should be able to view publishers, Age range, language, author, illustrator, series or session name under refine section")
	public void user_should_be_able_to_view_publishers_age_range_language_author_illustrator_series_or_session_name_under_refine_section() {
		tier1.view_tier2RefinerSection();
	}

	@Then("user should be able to view 1st bisac, 2nd bisac, 3rd bisac under refine section")
	public void user_should_be_able_to_view_1st_bisac_2nd_bisac_3rd_bisac_under_refine_section() {
		Logger.log("user should be able to view 1st bisac, 2nd bisac, 3rd bisac under refine section");
	}

	@Then("user should able to get result by select filter checkbox option and click search CTA")
	public void user_should_able_to_get_result_by_select_filter_checkbox_option_and_click_search_cta() {
		tier1.selectAnyRefineroption_Search();

	}

	@Then("user should be able to view the VBooks Title Icon for the VBook title")
	public void user_should_be_able_to_view_the_v_books_title_icon_for_the_v_book_title() {
		visibilityWait(tier1.tier1_vbooks_TitleIcon);
		Assert.assertTrue(tier1.tier1_vbooks_TitleIcon.isDisplayed());
	}

	@Then("user should be able to view the grey background icon for unavailable VBook title")
	public void user_should_be_able_to_view_the_grey_background_icon_for_unavailable_v_book_title() {
		Logger.log("UI validation");
	}

	@Then("user should be able to view the blue background icon for available VBook title")
	public void user_should_be_able_to_view_the_blue_background_icon_for_available_v_book_title() {
		Logger.log("UI validation");
	}

	@Then("user should be able to view default title image if the VBook title image is not available")
	public void user_should_be_able_to_view_default_title_image_if_the_v_book_title_image_is_not_available() {
		Logger.log("UI validation");
	}

	@Then("user should be able to view VBook list page")
	public void user_should_be_able_to_view_v_book_list_page() {
		//tier1.click_categoryCarousel_SeeAllCTA();
		Assert.assertTrue(tier1.videoTier2page.isDisplayed());
	}

	@Then("user should be able to view Video list page")
	public void user_should_be_able_to_view_video_list_page() {
		visibilityWait(tier1.videoTier2page);
		Assert.assertTrue(tier1.videoTier2page.isDisplayed());
	}

	@Then("user should be able to view relevance sort by default")
	public void user_should_be_able_to_view_relevance_sort_by_default() {
		Assert.assertTrue(tier1.tier2_sort.isDisplayed());
	}

	@Then("user should be able to view refine section at left side of the page")
	public void user_should_be_able_to_view_refine_section_at_left_side_of_the_page() {
		visibilityWait(tier1.tier2_RefinerSection);
		Assert.assertTrue(tier1.tier2_RefinerSection.isDisplayed());
	}

	@Then("user should able to view title, pub date, popularity, relavance under sort by section")
	public void user_should_able_to_view_title_pub_date_popularity_relavance_under_sort_by_section() {
		tier1.verify_tier2_RefinerSuboptions();
	}

	@Then("user should able to get result by select sort option and click search CTA")
	public void user_should_able_to_get_result_by_select_sort_option_and_click_search_cta() {
		tier1.selectAnyRefineroption_Search();
	}

	@Then("user navigate to VBook title detail page by clicking on VBook title card")
	public void user_navigate_to_v_book_title_detail_page_by_clicking_on_v_book_title_card() {
		tier3.click_tier2TitleCard();
	}

	@Then("user should be able to view VBook title detail attribute based on the metadata")
	public void user_should_be_able_to_view_v_book_title_detail_attribute_based_on_the_metadata() {
		visibilityWait(tier3.tier3_Details);
		Assert.assertTrue(tier3.tier3_Details.isDisplayed());
	}

	// 182689

	@Then("user should be able to view {int} number of video cards in the hero banner with carousel format configured by admin")
	public void user_should_be_able_to_view_number_of_video_cards_in_the_hero_banner_with_carousel_format_configured_by_admin(
			Integer int1) {
		Logger.log("Admin dependency cannot be automated");
	}

	@Then("user should be able to show titles for vBooks from each publisher with alternative title with publishers")
	public void user_should_be_able_to_show_titles_for_v_books_from_each_publisher_with_alternative_title_with_publishers() {
		Logger.log("Alternative publishers cannot be automated");
	}

	@Then("user should be able to view maximum of {int} titles in carousel")
	public void user_should_be_able_to_view_maximum_of_titles_in_carousel(Integer int1) {
		Logger.log("user should be able to view maximum of {int} titles in carousel");
	}

	// 182552

	@Then("user should be able to view the title list page based on the configuration in Drupal")
	public void user_should_be_able_to_view_the_title_list_page_based_on_the_configuration_in_drupal() {
		Logger.log("Drupal configuration cannot be automated");
	}

	@Then("user should be able to view the VBook title listed with Title Image")
	public void user_should_be_able_to_view_the_v_book_title_listed_with_title_image() {
		tier1.getTier2_vbooks_image();
	}

	@Then("user should be able to view the VBook icon in the title card")
	public void user_should_be_able_to_view_the_v_book_icon_in_the_title_card() {
		tier1.getTier2_vbooks_TitleIcon();
	}

	@Then("user should be able to view the refine section to filter the titles")
	public void user_should_be_able_to_view_the_refine_section_to_filter_the_titles() {
		tier1.getTier2_RefinerSection();
	}

	@Then("user should be able to view the match of result with API response")
	public void user_should_be_able_to_view_the_match_of_result_with_api_response() {
		Logger.log("dependency on API response");
	}

	@Then("user should be able to view videos in the carousel format Tier1 page")
	public void user_should_be_able_to_view_videos_in_the_carousel_format_tier1_page() {
		Assert.assertTrue(tier1.tier1_videos_carousel.isDisplayed());
	}

	@Then("User should be able to view these Videos with different categories Tier1 page")
	public void user_should_be_able_to_view_these_videos_with_different_categories_tier1_page() {
		Assert.assertTrue(tier1.tier1_videos_carousel.isDisplayed());
	}

	@Then("User should be able to view left & right arrow to swipe left & right side in the carousel in Tier1 page")
	public void user_should_be_able_to_view_left_right_arrow_to_swipe_left_right_side_in_the_carousel_in_tier1_page() {
		tier1.view_LeftAndRightArrowinVideoTier1Carousel();
	}
	
	@Then("user should be able to view categories with name and icon in Tier1 page")
	public void user_should_be_able_to_view_categories_with_name_and_icon_in_tier1_page() {
		Assert.assertTrue(tier1.videoCategoryNameTier1.isDisplayed());
		Assert.assertTrue(tier1.videoCategoryIconTier1.isDisplayed());
	}
	
	@Then("user should be able to view categories with name and icon in Tier1 page for VideoBooks")
	public void user_should_be_able_to_view_categories_with_name_and_icon_in_tier1_page_for_video_books() {
		Assert.assertTrue(tier1.vBooksCategoryIconTier1.isDisplayed());
		Assert.assertTrue(tier1.vBooksCategoryNameTier1.isDisplayed());
	}
	
	@Then("user should be able to view Popularity sort by default")
	public void user_should_be_able_to_view_Popularity_sort_by_default() {
		Assert.assertTrue(tier1.tier2_sort.isDisplayed());
	}

}
