package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.TitleDetail;

public class Tier3_TitleDetails_StepDef extends CommonAction {

	TitleDetail title = new TitleDetail(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@When("user taps on any of the title card")
	public void user_taps_on_any_of_the_title_card() {
		title.clickTitleCard();
	}
	
	@Then("user should be able to view the Also Available section as carosuel in details page for adult user with kidszone subscription")
	public void user_should_be_able_to_view_the_also_available_section_as_carosuel_in_details_page_for_adult_user_with_kidszone_subscription() {
		Assert.assertEquals(title.getRelatedItems().isDisplayed(), true);
		title.clickRelatedItems();
	}

	@Then("user should be able to view {string} section as carousel under {string} tab on title details screen")
	public void user_should_be_able_to_view_section_as_carousel_under_tab_on_title_details_screen(String string,
			String string2) {
		title.clickMoreLikeThis();
		WaitForWebElement(title.getTitleLikeThis());
		Assert.assertTrue(title.getTitleLikeThis().isDisplayed());
	}

	@Then("user should be able to view the alternate tab section as carosuel in details page for adult user with kidszone subscription")
	public void user_should_be_able_to_view_the_alternate_tab_section_as_carosuel_in_details_page_for_adult_user_with_kidszone_subscription() {
		Assert.assertTrue(title.getRelatedItems().isDisplayed());
		waitFor(2000);
		jsClick(title.getRelatedItems());
		waitFor(2000);
	}

	@Then("user should be able to view {string} that are available for the same title")
	public void user_should_be_able_to_view_that_are_available_for_the_same_title(String string) {
		Assert.assertTrue(title.getAlsoAvailableCarousel().isDisplayed());
	}

	@Then("user should be able to view each available {string} as title card")
	public void user_should_be_able_to_view_each_available_as_title_card(String string) {
		Assert.assertEquals(title.getAlsoAvailableCarousel().getText().contains(string), true);
	}

	@Then("user should be able to view {string} section as carousel under {string} tab on title details screen for adult user with kidszone subscription")
	public void user_should_be_able_to_view_section_as_carousel_under_tab_on_title_details_screen_for_adult_user_with_kidszone_subscription(
			String string, String string2) {
		Assert.assertTrue(title.getTitleLikeThis().isDisplayed());
	}

	@Then("user should be able to view recommended titles based on the title being viewed")
	public void user_should_be_able_to_view_recommended_titles_based_on_the_title_being_viewed() {
		Assert.assertTrue(title.getTitleLikeThisCarousel().isDisplayed());
	}

	@Then("user should be able to view {string} with recommended collection that are associated to that title")
	public void user_should_be_able_to_view_with_recommended_collection_that_are_associated_to_that_title(
			String string) {
		Assert.assertEquals(title.getTitleLikeThis().getText().contains(string), true);
	}

	@Then("user should be able to view {string} with series of titles that are associated to the title being viewed for adult user")
	public void user_should_be_able_to_view_with_series_of_titles_that_are_associated_to_the_title_being_viewed_for_adult_user(
			String string) {
		Assert.assertTrue(title.getOtherTitleCarousel().isDisplayed());
	}

	@Then("user should be able to view {string} section as carousel")
	public void user_should_be_able_to_view_section_as_carousel(String string) {
		Assert.assertTrue(title.getOtherTitles().getText().contains(string));
		Assert.assertTrue(title.getOtherTitleCarousel().isDisplayed());
	}

	@Then("user should be able to view breacrumbs in title details page")
	public void user_should_be_able_to_view_breacrumbs_in_title_details_page() {
		Assert.assertTrue(title.getBreadcrumbTitleDetail().isDisplayed());
	}

	@Then("breadcrum should be at page level")
	public void breadcrum_should_be_at_page_level() {
		Logger.log("User able to see the breadcrumb at page level");
	}

	@Then("user should be able to view {string} with series of titles that are associated to the title being viewed")
	public void user_should_be_able_to_view_with_series_of_titles_that_are_associated_to_the_title_being_viewed(
			String string) {
		Assert.assertTrue(title.getOtherTitleCarousel().isDisplayed());
	}

	@Given("user is in browse by subject listing screen")
	public void user_is_in_browse_by_subject_listing_screen() {
		login.click_HamburgerMenu();
		title.clickBrowseBySubject();
	}


//	@When("user tap on any of the title")
//	public void user_tap_on_any_of_the_title() {
//	}

	@When("user navigate to title details page")
	public void user_navigate_to_title_details_page() {
		Assert.assertTrue(title.getTitleDetailPage().isDisplayed());
	}

	@When("user tap on write a review CTA")
	public void user_tap_on_write_a_review_cta() {
		title.clickWriteAReview();
	}

	@Then("user should be able to view the submitted review greyed out inside the write a review box")
	public void user_should_be_able_to_view_the_submitted_review_greyed_out_inside_the_write_a_review_box() {
		Assert.assertTrue(title.getReviewSubmitted().isDisplayed());
	}

	@Then("user should view {string} as red inline message")
	public void user_should_view_as_red_inline_message(String string) {
		Assert.assertEquals(title.getReviewSubmitted().getText().contains(string), true);
	}
	
	//192311
	
	@Given("user should not be registered with email id")
	public void user_should_not_be_registered_with_email_id() {
	    Logger.log("this user is not registered with email Id");
	}

	@Given("user click the title to navigate to title details screen which is not available to checkout")
	public void user_click_the_title_to_navigate_to_title_details_screen_which_is_not_available_to_checkout() {
	    title.clickAndNavigateToDetailsPage();
	}

	@Given("user should be able to view title with primary and secondary CTA")
	public void user_should_be_able_to_view_title_with_primary_and_secondary_cta() {
	    title.secondaryCtaInDetailsPage();
	}

	@When("user should be able to view put the title on hold")
	public void user_should_be_able_to_view_put_the_title_on_hold() {
	    Assert.assertTrue(title.getPlaceHold_Cta().isDisplayed());
	}

	@Then("user should not get prompted to put their email id")
	public void user_should_not_get_prompted_to_put_their_email_id() {
		Assert.assertEquals(isElementPresent(title.getHold_Alertbox()), false);
	}

	@Then("user should be able to put the title on hold")
	public void user_should_be_able_to_put_the_title_on_hold() {
	    title.click_placeonhold();
	}
	
	@When("user put place on hold the title for the first time if the title was not available to checkout")
	public void user_put_place_on_hold_the_title_for_the_first_time_if_the_title_was_not_available_to_checkout() {
	    //title.click_holdCtaNewUI();
		title.click_WaitListForPlaceHold();
	}

	@Then("user should be able to view the popup with header {string} and body {string}")
	public void user_should_be_able_to_view_the_popup_with_header_and_body(String string, String string2) {
	    Assert.assertTrue(title.getHold_Alertbox().isDisplayed());
	    Assert.assertTrue(title.getHoldConfirmed_header().isDisplayed());
	    Assert.assertTrue(title.getHoldConfirmed_Textmsg().isDisplayed());
	}
	
	@When("user put place on hold the title for the second time if the title was not available to checkout")
	public void user_put_place_on_hold_the_title_for_the_second_time_if_the_title_was_not_available_to_checkout() {
		title.click_holdCtaNewUI();
	}
	
	@Then("user should not be able to view the popup with header {string} and body {string}")
	public void user_should_not_be_able_to_view_the_popup_with_header_and_body(String string, String string2) {
		Assert.assertEquals(isElementPresent(title.getHold_Alertbox()), false);
	}
	
	@Given("user clicks on program from hamberger menu")
	public void user_clicks_on_program_from_hamberger_menu() {
	    title.click_programsFromMenuNewUI();
	}

	@Given("user navigate to my program screen")
	public void user_navigate_to_my_program_screen() {
	    Assert.assertTrue(title.getActivePrograms().isDisplayed());
	}

	@Given("user clicks on program card to navigate program details screen")
	public void user_clicks_on_program_card_to_navigate_program_details_screen() {
	    title.click_activeProgram();
	}

	@Given("user should be able to view title with primary CTA")
	public void user_should_be_able_to_view_title_with_primary_cta() {
	    title.viewHoldAsPrimaryCta();
	}
	
	@Given("user should have the titles in wishlist screen that is not available to checkout")
	public void user_should_have_the_titles_in_wishlist_screen_that_is_not_available_to_checkout() {
	    title.AddHoldtitleToWishlist();
	}
	
	@Given("user navigates to myshelf screen")
	public void user_navigates_to_myshelf_screen() {
	    title.NavToMyShelfScreen();
	}

	@Given("user navigate to wishlist screen by clicking wishlist from top navigation")
	public void user_navigate_to_wishlist_screen_by_clicking_wishlist_from_top_navigation() {
	    title.click_WhishlistCtainMyStuffPage();
	}

	@Given("user should be able to view title with primary cta and secondary cta")
	public void user_should_be_able_to_view_title_with_primary_cta_and_secondary_cta() {
	    title.validateWhishlistSecondaryCta();
	}
	
	@Given("parent user should not be registered with email id")
	public void parent_user_should_not_be_registered_with_email_id() {
	    Logger.log("Parent user has not registered email");
	}

	@Given("user should be registered with email id")
	public void user_should_be_registered_with_email_id() {
	    Logger.log("user is registered with email");
	}

	@Given("user should enabled the email notification")
	public void user_should_enabled_the_email_notification() {
	    Logger.log("email notification is enabled for this user");
	}
	
	@Given("user clicks on program from hamberger menu OldUI")
	public void user_clicks_on_program_from_hamberger_menu_old_ui() {
	    title.click_programsFromMenuOldUI();
	}
	    
	@When("user search the Title {string} and {string} with carousels")
	public void user_search_the_title_with_carousels(String titleName, String UATtitle) {
		title.titleSearch(titleName,UATtitle);
	}
}
