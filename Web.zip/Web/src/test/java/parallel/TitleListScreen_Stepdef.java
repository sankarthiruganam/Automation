package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Given.Givens;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Myprog;
import pom.kidszone.Myprograms;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;
import pom.kidszone.TitleDetails;
import pom.kidszone.TitleListScreen;

public class TitleListScreen_Stepdef extends CommonAction {

	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	Myprograms myprogram = new Myprograms(DriverManager.getDriver());
	Myprog prog = new Myprog(DriverManager.getDriver());
	TitleListScreen titleList = new TitleListScreen(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	TitleDetails title = new TitleDetails(DriverManager.getDriver());

	// 148850

	@Given("user should be able to navigate titles list page and add a filters")
	public void user_should_be_able_to_navigate_titles_list_page_and_add_a_filters() {
		titleList.click_seeAllCtaInChildrenCarousel();
		titleList.addFilterOptionsInRefine();
	}

	@When("user is on titles list page and has applied filters")
	public void user_is_on_titles_list_page_and_has_applied_filters() {
		Assert.assertEquals(titleList.getValidate_titleListPage().isDisplayed(), true);
	}

	@Then("user should be able to view the selected refiners sub options on the page as pills")
	public void user_should_be_able_to_view_the_selected_refiners_sub_options_on_the_page_as_pills() {
		javascriptScroll(titleList.availabilityOption_underFilter);
		jsClick(titleList.availabilityOption_underFilter);
		visibilityWait(titleList.availableNowOption);
		jsClick(titleList.availableNowOption);
		WaitForWebElement(titleList.availableNow_pill);
		Assert.assertTrue(titleList.availableNow_pill.isDisplayed());
	}

	@Then("user should be able to remove refiners applied by clicking X on refiner sub  option pill")
	public void user_should_be_able_to_remove_refiners_applied_by_clicking_x_on_refiner_sub_option_pill() {
		titleList.click_closeIconInPills();
	}

	@Then("System should update the refiner section when refiners are removed")
	public void system_should_update_the_refiner_section_when_refiners_are_removed() {
		Logger.log("System should update the refiner section when refiners are removed");
	}

	@Then("user should be able to view clear all option on the page when more than one refiner is applied")
	public void user_should_be_able_to_view_clear_all_option_on_the_page_when_more_than_one_refiner_is_applied() {
		Assert.assertEquals(titleList.getBtn_clearAllCta().isDisplayed(), true);
	}

	@Then("user should be able to click on clear all CTA and clear all the refiners applied")
	public void user_should_be_able_to_click_on_clear_all_cta_and_clear_all_the_refiners_applied() {
		titleList.click_clearAllCta();
	}

	@When("user tap on title in the tiles list page")
	public void user_tap_on_title_in_the_tiles_list_page() {
		titleList.click_title_inTitlelist();
	}

	@Then("user should be able to view the title details page")
	public void user_should_be_able_to_view_the_title_details_page() {
		Assert.assertEquals(titleList.getValidate_titleDetailspage().isDisplayed(), true);
	}

	@Then("user navigate back to the titles list page")
	public void user_navigate_back_to_the_titles_list_page() {
		titleList.navigateBackToTitleListScreen();
	}

	@When("user tap on clear all in the tiles list page")
	public void user_tap_on_clear_all_in_the_tiles_list_page() {
		titleList.click_clearAllCta();
	}

	@Then("user should be able to view all reset refiners")
	public void user_should_be_able_to_view_all_reset_refiners() {
		titleList.viewAllRefinersReset();
	}

	@Then("user should be able to view the refiners should be in collapse mode")
	public void user_should_be_able_to_view_the_refiners_should_be_in_collapse_mode() {
		Logger.log("user able to view the refiners should be in collapse mode");
	}

	@Then("user should not be able to view the selected refiners sub options on the page as pills")
	public void user_should_not_be_able_to_view_the_selected_refiners_sub_options_on_the_page_as_pills() {
		Assert.assertEquals(isElementPresent(titleList.getReturnDate_pill()), false);
	}

	@Then("user should be able to view the selected refiners should reatained")
	public void user_should_be_able_to_view_the_selected_refiners_should_reatained() {
		Logger.log("options are retained");
	}

	// 148852

	@When("user is lands on browser screen with fiction level {int}")
	public void user_is_lands_on_browser_screen_with_fiction_level(Integer int1) {
		titleList.click_teen_Fiction();
	}

	@Given("user click browse by subject")
	public void user_click_browse_by_subject() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_browseBySubject();
	}

	@Then("user should be able to view the level {int} subject list for the level {int} subject fiction")
	public void user_should_be_able_to_view_the_level_subject_list_for_the_level_subject_fiction(Integer int1,
			Integer int2) {
		titleList.click_ActionAndAdventure();
	}

	@Then("user should be able to view top {int} level {int} subjects for fictionlisted first in the level {int} category section")
	public void user_should_be_able_to_view_top_level_subjects_for_fictionlisted_first_in_the_level_category_section(
			Integer int1, Integer int2, Integer int3) {
		titleList.scrollToTop20();
	}

	@Then("user should be able to view remaining level {int} subjects for fictionlisted after top {int} in alphabetical order")
	public void user_should_be_able_to_view_remaining_level_subjects_for_fictionlisted_after_top_in_alphabetical_order(
			Integer int1, Integer int2) {
		titleList.ScrollToMoreType();
	}

	@Then("user should be able to view header {string} for top {int} level {int} subjects group")
	public void user_should_be_able_to_view_header_for_top_level_subjects_group(String string, Integer int1,
			Integer int2) {
		titleList.scrollToTop20();
		Assert.assertEquals(titleList.getTop20Cta().isDisplayed(), true);
	}

	@Then("user should be able to view header {string} for top {int} level {int} subjects")
	public void user_should_be_able_to_view_header_for_top_level_subjects(String string, Integer int1, Integer int2) {
		titleList.ScrollToMoreType();
		Assert.assertEquals(titleList.getMoreTypeCta().isDisplayed(), true);
	}

	@Given("user clicks on level {int} title")
	public void user_clicks_on_level_title(Integer int1) {
		titleList.click_title_inTitlelist();
	}

	@When("user is lands on browser screen with fiction level {int} subjects")
	public void user_is_lands_on_browser_screen_with_fiction_level_subjects(Integer int1) {
//		    titleList.select_morelikethisLink();
	}

	@Then("user should be able to view the level {int} title list for the level {int} subject fiction")
	public void user_should_be_able_to_view_the_level_title_list_for_the_level_subject_fiction(Integer int1,
			Integer int2) {
		Assert.assertEquals(titleList.getValidate_titleDetailspage().isDisplayed(), true);
	}

	@When("user is lands on teen browser screen with fiction level {int}")
	public void user_is_lands_on_teen_browser_screen_with_fiction_level(Integer int1) {
		titleList.click_teen_Fiction();
	}

	@When("user is lands on kid browser screen with fiction level {int}")
	public void user_is_lands_on_kid_browser_screen_with_fiction_level(Integer int1) {
		titleList.click_kid_Fiction();
	}
	

	// 148851

	@Given("user clicks on fiction lands on level {int} subject screen")
	public void user_clicks_on_fiction_lands_on_level_subject_screen(Integer int1) {
		titleList.click_fictionOption();
	}

	@Then("user should be able to view the sub-option title to recommend under refiner option Collections")
	public void user_should_be_able_to_view_the_sub_option_title_to_recommend_under_refiner_option_collections() {
		titleList.ScrollToCollections();
	}

	@Then("user should be able to selected title to recommend and view titles listed from the Purchase Request collection")
	public void user_should_be_able_to_selected_title_to_recommend_and_view_titles_listed_from_the_purchase_request_collection() {
		titleList.clickTitlesToRecommend();
	}

	@Given("user should be able to navigate from Level {int} Subject bread crumb")
	public void user_should_be_able_to_navigate_from_level_subject_bread_crumb(Integer int1) {
		titleList.click_ActionAndAdventure();
	}

	@Given("kid user clicks on fiction lands on level {int} subject screen")
	public void kid_user_clicks_on_fiction_lands_on_level_subject_screen(Integer int1) {
		titleList.click_kid_Fiction();
	}

	@Given("teen user clicks on fiction lands on level {int} subject screen")
	public void teen_user_clicks_on_fiction_lands_on_level_subject_screen(Integer int1) {
		titleList.click_teen_Fiction();
	}

	// 148842

	@When("user clicks on Level {int} Subject CTA")
	public void user_clicks_on_level_subject_cta(Integer int1) {
		titleList.click_LibseeAllNavigateTileList();
	}

	@When("user clicks on Level two Subject CTA")
	public void user_clicks_on_level_two_subject_cta() {
		titleList.click_LibseeAllNavigateTileList();
	}

	@Then("user should be navigated to titles list screen")
	public void user_should_be_navigated_to_titles_list_screen() {
		myprogram.clicktitle_navTodetailscreen();
		Assert.assertTrue(titleList.link_Details.isDisplayed());

	}

	@Then("user should be able to view title list screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_title_list_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log(
				"user able to view title list screen with theme rendered based on library subscription and user profile type");
	}

	@Then("user should be able to navigate back to last screen by clicking back CTA")
	public void user_should_be_able_to_navigate_back_to_last_screen_by_clicking_back_cta() {
		titleList.validate_title_details_screen();
	}

	@When("user clicks on See All CTA for the carousel")
	public void user_clicks_on_see_all_cta_for_the_carousel() {
		titleList.clickseeAllCTA_carousel();
	}

	@When("user clicks on See All CTA for the Curated list")
	public void user_clicks_on_see_all_cta_for_the_curated_list() {
		titleList.clickSeeAll_curatedList();
	}

	@When("axis and kidszone user clicks on See All CTA for the Curated list")
	public void axis_and_kidszone_user_clicks_on_see_all_cta_for_the_curated_list() {
		titleList.click_oldSeeAll();
	}

	@When("user click on See All CTA for the carousel")
	public void user_click_on_see_all_cta_for_the_carousel() {
		titleList.clickoldseeAllCTA_carousel();
	}

	@Then("axis and kidszone user should be navigated to titles list screen")
	public void axis_and_kidszone_user_should_be_navigated_to_titles_list_screen() {
		Assert.assertTrue(isElementPresent(titleList.getTitleList_old()));
	}

	@Then("user should be able to view title list screen with old theme")
	public void user_should_be_able_to_view_title_list_screen_with_old_theme() {
		Logger.log("user able to view title list screen with old theme");
	}

	@Then("axis and kidszone user should be able to navigate back to last screen by clicking back CTA")
	public void axis_and_kidszone_user_should_be_able_to_navigate_back_to_last_screen_by_clicking_back_cta() {
		titleList.navigateBack_homeOld();
	}

	@Then("axis user should be navigated to titles list screen")
	public void axis_user_should_be_navigated_to_titles_list_screen() {
		Assert.assertTrue(isElementPresent(titleList.getAlwaysavailable_titleList_old()));
	}

	@Then("axis user should be able to navigate back to last screen by clicking back CTA")
	public void axis_user_should_be_able_to_navigate_back_to_last_screen_by_clicking_back_cta() {
		titleList.navigateBack_homeOld();
	}

	// 148843

	@Given("user should be able to view the bread crumb as CTA and navigate from Level {int} Subject bread crumb")
	public void user_should_be_able_to_view_the_bread_crumb_as_cta_and_navigate_from_level_subject_bread_crumb(
			Integer int1) {
		titleList.click_LibseeAllNavigateTileList();
		// Assert.assertTrue(isElementPresent(titleList.getNav_TitleListScreen()));
	}

	@Given("user should be navigate titles listed for level {int} subject")
	public void user_should_be_navigate_titles_listed_for_level_subject(Integer int1) {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_featuredList();
		titleList.click_fictionOption();
	}

	@Given("user should be able to view the bread crumb as CTA and navigate from Level two Subject bread crumb")
	public void user_should_be_able_to_view_the_bread_crumb_as_cta_and_navigate_from_level_two_subject_bread_crumb() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_browseBySubject();
		titleList.click_fictionOption();
		titleList.click_ActionAndAdventure();
	}

	@When("user lands on titles list screen")
	public void user_lands_on_titles_list_screen() {
		Assert.assertTrue(isElementPresent(titleList.getNav_TitleListScreen()));
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Level {int} Subject")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_level_subject(
			Integer int1) {
		visibilityWait(titleList.getTitleList_level1subject());
		Assert.assertTrue(isElementPresent(titleList.getTitleList_level1subject()));
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Level two Subject")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_level_two_subject() {
		titleList.level2Subject_numberofResults();
	}

	@Then("user should be able to view each title as a card and titles listed as grid view")
	public void user_should_be_able_to_view_each_title_as_a_card_and_titles_listed_as_grid_view() {
		Assert.assertTrue(isElementPresent(titleList.getTitle_gridview()));
	}

	@Then("user should be able to view {int} titles")
	public void user_should_be_able_to_view_titles(Integer int1) {
		titleList.verify_tenTitles();
	}

	@Then("System should lazy load next {int} titles per carousel as user browses towards the bottom of the titles displayed")
	public void system_should_lazy_load_next_titles_per_carousel_as_user_browses_towards_the_bottom_of_the_titles_displayed(
			Integer int1) {
		Logger.log(
				"System should lazy load next {int} titles per carousel as user browses towards the bottom of the titles displayed");
	}

	@Then("user should be able to view category section for Level {int} subjects")
	public void user_should_be_able_to_view_category_section_for_level_subjects(Integer int1) {
		Assert.assertTrue(isElementPresent(titleList.getCategeorySection_level1()));
	}

	@Then("user should be able to view refines section for sort and filter")
	public void user_should_be_able_to_view_refines_section_for_sort_and_filter() {
		titleList.verify_RefineSection();
	}

	@Then("user should be able to view category section expanded and filter options collapsed by default")
	public void user_should_be_able_to_view_category_section_expanded_and_filter_options_collapsed_by_default() {
		Assert.assertTrue(isElementPresent(titleList.getExpendAndcollepse()));
	}

	@Then("user should be able to click on to expand and collapse the category section and filter options")
	public void user_should_be_able_to_click_on_to_expand_and_collapse_the_category_section_and_filter_options() {
		titleList.verify_defaultExpendedoption();
	}

	@Given("user should be able to view the bread crumb as CTA and navigate from Level three Subject bread crumb")
	public void user_should_be_able_to_view_the_bread_crumb_as_cta_and_navigate_from_level_three_subject_bread_crumb() {
		titleList.click_level3Subject();
	}

	@Given("user should be able to view the See All CTA and navigate from curated list see all CTA")
	public void user_should_be_able_to_view_the_see_all_cta_and_navigate_from_curated_list_see_all_cta() {
		titleList.clickseeAllCTA_carousel();
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Curated List")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_curated_list() {
		Assert.assertTrue(isElementPresent(titleList.getTitleList_level1subject()));
	}

	@Then("user should be able to view category section for Curated list")
	public void user_should_be_able_to_view_category_section_for_curated_list() {
		Assert.assertTrue(isElementPresent(titleList.getCategeorySection_level1()));
	}

	@Then("user should be able to view the all profile type titles in the list screen")
	public void user_should_be_able_to_view_the_all_profile_type_titles_in_the_list_screen() {
		Logger.log("user able to view the all profile type titles in the list screen");

	}

	// 148844

	@Given("user click on hamburger menu via Browse By subject")
	public void user_click_on_hamburger_menu_via_browse_by_subject() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_browseBySubject();
		titleList.click_fictionOption();
		titleList.click_ActionAndAdventure();

	}

	@Then("user should be able to view the titles listed for the Level {int} subject on the title list screen when user has navigated from Level {int} Subject")
	public void user_should_be_able_to_view_the_titles_listed_for_the_level_subject_on_the_title_list_screen_when_user_has_navigated_from_level_subject(
			Integer int1, Integer int2) {
		titleList.verify_tenTitles();
	}

	@Then("user should be able to view the titles listed for the Level three subject on the title list screen when user has navigated from Level {int} Subject")
	public void user_should_be_able_to_view_the_titles_listed_for_the_level_three_subject_on_the_title_list_screen_when_user_has_navigated_from_level_subject(
			Integer int1) {
		// titleList.select_morelikethisLink();
	}

	@Given("user should be able to view the bread crumb as CTA and navigate from curated list bread crumb")
	public void user_should_be_able_to_view_the_bread_crumb_as_cta_and_navigate_from_curated_list_bread_crumb() {
		titleList.clickSeeAll_curatedList();
	}

	@When("user should be able to view the titles listed for the curated list on the title list screen when user has navigated from curated List")
	public void user_should_be_able_to_view_the_titles_listed_for_the_curated_list_on_the_title_list_screen_when_user_has_navigated_from_curated_list() {
		titleList.verify_tenTitles();
	}

	@When("user should be able to view the titles from both General collection and Always Available collection listed by default")
	public void user_should_be_able_to_view_the_titles_from_both_general_collection_and_always_available_collection_listed_by_default() {
		Logger.log(
				"user able to view the titles from both General collection and Always Available collection listed by default");
	}

	@Given("user should be able to view the see all CTA for Carousel and navigate from Carousel")
	public void user_should_be_able_to_view_the_see_all_cta_for_carousel_and_navigate_from_carousel() {
		// Assert.assertTrue(titleList.getLink_libSeeAll());
	}

	@When("user should be able to view the titles listed for the carousel on the title list screen when user has navigated from Carousel see all CTA")
	public void user_should_be_able_to_view_the_titles_listed_for_the_carousel_on_the_title_list_screen_when_user_has_navigated_from_carousel_see_all_cta() {
		titleList.clickseeAllCTA_carousel();
	}

	// 148848

	@Then("user should be able to view the titles sorted based on publication date by default")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_publication_date_by_default() {
		titleList.select_sortBy();
	}

	@Then("user should be able view the titles sorted based on selection")
	public void user_should_be_able_view_the_titles_sorted_based_on_selection() {
		visibilityWait(titleList.results_browse);
		Assert.assertTrue(isElementPresent(titleList.results_browse));
	}

	@Then("user should be able to expand and collapse the sort section")
	public void user_should_be_able_to_expand_and_collapse_the_sort_section() {
		titleList.sortBy_expandAndCollepse();
	}

	@Then("user should be able to view the selected sort option below the sort section header")
	public void user_should_be_able_to_view_the_selected_sort_option_below_the_sort_section_header() {
		Assert.assertTrue(isElementPresent(titleList.view_sortOption));
	}

	@Then("user should be able to view and select Added date sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_added_date_sort_option_for_the_titles_listed() {
		titleList.sortBy_addedDate();
	}

	@Then("user should be able view the titles sorted based on Added date")
	public void user_should_be_able_view_the_titles_sorted_based_on_added_date() {
		Assert.assertTrue(isElementPresent(titleList.sort_radioButton.get(3)));
	}

	@Then("user should be able to view and select Author sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_author_sort_option_for_the_titles_listed() {
		titleList.selectsortBy_Author();
	}

	@Then("user should be able view the titles sorted based on Author")
	public void user_should_be_able_view_the_titles_sorted_based_on_author() {
		Assert.assertTrue(isElementPresent(titleList.sort_radioButton.get(5)));
	}

	@Then("user should be able to view and select Popularity sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_popularity_sort_option_for_the_titles_listed() {
		titleList.selectsortBy_popularity();
	}

	@Then("user should be able view the titles sorted based on Popularity")
	public void user_should_be_able_view_the_titles_sorted_based_on_popularity() {
		Assert.assertTrue(isElementPresent(titleList.sort_radioButton.get(1)));
	}

	@Then("user should be able to view and select Return date sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_return_date_sort_option_for_the_titles_listed() {
		titleList.selectsortBy_ReturnDate();
	}

	@Then("user should be able view the titles sorted based on Return date")
	public void user_should_be_able_view_the_titles_sorted_based_on_return_date() {
		Assert.assertTrue(isElementPresent(titleList.sort_radioButton.get(0)));
	}

	@Then("user should be able to view and select Title sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_title_sort_option_for_the_titles_listed() {
		titleList.selectsortBy_Title();
	}

	@Then("user should be able view the titles sorted based on Title")
	public void user_should_be_able_view_the_titles_sorted_based_on_title() {
		Assert.assertTrue(isElementPresent(titleList.sort_radioButton.get(4)));
	}

	@Then("user should be able to view sort option in the refiner section")
	public void user_should_be_able_to_view_sort_option_in_the_refiner_section() {
		visibilityWait(titleList.view_sortOption);
		Assert.assertTrue(isElementPresent(titleList.view_sortOption));
		//titleList.select_sortBy();
	}

	@Then("user should be able to view the titles sorted based on publication date by descending order as default")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_publication_date_by_descending_order_as_default() {
		Logger.log("user able to view the titles sorted based on publication date by descending order as default");
	}

	@Then("user should be able to view the most recent should be the first")
	public void user_should_be_able_to_view_the_most_recent_should_be_the_first() {
		Logger.log("user able to view the most recent should be the first");
	}
	// 148849

	@Then("user should be to view refine options for the titles list")
	public void user_should_be_to_view_refine_options_for_the_titles_list() {
		Assert.assertTrue(isElementPresent(titleList.getTxt_refinesection()));
	}

	@Then("user should be able to view the each refine option collapsed by default")
	public void user_should_be_able_to_view_the_each_refine_option_collapsed_by_default() {
		titleList.view_refineSections();
	}

	@Then("user should be able to expand and view sub options for each refine option available")
	public void user_should_be_able_to_expand_and_view_sub_options_for_each_refine_option_available() {
		titleList.select_eachRefineOptions();
	}

	@Then("user should be able to select a refine option and view the results updated based on that refine option")
	public void user_should_be_able_to_select_a_refine_option_and_view_the_results_updated_based_on_that_refine_option() {
		titleList.select_sortBy();
		titleList.sortBy_addedDate();
	}

	@Then("user should be able to view the selected refine sub option option below the refine option")
	public void user_should_be_able_to_view_the_selected_refine_sub_option_option_below_the_refine_option() {
		Assert.assertTrue(isElementPresent(titleList.level1_numberofResults));
	}

	@Then("user should be to view refine options for the titles list based on the teen age level")
	public void user_should_be_to_view_refine_options_for_the_titles_list_based_on_the_teen_age_level() {
		Assert.assertTrue(titleList.verify_ageLevel());
	}

	@Then("user should be to view refine options for the titles list based on the kid age level")
	public void user_should_be_to_view_refine_options_for_the_titles_list_based_on_the_kid_age_level() {
		Assert.assertTrue(titleList.verify_ageLevel());
	}

	@Then("user should be able to view refine options for the titles list based on the adult age level")
	public void user_should_be_able_to_view_refine_options_for_the_titles_list_based_on_the_adult_age_level() {
		Assert.assertTrue(titleList.verify_ageLevel());

	}

	// 148845

	@When("user is on title list screen for the Level {int} subject")
	public void user_is_on_title_list_screen_for_the_level_subject(Integer int1) {
		javascriptScroll(titleList.getNav_TitleListScreen());
		Assert.assertTrue(isElementPresent(titleList.getNav_TitleListScreen()));
	}

	@Then("user should be able to view the category section for Level {int} subjects")
	public void user_should_be_able_to_view_the_category_section_for_level_subjects(Integer int1) {
		javascriptScroll(titleList.getCategeorySection_level1());
		Assert.assertTrue(isElementPresent(titleList.getCategeorySection_level1()));
	}

	@Then("user should be able to view Level {int} subject selected below the header")
	public void user_should_be_able_to_view_level_subject_selected_below_the_header(Integer int1) {
		javascriptScroll(titleList.getHeader_level1Subject());
		Assert.assertTrue(isElementPresent(titleList.getHeader_level1Subject()));
	}

	@Then("user should be able to view list of Level {int} subjects for the library")
	public void user_should_be_able_to_view_list_of_level_subjects_for_the_library(Integer int1) {
		// Logger.log("user is able to view the list of Level one subjects for the
		// library");
		System.out.println("user is able to see list of level 1 subjects");
	}

	@Then("user should be able to view Level {int} subject selected on landing")
	public void user_should_be_able_to_view_level_subject_selected_on_landing(Integer int1) {
		// titleList.verify_tenTitles();
	}

	@Then("user should be able to select level {int} subject and view the titles listed, level {int} subjects and refiners updated based on selection")
	public void user_should_be_able_to_select_level_subject_and_view_the_titles_listed_level_subjects_and_refiners_updated_based_on_selection(
			Integer int1, Integer int2) {
		titleList.selectsortBy_popularity();
		// Assert.assertTrue(isElementPresent(titleList.header_filteroptions));
	}

	@Then("user should be able to view the breadcrumb updated based on subject selected")
	public void user_should_be_able_to_view_the_breadcrumb_updated_based_on_subject_selected() {
		javascriptScroll(titleList.getTxt_TitleListScreen());		
		waitFor(2000);
//		Assert.assertTrue(isElementPresent(titleList.breadcrumb_titleList));
	}

	@Then("system should reset the filters when user selects a new level {int} subjects to navigation")
	public void system_should_reset_the_filters_when_user_selects_a_new_level_subjects_to_navigation(Integer int1) {
		titleList.selectsortBy_Author();
		// Assert.assertTrue(isElementPresent(titleList.header_filteroptions));
	}

	// 148846

	@Then("user should be able to view list of Level {int} subjects for the Level {int} subject")
	public void user_should_be_able_to_view_list_of_level_subjects_for_the_level_subject(Integer int1, Integer int2) {
		titleList.verify_tenTitles();
	}

	@Then("user should be able to view All Level {int} subject selected by default on landing and first option in the list")
	public void user_should_be_able_to_view_all_level_subject_selected_by_default_on_landing_and_first_option_in_the_list(
			Integer int1) {
		Logger.log(
				"ser should be able to view All Level 2 subject selected by default on landing and first option in the list");
	}

	@Then("user should be able to select level {int} subject and view the titles listed and refiners updated based on selection")
	public void user_should_be_able_to_select_level_subject_and_view_the_titles_listed_and_refiners_updated_based_on_selection(
			Integer int1) {
		titleList.selectsortBy_popularity();
		// Assert.assertTrue(isElementPresent(titleList.header_filteroptions));
	}

	@Then("user should be able to view the breadcrumb updated based on level {int} selected")
	public void user_should_be_able_to_view_the_breadcrumb_updated_based_on_level_selected(Integer int1) {
		Assert.assertTrue(isElementPresent(titleList.breadcrumb_titleList));
	}

	// 148847

	@When("user is on title list screen for the curated list")
	public void user_is_on_title_list_screen_for_the_curated_list() {
		titleList.clickSeeAll_curatedList();
	}

	@Then("user should be able to view the category section with in header Featured Lists")
	public void user_should_be_able_to_view_the_category_section_with_in_header_featured_lists() {
		Assert.assertTrue(isElementPresent(titleList.getTxt_TitleListScreen()));
	}

	@Then("user should be able to view Curated list selected below the header")
	public void user_should_be_able_to_view_curated_list_selected_below_the_header() {
		Assert.assertTrue(isElementPresent(titleList.getHeader_level1Subject()));
	}

	@Then("user should be able to view list of enabled curated lists for that library")
	public void user_should_be_able_to_view_list_of_enabled_curated_lists_for_that_library() {
		Logger.log("user able to view list of enabled curated lists for that library");
	}

	@Then("user should be able to view the curated lists in order defined in admin portal")
	public void user_should_be_able_to_view_the_curated_lists_in_order_defined_in_admin_portal() {
		Logger.log("user able to view the curated lists in order defined in admin portal");
	}

	@Then("user should be able to view Curated list selected by default on landing")
	public void user_should_be_able_to_view_curated_list_selected_by_default_on_landing() {
		Logger.log("user able to view Curated list selected by default on landing");
	}

	@Then("user should be able to select Curated list and view the titles listed updated based on selection")
	public void user_should_be_able_to_select_curated_list_and_view_the_titles_listed_updated_based_on_selection() {
		titleList.verify_tenTitles();
		Logger.log("user able to select Curated list and view the titles listed updated based on selection");
	}

	@Then("user should be able to view the breadcrumb updated based on Curated list selected")
	public void user_should_be_able_to_view_the_breadcrumb_updated_based_on_curated_list_selected() {
		Assert.assertTrue(isElementPresent(titleList.breadcrumb_titleList));
	}

	// 145697

	@Given("user should be navigated to library screen")
	public void user_should_be_navigated_to_library_screen() {
		
		Assert.assertTrue(isElementPresent(titleList.getNav_libraryScreen()));
	}

	@When("user taps on the title card")
	public void user_taps_on_the_title_card() {
		titleList.click_titleCard();
	}

	@Then("user should be navigated to title details screen")
	public void user_should_be_navigated_to_title_details_screen() {
		visibilityWait(title.getTitleDetailScreen());
		Assert.assertEquals(isElementPresent(title.getTitleDetailScreen()), true);
		Logger.log("user is able to view title details screen");
	}
	
	@Then("user should be able to view hold position")
	public void user_should_be_able_to_view_hold_position() {
	    visibilityWait(title.HoldPosition);
	    Assert.assertEquals(title.HoldPosition.isDisplayed(), true);
	    Logger.log("Title Hold position:  "+title.HoldPosition);
	}

	@Then("adult user should be navigated to title details screen")
	public void adult_user_should_be_navigated_to_title_details_screen() {
		Assert.assertEquals(titleList.view_titleCardold(), true);
		Logger.log("user is able to view title details screen");
	}

	@Then("user should be able to view title details screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_title_details_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("cannot automate theme based actions");
	}

	@When("user click back cta")
	public void user_click_back_cta() {
		titleList.navigateBackto_LibScreen();
	}

	@Then("user should be navigated back to last screen")
	public void user_should_be_navigated_back_to_last_screen() {
		Assert.assertTrue(isElementPresent(titleList.getNav_libraryScreen()));
		Logger.log("user is able to navigate Library Screen");
	}

	@Given("adult user should be navigated to library screen")
	public void adult_user_should_be_navigated_to_library_screen() {
		Assert.assertTrue(isElementPresent(titleList.getOld_Nav_libraryScreen()));
	}

	@When("adult user taps on the title card")
	public void adult_user_taps_on_the_title_card() {
		waitFor(4000);
		titleList.old_titleCard();
	}

	// 148855

	@Then("user should be able to select level {int} subject and navigate to titles list screen for that level {int} subject")
	public void user_should_be_able_to_select_level_subject_and_navigate_to_titles_list_screen_for_that_level_subject(
			Integer int1, Integer int2) {
		titleList.click_title_inTitlelist();
		Assert.assertEquals(titleList.getValidate_titleDetailspage().isDisplayed(), true);
	}

}
