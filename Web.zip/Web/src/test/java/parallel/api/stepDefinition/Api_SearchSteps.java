package parallel.api.stepDefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import api.APIClient;
import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.Title;
import api_search.ApiSearch;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;

public class Api_SearchSteps extends CommonAction {
	
//	ApiSearch search = new ApiSearch(DriverManager.getDriver());
//	Login login = new Login(DriverManager.getDriver());
//
//	@Given("user selects the subjects {string}")
//	public void user_selects_the_subjects(String subjects) {
//		search.select_Subjects(subjects);
//	}
//
//	@Given("user selects the categories {string}")
//	public void user_selects_the_categories(String category) {
//		search.select_Categories(category);
//	}
//
//	@Given("user selects the availability dropdown for {string}")
//	public void user_selects_the_availability_dropdown_for(String availability) {
//		search.click_AvailabilityDropdwn(availability);
//	}
//	
//	@Given("user unselects the availability dropdown for {string}")
//	public void user_unselects_the_availability_dropdown_for(String availability) {
//		search.click_AvailabilityDropdwn(availability);
//	}
//
//	@Given("user selects the age level for {string}")
//	public void user_selects_the_age_level_for(String agelevel) {
//	   search.click_AgelevelDropdwn(agelevel);
//	}
//	
//	@Given("user unselects the age level for {string}")
//	public void user_unselects_the_age_level_for(String agelevel) {
//	   search.click_AgelevelDropdwn(agelevel);
//	}
//	@When("user selects the format for {string}")
//	public void user_selects_the_format_for(String format) {
//	   search.click_formatDropdwn(format);
//	}
//	
//	@When("user unselects the language {string}")
//	public void user_unselects_the_language(String string) {
//		
//	}
//	
//	@When("user selects the language {string}")
//	public void user_selects_the_language(String string) {
//	   
//	}
//	@When("user unselects the format for {string}")
//	public void user_unselects_the_format_for(String format) {
//	   search.click_formatDropdwn(format);
//	}
//	
//	@When("user gets the browse results count")
//	public void user_gets_the_browse_results_count() {
//		 int get_CategoryCount = login.get_CategoryCounts();
//		   Assert.assertTrue("Category Title Count: " +get_CategoryCount, login.Results_count.isDisplayed());
//		   Logger.log("Category results Total count: "  + get_CategoryCount);
//	}
}
