package parallel.api.stepDefinition;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import api.APIClient;
import api.TokenManager;
import api.TokenManager.AuthorizationToken;
import api.searchTitlev8.SearchTitleResponse;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ThirdPartySearchSteps {
	private SearchTitleResponse apiResponse;

	@Given("user logs into the {string} using {string} and {string}  using API")
	public void user_logs_into_the_using_and_using_api(String libName, String username, String pin) throws IOException {
		String token = "";
		if (libName.equalsIgnoreCase(AuthorizationToken.AUTOKIDSNYC.toString())) {
			System.out.println("inside new york");
			token = TokenManager.fetchAuthToken(username, pin, AuthorizationToken.AUTOKIDSNYC);
		} else if (libName.equalsIgnoreCase(AuthorizationToken.AUTOKIDSI.toString())) {
			System.out.println("inside independent");
			token = TokenManager.fetchAuthToken(username, pin, AuthorizationToken.AUTOKIDSI);
		} else if (libName.equalsIgnoreCase(AuthorizationToken.AUTOKIDSTEXAS.toString())) {
			System.out.println("inside texas");
			token = TokenManager.fetchAuthToken(username, pin, AuthorizationToken.AUTOKIDSTEXAS);
		} else {
			System.out.println("token retrieved: " + token);
		}
		System.out.println("token retrieved: " + token);
	}
//
//	@Then("the third party search API response result counts match the UI result")
//	public void the_third_party_search_api_response_result_counts_match_the_ui_result() {
//		apiResponse = APIClient.getThirdPartySearchTitleResponse();
//		assertNotNull("API response is null", apiResponse);
//		System.out.println("result count displayed: "
//				+ apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
//	}

	@When("the API response is retrieved from third party search")
	public void the_api_response_is_retrieved_from_third_party_search() {

	}

}
