package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class BrowseBySubject_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of the level one subject list")
	public void capture_the_screenshot_of_level_one_subject_list() {
	    eyes.checkWindow("levelOneBrowseBySubjectScreen");
	}
	
	@Then("capture the screenshot of the level one subject list screen")
	public void capture_the_screenshot_of_level_one_subject_details_screen() {
	    eyes.checkWindow("levelOneBrowseBySubjectDetailsScreen");
	}
	
	@Then("capture the screenshot of the level one subject last list screen")
	public void capture_the_screenshot_of_level_one_subject_last_screen() {
	    eyes.checkWindow("levelOneBrowseBySubjectDetailsLastScreen");
	}
	
	@Then("capture the screenshot of the browse by subject menu")
	public void capture_the_screenshot_of_browse_by_subject_menu() {
		eyes.checkWindow("BrowseBySubjectMenu");
	}
	
//	@Then("capture the screenshot of the level one subject list")
//	public void capture_the_screenshot_of_the_level_one_subject_list() {
//		eyes.checkWindow("LevelOneSubjectist");
//		
//	}
	
	@Then("capture the screenshot of the browse by subject menu for teen profile") 
	public void capture_the_screenshot_of_the_browse_by_subject_menu_for_teen_profile() {
		eyes.checkWindow("BrowseBySbjectForTennProfile");
	}
	
	@Then("capture the screenshot of the level one subject list for teen profile")
	public void capture_the_screenshot_of_the_level_one_subject_list_for_teen_profile() {
		eyes.checkWindow("LevelOneSubjectListForTeenProfile");
	}
	
	@Then("capture the screenshot of the browse by subject menu for kid profile")
	public void capture_the_screenshot_of_the_browse_by_subject_menu_for_kid_profile() {
		eyes.checkWindow("BrowseBySubjectForKidProfile");
	}
	
	@Then("capture the screenshot of the level one subject list for kid profile")
	public void capture_the_screenshot_of_the_level_one_subject_list_for_kid_profile() {
		eyes.checkWindow("LevelOneSubjectListForKidProfile");
	}
	
    @Then("capture the screenshot of the boundless logo in the footer of the my shelf page")
    public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_of_the_my_shelf_page() {
    	eyes.checkWindow("BoundlessLogo-Footer-MyShelf-Page");
    }
    
    @Then("capture the screenshot of the boundless logo in the footer of the programs page")
    public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_of_the_programs_page() {
    	eyes.checkWindow("BoundlessLogo-Footer-programs-Page");
    }
    
    @Then("capture the screenshot of the boundless logo in the footer of my stuff page")
    public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_of_my_stuff_page() {
    	eyes.checkWindow("BoundlessLogo-Footer-MyStuff-Page");
    }
    
    @Then("capture the screenshot of the boundless logo in the footer of the profile management page")
    public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_of_profile_management_page() {
    	eyes.checkWindow("BoundlessLogo-ProfileManagement-Page");
    }
    
    @Then("capture the screenshot of the boundless logo in the footer of my library page")
    public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_of_my_library_page() {
    	eyes.checkWindow("BoundlessLogo-MyLibrary-Page");
    }

}
