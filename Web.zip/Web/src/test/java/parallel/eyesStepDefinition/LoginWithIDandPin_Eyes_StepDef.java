package parallel.eyesStepDefinition;


import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import pom.kidszone.Loginpageview;
import pom.kidszone.Profilecreation;

public class LoginWithIDandPin_Eyes_StepDef {
	
	public static final Logger logger = LoggerFactory.getLogger(Loginpageview.class);
	Eyes eyes = EyesManager.getEyes();
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginview = new Loginpageview(DriverManager.getDriver());
	CommonAction common = new CommonAction();
	
	@Then("capture the screenshot of the LoginScreen")
	public void capture_the_screenshot_of_the_login_screen() {
		common.WaitForWebElement(loginview.getCarouselTitle());
	    eyes.checkWindow("LoginScreen");
	}

	@Then("capture the screenshot of the updatedLoginScreen")
	public void capture_the_screenshot_of_updated_Login_Screen() {
		 eyes.checkWindow("updatedLoginScreen");
	}

	@Then("capture the screenshot of the updatedPinRecoveryScreen")
	public void capture_the_screenshot_of_updated_pinRecovery_screen() {
		eyes.checkWindow("updatedPinRecoveryScreen");
	}

	@Then("capture the screenshot of the forgotPinctaScreen")
	public void capture_the_screenshot_of_forgotPincta_screen() {
		eyes.checkWindow("forgotPinctaScreen");
	}

	@Then("capture the screenshot of the securityQuestionScreen")
	public void capture_the_screenshot_of_securityQuestion_screen() {
		eyes.checkWindow("securityQuestionScreen");
	}

	@Then("capture the screenshot of the forgotPasswordctaScreen")
	public void capture_the_screenshot_of_forgotPassword_screen() {
		eyes.checkWindow("forgotPassword_screen");
	}
	
	@Then("capture the screenshot of the credentialsEnterScreen")
	public void capture_the_screenshot_of_the_credentials_enter_screen() {
//		common.WaitForWebElement(loginview.getTxt_userName_Textfield());
		eyes.checkWindow("credentialsEnterScreen");
	}

	@Then("capture the screenshot of the updatedRegistrationWithPinScreen")
	public void capture_the_screenshot_of_the_updatedRegistrationWithPinScreen() {
		common.WaitForWebElement(loginview.getReg_Username());
		eyes.checkWindow("updatedRegistrationWithPinScreen");
	}
	
	@Then("capture the screenshot of the filledRegistrationWithPinScreen")
	public void capture_the_screenshot_of_the_filledRegistrationWithPinScreen() {
		common.WaitForWebElement(loginview.getReg_Username());
		eyes.checkWindow("filledRegistrationWithPinScreen");
	}
	
	@Then("capture the screenshot of the updatedRegistrationWithoutPinScreen")
	public void capture_the_screenshot_of_the_updatedRegistrationWithoutPinScreen() {
		common.WaitForWebElement(loginview.getReg_Username());
		eyes.checkWindow("updatedRegistrationWithoutPinScreen");
	}
	
	@Then("capture the screenshot of the filledRegistrationWithoutPinScreen")
	public void capture_the_screenshot_of_the_filledRegistrationWithoutPinScreen() {
		common.WaitForWebElement(loginview.getReg_Username());
		eyes.checkWindow("filledRegistrationWithoutPinScreen");
	}

	@Then("capture the screenshot of the viewProfilesOnRegisterPageScreen")
	public void capture_the_screenshot_of_the_viewProfilesOnRegisterPage_screen() {
		eyes.checkWindow("viewProfilesOnRegisterPageScreen");
	}
	
	@Then("capture the screenshot of the parentalPinScreen")
	public void capture_the_screenshot_of_parentalPin_screen() {
		eyes.checkWindow("parentalPinScreen");
	}
	
	@Then("capture the screenshot of the manageProfileScreen")
	public void capture_the_screenshot_of_manageProfileScreen() {
//		common.WaitForWebElement(profile.getProfilesList());
		eyes.checkWindow("manageProfileScreen");
	}
	
	@Then("capture the screenshot of the homeScreen")
	public void capture_the_screenshot_of_homeScreen() {
		eyes.checkWindow("homeScreen");
	}
	
	@Then("capture the screenshot of the parentalPinEnterScreen")
	public void capture_the_screenshot_of_the_parentalPinEnterScreen() {
		eyes.checkWindow("parentalPinEnterScreen");
	}

	@Then("capture the screenshot of the profile creation pageScreen")
	public void capture_the_screenshot_of_the_profile_creation_pageScreen() {
		eyes.checkWindow("profilecreationPageScreen");
	}
	
	@Then("capture the screenshot of the profileSetPinScreen")
	public void capture_the_screenshot_of_the_profileSetPinScreen() {
		eyes.checkWindow("profileSetPinScreen");
	}
	
	@Then("capture the screenshot of the RegisterPageScreen")
	public void capture_the_screenshot_of_the_RegisterPagePinScreen() {
		eyes.checkWindow("RegisterPageScreen");
	}
	
	@Then("capture the screenshot of the FilledInformationOnRegisterPageScreen")
	public void capture_the_screenshot_of_the_FilledInformationOnRegisterPageScreen() {
		eyes.checkWindow("FilledInformationOnRegisterPageScreen");
	}
	
	@Then("capture the screenshot of the authenticationFailedScreen")
	public void capture_the_screenshot_of_the_authenticationFailedScreen() {
		eyes.checkWindow("authenticationFailedScreen");
	}
	
	@Then("capture the screenshot of the profileDetailsScreen")
	public void capture_the_screenshot_of_the_profileDetailsScreen() {
//		common.WaitForWebElement(profile.getProfileImage());
		eyes.checkWindow("profileDetailsScreen");
	}
	
	@Then("capture the screenshot of the profileListScreen")
	public void capture_the_screenshot_of_the_profileListScreen() {
//		common.WaitForWebElement(profile.getProfilesList());
		eyes.checkWindow("profileListScreen");
	}
	
	@Then("capture the screenshot of the savedDetailsScreen")
	public void capture_the_screenshot_of_the_savedDetailsScreen() {
		eyes.checkWindow("savedDetailsScreen");
	}
	
	@Then("capture the screenshot of the confirmarionPopScreen")
	public void capture_the_screenshot_of_the_confirmarionPopScreen() {
		eyes.checkWindow("confirmarionPopScreen");
	}
	
	@Then("capture the screenshot of the Add a teen option selected")
		public void capture_the_screenshot_of_the_addATeenOptionSelectedScreen() {
		eyes.checkWindow("addATeenOptionSelectedScreen");
	}
	
	@Then("capture the screenshot of the Add a kid option selected")
	public void capture_the_screenshot_of_the_addAKidOptionSelectedScreen() {
		eyes.checkWindow("addAKidOptionSelectedScreen");
	}
	
	@Then("capture the screenshot of the Add a adult option selected")
	public void capture_the_screenshot_of_the_addAAdultOptionSelectedScreen() {
		eyes.checkWindow("addAAdultOptionSelectedScreen");
	}
	
	@Then("capture the screenshot profileNoAdultOptionPresent")
	public void capture_the_screenshot_of_the_profileNoAdultOptionPresent() {
		eyes.checkWindow("profileNoAdultOptionPresent");
	}
	
	@Then("capture the screenshot of the profilePageScreen")
	public void capture_the_screenshot_of_the_profilePageScreen() {
		eyes.checkWindow("profilePageScreen");
	}
	
	@Then("capture the screenshot of the profilePinSetErrorMessage")
	public void capture_the_screenshot_of_the_profilePinSetErrorMessage() {
		eyes.checkWindow("profilePinSetErrorMessage");
	}
	
	@Then("capture the screenshot of the pinResetScreen")
	public void capture_the_screenshot_of_the_pinResetScreen() {
		eyes.checkWindow("pinResetScreen");
	}
	
	@Then("capture the screenshot of the securityQuestionAnswerScreen")
	public void capture_the_screenshot_of_the_securityQuestionAnswerScreen() {
		eyes.checkWindow("securityQuestionAnswerScreen");
	}
	
	@Then("capture the screenshot of the enterNewPinScreen")
	public void capture_the_screenshot_of_the_enterNewPinScreen() {
		eyes.checkWindow("enterNewPinScreen");
	}
	
	@Then("capture the screenshot of the incorrectAnswerToastMessageScreen")
	public void capture_the_screenshot_of_the_incorrectAnswerToastMessageScreen() {
		eyes.checkWindow("incorrectAnswerToastMessageScreen");
	}
	
	@Then("capture the screenshot of the parentalPinOptionScreen")
	public void capture_the_screenshot_of_the_parentalPinOptionScreen() {
		eyes.checkWindow("parentalPinOptionScreen");
	}
	
	@Then("capture the screenshot of the incorrectPinEnterScreen")
	public void capture_the_screenshot_of_the_incorrectPinEnterScreen() {
		eyes.checkWindow("incorrectPinEnterScreen");
	}
	
	@Then("capture the screenshot of the resetPinScreen")
	public void capture_the_screenshot_of_the_resetPinScreen() {
		eyes.checkWindow("resetPinScreen");
	}
	
	@Then("capture the screenshot of the resetPinToastScreen")
	public void capture_the_screenshot_of_the_resetPinToastScreen() {
		eyes.checkWindow("resetPinToastScreen");
	}
	
	@Then("capture the screenshot of the createProfileScreen")
	public void capture_the_screenshot_of_the_createProfileScreen() {
		eyes.checkWindow("createProfileScreen");
	}
	
	@Then("capture the screenshot of the createProfileToastMessageScreen")
	public void capture_the_screenshot_of_the_createProfileToastMessageScreen() {
		try {
			if(profile.getProfile_errormessage_createTeenprofile().isDisplayed());
			logger.info("Teen profile has been created successfully");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Toast msg not displayed");
		}	
		eyes.checkWindow("createProfileToastMessageScreen");
	}
	
	@Then("capture the screenshot of the profilePinSetScreen")
	public void capture_the_screenshot_of_the_profilePinSetScreen() {
		eyes.checkWindow("profilePinSetScreen");
	}
	
	@Then("capture the screen for SSO login screen")
	public void capture_the_screenshot_of_the_SSOLoginScreen() {
		eyes.checkWindow("SSOLoginScreen");
	}
	
	@Then("capture the screenshot of the profilePinSet")
	public void capture_the_screenshot_of_profilePinSetScreen() {
		eyes.checkWindow("profilePinSetScreen");
	}
	
	@Then("capture the screenshot of the error toast message")
	public void capture_the_screenshot_of_the_error_toast_message() {
		eyes.checkWindow("errorToastMessage");
	}

	@Then("capture the screenshot of the reset pin error message")
	public void capture_the_screenshot_of_the_reset_pin_error_message() {
		eyes.checkWindow("resetPinErrorMessage");
	}

	@Then("capture the screenshot of the reset pin page")
	public void capture_the_screenshot_of_the_reset_pin_page() {
		eyes.checkWindow("resetPinPage");
	}

	@Then("capture the screenshot of the reset pin page after entering security question")
	public void capture_the_screenshot_of_the_reset_pin_page_after_entering_security_question() {
		eyes.checkWindow("resetPinPageAfterEnteringSecurityQuestion");
	}
}
