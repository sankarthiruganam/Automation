package api.MagicWall;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Category {
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	@JsonProperty("Description") 
	private String description;
	private String pageNumber;
    private String paramCatagory;
    private String paramCatagoryAvail;
    private String paramCatagoryFormats;
    private String paramCatagoryName;
    private SearchParameters searchParameters;
    private String searchSort;
    private String searchSortOrder;
    private Titles titles;
    
    
    public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getParamCatagory() {
		return paramCatagory;
	}
	public void setParamCatagory(String paramCatagory) {
		this.paramCatagory = paramCatagory;
	}
	public String getParamCatagoryAvail() {
		return paramCatagoryAvail;
	}
	public void setParamCatagoryAvail(String paramCatagoryAvail) {
		this.paramCatagoryAvail = paramCatagoryAvail;
	}
	public String getParamCatagoryFormats() {
		return paramCatagoryFormats;
	}
	public void setParamCatagoryFormats(String paramCatagoryFormats) {
		this.paramCatagoryFormats = paramCatagoryFormats;
	}
	public String getParamCatagoryName() {
		return paramCatagoryName;
	}
	public void setParamCatagoryName(String paramCatagoryName) {
		this.paramCatagoryName = paramCatagoryName;
	}
	public SearchParameters getSearchParameters() {
		return searchParameters;
	}
	public void setSearchParameters(SearchParameters searchParameters) {
		this.searchParameters = searchParameters;
	}
	public String getSearchSort() {
		return searchSort;
	}
	public void setSearchSort(String searchSort) {
		this.searchSort = searchSort;
	}
	public String getSearchSortOrder() {
		return searchSortOrder;
	}
	public void setSearchSortOrder(String searchSortOrder) {
		this.searchSortOrder = searchSortOrder;
	}
	public Titles getTitles() {
		return titles;
	}
	public void setTitles(Titles titles) {
		this.titles = titles;
	}
    
    

}
