package api.MagicWall;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class GetTitlesResponse {
	@JsonIgnoreProperties(ignoreUnknown = true)
	private TitleResponse getTitleResponse;

	public TitleResponse getGetTitleResponse() {
		return getTitleResponse;
	}

	public void setGetTitleResponse(TitleResponse getTitleResponse) {
		this.getTitleResponse = getTitleResponse;
	}


}
