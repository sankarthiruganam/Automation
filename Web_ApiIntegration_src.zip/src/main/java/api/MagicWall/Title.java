package api.MagicWall;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Title {
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	@JsonProperty("AxisAttribute") 
	private String axisAttribute;
	@JsonProperty("BookLength") 
	private String bookLength;
	@JsonProperty("ISBN")
    private String iSBN;
	@JsonProperty("IsRTV") 
    private Boolean isRTV;
	@JsonProperty("OnOrderQuantity")
    private int onOrderQuantity;
	@JsonProperty("RunTime") 
    private Object runTime;
	@JsonProperty("TotalQuantity")
    private int	 totalQuantity;
    private String audience;
    private Authors authors;
    private String bookTitle;
    private String edition;
    private String formatType;
    private String imageURL;
    private String isAcoustik;
    private String isAvailable;
    private String isBLIO;
    private String isCheckout;
    private String isEPub;
    private String isHold;
    private String isPDF;
    private Narrators narrators;
    private String publicationDate;
    private String publisher;
    private String purchaseOption;
    private String series;
    private String subject;
    private String synopsis;
    private String titleID;
    
    
    
    public String getAxisAttribute() {
		return axisAttribute;
	}
	public void setAxisAttribute(String axisAttribute) {
		this.axisAttribute = axisAttribute;
	}
	public String getBookLength() {
		return bookLength;
	}
	public void setBookLength(String bookLength) {
		this.bookLength = bookLength;
	}
	public String getiSBN() {
		return iSBN;
	}
	public void setiSBN(String iSBN) {
		this.iSBN = iSBN;
	}
	public Boolean getIsRTV() {
		return isRTV;
	}
	public void setIsRTV(Boolean isRTV) {
		this.isRTV = isRTV;
	}
	public int getOnOrderQuantity() {
		return onOrderQuantity;
	}
	public void setOnOrderQuantity(int onOrderQuantity) {
		this.onOrderQuantity = onOrderQuantity;
	}
	public Object getRunTime() {
		return runTime;
	}
	public void setRunTime(Object runTime) {
		this.runTime = runTime;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getAudience() {
		return audience;
	}
	public void setAudience(String audience) {
		this.audience = audience;
	}
	public Authors getAuthors() {
		return authors;
	}
	public void setAuthors(Authors authors) {
		this.authors = authors;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String getFormatType() {
		return formatType;
	}
	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public String getIsAcoustik() {
		return isAcoustik;
	}
	public void setIsAcoustik(String isAcoustik) {
		this.isAcoustik = isAcoustik;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public String getIsBLIO() {
		return isBLIO;
	}
	public void setIsBLIO(String isBLIO) {
		this.isBLIO = isBLIO;
	}
	public String getIsCheckout() {
		return isCheckout;
	}
	public void setIsCheckout(String isCheckout) {
		this.isCheckout = isCheckout;
	}
	public String getIsEPub() {
		return isEPub;
	}
	public void setIsEPub(String isEPub) {
		this.isEPub = isEPub;
	}
	public String getIsHold() {
		return isHold;
	}
	public void setIsHold(String isHold) {
		this.isHold = isHold;
	}
	public String getIsPDF() {
		return isPDF;
	}
	public void setIsPDF(String isPDF) {
		this.isPDF = isPDF;
	}
	public Narrators getNarrators() {
		return narrators;
	}
	public void setNarrators(Narrators narrators) {
		this.narrators = narrators;
	}
	public String getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPurchaseOption() {
		return purchaseOption;
	}
	public void setPurchaseOption(String purchaseOption) {
		this.purchaseOption = purchaseOption;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getTitleID() {
		return titleID;
	}
	public void setTitleID(String titleID) {
		this.titleID = titleID;
	}
    

}
