package api.MagicWall;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TitleResult {
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	@JsonProperty("VersionType") 
	private int versionType;
	private Categories catagories;
    private Object searchParameters;
    private Status status;
    
    
    public Integer getVersionType() {
		return versionType;
	}
	public void setVersionType(Integer versionType) {
		this.versionType = versionType;
	}
	public Categories getCatagories() {
		return catagories;
	}
	public void setCatagories(Categories catagories) {
		this.catagories = catagories;
	}
	public Object getSearchParameters() {
		return searchParameters;
	}
	public void setSearchParameters(Object searchParameters) {
		this.searchParameters = searchParameters;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}

}
