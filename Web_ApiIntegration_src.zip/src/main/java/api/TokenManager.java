package api;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import api.APIClient.RequestMethod;
import api.patronProfileInfo.PatronProfileInfo;

public class TokenManager {
	static String patronId ;

	@JsonProperty("token")
    private static String token;

	@JsonProperty("patronProfileInfo")
    private static PatronProfileInfo patronProfileInfo;

	@JsonProperty("acoustikSessionId")
    private static String acoustikSessionId;

	@JsonProperty("patronGUID")
    private static String patronGUID;

	@JsonProperty("bookVaultUUID")
    private static String bookVaultUUID;

	@JsonProperty("bookVaultPassword")
    private static String bookVaultPassword;
    
    private static String libPrefix;
    
    

    public static String getLibPrefix() {
		return libPrefix;
	}

	public static void setLibPrefix(String libPrefix) {
		TokenManager.libPrefix = libPrefix;
	}

	@JsonProperty("token")
    public  static String getToken() {
		return token;
	}

	public void setToken(String token) {
		TokenManager.token = token;
	}

	public PatronProfileInfo getPatronProfileInfo() {
		return patronProfileInfo;
	}

	public void setPatronProfileInfo(PatronProfileInfo patronProfileInfo) {
		TokenManager.patronProfileInfo = patronProfileInfo;
	}

	public String getAcoustikSessionId() {
		return acoustikSessionId;
	}

	public void setAcoustikSessionId(String acoustikSessionId) {
		TokenManager.acoustikSessionId = acoustikSessionId;
	}

	public static String getPatronGUID() {
		return patronGUID;
	}

	public void setPatronGUID(String patronGUID) {
		TokenManager.patronGUID = patronGUID;
	}

	public static String getBookVaultUUID() {
		return bookVaultUUID;
	}

	public void setBookVaultUUID(String bookVaultUUID) {
		TokenManager.bookVaultUUID = bookVaultUUID;
	}

	public String getBookVaultPassword() {
		return bookVaultPassword;
	}

	public void setBookVaultPassword(String bookVaultPassword) {
		TokenManager.bookVaultPassword = bookVaultPassword;
	}

	public static String fetchAuthToken(String username, String pin, AuthorizationToken authorization) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		InputStream inputStream=null;
		try {
			
			String env = System.getenv("ENVIRONMENT");
			if (env == null) {
				env = System.getProperty("ENVIRONMENT");

			}
			if (env.equalsIgnoreCase("QA4")) {

				inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/QA4_api-config.json");
				System.out.println("Inside the QA4 env " + inputStream);
			} else if (env.equalsIgnoreCase("UAT")) {
	
				inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/UAT_api-config.json");
				System.out.println("Inside the UAT env " + inputStream);
			}
//			InputStream inputStream = APIClient.class.getClassLoader().getResourceAsStream("config/UAT_api-config.json");
			JsonNode configNode = objectMapper.readTree(inputStream);

			JsonNode searchTitleConfig = configNode.get("authPatron");
			String baseUrl = searchTitleConfig.get("baseUrl").asText();
			String endpoint = searchTitleConfig.get("endpoint").asText();

			Map<String, String> requestBody = new HashMap<String, String>();
			Map<String, String> headers = objectMapper.convertValue(searchTitleConfig.get("headers"),
					new TypeReference<Map<String, String>>() {
					});
			headers.put("Authorization", authorization.getDescription());
			System.out.println("Authorization: " + authorization.getDescription());
			requestBody.put("username", username);

			requestBody.put("pin", pin);

			TokenManager responseTokenManager = APIClient.makeRequest(baseUrl, endpoint, RequestMethod.POST, requestBody,
                    null, headers, TokenManager.class);
            
            assertNotNull("API response is null", responseTokenManager);
            setLibPrefix(authorization.toString().substring(0, 11));
            System.out.println("lib value is " + authorization);
            patronId = TokenManager.getPatronGUID();
            return TokenManager.getToken();
            
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to read configuration file.");
		}
	}

 
public enum AuthorizationToken {
	
    AUTOKIDSNYC("HMAC512 BoundlessAppAPI&8703AA30-BBE7-EC11-B656-28187855D0A0&45&de1r6s+c4U6dGTwn2QhcW/Hfc9gKdpfB94jpBv4F6eVa40RMEApqlCbjykLiNDrUk3XBuxEJWrgxIEKEMc1jvA==&1693413346"),
    AUTOKIDSI("HMAC512 BoundlessAppAPI&22F4E31F-00FE-EC11-B47A-28187855E183&45&PvOYkGOzrq/Pp5Mo0U2nyXN5KSN4whb4jmss4V2vcz0Nl1ISewRG9d7IT0VVSnJYVA+x5VxD+cMl87w+4ulWxg==&1693429589"),
    AUTOKIDSTEXAS("HMAC512 BoundlessAppAPI&BC4DE874-02FE-EC11-B47A-28187855E183&45&x9mZtPRyZO7iwhzo554iLMgn2r+y6udJnBtqWf7TA2c5SLs1t0Zg2w7eC1lmeloo1sPYQPsO2ISU3HteSt0HQA==&1693429589"),
	AUTOKIDSNYC_QA4("HMAC512 BoundlessAppAPI&1CD7D273-91E5-EC11-B656-0003FF192C44&45&6xQdR8PnxyBAIOfT/A39moUiVlvhVByDk4OBDBv4nrHjNtpZ5QCtrkwlVJzjDgDhAzwmBcVeG1Ft9IpZgPucIg==&1702368681");
	
	private final String description;

    AuthorizationToken(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    	}
	}
}


