package api.getRecommendations;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecommendationsResponse {

	@JsonProperty("totalCount")
	private String totalCount;

	@JsonProperty("pageNo")
	private int pageNo;

	@JsonProperty("pageSize")
	private int pageSize;

	@JsonProperty("recommendedTitles")
	private ArrayList<RecommendedTitle> recommendedTitles;

	@JsonProperty("PatronGUID")
	private String patronGUID;

	@JsonProperty("responseCode")
	private int responseCode;

	public String getTotalCount() {
		return this.totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return this.pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public ArrayList<RecommendedTitle> getRecommendedTitles() {
		return this.recommendedTitles;
	}

	public void setRecommendedTitles(ArrayList<RecommendedTitle> recommendedTitles) {
		this.recommendedTitles = recommendedTitles;
	}

	public String getPatronGUID() {
		return this.patronGUID;
	}

	public void setPatronGUID(String patronGUID) {
		this.patronGUID = patronGUID;
	}

	public int getResponseCode() {
		return this.responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

}
