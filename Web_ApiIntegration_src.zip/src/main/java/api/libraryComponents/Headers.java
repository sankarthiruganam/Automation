package api.libraryComponents;

class Headers {
    // Define headers properties
}
