package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Authors {
	
	@JsonProperty("author")
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

}
