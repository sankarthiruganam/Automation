package api.magicWallList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TitlesList {
	
	@JsonProperty("title")
	private List<Title> title;

	public List<Title> getTitle() {
		return title;
	}

	public void setTitle(List<Title> title) {
		this.title = title;
	}

}
