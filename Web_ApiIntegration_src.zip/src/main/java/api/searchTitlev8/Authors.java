package api.searchTitlev8;

public class Authors {
    // The "author" field can be a single string or an array of strings
    private Object author;

    public Object getAuthor() {
        return author;
    }

    public void setAuthor(Object author) {
        this.author = author;
    }
}


