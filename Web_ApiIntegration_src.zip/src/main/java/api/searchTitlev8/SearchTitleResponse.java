package api.searchTitlev8;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchTitleResponse {
	@JsonProperty("version")
    private String version;

	@JsonProperty("encoding")
    private String encoding;

	@JsonProperty("searchTitleResponse")
    private SearchTitleResponseData searchTitleResponseData;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public SearchTitleResponseData getSearchTitleResponseData() {
        return searchTitleResponseData;
    }

    public void setSearchTitleResponseData(SearchTitleResponseData searchTitleResponseData) {
        this.searchTitleResponseData = searchTitleResponseData;
    }
}

