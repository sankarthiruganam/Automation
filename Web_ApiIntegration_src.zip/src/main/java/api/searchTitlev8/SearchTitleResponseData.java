package api.searchTitlev8;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchTitleResponseData {
	@JsonProperty("@xmlns")
    private String xmlns;

	@JsonProperty("@xmlns$xsi")
    private String xmlnsXsi;

	@JsonProperty("@xmlns$xsd")
    private String xmlnsXsd;

	@JsonProperty("searchTitleResult")
    private SearchTitleResult searchTitleResult;

    public String getXmlns() {
        return xmlns;
    }

    public void setXmlns(String xmlns) {
        this.xmlns = xmlns;
    }

    public String getXmlnsXsi() {
        return xmlnsXsi;
    }

    public void setXmlnsXsi(String xmlnsXsi) {
        this.xmlnsXsi = xmlnsXsi;
    }

    public String getXmlnsXsd() {
        return xmlnsXsd;
    }

    public void setXmlnsXsd(String xmlnsXsd) {
        this.xmlnsXsd = xmlnsXsd;
    }

    public SearchTitleResult getSearchTitleResult() {
        return searchTitleResult;
    }

    public void setSearchTitleResult(SearchTitleResult searchTitleResult) {
        this.searchTitleResult = searchTitleResult;
    }
}
