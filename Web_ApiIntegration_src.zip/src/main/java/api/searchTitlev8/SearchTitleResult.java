package api.searchTitlev8;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchTitleResult {
    private Status status;
    private SearchParameters searchParameters;
    @JsonProperty("resultCount")
    private String resultCount;
    @JsonProperty("eBookCount")
    public static String eBookCount;
    @JsonProperty("eAudioBookCount")
    public static String eAudioBookCount;
    private TitlesList titlesList;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public SearchParameters getSearchParameters() {
        return searchParameters;
    }

    public void setSearchParameters(SearchParameters searchParameters) {
        this.searchParameters = searchParameters;
    }

    public String getResultCount() {
        return resultCount;
    }

    public void setResultCount(String resultCount) {
        this.resultCount = resultCount;
    }

    public String geteBookCount() {
        return eBookCount;
    }

    public void seteBookCount(String eBookCount) {
        this.eBookCount = eBookCount;
    }

    public String geteAudioBookCount() {
        return eAudioBookCount;
    }

    public void seteAudioBookCount(String eAudioBookCount) {
        this.eAudioBookCount = eAudioBookCount;
    }

    public TitlesList getTitlesList() {
        return titlesList;
    }

    public void setTitlesList(TitlesList titlesList) {
        this.titlesList = titlesList;
    }
}

