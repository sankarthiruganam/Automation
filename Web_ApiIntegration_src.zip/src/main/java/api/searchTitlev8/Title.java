package api.searchTitlev8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Title {
	@JsonProperty("@xmlns")
    private String xmlns;
    private String bookTitle;
    private Authors authors;
    private Narrators narrators;
    private String titleID;
    private String formatType;
    private String iSBN;
    private String imageURL;
//    private String narrators;
    private String publicationDate;
    private String series;
    private String synopsis;
    private String purchaseOption;
    private String publisher;
    private String subject;
    private String edition;
    private String audience;
    private String isAvailable;
    private String isBLIO;
    private String isAcoustik;
    private String isPDF;
    private String isEPub;
    private String isHold;
    @JsonProperty("axisAttribute")
    private String axisAttribute;
    private String language;
    private String audienceCode;
    private String runTime;
    private String createdDate;
    
    // getters and setters
	public String getXmlns() {
		return xmlns;
	}
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
    
	public List<String> getAuthors() {
		if(authors == null) {
			return new ArrayList<>(); // Return an empty list for null authors
		} else if (authors.getAuthor() instanceof String) {
                return Collections.singletonList((String) authors.getAuthor());
            } else if (authors.getAuthor() instanceof List) {
                // Cast the list of authors to a list of strings
                List<?> authorList = (List<?>) authors.getAuthor();
                return authorList.stream()
                        .map(Object::toString)
                        .collect(Collectors.toList());
            } else {
            	// Handle unexpected type if needed
                return new ArrayList<>(); // Return an empty list as default
        }
    }
	
	public void setAuthors(Authors authors) {
		this.authors = authors;
	}
	
    public List<String> getFormattedNarrators() {
        if (narrators == null) {
            return new ArrayList<>(); // Return an empty list for null narrators
        } else if (narrators.getNarrator() instanceof String) {
            return Collections.singletonList((String) narrators.getNarrator());
        } else if (narrators.getNarrator() instanceof List) {
            List<?> narratorList = (List<?>) narrators.getNarrator();
            return narratorList.stream()
                    .map(Object::toString)
                    .collect(Collectors.toList());
        } else {
            // Handle unexpected type if needed
            return new ArrayList<>(); // Return an empty list as default
        }
    }
	
	public void setNarrators(Narrators narrators) {
		this.narrators = narrators;
	}
	
	public String getTitleID() {
		return titleID;
	}
	public void setTitleID(String titleID) {
		this.titleID = titleID;
	}
	public String getFormatType() {
		return formatType;
	}
	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}
	public String getiSBN() {
		return iSBN;
	}
	public void setiSBN(String iSBN) {
		this.iSBN = iSBN;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
//	public String getNarrators() {
//		return narrators;
//	}
//	public void setNarrators(String narrators) {
//		this.narrators = narrators;
//	}
	public String getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getPurchaseOption() {
		return purchaseOption;
	}
	public void setPurchaseOption(String purchaseOption) {
		this.purchaseOption = purchaseOption;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String getAudience() {
		return audience;
	}
	public void setAudience(String audience) {
		this.audience = audience;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public String getIsBLIO() {
		return isBLIO;
	}
	public void setIsBLIO(String isBLIO) {
		this.isBLIO = isBLIO;
	}
	public String getIsAcoustik() {
		return isAcoustik;
	}
	public void setIsAcoustik(String isAcoustik) {
		this.isAcoustik = isAcoustik;
	}
	public String getIsPDF() {
		return isPDF;
	}
	public void setIsPDF(String isPDF) {
		this.isPDF = isPDF;
	}
	public String getIsEPub() {
		return isEPub;
	}
	public void setIsEPub(String isEPub) {
		this.isEPub = isEPub;
	}
	public String getIsHold() {
		return isHold;
	}
	public void setIsHold(String isHold) {
		this.isHold = isHold;
	}
	public String getAxisAttribute() {
		return axisAttribute;
	}
	public void setAxisAttribute(String axisAttribute) {
		this.axisAttribute = axisAttribute;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getAudienceCode() {
		return audienceCode;
	}
	public void setAudienceCode(String audienceCode) {
		this.audienceCode = audienceCode;
	}
	public String getRunTime() {
		return runTime;
	}
	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
    
}

