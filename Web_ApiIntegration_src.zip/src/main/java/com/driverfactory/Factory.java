package com.driverfactory;

import java.net.MalformedURLException;

import java.net.URL;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.driverfactory.DriverFactory.Target;

public interface Factory {

	WebDriver createDriver(Target target);

	default WebDriver createRemoteDriver() {
		String USERNAME = System.getenv("BROWSERSTACK_USERNAME");
		String ACCESS_KEY = System.getenv("BROWSERSTACK_ACCESS_KEY");
		String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@hub.browserstack.com/wd/hub";
		DesiredCapabilities caps = new DesiredCapabilities();

		if (System.getProperty("browser").equalsIgnoreCase("android")) {
			caps.setCapability("browserName", "android");
			caps.setCapability("device", "Samsung Galaxy Tab S8");
			caps.setCapability("realMobile", "true");
			caps.setCapability("os_version", "12.0");
		} else if (System.getProperty("browser").equalsIgnoreCase("chrome")) {
			caps.setCapability("os", "Windows");
			caps.setCapability("os_version", "11");
			caps.setCapability("browser", "Chrome");
			caps.setCapability("browser_version", "latest-1");
					
		}
		if (System.getProperty("browser").equalsIgnoreCase("edge")) {
			caps.setCapability("os", "Windows");
			caps.setCapability("os_version", "11");
			caps.setCapability("browser", "Edge");
			caps.setCapability("browser_version", "latest-1");
		} else if (System.getProperty("browser").equalsIgnoreCase("firefox")) {
			caps.setCapability("browserName", "Firefox");
			caps.setCapability("browserVersion", "latest");
			caps.setCapability("os", "Windows");
			caps.setCapability("osVersion", "11");
			caps.setCapability("local", "false");
			caps.setCapability("seleniumVersion", "3.141.59");
		} else if (System.getProperty("browser").equalsIgnoreCase("safari")) {
			caps.setCapability("os", "OS X");
			caps.setCapability("os_version", "Big Sur");
			caps.setCapability("browser", "Safari");
			caps.setCapability("browser_version", "14.0");
			caps.setCapability("browserstack.local", "false");
			caps.setCapability("browserstack.selenium_version", "3.141.59");

		} else if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
//			caps.setCapability("browserName", "Safari");
			caps.setCapability("device", "iPad Air 4");
			caps.setCapability("realMobile", "true");
			caps.setCapability("local", "false");
			caps.setCapability("os_version", "14");
		} else if (System.getProperty("browser").equalsIgnoreCase("firefox")) {
			caps.setCapability("browserName", "Firefox");
			caps.setCapability("browserVersion", "latest");
			caps.setCapability("os", "Windows");
			caps.setCapability("osVersion", "11");
			caps.setCapability("local", "false");
			caps.setCapability("seleniumVersion", "3.141.59");
		}

		caps.setCapability("project", "KidsZone_Automation");
		caps.setCapability("build", "SmokeUATEnv_290823");


		try {
			return new RemoteWebDriver(new URL(URL), caps);
		} catch (MalformedURLException e) {
			System.out.println(String.format("URL not valid for remote browser", URL));
		}
		return null;
	}
}
