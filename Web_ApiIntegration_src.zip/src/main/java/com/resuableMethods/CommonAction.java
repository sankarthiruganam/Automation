package com.resuableMethods;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.apache.commons.io.FileUtils;
//import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class CommonAction {

	public static Properties props;
	public static WebDriver driver = null;

	public void findByClick(WebElement element) {

		if (element.isDisplayed() && element.isEnabled()) {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
			WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
			webelement.click();
		} else {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 25);
			WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
			js.executeScript("arguments[0].click();", webelement);
		}
	}

	public static void ClickOnWebElement(WebElement element) {

		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 5);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.click();

	}
	
	public void waitForInvisibilityOf(String xpath) {
	    WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 7);

	    try {
	        // Use a List<WebElement> to check for the existence of the element
	        List<WebElement> webElements = DriverManager.getDriver().findElements(By.xpath(xpath));
	        
	        // Check if the element exists
	        if (webElements.size() > 0) {
	            // Wait for the first element found to become invisible
	            wait.until(ExpectedConditions.invisibilityOf(webElements.get(0)));
	        } else {
	            Logger.log("Element with XPath '" + xpath + "' is not found, no need to wait for invisibility.");
	        }
	    } catch (TimeoutException e) {
	        Logger.log("Element with XPath '" + xpath + "' is still visible after the specified wait time or was never displayed.");
	    }
	}



	public static void visibilityListWait(List<WebElement> element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
			exwait.until(ExpectedConditions.visibilityOfAllElements(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void inVisibilityWait(WebElement element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
			exwait.until(ExpectedConditions.invisibilityOf(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void visibilityWait(WebElement element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 8);
			exwait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void WaitForWebElement(WebElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 5);
		exwait.until(ExpectedConditions.visibilityOf(element));
	}



	public static void WaitForListWebElement(List<WebElement> element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		exwait.until(ExpectedConditions.visibilityOfAllElements(element));
	}

	public static void highLighterMethod(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}

	public static void SendKeysOnWebElement(WebElement element, String Value) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.clear();
		webelement.sendKeys(Value);
	}
//
//	public static void jsClick(WebElement element) {
//		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 15);
//		WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
//		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
//		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');",
//				webelement);
//		waitForDocumentToLoad();
//		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", webelement, "");
//		js.executeScript("arguments[0].click();", webelement);
//	}
	
	public static void jsClick(WebElement element) {
	    WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 7);
	    WebElement webelement = wait.until(ExpectedConditions.elementToBeClickable(element));

	    JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
	    js.executeScript("arguments[0].click();", webelement);
	}
	
	public static void clickByXPath(String elementId) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 5);
		WebElement element = DriverManager.getDriver().findElement(By.xpath(elementId));
		exwait.until(ExpectedConditions.visibilityOf(element));
		element.click();
	}
	
	public static void clickById(String elementId) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 5);
		WebElement element = DriverManager.getDriver().findElement(By.id(elementId));
		exwait.until(ExpectedConditions.visibilityOf(element));
		element.click();
	}


	
	public static void waitForDocumentToLoad() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 10);

		// Wait for page load to complete (wait until document.readyState is 'complete')
		wait.until(webDriver -> ((String) js.executeScript("return document.readyState")).equals("complete"));
	}


	public static void waitFor(int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void javascriptScroll(WebElement element) {
		waitForDocumentToLoad();
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');",
				element);
//		waitForDocumentToLoad();
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
		js.executeScript("arguments[0].scrollIntoView();", element);

	}

	public static void scrollingDown(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wt = new WebDriverWait(driver, 10);
		wt.until(ExpectedConditions.visibilityOf(element));
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	public static void SendKeysEnter(WebElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.clear();
		webelement.sendKeys(Keys.ENTER);

	}

	public void pagescrollDown() throws IOException, Exception {
		for (int i = 0; i <= 1; i++) {
			waitFor(3000);
			javaScriptScrollToEnd();
		}
	}

	public static void scrollingup(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wt = new WebDriverWait(driver, 100);
		wt.until(ExpectedConditions.visibilityOf(element));
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void javaScriptScrollToEnd() {
		waitForDocumentToLoad();
		((JavascriptExecutor) DriverManager.getDriver())
				.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public void switchToTabs(String currentHandle) {

		Set<String> handles = DriverManager.getDriver().getWindowHandles();
		for (String actual : handles) {
			if (!actual.equalsIgnoreCase(currentHandle)) {
				DriverManager.getDriver().switchTo().window(actual);
			}
		}
	}

	public int generateRandomNumber() {
		Random rand = new Random();
		int randNumber = rand.nextInt(100000);
		return randNumber;

	}

	public boolean isElementPresent(WebElement e)

	{
		waitForDocumentToLoad();
		boolean flag = true;
		try {
			e.isDisplayed();
			flag = true;
		} catch (Exception a) {
			flag = false;
		}
		return flag;
	}

	public static void loadData() throws IOException {
		props = new Properties();
		String env = System.getenv("ENVIRONMENT");
		if (env == null) {
			env =System.getProperty("ENVIRONMENT");
			
		}
		if(env.equalsIgnoreCase("QA2"))
		{
		FileInputStream ip = new FileInputStream("./src/test/resources/config/QA2.properties");
		props.load(ip);
		}
		else if (env.equalsIgnoreCase("UAT"))
		{
			FileInputStream ip = new FileInputStream("./src/test/resources/config/UAT.properties");
			props.load(ip);	
		}
		else if (env.equalsIgnoreCase("QA4"))
		{
			FileInputStream ip = new FileInputStream("./src/test/resources/config/QA4.properties");
			props.load(ip);	
		}
	}

	public static String getData(String data) throws IOException {
		loadData();
		data = props.getProperty(data);
		return data;
	}

	public String RandomStringGenerate() {
//		return RandomStringUtils.randomAlphanumeric(3);
		return org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(3);
	}

	public static void swipeDown() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();

		int scrollStart = (int) (dimension.getHeight() * 0.5);

		int scrollEnd = (int) (dimension.getHeight() * 0.2);

		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart))

				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(0, scrollEnd))

				.release().perform();

	}

	public static void takeScreenshot(WebDriver driver, String filename) throws IOException {
		waitFor(2000);
		File sc = (File) ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sc, new File(filename));
	}

	
	public static void mouseHover(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.moveToElement(element).build().perform();
	}
	
	

}
