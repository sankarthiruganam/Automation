package pom.kidszone;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;

public class AdminDashboardPage extends CommonAction {

	public AdminDashboardPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	static ExcelReader reader = new ExcelReader();

	@FindBy(xpath = "//*[@id='UserName']")
	private WebElement txt_login_Username;

	@FindBy(xpath = "//*[@id='Password']")
	private WebElement txt_login_password;

	@FindBy(xpath = "//*[@type='submit']")
	private WebElement btn_login;

	@FindBy(xpath = "//a[text()='Log Off'")
	private WebElement lnk_logoff;

	public void adminLogin() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Login");
		WaitForWebElement(txt_login_Username);
		SendKeysOnWebElement(txt_login_Username, testData.get(0).get("AdminUsername"));
		WaitForWebElement(txt_login_password);
		SendKeysOnWebElement(txt_login_password, testData.get(0).get("AdminPassword"));
		ClickOnWebElement(btn_login);
	}

	public void btAdminLogin() throws InvalidFormatException, IOException {


	}

	public void accessbtAdminLibrarySettings() {

	}

	public void btAdminEnableLibrarySetting() {

	}

	public void btAdminDisableLibrarySetting() {

	}

	public void accessAdminLibrarySettings() {

	}

	public void btAdminLogout() {

	}

	public void adminLogout() {

	}
}
