package pom.kidszone;

import java.util.List;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.resuableMethods.Highlighter;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Holds extends CommonAction {

	static ExcelReader reader = new ExcelReader();
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());

	public Holds(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "LogOnModel_UserName")
	private WebElement userId;

	@FindBy(xpath = "//input[@id='LogOnModel_UserName']")
	private WebElement userIdAxis;

	@FindBy(id = "LogOnModel_Password")
	private WebElement passworD;

	@FindBy(id = "loc_btnLogin")
	private WebElement loginSubmit;

	@FindBy(id = "LibraryManagement")
	private WebElement librarymanagementMenu;

	@FindBy(xpath = "(//*[@class='kz-custom-container-secondary'])[1]")
	private WebElement libraryPage;

	@FindBy(id = "loginBtn")
	private WebElement logIn;

	@FindBy(id = "loginBtnMobile")
	private WebElement logInMobile;

	@FindBy(xpath = "//*[@class='login-container']")
	private WebElement logInPopUp;

	@FindBy(xpath = "(//*[contains(text(),'My Shelf')])[1]")
	private WebElement link_MyShelf;

	@FindBy(id = "loc_linkSignOut")
	private WebElement logOut;

	@FindBy(xpath = "(//button[@class='okBtn ng-star-inserted'])")
	private WebElement logOutYes;

	@FindBy(xpath = "(//*[@class='mat-tab-links'])")
	private WebElement myShelfTab;

	@FindBy(xpath = "//a[contains(text(),' Holds')]")
	public static WebElement holdMenu;

	@FindBy(id = "loc_txtHolds")
	public static WebElement holdPage;

	@FindBy(xpath = "(//*[@class='no-stuffs ng-star-inserted'])")
	private WebElement noStuffHold;

	@FindBy(xpath = "(//*[@class='card-body'])")
	private WebElement titleInHold;

	@FindBy(xpath = "(//*[contains(text(),'ON HOLD')])[1]")
	private WebElement holdStatus;

	@FindBy(xpath = "(//*[@class='mystuff-grids ng-star-inserted'])")
	private WebElement titleListView;
	
	@FindBy(xpath = "(//div[@class='kz-stuff-book-image'])[1]")
	public WebElement mystuff_titlecard_navTier3;

	@FindBy(xpath = "(//*[@class='title-sec'])[1]")
	private WebElement titleName;

	@FindBy(xpath = "(//*[@class='kz-card-text'])[1]")
	private WebElement authorName;

	@FindBy(xpath = "(//*[@class='mystuff-card-image'])[1]")
	private WebElement coverImage;

	@FindBy(xpath = "(//*[contains(text(),'Hold Position:')])[1]")
	private WebElement holdPosition;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-info-icon'])[1]")
	private WebElement toolTipIcon;

	@FindBy(id = "loc_btnSort")
	public static WebElement sortButton;

	@FindBy(xpath = "//*[@class='cdk-overlay-pane']")
	private WebElement sortOptions;

	@FindBy(id = "loc_Recently Added")
	private WebElement sortLatestHold;

	@FindBy(id = "loc_Ratings")
	private WebElement sortRating;

	@FindBy(id = "loc_A-Z")
	private WebElement sortAtoZ;

	@FindBy(id = "loc-Grid")
	private WebElement gridButton;

	@FindBy(xpath = "(//*[@class='mat-icon notranslate book-poster-icon mat-icon-no-color'])[1]")
	private WebElement titleFormatIcon;

	@FindBy(xpath = "//*[@class='titledetails-bookwrapper']")
	private WebElement titleList;

	@FindBy(id = "loc_List")
	private WebElement listViewButton;

	@FindBy(id = "loc_profiles")
	private WebElement profileButon;

	@FindBy(xpath = "//*[contains(text(),'PROFILES')]")
	private WebElement profileButonOldUI;

	@FindBy(xpath = "//*[@inputtype='password']")
	private WebElement pinProfileMgmt;

	@FindBy(id = "loc_btnSubmit")
	private WebElement submitPin;

	@FindBy(id = "loc_linkAdultEditProfile")
	private WebElement adultProfile;

	@FindBy(id = "loc_linkTeenEditProfile")
	private WebElement teenProfile;

	@FindBy(id = "loc_linkKidEditProfile")
	private WebElement kidProfile;

	@FindBy(id = "loc_txtProfiles")
	private WebElement profileScreen;

	@FindBy(id = "loc_textalertcontent")
	private WebElement holdsInfo;

	@FindBy(id = "alert-heading")
	private WebElement holdsHeader;

	@FindBy(xpath = "//*[@svgicon='close']")
	private WebElement holdsInfoClose;

	@FindBy(xpath = "//button[contains(text(),'Ok')]")
	private WebElement holdsInfoOK;

	@FindBy(xpath = "(//button[@class='kz-card-btn kz-card-btn-grid primary-action ng-star-inserted'])[1]")
	private WebElement primaryCta;

	@FindBy(xpath = "(//button[@class='kz-card-btn kz-card-btn-list primary-action ng-star-inserted'])[1]")
	private WebElement primaryCtaGrid;

	@FindBy(xpath = "(//*[@aria-label='more option'])[1]")
	private WebElement moreOptions;

	@FindBy(xpath = "(//*[@class='mat-ripple mat-menu-ripple'])[1]")
	private WebElement secondaryCta1;

	@FindBy(xpath = "(//*[@class='mat-ripple mat-menu-ripple'])[1]")
	private WebElement secondaryCta2;

	@FindBy(xpath = "(//*[@class='mystuff-lists ng-star-inserted'])")
	private WebElement titleGridView;

	@FindBy(xpath = "(//*[@class='ui-carousel-items-content'])[1]")
	private WebElement adultLibraryPage;

	@FindBy(xpath = "(//*[contains(text(),'Place Hold')])")
	private List<WebElement> placeHoldCTA;

	@FindBy(xpath = "//p[text()='Success!']")
	private WebElement success_msg;

	@FindBy(xpath = " //*[@id='030a5c3a-0c92-d3b8-aacf-a1f837f8f304']")
	private WebElement boundless_popup;
	
	@FindBy(xpath = "(//*[contains(text(),'Remove Hold')])[1]")
	public static WebElement primaryCta_RemoveHold;
	
	@FindBy(xpath = "(//*[contains(text(),' Suspend Hold ')])[1]")
	public static WebElement secondaryCta_SuspendHold;
	
	@FindBy(xpath = "(//*[contains(text(),'Place Hold')])[1]")
	public static WebElement PrimaryCta_PlaceHold;
	
	@FindBy(xpath = "(//*[contains(text(),'Wishlist')])[1]")
	public static WebElement WishList_in_Detailspage;
	

	public WebElement getPrimaryCta() {
		return primaryCta;
	}

	public WebElement getLogInPopUp() {
		return logInPopUp;
	}

	public WebElement getPrimaryCtaGrid() {
		return primaryCtaGrid;
	}

	public WebElement getAdultLibraryPage() {
		return adultLibraryPage;
	}

	public WebElement getLink_MyShelf() {
		return link_MyShelf;
	}

	public WebElement getTitleGridView() {
		return titleGridView;
	}

	public WebElement getUserId() {
		return userId;
	}

	public WebElement getLoginSubmit() {
		return loginSubmit;
	}

	public WebElement getMoreOptions() {
		return moreOptions;
	}

	public WebElement getHoldsInfoOK() {
		return holdsInfoOK;
	}

	public WebElement getProfileScreen() {
		return profileScreen;
	}

	public WebElement getHoldMenu() {
		return holdMenu;
	}

	public WebElement getLibraryPage() {
		return libraryPage;
	}

	public WebElement getMyShelfTab() {
		return myShelfTab;
	}

	public WebElement getHoldPage() {
		return holdPage;
	}

	public WebElement getNoStuffHold() {
		return noStuffHold;
	}

	public WebElement getTitleInHold() {
		return titleInHold;
	}

	public WebElement getCoverImage() {
		return coverImage;
	}

	public WebElement getTitleListView() {
		return titleListView;
	}

	public WebElement getTitleName() {
		return titleName;
	}

	public WebElement getAuthorName() {
		return authorName;
	}

	public WebElement getHoldPosition() {
		return holdPosition;
	}

	public WebElement getToolTipIcon() {
		return toolTipIcon;
	}

	public WebElement getTitleList() {
		return titleList;
	}

	public WebElement getLogIn() {
		return logIn;
	}

	public void waitForLoginOldUi() {
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			WaitForWebElement(logInMobile);
		} else if (System.getProperty("browser").equalsIgnoreCase("Android")) {
			WaitForWebElement(logInMobile);
		} else {
			WaitForWebElement(logIn);
		}
	}

	public void admin_login(String username, String password) {
		javascriptScroll(userId);
		SendKeysOnWebElement(userId, username);
		SendKeysOnWebElement(passworD, password);
		ClickOnWebElement(Loginpageview.btn_LoginOnlyId);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		//WaitForWebElement(libraryPage);
	}

	public void adult_login(String username, String password) {
		javascriptScroll(userId);
		SendKeysOnWebElement(userId, username);
		SendKeysOnWebElement(passworD, password);
		ClickOnWebElement(Loginpageview.btn_LoginOnlyId);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		WaitForWebElement(adultLibraryPage);
	}

	public void adult_login_Pop_Up(String username) {
		javascriptScroll(userId);
		SendKeysOnWebElement(userId, username);
		ClickOnWebElement(Loginpageview.btn_LoginOnlyId);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		WaitForWebElement(adultLibraryPage);
	}

	public void logInClick() {
		visibilityWait(logIn);
//		javascriptScroll(logIn);
		jsClick(logIn);
		visibilityWait(Loginpageview.btn_LoginOnlyId);
		//WaitForWebElement(loginSubmit);
	}

	public void myShelfClick() {
		WaitForWebElement(link_MyShelf);
		javascriptScroll(link_MyShelf);
		jsClick(link_MyShelf);
		WaitForWebElement(myShelfTab);
	}

	public void holdClick() {
		//visibilityWait(holdMenu);
		//javascriptScroll(holdMenu);
		WaitForWebElement(holdMenu);
		ClickOnWebElement(holdMenu);
		//jsClick(holdMenu);
		WaitForWebElement(holdPage);
	}

	public void app_logOut() {
		ham.click_HamburgerMenu();
		javascriptScroll(logOut);
		jsClick(logOut);
		WaitForWebElement(logOutYes);
		jsClick(logOutYes);
	}

	public void clickSort() {
		WaitForWebElement(sortButton);
		javascriptScroll(sortButton);
		jsClick(sortButton);
	}

	public void sortOptions() {
		WaitForWebElement(sortLatestHold);
		javascriptScroll(sortLatestHold);
		Assert.assertTrue(sortLatestHold.isDisplayed());
		if (sortRating.isDisplayed()) {
			Assert.assertTrue(sortRating.isDisplayed());
			Assert.assertTrue(sortAtoZ.isDisplayed());
		}
		jsClick(sortLatestHold);
		
	}

	public void clickGrid() {
		WaitForWebElement(gridButton);
		javascriptScroll(gridButton);
		waitFor(2000);
		jsClick(gridButton);
		waitFor(2000);
	}

	public void titleListDetails() {
		Assert.assertTrue(coverImage.isDisplayed());
		Assert.assertTrue(titleFormatIcon.isDisplayed());
		Assert.assertTrue(titleName.isDisplayed());
	}

	public void titleGridDetails() {
		Assert.assertTrue(coverImage.isDisplayed());
		Assert.assertTrue(titleFormatIcon.isDisplayed());
	}

	public void clickTitle() {
		javascriptScroll(coverImage);
		jsClick(coverImage);
		WaitForWebElement(titleList);
	}

	public void holdsHighlight() {
//		holdMenu.getText().contains("[1-9]");
//		holdMenu.getText().contains("Holds");
		waitFor(2000);
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			Logger.log("User able to view Holds Highlighted was verified manually");
		} else if (System.getProperty("browser").equalsIgnoreCase("Android")) {
			waitFor(2000);
			Logger.log("User able to view Holds Highlighted was verified manually");
		} else {
			visibilityWait(holdMenu);
			Highlighter.highLighterMethod(holdMenu, DriverManager.getDriver());
		}
	}

	public void listView() {
		if (isElementPresent(gridButton)) {
			ClickOnWebElement(gridButton);
		} else if (isElementPresent(listViewButton)) {
			ClickOnWebElement(listViewButton);
		}
	}

	public void clickProfile() {
		ham.click_HamburgerMenu();
		waitFor(4000);
		clickProfileAdultOrTeen();
	}

	public void clickProfileAdultOrTeen() {
		if (isElementPresent(profileButon)) {
			jsClick(profileButon);
			WaitForWebElement(profileScreen);
		} else if (isElementPresent(profileButonOldUI)) {
			jsClick(profileButonOldUI);
			WaitForWebElement(profileScreen);
		}
	}

	public void clickSubmit() {
		ClickOnWebElement(submitPin);
	}

	public void clickAdultProfile() {
		WaitForWebElement(adultProfile);
		ClickOnWebElement(adultProfile);
	}

	public void clickTeenProfile() {
		WaitForWebElement(teenProfile);
		ClickOnWebElement(teenProfile);
	}

	public void clickKidProfile() {
		WaitForWebElement(kidProfile);
		ClickOnWebElement(kidProfile);
	}

	public void clickToolTip() {
		javascriptScroll(toolTipIcon);
		jsClick(toolTipIcon);
		waitFor(2000);
		// ClickOnWebElement(toolTipIcon);
	}

	public void holdsInfo(String header, String text) {
		WaitForWebElement(holdsInfo);
		Assert.assertTrue(holdsInfo.isDisplayed());
		Assert.assertTrue(holdsHeader.isDisplayed());
		Assert.assertTrue(holdsHeader.getText().contains(header));
		Assert.assertTrue(holdsInfo.getText().contains(text));
	}

	public void holdsInfoClose() {
		Assert.assertTrue(holdsInfoOK.isDisplayed());
		ClickOnWebElement(holdsInfoOK);
	}

	public void navigateBack() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(coverImage);
	}

	public void idEnter(String id) {
		SendKeysOnWebElement(userIdAxis, id);
		javascriptScroll(loginSubmit);
		ClickOnWebElement(loginSubmit);
		WaitForWebElement(adultLibraryPage);
	}

	public void primaryAction() {
			javascriptScroll(primaryCta_RemoveHold);
			Assert.assertTrue(primaryCta_RemoveHold.isDisplayed());

//		else if (isElementPresent(primaryCtaGrid)) {
//			javascriptScroll(primaryCtaGrid);
//			Assert.assertTrue(primaryCtaGrid.isDisplayed());
//		}
	}

	public void secondaryAction() {
		Assert.assertTrue(moreOptions.isDisplayed());
		ClickOnWebElement(moreOptions);
		WaitForWebElement(secondaryCta2);
		Assert.assertTrue(secondaryCta1.isDisplayed());
		Assert.assertTrue(secondaryCta2.isDisplayed());
	}

	public void gridViewDisplayed() {
		WaitForWebElement(titleGridView);
		Assert.assertTrue(titleGridView.isDisplayed());
	}

	public void listViewDisplayed() {
		//DriverManager.getDriver().navigate().refresh();
		visibilityWait(coverImage);
		visibilityWait(titleListView);
		Assert.assertTrue(titleListView.isDisplayed());
	}

	public void addTitleHold() {
		javascriptScroll(placeHoldCTA.get(1));
		waitFor(2000);
		for (int i = 0; i < placeHoldCTA.size(); i++) {
			ClickOnWebElement(placeHoldCTA.get(i));
			if (isElementPresent(success_msg)) {
				waitFor(2000);
				break;
			} else {
				continue;
			}
		}
		DriverManager.getDriver().navigate().refresh();
	}

	public void clickProfilesOldUI() {
		jsClick(ham.getLink_old_hamburgerMenu());
		WaitForWebElement(profileButonOldUI);
		jsClick(profileButonOldUI);
		WaitForWebElement(profileScreen);
		waitFor(2000);
	}

	public void switchTeenOldUI() {
		clickProfilesOldUI();
		waitFor(2000);
//		if (boundless_popup.isDisplayed()) {
//			jsClick(boundless_popup);
//			waitFor(2000);
//		} else {
//			System.out.println("not displayed");
//		}
		clickTeenProfile();
		waitFor(2000);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
	}

	public void switchKidOldUI() {
		clickProfilesOldUI();
		waitFor(2000);
//		if (boundless_popup.isDisplayed()) {
//			jsClick(boundless_popup);
//			inVisibilityWait(boundless_popup);
//		} else {
//			System.out.println("not displayed");
//		}
		clickKidProfile();
		waitFor(2000);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
	}
	
	public void ValidatePrimaryCtaInWishlistScreen() {
		if (isElementPresent(PrimaryCta_PlaceHold)) {
			Assert.assertTrue(PrimaryCta_PlaceHold.isDisplayed());
		} else {
           Assert.assertTrue(Checkouts.primaryCta_CheckoutInWishScreen.isDisplayed());
		}

	}

}