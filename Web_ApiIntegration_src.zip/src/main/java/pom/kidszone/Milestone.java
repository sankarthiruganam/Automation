package pom.kidszone;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.lang.model.element.Element;

import org.apache.commons.math3.util.ContinuedFraction;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.Logger;
public class Milestone extends CommonAction {

	public Milestone(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "loc_linkPrograms")
	private WebElement menu_programs;
	
	@FindBy(id = "loc_labelMy Programs")
	private WebElement myprograms_tab;
	
	@FindBy(id = "loc_labelOpen Programs")
	private WebElement openprograms_tab;
	
	@FindBy(id = "loc_txtactivePrograms Programs")
	private WebElement Activeprogram_txt;
	
	@FindBy(xpath = "//*[contains(text(),'MilestoneProg ')]")
	public static WebElement ongoingprograms;
	
	@FindBy(xpath = "//*[contains(text(),'Auto_MileStone ')]")
	public static WebElement Activeprog_ongoingprograms;
	
	@FindBy(xpath = "//*[contains(text(),'Automation_upcomingProgram ')]")
	public static WebElement upcomingprograms;
	
	@FindBy(xpath = "(//div[@class='kz-card-details-col-rgt'])[1]")
	private WebElement ongoingprograms_StartDate;
	
	@FindBy(xpath = "(//div[@class='kz-card-details-col-rgt'])[1]")
	private WebElement upcomingprograms_StartDate;
	
	@FindBy(xpath = "(//span[contains(text(),'Started')])[1]")
	private WebElement Activegprograms_banner_started;
	
	@FindBy(xpath = "(//span[contains(text(),'Completed')])[1]")
	private WebElement Activegprograms_banner_Completed;
	
	@FindBy(xpath = "(//span[contains(text(),'Joined')])[1]")
	private WebElement Activegprograms_banner_Joined;
	
	@FindBy(xpath = "(//div[@class='kz-card-images'])[1]")
	public static WebElement Activeprograms_Details;
	
	@FindBy(xpath = "(//h2[@id='loc_activePrograms']/following::mat-card-title)[1]")
	private WebElement Activeprograms_title;
	
	@FindBy(xpath = "(//div[@class='kz-card-desc'])[1]")
	private WebElement Activeprograms_Description;
	
	@FindBy(id = "loc_txt_startDate")
	private WebElement Activeprograms_StartDate;
	
	@FindBy(id = "loc_txt_readByDate")
	private WebElement Activeprograms_EndDate;
	
	@FindBy(xpath = "(//div[@class='kz-card-images'])[1]")
	public static WebElement Activeprogram_Titleimg;
	
	@FindBy(xpath = "//div[@class='kz-reading-programs-details ng-star-inserted']")
	public static WebElement Nav_TitleDetails;
	
	@FindBy(xpath = "//div[@class='kz-reading-programs-details']")
	public static WebElement Nav_updatedTitleDetails;
	
	@FindBy(id = "loc_btnJoinProgram")
	private WebElement joinprogramCTA;
	
	@FindBy(xpath = "(//div[@class='joined kz-program-status ng-star-inserted'])[1]")
	private WebElement Activegprograms_banner;
	
	@FindBy(xpath = "//*[@class='kz-program-status not-completed ng-star-inserted']")
	private WebElement Closedprogm_banner;
	
	@FindBy(xpath = "//*[contains(text(),'MilestoneProg_texas')]")
	private WebElement ClosedProgram;
	
	@FindBy(id = "loc_closedPrograms")
	public static WebElement ClosedProgram_txt;
	
	@FindBy(xpath = "//*[contains(text(),'AutoMilestoneProgram_OngoingProgm')]")
	public static WebElement ongoingprograms_1;
	
	@FindBy(xpath = "//mat-card-title[contains(text(),'upcomingprogram_2 ')]")
	private WebElement Upcomingprograms_1;
	
	@FindBy(xpath = "")
	private WebElement ongoingprograms_withoutEndDate;
	
	@FindBy(xpath = "//h1[@class='kz-reading-programs-title']")
	public static WebElement progDetails_Title;
	
	@FindBy(id = "loc_ProgramDescription")
	public static WebElement progDetails_Description;
	
	@FindBy(id = "loc_txt_startDate")
	public static WebElement progDetails_StartDate;
	
	@FindBy(id = "loc_txt_endDate")
	public static WebElement progDetails_EndDate;
	
	@FindBy(id = "loc_txt_goal")
	private WebElement progDetails_Goal;
	
	@FindBy(id = "loc_txt_COMPLETED")
	private WebElement progDetails_Completed;
	
	@FindBy(id = "loc_txt_joinDate")
	public static WebElement progDetails_JoinDate;
	
	@FindBy(id = "loc_SuggestedTitles")
	public static WebElement progDetails_SuggestedList;
	
	@FindBy(id = "loc_btnLeaveProgram")
	public static WebElement progDetails_LeaveProgram;
	
	@FindBy(id = "loc_textalertcontent")
	public static WebElement progDetails_LeaveProgram_content;
	
	@FindBy(xpath = "//*[contains(text(),'upcomingprogram_2 ')]")
	public static WebElement upcomingProg_WithoutEndDate;
	
	@FindBy(xpath = "")
	public static WebElement physical_EReadprog;
	
	@FindBy(id = "loc_cancelbtn")
	public static WebElement leaveprog_cancel;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement leaveprog_yes;
	
	@FindBy(xpath = "(//div[@class='kz-title-carousel kz-program-card-carousel ng-star-inserted'])[1]")
	public static WebElement Titles_gridview;
	
	@FindBy(id = "loc_btnMilestoneSeeAll")
	public static WebElement Readingprog_SeeAll;
	
	@FindBy(id = "loc_Sort")
	public static WebElement Readingprog_Sort;
	
	@FindBy(id = "loc_Filter")
	public static WebElement Readingprog_Filter;
	
	@FindBy(id = "loc_editPenicon")
	public static WebElement Readingprog_Edit;
	
	@FindBy(id = "loc_Sort_Titles A-Z")
	public static WebElement Sort_ZtoA;
	
	@FindBy(id = "loc_Sort_Titles Z-A")
	public static WebElement Sort_AtoZ;
	
	@FindBy(id = "loc_Filter_eBook")
	public static WebElement Filter_ebook;
	
	@FindBy(id = "loc_Filter_eAudio")
	public static WebElement Filter_eAudio;
	
	@FindBy(xpath = "//button[contains(text(),'Video')]")
	public static WebElement Filter_video;
	
	@FindBy(id = "")
	public static WebElement Filter_vbooks;
	
	@FindBy(id = "loc_Filter_Added By User")
	public static WebElement Filter_Addedbyuser;
	
	@FindBy(id = "loc_editPenicon")
	public static WebElement edit_penicon;
	
	@FindBy(xpath = "(//div[@class='mat-checkbox-frame'])[1]")
	public static WebElement edit_cancelicon_deleteTitle;
	
	@FindBy(xpath = "//*[contains(text(),'Remove')]")
	public static WebElement edit_Remove;
	
	@FindBy(xpath = "//button[contains(text(),'Cancel')]")
	public static WebElement edit_Cancel;
	
	@FindBy(xpath = "//a[contains(text(),'Programs')]")
	public static WebElement programs_breadcrumb;
	
	@FindBy(id = "loc_btnMilestoneSeeAll")
	public static WebElement progDetail_SeeAll;
	
	@FindBy(id = "loc_AddaTitle")
	public static WebElement progDetail_EditReadingList_CTA;
	
	@FindBy(xpath = "//mat-card-title[contains(text(),'BadgeProgram ')]")
	public static WebElement Milestoneprog_BadgeCompleted;
	
	@FindBy(xpath = "//*[contains(text(),' SORT BY')]")
	public static WebElement browse_Sort;
	
	@FindBy(xpath = "(//*[contains(text(),'Publication Date')])[1]")
	public static WebElement browse_publicationDate;
	
	@FindBy(xpath = "(//*[contains(text(),'Return date')])[1]")
	public static WebElement browse_ReturnDate;
	
	@FindBy(xpath = "//*[@id='loc_radiobtnPopularity']/label")
	public static WebElement browse_Popularity;
	
	@FindBy(xpath = "(//*[contains(text(),'Added Date')])[1]")
	public static WebElement browse_AddedDate;
	
	@FindBy(xpath = "(//*[contains(text(),'Title')])[1]")
	public static WebElement browse_Title;
	
	@FindBy(xpath = "(//*[contains(text(),'Author')])[1]")
	public static WebElement browse_Author;
	
	@FindBy(xpath = "//axis360-title-list[@class='ng-star-inserted']")
	public static WebElement browse_resultsScreen;
	
	@FindBy(xpath = "//*[@class='kz-card-image ng-star-inserted']")
	public static List<WebElement> title_cardimg;
	
	
	
	public WebElement getActiveprograms_EndDate() {
		return Activeprograms_EndDate;
	}

	public void Click_programsInmenu() {
		visibilityWait(menu_programs);
		jsClick(menu_programs);
		visibilityWait(myprograms_tab);		
	}
	
	public void click_openProgramTab() {
		jsClick(openprograms_tab);
		waitFor(2000);

	}
	
	public void click_MyprogramTab() {
		visibilityWait(myprograms_tab);
		jsClick(myprograms_tab);
		waitFor(2000);

	}
	
	public void view_ongoingProgTitle() {	
		visibilityWait(ongoingprograms);
		 Date date = new Date();  
		 SimpleDateFormat formatter = new SimpleDateFormat("MMM dd,yyyy");  
		 String strDate = formatter.format(date);
		 System.out.println("current Date: " +strDate);
		 String ProgramDate = ongoingprograms_StartDate.getText();
		 int a = strDate.compareTo(ProgramDate);	
		 if (a>0 || a==0) {
			System.out.println("This program is ongoing");
		}
//		if (ongoingprograms.isDisplayed()) {
//			String programDate = ongoingprograms_StartDate.getText();
//			System.out.println("user is able to view start date" + programDate);
//		}
	}
	
	public void Click_OngoingProgTitle() {
		visibilityWait(ongoingprograms);
		jsClick(ongoingprograms);
		waitFor(2000);

	}
	public void view_upcomingProgTitle() {
		javaScriptScrollToEnd();
		visibilityWait(upcomingprograms);
		javascriptScroll(upcomingprograms);
		if (upcomingprograms.isDisplayed()) {
			String programDate = upcomingprograms_StartDate.getText();
			System.out.println("user is able to view start date" + programDate);
		}
	}
	
	public void click_upcomingProgTitle() {
		javaScriptScrollToEnd();
		javascriptScroll(upcomingprograms);
		jsClick(upcomingprograms);
		waitFor(2000);

	}
	
	public boolean verify_myprogramUnder_Activeprogram() {
		boolean b= true;
		if (Activeprogram_txt.isDisplayed()) {
			ongoingprograms.isDisplayed();
			b=true;
		}
		return b;

	}
	
	public void verify_Activeprogram_banner(String started, String completed, String joined) {
		String start = Activegprograms_banner_started.getText();
		String complete = Activegprograms_banner_Completed.getText();
		String join = Activegprograms_banner_Joined.getText();
		if (start.equalsIgnoreCase(started)) {
			Activegprograms_banner_started.isDisplayed();
			
		}else if (complete.equalsIgnoreCase(completed)) {
			Activegprograms_banner_Completed.isDisplayed();
		} else {
			join.equalsIgnoreCase(joined);
		}
	}
	
	public boolean activeProgram_Details() {
		boolean b=true;
		Activeprograms_title.isDisplayed();
		Activeprograms_Description.isDisplayed();
		Activeprograms_StartDate.isDisplayed();
		return b;
	}
	
	public void click_Activeprogram_NavTitleDatails() {
		visibilityWait(Activeprogram_Titleimg);
		jsClick(Activeprogram_Titleimg);
		WaitForWebElement(Nav_TitleDetails);
	}
	
	public void click_joinProgramCTA() {
		visibilityWait(joinprogramCTA);
		javascriptScroll(joinprogramCTA);
		jsClick(joinprogramCTA);
		try {
			jsClick(leaveprog_yes);
		} catch (Exception e) {
			// TODO: handle exception
		}
		

	}
	
	public void verify_programStatus(String status) {
		switch (status) {
		case "Started":
			Activegprograms_banner.getText().equalsIgnoreCase(status);
			break;
		case "Joined":
			Activegprograms_banner.getText().equalsIgnoreCase(status);
			break;
        case "Completed":
        	Activegprograms_banner.getText().equalsIgnoreCase(status);
			break;
        case "Ends today":
        	Activegprograms_banner.getText().equalsIgnoreCase(status);
			break;
        
		}
	}
	
	public void verify_closedProgramStatus(String status) {
		if (Closedprogm_banner.getText().contains(status)) {
			Logger.log("closed program status is"+ Closedprogm_banner.getText());
		}

	}
	public void click_ClosedProgram() {
		visibilityWait(ClosedProgram_txt);
		javascriptScroll(ClosedProgram_txt);
		if (ClosedProgram_txt.isDisplayed()) {
			jsClick(ClosedProgram);
			visibilityWait(Nav_TitleDetails);
		}

	}
	
	public void click_MilestoneongoingProgram() {
		waitFor(2000);
		javaScriptScrollToEnd();
		waitFor(2000);
		visibilityWait(ongoingprograms_1);
		javascriptScroll(ongoingprograms_1);
		jsClick(ongoingprograms_1);
		visibilityWait(Nav_TitleDetails);

	}
	
	public void click_MilestoneUpcoingProgram() {
		visibilityWait(Upcomingprograms_1);
		javascriptScroll(Upcomingprograms_1);
		jsClick(Upcomingprograms_1);
		visibilityWait(Nav_TitleDetails);

	}
	
	public boolean programDetails_TitleDetails() {
		boolean b=true;
		visibilityWait(progDetails_Title);
		progDetails_Title.isDisplayed();
		progDetails_Description.isDisplayed();
		javascriptScroll(progDetails_StartDate);
		progDetails_StartDate.isDisplayed();
		progDetails_EndDate.isDisplayed();
	    progDetails_Goal.isDisplayed();
	    progDetails_Completed.isDisplayed();
		return b;
	}
	
	public void verify_joinedprogram(String joinedprogram) {
		boolean b=true;
		String Activeprog = ongoingprograms_1.getText();
		if (Activeprog.contains(joinedprogram)) {
			b=true;
		}else {
			b=false;
		}
	}
	
	public void verify_joinedupcomingprogram(String joinedprogram) {
		boolean b=true;
		String Activeprog = Upcomingprograms_1.getText();
		if (Activeprog.contains(joinedprogram)) {
			b=true;
		}else {
			b=false;
		}
	}
	
	public void click_MilestoneongoingProgram_withoutEndDate() {
		visibilityWait(ongoingprograms_withoutEndDate);
		jsClick(ongoingprograms_withoutEndDate);
		visibilityWait(Nav_TitleDetails);

	}
	
	public boolean programDetails_TitleDetails_WithoutEndDate() {
		boolean b=true;
		visibilityWait(progDetails_Title);
		progDetails_Title.isDisplayed();
		progDetails_Description.isDisplayed();
		javascriptScroll(progDetails_StartDate);
		progDetails_StartDate.isDisplayed();
		progDetails_Goal.isDisplayed();
		progDetails_Completed.isDisplayed();
		return b;
	}
	
	public void upcomingprogram_WithoutEndData() {
		javaScriptScrollToEnd();
		jsClick(ongoingprograms_1);
		waitFor(3000);
	}
	
	public void click_Leaveprogram() {
		visibilityWait(progDetails_LeaveProgram);
		jsClick(progDetails_LeaveProgram);
		visibilityWait(leaveprog_yes);
		jsClick(leaveprog_yes);
		waitFor(2000);
		
	}
	
	public void click_LeaveCTA() {
		visibilityWait(progDetails_LeaveProgram);
		jsClick(progDetails_LeaveProgram);

	}
	
	public void click_SeeAllCTA() {
		javascriptScroll(Readingprog_SeeAll);
		jsClick(Readingprog_SeeAll);
		waitFor(2000);
		
	}
	
	public void click_sort() {
		visibilityWait(Readingprog_Sort);
		jsClick(Readingprog_Sort);
		visibilityWait(Sort_AtoZ);
		//WaitForWebElement(Sort_Duedate);

	}
	
//	public boolean view_SortOptions(String LatestCheckout,String Duedate,String atoz, String Ratings) {
//	boolean b=true;
//	Assert.assertEquals(Sort_LatestCheckout.getText(), LatestCheckout);
//	Assert.assertEquals(Sort_Duedate.getText(), Duedate);	
//	Assert.assertEquals(Sort_AtoZ.getText(), atoz);	
//	Assert.assertEquals(Sort_Ratings.getText(), Ratings);
//	return b;

//	}
	
	public  void soryby_Duedate(String sortoptions ) {
		switch (sortoptions) {
		case "Titles A-Z":
			 jsClick(Sort_AtoZ);
			 waitFor(2000);
			 break;
		case "Titles Z-A":
			 jsClick(Sort_ZtoA);
			 waitFor(2000);
			break;
		}	
	}
	
	public void click_Filter() {
		visibilityWait(Readingprog_Filter);
		jsClick(Readingprog_Filter);
		visibilityWait(Filter_eAudio);
	}
	
	public void select_FilterbyEbook(String ebooks) {
		//click_Filter();
		if (Filter_ebook.getText().equalsIgnoreCase(ebooks)) {
			jsClick(Filter_ebook);
			waitFor(2000);
		}
	}
	
	public void select_FilterbyEAudio(String eAudio) {
		click_Filter();
		if (isElementPresent(Filter_eAudio)) {
			jsClick(Filter_eAudio);
			waitFor(2000);
		}
		
	}
	
	public void select_FilterbyVideo(String video) {
		click_Filter();
		if (Filter_video.getText().equalsIgnoreCase(video)) {
			jsClick(Filter_video);
			waitFor(2000);
		}
	}
	
	public void select_FilterbyAddedbyuser(String Addedbyuser) {
		click_Filter();
		if (Filter_Addedbyuser.getText().equalsIgnoreCase(Addedbyuser)) {
			jsClick(Filter_Addedbyuser);
			waitFor(2000);
		}
	}
	
	public void click_edit() {
		visibilityWait(edit_penicon);
		jsClick(edit_penicon);
		waitFor(2000);

	}
	
	public void click_programDetails_Breadcrumb() {
	visibilityWait(programs_breadcrumb);
	jsClick(programs_breadcrumb);
	waitFor(2000);

	}
	
	public void completed_BadgeProgram() {
		visibilityWait(Milestoneprog_BadgeCompleted);
		jsClick(Milestoneprog_BadgeCompleted);
		waitFor(3000);

	}
	
	public void click_closeIcon_delete() {
		javascriptScroll(edit_cancelicon_deleteTitle);
		jsClick(edit_cancelicon_deleteTitle);
		visibilityWait(edit_Remove);
		jsClick(edit_Remove);
	}
	
	
	public void click_BrowseSort() {
		visibilityWait(browse_Sort);
		jsClick(browse_Sort);
		visibilityWait(browse_publicationDate);

	}
	
	
	public void click_BrowseSortoption(String sort) {
		switch (sort) {
		case "Return date":
			visibilityWait(browse_ReturnDate);
			ClickOnWebElement(browse_ReturnDate);
			visibilityWait(browse_resultsScreen);
			break;
		case "Popularity":
			visibilityWait(browse_Popularity);
			ClickOnWebElement(browse_Popularity);
			visibilityWait(browse_resultsScreen);
			break;
		case "Publication Date":
			visibilityWait(browse_publicationDate);
			ClickOnWebElement(browse_publicationDate);
			visibilityWait(browse_resultsScreen);
			break;
		case "Added Date":
			visibilityWait(browse_AddedDate);
			ClickOnWebElement(browse_AddedDate);
			visibilityWait(browse_resultsScreen);
			break;
		case "Title":
			visibilityWait(browse_Title);
			ClickOnWebElement(browse_Title);
			visibilityWait(browse_resultsScreen);
			break;
		case "Author":
			visibilityWait(browse_Author);
			ClickOnWebElement(browse_Author);
			visibilityWait(browse_resultsScreen);
			break;

		}

	}
	
}
