package pom.kidszone;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class MyShelfscreen extends CommonAction {

	static ExcelReader reader = new ExcelReader();
	WebDriver driver;

	public MyShelfscreen(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//ul[@id='main-menu']//*[text()=' My Shelf ']")
	private WebElement HamburgerMenu_btn_myshelf;

	@FindBy(xpath = "//li[@class='menu-item']")
	private List<WebElement> Menu_btn_listofMenus;

	@FindBy(xpath = "//a[@href='/MyStuff?type=checkout']")
	private WebElement Menu_btn_checkout;

	@FindBy(id = "loc_txtCheckouts")
	private WebElement Adultprofile_txt_checkoutScreen;

	@FindBy(xpath = "//h2[normalize-space()='Holds']")
	private WebElement Adultprofile_txt_HoldsScreen;

	@FindBy(xpath = "//a[text()=' See all ']")
	private WebElement myshelf_btn_interestSurveyseeAllcta;

	@FindBy(id = "loc_labelCheckouts")
	private List<WebElement> teenrofile_btn_navigationList;

	@FindBy(xpath = "//h2[text()='book-of-month']")
	private WebElement libraryscreen_txt_BookOfmonth;

	@FindBy(id = "loc_labelCheckouts")
	private WebElement myshelf_txt_checkoutCount;

	@FindBy(xpath = "//a[@class='nav-item ng-star-inserted']")
	private WebElement myshelf_btn_checkTitle;

	@FindBy(id = "loc_labelPurchase Requests")
	private WebElement myshelf_btn_RecommendationsTitle;

	@FindBy(id = "loc_labelwishlist")
	public static WebElement myshelf_btn_wishlistTitle;

	@FindBy(xpath = "(//h2[contains(text(),'Based On Your Interests')]/following::div[@class='kz-carousel'])[1]")
	private WebElement menu_btn_Recommendations;

	@FindBy(xpath = "//div[@class='mystufftitlepnl_titlecont_info']")
	private List<WebElement> Adultmyshelf_label_viewcheckoutCountBooks;

	@FindBy(xpath = "//p[contains(text(),'You currently have no checked out titles.')]")
	private WebElement myshelf_txt_NocheckoutCount;

	@FindBy(xpath = "//div[@class='bookinfo-parameter']")
	private List<WebElement> Adultprofile_txt_checkoutScreenEbook;

	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private List<WebElement> teenProfile_rightArrow_interestSurveyCarousel;

	@FindBy(xpath = "//h2[text()='Based on your Interests']")
	private WebElement myshelf_text_interestSurveyTitle;

	@FindBy(xpath = "//div[@class='carousel-arrow carousel-arrow-next']")
	private List<WebElement> teenProfile_leftArrow_interestSurveyCarousel;

	@FindBy(xpath = "//span[text()='Advanced Search']")
	private List<WebElement> myshelf_btn_checkoutscreen;

	@FindBy(id = "loc_labelHolds")
	private WebElement myshelf_btn_Holdscreen;

	@FindBy(id = "loc_txtWishlist")
	private WebElement myshelf_txt_wishlistscreen;

	@FindBy(id = "loc_txtPurchase Requests")
	private WebElement myshelf_txt_Recommendationscreen;

	@FindBy(id = "loc_txtCheckout History")
	private WebElement myshelf_txt_checkouthistorytsscreen;

	@FindBy(id = "loc_labelhistory")
	private WebElement myshelf_btn_Historyscreen;

	@FindBy(id = "loc_labelAverageRead")
	private WebElement myshelf_Average_Read;

	@FindBy(id = "loc_labelAverageRead")
	private WebElement myshelf_Minutes_Read;

	@FindBy(id = "loc_labelAverageListened")
	private WebElement myshelf_Average_Listened;

	@FindBy(id = "loc_labelCurrentStreak")
	private WebElement myshelf_Current_Streak;

	@FindBy(id = "loc_labelBooksReadMonth")
	private WebElement myshelf_Books_Read_Month;

	@FindBy(id = "loc_labelBooksReadYear")
	private WebElement myshelf_Books_Read_Year;

	@FindBy(id = "loc_labelBooksListenedMonth")
	private WebElement myshelf_Books_Listened_Month;

	@FindBy(id = "loc_labelBooksListenedYear")
	private WebElement myshelf_Books_Listened_Year;

	@FindBy(id = "loc_labelSetReadingGoal")
	private WebElement Popup_ReadingGoal;

	@FindBy(id = "loc_BtnRemoveGoal")
	private WebElement Btn_RemoveGoal;

	@FindBy(id = "loc_labelSetListeningGoal")
	private WebElement Popup_ListeningGoal;

	@FindBy(id = "loc_labelSetStreakingGoal")
	private WebElement Popup_Set_StreakGoal;

	@FindBy(id = "loc_labelSetMonthlyBookGoal")
	private WebElement Popup_Set_MonthlyBookGoal;

	@FindBy(id = "loc_labelSetYearlyGoal]")
	private WebElement Popup_Set_YearlyBookGoal;

	@FindBy(id = "loc_labelSetYearlyGoal")
	private WebElement Popup_Set_YearGoal;

	@FindBy(id = "loc_labelSetMonthlyListened")
	private WebElement Popup_ListenedMonth;

	@FindBy(id = "loc_labelSetYearlyListenedGoal")
	private WebElement Popup_ListenedYear;

	@FindBy(id = "goal-input")
	private WebElement TxtBox_GoalInput;

	@FindBy(id = "loc_BtnSetGoal")
	private WebElement Btn_SetGoal;

	@FindBy(xpath = "//mat-error[contains(text(),'Please enter a whole number between 1 and 999.')]")
	private WebElement Txt_MinsErrorMsg;

	@FindBy(xpath = "//mat-error[contains(text(),'Please enter a whole number between 1 and 365.')]")
	private WebElement Txt_DaysErrorMsg;

	@FindBy(xpath = "//mat-error[contains(text(),'Whoops! Your goal could not be set. Please enter a whole number between 1 and 9999')]")
	private WebElement Txt_YearlsErrorMsg;

	@FindBy(id = "loc_txtAvailability")
	private WebElement Nav_libaryScreen;

	@FindBy(xpath = "//h2[contains(text(),'Based On Your Interests')]")
	public static WebElement txt_basedonYourInterest;

	@FindBy(xpath = "//a[text()='MYSHELF']")
	private WebElement Btn_old_myshelf;

	@FindBy(xpath = "(//div[@class='carousel-arrow carousel-arrow-next'])[1]")
	private WebElement goals_rightarrow;

	@FindBy(id = "loc_labelCurrentlyCheckoutOut")
	public static WebElement nav_currentlyCheckout;
	
	@FindBy(xpath = "//*[@class='kz-toast-msg']")
	private WebElement success_msg;

	public WebElement getBtn_old_myshelf() {
		return Btn_old_myshelf;
	}

	public WebElement getNav_libaryScreen() {
		return Nav_libaryScreen;
	}

	public WebElement getTxt_MinsErrorMsg() {
		return Txt_MinsErrorMsg;
	}

	public WebElement getTxt_DaysErrorMsg() {
		return Txt_DaysErrorMsg;
	}

	public WebElement getTxt_YearlyErrorMsg() {
		return Txt_YearlsErrorMsg;
	}

	public WebElement getPopup_ReadingGoal() {
		return Popup_ReadingGoal;
	}

	public WebElement getPopup_ListeningGoal() {
		return Popup_ListeningGoal;
	}

	public WebElement getPopup_Set_StreakGoal() {
		return Popup_Set_StreakGoal;
	}

	public WebElement getPopup_Set_MonthlyBookGoal() {
		return Popup_Set_MonthlyBookGoal;
	}

	public WebElement getPopup_Set_YearlyBookGoal() {
		return Popup_Set_YearlyBookGoal;
	}

	public WebElement getPopup_Set_YearGoal() {
		return Popup_Set_YearGoal;
	}

	public WebElement getPopup_ListenedMonth() {
		return Popup_ListenedMonth;
	}

	public WebElement getPopup_ListenedYear() {
		return Popup_ListenedYear;
	}

	public List<WebElement> getTeenrofile_btn_navigationList() {
		return teenrofile_btn_navigationList;
	}

	public WebElement getMyshelf_text_interestSurveyTitle() {
		return myshelf_text_interestSurveyTitle;
	}

	public List<WebElement> getMyshelf_label_viewcheckoutCountBooks() {
		return Adultmyshelf_label_viewcheckoutCountBooks;
	}

	public WebElement getAdultprofile_txt_checkoutScreen() {
		return Adultprofile_txt_checkoutScreen;
	}

	public WebElement getMyshelf_txt_NocheckoutCount() {
		return myshelf_txt_NocheckoutCount;
	}

	public WebElement getLibraryscreen_txt_BookOfmonth() {
		return libraryscreen_txt_BookOfmonth;
	}

	public WebElement getHamburgerMenu_btn_myshelf() {
		return HamburgerMenu_btn_myshelf;
	}

	/***************************************
	 * Action
	 **************************************/

	public boolean view_Myshelfmenuitem() {
		boolean displayedmyshelf = true;
		if (Menu_btn_listofMenus.contains("My shelf")) {
			Logger.log("User is able to view myshelf menu item");
		} else {
			Logger.log("User is not able to view myshelf menu item");
		}
		return displayedmyshelf;
	}

	public void menu_clickRecommendation() {
		visibilityWait(menu_btn_Recommendations);
		jsClick(menu_btn_Recommendations);
		waitFor(2000);
	}

	public void shouldnotShow_preference() {
		if (Menu_btn_listofMenus.equals("My Preference")) {
			Logger.log("User is able to view My preference");
		} else {
			Logger.log("User is not able to view My preference");
		}

	}

	public boolean nav_libraryScreen() {
		boolean Myselfscreenotdisplayed = true;
		if (isElementPresent(Nav_libaryScreen)) {
			Myselfscreenotdisplayed = true;
			Logger.log(" myshelf is not set as default landing screen");
			waitFor(2000);
		} else {
			Myselfscreenotdisplayed = false;
		}
		return Myselfscreenotdisplayed;
	}

	public void notSet_CheckoutTitle() {
		if (myshelf_txt_checkoutCount.getText().contains("0")) {
			Logger.log(" user has not checkout any title");
		} else {
			Logger.log(" user has already set checkout any title");
		}

	}

	public void click_MinutesRead() {
		waitFor(2000);
		ClickOnWebElement(myshelf_Minutes_Read);
		waitFor(2000);
	}

	public void click_AvgReadDay() {
		waitFor(2000);
		jsClick(myshelf_Average_Read);
		// ClickOnWebElement(myshelf_Average_Read);
		waitFor(3000);
	}

	public void enter_InvalidGoal() {
		waitFor(2000);
		SendKeysOnWebElement(TxtBox_GoalInput, "Dsf#");
		ClickOnWebElement(Btn_SetGoal);
		waitFor(6000);

	}

	public void enter_ValidGoal() {
		waitFor(2000);
		SendKeysOnWebElement(TxtBox_GoalInput, "120");
		ClickOnWebElement(Btn_SetGoal);
		waitFor(5000);

	}

	public void enter_RemoveGoal() {
		waitFor(2000);
		if (isElementPresent(Btn_RemoveGoal)) {
			System.out.println("remove cta is displayed");
			// jsClick(Btn_RemoveGoal);
			// ClickOnWebElement(Btn_RemoveGoal);
		} else {
			setGoal();
			click_MinutesRead();
			Logger.log("Remove button is not displayed");
		}
	}

	public void click_AvgListenedDay() {
		waitFor(2000);
		ClickOnWebElement(myshelf_Average_Listened);
		waitFor(2000);
	}

	public void click_CurrentStreak() {
		waitFor(2000);
		jsClick(myshelf_Current_Streak);
		waitFor(2000);
	}

	public void click_MonthlyReadGoal() {
		waitFor(2000);
		ClickOnWebElement(myshelf_Books_Read_Month);
		waitFor(2000);
	}

	public void click_YearlyRead() {
		ClickOnWebElement(goals_rightarrow);
		waitFor(1000);
		ClickOnWebElement(goals_rightarrow);
		waitFor(1000);
		ClickOnWebElement(goals_rightarrow);
		waitFor(2000);
		ClickOnWebElement(myshelf_Books_Read_Year);
		waitFor(2000);
	}

	public void click_checkoutMenu() {
		waitFor(2000);

		try {
			ClickOnWebElement(Menu_btn_checkout);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitFor(4000);
	}

	public void click_checkoutTitle() {
		waitFor(2000);
		try {
			if (isElementPresent(myshelf_txt_checkoutCount)
					&& myshelf_btn_checkTitle.getAttribute("aria-label").contains("Checkouts")) {
				ClickOnWebElement(myshelf_txt_checkoutCount);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		waitFor(3000);
	}

	public void view_checkoutBooksAdultProfile() {
		for (int i = 0; i < Adultmyshelf_label_viewcheckoutCountBooks.size(); i++) {
			if (Adultmyshelf_label_viewcheckoutCountBooks.get(i).isDisplayed()) {
				Logger.log(" user has not checkout any title");
			}
		}
	}

	public void click_eReaderNavToebook() {
		ClickOnWebElement(Adultmyshelf_label_viewcheckoutCountBooks.get(1));
		waitFor(2000);
		for (int i = 0; i < Adultprofile_txt_checkoutScreenEbook.size(); i++) {
			if (Adultprofile_txt_checkoutScreenEbook.get(i).getText().contains("eBook")) {
				Logger.log(" user is click on the title in focus and navigate to ereader if it is an ebook");
			} else {
				Logger.log(" user is click on the title in focus and navigate to ereader if it is an adudio player");
			}
		}

	}

	public void view_checkoutTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("Checkouts")) {
				Logger.log(" user is able to view checkout title on myshelf screen");
			}
		}
	}

	public void click_NavcheckoutCTA() {
		ClickOnWebElement(teenrofile_btn_navigationList.get(1));
		waitFor(2000);
		if (isElementPresent(Adultprofile_txt_checkoutScreen)) {
			Logger.log(" system should navigate to checkout screen");
		}

	}

	public void clickCheckoutCta() {
		WaitForWebElement(myshelf_txt_checkoutCount);
		ClickOnWebElement(myshelf_txt_checkoutCount);
		WaitForWebElement(Adultprofile_txt_checkoutScreen);
		if (isElementPresent(Adultprofile_txt_checkoutScreen)) {
			Logger.log(" system should navigate to checkout screen");
		}

	}

	public void view_holdsTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("Holds")) {
				Logger.log(" user is able to view holds title on myshelf screen");
			}
		}
	}

	public void click_NavHoldCTA() {
		ClickOnWebElement(myshelf_btn_Holdscreen);
		waitFor(2000);
		if (Adultprofile_txt_HoldsScreen.isDisplayed()) {
			Logger.log("system should navigate to hold screen");
		}

	}

	public void view_wishlistTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("Wishlist")) {
				Logger.log(" user is able to view wishlist title on myshelf screen");
			}
		}
	}

	public void click_NavWishlistCTA() {
		jsClick(myshelf_btn_wishlistTitle);
		// ClickOnWebElement(myshelf_btn_wishlistTitle);
		WaitForWebElement(myshelf_txt_wishlistscreen);
		if (myshelf_txt_wishlistscreen.isDisplayed()) {
			Logger.log(" system should navigate to wishlist screen");
		}

	}

	public void view_RecommendationTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("Recommendations")) {
				Logger.log(" user is able to view Recommendations title on myshelf screen");
			}
		}
	}

	public void click_NavRecommendationsCTA() {
		jsClick(myshelf_btn_RecommendationsTitle);
		// ClickOnWebElement(myshelf_btn_RecommendationsTitle);
		waitFor(2000);
		if (myshelf_txt_Recommendationscreen.isDisplayed()) {
			Logger.log(" system should navigate to wishlist screen");
		}

	}

	public void view_AssignmentsTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("Assignments")) {
				Logger.log(" user is able to view Assignments title on myshelf screen");
			}
		}
	}

	public void click_NavAssignmentsCTA() {
		ClickOnWebElement(teenrofile_btn_navigationList.get(0));
		waitFor(2000);
		if (Adultprofile_txt_checkoutScreen.isDisplayed()) {
			Logger.log(" system should navigate to Assignments screen");
		}

	}

	public void view_HistoryTitleonMyshelf() {
		for (int i = 0; i < teenrofile_btn_navigationList.size(); i++) {
			if (teenrofile_btn_navigationList.get(i).getText().contains("History")) {
				Logger.log(" user is able to view history title on myshelf screen");
			}
		}
	}

	public void click_NavHistoryCTA() {
		ClickOnWebElement(myshelf_btn_Historyscreen);
		WaitForWebElement(myshelf_txt_checkouthistorytsscreen);
		if (myshelf_txt_checkouthistorytsscreen.isDisplayed()) {
			Logger.log(" system should navigate to history screen");
		}

	}

	public void view_interestSurveycarousel() {
		for (int i = 7; i <= 0; i--) {
			if (isElementPresent(teenProfile_rightArrow_interestSurveyCarousel.get(i))) {
				Logger.log(" user is able to view interest survey carousel");
			} else {
				Logger.log(" user is not able to view interest survey carousel");
				waitFor(2000);
			}
		}

	}

	public void interestsSurvey_seeAllcta() {
		waitFor(2000);
		try {
			ClickOnWebElement(myshelf_btn_interestSurveyseeAllcta);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void click_seeAllinterestSurvey() {
		if (isElementPresent(myshelf_btn_interestSurveyseeAllcta)) {
			ClickOnWebElement(myshelf_btn_interestSurveyseeAllcta);
			waitFor(2000);
			isElementPresent(txt_basedonYourInterest);
		} else {
			System.out.println("user is not able to see see all cta");
		}

	}

	public void click_MonthlyBooksRead() {
		waitFor(2000);
		ClickOnWebElement(myshelf_Books_Read_Month);

	}

//	public void click_AvgListenedDay() {
//		waitFor(2000);
//		ClickOnWebElement(myshelf_Average_Listened);
//	}
//	
//	public void click_CurrentStreak() {
//		waitFor(2000);
//		ClickOnWebElement(myshelf_Current_Streak);
//	}

	public void click_YearlyBooksRead() {
		waitFor(2000);
		ClickOnWebElement(myshelf_Books_Read_Year);
	}

	public void click_MonthlyListenedGoal() {
		waitFor(2000);
		visibilityWait(myshelf_Books_Listened_Month);
		ClickOnWebElement(myshelf_Books_Listened_Month);
	}

	public void click_YearlyListenedGoal() {
		ClickOnWebElement(goals_rightarrow);
		waitFor(1000);
		ClickOnWebElement(goals_rightarrow);
		waitFor(1000);
		ClickOnWebElement(goals_rightarrow);
		waitFor(2000);
		ClickOnWebElement(myshelf_Books_Listened_Year);
	}

	public void click_CheckoutCta() {

		ClickOnWebElement(myshelf_txt_checkoutCount);
	}

	public boolean view_basedonyourInterest() {
		javascriptScroll(txt_basedonYourInterest);
		boolean b = true;
		isElementPresent(txt_basedonYourInterest);
		return b;
	}

	public void click_old_myShelfcta() {
		waitFor(2000);
		jsClick(Btn_old_myshelf);
	}

	public void setGoal() {
		javascriptScroll(TxtBox_GoalInput);
		SendKeysOnWebElement(TxtBox_GoalInput, "4");
		waitFor(2000);
		jsClick(Btn_SetGoal);
		WaitForWebElement(success_msg);
	}

}
