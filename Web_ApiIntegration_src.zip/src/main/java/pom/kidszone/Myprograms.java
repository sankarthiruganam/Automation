
package pom.kidszone;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Myprograms extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public Myprograms(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='card-text']")
	private WebElement txt_interestSurveyTopics;

	@FindBy(xpath = "//p[text()='Books in Order']")
	private WebElement txt_books_in_order;

	@FindBy(id = "loc_txtReadingList")
	private WebElement Reading_list;

	@FindBy(xpath = "//button[text()='Leave Program']")
	private WebElement leave_program;

	@FindBy(xpath = "//a[text()='See All']")
	private WebElement see_all_cta;

	@FindBy(xpath = "(//div[@class='book-poster ng-star-inserted'])[1]")
	private WebElement title_format_icon;

	@FindBy(xpath = "(//span[text()='Checkout'])[1]")
	private WebElement primary_action_cta;

	@FindBy(xpath = "(//mat-card[@class='mat-card mat-focus-indicator kz-card ng-star-inserted'])[1]")
	private WebElement title_cta;

	@FindBy(xpath = "//h2[text()='Book Details']")
	private WebElement title_list_screen;

	@FindBy(xpath = "(//span[text()='Checkout'])[2]")
	private WebElement disabled_checkout_cta;

	@FindBy(xpath = "(//span[@class='kz-progressbar-percentage'])[1]")
	private WebElement reading_progress;

	@FindBy(xpath = "//span[text()='100%']")
	private WebElement progress_completion;

	@FindBy(xpath = "//span[text()='Read Now']")
	private WebElement title_readnow;

	@FindBy(xpath = "//mat-card-title[text()='AutoProgram19July ']")
	private WebElement NYC_program;

	@FindBy(xpath = "//h1[text()=' AutoProgram19July ']")
	private WebElement navigate_to_NYC_program_details_screen;

	@FindBy(xpath = "//mat-card-title[text()='AutoProgramXY20July ']")
	private WebElement texas_XY_program;

	@FindBy(xpath = "//mat-card-title[text()='AutoProgramJuly20 ']")
	private WebElement texas_openprogram;

	@FindBy(id = "loc_textalertcontent")
	private WebElement leave_program_toast_msg;

	@FindBy(xpath = "//mat-card-title[text()='AutoLeaveProgramJuly20 ']")
	private WebElement texas_click_leave_program;

	@FindBy(id = "loc_confirmbtnOK")
	private WebElement leave_program_popup_yes;

	@FindBy(id = "loc_cancelbtn")
	private WebElement leave_program_popup_no;

	@FindBy(xpath = "//div[@class='kz-head-group']")
	private List<WebElement> view_listofprogram;

	@FindBy(id = "loc_labelMyPrograms")
	private WebElement Myshelf_txt_myprograms;

	@FindBy(xpath = "(//button[@aria-label='Profile'])[1]")
	private WebElement profile_Icon;

	@FindBy(xpath = "(//button[@aria-label='Profile'])[2]")
	private WebElement profile_Icon_Mobile;

	@FindBy(id = "loc_txtDisplayName")
	private WebElement profile_information_prepopulated;

	@FindBy(xpath = "//button[text()='View settings']")
	private WebElement profilepopup_viewSetting;

	@FindBy(xpath = "//*[@class='kz-pro-edit-img']")
	private WebElement profileSetting_avatar;

	@FindBy(id = "kz-security-que-panel")
	private WebElement profileSetting_securityQues;

	@FindBy(id = "mat-checkbox-2")
	private WebElement profileSetting_AutocheckoutHolds;

	@FindBy(id = "loc_chkboxDisplayCheckoutHistory")
	private WebElement profileSetting_checkoutHistory;

	@FindBy(id = "mat-input-2")
	private WebElement profileSetting_securityAns;

	@FindBy(id = "mat-checkbox-3")
	private WebElement profileSetting_insightsAndBadges;

	@FindBy(id = "loc_linkViewMyinterests")
	private WebElement profileSetting_viewMyInerest;

	@FindBy(id = "loc_linkViewLibraryCards")
	private WebElement viewLibrary_Cards;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement profileSetting_settingPreference;

	@FindBy(id = "loc_profileImg")
	private WebElement updated_avatar;

	@FindBy(xpath = "(//*[@class='btn-empty accountSettingsBtn'])[1]")
	private WebElement updated_avatarAdultTheme;

	@FindBy(id = "loc_chkboxDisplayCheckoutHistory-input")
	private WebElement profileSetting_checkbox_displaycheckoutHistory;

	@FindBy(xpath = "//p[@class='edit-det-sub-head recommendation-limit teen-heading ng-star-inserted']")
	private WebElement scroll_editProfile;

	@FindBy(id = "mat-checkbox-3-input")
	private WebElement profileSetting_checkbox_insightAndbadges;

	@FindBy(xpath = "//button[text()='UPDATE SETTINGS']")
	private WebElement profileSetting_btn_updateSetting;

	@FindBy(id = "loc_dpProfileType")
	private WebElement profileSetting_btn_profileType;

	@FindBy(id = "loc_linkPrograms")
	private WebElement hambergerMenu_programs;
	
	@FindBy(xpath = "//div[@class='mat-tab-list']")
	private WebElement landing_program;

	@FindBy(id = "loc_activePrograms")
	private WebElement txt_activeProgram;

	@FindBy(xpath = "(//*[contains(text(),'My Programs')])[1]")
	private WebElement myprogram_tab;

	@FindBy(id = "programTabss")
	private WebElement myprogramAndopenprogram_tabs;

	@FindBy(id = "loc_labelOpen Programs")
	private WebElement openprogram_tabs;

	@FindBy(xpath = "//*[contains(text(),'upcoming Programs')]")
	private WebElement txt_upcomingProgram;

	@FindBy(xpath = "(//mat-card-title[@class='mat-card-title kz-card-title single-ellipsis'])[2]")
	public static WebElement txt_programName;

	@FindBy(xpath = "//div[@class='kz-card-details-row']")
	private List<WebElement> txt_programdescriptionAndDate;

	@FindBy(xpath = "//*[@class='kz-card-images']")
	private List<WebElement> img_programCoverimg;

	@FindBy(xpath = "//*[@class='kz-card-item ng-star-inserted']")
	private List<WebElement> img_programicon;

	@FindBy(xpath = "//p[text()='members']")
	private List<WebElement> txt_NumberofParticipants;

	@FindBy(id = "loc_txtReadingList")
	public static WebElement txt_NavprogDetailsScreen;

	@FindBy(xpath = "//button[text()='Remove']")
	private List<WebElement> myprogram_deleteCta;

	@FindBy(id = "loc_closedPrograms")
	public static WebElement myprogram_txt_closedProgram;

	@FindBy(xpath = "//p[text()='No Reading Programs Yet']")
	private WebElement myprogram_noprograms;

	@FindBy(xpath = "//div[@class='kz-progress-bar-container']")
	private WebElement overAllprogress;

	@FindBy(xpath = "//span[@class='kz-progressbar-percentage']")
	private List<WebElement> overAllprogress_calculated;

	@FindBy(xpath = "//p[text()='members']")
	private List<WebElement> listofPrograms_participatedin;

	@FindBy(xpath = "//*[text()='active Programs']/following::div[1]")
	public static WebElement myprogram_program_ActiveprogramSection;

	@FindBy(xpath = "//h2[@id='loc_txtclosedPrograms']/following-sibling::div")
	public static WebElement myprogram_program_closedProgramSection;

	@FindBy(xpath = "//div[@class='kz-program-status started']")
	private List<WebElement> myprogram_program_started;

	@FindBy(xpath = "//h1[text()='closed Programs']//following-sibling::div")
	private List<WebElement> myprogram_closedProgm_listofPrograms;

	@FindBy(xpath = "//p[contains(text(),'recommend titles')]")
	private WebElement interest_survey_preferences;

	@FindBy(xpath = "//p[@class='interest-description']")
	private WebElement interestSurvey_description;

	@FindBy(id = "closeButton")
	private WebElement interest_preference_close_cta;

	@FindBy(xpath = "//h2[contains(text(),'PREFERRED AGE LEVEL')]")
	private WebElement prefered_age;

	@FindBy(xpath = "//span[text()='Juvenile']")
	private WebElement juvenile;

	@FindBy(xpath = "//span[text()='Young Adult']")
	private WebElement young_adult;

	@FindBy(xpath = "//span[text()='Adult']")
	private WebElement adult;

	@FindBy(id = "loc_checkboxKid")
	private WebElement kid;

	@FindBy(id = "loc_checkboxTeen")
	private WebElement teen;

	@FindBy(xpath = "//div[@class='card-text']")
	private List<WebElement> topics_for_teen;

	@FindBy(xpath = "//div[@class='intst-txt-sec']")
	private List<WebElement> topics_for_adult;

	@FindBy(xpath = "//div[@class='card-img']")
	private List<WebElement> interestSurvey_icons;

	@FindBy(xpath = "//mat-checkbox[@id='loc_checkboxKid']")
	private WebElement kid_match_box;

	@FindBy(id = "loc_txtSetyourReadingInterest")
	private WebElement teen_and_kid_reading_interest;

	@FindBy(xpath = "//h1[text()='Set Your Reading Preferences']")
	private WebElement adult_reading_preferences;

	@FindBy(id = "loc_btnSaveinterest")
	private WebElement save_button;

	@FindBy(id = "loc_btncancelInterest")
	private WebElement cancel_button;

	@FindBy(xpath = "//p[text()='Adventure Fiction']")
	private WebElement book1_adv_fic;

	@FindBy(xpath = "//p[text()='Biography & Memoir']")
	private WebElement book2_bio_mem;

	@FindBy(xpath = "//p[text()='Business']")
	private WebElement book3_bussiness;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement removeProg_popup;

	@FindBy(id = "closeButton")
	private WebElement preferencepopup_closeicon;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[2]")
	public static WebElement closedProgram_txt_notCompleted;

	@FindBy(xpath = "//mat-card-title[text()='DemoProgramClosed ']")
	public static WebElement closedProgram_name;

	@FindBy(xpath = "//mat-card-title[text()='closedProgram12 ']")
	public static WebElement closedProgram_name2;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[18]")
	public static WebElement closedProgram_startDate;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[21]")
	public static WebElement closedProgram_EndDate;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[24]")
	public static WebElement closedProgram_numberOfparticipants;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[9]")
	public static WebElement closedProgram_coverimg;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[13]")
	public static WebElement closedProgram_progressbar;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[13]")
	public static WebElement nav_closedProgram_programDetailsscreen;

	@FindBy(xpath = "//h2[text()='closed Programs']/following::div[15]")
	public static WebElement closedProgram_programprogress;

	@FindBy(xpath = "//*[@class='carousel-container']")
	public static WebElement progDetailScreen_readinglist;

	@FindBy(xpath = "//div[@class='kz-reading-programs-details ng-star-inserted']")
	public static WebElement progDetailScreen_title;

	@FindBy(xpath = "//div[@class='kz-card-number ng-star-inserted']")
	public static List<WebElement> readlingList_orderNumber;

//	@FindBy(xpath = "(//button[@class='primary-action ng-star-inserted'])[2]")
//	private WebElement primaryaction_checkout;

	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private List<WebElement> readlingList_coverimg;

	@FindBy(xpath = "//*[contains(text(),'See All')]")
	public static WebElement seeAll_cta;

	@FindBy(xpath = "//span[text()='Not completed']")
	private List<WebElement> closedProgram_notCompleted;

	@FindBy(xpath = "//h2[text()='closed Programs']")
	private WebElement closedProgram_Completed;

	@FindBy(xpath = "//*[contains(text(),'Autoprogramjulyyy15 ')]")
	private WebElement closed_xyprograms;
	
	@FindBy(xpath = "(//h2[@id='loc_closedPrograms']/following::img)[1]")
	private WebElement closed_xyprogramsUAT;

	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private List<WebElement> yprograms;

	@FindBy(xpath = "//mat-card-title[text()='xyprogramOngoing ']")
	private WebElement ongoingprogram_adult;

	@FindBy(xpath = "//mat-card-title[text()='xyprogram2 ']")
	private WebElement ongoingprogram_kid;

	@FindBy(xpath = "(//mat-card-title[@class='mat-card-title kz-card-title single-ellipsis'])[2]")
	private WebElement ongoingprogram_booksinOrderadult;

	@FindBy(xpath = "//h1[@class='kz-reading-programs-title']")
	private WebElement progDetailscreen_title;

	@FindBy(xpath = "//p[text()='END DATE']")
	private WebElement progDetailscreen_endDate;

	@FindBy(xpath = "//h4[text()='START DATE']")
	private WebElement progDetailscreen_startdate;

	@FindBy(id = "loc_btnJoinProgram")
	public static WebElement progDetailscreen_joinprogramCTA;

	@FindBy(id = "mat-checkbox-1-input")
	private WebElement adult_checkbox;

	@FindBy(xpath = "(//div[@class='mat-checkbox-frame'])[1]")
	private WebElement teen_checkbox;

	@FindBy(xpath = "(//div[@class='mat-checkbox-frame'])[2]")
	private WebElement kid_checkbox;

	@FindBy(xpath = "(//div[@class='mat-checkbox-frame'])")
	private WebElement kid_fromteen_checkbox;

	@FindBy(xpath = "//div[@class='carousel-arrow carousel-arrow-next']")
	private WebElement carousel_right_button;

	@FindBy(xpath = "//div[@class='carousel-arrow carousel-arrow-prev']")
	private WebElement carousel_left_button;

	@FindBy(xpath = "//p[text()='Animals']")
	private WebElement kid_book1;

	@FindBy(xpath = "//p[text()='Funny Stories']")
	private WebElement kid_book2;

	@FindBy(xpath = "//h2[text()='Based on your Interests']")
	private WebElement based_on_your_interest;

	@FindBy(xpath = "//div[text()='AGE RANGE']")
	private WebElement agelevel_in_bookdetail;

	@FindBy(xpath = "//div[@class='mat-checkbox-inner-container']")
	private List<WebElement> agelevel_checkbox;

	@FindBy(xpath = "(//div[@class='mat-checkbox-frame'])")
	private WebElement validating_kid_checkbox;

	@FindBy(xpath = "//p[text()='Action & Adventure']")
	private WebElement Book1_Magic_Adult;

	@FindBy(xpath = "//p[text()='Biography & Autobiography']")
	private WebElement Book2_Magic_Adult;

	@FindBy(xpath = "//p[text()='Business']")
	private WebElement Book3_Magic_Adult;

	@FindBy(xpath = "//button[text()='Save Preferences']")
	private WebElement save_prefrences_Magic_Adult;

	@FindBy(xpath = "//h1[text()='Set Your Reading Preferences']")
	public static WebElement axis360_intersurveyTopics;

	@FindBy(id = "loc_Ongoing & Upcoming Programs")
	public static WebElement ongoingProg_title;

	@FindBy(id = "loc_Ongoing & Upcoming Programs")
	public static WebElement upcomingProg_title;

	@FindBy(xpath = "(//div[@class='kz-card-images'])[1]")
	public static WebElement active_Prog;

	@FindBy(xpath = "//*[contains(text(),'Autoprogramjulyyy15')]")
	public static WebElement active_ProgUAT;

	@FindBy(xpath = "//*[contains(text(),'xyprogram2upcoming')]")
	public static WebElement upcomingProg_prog;

	@FindBy(xpath = "")
	public static WebElement upcomingProg_progUAT;

	@FindBy(xpath = "//mat-card-title[contains(text(),'Programupcoming ')]")
	public static WebElement upcomingProg_progkid;

	@FindBy(id = "Vector")
	private List<WebElement> titleFormaticon;

	@FindBy(xpath = "(//div[@class='display-date'])[3]")
	public static WebElement ynumberofTitleList;

	@FindBy(id = "loc_btnLeaveProgram")
	public static WebElement leaveProgram;

	@FindBy(xpath = "//*[contains(text(),'ProgramsBooksinOrder')]")
	public static WebElement booksinOrder_prog;

	@FindBy(xpath = "//mat-card-title[text()='AutoProgramXY20July ']")
	public static WebElement xyprgrm_prog;

	@FindBy(xpath = "//h1[text()=' AutoProgramXY20July ']")
	public static WebElement xyprgrm_progTitle;

	@FindBy(xpath = "//h1[text()='Welcome to ']")
	public static WebElement joinprog_confirmPopup;

	@FindBy(xpath = "//button[@type='button']")
	public static WebElement joinprog_letsGetStarted;

	@FindBy(xpath = "//h1[text()=' ProgramsBooksinOrder ']")
	private WebElement booksinOrder_progTitle;

	@FindBy(xpath = "(//mat-icon[text()='close'])[2]")
	private WebElement joinProg_close;

	@FindBy(xpath = "//span[@_ngcontent-bvy-c309]")
	private WebElement joinprog_programName;

	@FindBy(xpath = "(//mat-card-title[@class='mat-card-title kz-card-title single-ellipsis'])[2]")
	private WebElement prog_activeProg;

	@FindBy(xpath = "//*[@id='skip-nav']/axis360-kz-programs/div/axis360-kz-programs-cards/div/div[1]")
	public static WebElement openProg_ongoingProgsection;

	@FindBy(xpath = "//*[@id='skip-nav']/axis360-kz-programs/div/axis360-kz-programs-cards/div/div[2]")
	public static WebElement openProg_upcomingProgsection;

	@FindBy(xpath = "//mat-card-title[@class='mat-card-title kz-card-title single-ellipsis']")
	private List<WebElement> listofProg_ongoing;

	@FindBy(xpath = "(//*[contains(text(),'Checkout')])[2]")
	public static WebElement primaryaction_checkout;

	@FindBy(xpath = "(//button[@class='primary-action ng-star-inserted'])[1]")
	public static WebElement titlelist_primaryAction;

	@FindBy(id = "loc_txtReadingList")
	private WebElement reading_list;

	@FindBy(id = "loc_labelMy Programs")
	private WebElement program_myprogmtab;

	@FindBy(xpath = "(//*[@aria-label='Profile'])[1]")
	private WebElement oldUi_avatar;

	@FindBy(xpath = "//span[contains(text(),'VIEW MY INTERESTS')]")
	private WebElement viewMy_interest_oldUi;

	@FindBy(xpath = "(//div[@class='title-details-info'])[2]")
	private WebElement titleDetails;

	@FindBy(xpath = "(//div[@class='kz-program-status started ng-star-inserted'])[1]")
	public static WebElement joinedprogram_TitleProgress;

	@FindBy(xpath = "//h1[@class='kz-reading-programs-title']")
	public static WebElement program_details;

	@FindBy(xpath = "(//div[@class='kz-card-images'])[1]")
	public static WebElement ongoing_prog;
	
	@FindBy(xpath = "//*[contains(text(),'AutomationProgram')]")
	public static WebElement ongoing_progUAT;

	@FindBy(xpath = "(//div[@class='kz-card-images'])[1]")
	public static WebElement upcoming_prog;
	
	@FindBy(xpath = "(//*[contains(text(),'Black History Month')])[1]")
	public static WebElement upcoming_progUAT;

	public WebElement getProgDetailscreen_title() {
		return progDetailscreen_title;
	}

	public WebElement getOldUi_avatar() {
		return oldUi_avatar;
	}

	public WebElement getProfileSetting_avatar() {
		return profileSetting_avatar;
	}

	public WebElement getInterestSurvey_description() {
		return interestSurvey_description;
	}

	public List<WebElement> getTopics_for_adult() {
		return topics_for_adult;
	}

	public WebElement getPopup_closedProgram_txt() {
		return closedProgram_name;
	}

	public WebElement getBook1_adv_fic() {
		return book1_adv_fic;
	}

	public WebElement getBook2_bio_mem() {
		return book2_bio_mem;
	}

	public WebElement getBook3_bussiness() {
		return book3_bussiness;
	}

	public WebElement getSave_button() {
		return save_button;
	}

	public WebElement getCancel_button() {
		return cancel_button;
	}

	public WebElement getTeen_and_kid_reading_interest() {
		return teen_and_kid_reading_interest;
	}

	public WebElement getAdult_reading_preferences() {
		return adult_reading_preferences;
	}

	public WebElement getKid_match_box() {
		return kid_match_box;
	}

	public List<WebElement> getTopics_for_teen() {
		return topics_for_teen;
	}

	public List<WebElement> getTopics_for_kid() {
		return topics_for_adult;
	}

	public WebElement getKid() {
		return kid;
	}

	public WebElement getTeen() {
		return teen;
	}

	public WebElement getInterest_preference_close_cta() {
		return interest_preference_close_cta;
	}

	public WebElement getPreferencepopup_closeicon() {
		return preferencepopup_closeicon;
	}

	public WebElement getInterest_survey_preferences() {
		return interest_survey_preferences;
	}

	public WebElement getPrefered_age() {
		return prefered_age;
	}

	public WebElement getJuvenile() {
		return juvenile;
	}

	public WebElement getYoung_adult() {
		return young_adult;
	}

	public WebElement getAdult() {
		return adult;
	}

	public static ExcelReader getReader() {
		return reader;
	}

	public WebElement getProfile_Icon() {
		return profile_Icon;
	}

	public WebElement getProfileSetting_securityQues() {
		return profileSetting_securityQues;
	}

	public WebElement getProfileSetting_securityAns() {
		return profileSetting_securityAns;
	}

	public WebElement getProfileSetting_viewMyInerest() {
		return profileSetting_viewMyInerest;
	}

	public WebElement getProfileSetting_settingPreference() {
		return profileSetting_settingPreference;
	}

	public WebElement getUpdated_avatar() {
		return updated_avatar;
	}

	public WebElement getProfileSetting_checkbox_displaycheckoutHistory() {
		return profileSetting_checkbox_displaycheckoutHistory;
	}

	public WebElement getProfileSetting_checkbox_insightAndbadges() {
		return profileSetting_checkbox_insightAndbadges;
	}

	public WebElement getProfileSetting_btn_updateSetting() {
		return profileSetting_btn_updateSetting;
	}

	public WebElement getHambergerMenu_programs() {
		return hambergerMenu_programs;
	}

	public WebElement getMyprogram_tab() {
		return myprogram_tab;
	}

	public WebElement getOpenprogram_tabs() {
		return openprogram_tabs;
	}

	public WebElement getTxt_upcomingProgram() {
		return txt_upcomingProgram;
	}

	public WebElement getTxt_programName() {
		return txt_programName;
	}

	public List<WebElement> getTxt_programdescriptionAndDate() {
		return txt_programdescriptionAndDate;
	}

	public List<WebElement> getImg_programCoverimg() {
		return img_programCoverimg;
	}

	public List<WebElement> getTxt_NumberofParticipants() {
		return txt_NumberofParticipants;
	}

	public WebElement getTxt_NavprogDetailsScreen() {
		return txt_NavprogDetailsScreen;
	}

	public WebElement getMyprogram_txt_closedProgram() {
		return myprogram_txt_closedProgram;
	}

	public List<WebElement> getListofPrograms_participatedin() {
		return listofPrograms_participatedin;
	}

	public List<WebElement> getMyprogram_program_started() {
		return myprogram_program_started;
	}

	public List<WebElement> getMyprogram_closedProgm_listofPrograms() {
		return myprogram_closedProgm_listofPrograms;
	}

	public WebElement getTxt_activeProgram() {
		return txt_activeProgram;
	}

	public List<WebElement> getOverAllprogress_calculated() {
		return overAllprogress_calculated;
	}

	public WebElement getOverAllprogress() {
		return overAllprogress;
	}

	public WebElement getMyprogram_noprograms() {
		return myprogram_noprograms;
	}

	public WebElement getMyprogramAndopenprogram_tabs() {
		return myprogramAndopenprogram_tabs;
	}

	public WebElement getProfileSetting_btn_profileType() {
		return profileSetting_btn_profileType;
	}

	public WebElement getProfileSetting_insightsAndBadges() {
		return profileSetting_insightsAndBadges;
	}

	public WebElement getProfileSetting_checkoutHistory() {
		return profileSetting_checkoutHistory;
	}

	public WebElement getProfileSetting_AutocheckoutHolds() {
		return profileSetting_AutocheckoutHolds;
	}

	public WebElement getProfile_information_prepopulated() {
		return profile_information_prepopulated;
	}

	public WebElement getMyshelf_txt_myprograms() {
		return Myshelf_txt_myprograms;
	}

	public List<WebElement> getView_listofprogram() {
		return view_listofprogram;
	}

	public WebElement getSave_prefrences_Magic_Adult() {
		return save_prefrences_Magic_Adult;
	}

	public WebElement getBook1_Magic_Adult() {
		return Book1_Magic_Adult;
	}

	public WebElement getBook2_Magic_Adult() {
		return Book2_Magic_Adult;
	}

	public WebElement getBook3_Magic_Adult() {
		return Book3_Magic_Adult;
	}

	public WebElement getValidating_kid_checkbox() {
		return validating_kid_checkbox;
	}

	public WebElement getKid_fromteen_checkbox() {
		return kid_fromteen_checkbox;
	}

	public List<WebElement> getAgelevel_checkbox() {
		return agelevel_checkbox;
	}

	public WebElement getAgelevel_in_bookdetail() {
		return agelevel_in_bookdetail;
	}

	public WebElement getBased_on_your_interest() {
		return based_on_your_interest;
	}

	public WebElement getKid_book1() {
		return kid_book1;
	}

	public WebElement getKid_book2() {
		return kid_book2;
	}

	public WebElement getCarousel_right_button() {
		return carousel_right_button;
	}

	public WebElement getCarousel_left_button() {
		return carousel_left_button;
	}

	public WebElement getAdult_checkbox() {
		return adult_checkbox;
	}

	public WebElement getTeen_checkbox() {
		return teen_checkbox;
	}

	public WebElement getKid_checkbox() {
		return kid_checkbox;
	}

	public WebElement getLeave_program_popup_no() {
		return leave_program_popup_no;
	}

	public WebElement getLeave_program_popup_yes() {
		return leave_program_popup_yes;
	}

	public WebElement getTexas_leave_program() {
		return texas_click_leave_program;
	}

	public WebElement getLeave_program_toast_msg() {
		return leave_program_toast_msg;
	}

	public WebElement getTexas_openprogram() {
		return texas_openprogram;
	}

	public WebElement getTexas_XY_program() {
		return texas_XY_program;
	}

	public WebElement getNavigate_to_NYC_program_details_screen() {
		return navigate_to_NYC_program_details_screen;
	}

	public WebElement getNYC_program() {
		return NYC_program;
	}

	public WebElement getTitle_readnow() {
		return title_readnow;
	}

	public WebElement getProgress_completion() {
		return progress_completion;
	}

	public WebElement getReading_progress() {
		return reading_progress;
	}

	public WebElement getDisabled_checkout_cta() {
		return disabled_checkout_cta;
	}

	public WebElement getTitle_list_screen() {
		return title_list_screen;
	}

	public WebElement getTitle_cta() {
		return title_cta;
	}

	public WebElement getPrimary_action_cta() {
		return primary_action_cta;
	}

	public WebElement getTitle_format_icon() {
		return title_format_icon;
	}

	public WebElement getSee_all_cta() {
		return see_all_cta;
	}

	public WebElement getTxt_books_in_order() {
		return txt_books_in_order;
	}

	public WebElement getReading_list() {
		return reading_list;
	}

	public WebElement getLeave_program() {
		return leave_program;
	}

	/**********************************************************************************************************/

	public boolean booksInOrder() {
		javascriptScroll(txt_books_in_order);
		boolean b = true;
		isElementPresent(txt_books_in_order);
		return b;

	}

	public boolean readingList() {
		boolean b = true;
		isElementPresent(reading_list);
		return b;

	}

	public boolean leaveProgram() {
		boolean b = true;
		isElementPresent(leave_program);
		return b;

	}

	public void seeAllcta() {
		javascriptScroll(see_all_cta);
		// isElementPresent(see_all_cta);
		waitFor(2000);
		jsClick(see_all_cta);

	}

	public void titleFormatIcon() {
		isElementPresent(title_format_icon);
		System.out.println("user is able to see title format icon");
	}

	public void primaryActionCta() {
		isElementPresent(primary_action_cta);
		System.out.println("user is able to view primary action cta");
	}

	public void viewSeeAllCta() {
		isElementPresent(see_all_cta);
	}

	public void titleCta() {
		waitFor(2000);
		// isElementPresent(title_cta);
		ClickOnWebElement(title_cta);
	}

	public boolean titleListScreen() {
		boolean b = true;
		isElementPresent(title_list_screen);
		return b;
	}

	public void ctaEnabledOrDisabled() {
		try {
			Assert.assertEquals(primary_action_cta.isEnabled(), true);
		} catch (Exception e) {
			Logger.log("CTA is disabled ");
			e.printStackTrace();
		}
	}

	public boolean readingProgress() {
		boolean b = true;
		isElementPresent(reading_progress);
		return b;
	}

	public boolean titleCompletion() {
		boolean b = true;
		isElementPresent(progress_completion);
		return b;
	}

	public void titleReadNow() {
		try {
			Assert.assertEquals(title_readnow.isDisplayed(), true);

		} catch (Exception e) {

			Logger.log("read now cta is not displayed");
			e.printStackTrace();
		}

	}

	public void nycProgram() {
		javascriptScroll(NYC_program);
		ClickOnWebElement(NYC_program);
		isElementPresent(navigate_to_NYC_program_details_screen);

	}

	public void texasXYProgram() {
		javascriptScroll(texas_XY_program);
		ClickOnWebElement(texas_XY_program);
		isElementPresent(texas_XY_program);
	}

	public void texasOpenProgram() {
		waitFor(2000);
		javascriptScroll(texas_openprogram);
		ClickOnWebElement(texas_openprogram);
		isElementPresent(texas_openprogram);

	}

	public void texasLeaveProgram() {
		javascriptScroll(texas_click_leave_program);
		isElementPresent(texas_click_leave_program);
		ClickOnWebElement(texas_click_leave_program);
	}

	public void clickLeaveProgram() {
		isElementPresent(leave_program);
		ClickOnWebElement(leave_program);
	}

	public void leaveProgramPopupYes() {
		ClickOnWebElement(leave_program_popup_yes);
	}

	public boolean leaveProgramToastMsg() {
		boolean b = true;
		isElementPresent(leave_program_toast_msg);
		return b;
	}

	public void leaveProgramPopupNo() {
		ClickOnWebElement(leave_program_popup_no);
	}

//	public void click_programs() {
//		ClickOnWebElement(teenprofile_btn_program);
//		waitFor(2000);
//
//	}

	public void view_listofProgramsActive() {
		waitFor(2000);
		for (int i = 0; i < view_listofprogram.size(); i++) {
			if (view_listofprogram.get(i).isDisplayed()) {
				Logger.log("User is able to view list of programs user has joined and are active");
			}
		}
	}

	public void view_tenNumberofProgram() {
		for (int i = 0; i < view_listofprogram.size() - 1; i++) {
			if (view_listofprogram.size() == 10) {
				Logger.log("User is able to view 10 number of programs in the carousel");
			}
		}

	}

	public void view_myprogramsonMyshelfscreen() {
		javascriptScroll(Myshelf_txt_myprograms);
		if (Myshelf_txt_myprograms.isDisplayed()) {
			Logger.log("user is able to view my program on my shelf screen");
		}
	}

	public void shouldnotShow_myprogramonMyshelf() {
		if (!Myshelf_txt_myprograms.isDisplayed()) {
			Logger.log("user is not able to view my program on my shelf screen");
		}

	}

//	public boolean view_myprofilePopup() {
//		boolean b= true;
//		isElementPresent(profile_popup);
//		return b;
//	}

	public void click_myProfilePopup() {

		if (profile_Icon.isDisplayed()) {
			System.out.println("Execution happening on the Web browser");
			jsClick(profile_Icon);
			// ClickOnWebElement(profile_popup);
			waitFor(3000);
		} else {
			System.out.println("Execution happening on the Mobile browser");
			jsClick(profile_Icon_Mobile);
		}
	}

	public void click_viewSetting() {
		ClickOnWebElement(profilepopup_viewSetting);
		waitFor(3000);
	}

	public boolean view_secutityQuesAndansw() {
		javascriptScroll(profileSetting_securityQues);
		boolean b = true;
		isElementPresent(profileSetting_securityQues);
		isElementPresent(profileSetting_securityAns);
		return b;
	}

	public void click_viewMycheckouts() {
		// javascriptScroll(viewLibrary_Cards);
		if (isElementPresent(profileSetting_viewMyInerest)) {
			ClickOnWebElement(profileSetting_viewMyInerest);
		} else {
			ClickOnWebElement(viewMy_interest_oldUi);
		}
		WaitForWebElement(profileSetting_settingPreference);
		if (profileSetting_settingPreference.isDisplayed()) {
			System.out.println("user is able to view intrest survey screen");
		}
	}

	public void click_avatar() {
		waitFor(2000);
		if (isElementPresent(updated_avatar)) {
			jsClick(updated_avatar);
			waitFor(2000);
		} else if (isElementPresent(updated_avatarAdultTheme)) {
			jsClick(updated_avatarAdultTheme);
			waitFor(2000);
		}
		waitFor(2000);
	}

	public void enable_displayCheckoutHistory() {
		javascriptScroll(profileSetting_checkbox_displaycheckoutHistory);
		waitFor(2000);
		if (profileSetting_checkbox_displaycheckoutHistory.isSelected()) {
			System.out.println("user is enable the display checkout history");
			// ClickOnWebElement(profileSetting_checkbox_displaycheckoutHistory);
		} else {
			waitFor(2000);
			jsClick(profileSetting_checkbox_displaycheckoutHistory);
			// ClickOnWebElement(profileSetting_checkbox_displaycheckoutHistory);
			// System.out.println("user is enable the display checkout history");
		}
	}

	public void disable_displaycheckoutHistory() {
//		javascriptScroll(scroll_editProfile);
		javascriptScroll(profileSetting_checkbox_displaycheckoutHistory);
		if (profileSetting_checkbox_displaycheckoutHistory.isSelected()) {
			// ClickOnWebElement(profileSetting_checkbox_displaycheckoutHistory);
			jsClick(profileSetting_checkbox_displaycheckoutHistory);
		} else {
			Logger.log("Not selected the checkbox");

			// ClickOnWebElement(Myshelf_txt_myprograms);
		}

	}

	public void enable_insightAndBadges() {
		if (profileSetting_checkbox_insightAndbadges.isSelected()) {
			System.out.println("user is enable the insights and badges");

		} else {
			jsClick(profileSetting_checkbox_displaycheckoutHistory);
			// ClickOnWebElement(profileSetting_checkbox_insightAndbadges);
		}
	}

	public void disable_insightBadges() {
		if (profileSetting_checkbox_insightAndbadges.isSelected()) {
			jsClick(profileSetting_checkbox_insightAndbadges);
			// ClickOnWebElement(profileSetting_checkbox_insightAndbadges);
		} else {
			System.out.println("user is disable the insights and badges");
		}

	}

	public void click_updateSetting() {
		ClickOnWebElement(profileSetting_btn_updateSetting);
		waitFor(3000);
	}

	public void click_programinHambergermenu() {
		visibilityWait(hambergerMenu_programs);
		jsClick(hambergerMenu_programs);
		visibilityWait(landing_program);
	}

	public void verify_myprogramtab_default() {
		if (myprogram_tab.isEnabled()) {
			isElementPresent(txt_activeProgram);
			System.out.println("user is able to view my program has default tab");
		}
	}

	public boolean view_programs() {
		boolean b = true;
		isElementPresent(myprogram_tab);
		// isElementPresent(openprogram_tabs);
		return true;
	}

	public void click_openProgram() {
		waitFor(2000);
		jsClick(openprogram_tabs);
		waitFor(3000);
	}

	public boolean view_programStarted() {
		boolean b = true;
		for (int i = 3; i < 0; i++) {
			isElementPresent(myprogram_program_started.get(i));
			break;
		}
		return b;
	}

	public void view_upcomingProgram() {
		javascriptScroll(txt_upcomingProgram);
		isElementPresent(txt_upcomingProgram);
		System.out.println("user is able to view upcoming program");
	}

	public boolean view_programTitleAndDiscription() {
		waitFor(2000);
		boolean b = true;
		// for (int i = 3; i >= 0; i++) {
		javascriptScroll(txt_programName);
		txt_programName.isDisplayed();
		// break;
		// }
		waitFor(2000);
		return b;
	}

	public boolean view_overAllprogressPercentage() {
		boolean b = true;
		for (int i = 3; i >= 0; i++) {
			isElementPresent(overAllprogress_calculated.get(1));
			break;
		}
		return b;
	}

	public boolean view_programDiscriptionAndDate() {
		waitFor(2000);
		boolean b = true;
		// for (int i = 3; i >= 0; i--) {
		javascriptScroll(txt_programdescriptionAndDate.get(5));
		isElementPresent(txt_programdescriptionAndDate.get(5));
		// break;
		// }
		waitFor(2000);
		return b;
	}

	public boolean view_progCoverimg() {
		boolean b = true;
		for (int i = 3; i >= 0; i--) {
			javascriptScroll(img_programCoverimg.get(1));
			isElementPresent(img_programCoverimg.get(1));
			break;
		}
		waitFor(2000);
		return b;
	}

	public void view_numberOfparticipants() {
		for (int i = 3; i >= 0; i--) {
			javascriptScroll(txt_NumberofParticipants.get(2));
			isElementPresent(txt_NumberofParticipants.get(2));
			break;
		}
		waitFor(3000);
	}

	public void click_programNavtoProgDetailsScreen() {
		jsClick(titleFormaticon.get(0));
		WaitForWebElement(titleDetails);
		waitFor(2000);
		// ClickOnWebElement(img_programCoverimg.get(1));
		isElementPresent(titleDetails);
	}

	public void click_deleteCTA() {
		jsClick(myprogram_deleteCta.get(0));
		// ClickOnWebElement();
		waitFor(2000);
	}

	public boolean not_viewClosedProgram() {
		boolean b = false;
		if (isElementPresent(myprogram_txt_closedProgram)) {
			b = true;
			System.out.println("user should not able to view closed program");
		}
		return b;
	}

	public void view_closedProgram() {
		javascriptScroll(myprogram_txt_closedProgram);
		isElementPresent(myprogram_txt_closedProgram);
		waitFor(2000);

	}

	public boolean not_viewProgramonMyprogram() {
		boolean b = false;
		if (isElementPresent(txt_activeProgram)) {
			b = true;
			System.out.println("user has no program to be displayed on my programs screen");
		}
		return b;
	}

	public void view_listOfprogramsparticipated() {
		for (int i = 0; i < listofPrograms_participatedin.size(); i++) {
			if (isElementPresent(listofPrograms_participatedin.get(0))) {
				System.out.println("user is able to view list of programs only that user has participating in");
				break;
			}
		}
		waitFor(2000);
	}

	public boolean preferedAgeAndProfileTypeAdultaxis360Only() {
		javascriptScroll(prefered_age);
		boolean b = true;
		isElementPresent(juvenile);
		isElementPresent(young_adult);
		isElementPresent(adult);
		return true;

	}

	public boolean preferedAgeAndProfileTypeAdult() {
		javascriptScroll(prefered_age);
		boolean b = true;
		isElementPresent(teen);
		isElementPresent(kid);
		return true;

	}

	public boolean preferedAgeAndProfileTypeKid() {
		javascriptScroll(prefered_age);
		boolean b = true;
		isElementPresent(kid);
		return true;

	}

	public boolean interestTopics_kidAndteen() {
		boolean b = true;
		if (isElementPresent(teen_and_kid_reading_interest)) {
			for (int i = 0; i < topics_for_teen.size(); i++) {
				isElementPresent(topics_for_teen.get(i));
			}
		}
		return true;
	}

	public boolean view_interestTopics_Adult() {
		isElementPresent(adult_reading_preferences);
		for (int i = 0; i < topics_for_adult.size(); i++) {
			isElementPresent(topics_for_adult.get(i));
		}
		return true;
	}

	public void alreadySet_preference() {

		for (int i = 0; i < topics_for_teen.size(); i++) {
			if (topics_for_teen.get(i).isEnabled()) {
				ClickOnWebElement(interestSurvey_icons.get(i));
			} else {
				for (int j = 3; j >= 0; j--) {
					ClickOnWebElement(interestSurvey_icons.get(j));
				}
			}
		}

	}

	public void view_alreadySet_preference() {

		for (int i = 0; i < topics_for_teen.size(); i++) {
			if (topics_for_teen.get(i).isEnabled()) {
				System.out.println("user is able to veiw already preference set");
			} else {
				System.out.println("user is not able to veiw already preference set");
			}
		}
	}

	public void close_preferencepopup() {
		visibilityWait(preferencepopup_closeicon);
		ClickOnWebElement(preferencepopup_closeicon);

	}

	public boolean saveAndCancel() {
		javascriptScroll(prefered_age);
		boolean b = true;
		isElementPresent(save_button);
		isElementPresent(cancel_button);
		return b;

	}

	public void interestIconAndSave() {
		WaitForWebElement(book1_adv_fic);
		ClickOnWebElement(book1_adv_fic);
		waitFor(2000);
		ClickOnWebElement(book2_bio_mem);
		waitFor(2000);
		ClickOnWebElement(book3_bussiness);
		waitFor(5000);
		ClickOnWebElement(save_button);
	}

	public void interestTopicsForAdultMagic() {
		WaitForWebElement(Book1_Magic_Adult);
		jsClick(Book1_Magic_Adult);
		WaitForWebElement(Book2_Magic_Adult);
		ClickOnWebElement(Book2_Magic_Adult);
		WaitForWebElement(Book3_Magic_Adult);
		ClickOnWebElement(Book3_Magic_Adult);

	}

	public void Save_Preferences_Magic_adult() {
		waitFor(2000);
		ClickOnWebElement(save_prefrences_Magic_Adult);
	}

	public void click_closedProgram() {
		javascriptScroll(closedProgram_name);
		jsClick(closedProgram_name);
		waitFor(2000);
		// ClickOnWebElement(closedProgram_name);
//		if (nav_closedProgram_programDetailsscreen.isDisplayed()) {
//			System.out.println("user is able to view program details screen");
//		}

	}

	public void click_closedProg2() {
		jsClick(closedProgram_name2);
		waitFor(2000);
	}

	public boolean view_interestSurveyIcons() {
		boolean b = true;
		for (int i = 0; i < interestSurvey_icons.size(); i++) {
			javascriptScroll(interestSurvey_icons.get(i));
			isElementPresent(interestSurvey_icons.get(i));
		}
		return true;
	}

	public void select_interestSurvey() {
		for (int i = 3; i >= 0; i--) {
			javascriptScroll(interestSurvey_icons.get(i));
			ClickOnWebElement(interestSurvey_icons.get(i));
		}

	}

	public void save_preference() {
		jsClick(save_button);
		waitFor(2000);
	}

	public boolean closedProg_detailscreen_verifycoverimg() {
		boolean b = true;
		for (int i = 0; i < readlingList_coverimg.size(); i++) {
			isElementPresent(readlingList_coverimg.get(i));
		}
		return true;
	}

	public void clicktitle_navTodetailscreen() {
		visibilityWait(readlingList_coverimg.get(1));
		jsClick(readlingList_coverimg.get(1));
		waitFor(2000);
	}

	public boolean verify_alltitleEnable() {
		boolean b = true;
		for (int i = 0; i < readlingList_coverimg.size(); i++) {
			readlingList_coverimg.get(i).isEnabled();
		}
		return true;
	}

	public void nav_progDetailscreen() {
		ClickOnWebElement(img_programCoverimg.get(1));

	}

	public boolean view_primaryAction() {
		boolean b = true;
		try {
			primaryaction_checkout.getText().contains("Checkout");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("user is able to view primary action");
		return b;
	}

	public boolean verify_primaryActiionCtanotcheckout() {
		boolean b = true;
		primaryaction_checkout.isEnabled();
		System.out.println(
				"user should be able to view action for the title checkout as a cta if title is not checked out");
		return b;
	}

	public void click_seeAllcta() {
		navigateup_scroll();
		// Actions a = new Actions(DriverManager.getDriver());
		// a.sendKeys(Keys.PAGE_UP).build().perform();
		javascriptScroll(seeAll_cta);
		// WaitForWebElement(seeAll_cta);
		jsClick(seeAll_cta);
		// ClickOnWebElement(seeAll_cta);
		waitFor(2000);
	}

	public boolean view_completedProg() {
		javascriptScroll(closedProgram_Completed);
		boolean b = true;
		isElementPresent(closedProgram_Completed);
		return true;

	}

	public void Click_xyclosedProgram() {
		// javaScriptScrollToEnd();
		javascriptScroll(closed_xyprograms);
		jsClick(closed_xyprograms);
		// ClickOnWebElement(closed_xyprograms);
		waitFor(3000);
	}

	public boolean view_ytitlesProgm() {
		boolean b = true;
		for (int i = 3; i >= 0; i--) {
			isElementPresent(yprograms.get(i));
			isElementPresent(titleFormaticon.get(i));
		}
		return true;
	}

	public void click_ongoingProg() {
		if (isElementPresent(ongoingprogram_adult)) {
			javascriptScroll(ongoingprogram_adult);
			jsClick(ongoingprogram_adult);
			// ClickOnWebElement(ongoingprogram_adult);
			visibilityWait(progDetailScreen_title);
			// WaitForWebElement(progDetailScreen_readinglist);
		} else {
			javascriptScroll(ongoingprogram_kid);
			jsClick(ongoingprogram_kid);
			// WaitForWebElement(progDetailScreen_readinglist);
			visibilityWait(progDetailScreen_readinglist);
		}

	}

	public void click_booksinorderOngoingProg() {
		ClickOnWebElement(ongoingprogram_booksinOrderadult);
		waitFor(2000);

	}

	public boolean view_progNameAndstartdateendDate() {
		boolean b = true;
		// isElementPresent(progDetailscreen_title);
		isElementPresent(progDetailscreen_endDate);
		isElementPresent(progDetailscreen_startdate);
		return true;
	}

	public void ageLevelOptions() {
		javascriptScroll(teen_checkbox);
		waitFor(2000);
		jsClick(teen_checkbox);
		// ClickOnWebElement(teen_checkbox);
		waitFor(2000);
		jsClick(kid_checkbox);
		// ClickOnWebElement(kid_checkbox);
		waitFor(2000);
		ClickOnWebElement(save_button);
	}

	public void swipeLeftRight() {
		WaitForWebElement(carousel_right_button);
		jsClick(carousel_right_button);
		waitFor(2000);
		jsClick(carousel_left_button);
		waitFor(2000);
	}

	public void teenProfileOnly() {
		jsClick(book1_adv_fic);
		jsClick(book2_bio_mem);
		jsClick(book3_bussiness);
		javascriptScroll(teen_checkbox);
		waitFor(2000);
		// ClickOnWebElement(teen_checkbox);
		jsClick(teen_checkbox);
		waitFor(2000);
		jsClick(save_button);
	}

	public void kidProfileOnly() {
		ClickOnWebElement(kid_book1);
		ClickOnWebElement(kid_book2);
		javascriptScroll(kid_checkbox);
		waitFor(1000);
		// ClickOnWebElement(kid_checkbox);
		jsClick(kid_checkbox);
		waitFor(2000);
		ClickOnWebElement(save_button);
	}

	public void teenAndKidOnly() {
		ClickOnWebElement(book1_adv_fic);
		ClickOnWebElement(book2_bio_mem);
		ClickOnWebElement(book3_bussiness);
		javascriptScroll(teen_checkbox);
		waitFor(2000);
		jsClick(teen_checkbox);
		waitFor(2000);
		jsClick(kid_checkbox);
		// ClickOnWebElement(kid_checkbox);
		waitFor(2000);
		ClickOnWebElement(save_button);
	}

	public void baseOnYourInterest() {
		javascriptScroll(based_on_your_interest);
		try {
			Assert.assertEquals(based_on_your_interest.isDisplayed(), true);
		} catch (Exception e) {
			Logger.log("user should not view interest topics");
			e.printStackTrace();
		}

	}

	public boolean ageLevelInBookDetail() {
		boolean b = true;
		isElementPresent(agelevel_in_bookdetail);
		return b;
	}

	public void saveInterestEnableAndDisable() {
		if (save_button.isEnabled()) {
			Logger.log("save cta is enabled");
		} else {
			Logger.log("save cta is disabled");
		}
	}

	public void teenProfileEnabled() {
		jsClick(book1_adv_fic);
		jsClick(book2_bio_mem);
		jsClick(book3_bussiness);
//		try {
//			Assert.assertEquals(teen_checkbox.isEnabled(), true);
//		} catch (Exception e) {
//			Logger.log("teen checkbox is disabled");
//			e.printStackTrace();
//		}
		if (teen_checkbox.isEnabled()) {
			Assert.assertEquals(teen_checkbox.isEnabled(), true);
		} else {
			waitFor(2000);
			jsClick(teen_checkbox);
		}
		ClickOnWebElement(save_button);

	}

	public void kidProfileEnabled() {
		jsClick(kid_book1);
		jsClick(kid_book2);
		try {
			Assert.assertEquals(kid_checkbox.isEnabled(), true);
		} catch (Exception e) {
			Logger.log("kid checkbox is disabled");
			e.printStackTrace();
		}
		ClickOnWebElement(save_button);

	}

	public void teenProfileNonEditable() {
		javascriptScroll(teen_checkbox);
		try {
			Assert.assertEquals(teen_checkbox.isEnabled(), true);
		} catch (Exception e) {
			Logger.log("teen profile is not enabled");
			e.printStackTrace();
		}

	}

	public void kidProfileNonEditable() {
		javascriptScroll(kid_fromteen_checkbox);
		try {
			Assert.assertEquals(kid_fromteen_checkbox.isEnabled(), true);
		} catch (Exception e) {
			Logger.log("kid profile is not enabled");
			e.printStackTrace();
		}
	}

	public void kidTopicsInAdult() {
		jsClick(book1_adv_fic);
		waitFor(2000);
		// ClickOnWebElement(book1_adv_fic);
		jsClick(book2_bio_mem);
		// ClickOnWebElement(book2_bio_mem);
		jsClick(book3_bussiness);
		// ClickOnWebElement(book3_bussiness);
		javascriptScroll(kid_checkbox);
		waitFor(1000);
		// ClickOnWebElement(kid_checkbox);
		jsClick(kid_checkbox);
		waitFor(2000);
		ClickOnWebElement(save_button);
	}

	public boolean no_ongoingProgDisplayed() {
		boolean b = false;
		if (isElementPresent(ongoingProg_title)) {
			b = true;
			System.out.println("no ongoing program available to be displayed");
		}
		return false;

	}

	public boolean no_upcomingprogDisplayed() {
		boolean b = false;
		if (isElementPresent(upcomingProg_title)) {
			b = true;
			System.out.println("no upcoming program available to be displayed");
		}
		return false;

	}

	public boolean no_programsDisplayedinOngoing() {
		boolean b = false;
		if (isElementPresent(ongoingprogram_adult)) {
			b = true;
			System.out.println("view screen for no program to be displayed for the adult in the open programs tab");
		}
		return false;
	}

	public boolean no_programsDisplayedupcoming() {
		boolean b = false;
		if (isElementPresent(upcomingProg_prog)) {
			b = true;
			System.out.println("view screen for no program to be displayed for the adult in the open programs tab");
		}
		return false;
	}

	public void clik_xyprogram() {
		// javaScriptScrollToEnd();
		WaitForWebElement(upcomingProg_prog);
		javascriptScroll(upcomingProg_prog);
		jsClick(upcomingProg_prog);
		// visibilityWait(xyprogram_title);
		// ClickOnWebElement(upcomingProg_prog);
		waitFor(2000);
	}

	public void click_yprogramstoNavtitleScreen() {
		ClickOnWebElement(yprograms.get(1));
		waitFor(2000);
	}

	public void view_leaveProgram() {
		javaScriptScrollToEnd();
		isElementPresent(leaveProgram);
	}

	public void click_leaveProg() {
		javaScriptScrollToEnd();
		jsClick(leaveProgram);
		waitFor(2000);
	}

	public void click_booksinOrderprog() {
		WaitForWebElement(booksinOrder_prog);
		javascriptScroll(booksinOrder_prog);
		jsClick(booksinOrder_prog);
		// ClickOnWebElement(booksinOrder_prog);
		waitFor(3000);
		// WaitForWebElement(txt_activeProgram);
	}

	public void click_xyprog() {
		javascriptScroll(xyprgrm_prog);
		try {
			jsClick(xyprgrm_prog);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ClickOnWebElement(xyprgrm_prog);
		waitFor(2000);
	}

	public boolean verify_booksinorder_prgramNameAndDescription() {
		boolean b = true;
		if (isElementPresent(booksinOrder_progTitle)) {
			javascriptScroll(booksinOrder_progTitle);
			b = true;
		}
		return true;
	}

	public void verify_xyprog_prgramNameAndDescription() {
		isElementPresent(xyprgrm_progTitle);
		javascriptScroll(progDetailscreen_endDate);
		isElementPresent(progDetailscreen_endDate);

	}

	public void click_joinProgram() {
		javascriptScroll(progDetailscreen_joinprogramCTA);
		ClickOnWebElement(progDetailscreen_joinprogramCTA);
		waitFor(2000);
	}

	public void click_letsGetStarted() {
		ClickOnWebElement(joinprog_letsGetStarted);
		waitFor(2000);
	}

	public void click_upcomingProg() {
		if (upcomingProg_prog.isDisplayed()) {
			javascriptScroll(upcomingProg_prog);
			// visibilityWait(upcomingProg_prog);
			jsClick(upcomingProg_prog);
			// ClickOnWebElement(upcomingProg_prog);

		} else {
			javaScriptScrollToEnd();
			javascriptScroll(upcomingProg_progkid);
			jsClick(upcomingProg_progkid);
			// ClickOnWebElement(upcomingProg_progkid);
			WaitForWebElement(reading_list);
		}
	}

	public boolean view_progranNameInjoinProgScreen() {
		boolean b = true;
		isElementPresent(joinprog_confirmPopup);
		isElementPresent(joinprog_programName);
		return b;
	}

	public void click_close_joinProg() {
		ClickOnWebElement(joinProg_close);
		waitFor(2000);

	}

	public void select_activeProg() {
		ClickOnWebElement(prog_activeProg);
		waitFor(4000);
		// WaitForWebElement(progDetailScreen_readinglist);
	}

	public void view_listOfprog() {
		for (int i = 5; i <= 0; i--) {
			if (listofProg_ongoing.get(i).isDisplayed()) {
				Logger.log("user is able to view list of programs");
			}
		}
	}

	public void view_lazyload() {
		for (int i = 0; i < listofProg_ongoing.size(); i++) {
			if (listofProg_ongoing.size() >= 20) {
				Logger.log(" user is able to view load twenty programs at a time and lazy load as user scrolls down");
			}
		}
	}

	public boolean view_removeCTA() {
		boolean b = true;
		for (int i = 0; i < myprogram_deleteCta.size(); i++) {
			isElementPresent(myprogram_deleteCta.get(i));
		}
		Logger.log("user is able to view remove CTA");
		return b;
	}

	public boolean view_closedProgNameandDes() {
		javascriptScroll(closedProgram_name);
		boolean b = true;
		if (isElementPresent(closedProgram_name)) {
			isElementPresent(closedProgram_startDate);
			isElementPresent(closedProgram_EndDate);
			b = true;
		}
		return b;

	}

	public void kid_fromteen_checkbox() {
		waitFor(2000);
		ClickOnWebElement(kid_book1);
		ClickOnWebElement(kid_book2);
		javascriptScroll(kid_fromteen_checkbox);
		try {
			Assert.assertEquals(kid_fromteen_checkbox.isEnabled(), true);
		} catch (Exception e) {
			Logger.log("checkbox is disabled");
			e.printStackTrace();
		}
		ClickOnWebElement(save_button);
		waitFor(2000);
	}

	public void interestIcon_And_Kid_Checkbox_In_KidProfile() {
		waitFor(2000);
		jsClick(kid_book1);
		jsClick(kid_book2);
		javascriptScroll(validating_kid_checkbox);
//		try {
//			Assert.assertEquals(validating_kid_checkbox.isEnabled(), true);
//		} catch (Exception e) {
//			Logger.log("checkbox is disabled");
//			e.printStackTrace();
//		}
		if (validating_kid_checkbox.isEnabled()) {
			Assert.assertEquals(validating_kid_checkbox.isEnabled(), true);
		} else {
			waitFor(2000);
			jsClick(validating_kid_checkbox);
		}
		ClickOnWebElement(save_button);
		waitFor(2000);
	}

	public void navigateup_scroll() {
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
		} else {
			waitFor(4000);
			Actions a = new Actions(DriverManager.getDriver());
			a.sendKeys(Keys.PAGE_UP).build().perform();
			waitFor(5000);
		}
	}

	public void interestIconAndageLevelOptions() {
		WaitForWebElement(book1_adv_fic);
		ClickOnWebElement(book1_adv_fic);
		waitFor(2000);
		ClickOnWebElement(book2_bio_mem);
		waitFor(2000);
		ClickOnWebElement(book3_bussiness);
		javascriptScroll(teen_checkbox);
		waitFor(2000);
		jsClick(teen_checkbox);
		waitFor(2000);
		jsClick(kid_checkbox);
		waitFor(2000);
		ClickOnWebElement(save_button);
	}

	public void navigateDown_scroll() {
		waitFor(2000);
		Actions a = new Actions(DriverManager.getDriver());
		a.sendKeys(Keys.PAGE_DOWN).build().perform();
		waitFor(3000);
	}

	public void verify_programSection() {
		WaitForWebElement(myprogram_program_closedProgramSection);
		javascriptScroll(myprogram_program_closedProgramSection);
		isElementPresent(myprogram_program_closedProgramSection);

	}

	public void validate_Reading_List() {
		visibilityWait(progDetailScreen_readinglist);
		javascriptScroll(progDetailScreen_readinglist);
//		isElementPresent(progDetailScreen_readinglist);
		waitFor(3000);

		/*
		 * if (isElementPresent(progDetailScreen_readinglist)) {
		 * Assert.assertTrue(isElementPresent(progDetailScreen_readinglist)); } else {
		 * Logger.log("Reading List is not displayed"); }
		 */
	}

	public void click_activeProg() {
		waitFor(2000);
//		if (System.getProperty("Environment").equalsIgnoreCase("QA2")) {
			visibilityWait(active_Prog);
			javascriptScroll(active_Prog);
			jsClick(active_Prog);
			WaitForWebElement(program_details);
//		} else if (System.getProperty("Environment").equalsIgnoreCase("UAT")) {
//			visibilityWait(active_ProgUAT);
//			javascriptScroll(active_ProgUAT);
//			jsClick(active_ProgUAT);
//			WaitForWebElement(program_details);
//		}
	}

	public void click_ClosedProg() {
		waitFor(2000);
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			visibilityWait(closed_xyprograms);
			javascriptScroll(closed_xyprograms);
			jsClick(closed_xyprograms);
			WaitForWebElement(program_details);
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			visibilityWait(closed_xyprogramsUAT);
			javascriptScroll(closed_xyprogramsUAT);
			jsClick(closed_xyprogramsUAT);
			WaitForWebElement(program_details);
		}
	}

	public void click_ongoingprog() {
		waitFor(2000);
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			visibilityWait(ongoing_prog);
			javascriptScroll(ongoing_prog);
			jsClick(ongoing_prog);
			WaitForWebElement(program_details);
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			visibilityWait(ongoing_prog);
			javascriptScroll(ongoing_prog);
			jsClick(ongoing_prog);
			WaitForWebElement(program_details);
		}
	}

	public void click_upcomingprog() {
		waitFor(2000);
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			visibilityWait(upcoming_prog);
			javascriptScroll(upcoming_prog);
			jsClick(upcoming_prog);
			WaitForWebElement(program_details);
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			visibilityWait(upcoming_prog);
			javascriptScroll(upcoming_prog);
			jsClick(upcoming_prog);
			WaitForWebElement(program_details);
		}
	}
}
