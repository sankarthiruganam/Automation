package pom.kidszone;

import com.resuableMethods.CommonAction;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class MyshelfvideosVbooks extends CommonAction {
	String titleName="";
	static ExcelReader reader = new ExcelReader();
	public MyshelfvideosVbooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(id = "loc_linkMyShelf")
	private WebElement Menu_myshlf;

	@FindBy(xpath = "//div[@class='mat-tab-links']")
	public static WebElement Menu_myshlftabs;

	@FindBy(id = "loc_labelCurrentlyCheckoutOut")
	public static WebElement myshlf_CurrrentlyCheckout;

	@FindBy(xpath = "(//div[@class='kz-carousel'])[1]")
	public static WebElement CurrentlyCheckout_Carousel;

	@FindBy(xpath = "(//img[@class='ac-image'])[1]")
	public static WebElement CurrentlyCheckout_videos;

	@FindBy(xpath = "//a[contains(text(),' Checkout History')]")
	private WebElement myshelf_history;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	private WebElement historyScreenTitle;

	@FindBy(xpath = "//a[contains(text(),' Checkouts')]")
	private WebElement myshelf_Checkouts;

	@FindBy(xpath = "(//*[text()='My Stuff'])[3]")
	public static WebElement Nav_mystuffScreen;

	@FindBy(id = "loc_txtCheckout History")
	public static WebElement mystuff_checkouthistory;

	@FindBy(id = "loc_txtCheckouts")
	public static WebElement mystuff_checkout;

	@FindBy(id = "")
	public static WebElement mystuff_checkoutVideoTitles;

	@FindBy(id = "")
	public static WebElement mystuff_checkoutVBookTitles;

	@FindBy(xpath = "(//*[contains(text(),'Play')])[1]")
	public static WebElement playas_primaryCTA;

	@FindBy(xpath = "//*[@autoplay='autoplay']")
	public static WebElement videoContainer;

	@FindBy(id = "play-pause")
	public static WebElement playerButton;

	@FindBy(id = "btnVideoPrevious")
	public static WebElement playerRev;

	@FindBy(id = "btnVideoNext")
	public static WebElement playerFwd;

	@FindBy(xpath = "//*[@class='icon icon-full-screen']")
	public static WebElement fullScreen;

	@FindBy(xpath = "//*[@class='icon icon-exit-full-screen']")
	public static WebElement exitFullScreen;

	@FindBy(id = "volume-bar")
	public static WebElement volumeBar;

	@FindBy(id = "mute")
	public static WebElement muteIcon;

	@FindBy(id = "currentTime")
	public static WebElement currentTime;

	@FindBy(id = "durationTime")
	public static WebElement durationTime;

	@FindBy(id = "seek-bar")
	public static WebElement seekBar;

	@FindBy(xpath = "(//button[@class='ac-pushButton style-default ac-selectable'])[1]")
	public static WebElement primaryCTAMyStuffPage;

	@FindBy(xpath = "(//*[contains(text(),'Remove')])[1]")
	public static WebElement removeAs_primaryCTA;

	@FindBy(xpath = "(//*[contains(text(),'Resume')])[1]")
	public static WebElement resumeAs_primaryCTA;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-more-down'])[1]")
	public static WebElement SecondaryCTA_dropdwn;

	@FindBy(xpath = "//button[@alt='return']")
	public static WebElement playSecondaryCTA_Return;

	@FindBy(xpath = "//button[@alt='renew']")
	public static WebElement playSecondaryCTA_Renew;

	@FindBy(xpath = "//button[@alt='renew']")
	public static WebElement ResumeSecondaryCTA_Renew;

	@FindBy(xpath = "//*[@class='mystuff-lists ng-star-inserted']")
	public static WebElement mystuff_checkout_Ebook;

	@FindBy(id = "dummy")
	public static WebElement mystuff_checkout_EAudio;

	@FindBy(id = "loc_btnSelected filter_items Videobooks")
	public static WebElement mystuff_checkout_vbooks;

	@FindBy(id = "loc_btnSelected filter_items Video")
	public static WebElement mystuff_checkout_videos;

	@FindBy(id = "dummy")
	public static WebElement mystuff_checkout_ListViewDefault;

	@FindBy(id = "dummy")
	public static WebElement Checkoutas_SecondaryCTA;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	public static WebElement mystuff_Checkoutas_Titles;

	@FindBy(id = "loc_btnSort")
	public static WebElement Mystuff_sort_btn;

	@FindBy(id = "loc_Recently Checkedout")
	private WebElement Mystuff_RecentlyCheckout;

	@FindBy(id = "loc_A-Z")
	private WebElement Mystuff_AtoZ;

	@FindBy(id = "loc_Due Date")
	private WebElement Mystuff_Ratings;

	@FindBy(id = "loc_btnSearchicons")
	private WebElement Mystuff_SearchIcons;

	@FindBy(id = "dummy")
	public static WebElement Mystuff_titleName;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	public static WebElement Mystuff_coverimg;

	@FindBy(id = "dummy")
	public static WebElement Mystuff_ExpiryDate;

	@FindBy(id = "dummy")
	public static WebElement Mystuff_RenewDate;

	@FindBy(xpath = "//label[@aria-owns='mat-input-7']")
	private WebElement Mystuff_searchInput;

	@FindBy(xpath = "dummy")
	public static WebElement Mystuff_searchResultsTitle;

	@FindBy(xpath = "dummy")
	public static WebElement Mystuff_searchResults_Listview;

	@FindBy(id = "loc_btnFilter")
	private WebElement Mystuff_Filter;

	@FindBy(id = "loc_btnSelected filter_items All")
	public static WebElement Mystuff_Filter_All;

	@FindBy(id = "loc_btnSelected filter_items eBook")
	private WebElement Mystuff_Filter_Ebook;

	@FindBy(id = "loc_btnSelected filter_items eAudio")
	private WebElement Mystuff_Filter_EAudio;

	@FindBy(xpath = "")
	public static WebElement ResumeSecondaryCTA_Return;

	@FindBy(xpath = "")
	public static WebElement eAudioSecCheckout;

	@FindBy(xpath = "")
	public static WebElement eAudioSecCheckoutGrid;

	@FindBy(xpath = "")
	public static WebElement eBookSecCheckout;

	@FindBy(xpath = "")
	public static WebElement eBookSecCheckoutGrid;

	@FindBy(xpath = "")
	public static WebElement videoSecCheckout;

	@FindBy(xpath = "//div[@class='mystuff-lists ng-star-inserted']")
	public static WebElement videoSecCheckoutGrid;

	@FindBy(xpath = "")
	public static WebElement vBookSecCheckout;

	@FindBy(xpath = "//div[@class='kz-my-stuff-main']")
	public static WebElement vBookSecCheckoutGrid;

	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	private WebElement coverImage;

	@FindBy(xpath = "(//*[@class='ac-columnSet'])[1]")
	public static WebElement titleDetailPage;

	@FindBy(xpath = "//span[@class='due-duration kz-time-remain-lbl ng-star-inserted']")
	public static WebElement dueDate;

	@FindBy(id = "loc_btnFilter")
	public static WebElement filterOptions;

	@FindBy(id = "loc_btnSort")
	public static WebElement sortButton;

	@FindBy(xpath = "(//*[@class='ac-pushButton style-default ac-selectable'])[1]")
	public static WebElement primaryCTAMyStuff;
	
	@FindBy(xpath = "(//a[@id='breadcrumb-link-2'])[1]")
	public static WebElement videosAndvbooks_titleName;
	
	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	private static WebElement vbooks_jacketimg;
	
	@FindBy(xpath = "(//button[@type='button']//div[text()='Checkout'])")
	private WebElement Lib_videoCarousel_PrimaryCTAasCheckout;
	
	@FindBy(xpath = "//*[@placeholder='Search for content']")
	public WebElement searchBar;

	@FindBy(xpath = "//*[@class='kz-searchButton']")
	public WebElement searchButton;

	@FindBy(xpath = "//*[@class='carousel-container']")
	public static WebElement searchResult;

	public static WebElement getFilterOptions() {
		return filterOptions;
	}

	public static WebElement getSortButton() {
		return sortButton;
	}

	public void checkoutScreenValidation() {
		Assert.assertTrue(eAudioSecCheckout.isDisplayed());
		Assert.assertTrue(eBookSecCheckout.isDisplayed());
		Assert.assertTrue(videoSecCheckout.isDisplayed());
		Assert.assertTrue(vBookSecCheckout.isDisplayed());
	}

	public void checkoutScreenTitleValidation() {
		visibilityWait(coverImage);
		Assert.assertTrue(coverImage.isDisplayed());
//		try {
//			if (dueDate.isDisplayed()) {
//				Assert.assertTrue(dueDate.isDisplayed());
//			} else {
//				Logger.log("user not able to view the title due date like checkout expiry or return date");
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}		
		Assert.assertTrue(playas_primaryCTA.isDisplayed());
	}

	public void click_MyshelfCTA() {
		visibilityWait(Menu_myshlf);
		jsClick(Menu_myshlf);
		visibilityWait(Menu_myshlftabs);
		// WaitForWebElement(Menu_myshlftabs);
	}

	public void Click_CheckoutHistory() {
		//visibilityWait(myshelf_history);
		WaitForWebElement(myshelf_history);
		jsClick(myshelf_history);
		WaitForWebElement(historyScreenTitle);
	}

	public void click_checkoutMyshelfpage() {
		visibilityWait(myshelf_Checkouts);
		ClickOnWebElement(myshelf_Checkouts);
		visibilityWait(Mystuff_coverimg);
	}

	public void click_playSecondaryCTADropdown() {
		if (playas_primaryCTA.isDisplayed()) {
			jsClick(SecondaryCTA_dropdwn);
			WaitForWebElement(playSecondaryCTA_Return);
		}
	}

	public void click_ResumeSecondaryCTADropdown() {
		if (ResumeSecondaryCTA_Renew.isDisplayed()) {
			jsClick(SecondaryCTA_dropdwn);
			WaitForWebElement(playSecondaryCTA_Return);
		}
	}

	public void click_MystuffSort_dropdwn() {
		visibilityWait(Mystuff_sort_btn);
		jsClick(Mystuff_sort_btn);
		waitFor(2000);
		Assert.assertTrue(Mystuff_RecentlyCheckout.isDisplayed());
		Assert.assertTrue(Mystuff_AtoZ.isDisplayed());
		Assert.assertTrue(Mystuff_Ratings.isDisplayed());
	}

	public void click_sortOptions() {
		if (Mystuff_RecentlyCheckout.isDisplayed()) {
			jsClick(Mystuff_RecentlyCheckout);
			mystuff_Checkoutas_Titles.isDisplayed();
		}
	}

	public void click_SearchIcon() {
//		String text = Mystuff_titleName.getText();
		visibilityWait(Mystuff_SearchIcons);
		jsClick(Mystuff_SearchIcons);
//		SendKeysOnWebElement(Mystuff_searchInput, text);		
	}

	public void view_FilterOptions() {
		visibilityWait(Mystuff_Filter);
		Assert.assertTrue(Mystuff_Filter.isDisplayed());
		jsClick(Mystuff_Filter);
		WaitForWebElement(Mystuff_Filter_All);
		Mystuff_Filter_All.isDisplayed();
		Mystuff_Filter_Ebook.isDisplayed();
		Mystuff_Filter_EAudio.isDisplayed();
		mystuff_checkout_vbooks.isDisplayed();
		mystuff_checkout_videos.isDisplayed();
	}

	public void clickTitleCoverImage() {
		visibilityWait(coverImage);
		waitFor(2000);
		javascriptScroll(coverImage);
		waitFor(2000);
		jsClick(coverImage);
		visibilityWait(titleDetailPage);
		// WaitForWebElement(titleDetailPage);
	}

	public void view_CombaindSectioninMystuff() {
		mystuff_checkout_Ebook.isDisplayed();
//		mystuff_checkout_EAudio.isDisplayed();
//		javascriptScroll(mystuff_checkout_vbooks);
//		mystuff_checkout_vbooks.isDisplayed();
//		mystuff_checkout_videos.isDisplayed();
	}

	public boolean view_title_ExpirydateAndRenewDate() {
		boolean b = true;
		Mystuff_ExpiryDate.isDisplayed();
		Mystuff_RenewDate.isDisplayed();
		return b;
	}

	public void clickPlayOrResume() {
		if (System.getProperty("browser").equalsIgnoreCase("Safari")) {
			Logger.log("Window Switch is not possible");
		} else if (System.getProperty("browser").equalsIgnoreCase("IOS")) {
			Logger.log("Window Switch is not possible");
		} else {
			waitFor(2000);
			if (isElementPresent(playas_primaryCTA)) {
				jsClick(playas_primaryCTA);
			} else if (isElementPresent(resumeAs_primaryCTA)) {
				jsClick(resumeAs_primaryCTA);
			}
		}
	}

	public void switchPlayer() {
		waitFor(2000);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		waitFor(2000);
		javascriptScroll(videoContainer);
		//Assert.assertEquals(DriverManager.getDriver().getTitle(), "Boundless");
		waitFor(2000);
		playerPausePlay();
	}

	public void exitPlayer() {
		waitFor(2000);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		waitFor(2000);
	}

	public void playerPausePlay() {
		mouseHover(DriverManager.getDriver(), videoContainer);
		javascriptScroll(videoContainer);
		jsClick(videoContainer);
		mouseHover(DriverManager.getDriver(), videoContainer);
		visibilityWait(playerButton);
		Logger.log("Player paused and Resumed");
	}

	public int streamTime() {
		String streamTime = currentTime.getText();
		String trim = streamTime.substring(3, 4);
		int trimTime = Integer.parseInt(trim);
		System.out.println("current time"+trimTime);
		return trimTime;
	}
	
	public int vbook_streamTime() {
		String streamTime = currentTime.getText();
		String trim = streamTime.substring(3, 4);
		int trimTime = Integer.parseInt(trim);
		System.out.println("current time  "+trimTime);
		return trimTime;
	}
	
	public void playerFwd() {
		int currentTime = streamTime();
		Logger.log("The Current Streaming Time is " + currentTime);
		jsClick(playerFwd);
		waitFor(2000);
		int forwardedTime = streamTime();
		Logger.log("After Clicking Forward Button is " + forwardedTime);
		Assert.assertEquals(currentTime + 10, forwardedTime);
		Assert.assertFalse(currentTime == forwardedTime);
		Logger.log("By clicking the forward button stream time forwarded successfully");
	}
	
	public void vbook_playerFwd() {
		int currentTime = vbook_streamTime();
		Logger.log("The Current Streaming Time is " + currentTime);
		jsClick(playerFwd);
		waitFor(2000);
		int forwardedTime = streamTime();
		Logger.log("After Clicking Forward Button is " + forwardedTime);
		Assert.assertEquals(currentTime + 10, forwardedTime);
		Assert.assertFalse(currentTime == forwardedTime);
		Logger.log("By clicking the forward button stream time forwarded successfully");

	}

	public void playerRev() {
		int currentTime = streamTime();
		Logger.log("The Current Streaming Time is " + currentTime);
		jsClick(playerRev);
		waitFor(2000);
		int backwardTime = streamTime();
		Logger.log("After Clicking Backward Button is " + backwardTime);
		Assert.assertEquals(currentTime - 10, backwardTime);
		Assert.assertFalse(currentTime == backwardTime);
		Logger.log("By clicking the forward button stream time forwarded successfully");
	}

	public void muteAndUnmute() {
		javascriptScroll(videoContainer);
		WaitForWebElement(muteIcon);
		ClickOnWebElement(muteIcon);
		waitFor(1000);
		ClickOnWebElement(muteIcon);
		waitFor(1000);
	}

	public void fullScreen() {
		mouseHover(DriverManager.getDriver(), videoContainer);
		javascriptScroll(videoContainer);
		visibilityWait(fullScreen);
		ClickOnWebElement(fullScreen);
		//visibilityWait(exitFullScreen);
		Logger.log("User able to view the video full screen");
	}

	public void exitFullScreen() {
		mouseHover(DriverManager.getDriver(), videoContainer);
		javascriptScroll(videoContainer);
		waitFor(1000);
		if (fullScreen.isDisplayed()) {
			jsClick(fullScreen);
			visibilityWait(exitFullScreen);
			jsClick(exitFullScreen);
		}else {
			ClickOnWebElement(exitFullScreen);
		}
		WaitForWebElement(fullScreen);
		Logger.log("User able to view the video minimised screen");
	}
	
	
	public String get_videosAndVbookTitleName() {
		String titleName = videosAndvbooks_titleName.getText();
		System.out.println("Adult title name" + titleName);
		return titleName;

	}
	
	public void searchtitle(String titleName) {
		visibilityWait(searchBar);
		SendKeysOnWebElement(searchBar, titleName);
		ClickOnWebElement(searchButton);
	}
	
	public void search_checkoutTitle() {
//		waitFor(2000);
//		searchtitle(titleName);
		waitFor(2000);
		visibilityWait(vbooks_jacketimg);
		jsClick(vbooks_jacketimg);
		javascriptScroll(Lib_videoCarousel_PrimaryCTAasCheckout);
		jsClick(Lib_videoCarousel_PrimaryCTAasCheckout);

	}

}
