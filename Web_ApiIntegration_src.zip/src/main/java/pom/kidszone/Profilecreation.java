package pom.kidszone;

import java.io.IOException;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Profilecreation extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public Profilecreation(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "RegisterModel_DisplayName")
	private WebElement txtbox_regdisplayname;

	@FindBy(id = "RegisterModel_Email")
	private WebElement txtbox_regemail;

	@FindBy(xpath = "//label[contains(text(),'Adult')]")
	private WebElement label_adult;

	@FindBy(id = "teen")
	private WebElement label_Teen;

	@FindBy(id = "kid")
	private WebElement label_kid;

	@FindBy(xpath = "//button[@class='no-thanks-btn']")
	private WebElement preference_Nothanks_popup;

	@FindBy(id = "closeButton")
	private WebElement closeButton_popup;

	@FindBy(id = "toggle")
	private WebElement btn_menu;

	@FindBy(id = "closeButton")
	private WebElement btn_CloseOverlay;

	@FindBy(xpath = "//*[@id='alert-heading'][contains(text(),'Read & Checkout in our app!')]")
	private WebElement readPopUp;

	@FindBy(xpath = "//*[@class='alert-dialog ng-star-inserted']/*[@aria-label='Close']")
	private WebElement readPopUpclose;

	@FindBy(xpath = "//a[text()='PROFILES']")
	private WebElement menu_profiles;

	@FindBy(xpath = "//button[contains(text(),'Register')]")
	private WebElement btn_Register;

	@FindBy(id = "loginBtn")
	private WebElement btn_login_Button;

	@FindBy(xpath = "//*[@svgicon='kz-hamburger']")
	private WebElement hamMenuNew;

	@FindBy(id = "RegisterModel_UserName")
	private WebElement txt_userName_Textfield;

	@FindBy(id = "RegisterModel_SecurityAnswer")
	private WebElement txtbox_regsecurityanswer;

	@FindBy(id = "RegisterModel_SecurityQuestion_button")
	private WebElement txt_securityQuestion_dropdown;

	@FindBy(id = "RegisterModel_Password")
	private WebElement txt_password_Textfield;

	@FindBy(id = "loc_txtProfileManagementPin")
	private WebElement txt_profileManagementPin;

	@FindBy(id = "loc_btnSubmit")
	private WebElement btn_setupPin_submit;

	@FindBy(id = "loc_confirmbtnOK")
	private WebElement btn_Yes;

	@FindBy(xpath = "//input[@type='password']")
	private List<WebElement> txtfield_profileManagementPin;

	@FindBy(id = "showHidePassword")
	private WebElement lnk_showHidden_Password;

	@FindBy(id = "lnkShowRegPwd")
	private WebElement lnk_contactAdmin_forPassword;

	@FindBy(xpath = "//*[@id=\"loginForm\"]/div/div[3]/button")
	private WebElement btn_signin;

	@FindBy(id = "forgotPinLink")
	private WebElement link_forgotPin;

	@FindBy(id = "dialogHeadingForgotPin")
	private WebElement txt_forgotPin_Heading;

	@FindBy(id = "IsDialog")
	private WebElement txt_forgotPin_Subheading;

	@FindBy(id = "Username")
	private WebElement txt_forgotPin_Username_Textfield;

	@FindBy(xpath = "//*[@id=\"forgotPinForm\"]/div[4]/button")
	private WebElement btn_forgotPin_Submit;

	@FindBy(xpath = "//*[@id=\"loginBackBtn\"]/span/svg")
	private WebElement btn_forgotPin_Back;

	@FindBy(xpath = "//*[@id=\"forgotPinModal\"]/div/div/div/div[2]/button/span/svg")
	private WebElement btn_forgotPin_Close;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div/div[1]/button/span/svg")
	private WebElement btn_close_login;

	@FindBy(xpath = "//a[text()='Library Home']")
	private WebElement txt_homepage;

	@FindBy(id = "btnLogout")
	private WebElement btn_logout;

	@FindBy(id = "btnLogoutMobile")
	private WebElement mobilebrowser_btn_logout;

	@FindBy(id = "loc_txtProfiles")
	private WebElement Addprofile_txt_profile;

	@FindBy(id = "loc_cancelbtn")
	private WebElement btn_Cancel;

	@FindBy(id = "add-profile-button")
	private WebElement Addprofile_btn_addprofilebutton;

	@FindBy(id = "loc_txtAddaProfile")
	private WebElement Addprofile_txt_addprofile;

	@FindBy(id = "loc_btnAddaTeen")
	private WebElement Addprofile_label_addTeenprofile;

	@FindBy(id = "loc_btnAddaKid")
	private WebElement Addprofile_label_addkidprofile;

	@FindBy(id = "loc_txtDisplayName")
	public static WebElement editprofile_txtfield_displayName;

	@FindBy(id = "loc_dpProfileType")
	private WebElement editprofile_txt_profileType;

	@FindBy(id = "loc_txtDisplayName")
	private WebElement Addprofile_txtfield_displayName;

	@FindBy(xpath = "//div[@role='button']")
	private List<WebElement> manageProf_icon_profile;

	@FindBy(xpath = "//button[contains(text(),'Done')]")
	private WebElement parentalpin_btn_done;

	@FindBy(xpath = "//p[contains(text(),'Checkout Limit')]")
	private WebElement manageProf_txt_checkoutLimit;

	@FindBy(xpath = "(//p[contains(text(),'Hold')])[1]")
	private WebElement manageProf_txt_holdLimit;

	@FindBy(xpath = "(//p[@class='edit-details-value ng-star-inserted'])[4]")
	private WebElement manageProf_txt_RecommendationLimit;

	@FindBy(id = "loc_linkEdit")
	private WebElement manageProf_edit_button;

	@FindBy(xpath = "(//div[@role='button'])")
	private List<WebElement> manageProf_pencilIcon_editProfile;

	@FindBy(xpath = "//span[contains(text(),'Display checkout history')]")
	private WebElement manageProf_txt_checkoutHistory;

	@FindBy(xpath = "//span[contains(text(),' Display Insight & Badges')]")
	private WebElement manageProf_txt_insightbadgesCheckbox;

	@FindBy(xpath = "//span[contains(text(),' Set My Shelf page as my default landing page')]")
	private WebElement manageProf_txt_Myshelfdefaultlanding;

	@FindBy(xpath = "//img[@alt='profile image']")
	private WebElement manageProf_txt_librarydisplayed;

	@FindBy(id = "edit-icon-focus")
	private WebElement manageProf_txt_editicon;

	@FindBy(xpath = "//p[@class='parent-email']")
	private WebElement manageProf_txt_parentalEmail;

	@FindBy(id = "loc_btnDone")
	private WebElement Addprofile_btn_done;

	@FindBy(xpath = "//span[contains(text(),'Teen profile has been created successfully.')]")
	private WebElement profile_errormessage_createTeenprofile;

	@FindBy(xpath = "//span[contains(text(),'Kid profile has been created successfully ')]")
	private WebElement profile_errormessage_createKidprofile;

	@FindBy(xpath = "//div[@class='profile-image adult profile-default-border']")
	private WebElement profile_img_hightlightedProfile;

	@FindBy(id = "loc_btnSelectAvator")
	private WebElement manageProf_label_selectAvatar;

	@FindBy(xpath = "//img[@alt='avatar 1']")
	private WebElement manageProf_img_selectAvatar;

	@FindBy(xpath = "//div[@class='profile-details']")
	private List<WebElement> manageProf_txt_profileDetails;

	@FindBy(id = "loc_linkDeleteProfile")
	private WebElement editProf_btn_deleteProfile;

	@FindBy(id = "loc_confirmbtnOK")
	private WebElement editProf_btn_deleteProfilePopupyes;

	@FindBy(id = "loc_cancelbtn")
	private WebElement editProf_btn_deleteProfilePopupNo;

	@FindBy(xpath = "//div[@class='profile-details']//following-sibling::p")
	private List<WebElement> manageProf_lbl_profType;

	@FindBy(xpath = "//div[@class='profile-details']//preceding-sibling::p")
	private List<WebElement> manageProf_lbl_profName;

	@FindBy(id = "loc_btnUploadPhoto")
	private List<WebElement> addprof_lbl_uploadimg;

	@FindBy(xpath = "//span[contains(text(),' Pin mismatch ')]")
	private List<WebElement> profile_invalidPin_errormessage;

	@FindBy(id = "edit-icon-focus")
	private WebElement edidProf_avatar;

	@FindBy(id = "loc_linkViewMyinterests")
	private WebElement manageProf_link_viewMyintrest;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement Nav_myinterestScreen;

	@FindBy(id = "loc_linkViewMyinterests")
	private WebElement manageprof_link_myinterests;

	@FindBy(id = "loc_txtAvailability")
	private WebElement txt_libraryscreen_availability;

	@FindBy(xpath = "//img[@class='kz-edit-icon']")
	private WebElement click_pen_icon;

	@FindBy(id = "loc_btnSave")
	private WebElement editprofile_Save;

	@FindBy(xpath = "//mat-select[@id='loc_dpProfileType']")
	public static WebElement editProfile_profiletype;

	@FindBy(xpath = "//label[contains(text(),'Teen ')]")
	private WebElement new_teen_user;

	@FindBy(xpath = "//label[contains(text(),'Kid ')]")
	private WebElement new_kid_user;

	/**************************************************************************************/

	public WebElement getManageProf_txt_editicon() {
		return manageProf_txt_editicon;
	}

	public WebElement getBtn_CloseOverlay() {
		return btn_CloseOverlay;
	}

	public WebElement getNew_teen_user() {
		return new_teen_user;
	}

	public WebElement getNew_kid_user() {
		return new_kid_user;
	}

	public WebElement getTxt_libraryscreen_availability() {
		return txt_libraryscreen_availability;
	}

	public WebElement getNav_myinterestScreen() {
		return Nav_myinterestScreen;
	}

	public WebElement getEdidProf_avatar() {
		return edidProf_avatar;
	}

	public WebElement getTxt_profileManagementPin() {
		return txt_profileManagementPin;
	}

	public WebElement getAddprofile_txt_profile() {
		return Addprofile_txt_profile;
	}

	public WebElement getAddprofile_txt_addprofile() {
		return Addprofile_txt_addprofile;
	}

	public WebElement getManageProf_edit_button() {
		return manageProf_edit_button;
	}

	public WebElement getAddprofile_label_addTeenprofile() {
		return Addprofile_label_addTeenprofile;
	}

	public WebElement getAddprofile_label_addkidprofile() {
		return Addprofile_label_addkidprofile;
	}

	public WebElement getAddprofile_btn_done() {
		return Addprofile_btn_done;
	}

	public WebElement getManageProf_txt_librarydisplayed() {
		return manageProf_txt_librarydisplayed;
	}

	public WebElement getProfile_errormessage_createTeenprofile() {
		return profile_errormessage_createTeenprofile;
	}

	public WebElement getProfile_errormessage_createKidprofile() {
		return profile_errormessage_createKidprofile;
	}

	public WebElement getProfile_img_hightlightedProfile() {
		return profile_img_hightlightedProfile;
	}

	public WebElement getManageProf_label_selectAvatar() {
		return manageProf_label_selectAvatar;
	}

	public List<WebElement> getManageProf_pencilIcon_editProfile() {
		return manageProf_pencilIcon_editProfile;
	}

	public WebElement getManageProf_txt_checkoutHistory() {
		return manageProf_txt_checkoutHistory;
	}

	public WebElement getManageProf_txt_insightbadgesCheckbox() {
		return manageProf_txt_insightbadgesCheckbox;
	}

	public WebElement getManageProf_txt_checkoutLimit() {
		return manageProf_txt_checkoutLimit;
	}

	public WebElement getManageProf_txt_holdLimit() {
		return manageProf_txt_holdLimit;
	}

	public WebElement getManageProf_txt_RecommendationLimit() {
		return manageProf_txt_RecommendationLimit;
	}

	public WebElement getEditProf_btn_deleteProfile() {
		return editProf_btn_deleteProfile;
	}

	public WebElement getEditProf_btn_deleteProfilePopup() {
		return editProf_btn_deleteProfilePopupyes;
	}

	public WebElement getEditProf_btn_deleteProfilePopupNo() {
		return editProf_btn_deleteProfilePopupNo;
	}

	public WebElement getTxt_homepage() {
		return txt_homepage;
	}

	/******************************************
	 * Action Methods
	 ***************************************/

	public void clickLogin() {
		btn_login_Button.click();
	}

	public void verify_registerPage_prefixRepopulate() {
		if (isElementPresent(txt_userName_Textfield)) {
			String libraryid = txt_userName_Textfield.getAttribute("value");
			if (libraryid.startsWith("BT")) {
				Logger.log("user is in Register page prefix" + libraryid + "is repopulated in library ID");
			} else {
				Logger.log("user is not able to see prefix");
			}
		}
	}

	public void registerPage_set_Pin(String pin) {
		SendKeysOnWebElement(txt_password_Textfield, pin);
	}

	public void select_SecurityQuestion() {
		Select select = new Select(txt_securityQuestion_dropdown);
		select.selectByVisibleText("What is your favorite Color?");
	}

	public void enter_securityAnswer(String securityanswer) {
		javascriptScroll(txtbox_regsecurityanswer);
		SendKeysOnWebElement(txtbox_regsecurityanswer, securityanswer);
	}

	public void enter_DisplayName(String displayName) {
		SendKeysOnWebElement(txtbox_regdisplayname, displayName);
	}

	public void enter_EmailAddress(String email) {
		SendKeysOnWebElement(txtbox_regemail, email);

	}

	public void select_profile(String profiletype) {
		if (profiletype.equalsIgnoreCase("adult")) {
			jsClick(label_adult);
			waitFor(2000);
		} else if (profiletype.equalsIgnoreCase("teen")) {
			jsClick(label_Teen);
			waitFor(3000);
		} else if (profiletype.equalsIgnoreCase("kid")) {
			jsClick(label_kid);
			waitFor(3000);
		}

	}

	public void click_RegisterButton() {
		jsClick(btn_Register);
		// ClickOnWebElement(btn_Register);
		waitFor(3000);
		visibilityWait(btn_CloseOverlay);
		// WaitForWebElement(btn_CloseOverlay);
	}

	public void addprofle_donebtn() {
		jsClick(Addprofile_btn_done);
		waitFor(2000);

	}

	public void preferenceScreen_popup() {
		try {
			if (btn_CloseOverlay.isDisplayed()) {
				jsClick(btn_CloseOverlay);
			} else {
				Logger.log("Set Preferences Pop up is not displayed");
			}
		} catch (Exception e) {

			Logger.log("Set Preferences Pop up is not displayed");
		}
	}

	public void readInAppClose() {
		try {
			waitFor(2000);
			ClickOnWebElement(readPopUpclose);
		} catch (Exception e) {
			Logger.log("Read In Our App Pop-Up is not displayed");
		}
	}

	public boolean toastValidation() {
		WaitForListWebElement(profile_invalidPin_errormessage);
		boolean toastDisplay = true;
		if (profile_invalidPin_errormessage.size() != 0) {
			Logger.log("toast message is displayed");
		} else {
			toastDisplay = false;
			Logger.log("cant able to see toast message");
		}
		return toastDisplay;
	}

	public void already_setupParentPin() {
		ClickOnWebElement(closeButton_popup);
		waitFor(4000);
		if (isElementPresent(txt_homepage)) {
			Logger.log("user already setup the parent pin to navigate to home screen");
		}
		waitFor(3000);
	}

	public void notSelectedProfileAlready_withbrowserCache() {
		WebDriver chromeDriver = null;
		chromeDriver.manage().deleteAllCookies();
		chromeDriver.get("chrome://settings/clearBrowserData");
	}

	public void Enter_setPin(String Pin) {
		String pin = Pin;
		for (int i = 0; i < pin.length(); i++) {
			char s = pin.charAt(i);
			String s1 = new StringBuilder().append(s).toString();
			SendKeysOnWebElement(txtfield_profileManagementPin.get(i), s1);
		}
		waitFor(4000);
	}

	public void clickSubmit() {
		jsClick(btn_setupPin_submit);
		waitFor(5000);
	}

	public void clickDone() {
		jsClick(parentalpin_btn_done);
		waitFor(2000);
	}

	public void Enter_setupParentalPin(String Pin) {
		String pin = Pin;
		for (int i = 0; i < pin.length(); i++) {
			char s = pin.charAt(i);
			String s1 = new StringBuilder().append(s).toString();
			SendKeysOnWebElement(txtfield_profileManagementPin.get(i), s1);
			ClickOnWebElement(parentalpin_btn_done);
		}
		for (int j = 0; j < pin.length(); j++) {
			char s2 = pin.charAt(j);
			String s3 = new StringBuilder().append(s2).toString();
			SendKeysOnWebElement(txtfield_profileManagementPin.get(j), s3);
			ClickOnWebElement(parentalpin_btn_done);
		}
		waitFor(3000);
	}

	public void log_Out() {
		waitFor(2000);
		if (btn_logout.isDisplayed()) {
			jsClick(btn_logout);
		} else {
			jsClick(mobilebrowser_btn_logout);
		}
	}

	public void click_menu() {
		ClickOnWebElement(btn_menu);
		waitFor(4000);
		ClickOnWebElement(menu_profiles);
		waitFor(2000);

	}

	public void click_MenuOnly() {
		waitFor(6000);
		if (isElementPresent(btn_menu)) {
			jsClick(btn_menu);
		} else if (isElementPresent(hamMenuNew)) {
			jsClick(hamMenuNew);
		}

	}

	public void clickOnAddCTA() {
		System.out.println(manageProf_lbl_profName.size());
		waitFor(2000);
		if (manageProf_lbl_profName.size() <= 4) {
			jsClick(Addprofile_btn_addprofilebutton);
		} else if (manageProf_lbl_profName.size() == 5) {
			System.out.println("Entering else");
			edit_deleteProfile1();
			jsClick(Addprofile_btn_addprofilebutton);
		}
	}

	public void edit_deleteProfile() {
		jsClick(manageProf_edit_button);
		System.out.println("clicking edit button");
		for (int i = manageProf_lbl_profName.size() - 1; i > 0; i++) {
			if (!manageProf_lbl_profType.get(i).getText().contains("Adult"))
				waitFor(2000);
			jsClick(manageProf_pencilIcon_editProfile.get(i));
			waitFor(3000);
			for (int j = manageProf_lbl_profName.size() - 1; j > 0; j++) {
				if (!manageProf_lbl_profType.get(j).getText().contains("Adult"))
					waitFor(2000);
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(j));
				waitFor(3000);

				javascriptScroll(editProf_btn_deleteProfile);
				ClickOnWebElement(editProf_btn_deleteProfile);
				ClickOnWebElement(editProf_btn_deleteProfilePopupyes);
				waitFor(2000);
				break;

			}
		}
	}

	public void edit_deleteProfile1() {
		jsClick(manageProf_edit_button);
		System.out.println("clicking edit button");
		for (int i = manageProf_lbl_profName.size() - 1; i > 0; i++) {
			if (!manageProf_lbl_profType.get(i).getText().contains("Adult"))
				waitFor(2000);
			jsClick(manageProf_pencilIcon_editProfile.get(i));
			waitFor(3000);
			javascriptScroll(editProf_btn_deleteProfile);
			jsClick(editProf_btn_deleteProfile);
			ClickOnWebElement(editProf_btn_deleteProfilePopupyes);
			waitFor(2000);
			break;
		}
	}

	public void select_penIcon() {
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Teen")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			} else if (manageProf_lbl_profType.get(i).getText().contains("Kid")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			}
		}

	}

	public boolean kidProfile_notShowingUploadimg() {
		boolean uploading = false;
		if (addprof_lbl_uploadimg.size() != 0) {
			uploading = true;
			Logger.log("User shouldn't show upload img");
		}
		return uploading;
	}

	public void click_addprofile_Button() {
		ClickOnWebElement(Addprofile_btn_addprofilebutton);
	}

	public boolean view_addProfile(String profiletype) {
		boolean b = true;
		if (profiletype.equalsIgnoreCase("teen")) {
			isElementPresent(Addprofile_txt_addprofile);
			Logger.log("user views the profile creation page with options");
		} else if (profiletype.equalsIgnoreCase("kid")) {
			isElementPresent(Addprofile_txt_addprofile);
			Logger.log("user views the profile creation page with options");
		} else {
			b = false;
			Logger.log("user is not able to views the profile creation page with options");
		}
		return b;
	}

	public void Addprofile_enterDisplayName(String displayname) {
		jsClick(Addprofile_txtfield_displayName);
		// ClickOnWebElement(Addprofile_txtfield_displayName);
		SendKeysOnWebElement(Addprofile_txtfield_displayName, displayname);
		waitFor(2000);
	}

	public void select_avatar(String displayname) {
		javascriptScroll(Addprofile_txtfield_displayName);
		jsClick(Addprofile_txtfield_displayName);
		// ClickOnWebElement(Addprofile_txtfield_displayName);
		SendKeysOnWebElement(Addprofile_txtfield_displayName, displayname);
		waitFor(2000);
		jsClick(manageProf_label_selectAvatar);
		waitFor(2000);
		jsClick(manageProf_img_selectAvatar);
		waitFor(2000);
	}

	public WebElement recent_profileHighlighted() {
		JavascriptExecutor driver = null;
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='.1rem solid'",
					profile_img_hightlightedProfile);
			Logger.log("user view recent profile highlighted");
		}
		return profile_img_hightlightedProfile;
	}

	public void profDisplayCheck() {
		if (manageProf_icon_profile.size() != 0 && manageProf_icon_profile.size() <= 5) {
			for (int i = 0; i <= manageProf_icon_profile.size() - 1; i++) {
				Logger.log(" view the existing profiles list : " + manageProf_icon_profile.get(i));
			}
		} else if (manageProf_icon_profile.size() == 0) {
			Logger.log("User is on the manage profile screen but no profiles displayed");
		}
	}

	public void verify_eachProfile_Penicon() {
		for (int i = 0; i < manageProf_pencilIcon_editProfile.size(); i++) {
			if (manageProf_pencilIcon_editProfile.size() <= 5) {
				Logger.log("user is able to see each profile pen icon");
			} else {
				Logger.log("user is not able to see each profile pen icon");
			}
		}
	}

	public boolean profileDetails_autoPopulated() {
		boolean b = true;
		isElementPresent(editprofile_txtfield_displayName);
		//isElementPresent(manageProf_txt_parentalEmail);
		Logger.log("user is able to view display name and parental email");
		return b;
	}

	public boolean library_information() {
		boolean libraryinformation = true;
		if (libraryinformation) {
			isElementPresent(manageProf_txt_librarydisplayed);
			isElementPresent(manageProf_txt_checkoutLimit);
			isElementPresent(manageProf_txt_RecommendationLimit);
			Logger.log("user is able to view library informationl");
		} else {
			libraryinformation = false;
		}

		return libraryinformation;
	}

	public void manageprofielScreenNav() {
		if (manageProf_icon_profile.size() != 0) {
			Logger.log("User is on the manage profile screen");
		}
	}

	public boolean addProfilevalidation() {
		boolean b = true;
		try {
			isElementPresent(Addprofile_btn_addprofilebutton);
			Logger.log("Add button is displayed");
		} catch (Exception e) {
			b = false;
			Logger.log("Add button is not displayed");
		}
		return b;
	}

	public void verify_create5ProfileOnly() {
		if (manageProf_icon_profile.size() != 0 && manageProf_icon_profile.size() == 5) {
			for (int i = 0; i <= manageProf_icon_profile.size() - 1; i++) {
				Logger.log(" user already created  " + manageProf_icon_profile.get(i));
			}
		} else {
			Logger.log(" user is not able to see profiles");
		}
	}

	public void manageProf_edit() {
		waitFor(4000);
		ClickOnWebElement(manageProf_edit_button);

	}

	public boolean verify_homeScreenNav() {
		boolean b = true;
		javascriptScroll(txt_homepage);
		isElementPresent(txt_homepage);
		Logger.log("user is on home page");
		return b;
	}

	public void enter_WrongPin() {
		String pin = "1432";
		for (int i = pin.length() - 1; i >= 0; i--) {
			char s = pin.charAt(i);
			String s1 = new StringBuilder().append(s).toString();
			SendKeysOnWebElement(txtfield_profileManagementPin.get(i), s1);
		}
		waitFor(4000);
	}

	public boolean confirmation_popup() {
		boolean confirmationPopup = true;
		isElementPresent(editProf_btn_deleteProfilePopupyes);
		Logger.log("user is able to see confirmation yes option");
		isElementPresent(editProf_btn_deleteProfilePopupNo);
		Logger.log("user is able to see confirmation nO option");
		return confirmationPopup;
	}

	public void view_deleteProfile_option() {
		javascriptScroll(editProf_btn_deleteProfile);
		try {
			isElementPresent(editProf_btn_deleteProfile);
			Logger.log("user is able to view delete profile option");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_yesConfirmpopup() {
		if (isElementPresent(btn_Yes)) {
			ClickOnWebElement(btn_Yes);
		} else {
			System.out.println("yes button not displayed");
		}
		waitFor(2000);
	}

	public void click_NoPopup() {
		ClickOnWebElement(btn_Cancel);
		waitFor(2000);
	}

	public boolean verify_AlreadyAdultProfile() {
		boolean adult = true;
		for (int i = 0; i < manageProf_lbl_profType.size() - 1; i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Adult")) {
				Logger.log("user already have adult profile");
			}
		}
		return adult;
	}

	public boolean verify_shouldnotshowAdultProfile() {
		boolean adult = true;
		for (int i = 0; i < manageProf_lbl_profType.size() - 1; i++) {
			if (!manageProf_lbl_profType.get(i).getText().contains("Adult")) {
				Logger.log("user should not show adult profie");
			}
		}
		return adult;
	}

	public void click_delete_profile() {
		for (int i = 5; i <= manageProf_lbl_profName.size() - 1; i--) {
			if (manageProf_lbl_profType.get(i).getText().contains("Adult"))
				jsClick(manageProf_pencilIcon_editProfile.get(i));
		}
	}

	public void existingUser_setpin() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "setpin");
		registerPage_set_Pin(testData.get(0).get("Pin"));
		enter_securityAnswer(testData.get(0).get("securityAns"));
		enter_DisplayName(testData.get(0).get("displayname"));
		enter_EmailAddress(testData.get(0).get("email"));
		select_profile(testData.get(0).get("adult"));
		click_RegisterButton();
		preferenceScreen_popup();
		log_Out();
	}

	public void click_viewMyinterest() {
		javascriptScroll(manageProf_link_viewMyintrest);
		jsClick(manageProf_link_viewMyintrest);
		waitFor(2000);
		WaitForWebElement(Nav_myinterestScreen);
	}

	public void click_interestSurvey() {
		try {
			javascriptScroll(manageprof_link_myinterests);
			jsClick(manageprof_link_myinterests);
			waitFor(2000);
		} catch (Exception e) {

			Logger.log("Interest survey is not displayed ");
		}
	}

	public void editAdultProfile() {
		jsClick(manageProf_edit_button);
		jsClick(click_pen_icon);
	}

	public void editProfile_save() {
		javascriptScroll(editprofile_Save);
		ClickOnWebElement(editprofile_Save);
		waitFor(3000);
	}

	public void create_addkidProfile() {
		javascriptScroll(Addprofile_label_addkidprofile);
		jsClick(Addprofile_label_addkidprofile);
		waitFor(2000);
	}

	public void click_new_teen_user() {
		ClickOnWebElement(new_teen_user);

	}

	public void click_new_kid_user() {
		ClickOnWebElement(new_kid_user);
	}

	public void click_manageProf_Edit_button() {
		jsClick(manageProf_edit_button);
	}

	public void create_addTeenProfile() {
		javascriptScroll(Addprofile_label_addTeenprofile);
		jsClick(Addprofile_label_addTeenprofile);
		waitFor(2000);
	}

	public void select_AdultProfile() {
		jsClick(manageProf_pencilIcon_editProfile.get(0));
		waitFor(2000);
	}

	public void select_Kidprofile() {
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Kid")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			}
		}
		preferenceScreen_popup();
	}

	public void select_Teenprofile() {
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Teen")) {
				WaitForWebElement(manageProf_pencilIcon_editProfile.get(i));
				jsClick(manageProf_pencilIcon_editProfile.get(i));
				waitFor(5000);
			}
		}
		preferenceScreen_popup();
	}
	
}
