package pom.kidszone;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class SearchResults_Vbooks extends CommonAction {
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();
	MyLibrary_Videobooks library = new MyLibrary_Videobooks(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());

	public SearchResults_Vbooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Advanced Search']")
	public static WebElement AdvanceSearch_txt;

	@FindBy(id = "advancedSearchForm")
	public static WebElement AdvancedSearch_popup;

	@FindBy(xpath = "(//label[contains(text(),'Checkers Library TV')])[1]")
	private WebElement AdvancedSearch_video_radiobtn;

	@FindBy(xpath = "(//div[@class='third-party-card third-party-card-checkout-videos third-party-card-common'])[1]")
	private WebElement relatedvideoTitleTier3;

	@FindBy(xpath = "(//*[contains(@id,'list_id_VBOOKS')]//following::*[@class='ac-container ac-selectable'])[1]")
	private WebElement vBookTitleCard;

	@FindBy(xpath = "(//*[@id='list_id_VIDEOS']//following::*[@class='ac-container ac-selectable'])[1]")
	private WebElement videoTitleCard;

	@FindBy(xpath = "(//*[@id='list_id_VBOOKS']//following::*[@class='ac-container ac-selectable'])")
	private List<WebElement> vBookTitleCardList;

	@FindBy(id = "loc_Videobooks")
	private WebElement AdvancedSearch_vbook_radiobtn;

	@FindBy(id = "searchText")
	public static WebElement AdvancedSearch_input;

	@FindBy(xpath = "//*[text()='Search']")
	private WebElement Search_btn;

	@FindBy(xpath = "(//div[@class='search-result-info'])[1]")
	private WebElement Search_Result;

	@FindBy(xpath = "//button[text()='Search']")
	private WebElement vbookCategory_separateCarousel;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement SearchREsult_breadcrumb;

	@FindBy(xpath = "(//div[@class='ac-container ac-adaptiveCard'])[2]")
	public static WebElement vbooks_Resources;

	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	public static WebElement videos_Resources;

	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	private static WebElement vbooks_jacketimg;

	@FindBy(xpath = "(//*[@class='ac-columnSet'])[6]")
	private static WebElement vbooks_icon;

	@FindBy(xpath = "//h2[@class='thirdparty-title']")
	private static WebElement vbooks_SearchResult_Tier2;

	@FindBy(xpath = "//*[@aria-label='See All Videobooks']")
	public static WebElement vbooks_SearchResult_SeeAll;

	@FindBy(xpath = "//*[@class='thirdparty-title']")
	public static WebElement vbooks_SearchResult_Tire2_Listview;

	@FindBy(id = "loc_third_party_VBOOKS_item_carousel")
	public static WebElement video_SearchResult_Tire2_Listview;

	@FindBy(id = "loc_third_party_VIDEOS_item_carousel")
	public static WebElement video_SearchResult_Tire1_Listview;

	@FindBy(xpath = "//div[@class='third-party-tier-two-container']")
	public static WebElement video_SearchResult_Tier2_Listview;

	@FindBy(xpath = "(//div[text()='Checkout'])[1]")
	public static WebElement vbooks_SearchResult_Tire2_primaryCTA;

	@FindBy(xpath = "//div[@class='ac-textBlock']")
	public static List<WebElement> vbooks_SearchResult_Titlename;

	@FindBy(xpath = "//a[@aria-label='videobooks']")
	public static WebElement vbooks_vbooks_Refiners;

	@FindBy(xpath = "//*[@class='search kz-custom-container-secondary']")
	public static WebElement expandedResultsView;

	@FindBy(xpath = "//*[contains(text(),'Newspapers & Magazines - 3rd party')]")
	public static WebElement vbooks_newspaper_Refiners;

	@FindBy(xpath = "//a[@aria-label='checkers library tv']")
	public static WebElement videos_Refiners;

	@FindBy(xpath = "(//a[@class='menuitem ng-star-inserted'])[1]")
	public static WebElement vbooks_All_Refiners;
	
	@FindBy(xpath = "//a[@aria-label='Selected all']")
	public static WebElement All_Refiners;

	@FindBy(xpath = "//a[@aria-label='ebooks']")
	public static WebElement vbooks_EbooksEAudio_Refiners;

	@FindBy(xpath = "//a[text()='Resource Hub ']")
	public static WebElement vbooks_ActivityResources_Refiners;

	@FindBy(xpath = "//a[text()='Web Resources ']")
	public static WebElement vbooks_webResources_Refiners;

	@FindBy(xpath = "//a[text()='Newspapers & Magazines - 3rd party ']")
	public static WebElement vbooks_NewspaperMagazine_Refiners;

	@FindBy(xpath = "(//*[contains(text(),'Checkout')])[2]")
	public static WebElement vbooks_LibPageCheckoutCta;

	@FindBy(xpath = "//*[contains(text(),'Video Carousel')]/following::*[contains(text(),'Checkout')]")
	public static List<WebElement> video_LibPageCheckoutCta;

	@FindBy(xpath = "//*[@class='kz-toast-msg']")
	private WebElement success_msg;

	@FindBy(xpath = "//*[@class='kz-alert-dialog kz-info-dialog']")
	public static WebElement popUpCheckout;

	@FindBy(xpath = "//*[@class='holdBtn']")
	public static WebElement popUpCheckoutokBtn;

	@FindBy(xpath = "//a[@aria-label='ebooks']")
	public static WebElement othertype_ebookEAudio;

	@FindBy(xpath = "(//div[@class='ac-container ac-adaptiveCard'])[2]")
	public static WebElement TitleCard_search;

	@FindBy(xpath = "(//*[@class='ac-textBlock'])[1]")
	public static WebElement titleNameTire3;

	@FindBy(xpath = "//*[@placeholder='Search for content']")
	public WebElement searchBar;

	@FindBy(xpath = "//*[@class='kz-searchButton']")
	public WebElement searchButton;

	@FindBy(xpath = "//*[@class='carousel-container']")
	public static WebElement searchResult;

	@FindBy(xpath = "//button[@title='Checkout']")
	private WebElement checkOutSearchResult;

	@FindBy(xpath = "//div[@class='kz-radio-btn-group ng-star-inserted']")
	private List<WebElement> AdvancedSearch_options;

	@FindBy(xpath = "//h2[contains(text(),'Advanced Search Options')]")
	public static WebElement AdvancedSearch_txt;

	@FindBy(xpath = "(//*[@svgicon='kz-close'])[2]")
	public static WebElement AdvancedSearch_closeIcon;

	@FindBy(xpath = "//*[contains(text(),'Format')]")
	public static WebElement AdvancedSearch_formattxt;

	@FindBy(xpath = "//*[contains(text(),'Format')]")
	public static WebElement Searchinput_cleartxt;

	@FindBy(id = "loc_Newspapers")
	public static WebElement AdvanceSearch_Newspaper;

	@FindBy(xpath = "//label[text()='Publication Date']")
	public static WebElement sort_publicationDate;

	@FindBy(id = "loc_Videobooks")
	public static WebElement AdvanceSearch_VBooks;

	@FindBy(id = "loc_Checkers Library TV")
	public static WebElement AdvanceSearch_VideoOption;

	@FindBy(xpath = "(//label[contains(text(),'Newspapers')])[1]")
	public static WebElement advanceSearch_Newspaper;

	@FindBy(xpath = "(//label[contains(text(),'Magazines')])[1]")
	public static WebElement advanceSearch_Magazine;

	@FindBy(xpath = "(//label[contains(text(),'Articles')])[1]")
	public static WebElement advanceSearch_Article;

	@FindBy(xpath = "//div[@class='third-party-tier-two-container']")
	public static WebElement advanceSearch_thirdpartySearchResult;

	@FindBy(xpath = "//*[@class='thirdparty-title']")
	public static WebElement advanceSearch_thirdpartySearchResult_title;

	@FindBy(xpath = "//span[@class='results-text ng-star-inserted']")
	public static WebElement advanceSearch_thirdpartySearchResult_Notitle;

	@FindBy(xpath = "//*[@class='no-third-party-title ng-star-inserted']")
	public static WebElement advanceSearch_thirdpartySearchResult_msg;

	@FindBy(xpath = "//*[@class='result-count']")
	public static WebElement advanceSearch_thirdpartySearchResult_count;

	@FindBy(xpath = "//div[@class='mat-tab-links']")
	public static WebElement advanceSearch_thirdpartySearchResult_pills;

	@FindBy(xpath = "//button[contains(text(),'Search')]")
	public static WebElement Search_CTA;

	@FindBy(xpath = "//*[@class='carousel-title heading-2 no-transform']")
	public static List<WebElement> advanceSearch_thirdpartySearchResult_Allformats;

	@FindBy(id = "loc_search_list_refiner")
	public static WebElement searchListRefiner;

	@FindBy(xpath = "//*[contains(text(),'Collections ')]")
	public static WebElement collection_dropdwn;

	@FindBy(id = "loc_refiners_Always Available")
	public static WebElement always_Available;

	@FindBy(xpath = "//*[contains(text(),' Availability ')]")
	public static WebElement availability_dropdwn;

	@FindBy(id = "loc_refiners_Available Now")
	public static WebElement availablenow;
	
	@FindBy(xpath = "//*[contains(text(),'Clear All')]")
	public static WebElement pills_clearAll;

	@FindBy(xpath = "(//*[contains(text(),'Resource Hub')])[1]")
	public static WebElement Advancesearch_ResourceHub;

	@FindBy(xpath = "(//*[contains(text(),'Web Resources')])[1]")
	public static WebElement Advancesearch_WebResources;

	@FindBy(xpath = "//*[@class='ng-star-inserted ui-radiobutton-label ui-label-disabled']")
	public static List<WebElement> FormatAndType_disabled;

	@FindBy(xpath = "(//label[contains(text(),'Newspapers')])[1]")
	public static WebElement Advancesearch_newspapers;

	@FindBy(xpath = "(//*[contains(text(),'ISBN')])[1]")
	public static WebElement Advancesearch_ISBN;

	@FindBy(xpath = "//a[contains(text(),'eBooks ')]")
	public static WebElement format_eBook;

	@FindBy(xpath = "//*[@class='refine-filter-head']")
	public static WebElement tier2RefineHeader;

	@FindBy(xpath = "(//*[@class='thirdparty-title'])//span[@class='results-text ng-star-inserted']")
	public static WebElement searchCountNumber;

	@FindBy(xpath = "//*[@class='carousel']//..//..//preceding-sibling::h2")
	public static WebElement searchCountWithoutSeeAll;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])")
	public static List<WebElement> searchDisplayed;
	
	@FindBy(xpath = "//*[contains(text(),'Videos (')]//following::*[@svgicon='kz-right-arrow']")
	public static WebElement videos_SearchResult_SeeAll;
	
	@FindBy(xpath = "//h2[@class='thirdparty-title']")
	private static WebElement videos_SearchResult_Tier2;
	
	@FindBy(xpath = "//div[@class='search-result-info']")
	public static WebElement search_ResultAll;
	
	@FindBy(xpath = "//*[@class='search']")
	public static WebElement search_withoutSelectionFormat;
	
	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'Age Level')]")
	public static WebElement ageRangeRef;

	@FindBy(xpath = "(//*[@class='ac-input ac-choiceSetInput-expanded'])[1]")
	public static WebElement ageRangeRefSec;

	@FindBy(xpath = "(//*[@id='Refiner_title_Age Level']/following::*[@class='custom-radio'])[1]/label")
	public static WebElement ageRangeSecGrade1;
	
	@FindBy(xpath = "//div[contains(text(),'Search')]")
	public static WebElement refSearchButton;
	
	@FindBy(xpath = "//*[@class='spinner-loader']")
	public static WebElement spinnerLoading;
	
	@FindBy(xpath = "(//*[contains(text(),'AUDIENCE')]//following::*[@class='ac-textBlock'])[1]")
	public static WebElement audienceType;
	
	@FindBy(xpath = "(//*[contains(text(),'AGE RANGE')]//following::*[@class='ac-container'])[1]")
	public static WebElement ageRangeValue;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement return_confirmBtn;
	
	@FindBy(xpath = "(//*[contains(text(),'Title')])[1]")
	public static WebElement Advancesearch_TITLE;

	@FindBy(xpath = "(//*[contains(text(),'Author')])[1]")
	public static WebElement Advancesearch_AUTHOR;


	public static WebElement getVbooks_icon() {
		return vbooks_icon;
	}

	public static WebElement getPopUpCheckout() {
		return popUpCheckout;
	}

	public static WebElement getPopUpCheckoutokBtn() {
		return popUpCheckoutokBtn;
	}

	public WebElement getSuccess_msg() {
		return success_msg;
	}

	public WebElement getVbookCategory_separateCarousel() {
		return vbookCategory_separateCarousel;
	}

	public WebElement getSearch_Result() {
		return Search_Result;
	}

	public WebElement getAdvancedSearch_video_radiobtn() {
		return AdvancedSearch_video_radiobtn;
	}

	public WebElement getAdvancedSearch_vbook_radiobtn() {
		return AdvancedSearch_vbook_radiobtn;
	}

	public void click_videosInAdvancesearch() {
		javascriptScroll(AdvancedSearch_video_radiobtn);
		jsClick(AdvancedSearch_video_radiobtn);

	}

	public List<WebElement> getvBookTitleCardList() {
		return vBookTitleCardList;
	}

	public void clickVideoTitleCard() {
		visibilityWait(videoTitleCard);
		javascriptScroll(videoTitleCard);
		jsClick(videoTitleCard);
		WaitForWebElement(library.getTitleDetailPage());
	}

	public void clickVBookTitleCard() {
		javascriptScroll(vBookTitleCard);
		visibilityWait(vBookTitleCard);
		jsClick(vBookTitleCard);
		visibilityWait(library.getTitleDetailPage());
	}

	public void click_vbooksInAdvancesearch() {
		visibilityWait(AdvancedSearch_vbook_radiobtn);
		javascriptScroll(AdvancedSearch_vbook_radiobtn);
		waitFor(2000);
		jsClick(AdvancedSearch_vbook_radiobtn);
		waitFor(2000);
	}

	public void click_AdvanceSearch() {
		visibilityWait(AdvanceSearch_txt);
		jsClick(AdvanceSearch_txt);
		WaitForWebElement(AdvancedSearch_popup);
	}

	public void clickVideoTitleTier3() {
		visibilityWait(relatedvideoTitleTier3);
		javascriptScroll(relatedvideoTitleTier3);
		jsClick(relatedvideoTitleTier3);
		WaitForWebElement(library.getTitleDetailPage());
	}

	public void AdvanceSesarch_EnterInput(String keyword) {
		SendKeysOnWebElement(AdvancedSearch_input, keyword);
		waitFor(2000);
	}

	public void verify_crossIconInSearchbar(String keyword) {
		visibilityWait(AdvancedSearch_input);
		SendKeysOnWebElement(AdvancedSearch_input, keyword);
		visibilityWait(Searchinput_cleartxt);
		Assert.assertTrue(Searchinput_cleartxt.isDisplayed());

	}

	public void Click_Searchbtn() {
		visibilityWait(Search_btn);
		javascriptScroll(Search_btn);
		jsClick(Search_btn);
		waitFor(3000);
	}

	public void SearchKeyword_SearchREsults() {
		String text = SearchREsult_breadcrumb.getText();
		Assert.assertTrue(Search_Result.isDisplayed());
//		if (text.contains("Science")) {
//			Search_Result.isDisplayed();
//		}

	}

	public boolean view_jacketimgwithIcon() {
		boolean b = true;
		visibilityWait(vbooks_jacketimg);
		javascriptScroll(vbooks_jacketimg);
		Assert.assertTrue(vbooks_jacketimg.isDisplayed());
		visibilityWait(vbooks_icon);
		Assert.assertTrue(vbooks_icon.isDisplayed());
		return b;
	}

	public void ClickTitle_navDetailPage() {
		visibilityWait(vbooks_jacketimg);
		javascriptScroll(vbooks_jacketimg);
		jsClick(vbooks_jacketimg);
		visibilityWait(vbook.getLib_vbookCarousel_Nav_Tier3Detailspage());
		vbook.getLib_vbookCarousel_Nav_Tier3Detailspage().isDisplayed();

	}

	public void click_SeeAllCTA() {
		javascriptScroll(vbooks_SearchResult_SeeAll);
		jsClick(vbooks_SearchResult_SeeAll);
		// visibilityWait(vbooks_SearchResult_Tier2);

	}

	public void view_vbooksSearchResults() {
		visibilityWait(vbooks_Resources);
		javascriptScroll(vbooks_Resources);
		vbooks_Resources.isDisplayed();
		visibilityWait(AdvanceSearch_txt);
		//vbooks_SearchResult_Tire2_primaryCTA.isDisplayed();

	}

	public void verify_SortOrder_Relevence() {
		boolean b = true;
		visibilityWait(SearchREsult_breadcrumb);
		String text = SearchREsult_breadcrumb.getText();
		if (SearchREsult_breadcrumb.isDisplayed()) {
			System.out.println("user is able to view relevence title");
		}
//		String scienct_txt = text.substring(12, 19);
//		System.out.println(scienct_txt);
//		for (int i = 0; i < vbooks_SearchResult_Titlename.size(); i++) {
//			if (text == scienct_txt) {
//				b = true;
//				break;
//			}
//			Logger.log("user able to view sort order for the results based on relevance");
//		}
	}

	public void clickPopUpOk() {
		waitFor(2000);
		jsClick(popUpCheckoutokBtn);
	}

	public void click_vbooksInRefinerSection() {
		//javascriptScroll(vbooks_newspaper_Refiners);
		visibilityWait(vbooks_vbooks_Refiners);
		jsClick(vbooks_vbooks_Refiners);
		waitFor(2000);
	}

	public void view_CategoriesInRefiners() {
		vbooks_EbooksEAudio_Refiners.isDisplayed();
		vbooks_ActivityResources_Refiners.isDisplayed();
		vbooks_webResources_Refiners.isDisplayed();
		//javascriptScroll(vbooks_NewspaperMagazine_Refiners);
		//vbooks_NewspaperMagazine_Refiners.isDisplayed();
		videos_Refiners.isDisplayed();
		vbooks_vbooks_Refiners.isDisplayed();
	}

	public void clickCheckoutVBookLibPage() {
		if (isElementPresent(vbooks_LibPageCheckoutCta)) {
			javascriptScroll(vbooks_LibPageCheckoutCta);
			jsClick(vbooks_LibPageCheckoutCta);
			WaitForWebElement(success_msg);
		}else {
			javascriptScroll(library.returnCTA);
			jsClick(library.returnCTA);
			visibilityWait(return_confirmBtn);
			jsClick(return_confirmBtn);
			javascriptScroll(vbooks_LibPageCheckoutCta);
			jsClick(vbooks_LibPageCheckoutCta);
			WaitForWebElement(success_msg);
		}
		
	}
	
	public void verify_PlayCTA() {
	if (video.playButton.isDisplayed()) {
		javascriptScroll(video.playButton);
		Assert.assertTrue(video.playButton.isDisplayed());
		Assert.assertTrue(library.returnCTA.isDisplayed());
		Assert.assertTrue(library.renewCTA.isDisplayed());
	} else {
		javascriptScroll(library.returnCTA);
		jsClick(library.returnCTA);
		visibilityWait(return_confirmBtn);
		jsClick(return_confirmBtn);
		javascriptScroll(vbooks_LibPageCheckoutCta);
		jsClick(vbooks_LibPageCheckoutCta);
		visibilityWait(video.playButton);
		jsClick(video.playButton);
		Assert.assertTrue(video.playButton.isDisplayed());
		
	}

	}

	public void clickRenewCTA() {
		javascriptScroll(library.renewCTA);
		jsClick(library.renewCTA);
		visibilityWait(return_confirmBtn);
		jsClick(return_confirmBtn);
		WaitForWebElement(success_msg);
	}

	public void clickReturnCTA() {
		javascriptScroll(library.returnCTA);
		jsClick(library.returnCTA);
		visibilityWait(return_confirmBtn);
		jsClick(return_confirmBtn);
		WaitForWebElement(success_msg);
	}

	public void clickCheckoutVideoLibPage() {
		javascriptScroll(video_LibPageCheckoutCta.get(0));
		jsClick(video_LibPageCheckoutCta.get(0));
		WaitForWebElement(success_msg);
	}

	public void titleDetailSectionDisplayed() {
		if (isElementPresent(library.getTitleDetailSection())) {
			Logger.log("Title Detail section is displayed based on the API Response");
		} else {
			Logger.log("Title Detail section is not displayed based on the API Response");
		}
	}

	public void click_AllRefiner() {
		visibilityWait(vbooks_All_Refiners);
		jsClick(vbooks_All_Refiners);
		visibilityWait(othertype_ebookEAudio);
		if (isElementPresent(othertype_ebookEAudio)) {
			Logger.log(
					"user should be able to view other carousels along with vBooks carousel for other search criteria");
		}
	}

	public void searchTitle(String title) {
		WaitForWebElement(searchBar);
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, title);
		ClickOnWebElement(searchButton);
		WaitForWebElement(searchResult);
	}

	public void checkoutSearchResult() {
		javascriptScroll(checkOutSearchResult);
		jsClick(checkOutSearchResult);
		WaitForWebElement(popUpCheckout);
	}

	public void searchTitleInTeen() {
		String titleName = titleNameTire3.getText();
		waitFor(2000);
		login.click_HamburgerMenu();
		login.click_Profiles();
		login.select_Teenprofile();
		waitFor(2000);
		searchTitle(titleName);
	}

	public void Search_suggestedCarousel() {
		click_AdvanceSearch();
		visibilityWait(AdvancedSearch_input);
		waitFor(3000);
		click_videosInAdvancesearch();
		waitFor(2000);
		SendKeysOnWebElement(AdvancedSearch_input, "Desert Animals");
		waitFor(2000);
		Click_Searchbtn();
		javascriptScroll(TitleCard_search);
		jsClick(TitleCard_search);
		visibilityWait(video.titleDetailPage);
		video.verify_SuggestedCarousel();
	}

	public void verify_AdvancedSearchOptions(String options) {
		boolean b = true;
		for (int i = 0; i < AdvancedSearch_options.size(); i++) {
			if (AdvancedSearch_options.contains(options)) {
				b = true;
			}

		}

	}

	public void click_NewspaperOptionInAdvanceSearch() {
		WaitForWebElement(AdvanceSearch_Newspaper);
		ClickOnWebElement(AdvanceSearch_Newspaper);
	}

	public void click_NewspaperInAdvanceSearch(String format) {
		if (format.equalsIgnoreCase("Newspapers")) {
			visibilityWait(advanceSearch_Newspaper);
			waitFor(2000);
			jsClick(advanceSearch_Newspaper);
			waitFor(2000);
		} else if (format.equalsIgnoreCase("Magazines")) {
			visibilityWait(advanceSearch_Magazine);
			waitFor(2000);
			jsClick(advanceSearch_Magazine);
			waitFor(2000);
		} else if (format.equalsIgnoreCase("Articles")) {
			visibilityWait(advanceSearch_Article);
			waitFor(2000);
			jsClick(advanceSearch_Article);
			waitFor(2000);
		}

	}

	public void click_Articles() {
		waitFor(2000);
		jsClick(advanceSearch_Article);
		waitFor(2000);

	}

	public void verify_Allformats() {
		for (int i = 0; i < advanceSearch_thirdpartySearchResult_Allformats.size(); i++) {
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("eBooks")) {
				Assert.assertEquals(advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("eBooks"),
						true);
			}
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("eAudios")) {
				Assert.assertEquals(
						advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("eAudios"), true);
			}
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Newspapers ")) {
				Assert.assertEquals(
						advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Newspapers "), true);
			}
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Magazines ")) {
				Assert.assertEquals(
						advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Magazines "), true);
			}
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Resource Hub ")) {
				Assert.assertEquals(
						advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Resource Hub "),
						true);
			}
			if (advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Web Resources")) {
				Assert.assertEquals(
						advanceSearch_thirdpartySearchResult_Allformats.get(i).getText().contains("Web Resources"),
						true);
			}

		}

	}

	public void click_AdvanceSearchCTA() {
		javascriptScroll(Search_CTA);
		jsClick(Search_CTA);

	}

	public void click_Refineroptions() {
		ClickOnWebElement(format_eBook);
		visibilityWait(searchListRefiner);
		javascriptScroll(searchListRefiner);
		ClickOnWebElement(collection_dropdwn);
		visibilityWait(always_Available);
		ClickOnWebElement(always_Available);
		waitFor(2000);
		ClickOnWebElement(availability_dropdwn);
		visibilityWait(availablenow);
		ClickOnWebElement(availablenow);
		visibilityWait(pills_clearAll);
	}

	public void select_ResourceHub() {
		jsClick(Advancesearch_ResourceHub);
		waitFor(2000);
	}

	public void select_webResource() {
		jsClick(Advancesearch_WebResources);
		waitFor(2000);
	}

	public void select_Newspaper() {
		jsClick(Advancesearch_newspapers);
		waitFor(2000);
	}

	public void select_FortmatOptions(String FormatOptions) {
		switch (FormatOptions) {
		case "Newspapers":
			jsClick(Advancesearch_newspapers);
			waitFor(2000);
			break;
		case "Resource Hub":
			jsClick(Advancesearch_ResourceHub);
			waitFor(2000);
			break;
		case "Web Resources":
			jsClick(Advancesearch_WebResources);
			waitFor(2000);

			break;

//			Assert.assertEquals(grade1Name.contains(audienceType.getText()), true);
//			Assert.assertEquals(grade1Name.contains(ageRangeValue.getText()), true);
//			Assert.assertTrue(audienceType.isDisplayed());
//			Assert.assertTrue(ageRangeValue.isDisplayed());
		}
		Logger.log("Results are loaded based on the Age Range selected");

	}
	
	
	public void click_ISBN() {
		jsClick(Advancesearch_ISBN);
		waitFor(2000);
	}


	public int searchCountWithSeeAll() {
		String resultCount = searchCountNumber.getText();
		String extNumber = resultCount.replaceAll("[^0-9]", "");
		waitFor(2000);
		int count = Integer.parseInt(extNumber);
		return count;
	}

	
	public void click_VideoSeeAllCTA() {
		WaitForWebElement(Search_Result);
		if (isElementPresent(videos_SearchResult_SeeAll)) {
			waitFor(2000);
			jsClick(videos_SearchResult_SeeAll);
			visibilityWait(videos_SearchResult_Tier2);
		} else {
			Logger.log("Number of titles for the Search result displayed is lest than 10 Nos");
		}
	}
	

	

	public void lazyLoadValidation() {
		if (isElementPresent(tier2RefineHeader)) {
			waitFor(2000);
			int count = searchCountWithSeeAll();
			waitFor(2000);
			searchAssert(count);
		} else {
			waitFor(2000);
			int count = searchCountWithoutSeeAll();
			waitFor(2000);
			searchAssert(count);
		}
	}
	
	public void click_VBookSeeAllCTA() {
		WaitForWebElement(Search_Result);
		if (isElementPresent(vbooks_SearchResult_SeeAll)) {
			waitFor(2000);
			jsClick(vbooks_SearchResult_SeeAll);
			visibilityWait(vbooks_SearchResult_Tier2);
		} else {
			Logger.log("Number of titles for the Search result displayed is lest than 10 Nos");
		}
	}
	
	public void searchAssert(int count) {
		if (count <= 99) {
			for (int i = 0; i < 100; i++) {
				if (searchDisplayed.size() == count) {
					break;
				} else {
					javaScriptScrollToEnd();
					waitFor(6000);
					Logger.log("Titles Loaded " + searchDisplayed.size());
					Logger.log("Titles Search Result Count " + count);
					continue;
				}
			}
			Logger.log("Search results are loaded " + searchDisplayed.size());
			Logger.log("Titles Search Result Count " + count);
			Assert.assertEquals(searchDisplayed.size(), count);
		} else {
			Logger.log("More than 100 titles are loaded");
		}
	}
	public int searchCountWithoutSeeAll() {
		String resultCount = searchCountWithoutSeeAll.getText();
		String extNumber = resultCount.replaceAll("[^0-9]", "");
		waitFor(2000);
		int count = Integer.parseInt(extNumber);
		return count;
	}
	

	public void clickAgeRange() {
		javascriptScroll(ageRangeRef);
		jsClick(ageRangeRef);
		WaitForWebElement(ageRangeRefSec);
	}
	
	public void ageRangeValidation() {
		if (System.getProperty("browser").equalsIgnoreCase("android")) {
			Logger.log("Refiner options UI are as same as Mobile App");
		} else {
			clickAgeRange();
			String grade1Name = ageRangeSecGrade1.getText();
			waitFor(2000);
			jsClick(ageRangeSecGrade1);
			javascriptScroll(refSearchButton);
			jsClick(refSearchButton);
			inVisibilityWait(spinnerLoading);
			waitFor(2000);
			WaitForWebElement(searchDisplayed.get(0));
			ClickTitle_navDetailPage();
			javascriptScroll(audienceType);
			waitFor(2000);
			Assert.assertEquals(grade1Name.contains(audienceType.getText()), true);
			Assert.assertEquals(grade1Name.contains(ageRangeValue.getText()), true);
		}
		Logger.log("Results are loaded based on the Age Range selected");
	}
	
	public void select_AdvanceSearchType(String type) {
		switch (type) {
		
		case "ISBN":
			jsClick(Advancesearch_ISBN);
			waitFor(2000);
			break;

		case "Title":
			jsClick(Advancesearch_TITLE);
			waitFor(2000);
			break;
			
		case "Author":
			jsClick(Advancesearch_AUTHOR);
			waitFor(2000);
			break;		
		}

	}

}
