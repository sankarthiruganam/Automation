package pom.kidszone;

import java.io.IOException;

import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class SetUpParentPin extends CommonAction {
	static ExcelReader reader = new ExcelReader();

	public SetUpParentPin(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "lnkShowRegPwd")
	private WebElement link_adminpassowrd;

	@FindBy(id = "RegistrationPassword")
	private WebElement text_registrationpassword;

	@FindBy(xpath = "//button[contains(text(),'Register')]")
	private WebElement btn_tempRegister;

	@FindBy(xpath = "//img[@class='img-responsive']")
	private WebElement header_logo;

	@FindBy(id = "dialogHeadingRegister")
	private WebElement text_headingRegister;

	@FindBy(id = "RegisterModel_UserName")
	private WebElement textbox_userName;

	@FindBy(xpath = "//p[@class='kz-sub-text ng-star-inserted']")
	private WebElement reset_pinPage;

	@FindBy(xpath = "//button[contains(text(),'Register')]")
	private WebElement btn_Register;

	@FindBy(xpath = "//button[contains(text(),'Reset PIN')]")
	private WebElement btn_resetPin;

	@FindBy(xpath = "//p[contains(text(),'You entered the wrong PIN too many times. Please ')]")
	private WebElement txt_resetDescription;

	@FindBy(xpath = "//p[contains(text(),'Please answer the security question to reset your ')]")
	private WebElement txt_securityQuestion;

	@FindBy(xpath = "//input[contains(@placeholder,'Answer')]")
	private WebElement textbox_answerField;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	private WebElement btn_submit;

	@FindBy(xpath = "//p[contains(text(),'Please set up your Profile Management PIN. You wil')]")
	private WebElement txt_pinSetDescription;

	@FindBy(id = "loc_txtProfileManagementPin")
	private WebElement txt_profilePinHeading;

	public WebElement getTxt_profilePinHeading() {
		return txt_profilePinHeading;
	}

	public WebElement getText_headingRegister() {
		return text_headingRegister;
	}

	public WebElement getTxt_pinSetDescription() {
		return txt_pinSetDescription;
	}

	public WebElement getTxt_resetDescription() {
		return txt_resetDescription;
	}

	public WebElement getTxt_securityQuestion() {
		return txt_securityQuestion;
	}

	public WebElement getReset_pinPage() {
		return reset_pinPage;
	}

	/*****************************************
	 * Action methods
	 *****************************************************/

	public void click_AdminForPassword() {
		waitFor(2000);
		javascriptScroll(link_adminpassowrd);
		jsClick(link_adminpassowrd);
		//ClickOnWebElement(link_adminpassowrd);

	}

	public void enter_TempPassword(String password) {

		SendKeysOnWebElement(text_registrationpassword, password);

	}

	public void click_RegisterButton() {
		waitFor(2000);
		ClickOnWebElement(btn_tempRegister);

	}

	public void enter_UserName(String username) {
		waitFor(2000);
		SendKeysOnWebElement(textbox_userName, username + RandomStringGenerate());
	}

	public void click_ResetPin() {
		waitFor(2000);
		jsClick(btn_resetPin);
	}

	public void click_HeaderLogo() {
		waitFor(2000);
		ClickOnWebElement(header_logo);

	}

	public void enter_AnswerField() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "setpin");
		SendKeysOnWebElement(textbox_answerField, testData.get(0).get("securityAns"));
		waitFor(2000);

	}

	public void wrong_AnswerField() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "setpin");
		SendKeysOnWebElement(textbox_answerField, testData.get(0).get("securitywrongAns"));
		waitFor(2000);

	}

	public void click_SubmitButton() {
		waitFor(2000);
		jsClick(btn_submit);
		waitFor(4000);

	}

	public void texas_EnteruserName(String username) {
		SendKeysOnWebElement(textbox_userName, username);
	}

	public void texas_Enterpassword(String password) {
		SendKeysOnWebElement(textbox_userName, password);
	}
}
