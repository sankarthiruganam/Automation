package pom.kidszone;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Tier3_Videobooks extends CommonAction {
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();

	public Tier3_Videobooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//div[text()='Return'])[1]")
	public static WebElement tier1_secodaryCTA_return;

	@FindBy(xpath = "//div[text()='Renew']")
	public static WebElement tier3_RenewCTA;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement tier3_RenewOk;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement tier3_ReturnOk;

	@FindBy(xpath = "(//div[text()='Checkout'])[1]")
	public static WebElement tier3_CheckoutCTA;

	@FindBy(xpath = "(//div[@class='carousel-container'])[1]")
	public static WebElement tier3_suggestedCarousel;

	@FindBy(xpath = "//div[@class='ac-container ac-adaptiveCard']")
	public static List<WebElement> tier3_SuggestedTitedCard;

	@FindBy(xpath = "(//a[contains(text(),'See All')])[1]")
	public static WebElement tier3_SuggestCarousel_SeeAll;

	@FindBy(xpath = "//div[@class='thirdpartytiertwo-container ng-star-inserted']")
	public static WebElement Nav_tier2page;

	@FindBy(xpath = "(//h3[text()='Vbook Carousel ']/following::div[@class='ac-container ac-selectable'])[1]")
	private WebElement Lib_vbooktitleCatd;
	
	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	public static WebElement tier2_TitedCard;
	
	@FindBy(xpath = "(//div[@class='third-party-card-details third-party-videos-detail'])")
	public static WebElement tier3_Details;
	
	public void viewPlayCTA_afterRenewTitle() {
		visibilityWait(tier3_RenewCTA);
		javascriptScroll(tier3_RenewCTA);
		jsClick(tier3_RenewCTA);
		// ClickOnWebElement(tier3_RenewCTA);
		waitFor(2000);
		javascriptScroll(tier3_RenewOk);
		jsClick(tier3_RenewOk);
		visibilityWait(video.playButton);
		// WaitForWebElement(video.playButton);
		javascriptScroll(video.playButton);
		if (video.playButton.isDisplayed()) {
			Logger.log("user is able to view play CTA after renew the title");
			waitFor(2000);
		}
	}

	public void viewCheckoutCTA_afterReturnTitle() {
		waitFor(2000);
		javascriptScroll(tier1_secodaryCTA_return);
		jsClick(tier1_secodaryCTA_return);
		waitFor(2000);
		javascriptScroll(tier3_ReturnOk);
		jsClick(tier3_ReturnOk);
		WaitForWebElement(tier3_CheckoutCTA);
		javascriptScroll(tier3_CheckoutCTA);
		if (tier3_CheckoutCTA.isDisplayed()) {
			Logger.log("user is able to view play CTA after renew the title");
			waitFor(2000);
		}	
	}

	public void viewResumeCTA_afterRenewTitle() {
		waitFor(2000);
		javascriptScroll(tier3_RenewCTA);
		jsClick(tier3_RenewCTA);
		waitFor(2000);
		javascriptScroll(tier3_RenewOk);
		jsClick(tier3_RenewOk);
		WaitForWebElement(video.ResumeCta);
		javascriptScroll(video.ResumeCta);
		if (video.ResumeCta.isDisplayed()) {
			Logger.log("user is able to view play CTA after renew the title");
			waitFor(2000);
		}

	}

	public boolean view_SuggestedCarousel() {
		javaScriptScrollToEnd();
		boolean b = true;
		tier3_suggestedCarousel.isDisplayed();
		return b;
	}

	public void verify_SuggestedTitle() {
		visibilityWait(tier3_SuggestedTitedCard.get(1));
		// javascriptScroll(tier3_SuggestedTitedCard.get(1));
		tier3_SuggestedTitedCard.get(1).isDisplayed();
	}

	public void verify_morethen10Tittle_SeeAllCTA() {
		int size = tier3_SuggestedTitedCard.size();
		if (size >= 10) {
			visibilityWait(tier3_SuggestCarousel_SeeAll);
			Assert.assertTrue(tier3_SuggestCarousel_SeeAll.isDisplayed());
		} else {
			Logger.log("user is able to view less then 10 titles");
		}
	}

	public void click_SeeAllCTA_tier3() {
		if (tier3_SuggestCarousel_SeeAll.isDisplayed()) {
			visibilityWait(tier3_SuggestCarousel_SeeAll);
			jsClick(tier3_SuggestCarousel_SeeAll);
			// ClickOnWebElement(tier3_SuggestCarousel_SeeAll);
			visibilityWait(Nav_tier2page);
			Assert.assertTrue(Nav_tier2page.isDisplayed());
		} else {
			Logger.log("See All CTA is not displayed due to less then 10 titles");
		}
	}

	public void click_TitleCardTier1Vbook() {
		javascriptScroll(Lib_vbooktitleCatd);
		jsClick(Lib_vbooktitleCatd);
		WaitForWebElement(video.titleDetailPage);
	}

	public void clickCheckoutTier3() {
		javascriptScroll(tier3_CheckoutCTA);
		jsClick(tier3_CheckoutCTA);
		WaitForWebElement(video.playButton);
	}
	public void click_tier2TitleCard() {
		visibilityWait(tier2_TitedCard);
		jsClick(tier2_TitedCard);
		visibilityWait(video.titleDetailPage);
		
	}
}
