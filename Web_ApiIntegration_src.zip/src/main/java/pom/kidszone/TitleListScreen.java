
package pom.kidszone;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class TitleListScreen extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public TitleListScreen(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//h2[text()='Children']//following::a[contains(text(),'See all')])[1]")
	private WebElement seeAllCta_inChildrenCarousel;

	@FindBy(xpath = "//h2[text()='Children']")
	private WebElement children_carousel;

	@FindBy(id = "loc_dropdwnSort By")
	private WebElement sortDropdownOption;

	@FindBy(xpath = "//h2[contains(text(),'Refine')]")
	private WebElement refine_heading;

	@FindBy(xpath = "(//*[@class='ui-radiobutton-icon ui-clickable'])[1]")
	private WebElement radioBtn_returnDate;

	@FindBy(xpath = "//h2[@class='primary-para mb-1']")
	private WebElement validate_titleListPage;

	@FindBy(xpath = "//h2[text()='Sort By']")
	private WebElement sortOPtion_inRefine;

	@FindBy(xpath = "//label[contains(text(),'Return date')]")
	private WebElement returnDate_pill;

	@FindBy(xpath = "(//*[@class='count close-icon ng-star-inserted'])[2]")
	private WebElement closeIcon_pill;

	@FindBy(id = "loc_dropdwnFormat")
	public static WebElement formatDropdownOption;

	@FindBy(xpath = "(//*[@class='ui-radiobutton-icon ui-clickable'])[6]")
	private WebElement radioBtn_eBook;

	@FindBy(id = "loc_labelClear All")
	private WebElement Btn_clearAllCta;

	@FindBy(xpath = "(//*[@class='title-card ng-star-inserted'])[1]")
	private WebElement Btn_firstTitle;

	@FindBy(xpath = "//div[contains(text(),'Details')]")
	private WebElement validate_titleDetailspage;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement Btn_navigate_backTo_titleList;

	@FindBy(id = "loc_txtyoung_adult_fiction")
	private WebElement Btn_fiction_from_browse;

	@FindBy(id = "loc_txtACTION & ADVENTURE")
	private WebElement Btn_actionAndAdventure;

	@FindBy(xpath = "//*[contains(text(),'TOP 20')]")
	private WebElement Top20Cta;

	@FindBy(xpath = "//*[contains(text(),'MORE FICTION TYPE')]")
	private WebElement moreTypeCta;

	@FindBy(xpath = "//h2[contains(text(),'Collections')]")
	private WebElement collections_inRefine;

	@FindBy(id = "loc_dropdwnCollections")
	private WebElement collections_dropdown;

	@FindBy(xpath = "//label[text()='Purchase Request']")
	private WebElement radioBtn_titlesToRecommend;

	@FindBy(xpath = "//div[contains(text(),'More Like This')]")
	private WebElement link_MoreLikethis;

	@FindBy(xpath = "//h1[text()='Titles Like This']")
	private WebElement level3_title;

	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private List<WebElement> level3_titles;

	@FindBy(xpath = "((//*[@class='kz-custom-container-secondary'])[1]//following::*[contains(text(),'See all')])[1]")
	private WebElement link_libSeeAll;

	@FindBy(xpath = "//h2[text()='Children']//following-sibling::button[text()=' SEE ALL ']")
	private WebElement old_seeAllLib;

	@FindBy(xpath = "(//*[@class='title-list-container'])")
	private WebElement titleList_level1subject;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement nav_TitleListScreen;

	@FindBy(xpath = "//h2[text()='featured lists ']")
	private WebElement txt_TitleListScreen;

	@FindBy(id = "loc_txtAvailability")
	private WebElement Nav_libraryScreen;

	@FindBy(xpath = "//h2[contains(text(),'Children')]")
	private WebElement titleList_old;

	@FindBy(xpath = "//h2[text()='Goals & Insights']")
	private WebElement old_Nav_libraryScreen;

	@FindBy(xpath = "//div[@class='mylib-category-header']")
	private WebElement Alwaysavailable_titleList_old;

	@FindBy(xpath = "//h2[text()='Newspapers & Magazines']")
	private WebElement NavbacktitleList_old;

	@FindBy(xpath = "(//*[@class='title-list-container'])//following::h2[contains(text(),'results')]")
	public static WebElement level1_numberofResults;

	@FindBy(xpath = "(//axis360-title-card[@class='title-card ng-star-inserted'])[1]")
	private WebElement title_gridview;

	@FindBy(xpath = "//axis360-title-card[@class='title-card ng-star-inserted']")
	private List<WebElement> level1_titles;

	@FindBy(xpath = "//h2[contains(text(),'Refine')]")
	private WebElement txt_refinesection;

	@FindBy(xpath = "(//*[contains(text(),'featured lists')]//following::*[@role='region'])[1]")
	private WebElement categeorySection_level1;

	@FindBy(xpath = "//*[@class='title-details-info']")
	private WebElement expendAndcollepse;

	@FindBy(id = "loc_linkBrowserBySubject")
	private WebElement navigationMenu_btn_browseBySubject;

	@FindBy(id = "loc_radiobtnPublication Date")
	public static WebElement drop_sortBy;

	@FindBy(xpath = "//div[@class='accordion-content ng-star-inserted']")
	public static WebElement view_sortOption;

	@FindBy(xpath = "//div[@class='ui-radiobutton ui-widget']")
	public static List<WebElement> sort_radioButton;

	@FindBy(xpath = "//mat-expansion-panel-header[@role='button']")
	private List<WebElement> refineSection;

	@FindBy(xpath = "//h1[@class='heading-1 text-capitalize']")
	private WebElement header_level1Subject;

	@FindBy(xpath = "//div[@class='mat-tab-links']")
	public static WebElement header_filteroptions;

	@FindBy(xpath = "//*[@class='breadcrumb kz-breadcrumb']")
	public static WebElement breadcrumb_titleList;

	@FindBy(xpath = "//h2[@class='primary-para mb-1']")
	private WebElement level2_titleList;

	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private List<WebElement> libPage_titlecard;

	@FindBy(xpath = "//axis360-home-my-library-list-card[@class='ng-star-inserted']")
	private List<WebElement> oldlibPage_titlecard;

	@FindBy(id = "loc_txtAvailability")
	private WebElement txt_NavlibraryScreen;

	@FindBy(xpath = "//label[@for='loc_txtYOUNG ADULT NONFICTION-input']")
	private WebElement adultFictionFromBrowse;

	@FindBy(xpath = "//label[@for='loc_txtYOUNG ADULT FICTION-input']")
	private WebElement teenFictionFromBrowse;

	@FindBy(id = "loc_txtjuvenile_fiction")
	private WebElement kidFictionFromBrowse;

	@FindBy(xpath = "(//*[@svgicon='kz-filter-down-arrow'])[2]")
	private WebElement formatDropdown;

	@FindBy(xpath = "//*[contains(text(),' eBook ')]")
	private WebElement eBook;

	@FindBy(xpath = "//*[@class='primary-action ng-star-inserted']")
	private List<WebElement> primaryCTA;

	@FindBy(xpath = "(//*[@class='featured-carousel']//*[@class='kz-card-image ng-star-inserted'])[1]")
	private WebElement eBookTitles;

	@FindBy(xpath = "//div[text()='Related Items']")
	private WebElement link_Recommendationitems;

	@FindBy(xpath = "//div[text()='Details']")
	public static WebElement link_Details;

	@FindBy(xpath = "//h1[@class='primary-heading-1 ng-star-inserted']")
	private WebElement title_details_screen;

	@FindBy(xpath = "//div[@class='wrapper']")
	public static WebElement old_titleDetails;
	
	@FindBy(id = "loc_dropdwnRecently Added")
	public static WebElement recentlyAdded_option;
	
	@FindBy(xpath = "( //*[contains(text(),'Available Now ')])[1]")
	public static WebElement availableNowOption;
	
	@FindBy(id = "loc_dropdwnAvailability")
	public static WebElement availabilityOption_underFilter;
	
	@FindBy(id = "loc_labelAvailable Now")
	public static WebElement availableNow_pill;
	
	@FindBy(xpath = "//div[@class='title-list-sec ng-star-inserted']")
	public static WebElement results_browse;
	
	@FindBy(xpath = "(//mat-expansion-panel-header[@role='button'])[1]")
	public static WebElement expansion_sort;

	public WebElement getTitle_details_screen() {
		return title_details_screen;
	}

	public WebElement getTeenFictionFromBrowse() {
		return teenFictionFromBrowse;
	}

	public WebElement getKidFictionFromBrowse() {
		return kidFictionFromBrowse;
	}

	public WebElement getNav_libraryScreen() {
		return Nav_libraryScreen;
	}

	public WebElement getAlwaysavailable_titleList_old() {
		return Alwaysavailable_titleList_old;
	}

	public WebElement getHeader_level1Subject() {
		return header_level1Subject;
	}

	public WebElement getTxt_refinesection() {
		return txt_refinesection;
	}

	public WebElement getExpendAndcollepse() {
		return expendAndcollepse;
	}

	public WebElement getOld_Nav_libraryScreen() {
		return old_Nav_libraryScreen;
	}

	public WebElement getCategeorySection_level1() {
		return categeorySection_level1;
	}

	public WebElement getTitle_gridview() {
		return title_gridview;
	}

	public WebElement getTitleList_level1subject() {
		return titleList_level1subject;
	}

	public WebElement getTxt_TitleListScreen() {
		return txt_TitleListScreen;
	}

	public WebElement getTitleList_old() {
		return titleList_old;
	}

	public WebElement getLink_libSeeAll() {
		return link_libSeeAll;
	}

	public WebElement getNav_TitleListScreen() {
		return nav_TitleListScreen;
	}

	public WebElement getCollections_inRefine() {
		return collections_inRefine;
	}

	public WebElement getCollections_dropdown() {
		return collections_dropdown;
	}

	public WebElement getRadioBtn_titlesToRecommend() {
		return radioBtn_titlesToRecommend;
	}

	public WebElement getMoreTypeCta() {
		return moreTypeCta;
	}

	public WebElement getTop20Cta() {
		return Top20Cta;
	}

	public WebElement getBtn_actionAndAdventure() {
		return Btn_actionAndAdventure;
	}

	public WebElement getBtn_fiction_from_browse() {
		return Btn_fiction_from_browse;
	}

	public WebElement getBtn_navigate_backTo_titleList() {
		return Btn_navigate_backTo_titleList;
	}

	public WebElement getValidate_titleDetailspage() {
		return validate_titleDetailspage;
	}

	public WebElement getBtn_firstTitle() {
		return Btn_firstTitle;
	}

	public WebElement getBtn_clearAllCta() {
		return Btn_clearAllCta;
	}

	public WebElement getRadioBtn_eBook() {
		return radioBtn_eBook;
	}

	public WebElement getFormatDropdownOption() {
		return formatDropdownOption;
	}

	public WebElement getCloseIcon_pill() {
		return closeIcon_pill;
	}

	public WebElement getReturnDate_pill() {
		return returnDate_pill;
	}

	public WebElement getSortOPtion_inRefine() {
		return sortOPtion_inRefine;
	}

	public WebElement getValidate_titleListPage() {
		return validate_titleListPage;
	}

	public WebElement getRadioBtn_returnDate() {
		return radioBtn_returnDate;
	}

	public WebElement getRefine_heading() {
		return refine_heading;
	}

	public WebElement getChildren_carousel() {
		return children_carousel;
	}

	public WebElement getSortDropdownOption() {
		return sortDropdownOption;
	}

	public WebElement getSeeAllCta_inChildrenCarousel() {
		return seeAllCta_inChildrenCarousel;
	}

	/**********************************
	 * Action methods
	 *********************************************/

	public void click_seeAllCtaInChildrenCarousel() {
		javascriptScroll(children_carousel);
		jsClick(seeAllCta_inChildrenCarousel);

	}

	public void addFilterOptionsInRefine() {
		javascriptScroll(refine_heading);
		jsClick(sortDropdownOption);
		WaitForWebElement(radioBtn_returnDate);
		jsClick(radioBtn_returnDate);
		jsClick(formatDropdownOption);
		jsClick(radioBtn_eBook);
	}

	public void click_closeIconInPills() {
		WaitForWebElement(closeIcon_pill);
		jsClick(closeIcon_pill);

	}

	public void click_clearAllCta() {
		WaitForWebElement(Btn_clearAllCta);
		jsClick(Btn_clearAllCta);
	}

	public void click_title_inTitlelist() {
		// javascriptScroll(Btn_firstTitle);
		javascriptScroll(Btn_firstTitle);
		WaitForWebElement(Btn_firstTitle);
		jsClick(libPage_titlecard.get(0));
		waitFor(2000);
	}

	public void navigateBackToTitleListScreen() {
//         WaitForWebElement(Btn_navigate_backTo_titleList);
//         ClickOnWebElement(Btn_navigate_backTo_titleList);
		DriverManager.getDriver().navigate().back();
		waitFor(2000);
	}

	public void viewAllRefinersReset() {
		WaitForWebElement(refine_heading);
		javascriptScroll(refine_heading);
	}

	public void click_fictionOption() {
		if (isElementPresent(Btn_fiction_from_browse)) {
			ClickOnWebElement(Btn_fiction_from_browse);
		} else {
			WaitForWebElement(teenFictionFromBrowse);
			ClickOnWebElement(teenFictionFromBrowse);
		}
	}

	public void click_Adultfiction() {
		if (isElementPresent(adultFictionFromBrowse)) {
			jsClick(adultFictionFromBrowse);
		} else {
			WaitForWebElement(teenFictionFromBrowse);
			jsClick(teenFictionFromBrowse);
		}
	}

	public void click_ActionAndAdventure() {
		waitFor(6000);
		javascriptScroll(Btn_actionAndAdventure);
		jsClick(Btn_actionAndAdventure);
	}

	public void scrollToTop20() {
		javascriptScroll(Top20Cta);
	}

	public void ScrollToMoreType() {
		javascriptScroll(moreTypeCta);
	}

	public void ScrollToCollections() {
		javascriptScroll(collections_inRefine);
		waitFor(2000);
		jsClick(collections_dropdown);
	}

	public void clickTitlesToRecommend() {
		WaitForWebElement(radioBtn_titlesToRecommend);
		jsClick(radioBtn_titlesToRecommend);
		waitFor(2000);
	}

	public void select_morelikethisLink() {
		javascriptScroll(link_MoreLikethis);
		jsClick(link_MoreLikethis);
		waitFor(2000);
		// WaitForWebElement(level3_title);
		// ClickOnWebElement(level3_titles.get(0));
	}

	public void click_LibseeAllNavigateTileList() {
		javascriptScroll(link_libSeeAll);
		jsClick(link_libSeeAll);
		waitFor(2000);
		WaitForWebElement(nav_TitleListScreen);
	}

	public void clickseeAllCTA_carousel() {
		javascriptScroll(link_libSeeAll);
		jsClick(link_libSeeAll);
	}

	public void clickoldseeAllCTA_carousel() {
		javascriptScroll(old_seeAllLib);
		jsClick(old_seeAllLib);
	}

	public void clickSeeAll_curatedList() {
		javascriptScroll(link_libSeeAll);
		WaitForWebElement(link_libSeeAll);
		jsClick(link_libSeeAll);
	}

	public void click_oldSeeAll() {
		javascriptScroll(old_seeAllLib);
		jsClick(old_seeAllLib);
		// ClickOnWebElement(old_seeAllLib.get(2));

	}

	public void navigateBackto_LibScreen() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(Nav_libraryScreen);

	}

	public void numberOf_Results() {
		scrollingup(titleList_level1subject);
		isElementPresent(titleList_level1subject);

	}

	public void navigateBack_homeOld() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(NavbacktitleList_old);
		isElementPresent(NavbacktitleList_old);
	}

	public void verify_tenTitles() {
		visibilityWait(level1_titles.get(0));
		javascriptScroll(level1_titles.get(0));
		// scrollingup(level1_titles.get(0));
		for (int i = 0; i < level1_titles.size(); i++) {
			if (i >= 10) {
				isElementPresent(level1_titles.get(i));
			}
		}

	}

	public void verify_RefineSection() {
		javascriptScroll(txt_refinesection);
		isElementPresent(txt_refinesection);
	}

	public void verify_defaultExpendedoption() {

		// scrollingup(expendAndcollepse);
		jsClick(expendAndcollepse);
		System.out.println("user is able to view category section collapsed by default ");
		waitFor(2000);
		jsClick(expendAndcollepse);
		System.out.println("user is able to view category section filter option expendend by default ");
	}

	public void click_level3Subject() {
		WaitForWebElement(level1_titles.get(0));
		jsClick(level1_titles.get(0));
		// ClickOnWebElement(level1_titles.get(0));
		waitFor(2000);
	}

	public void select_returnDate() {
		javascriptScroll(returnDate_pill);
		waitFor(2000);
		jsClick(returnDate_pill);
		waitFor(2000);
	}

	public void select_sortBy() {
		javascriptScroll(drop_sortBy);
		jsClick(drop_sortBy);
		waitFor(3000);
	}

	public void sortBy_expandAndCollepse() {
		jsClick(expansion_sort);
		isElementPresent(expansion_sort);
		Logger.log("user is able to view the default expand the sort option");
		visibilityWait(expansion_sort);
		jsClick(expansion_sort);
		Logger.log("user is able to view the collepse the sort option");
	}

	public void sortBy_addedDate() {
		javascriptScroll(drop_sortBy);
		jsClick(drop_sortBy);
		WaitForWebElement(sort_radioButton.get(3));
		if (!sort_radioButton.get(3).isSelected()) {
			javascriptScroll(sort_radioButton.get(3));
			System.out.println(sort_radioButton.size());
			jsClick(sort_radioButton.get(3));
		}
	}

	public void selectsortBy_Author() {
//		WaitForWebElement(drop_sortBy);
//		javascriptScroll(drop_sortBy);
//		jsClick(drop_sortBy);
		// ClickOnWebElement(drop_sortBy);
		// WaitForWebElement(sort_radioButton.get(5));
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			jsClick(sort_radioButton.get(2));
		} else {
			waitFor(2000);
			if (!sort_radioButton.get(2).isSelected()) {
				jsClick(sort_radioButton.get(2));
			}
		}
	}

	public void selectsortBy_popularity() {
		// scrollingup(drop_sortBy);
		visibilityWait(drop_sortBy);
		javascriptScroll(drop_sortBy);
		jsClick(drop_sortBy);
		// ClickOnWebElement(drop_sortBy);
		// WaitForWebElement(sort_radioButton.get(1));
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			jsClick(sort_radioButton.get(1));
		} else {
			waitFor(2000);
			if (!sort_radioButton.get(1).isSelected()) {
				jsClick(sort_radioButton.get(1));
			}
		}
	}

	public void selectsortBy_ReturnDate() {
		visibilityWait(drop_sortBy);
		javascriptScroll(drop_sortBy);
		jsClick(drop_sortBy);
		WaitForWebElement(sort_radioButton.get(0));
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			jsClick(sort_radioButton.get(0));
		} else {
			waitFor(2000);
			if (!sort_radioButton.get(0).isSelected()) {
				jsClick(sort_radioButton.get(0));
			}
		}
	}

	public void selectsortBy_Title() {
		javascriptScroll(drop_sortBy);
		jsClick(drop_sortBy);
		WaitForWebElement(sort_radioButton.get(4));
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			jsClick(sort_radioButton.get(4));
		} else {
			waitFor(2000);
			if (!sort_radioButton.get(4).isSelected()) {
				jsClick(sort_radioButton.get(4));
			}
		}
	}

	public void view_refineSections() {
		for (int i = 0; i < refineSection.size(); i++) {
			isElementPresent(refineSection.get(i));
		}
		Logger.log("user is able to view the refine options for the titles list");
	}

	public void select_eachRefineOptions() {
		javascriptScroll(refineSection.get(6));
		for (int i = 0; i < refineSection.size(); i++) {
			jsClick(refineSection.get(i));
		}

	}

	public boolean verify_ageLevel() {
		boolean b = true;
		javascriptScroll(refineSection.get(5));
		isElementPresent(refineSection.get(5));
		return b;

	}

	public void level2Subject_numberofResults() {
		javascriptScroll(level2_titleList);
		// scrollingup(level2_titleList);
		isElementPresent(level2_titleList);

	}

	public void click_titleCard() {
		WaitForWebElement(libPage_titlecard.get(0));
		jsClick(libPage_titlecard.get(0));
		WaitForWebElement(title_details_screen);
	}

	public void old_titleCard() {
		javascriptScroll(oldlibPage_titlecard.get(1));
		waitFor(2000);
		ClickOnWebElement(oldlibPage_titlecard.get(1));
		// jsClick(oldlibPage_titlecard.get(0));
		// WaitForWebElement(old_titleDetails);
		waitFor(3000);
	}

	public void click_teen_Fiction() {
		ClickOnWebElement(teenFictionFromBrowse);

	}

	public void click_kid_Fiction() {
		ClickOnWebElement(kidFictionFromBrowse);
	}

	public boolean view_moreLikeThisAndReleateditems() {
		javascriptScroll(link_Details);
		waitFor(2000);
		boolean b = true;
		isElementPresent(link_MoreLikethis);
		isElementPresent(link_Recommendationitems);
		isElementPresent(link_Details);
		return b;

	}

	public void click_Releateditems() {
		waitFor(2000);
		jsClick(link_Recommendationitems);
		waitFor(2000);
	}

	public void click_details() {
		waitFor(2000);
		jsClick(link_Details);
		waitFor(2000);
	}

	public void validate_title_details_screen() {
		if (isElementPresent(Btn_navigate_backTo_titleList)) {
			Assert.assertTrue(Btn_navigate_backTo_titleList.isDisplayed());

		} else {
			WaitForWebElement(title_details_screen);
			Assert.assertTrue(title_details_screen.isDisplayed());
		}
	}

	public boolean view_titleCardold() {
		visibilityWait(old_titleDetails);
		boolean b = true;
		isElementPresent(old_titleDetails);
		return b;

	}

}
