package parallel;

import java.util.List;
import java.util.Map;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Milestone;
import pom.kidszone.Milestone_edit;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.Profile;
import pom.kidszone.SearchResults_Vbooks;

import org.junit.Assert;

public class Milestone_Edit_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	Milestone milestone = new Milestone(DriverManager.getDriver());
	Milestone_edit milestone_edit = new Milestone_edit(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	Profile old = new Profile(DriverManager.getDriver());

	/*******************************************************/
	
	@Given("user joins a upcoming program from open program section which have milestone program type")
	public void user_joins_a_upcoming_program_from_open_program_section_which_have_milestone_program_type() {
		milestone_edit.click_joinedUpcomingprogram();
	}

	@Given("user should be navigates to program details screen")
	public void user_should_be_navigates_to_program_details_screen() {
	  visibilityWait(milestone.Nav_TitleDetails);
	  Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	  waitFor(2000);
	}

	@When("user select the {string} option in a program detail page")
	public void user_select_the_option_in_a_program_detail_page(String string) {
	   milestone_edit.click_AddaTitle();
	}

	@Then("user should be able to view a modal with options to {string} and {string}")
	public void user_should_be_able_to_view_a_modal_with_options_to_and(String string, String string2) {
		visibilityWait(milestone_edit.popup_SearchyourLibrary);
	   Assert.assertTrue(milestone_edit.popup_SearchyourLibrary.isDisplayed());
	   Assert.assertTrue(milestone_edit.popup_AddyourownTitle.isDisplayed());
	}

	@Then("user select {string} option")
	public void user_select_option(String string) {
	   milestone_edit.select_SearchyourLibrary();
	}

	@Then("user should be redirected to advance search screen and view search bar and various filtering option with existing functionality")
	public void user_should_be_redirected_to_advance_search_screen_and_view_search_bar_and_various_filtering_option_with_existing_functionality() {
	   visibilityWait(search.AdvancedSearch_popup);
	   Assert.assertTrue(search.AdvancedSearch_popup.isDisplayed());
	}

	@Then("user enters the keyword {string}")
	public void user_enters_the_keyword(String keyword) {
		 search.AdvanceSesarch_EnterInput(keyword);
	}

	@Then("user should be able to view clear  CTA once they enter the keyword")
	public void user_should_be_able_to_view_clear_cta_once_they_enter_the_keyword() {
		javascriptScroll(milestone_edit.Search_Clear);
	    Assert.assertTrue(milestone_edit.Search_Clear.isDisplayed());
	}

	@Then("user should be able to view search CTA once they enter the keyword")
	public void user_should_be_able_to_view_search_cta_once_they_enter_the_keyword() {
		 Assert.assertTrue(milestone_edit.AdvancedSearch_Search.isDisplayed());
	}
	
	@Then("user should be redirected to advance search screen and user enters the keyword {string}")
	public void user_should_be_redirected_to_advance_search_screen_and_user_enters_the_keyword(String keyword) {
		 visibilityWait(search.AdvancedSearch_popup);
		 search.AdvanceSesarch_EnterInput(keyword);
		 //milestone_edit.click_searchCTA();
	}

	@Then("user should initiated the search and navigates to search results screen")
	public void user_should_initiated_the_search_and_navigates_to_search_results_screen() {
		 milestone_edit.click_searchCTA();
	   visibilityWait(milestone_edit.SearchResults_Screen);
	   Assert.assertEquals(milestone_edit.SearchResults_Screen.isDisplayed(), true);
	}

	@Then("user should able to view add title option")
	public void user_should_able_to_view_add_title_option() {
	   Assert.assertTrue(milestone_edit.SearchResults_AddaTitle.isDisplayed());
	}

	@Then("user should able to have option to add titles one at a time and cant add titles in bulk")
	public void user_should_able_to_have_option_to_add_titles_one_at_a_time_and_cant_add_titles_in_bulk() {
		milestone_edit.SearchResult_AddaTitles();
	}

	@Then("user should able to view titles from all existing formats such as eBook and eAudio and Video etc")
	public void user_should_able_to_view_titles_from_all_existing_formats_such_as_e_book_and_e_audio_and_video_etc() {
	   Assert.assertTrue(milestone_edit.Titles_Formats.isDisplayed());
	}

	@Then("user should able to view and click the title added option to add the title from keyword search result page into the program details page")
	public void user_should_able_to_view_and_click_the_title_added_option_to_add_the_title_from_keyword_search_result_page_into_the_program_details_page() {
		Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	}
	@Then("user should be able to view cancel icon to close the advance search page and go back to program details page")
	public void user_should_be_able_to_view_cancel_icon_to_close_the_advance_search_page_and_go_back_to_program_details_page() {
	   milestone_edit.Click_CloseIcon_NavprogramDetails();
	}
	
	@Then("user should be able to view filter option in keyword search result page")
	public void user_should_be_able_to_view_filter_option_in_keyword_search_result_page() {
	   Assert.assertTrue(milestone_edit.SearchResults_Filter.isDisplayed());
	}

	@Then("user should be able to filter the titles with existing functionality")
	public void user_should_be_able_to_filter_the_titles_with_existing_functionality() {
	   Logger.log("user should be able to filter the titles with existing functionality");
	}
	
	@Then("user should able to select {string} option")
	public void user_should_able_to_select_option(String string) {
	   milestone_edit.click_AddyourownTitles();
	}

	@Then("user should able to redirect to add a title screen once select the {string} option")
	public void user_should_able_to_redirect_to_add_a_title_screen_once_select_the_option(String string) {
	   visibilityWait(milestone_edit.own_title_page);
	   
	}
	
	@Given("user joins a milestone program from open program section")
	public void user_joins_a_milestone_program_from_open_program_section() {
	   milestone_edit.click_ActiveProgram();
	}

	@When("user should be able to view titles for that program in the details screen")
	public void user_should_be_able_to_view_titles_for_that_program_in_the_details_screen() {
		visibilityWait(milestone.Nav_TitleDetails);
		Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	}

	@Then("user should be able to view titles have a progress bar for each title added from library")
	public void user_should_be_able_to_view_titles_have_a_progress_bar_for_each_title_added_from_library() {
	   milestone_edit.view_progressforEachTitles();
	}

	@Then("user should be able to view CTAs from the last know status such as {string} but when the status is on {string} the progress bar should be {int}%")
	public void user_should_be_able_to_view_ct_as_from_the_last_know_status_such_as_but_when_the_status_is_on_the_progress_bar_should_be(String ctaStatus, String string2, Integer int1) {
		milestone_edit.view_ProgressforCheckoutCTA(ctaStatus);
	}
	
	@Then("user should be able to view {string} cta which will have option to add to Wishlist when they go to the title details page")
	public void user_should_be_able_to_view_cta_which_will_have_option_to_add_to_wishlist_when_they_go_to_the_title_details_page(String ctaStatus) {
		milestone_edit.view_ProgressforCheckoutCTA(ctaStatus);
	}
	
	@Given("user joins a milestine upcoming program from open program section")
	public void user_joins_a_milestine_upcoming_program_from_open_program_section() {
	    
	}

	@Then("user should be able to view a modal with option to {string} and {string}")
	public void user_should_be_able_to_view_a_modal_with_option_to_and(String string, String string2) {
	   
	}

	@Then("user should be able to select {string} option")
	public void user_should_be_able_to_select_option(String string) {
	   
	}

	@Then("user should be able to view the {string}")
	public void user_should_be_able_to_view_the(String string) {
	   Assert.assertTrue(old.profilePin_popup.isDisplayed());
	}

	@Then("user enter the mandatory and optional fields on search")
	public void user_enter_the_mandatory_and_optional_fields_on_search() {
	  
	}

	@Then("user tap on the {string} cta")
	public void user_tap_on_the_cta(String string) {
	  
	}

	@Then("user should be able to view the added title in the program in the details screen")
	public void user_should_be_able_to_view_the_added_title_in_the_program_in_the_details_screen() {
	    
	}

	@Then("user should be able to view external titles with either Mark as done")
	public void user_should_be_able_to_view_external_titles_with_either_mark_as_done() {
	   Assert.assertTrue(milestone_edit.MarkAsDone_CTA.isDisplayed());
	}

	@Then("user should be able to view progress as {int} % if user selected {string} option when creating the title and the primary CTA as {string}")
	public void user_should_be_able_to_view_progress_as_if_user_selected_option_when_creating_the_title_and_the_primary_cta_as(Integer int1, String string, String string2) {
	  if (milestone_edit.MarkAsNotDone_CTA.isDisplayed()) {
		Assert.assertTrue(milestone_edit.Title_progress.get(0).isDisplayed());
	}
	}

	@Then("user should be able to switch the completion status as many times as they want as long as the maximum title list is not fully completed")
	public void user_should_be_able_to_switch_the_completion_status_as_many_times_as_they_want_as_long_as_the_maximum_title_list_is_not_fully_completed() {
	   
	}

	@Then("user should be able to view external titles with Mark as not done progress")
	public void user_should_be_able_to_view_external_titles_with_mark_as_not_done_progress() {
	  Assert.assertTrue(milestone_edit.MarkAsNotDone_CTA.isDisplayed());
	}

	@Then("user should be able to view progress as {int} % if user  DID NOT select {string} option when creating the title and should see the primary CTA as {string}")
	public void user_should_be_able_to_view_progress_as_if_user_did_not_select_option_when_creating_the_title_and_should_see_the_primary_cta_as(Integer int1, String string, String string2) {
	  
	}
	
	//169950
	

	@Given("user joins a milestone program type and completed program")
	public void user_joins_a_milestone_program_type_and_completed_program() {
	   milestone_edit.click_completedprog();
	}

	@When("user finished reading all titles added by them as per the milestone that means maximum number of titles to read")
	public void user_finished_reading_all_titles_added_by_them_as_per_the_milestone_that_means_maximum_number_of_titles_to_read() {
	   javascriptScroll(milestone_edit.Reading_AllTitles);
		milestone_edit.Reading_AllTitles.isDisplayed();
	}

	@Then("user should be able to view the program as completed")
	public void user_should_be_able_to_view_the_program_as_completed() {
	   Assert.assertTrue(milestone_edit.view_programAs_completed.isDisplayed());
	}

	@Then("user should not be able to make any further edits such as add a title or delete an existing titles from the list")
	public void user_should_not_be_able_to_make_any_further_edits_such_as_add_a_title_or_delete_an_existing_titles_from_the_list() {
	    visibilityWait(milestone_edit.Titledetails_EditReadigList);
		Assert.assertTrue(milestone_edit.Titledetails_EditReadigList.isDisplayed());
	}

	@Given("user should be navigates to my stuff page")
	public void user_should_be_navigates_to_my_stuff_page() {
		login.click_HamburgerMenu();
		login.click_Myshelf();
	}

	@Then("user should be able to view the badges associated with that milestone program in their my stuff page")
	public void user_should_be_able_to_view_the_badges_associated_with_that_milestone_program_in_their_my_stuff_page() {
		milestone_edit.verify_programCompletedBadge();
	}

	
	@Then("user should be able to view completed status on the program details as example {int} of {int} books")
	public void user_should_be_able_to_view_completed_status_on_the_program_details_as_example_of_books(Integer int1, Integer int2) {
	   Assert.assertEquals(milestone_edit.Title_Completed_Status.getText().equalsIgnoreCase("1 of 1 Titles"), true);
	}

	@Given("user switch to teen profile in manage profile section and user select the program tab")
	public void user_switch_to_teen_profile_in_manage_profile_section_and_user_select_the_program_tab() {
	   
	}

	@Given("user switch to adult profile in manage profile section and user select the program tab")
	public void user_switch_to_adult_profile_in_manage_profile_section_and_user_select_the_program_tab() {
	  
	}
	
	@Then("user should be redirected to add a title screen")
	public void user_should_be_redirected_to_add_a_title_screen() {
		Assert.assertTrue(milestone_edit.own_title_page.isDisplayed());
		waitFor(3000);
	}

	@Then("user should be able to view title name as mandatory")
	public void user_should_be_able_to_view_title_name_as_mandatory() {
		boolean b=true;
		Assert.assertTrue(isElementPresent(milestone_edit.own_title_TitleName_Mandatory));
		if (isElementPresent(milestone_edit.own_title_TitleName)) {
			waitFor(2000);
			ClickOnWebElement(milestone_edit.own_title_TitleName);
			SendKeysOnWebElement(milestone_edit.own_title_TitleName, "Success Story"+RandomStringGenerate());
			waitFor(2000);
			b=true;
		} else {
			b=false;
		}
	   
	}

	@Then("user should be able to view authors name as optional")
	public void user_should_be_able_to_view_authors_name_as_optional() {
		milestone_edit.Verify_authorNameOptional();
	}

	@Then("user should be able to view title type as mandatory field and listed as dropdown with options eBook\\/Print Book and eAudio\\/Audiobook and Video")
	public void user_should_be_able_to_view_title_type_as_mandatory_field_and_listed_as_dropdown_with_options_e_book_print_book_and_e_audio_audiobook_and_video() {
		milestone_edit.Select_owntitle_Dropdwn();
	}

	@Then("user should be able to view the manually added external title be added to the program detail page")
	public void user_should_be_able_to_view_the_manually_added_external_title_be_added_to_the_program_detail_page() {
		milestone_edit.external_AddCTA();
	}

	@Then("user should be able to view default title cover image added with the title name specified by user")
	public void user_should_be_able_to_view_default_title_cover_image_added_with_the_title_name_specified_by_user() {
	  Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	  waitFor(2000);
	  Assert.assertTrue(milestone_edit.Default_coverimg.isDisplayed());
	}
	
	
	@Then("user is clicks on search CTA")
	public void user_is_clicks_on_search_cta() {
		search.Click_Searchbtn();
	}

	@Then("user navigates to search results page")
	public void user_navigates_to_search_results_page() {
	  visibilityWait(milestone_edit.SearchResults_addatitle);
	  Assert.assertTrue(milestone_edit.SearchResults_addatitle.isDisplayed());
	}

	@Then("user is able to add the titles")
	public void user_is_able_to_add_the_titles() {
		milestone_edit.Select_AddCTA();
		
	}

	@Then("verify user is able to navigates profile details page")
	public void verify_user_is_able_to_navigates_profile_details_page() {
		Assert.assertTrue(milestone.Nav_TitleDetails.isDisplayed());
	}

	@Then("verify user is able to view the added title for profile details page")
	public void verify_user_is_able_to_view_the_added_title_for_profile_details_page() {
		visibilityWait(milestone_edit.Addedtitle_titleDetails);
	   Assert.assertTrue(milestone_edit.Addedtitle_titleDetails.isDisplayed());
	}


}
