package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyLibrary_Guest;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class MyLibrary_Stepdef extends CommonAction {

	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());

	// 125318

	@And("user click on library options")
	public void user_click_on_library_options() throws Throwable {
		hamburgerMenu.click_library();
	}
	
	@And("user click on axis360 library link")
	public void user_click_on_axis360_library_link() throws Throwable {
		hamburgerMenu.axis360_libraryMenu();
	}


	@When("user lands on my library screen")
	public void user_lands_on_my_library_screen() {
		mylibrary.view_LibraryScreen();
	}

	@Then("user should be able to view home screen with adult theme rendered based on axis360 library subscription and adult profile type")
	public void user_should_be_able_to_view_home_screen_with_adult_theme_rendered_based_on_axis360_library_subscription_and_adult_profile_type() {
		hamburgerMenu.click_closeoldMenu();
		Logger.log(
				"user is able to view home screen with adult theme rendered based on axis360 library subscription and adult profile type");
	}

	@Then("user should be able to view current axis360 home screen for adult profile and axis360 library subscription")
	public void user_should_be_able_to_view_current_axis360_home_screen_for_adult_profile_and_axis360_library_subscription() {
		Assert.assertTrue(isElementPresent(mylibrary.getOld_libraryScreen()));
	}

	@Then("user should be able to view home screen with teen theme rendered based on kidszone library subscription and teen profile type")
	public void user_should_be_able_to_view_home_screen_with_teen_theme_rendered_based_on_kidszone_library_subscription_and_teen_profile_type() {
		Logger.log(
				"user is  able to view home screen with teen theme rendered based on kidszone library subscription and teen profile type");
	}

	@Then("user should be able to view new updated library home screen for teen profile and kidszone library subscription")
	public void user_should_be_able_to_view_new_updated_library_home_screen_for_teen_profile_and_kidszone_library_subscription() {
		Assert.assertTrue(mylibrary.getTxt_NavlibraryScreen().isDisplayed());
	}

	@Then("user should be able to view home screen with kid theme rendered based on kidszone library subscription and kid profile type")
	public void user_should_be_able_to_view_home_screen_with_kid_theme_rendered_based_on_kidszone_library_subscription_and_kid_profile_type() {
		Logger.log(
				"user is  able to view home screen with kid theme rendered based on kidszone library subscription and kid profile type");
	}

	@Then("user should be able to view new updated library home screen for kid profile and kidszone library subscription")
	public void user_should_be_able_to_view_new_updated_library_home_screen_for_kid_profile_and_kidszone_library_subscription() {
		Assert.assertTrue(mylibrary.getTxt_NavlibraryScreen().isDisplayed());
	}

	@Then("user should be able to view home screen with kid theme rendered based on kidszoneandaxis360 library subscription and kid profile type")
	public void user_should_be_able_to_view_home_screen_with_kid_theme_rendered_based_on_kidszoneandaxis360_library_subscription_and_kid_profile_type() {
		Logger.log(
				"user is  able to view home screen with kid theme rendered based on kidszoneandaxis360 library subscription and kid profile type");
	}

	@Then("user should be able to view new updated library home screen for kid profile and kidszone and axis360 library subscription")
	public void user_should_be_able_to_view_new_updated_library_home_screen_for_kid_profile_and_kidszone_and_axis360_library_subscription() {
		Assert.assertTrue(mylibrary.getTxt_NavlibraryScreen().isDisplayed());
	}

	// 125319

	@Then("user should be able to view library name and logo in the header")
	public void user_should_be_able_to_view_library_name_and_logo_in_the_header() {
		mylibrary.view_logoAlongwithLibraryName();
	}

	@Then("user should be able to click on menu and view menu drawer")
	public void user_should_be_able_to_click_on_menu_and_view_menu_drawer() {
		mylibrary.view_updatedNavigationBar();
	}

	@Then("user should be able to view searchbar and Advance search CTA")
	public void user_should_be_able_to_view_searchbar_and_advance_search_cta() {
		mylibrary.view_oldAdvanceSearch();
	}

	@Then("user should be able to view updated top navigation bar")
	public void user_should_be_able_to_view_updated_top_navigation_bar() {
		mylibrary.view_updatedNavigationBar();
	}

	@Then("user should be able to view Updated top navigation bar")
	public void user_should_be_able_to_view_Updated_top_navigation_bar() {
		mylibrary.updated_NavigationBar();
	}

	@Then("user should be able to view Hamburger Menu and Library Name along with Logo")
	public void user_should_be_able_to_view_hamburger_menu_and_library_name_along_with_logo() {
		mylibrary.view_logoAlongwithLibraryName();
	}

	@Then("user should be able to view the Notifications and User Avatar and Search bar and Advance search option")
	public void user_should_be_able_to_view_the_notifications_and_user_avatar_and_search_bar_and_advance_search_option() {
		Assert.assertTrue(mylibrary.view_avatarAndnotificationAdvancedSearch());
	}

	@Then("user should be able to click on avatar and navigate to my profile screen pop up")
	public void user_should_be_able_to_click_on_avatar_and_navigate_to_my_profile_screen_pop_up() {
		Assert.assertTrue(mylibrary.getAvatar_profile().isDisplayed());
	}

	@Then("user should be able to view default image if avatar image is not set by the user")
	public void user_should_be_able_to_view_default_image_if_avatar_image_is_not_set_by_the_user() {
		Logger.log("Currently logo is not available to validate");
	}

	@Then("user should be able to click on notifications icon and view notification center drawer")
	public void user_should_be_able_to_click_on_notifications_icon_and_view_notification_center_drawer() {
		Assert.assertTrue(mylibrary.getLabel_notification().isDisplayed());
	}

	@Then("user should be able to view library name and logo in the top header")
	public void user_should_be_able_to_view_library_name_and_logo_in_the_top_header() {
		Assert.assertTrue(mylibrary.getImg_logo().isDisplayed());
	}

	@Then("user should be able to click on hamburger menu and view menu drawer")
	public void user_should_be_able_to_click_on_hamburger_menu_and_view_menu_drawer() {
		Assert.assertTrue(mylibrary.getBtn_HambergerNavigationbar().isDisplayed());
		hamburgerMenu.click_HamburgerMenu();
		waitFor(3000);
		Assert.assertTrue(mylibrary.getHamMenuDrawer().isDisplayed());
	}

	@Then("user should be able to view search bar and advance search CTA")
	public void user_should_be_able_to_view_search_bar_and_advance_search_cta() {
		Assert.assertTrue(mylibrary.getTxt_advancedSearch().isDisplayed());
	}

	@Then("user should be able to click in advance search CTA to view advance search options")
	public void user_should_be_able_to_click_in_advance_search_cta_to_view_advance_search_options() {
		Assert.assertTrue(mylibrary.getBtn_searchicon().isDisplayed());
	}

	// 125321

	@Given("programs are enabled for the Profile and Library")
	public void programs_are_enabled_for_the_profile_and_library() {
		Logger.log("programs are enable for the profile and library");
	}

	@Then("user should be able to view set featured program as banner based on profile with adult profile theme")
	public void user_should_be_able_to_view_set_featured_program_as_banner_based_on_profile_with_adult_profile_theme() {
		Assert.assertEquals(mylibrary.getTxt_libraryScreen().isDisplayed(), true);
	}

	@Then("user should be able to navigate to featured program or My programs screen from CTA in the banner")
	public void user_should_be_able_to_navigate_to_featured_program_or_my_programs_screen_from_cta_in_the_banner() {
		hamburgerMenu.click_HamburgerMenu();
		mylibrary.click_featuredProgram();
	}

	@Then("user should view the featured program banner if state of the featured program is published and active")
	public void user_should_view_the_featured_program_banner_if_state_of_the_featured_program_is_published_and_active() {
		mylibrary.view_featuredProgram_state();
		
	}

	@Then("user should be able to view set featured program as banner based on profile with teen profile theme")
	public void user_should_be_able_to_view_set_featured_program_as_banner_based_on_profile_with_teen_profile_theme() {
		Logger.log("user able to view set featured program as banner based on profile with teen profile theme");
		
	}

	@Then("user should be able to view set featured program as banner based on profile with kid profile theme")
	public void user_should_be_able_to_view_set_featured_program_as_banner_based_on_profile_with_kid_profile_theme() {
		Assert.assertEquals(mylibrary.getTxt_NavlibraryScreen().isDisplayed(), true);
	}

	@Then("adult user should view the featured program banner if state of the featured program is published and active")
	public void adult_user_should_view_the_featured_program_banner_if_state_of_the_featured_program_is_published_and_active() {
		mylibrary.view_adultFeaturedProgram_state();
	}

	// 125320

	@Then("user should be able to view updated bottom navigation bar")
	public void user_should_be_able_to_view_updated_bottom_navigation_bar() throws Throwable {
		mylibrary.view_footerNavigationBar();
	}

	@And("user should be able to view library home and privacy policy and click on these cta to navigate to respective screens")
	public void user_should_be_able_to_view_library_home_and_privacy_policy_and_click_on_these_cta_to_navigate_to_respective_screens()
			throws Throwable {
		mylibrary.click_privacypolicy();
	}

	@And("user should be able to view terms and conditions and click on these cta to navigate to respective screen")
	public void user_should_be_able_to_view_terms_and_conditions_and_click_on_these_cta_to_navigate_to_respective_screen()
			throws Throwable {
		mylibrary.click_termsAndconditions();
	}

	@And("user should be able to view branding description or text in the footer added in admin portal")
	public void user_should_be_able_to_view_branding_description_or_text_in_the_footer_added_in_admin_portal()
			throws Throwable {
		Assert.assertEquals(mylibrary.getTxt_FooterNavigationbar().isDisplayed(), true);
	}

	@And("user should be able to view updated axsi360 logo")
	public void user_should_be_able_to_view_updated_axsi360_logo() throws Throwable {
		// Assert.assertTrue(mylibrary.getTxt_logotitle().isDisplayed());
		Logger.log("User able to view updated axsi360 logo");
	}

	@And("user should be able to view axis360 copy right information")
	public void user_should_be_able_to_view_axis360_copy_right_information() throws Throwable {
		Assert.assertEquals(mylibrary.getTxt_FooterNavigationbar().isDisplayed(), true);
		Assert.assertEquals(mylibrary.getCopyRights().isDisplayed(), true);
	}

	// 125333

	@Then("user should be able to view newspapers and magazines carousel with adult profile theme")
	public void user_should_be_able_to_view_newspapers_and_magazines_carousel_with_adult_profile_theme()
			throws Throwable {
		mylibrary.view_newspaperAndmagazine();
	}

	@And("adult user should be able to click on view all cta and navigate to newspapers and magazines screen")
	public void adult_user_should_be_able_to_click_on_view_all_cta_and_navigate_to_newspapers_and_magazines_screen()
			throws Throwable {
		mylibrary.click_seeAllcta();
	}
	
	@Given("axis user click on library options")
	public void axis_user_click_on_library_options() {
		hamburgerMenu.click_oldMylibrary();
	}

	@When("axis user should be navigated to my library screen")
	public void axis_user_should_be_navigated_to_my_library_screen() {
	   hamburgerMenu.mylibrary_homepage.isDisplayed();
	}
	@Then("user should be able to view newspapers and magazines carousel with teen profile theme")
	public void user_should_be_able_to_view_newspapers_and_magazines_carousel_with_teen_profile_theme()
			throws Throwable {
		mylibrary.view_newspaperAndmagazine();
	}

	@Then("User should be able to view newspapers and magazines carousel with kid profile theme")
	public void user_should_be_able_to_view_newspapers_and_magazines_carousel_with_kid_profile_theme()
			throws Throwable {
		mylibrary.view_newspaperAndmagazine();
	}

	@And("user should be able to view featured publications in newspapers and magazines carousel")
	public void user_should_be_able_to_view_featured_publications_in_newspapers_and_magazines_carousel()
			throws Throwable {
		mylibrary.view_newsPapermagazineCarousel();
	}

	@And("user should be able to view brief description for the carousel")
	public void user_should_be_able_to_view_brief_description_for_the_carousel() throws Throwable {
//		Assert.assertTrue(mylibrary.getTxt_description().isDisplayed());
		Logger.log("Description abaout the carousel will get displayed only if preferences of the features are set");
	}

	@And("user should be able to click on view all cta and navigate to newspapers and magazines screen")
	public void user_should_be_able_to_click_on_view_all_cta_and_navigate_to_newspapers_and_magazines_screen()
			throws Throwable {
		mylibrary.click_newsPaperAndMagazineSeeAllcta();
	}

	// 125335

//	@Then("^user should be able to view always available collection carousel with adult profile specific theme$")
//    public void user_should_be_able_to_view_always_available_collection_carousel_with_adult_profile_specific_theme() throws Throwable {
//		Logger.log("user should be able to view always available collection carousel with adult profile");
//    }

	@Then("user should be able to view always available collection carousel with teen profile specific theme")
	public void user_should_be_able_to_view_always_available_collection_carousel_with_teen_profile_specific_theme()
			throws Throwable {
		Logger.log("user should be able to view always available collection carousel with teen profile");
	}

	@Then("user should be able to view always available collection carousel with kid profile specific theme")
	public void user_should_be_able_to_view_always_available_collection_carousel_with_kid_profile_specific_theme()
			throws Throwable {
		Logger.log("user should be able to view always available collection carousel with kid profile");
	}

	@And("user should be able to view featured titles in always available collection carousel")
	public void user_should_be_able_to_view_featured_titles_in_always_available_collection_carousel() throws Throwable {
		mylibrary.view_alwaysAvailableTitle();
	}

	@And("user should be able to view always available brief description for the carousel")
	public void user_should_be_able_to_view_always_available_brief_description_for_the_carousel() throws Throwable {
		Assert.assertTrue(isElementPresent(mylibrary.getTxt_AlwaysavailableDescription()));
		Logger.log("user should be able to view always available brief description for the carousel");
	}

	@And("user should be able to click on view all cta and navigate to always available collection list screen")
	public void user_should_be_able_to_click_on_view_all_cta_and_navigate_to_always_available_collection_list_screen()
			throws Throwable {
		mylibrary.alwaysAvailable_seeAllcta();
		
	}

	// 131657

	@Then("user should not be able to view always available carousel if always available collections is disabled in the library")
	public void user_should_not_be_able_to_view_always_available_carousel_if_always_available_collections_is_disabled_in_the_library() {
         //Assert.assertTrue(mylibrary.getTxt_AlwaysavailableTitle().isDisplayed());
		 Assert.assertFalse(isElementPresent(mylibrary.getTxt_AlwaysavailableTitle()));
	}

	@Then("user should not be able to view the always available in my library screen")
	public void user_should_not_be_able_to_view_the_always_available_in_my_library_screen() {
		// Assert.assertFalse(mylibrary.getTxt_AlwaysavailableTitle().isDisplayed());
		Logger.log("user should not be able to view the always available in my library screen");
	}

	// 125322

	@When("user navigates to the library screen")
	public void user_navigates_to_the_library_screen() throws Throwable {
		Assert.assertTrue(mylibrary.getBtn_SearcBar().isDisplayed());
	}

	@Then("user should not view the featured program banner")
	public void user_should_not_view_the_featured_program_banner() throws Throwable {
		Logger.log("user not able to view the featured program banner");
	}

	@And("no featured program has been set")
	public void no_featured_program_has_been_set() throws Throwable {
		Logger.log("Feature program has not been set in the admin");
	}

}
