package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Profile;
import pom.kidszone.ProfileS4;

public class ProfileS4_StepDef extends CommonAction {

	Profile old = new Profile(DriverManager.getDriver());
	ProfileS4 profileNew = new ProfileS4(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Then("user is on manage profile screen")
	public void user_is_on_manage_profile_screen() {
		visibilityWait(old.profileListPage);
//		Assert.assertTrue(old.profileListPage.isDisplayed());
	}

	@Given("user clicks on Primary Profile")
	public void user_clicks_on_primary_profile() {
		login.click_Adultprofile();
	}

	@Given("user clicks on Teen Profile")
	public void user_clicks_on_teen_profile() {
		profileNew.click_Teenprofile();
	}
	
	@Given("user clicks on Kid Profile")
	public void user_clicks_on_kid_profile() {
		profileNew.click_Kidprofile();
	}

	@When("user clicks the profile icon in header")
	public void user_clicks_the_profile_icon_in_header() {
		profileNew.clickProfileAvatar();
	}

	@When("user clicks on Manage Profiles cta")
	public void user_clicks_on_manage_profiles_cta() {
		profileNew.clickManageProfDropDown();
	}

	@When("user clicks on Profile Settings cta")
	public void user_clicks_on_profile_settings_cta() {
		profileNew.clickProfileDropDown();
	}
}
