package parallel;

import java.io.IOException;


import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Loginpageview;
import pom.kidszone.Profilecreation;
import pom.kidszone.SetUpParentPin;

public class SetupParentPin_Stepdef {

	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	SetUpParentPin parentPin = new SetUpParentPin(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());

	@And("user re-enters the Pin {string} again for confirmation")
	public void user_enter_the_pin_again_for_confirmation(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickDone();
	}
	@And("user is successfully redirected to the profile page")
	public void user_is_successfully_redirected_to_the_profile_page() {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
//		profile.log_Out();
	}

	@And("user enter the wrong pin in confirm and click done cta")
	public void user_enter_the_pin_in_for_confirm_and_click_done_cta() {
		profile.enter_WrongPin();
		profile.clickDone();
	}

	@And("user should view error message as {string}")
	public void user_should_vew_error_message_as(String Pin) {
		Logger.log("Currently failure toast message is displayed");
		//profile.toastValidation();

	}

	@And("user clicks on admin for password link")
	public void user_clicks_on_admin_for_password_link() {
		parentPin.click_AdminForPassword();

	}

	@And("user enters the temp password {string}")
	public void user_enters_the_temp_password(String password) {
		parentPin.enter_TempPassword(password);
		Logger.log("User entered the temp password");
	}

	@And("user clicks on the register button")
	public void user_clicks_on_the_register_button() {
		parentPin.click_RegisterButton();
	}

	@And("user is in register pop up page")
	public void user_is_in_register_pop_up_page() {
		Assert.assertEquals(parentPin.getText_headingRegister().isDisplayed(), true);
	}

	@And("user enters the username {string}")
	public void user_enters_the_username(String username) {
		parentPin.enter_UserName(username);
		Logger.log("User entered the username field");
	}

	@And("user enters the password {string} for login")
	public void user_enters_the_password_for_login(String Pin) {
		profile.registerPage_set_Pin(Pin);
	}

	@And("system navigate to reset screen")
	public void system_navigate_to_reset_screen() {
		Assert.assertTrue(parentPin.getTxt_resetDescription().isDisplayed());
	}

	@And("user clicks on reset pin cta")
	public void user_clicks_on_reset_pin_cta() {
		parentPin.click_ResetPin();
	}

	@And("system prompts the security question and answer")
	public void system_prompts_the_security_question_and_answer() {
		Assert.assertTrue(parentPin.getTxt_securityQuestion().isDisplayed());
	}

	@And("user enter answer and click submit cta")
	public void user_enter_answer_and_click_submit_cta() throws InvalidFormatException, IOException {
		parentPin.enter_AnswerField();
		parentPin.click_SubmitButton();

	}

	@And("system prompts to set new pin on successful validation of security question")
	public void system_prompts_to_set_new_pin_on_successful_validation_of_security_question() {
		Assert.assertTrue(parentPin.getTxt_pinSetDescription().isDisplayed());
	}

	@And("user should see the option to enter new {string} and click on done")
	public void user_should_see_the_option_to_enter_new_and_click_on_done(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickDone();
	}

	@And("user should see the option to enter confirm {string} and click on done")
	public void user_should_see_the_option_to_enter_confirm_and_click_on_done(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickDone();
	}

	@And("user has already set up parent pin earlier")
	public void user_has_already_set_up_parent_pin_earlier() {
		Assert.assertTrue(parentPin.getTxt_profilePinHeading().isDisplayed());

	}
	@And("user has entered the wrong parent pin multiple times")
	public void user_has_entered_the_wrong_parent_pin_multiple_times() {
		int i = 0;
		while (i < 3) {
			profile.enter_WrongPin();
			profile.clickSubmit();
			i++;
		}
	}

	@Given("existing user not set the parent pin")
	public void existing_user_not_set_the_parent_pin() throws Throwable {
		profile.existingUser_setpin();	
	}

	@When("Existing user enters the prefix {string} and pin {string} shared by the client")
	public void Existing_user_enters_the_prefix_and_pin_shared_by_the_client(String loginid, String pin) {
		loginpageUpdatedui.existing_loginwithPin(loginid, pin);
		profile.preferenceScreen_popup();
	}
	
	@When("New user enters the prefix {string} and pin {string}")
	public void new_user_enters_the_prefix_and_pin(String loginid, String pin) {
		loginpageUpdatedui.existing_loginwithPin(loginid, pin);
		profile.preferenceScreen_popup();
	}
	
	@When("user successfully logged {string} in")
	public void user_successfully_logged_in(String Pin) {
		loginpageUpdatedui.click_loginPage();
		loginpageUpdatedui.existing_loginwithIdPin(Pin);
	}

	@And("user will be redirected to the profile page")
	public void user_will_be_redirected_to_the_profile_page() throws Throwable {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
	}

	/* ******************************** Authenticate via ParentPin************/

	@And("user should see the parental pin option")
	public void user_should_see_the_parental_pin_option() throws Throwable {
		Assert.assertEquals(parentPin.getTxt_profilePinHeading().getText(), "Profile Management PIN");
	}

	@And("user enters the wrong Pin and click submit")
	public void user_enters_the_wrong_pin_and_click_submit() throws Throwable {
		profile.enter_WrongPin();
		profile.clickSubmit();
	}

	@And("user should see toast error message 'Invalid pin'")
	public void user_should_see_toast_error_message_invalid_pin() throws Throwable {
		Logger.log("user views the Invalid Pin Toast message");
	}

	@And("user should see reset pin option after two failure attempts in a row")
	public void user_should_see_reset_pin_option_after_two_failure_attempts_in_a_row() throws Throwable {
		profile.enter_WrongPin();
		profile.clickSubmit();
		profile.enter_WrongPin();
		profile.clickSubmit();
	}

	@And("system redirects the user to reset pin page")
	public void system_redirects_the_user_to_reset_pin_page() throws Throwable {
		Assert.assertTrue(parentPin.getTxt_securityQuestion().isDisplayed());
	}

	@And("user answers the security question to continue")
	public void user_answers_the_security_question_to_continue() throws Throwable {
		parentPin.enter_AnswerField();
		parentPin.click_SubmitButton();
	}

	@And("user should see error message {string}")
	public void user_should_see_error_message(String message) throws Throwable {
		Logger.log("user views the error message as " + message);
	}

	@And("user clicks on the reset pin option to reset the pin")
	public void user_clicks_on_the_reset_pin_option_to_reset_the_pin() throws Throwable {
		parentPin.click_ResetPin();
	}

	@And("user should see reset pin option after three failure attempts in a row")
	public void user_should_see_reset_pin_option_after_three_failure_attempts_in_a_row() throws Throwable {
		int i = 1;
		while (i < 3) {
			profile.enter_WrongPin();
			profile.clickSubmit();;
			i++;
		}
	}

	@And("user is clicking on profiles from Menu")
	public void user_is_clicking_on_profiles_from_menu() throws Throwable {
		profile.click_menu();
	}

	@And("user enters the profile details like display name {string} and select avatar is optional")
	public void user_enters_the_profile_details_like_display_namemandatory_and_select_avataroptional(String displayname)
			throws Throwable {
		profile.select_avatar(displayname);
	}

	@And("^user clicks on the done button to create the profile$")
	public void user_clicks_on_the_done_button_to_create_the_profile() throws Throwable {
		profile.addprofle_donebtn();
	}

	@And("user enter wrong answer and click submit cta")
	public void user_enter_wrong_answer_and_click_submit_cta() throws Throwable {
		parentPin.wrong_AnswerField();
		parentPin.click_SubmitButton();
	}

	@And("system prompts error toast message {string}")
	public void system_prompts_error_toast_message_security_answer_not_matched(String message) throws Throwable {
		Logger.log("user views the error message as " + message);
	}

	@Then("user navigate to reset pin screen")
	public void user_navigate_to_reset_pin_screen() throws Throwable {
		Assert.assertTrue(parentPin.getReset_pinPage().isDisplayed());
	}

	@And("user leave the page without reset the pin")
	public void user_leave_the_page_without_reset_the_pin() throws Throwable {
		profile.click_menu();
	}

	@And("user click on profiles from menu")
	public void user_click_on_profiles_from_menu() throws Throwable {
		profile.click_menu();
	}

	@And("user should see the reset pin screen")
	public void user_should_see_the_reset_pin_screen() throws Throwable {	
		parentPin.click_ResetPin();
		parentPin.enter_AnswerField();
		parentPin.click_SubmitButton();
			
	}
	
	@Given("user enters {string}")
	public void user_enters(String username) {
		parentPin.texas_EnteruserName(username);
	}

	@Given("user sets {string} for login")
	public void user_sets_for_login(String password) {
		parentPin.texas_Enterpassword(password);
	}
}

