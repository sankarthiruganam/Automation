package parallel;

import java.util.List;

import java.util.Map;

import org.junit.Assert;
import com.driverfactory.DriverManager;
import com.resuableMethods.Highlighter;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Login;
import pom.kidszone.Profilecreation;
import pom.kidszone.Wishlist;

public class Whishlist_StepDef {

	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Holds hold = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("user launch the kidszone newyork library url")
	public void user_launch_the_kidszone_newyork_library_url() throws Throwable {
		login.Login_PrefixWithoutPin();
	}

	
	@Given("user click on login button after user enter kidszone subscription only {string} Adult")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_only_adult(String id) {
		profile.readInAppClose();
		hold.logInClick();
		hold.adult_login_Pop_Up(id);
	}

	@Given("no title is wishlist")
	public void no_title_is_wishlist() {
		Highlighter.highLighterMethod(wish.getWishlist(), DriverManager.getDriver());
	}

	@When("user lands on wishlist screen")
	public void user_lands_on_wishlist_screen() {
		ham.click_HamburgerMenu();
		hold.myShelfClick();
		wish.clickWishlist();
		Assert.assertTrue(wish.getWishlistPage().isDisplayed());
	}

	@Then("user should be able to view wishlist screen with theme rendered based on library subscription and kid profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_theme_rendered_based_on_library_subscription_and_kid_profile_type() {
		Logger.log("User able to view wishlist screen with theme rendered based on library subscription");
	}

	@Then("user should be able to view no title wishlist screen")
	public void user_should_be_able_to_view_no_title_wishlist_screen() {
		wish.wishListTitleAbsent();
	}

	@Then("user should be able to message {string} on wishlist screen")
	public void user_should_be_able_to_message_on_wishlist_screen(String text) {
		Assert.assertTrue(wish.getWishlistText().isDisplayed());
		wish.getWishlistText().getText().contains(text);
	}

	@Then("user should be able to view wishlist screen with theme rendered based on library subscription and teen profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_theme_rendered_based_on_library_subscription_and_teen_profile_type() {
		Logger.log("User able to view wishlist screen with theme rendered based on library subscription");
	}

	@Then("user should be able to view wishlist screen with theme rendered based on library subscription and adult profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_theme_rendered_based_on_library_subscription_and_adult_profile_type() {
		Logger.log("User able to view wishlist screen with theme rendered based on library subscription");
	}

	@When("user lands on existing home screen")
	public void user_lands_on_existing_home_screen() {
		Assert.assertTrue(hold.getAdultLibraryPage().isDisplayed());
	}

	@Then("user should not able to view wishlist screen with theme rendered based on library subscription and user profile type")
	public void user_should_not_able_to_view_wishlist_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		ham.click_HamburgerMenu();
		Assert.assertFalse(ham.notDisplayed_myshelfInaxisLib());
		Logger.log("User is not able to view the wishlist screen with theme rendered based on library subscription");
	}

	@When("user lands on existing Home screen")
	public void user_lands_on_existing_Home_screen() {
		Assert.assertTrue(hold.getAdultLibraryPage().isDisplayed());
	}

	@Then("user should not able to view Wishlist screen with theme rendered based on library subscription and user profile type")
	public void user_should_not_able_to_view_Wishlist_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log(
				"User not able to view the wishlist screen with theme rendered based on library subscription");
	}

	@When("user clicks on the wishlist quick nativation CTA")
	public void user_clicks_on_the_wishlist_quick_nativation_cta() {
		ham.click_HamburgerMenu();
		hold.myShelfClick();
		wish.clickWishlist();
	}

	@Then("user should be able to view wishlist screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("User able to view wishlist screen with theme rendered based on library subscription and user profile");
	}

	@Then("user should be able to view quick navigation CTAs as a carousel on top with wishlist highlighted and should be able to view number of titles in the wishlist")
	public void user_should_be_able_to_view_quick_navigation_ct_as_as_a_carousel_on_top_with_wishlist_highlighted_and_should_be_able_to_view_number_of_titles_in_the_wishlist() {
		hold.holdClick();
		wish.clickWishlist();
		Highlighter.highLighterMethod(wish.getWishlist(), DriverManager.getDriver());
		Assert.assertTrue(wish.getWishCount().isDisplayed());
	}

	@Then("user should be able to view titles added to wishlist by that user only")
	public void user_should_be_able_to_view_titles_added_to_wishlist_by_that_user_only() {
		Assert.assertTrue(wish.getWishlistTitle().isDisplayed());
		Logger.log("User able to view the title added to wishlist by that user only");
	}

	@Then("user should be able to view titles sorted by latest added title first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_added_title_first_by_default() {
		Logger.log("User able to view the titles sorted by latest added title frist by default");
	}

	@Then("user should be able to view Filter and sort option for the titles")
	public void user_should_be_able_to_view_filter_and_sort_option_for_the_titles() {
		Assert.assertTrue(wish.getFilterIcon().isDisplayed());
		Assert.assertTrue(wish.getSortIcon().isDisplayed());
	}

	@Then("user should be able to view the Bread crumb navigation for the screen")
	public void user_should_be_able_to_view_the_bread_crumb_navigation_for_the_screen() {
		Assert.assertTrue(wish.getBreadCrumb().isDisplayed());
	}

	@Then("user should be able to click on back CTA to navigate back to last screen")
	public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() {
		wish.backCta();
		Logger.log("User able to navigate back to last screen");
	}

	@Then("if user add the titles in wishlist, wishlist count should be increase")
	public void if_user_add_the_titles_in_wishlist_wishlist_count_should_be_increase() {
		wish.addtoWishList();
		Assert.assertTrue(wish.getWishlistTitle().isDisplayed());
	}

	@Then("if user remove the titles in wishlist, wishlist count shoule be decrease")
	public void if_user_remove_the_titles_in_wishlist_wishlist_count_shoule_be_decrease() {
		wish.removeWishList();
		wish.wishRemoveCount();
	}

	@Given("user title added to wishlist")
	public void user_title_added_to_wishlist() {
		wish.addtoWishList();
	}

	@Then("User should be able to view primary action for the title as a button")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button() {
		hold.primaryAction();
	}

	@Then("User should be able to view more options cta to view secondary actions available for the title")
	public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title() {
		Assert.assertTrue(wish.getSecCtaOptions().isDisplayed());

	}

	@Then("User should be able to click in more options cta and view secondary actions for the title")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title() {
		wish.clickSecActions();
	}

	@Then("Removing title from Wishlist")
	public void removing_title_from_wishlist() {
		wish.removeWishList();
	}

	@Then("user should be able to view titles listed as list view by default and sorted by latest title wishlist first by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_and_sorted_by_latest_title_wishlist_first_by_default() {
		hold.getTitleListView().isDisplayed();
		Logger.log("Title is displayed as List View as default");
	}

	@When("user is on wishlist screen")
	public void user_is_on_wishlist_screen() {
		Assert.assertTrue(wish.getWishlistPage().isDisplayed());
	}

	@Then("user should be able to click on Sort to view sort options")
	public void user_should_be_able_to_click_on_sort_to_view_sort_options() {
		wish.sortClick();
	}

	@Then("user should be able to view Sort options {string},{string},{string}")
	public void user_should_be_able_to_view_sort_options(String latest, String rating, String alphabetic) {
		wish.sortOptions(latest, rating, alphabetic);

	}

	@Then("user should view the titles sorted with latest title added to Wishlist first by default")
	public void user_should_view_the_titles_sorted_with_latest_title_added_to_wishlist_first_by_default() {
		Logger.log("User able to see the latest title added to wishlist first by default");
	}

	@When("user has checkout title that is in wishlist")
	public void user_has_checkout_title_that_is_in_wishlist() {
//		wish.ClearTitlesIncheckOut();
		wish.addtoWishList();
	}

	@Then("system should update the wishlist and remove the title checked out from the wishlist")
	public void system_should_update_the_wishlist_and_remove_the_title_checked_out_from_the_wishlist() {
		wish.removeWishList();
//		wish.wishRemoveCount();
//		wish.moveAndVerifyTheTitleinCheckout();
//		wish.returnTitleFromCheckout();
	}

	@When("user switch to grid view for wishlist screen")
	public void user_switch_to_grid_view_for_wishlist_screen() {
		hold.clickGrid();
		hold.gridViewDisplayed();
	}

	@Then("user should be able to view titles listed as list view and sorted by latest title wishlist first by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_and_sorted_by_latest_title_wishlist_first_by_default() {
		Logger.log("User able to see the titles listed as list view and sorted by latest title wishlist first by default");
	}
	
	@Then("user should be able to view primary action and secondary action for the wishlist title as a button")
	public void user_should_be_able_to_view_primary_action_and_secondary_action_for_the_wishlist_title_as_a_button() {
	    hold.ValidatePrimaryCtaInWishlistScreen();
	    checkout.click_moreOption();
	    Assert.assertTrue(wish.secondaryCta_Remove.isDisplayed());
	    
	}

}
