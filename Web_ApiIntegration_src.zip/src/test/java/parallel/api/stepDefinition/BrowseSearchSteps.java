package parallel.api.stepDefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import api.APIClient;
import api.enums.GenericEnum.SearchParams;
import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.Title;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import parallel.Migration_StepDef;
import pom.kidszone.BrowseBySearch;
import pom.kidszone.LibrarySprint6B;
import pom.kidszone.Login;


public class BrowseSearchSteps {
    private List<SearchTitleResponse> apiResponses;
    private List<String> extractedAudienceCodes = new ArrayList<>();
    LibrarySprint6B library = new LibrarySprint6B(DriverManager.getDriver());
    Login login = new Login(DriverManager.getDriver());
    BrowseBySearch browseSearch = new BrowseBySearch(DriverManager.getDriver());    

    @When("the API response is retrieved from Browse")
    public void retrieveAPIResponse() throws IOException {
    	apiResponses = APIClient.getBrowseSearchTitleResponse("pubDate");
        assertNotNull("API response is null", apiResponses);
    }

    @Then("the Browse Search API response result counts match the UI result")
    public void compareResultCounts() {
        assertNotNull("API response is null", apiResponses);
        
        for(SearchTitleResponse apiResponse : apiResponses) {

        String apiResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount();
        String ebookResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteBookCount();
        String audioResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount();

        List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList().getTitles();
        for (Title title : titles) {
            String audience = title.getAudience();
            System.out.println("extracted audience code for title : " + title.getiSBN() + " is : " + audience);
            try {
                assertNotEquals("Audience code is not GA", audience, "GA");
            } catch (AssertionError e) {
            	Logger.error("Assertion failed: " + e.getMessage());
            }            
            extractedAudienceCodes.add(audience);
        }

        System.out.println(extractedAudienceCodes);

        int apiResultCountInt = Integer.parseInt(apiResultCount);
        int apiEbookCount = Integer.parseInt(ebookResultCount);
        int apiEaudioCount = Integer.parseInt(audioResultCount);
        
        Logger.info("Total count received from API: " + Integer.toString(Migration_StepDef.get_CategoryCount));
        Logger.info("Total count received from API for eBooks: " + Integer.toString((Migration_StepDef.get_eBookcount)));
        Logger.info("Total count received from API for audioBooks: " + Integer.toString((Migration_StepDef.get_eAudiocount)));
        
        assertEquals("API result count doesn't match UI result", apiResultCountInt, Migration_StepDef.get_CategoryCount);
        assertEquals("Ebook result count doesn't match", apiEbookCount, Migration_StepDef.get_eBookcount);
        assertEquals("Audio result count doesn't match", apiEaudioCount, Migration_StepDef.get_eAudiocount);
        
        }
    }

    @Given("the user is on Browse page")
    public void the_user_searches_for_a_title() {
        System.out.println("step def for the user searches for a title");
    }
    

    public void GetApiResultsCount(String searchSort, String subject, String category, String availability, String formatType, String ageLevel, String languageDesc, String profileType) {
    	String collection="";
		Logger.info("category provided: " + category);

		category = library.convertCategories(category);

		if (formatType.equalsIgnoreCase("eBook")) {
			SearchParams.format.getEformatType();
		} else if (formatType.equalsIgnoreCase("eAudio")) {
			SearchParams.format.getAformatType();
		}

		if (availability.equalsIgnoreCase("All Titles")) {
			availability = "";
		} else if (availability.equalsIgnoreCase("Available Now")) {
			availability = "Y";
		}
		if(profileType.equalsIgnoreCase("Adult")) {
//			collection = "recommendation,PPC";
			SearchParams.collection.getParams();
			
		}else if (profileType.equalsIgnoreCase("Teen")) {
			collection = "recommendation";
		}
	
		apiResponses = APIClient.getBrowseSearchTitleResponse(searchSort, subject, category, availability, formatType,
				ageLevel, languageDesc, collection);

		HashMap<String, String> isbnAudienceMap = new HashMap<String, String>();

		for (SearchTitleResponse apiResponse : apiResponses) {

			int apiResultCount = Integer
					.parseInt(apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount());

			
			if (browseSearch.searchResultCount() == apiResultCount) {
				Assert.assertEquals("browse result count should match", browseSearch.searchResultCount(), apiResultCount);
			} else {
				Logger.error("browse result count did not match " + " count from UI : " + browseSearch.searchResultCount() + " count from API " + apiResultCount);
			}

			List<Title> titles = null;
			if (apiResponse != null
			    && apiResponse.getSearchTitleResponseData() != null
			    && apiResponse.getSearchTitleResponseData().getSearchTitleResult() != null
			    && apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList() != null) {
			    titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList().getTitles();
			}

			if (titles == null || titles.isEmpty()) {
			    Logger.error("browse API call didn't return any result");
			    break;
			}

			int audioCountResult = Integer
					.parseInt(apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());

			int eBookCountResult = Integer
					.parseInt(apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());

			Logger.info("API count fetched from the getbrowseSearch Response for audiobook is " + audioCountResult);

			Logger.info("API count fetched from the getbrowseSearch Response for eBookcount is " + eBookCountResult);

			if(!profileType.equalsIgnoreCase("Adult")) {
			List<String> isbnListFromAPI = new ArrayList<String>();

			for (Title title : titles) {
				String audience = title.getAudience();
				String isbn = title.getiSBN();
				isbnAudienceMap.put(isbn, audience);
				isbnListFromAPI.add(isbn);
//				System.out.println("extracted audience code for title : " + isbn + " is : " + audience);
			}

			List<String> isbListfromUI = new ArrayList<String>();

			isbListfromUI = login.get_TitlesISBN();

			for (String isbn : isbListfromUI) {
				Logger.info("isbn from UI: " + isbn);
				if (isbnAudienceMap.containsKey(isbn)) {
					Logger.info("Audience Code is : " + isbnAudienceMap.get(isbn));
					if(isbnAudienceMap.get(isbn).contains("Teen") ||isbnAudienceMap.get(isbn).contains("Children")) {
			    		Assert.assertTrue("Audience should be Teen or Children", isbnAudienceMap.get(isbn).contains("Teen") ||isbnAudienceMap.get(isbn).contains("Children"));
					} else {
						Logger.error("API response does not contains the ISBN : " + isbn);
					}
				} else {
					Logger.info("API response does not contain the key : " + isbn);
					Logger.info("Audience code is : " + isbnAudienceMap.get(isbn));
				}
			 }
		  }
	   }

	}
}
    	
    	

    	
    	
   

