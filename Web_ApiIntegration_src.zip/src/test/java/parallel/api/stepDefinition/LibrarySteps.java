package parallel.api.stepDefinition;

import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import org.junit.Assert;
import com.driverfactory.DriverManager;
import com.utilities.Logger;
import api.APIClient;
import api.MagicWall.Category;
import api.MagicWall.GetTitlesResponse;
import api.curatedList.CuratedResponse;
import api.curatedList.CuratedResponseItem;
import api.getRecommendations.RecommendationsResponse;
import api.getRecommendations.RecommendedTitle;
import api.libraryComponents.Component;
import api.libraryComponents.ComponentResponse;
import api.magicWallList.FeaturedList;
import api.searchTitlev8.SearchTitleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import parallel.Librarybasedsubscription_Stepdef;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Librarysubscription;
import pom.kidszone.Login;
import pom.kidszone.TitleAcrossProfile;

public class LibrarySteps {

	TitleAcrossProfile across = new TitleAcrossProfile(DriverManager.getDriver());
	Librarysubscription library = new Librarysubscription(DriverManager.getDriver());
	pom.kidszone.FeaturedList featurelist = new pom.kidszone.FeaturedList(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	private ComponentResponse componentResponse;
	private GetTitlesResponse getTitleResponse;
	private RecommendationsResponse recommendationResponse;
	private List<CuratedResponse> curatedResponseList;
	private FeaturedList featureListResponse;
	String listID = "";
	String paramCatagory = "";
	String entityListId = "";

	@Given("the user is on my library page")
	public void the_user_is_on_my_library_page() {
		System.out.println("I am on My Library page");
	}

//	@When("the Library API response is retrieved")
//	public void the_library_api_response_is_retrieved() {
////		componentResponse = APIClient.getComponentResponse();
////		assertNotNull("API response is null", componentResponse);
//
//		getTitleResponse = APIClient.getLibraryResponse(null);
//		assertNotNull("API response is null", getTitleResponse);
//
//	}

//	@Then("validate the Library components displayed in the library page with {string} and compare API name matches the UI component names")
//	public void validate_the_Library_components_displayed_in_the_library_page_and_compare_API_name_matches_the_UI_component_names(
//			String profileType) throws Exception {
//
////		HashMap<String, ArrayList> CategoryMap = new HashMap<String, ArrayList>();
//
//		getTitleResponse = APIClient.getLibraryResponse(profileType);
//		assertNotNull("API response is null", getTitleResponse);
//
//		List<Category> categories = getTitleResponse.getGetTitleResponse().getGetTitleResult().getCatagories()
//				.getCategory();
//
//		List<String> LibraryCarouselfromAPI = new ArrayList<String>();
//
//		for (Category categoryName : categories) {
//			String name = categoryName.getParamCatagoryName();
////			CategoryMap.put(name, null);
//			LibraryCarouselfromAPI.add(name);
//			Logger.log("Extracted component Name from API is : " + name);
//
//		}
//		System.out.println(LibraryCarouselfromAPI);
//
//		List<String> LibraryCarouselfromUI = new ArrayList<String>();
//
//		LibraryCarouselfromUI = library.verify_LibraryCarousel();
//
//		System.out.println("After adding in list " + LibraryCarouselfromUI);
//
////		for (String carousel : LibraryCarouselfromUI) {
////			Logger.log("Extracted components name from library page UI is : " + carousel);
//
//		LibraryCarouselfromUI.remove(0);
//
////		}
//		System.out.println("After removing Always Available carousel from list " + LibraryCarouselfromUI);
//
//		if (LibraryCarouselfromAPI.contains(LibraryCarouselfromUI)) {
//			Logger.log("The name should contain in the list : " + LibraryCarouselfromAPI.equals(LibraryCarouselfromUI));
//		} else {
//
//			Logger.log("The name does not contains in the list");
//		}
//
//		try {
//			Assert.assertTrue("The category name not matched with API",
//					LibraryCarouselfromAPI.contains(LibraryCarouselfromUI));
//		} catch (AssertionError e) {
//			Logger.log("Assertion failed: " + e.getMessage());
//		}
//
//	}

	@Then("validate the Library components displayed in the library page with {string}, {string} and compare API name matches the UI component names")
	public void validate_the_Library_components_displayed_in_the_library_page_with_and_compare_API_name_matches_the_UI_component_names(
			String profileType, String profileID) throws Exception {

		List<String> EntityTypeList = new ArrayList<String>();
		List<String> EntityIdList = new ArrayList<String>();
		List<String> LibraryCarouselfromAPI = new ArrayList<String>();
		componentResponse = APIClient.getComponentResponse();

		List<Component> getComponentList = componentResponse.getComponents();
		for (Component listId : getComponentList) {
//			String entityId = listId.getEntityId();
//			Logger.log("The list of EntityId's " + entityId);
			String entityType = listId.getEntityType();
			EntityTypeList.add(entityType);

			if (EntityTypeList.contains("CURATED_LIST")) {
				String entityId = listId.getEntityId();
				String componentNames = listId.getTitle();
				Logger.log("The list of EntityId's " + entityId);
				Logger.log("Extracted component Name from API is : " + componentNames);
				EntityIdList.add(entityId);
				LibraryCarouselfromAPI.add(componentNames);

			}
		}
		String entityList = EntityIdList.toString();
		entityList = entityList.substring(1, entityList.length() - 1);
		entityListId = entityList.replaceAll(" ", "");
		System.out.println(entityListId);

		curatedResponseList = APIClient.getCuratedResponse(profileType, profileID, entityListId);

//		TreeSet<String> LibraryCarouselfromAPI = new TreeSet<String>();

//		for (CuratedResponse apiResponse : curatedResponseList) {
//
//			String listNames = apiResponse.getListName();
//			LibraryCarouselfromAPI.add(listNames);
//			Logger.log("Extracted component Name from API is : " + listNames);
//		}

		List<String> LibraryCarouselfromUI = new ArrayList<String>();

//		TreeSet<String> LibraryCarouselfromUI = new TreeSet<String>();

		LibraryCarouselfromUI = library.verify_LibraryCarousel();

		System.out.println("After adding in list from UI " + LibraryCarouselfromUI);

		if (LibraryCarouselfromUI.contains("Always Available")) {
			LibraryCarouselfromUI.remove("Always Available");
			Logger.log("After removing Always Available carousel from list for Adult user " + LibraryCarouselfromUI);

		}
		System.out.println("The componentNames retrieved from API list " + LibraryCarouselfromAPI);

		if (LibraryCarouselfromAPI.contains(LibraryCarouselfromUI)) {

			Logger.log("The categoryName list matches from the list : "
					+ LibraryCarouselfromAPI.equals(LibraryCarouselfromUI));
		} else {

			Logger.log("The categoryNames does not matched in the list");
		}

		try {
			Assert.assertTrue("The list did not match ", LibraryCarouselfromAPI.contains(LibraryCarouselfromUI));
		} catch (AssertionError e) {
			Logger.error("Assertion failed: " + e.getMessage());
		}

	}

	@And("Validate the curated list of titles from the {string} carousel for {string} and {string}")
	public void Validate_the_curated_list_of_titles_from_the_featured_carousel(String categoryName, String profileId,
			String profileType) {

		curatedResponseList = APIClient.getCuratedResponse(profileType, profileId, entityListId);
		List<String> isbnListAPI = new ArrayList<String>();
//		List<CuratedResponseItem> curatedResponseItem = curatedResponseList.get(0).getItems();

		System.out.println("The component Name " + categoryName);
		for (CuratedResponse apiResponse : curatedResponseList) {
			String listNames = apiResponse.getListName();

			if (listNames.equalsIgnoreCase(categoryName)) {
				listID = apiResponse.getListId();
				System.out.println("The list ID is " + listID);
				
				List<CuratedResponseItem> curatedResponseItem = apiResponse.getItems();
				
				for (CuratedResponseItem item : curatedResponseItem) {
					String isbn = item.getIsbn();
					isbnListAPI.add(isbn);
					System.out.println("isbnList from API: " + isbn);

				}
			}
		}
		System.out.println("The ISBN's list from API " + isbnListAPI);

		List<String> isbListfromUI = new ArrayList<String>();
		isbListfromUI = library.get_LibCarouselTitlesISBN(categoryName, profileType);

		System.out.println("The ISBN's list from UI " + isbListfromUI);

		try {
			Assert.assertTrue(isbnListAPI.equals(isbListfromUI));

		} catch (AssertionError e) {
			Logger.error("List of isbn's are not matching with API and UI:" + isbnListAPI.contains(isbListfromUI));
		}

	}

	@And("Compare the results displayed from API and UI after clicking see all link for {string}, {string}")
	public void Compare_the_results_displayed_from_see_all_link(String name, String profileType) {

		curatedResponseList = APIClient.getCuratedResponse(profileType, "", entityListId);

		for (CuratedResponse apiResponse : curatedResponseList) {
			String listNames = apiResponse.getListName();
			if (listNames.equalsIgnoreCase(name)) {
				paramCatagory = apiResponse.getListId();
				System.out.println("value of ID " + paramCatagory);
				break;
			}
		}

		featureListResponse = APIClient.getFeaturedListResponse(paramCatagory, profileType);
		HashMap<String, String> isbnAudienceMap = new HashMap<String, String>();

		int apiCount = Integer
				.parseInt(featureListResponse.getSearchTitleResult().getSearchTitleResult().getResultCount());
		System.out.println("total count of result from API for caraousel is " + apiCount);

		try {
			Assert.assertEquals("Count not matched with the API and UI result ", apiCount,
					Librarybasedsubscription_Stepdef.ListPageCount);
		} catch (AssertionError e) {
			Logger.error("Assertion failed: " + e.getMessage());
		}
//		Assert.assertEquals("Count mismatch result ", apiTotalResultCount, Librarybasedsubscription_Stepdef.ListPageCount);

		List<api.magicWallList.Title> titles = featureListResponse.getSearchTitleResult().getSearchTitleResult()
				.getTitlesList().getTitle();
		List<String> isbnListFromAPI = new ArrayList<String>();

		for (api.magicWallList.Title title : titles) {

			String audience = title.getAudience();
			String isbn = title.getiSBN();
			isbnAudienceMap.put(isbn, audience);
			isbnListFromAPI.add(isbn);
			System.out.println("extracted audience code for title : " + isbn + " is : " + audience);
		}

	}

	@Then("user should able to see the search results count for search term {string} for a searchType {string} and {string}")
	public void user_should_able_to_see_the_search_results_count(String searchTerm, String searchType,
			String profileType) {

		int get_EbookSearchCount = across.get_EbookSearchCount();
		Logger.log("Ebook Search Count: " + get_EbookSearchCount);
		int get_EAudioSearchCount = across.get_EAudioSearchCount();
		Logger.log("EAudio Search Count: " + get_EAudioSearchCount);

		SearchTitleResponse search = APIClient.getSearchTitleResponse(searchTerm, searchType, "publicationDate",
				profileType);

		int searchCountEbookFromAPI = Integer
				.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());

		int searchCountAudiobookFromAPI = Integer
				.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());

		Assert.assertEquals("Ebook count did not match", get_EbookSearchCount, searchCountEbookFromAPI);
		Assert.assertEquals("audio count did not match", get_EAudioSearchCount, searchCountAudiobookFromAPI);

	}

	@Given("user should not be able to view Only Vocational carousel")
	public void user_should_not_be_able_to_view_only_vocational_carousel() {

//		HashMap<String, ArrayList> CategoryMap = new HashMap<String, ArrayList>();

		getTitleResponse = APIClient.getLibraryResponse("2");
		assertNotNull("API response is null", getTitleResponse);

		List<Category> categories = getTitleResponse.getGetTitleResponse().getGetTitleResult().getCatagories()
				.getCategory();

		List<String> LibraryCarouselfromAPI = new ArrayList<String>();

		for (Category categoryName : categories) {
			String name = categoryName.getParamCatagoryName();
			LibraryCarouselfromAPI.add(name);
			Logger.log("Extracted componenet Name from API is : " + name);

		}
		if (!LibraryCarouselfromAPI.contains("Vocational")) {

			Logger.log("Vocational category is not present for the Teen user");
		} else {

			Logger.log("Vocational category is present for the Teen user");
		}
	}

	@And("user clicks on Featured List from hamburger menu")
	public void user_clicks_on_featured_list_from_hamburger_menu() {
		hamburgerMenu.click_HamburgerMenu();
		featurelist.click_adultprofileFeaturedlist();
	}

	@And("User clicks on Only Vocational list")
	public void user_clicks_on_only_vocational_list() {
		featurelist.click_OnlyVocational();
	}

	@And("user should be displayed with {int} results")
	public void user_should_be_displayed_with_results(Integer int1) {
		int count = login.get_CategoryCounts();
		System.out.println("Result Count-------" + count);
	}

	@And("user should not be able to view Teens carousel")
	public void user_should_not_be_able_to_view_teens_carousel() {

		getTitleResponse = APIClient.getLibraryResponse("3");
		assertNotNull("API response is null", getTitleResponse);

		List<Category> categories = getTitleResponse.getGetTitleResponse().getGetTitleResult().getCatagories()
				.getCategory();

		List<String> LibraryCarouselfromAPI = new ArrayList<String>();

		for (Category categoryName : categories) {
			String name = categoryName.getParamCatagoryName();
			LibraryCarouselfromAPI.add(name);
			Logger.log("Extracted componenet Name from API is : " + name);

			if (!LibraryCarouselfromAPI.contains("Teen")) {

				Logger.log("Teen category is not present for the Kid user");
			} else {

				Logger.log("Teen category is present for the Kid user");
			}
		}

	}

	@And("User clicks on Teens list")
	public void user_clicks_on_teens_list() {
		featurelist.click_Teens();
	}

	@And("user clicks on save Interest button after selecting some reading interests")
	public void user_clicks_on_save_Interest_button_after_selecting_some_reading_interests() {
		featurelist.click_SaveInterests();
	}

	@Then("validate the {string} carousel and click on see all link")
	public void validate_the_carousel_and_click_on_see_all_link(String Carouselname) {

		Logger.log("The carousel name displayed is " + Carouselname);
		featurelist.clickSeeAll_Interest();

		Librarybasedsubscription_Stepdef.ListPageCount = login.get_CategoryCounts();
		Logger.log(Carouselname + " List page count : " + Librarybasedsubscription_Stepdef.ListPageCount);

	}

	@And("compare the results count displayed from API and UI after clicking see all link for {string}, {string} and {string}")
	public void compare_the_results_count_displayed_from_API_and_UI_after_clicking_see_all_link(String profileType, String isPrimary, String profileId) {
		List<String> isbnListFromAPI = new ArrayList<String>();
		List<String> isbnListfromUI = new ArrayList<String>();
		recommendationResponse = APIClient.getRecommendationsResponse(profileType, isPrimary, profileId);
		
		 int totalCount = Integer.parseInt(recommendationResponse.getTotalCount());
		 Logger.log("Total count retrieved from API response is " + totalCount);
		 
		 Assert.assertEquals("Total count did not match", Librarybasedsubscription_Stepdef.ListPageCount, totalCount);
		 
		 isbnListfromUI = login.get_TitlesISBN();
		 Logger.log("The list of retrieved ISBNs from UI is " + isbnListfromUI);
		 
		 List<RecommendedTitle> titles = recommendationResponse.getRecommendedTitles();
		 for ( RecommendedTitle title : titles) {

				String isbn = title.getIsbn();
				isbnListFromAPI.add(isbn);
				Logger.log("isbnList from API: " + isbn);
		 }
		 Logger.log("The list of retrieved ISBNs from API is " + isbnListFromAPI);
		 if (isbnListFromAPI.contains(isbnListfromUI)) {

				Logger.log("The ISBNs list matches from the UI list : "
						+ isbnListFromAPI.equals(isbnListfromUI));
			} else {

				Logger.error("The categoryNames does not matched in the list");
			}
		 
		
		 
	}

}
