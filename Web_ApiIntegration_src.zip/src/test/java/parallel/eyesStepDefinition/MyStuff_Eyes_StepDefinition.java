package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class MyStuff_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of the myShelf screen with no history CTA")
	public void capture_the_screenshot_of_the_myShelf_screen_with_no_history_CTA() {
		eyes.checkWindow("myShelfScreenWithNoHistoryCTA");
	}
	
	@Then("capture the screenshot of the myShelf screen with my stuff options CTA")
	public void capture_the_screenshot_of_the_myShelf_screen_with_my_stuff_options_CTA() {
		eyes.checkWindow("myShelfScreenWithNoHistoryCTA");
	}

	@Then("capture the screenshot of the checkouts screen")
	public void capture_the_screenshot_of_the_checkouts_screen() {
		eyes.checkWindow("checkoutsScreen");
	}
	
	@Then("capture the screenshot of the checkouts filter option")
	public void capture_the_screenshot_of_the_checkouts_fiter_option() {
		eyes.checkWindow("checkoutsFiterOption");
	}
	
	@Then("capture the screenshot of the myShelf screen with multiple filter options")
	public void capture_the_screenshot_of_the_myShelf_screen_with_multiple_filter_option() {
		eyes.checkWindow("myShelfScreenWithNoHistoryCTA");
	}
	
	@Then("capture the screenshot of the holds screen")
	public void capture_the_screenshot_of_holds_screen() {
		eyes.checkWindow("holdsScreen");
	}
	
	@Then("capture the screenshot of the holds filter option ")
	public void capture_the_screenshot_of_holds_filter_option() {
		eyes.checkWindow("holdsFilterOption");
	}
	
	@Then("capture the screenshot of the wishlist screen")
	public void capture_the_screenshot_of_wishlist_screen() {
		eyes.checkWindow("wishlistScreen");
	}
	
	@Then("capture the screenshot of the wishlist filter option")
	public void capture_the_screenshot_of_wishlist_filter_option() {
		eyes.checkWindow("wishlistFiterOption");
	}
	
	@Then("capture the screenshot of the history screen")
	public void capture_the_screenshot_of_the_history_screen() {
		eyes.checkWindow("historyScreen");
	}
	
	@Then("capture the screenshot of the history filter option")
	public void capture_the_screenshot_of_history_filter_option() {
		eyes.checkWindow("myShelfScreenWithNoHistoryCTA");
	}
	
	@Then("capture the screenshot of the recommendation screen")
	public void capture_the_screenshot_of_the_recommendation_screen() {
		eyes.checkWindow("recommendationsScreen");
	}
	
	
	
}
