package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class TitleDetails_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of the title details screen")
	public void capture_the_screenshot_of_the_title_details_screen() {
		eyes.checkWindow("titleDetailsScreen");
	}

	@Then("capture the screenshot of the title details screen after adding title to wishist")
	public void capture_the_screenshot_of_the_title_details_screen_after_adding_title_to_wishist() {
		eyes.checkWindow("titleDetailsScreenAfterAddingTitlesToWishList");
	}
	
	@Then("capture the screenshot of the title details screen after removing the title from wishlist")
	public void capture_the_screenshot_of_the_title_details_screen_after_removing_the_titlle_from_wishlist() {
		eyes.checkWindow("titleDetailsScreenAfterRemovingTitlesToWishList");
	}

	@Then("capture the screenshot of the title details screen after putting title on hold")
	public void capture_the_screenshot_of_the_title_details_screen_after_putting_title_on_hold() {
		eyes.checkWindow("titleDetailsScreenAfterPuttingTitlesOnHold");
	}

	@Then("capture the screenshot of the title details screen after clicking on viewAll complete synopsis")
	public void capture_the_screenshot_of_the_title_details_screen_after_clicking_on_view_all_complete_synopsis() {
		eyes.checkWindow("titleDetailsScreenAfterClickingOnViewAllCompleteSynopsis");
	}

	@Then("capture the screenshot of the title details screen after clicking on viewLess synopsis")
	public void capture_the_screenshot_of_the_title_details_screen_after_clicking_on_view_less_synopsis() {
		eyes.checkWindow("titleDetailsScreenAfterClickingOnViewLessSynopsis");
	}

	@Then("capture the screenshot of the search results screen after clicking author name")
	public void capture_the_screenshot_of_the_search_results_screen_after_clicking_author_name() {
		eyes.checkWindow("searchDetailsScreenAfterClickingAuthorName");
	}

	@Then("capture the screenshot of the title details screen after clicking details tab")
	public void capture_the_screenshot_of_the_title_details_screen_after_clicking_details_tab() {
		eyes.checkWindow("titleDetailsScreenAfterClickingOnViewAllCompleteSynopsis");
	}

	@Then("capture the screenshot of the title details screen after clicking on book series")
	public void capture_the_screenshot_of_the_title_details_screen_after_clicking_on_book_series() {
		eyes.checkWindow("titleDetailsScreenAfterClickingOnViewAllCompleteSynopsis");
	}

	@Then("capture the screenshot of the title details screen after clicking on the tool tip")
	public void capture_the_screenshot_of_the_title_details_screen_after_clicking_on_the_tool_tip() {
		eyes.checkWindow("titleDetailsScreenAfterCickingOnTheToolTip");
	}

	@Then("capture the screenshot of the title details screen after removing the title from hold")
	public void capture_the_screenshot_of_the_title_details_screen_after_removing_the_title_from_hold() {
		eyes.checkWindow("titleDetailsScreenAfterRemovingTitesFromHold");
	}

	@Then("capture the screenshot of the title details screen after closing the pop up")
	public void capture_the_screenshot_of_the_title_details_screen_after_closing_the_pop_up() {
		eyes.checkWindow("titleDetailsScreenAfterCickingClosingThePopup");
	}

}
