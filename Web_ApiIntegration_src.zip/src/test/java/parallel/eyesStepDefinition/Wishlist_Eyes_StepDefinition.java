package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class Wishlist_Eyes_StepDefinition {
	
Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of the updated wishlist screen after book is removed from wishlist")
	public void capture_the_screenshot_of_the_myShelf_updated_wishlist_screen() {
		eyes.checkWindow("updatedWishlistScreenAfterBookRemoved");
	}
	
	@Then("capture the screenshot list view of the wishlist screen")
	public void screenshotListViewWishListScreen() {
		eyes.checkWindow("screenshotListViewWishListScreen");
	}
	
	@Then("capture the screenshot grid view of the wishlist screen")
	public void screenshotGridViewWishListScreen() {
		eyes.checkWindow("screenshotGridViewWishListScreen");
	}

}
