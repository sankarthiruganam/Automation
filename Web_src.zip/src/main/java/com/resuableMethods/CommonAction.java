package com.resuableMethods;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.interactions.touch.TouchActions;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class CommonAction {

	public Properties props;

	public void findByClick(WebElement element) {

		if (element.isDisplayed() && element.isEnabled()) {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
			WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
			webelement.click();
		} else {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 25);
			WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
			js.executeScript("arguments[0].click();", webelement);
		}
	}

	public void ClickOnWebElement(WebElement element) {

		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.click();

	}
	
	public void waitForInvisibilityOf(String string) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);		
		WebElement webelement = DriverManager.getDriver().findElement(By.xpath(string));
		exwait.until(ExpectedConditions.invisibilityOf(webelement));
		
	}

	public void visibilityListWait(List<WebElement> element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
			exwait.until(ExpectedConditions.visibilityOfAllElements(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void inVisibilityWait(WebElement element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 35);
			exwait.until(ExpectedConditions.invisibilityOf(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void visibilityWait(WebElement element) {
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
			exwait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void WaitForWebElement(WebElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		exwait.until(ExpectedConditions.visibilityOf(element));
	}

	public void WaitForListWebElement(List<WebElement> element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		exwait.until(ExpectedConditions.visibilityOfAllElements(element));
	}

	public void highLighterMethod(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}

	public void SendKeysOnWebElement(WebElement element, String Value) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.clear();
		webelement.sendKeys(Value);
	}

	public void jsClick(WebElement element) {
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].click();", webelement);
	}

	public void waitFor(int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void waitForDocumentToLoad() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 7);
 
		// Wait for page load to complete (wait until document.readyState is 'complete')
		wait.until(webDriver -> ((String) js.executeScript("return document.readyState")).equals("complete"));
	}
	
	public static void javascriptScroll(WebElement element) {
		waitForDocumentToLoad();
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');",
				element);
		waitForDocumentToLoad();
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
		js.executeScript("arguments[0].scrollIntoView();", element);
 
	}

	public void scrollingDown(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wt = new WebDriverWait(DriverManager.getDriver(), 100);
		wt.until(ExpectedConditions.visibilityOf(element));
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	public void SendKeysEnter(WebElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 15);
		WebElement webelement = exwait.until(ExpectedConditions.visibilityOf(element));
		webelement.clear();
		webelement.sendKeys(Keys.ENTER);

	}

	public void pagescrollDown() throws IOException, Exception {
		for (int i = 0; i <= 1; i++) {
			waitFor(3000);
			javaScriptScrollToEnd();
		}
	}

	public void scrollingup(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		WebDriverWait wt = new WebDriverWait(DriverManager.getDriver(), 100);
		wt.until(ExpectedConditions.visibilityOf(element));
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void javaScriptScrollToEnd() {
		waitFor(2000);
		((JavascriptExecutor) DriverManager.getDriver())
				.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public void switchToTabs(String currentHandle) {

		Set<String> handles = DriverManager.getDriver().getWindowHandles();
		for (String actual : handles) {
			if (!actual.equalsIgnoreCase(currentHandle)) {
				DriverManager.getDriver().switchTo().window(actual);
			}
		}
	}

	public int generateRandomNumber() {
		Random rand = new Random();
		int randNumber = rand.nextInt(100000);
		return randNumber;

	}

	public boolean isElementPresent(WebElement e)

	{
		waitFor(2000);
		boolean flag = true;
		try {
			e.isDisplayed();
			flag = true;
		} catch (Exception a) {
			flag = false;
		}
		return flag;
	}

	public void loadData() throws IOException {
		props = new Properties();
		String env = System.getenv("ENVIRONMENT");
		if (env == null) {
			env =System.getProperty("ENVIRONMENT");
			
		}
		if(env.equalsIgnoreCase("QA2"))
		{
		FileInputStream ip = new FileInputStream("./src/test/resources/config/QA2.properties");
		props.load(ip);
		}
		else if (env.equalsIgnoreCase("UAT"))
		{
			FileInputStream ip = new FileInputStream("./src/test/resources/config/UAT.properties");
			props.load(ip);	
		}else if (env.equalsIgnoreCase("QA1"))
		{
			FileInputStream ip = new FileInputStream("./src/test/resources/config/QA1.properties");
			props.load(ip);
		}
	}

	public String getData(String data) throws IOException {
		loadData();
		data = props.getProperty(data);
		return data;
	}

	public String RandomStringGenerate() {
		return RandomStringUtils.randomAlphanumeric(3);
	}

	public void swipeDown() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();

		int scrollStart = (int) (dimension.getHeight() * 0.5);

		int scrollEnd = (int) (dimension.getHeight() * 0.2);

		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart))

				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(0, scrollEnd))

				.release().perform();

	}

	public void takeScreenshot(WebDriver driver, String filename) throws IOException {
		waitFor(2000);
		File sc = (File) ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sc, new File(filename));
	}

	
	public void mouseHover(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.moveToElement(element).build().perform();
	}
	
	

}
