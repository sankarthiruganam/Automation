package com.utilities;

import java.io.File;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.presentation.PresentationMode;

public class ReportWeb {

	public static String ConfigurationFile = System.getProperty("user.dir")
			+ "/src/test/resources/config/config.properties";

	public static Properties prop = new ConfigReader().init_prop();

	static List<String> JsonFiles = new ArrayList<String>();
	static String platform;
	static String BrowserVersion;

	static String System_Info;

	static String OS_Version;
	static String build;
	static String platformVersion;
	static String deviceName;
	static	String browserName;

	static {
		try {
			browserName = System.getProperty("browser");
			JsonFiles.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void generateReport(String JsonFile) throws IOException {

		if (browserName.equalsIgnoreCase("chrome")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("platform", System.getProperty("browser"));
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
			config.addClassifications("BrowserVersion", "110");
			config.addClassifications("System_Info", "Windows OS");
			config.addClassifications("OS_Version", "10.0");
			JsonFiles.add(JsonFile);
			ReportBuilder report = new ReportBuilder(JsonFiles, config);
			report.generateReports();
		} else if (browserName.equalsIgnoreCase("safari")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("Platform", "Web");
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
			config.addClassifications("Browser Name", System.getProperty("browser"));
			config.addClassifications("BrowserVersion", "14");
			config.addClassifications("System Info", "Mac OS ");
		} else if (browserName.equalsIgnoreCase("edge")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("Platform", "Web");
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
			config.addClassifications("Browser Name", System.getProperty("browser"));
			config.addClassifications("BrowserVersion", "110");
			config.addClassifications("System Info", "Windows OS");
			config.addClassifications("OS Version", "10.0");
		} else if (browserName.equalsIgnoreCase("firefox")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("Platform", "Web");
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
			config.addClassifications("Browser Name", System.getProperty("browser"));
			config.addClassifications("BrowserVersion", "110");
			config.addClassifications("System Info", "Windows OS");
			config.addClassifications("OS Version", "10.0");
		} else if (browserName.equalsIgnoreCase("android")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("Platform Name", System.getProperty("browser"));
			config.addClassifications("DeviceName", "Samsung Galaxy Tab S8");
			config.addClassifications("OSVersion", "12.0");
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
		} else if (browserName.equalsIgnoreCase("iOS")) {
			Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
					"KidsZoneWebAutomationReport");
			config.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			config.addClassifications("Platform Name", System.getProperty("browser"));
			config.addClassifications("DeviceName", "iPad Air 4");
			config.addClassifications("OSVersion", "14");
			config.addClassifications("Before Suite", System.getProperty("Start_Time"));
			config.addClassifications("After Suite", System.getProperty("End_Time"));
		}



	}

}
