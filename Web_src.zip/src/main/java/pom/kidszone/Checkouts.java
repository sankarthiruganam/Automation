package pom.kidszone;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class Checkouts extends CommonAction {

	TitleDetails title = new TitleDetails(DriverManager.getDriver());

	public Checkouts(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_labelCheckouts")
	public WebElement btn_CtaCheckouts;

	@FindBy(xpath = "//div[@class='mystuff-lists ng-star-inserted']")
	private WebElement btn_TitleBooks;

	@FindBy(id = "loc_btnSort")
	private WebElement btn_SortIcon;

	@FindBy(xpath = "//div[@class='no-stuffs ng-star-inserted']")
	private WebElement txt_No_Checkouts;

	@FindBy(id = "loc-Grid")
	private WebElement btn_GridView;

	@FindBy(xpath = "//ul[@class='breadcrumb kz-breadcrumb']")
	private WebElement link_BreadCrumb;

	@FindBy(id = "loc_btnFilter")
	public WebElement btn_FilterIcon;

	@FindBy(id = "loc_List")
	private WebElement Checkouts_ListViewBtn;

	@FindBy(xpath = "(//*[@class='mystuff-grids ng-star-inserted'])[1]")
	private WebElement Checkouts_ListViewDisplay;

	@FindBy(xpath = "(//*[@class='kz-stuff-book-image'])[1]")
	public WebElement title_Card_Display;

	@FindBy(xpath = "(//p[@class='author-name single-ellipsis'])[1]")
	private WebElement Title_AuthorName;

	@FindBy(xpath = "(//h3[@class='card-title single-ellipsis'])[1]")
	private WebElement title_Name;

	@FindBy(xpath = "(//*[@class='due-duration kz-time-remain-lbl'])[1]")
	private WebElement title_Duration;

	@FindBy(xpath = "(//*[@svgicon='kz-three-dots-icon'])[1]")
	private WebElement btn_more_Option;

	@FindBy(xpath = "//a[normalize-space()='Download']")
	private WebElement btn_Download;

	@FindBy(xpath = "//button[normalize-space()='Return']")
	private WebElement btn_Return;

	@FindBy(xpath = "(//div[@class='kz-btn-group'])[1]")
	private WebElement btn_title_group;

	@FindBy(id = "loc_Recently Checkedout")
	private WebElement sort_Latest_Checkout;

	@FindBy(id = "loc_Due Date")
	private WebElement sort_Due_Date;

	@FindBy(id = "loc_A-Z")
	private WebElement sort_AtoZ;

	@FindBy(xpath = "//div[@class='profile-details']//following-sibling::p")
	private List<WebElement> manageProf_lbl_profType;

	@FindBy(xpath = "//div[@role='button']")
	private List<WebElement> manageProf_pencilIcon_editProfile;

	@FindBy(id = "loc_labelHistory")
	private WebElement history_cta;

	@FindBy(xpath = "//a[@href=\"/MyStuff?type=history\"]")
	private WebElement history_cta_in_axis360Only;

	@FindBy(id = "loc_labelHolds")
	private WebElement holds_cta;

	@FindBy(id = "loc_labelPurchase Requests")
	private WebElement recommendations_cta;

	@FindBy(id = "loc_labelWishlist")
	private WebElement wishlist_cta;

	@FindBy(id = "breadcrumb-link-0")
	private WebElement btn_home_cta;

	@FindBy(id = "loc_btnSearchicons")
	private WebElement Btn_search_icon;

	@FindBy(xpath = "//input[@aria-required='false']")
	private WebElement Input_text_in_search_bar;

	@FindBy(xpath = "//button[@class='kz-search-button']")
	private WebElement Enter_search_icon;

	@FindBy(xpath = "//p[text()='Failure!']")
	private WebElement failure_msg;

	@FindBy(xpath = "//p[text()='Success!']")
	private WebElement success_msg;

	@FindBy(xpath = "//h2[text()='Children']")
	private WebElement children_carousel;

	@FindBy(xpath = "(//button[@aria-label='more option'])[1]")
	private WebElement more_Options;

	@FindBy(xpath = "//button[@alt='renew']")
	public WebElement renew_option;

	@FindBy(xpath = "//button[@alt='return']")
	public WebElement return_option;

	@FindBy(xpath = "//button[contains(text(),'Cancel Request')]")
	private WebElement cancel_recommendation;

	@FindBy(id = "loc_btnSelected filter_items All")
	private WebElement All_option_in_filter;

	@FindBy(id = "loc_btnSelected filter_items eBook")
	private WebElement eBook_option_in_filter;

	@FindBy(id = "loc_btnSelected filter_items eAudio")
	private WebElement Audio_option_in_filter;

	@FindBy(id = "loc_btnSelected filter_items Video")
	private WebElement video_option_in_filter;

	@FindBy(id = "loc_btnSelected filter_items Videobooks")
	private WebElement vbook_option_in_filter;

	@FindBy(xpath = "(//*[@class='mat-icon notranslate book-poster-icon mat-icon-no-color'])[1]")
	private WebElement eBook_icon_validation;

	@FindBy(xpath = "(//*[contains(text(),'Checkout')])[15]")
	private WebElement click_Checkout_title;

	@FindBy(xpath = "(//button[@aria-label='more option'])[15]")
	private WebElement more_options_to_return;

	@FindBy(xpath = "//button[text()=' Suspend Hold ']")
	private WebElement suspend_Hold_cta;

	@FindBy(xpath = "//span[text()='Unsuspend']")
	private WebElement unsuspend_Hold_cta;

	@FindBy(id = "mat-select-0")
	private WebElement myStuff_validation;

	@FindBy(xpath = "(//*[@class='kz-card-btn kz-card-btn-grid primary-action ng-star-inserted'])[1]")
	private WebElement validate_placeHold_primaryCta;

	@FindBy(xpath = "(//*[@class='kz-card-btn kz-card-btn-grid primary-action ng-star-inserted'])[1]")
	private WebElement validate_checkout_primary;

	@FindBy(xpath = "//*[@alt='remover from wishlist']")
	private WebElement Click_remove_Wishlist_secondaryCta;

	@FindBy(xpath = "(//*[@aria-label='more option'])[2]")
	public WebElement click_second_moreOption;

	@FindBy(xpath = "(//button[@class='mat-focus-indicator action-expand action-links mat-menu-item'])[1]")
	private WebElement click_secodaryCta_suspendHold;

	@FindBy(xpath = "(//span[text()='Remove Hold'])[1]")
	private WebElement click_primaryCta_removeHold;

	@FindBy(id = "loc_txtHolds")
	private WebElement holdPage;

	@FindBy(xpath = "")
	private WebElement removeHold;

	@FindBy(xpath = "(//button[@alt='add to wishlist'])")
	public WebElement addToWish;

	@FindBy(xpath = "(//button[@alt='remover from wishlist'])[1]")
	private WebElement removeWish;

	@FindBy(xpath = "(//span[contains(text(),'Read')])[1]")
	private WebElement primaryCta_readNow;
	
	@FindBy(xpath = "(//span[contains(text(),'Read')])[2]")
	private WebElement Tier3_primaryCta_readNow;

	@FindBy(xpath = "//span[text()='Remove Hold']")
	private WebElement secondaryCta_removeHold;

	@FindBy(xpath = "(//span[contains(text(),'Listen')])[1]")
	public WebElement primaryCta_listenNow;
	
	@FindBy(xpath = "(//span[contains(text(),'Listen')])[2]")
	public WebElement primaryCta_listenNow_Tier3;
	
	@FindBy(xpath = "(//*[contains(text(),'Read')])[1]")
	public WebElement primaryCta_Read;

	@FindBy(xpath = "(//span[contains(text(),'Remove')])[1]")
	public WebElement primaryCta_Removetitle;

	@FindBy(xpath = "(//span[contains(text(),'Place Hold')])")
	private List<WebElement> btn_PlaceHolds;

	@FindBy(xpath = "(//span[contains(text(),'Checkout')])")
	private List<WebElement> btn_checkouts;

	@FindBy(xpath = "//a[contains(text(),'CHECKOUTS')]")
	private WebElement checkoutFromMenuOldUI;

	@FindBy(xpath = "//div[@class='card-body']")
	private List<WebElement> titlesInCheckout;

	@FindBy(xpath = "(//a[contains(text(),'Listen Now')])[1]")
	private WebElement secondaryCta_ListenNow;

	@FindBy(xpath = "(//*[@class='mystuff-card-image'])[1]")
	private WebElement checkout_txt;

	@FindBy(id = "app-navbar")
	private WebElement header_navbar;
	
	@FindBy(id = "loc_btnSelected Video")
	public WebElement video_Option_inFilter;
	
	@FindBy(id = "loc_btnSelected vBook")
	public WebElement vBook_Option_inFilter;

	@FindBy(xpath = "//button[contains(text(),' Checkout ')]")
	public WebElement secondaryCta_Checkout;
	
	@FindBy(xpath = "//button[contains(text(),' Add to Wishlist ')]")
	public WebElement secondaryCta_AddtoWishlist;
	
	@FindBy(xpath = "(//span[text()='Checkout'])[1]")
	public WebElement primaryCta_CheckoutInWishScreen;
	
	@FindBy(xpath = "(//*[contains(text(),' Suspend Hold ')])[1]")
	public WebElement secondaryCta_SuspendHold;
	
	@FindBy(id = "loc_confirmbtnOK")
	public WebElement return_confirm;
	
	@FindBy(xpath = "//div[@class='duration-sec ng-star-inserted']")
	public List<WebElement> Bookformat ;
	
	@FindBy(xpath = "//a[@id='loc_labelcheckouts']/span")
	public WebElement CheckoutCount ;
	
	@FindBy(xpath = "//a[@id='loc_labelholds']/span")
	public WebElement HoldsCount ;
	
	@FindBy(xpath = "//a[@id='loc_labelwishlist']/span")
	public WebElement WishListCount ;
	
	@FindBy(xpath = "//a[@id='loc_labelhistory']/span")
	public WebElement CheckoutHistoryCount ;
	
	@FindBy(xpath = "(//button[@aria-label='more option'])[2]")
	public WebElement Tier3_moreoptions ;
	
	@FindBy(xpath = "//*[@class='mystuff-card-image']")
	public List<WebElement> mystuffcardimg ;
	
	@FindBy(xpath = "(//button[@class='btn-primary btn-primary-blue ng-star-inserted']/span[contains(text(),'Checkout')])[2]")
	public WebElement tier3Checkout ;
	
	@FindBy(xpath = "(//div[@class='container-fluid'])[1]")
	public WebElement Reader_headerbar ;
	
	@FindBy(xpath = "//div[@class='page-current']")
	public WebElement Reader_pageNumber;

	@FindBy(xpath = "//button[@id='right-page-btn']/span[@class='icon  icon-arrow-left']")
	public WebElement Reader_RightArrow;
	
	@FindBy(xpath = "(//span[contains(text(),'Listen')])[2]")
	public WebElement tier3ListenCTA ;
	
	@FindBy(id = "btnNext")
	public WebElement EAudio_nextbtn ;
	
	@FindBy(xpath = "//div[@class='pagination-current']")
	public WebElement EAudio_playerTiming ;
	
	@FindBy(xpath = "//button[contains(text(),'Checkout')]")
	public WebElement checkoutHistory_SecondaryCTA ;
	
	@FindBy(xpath = "//*[contains(text(),'Remove')]")
	public WebElement WishListSecondaryCTA_Remove ;
	
	@FindBy(xpath = "//button[contains(@aria-label,'Wishlist')]")
	private WebElement Thirdparty_Wishlist;
	
	@FindBy(id = "toast-description")
	private WebElement ToastMsg_Wishlist;
	
	@FindBy(id = "svg-spinner")
	private WebElement Reader_spinner;
	
	@FindBy(id = "epub-reader-container")
	private WebElement Reader_container;
	
	@FindBy(id = "wdg-slider-input")
	private WebElement EAudio_sliderbar;
	
	
	public WebElement getCheckoutCount() {
		return CheckoutCount;
	}


	public WebElement getHeader_navbar() {
		return header_navbar;
	}

	
	public WebElement getVideo_option_in_filter() {
		return video_option_in_filter;
	}

	public WebElement getVbook_option_in_filter() {
		return vbook_option_in_filter;
	}

	public WebElement getSecondaryCta_ListenNow() {
		return secondaryCta_ListenNow;
	}

	public List<WebElement> getBtn_checkouts() {
		return btn_checkouts;
	}

	public List<WebElement> getBtn_PlaceHolds() {
		return btn_PlaceHolds;
	}

	public WebElement getPrimaryCta_Removetitle() {
		return primaryCta_Removetitle;
	}

	public WebElement getPrimaryCta_listenNow() {
		return primaryCta_listenNow;
	}

	public WebElement getSecondaryCta_removeHold() {
		return secondaryCta_removeHold;
	}

	public WebElement getAddToWish() {
		return addToWish;
	}

	public WebElement getCheckouts_ListViewDisplay() {
		return Checkouts_ListViewDisplay;
	}

	public WebElement getPrimaryCta_readNow() {
		return primaryCta_readNow;
	}

	public WebElement getHoldPage() {
		return holdPage;
	}

	public WebElement getClick_suspendHold() {
		return click_secodaryCta_suspendHold;
	}

	public WebElement getClick_removeHold() {
		return click_primaryCta_removeHold;
	}

	public WebElement getClick_second_moreOption() {
		return click_second_moreOption;
	}

	public WebElement getClick_remove_Wishlist_secondaryCta() {
		return Click_remove_Wishlist_secondaryCta;
	}

	public WebElement getValidate_checkout_primary() {
		return validate_checkout_primary;
	}

	public WebElement getValidate_placeHold_primaryCta() {
		return validate_placeHold_primaryCta;
	}

	public WebElement getMyStuff_validation() {
		return myStuff_validation;
	}

	public WebElement getSuspend_Hold_cta() {
		return suspend_Hold_cta;
	}

	public WebElement getUnsuspend_Hold_cta() {
		return unsuspend_Hold_cta;
	}

	public WebElement getClick_Checkout_title() {
		return click_Checkout_title;
	}

	public WebElement getAll_option_in_filter() {
		return All_option_in_filter;
	}

	public WebElement geteBook_option_in_filter() {
		return eBook_option_in_filter;
	}

	public WebElement getAudio_option_in_filter() {
		return Audio_option_in_filter;
	}

	public WebElement getCancel_recommendation() {
		return cancel_recommendation;
	}

	public WebElement getReturn_option() {
		return return_option;
	}

	public WebElement getRenew_option() {
		return renew_option;
	}

	public WebElement getFailure_checkout() {
		return failure_msg;
	}

	public WebElement getSuccess_msg() {
		return success_msg;
	}

	public WebElement getInput_text_in_search_bar() {
		return Input_text_in_search_bar;
	}

	public WebElement getEnter_search_icon() {
		return Enter_search_icon;
	}

	public WebElement getBtn_search_icon() {
		return Btn_search_icon;
	}

	public WebElement getBtn_home_cta() {
		return btn_home_cta;
	}

	public WebElement getHolds_cta() {
		return holds_cta;
	}

	public WebElement getRecommendations_cta() {
		return recommendations_cta;
	}

	public WebElement getWishlist_cta() {
		return wishlist_cta;
	}

	public WebElement getHistory_cta_in_axis360Only() {
		return history_cta_in_axis360Only;
	}

	public WebElement getHistory_cta() {
		return history_cta;
	}

	public WebElement getSort_Latest_Checkout() {
		return sort_Latest_Checkout;
	}

	public WebElement getSort_Due_Date() {
		return sort_Due_Date;
	}

	public WebElement getBtn_title_group() {
		return btn_title_group;
	}

	public WebElement getSort_AtoZ() {
		return sort_AtoZ;
	}

	public WebElement getBtn_CtaCheckouts() {
		return btn_CtaCheckouts;
	}

	public WebElement getBtn_TitleBooks() {
		return btn_TitleBooks;
	}

	public WebElement getBtn_FilterIcon() {
		return btn_FilterIcon;
	}

	public WebElement getBtn_SortIcon() {
		return btn_SortIcon;
	}

	public WebElement getBtn_GridView() {
		return btn_GridView;
	}

	public WebElement getLink_BreadCrumb() {
		return link_BreadCrumb;
	}

	public WebElement getTxt_No_Checkouts() {
		return txt_No_Checkouts;
	}

	public WebElement getTitle_Card_Display() {
		return title_Card_Display;
	}

	public WebElement getTitle_AuthorName() {
		return Title_AuthorName;
	}

	public WebElement getTitle_Name() {
		return title_Name;
	}

	public WebElement getTitle_Duration() {
		return title_Duration;
	}

	public WebElement getBtn_more_Option() {
		return btn_more_Option;
	}

	public WebElement getBtn_Download() {
		return btn_Download;
	}

	public WebElement getBtn_Return() {
		return btn_Return;
	}

	/**********************************
	 * Action methods
	 *********************************************/

	public void click_Sort() {
		try {
			ClickOnWebElement(btn_SortIcon);

		} catch (Exception e) {

			Logger.log("Sort Button is not displayed due to checked out title is not available in checkouts");
		}
	}

	public void click_DueDate() {
		try {
			ClickOnWebElement(sort_Due_Date);

		} catch (Exception e) {

			Logger.log("Sort Button is not displayed due to checked out title is not available in checkouts");
		}
	}

	public void click_AtoZ() {
		waitFor(2000);
		try {
			ClickOnWebElement(sort_AtoZ);

		} catch (Exception e) {

			Logger.log("Sort Button is not displayed due to checked out title is not available in checkouts");
		}
		waitFor(5000);
	}

	public void click_moreOption() {
			waitFor(2000);
			visibilityWait(btn_more_Option);
			jsClick(btn_more_Option);
			waitFor(3000);
		
	}

	public void click_TitleCard() {
		try {
			ClickOnWebElement(btn_title_group);

		} catch (Exception e) {

			Logger.log("Card Title Button is not displayed due to checked out title is not available in checkouts");
		}
	}

	public void select_TeenProfile() {
		WaitForListWebElement(manageProf_lbl_profType);
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Teen")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			} else {

				Logger.log("Teen profile is not available");
			}
		}

	}

	public void select_KidProfile() {
		WaitForListWebElement(manageProf_lbl_profType);
		for (int i = 0; i < manageProf_lbl_profType.size(); i++) {
			if (manageProf_lbl_profType.get(i).getText().contains("Kid")) {
				ClickOnWebElement(manageProf_pencilIcon_editProfile.get(i));
			} else {

				Logger.log("Teen profile is not available");
			}
		}

	}

	public void view_HistoryCta() {
		waitFor(2000);
		try {
			Assert.assertEquals(history_cta.isDisplayed(), true);
		} catch (Exception e) {
			Logger.log("history cta is not displayed");
			e.printStackTrace();
		}
	}

	public void click_Checkouts() {
		try {
			ClickOnWebElement(btn_CtaCheckouts);
		} catch (Exception e) {
			Logger.log("checkout cta is not displayed");
			e.printStackTrace();
		}
	}

	public void click_HoldsCta() {
		try {
			ClickOnWebElement(holds_cta);
		} catch (Exception e) {
			Logger.log("holds cta is not displayed");
			e.printStackTrace();
		}
	}

	public void click_RecommendationsCta() {
		try {
			ClickOnWebElement(recommendations_cta);
		} catch (Exception e) {
			Logger.log("recommendations is not displayed");
			e.printStackTrace();
		}
	}

	public void click_WishListCta() {
		try {
			ClickOnWebElement(wishlist_cta);
		} catch (Exception e) {
			Logger.log("wishlist is not displayed");
			e.printStackTrace();
		}
	}

	public void click_homeCta() {
		waitFor(4000);
		ClickOnWebElement(btn_home_cta);
		waitFor(2000);
	}

	public boolean search_Icon() {
		boolean b = true;
		isElementPresent(Btn_search_icon);
		return b;
	}

	public void click_SearchIcon() {
		jsClick(Btn_search_icon);
		waitFor(2000);
	}

	public void sendTextFromSearchBar() {
		waitFor(2000);
		String text = checkout_txt.getAttribute("alt");
		SendKeysOnWebElement(Input_text_in_search_bar, text);
		jsClick(Enter_search_icon);
		waitFor(3000);

	}

	public void click_HistoryCta() {
		waitFor(2000);
		try {
			ClickOnWebElement(history_cta);
		} catch (Exception e) {
			Logger.log("history cta is not displayed");
			e.printStackTrace();
		}
	}

	public void click_checkout() {
		title.select_availablenowdrop();
		javaScriptScrollToEnd();
		// javascriptScroll(children_carousel);
		waitFor(3000);
		int sum = btn_checkouts.size();
		System.out.println(sum);
		for (int i = 0; i < btn_checkouts.size(); i++) {
			String CheckoutButton = btn_checkouts.get(i).getText();
			System.out.println(CheckoutButton);
			System.out.println(CheckoutButton.contains("Checkout"));
			if (CheckoutButton.contains("Checkout")) {
				waitFor(3000);
				jsClick(btn_checkouts.get(i));
				// ClickOnWebElement(btn_checkouts.get(i));
				break;
			}
		}
	}

	public void success_Message() {
		try {
			Assert.assertEquals(success_msg.isDisplayed(), true);
		} catch (Exception e) {
			Logger.log("success msg is not displayed");
			e.printStackTrace();
		}
	}

	public void failure_Message() {
		try {
			Assert.assertEquals(failure_msg.isDisplayed(), true);
		} catch (Exception e) {
			Logger.log("failure msg is not displayed");
			e.printStackTrace();
		}
	}

	public void renewDropdown() {
		WaitForWebElement(btn_more_Option);
		ClickOnWebElement(more_Options);
		waitFor(2000);
		ClickOnWebElement(renew_option);
		DriverManager.getDriver().navigate().refresh();
	}

	public void returnDropdown() {
//		WaitForWebElement(btn_more_Option);
//		jsClick(more_Options);
		WaitForWebElement(return_option);
		jsClick(return_option);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_cancel__recommendation() {
		WaitForWebElement(btn_more_Option);
		ClickOnWebElement(more_Options);
		waitFor(3000);
		jsClick(cancel_recommendation);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_Filter() {
		visibilityWait(btn_FilterIcon);
		jsClick(btn_FilterIcon);
		//Logger.log("filter is not dispalyed due to checkout title is not available");
	}

	public void filter_Options() {
		waitFor(2000);
		Assert.assertEquals(All_option_in_filter.isDisplayed(), true);
		Assert.assertEquals(eBook_option_in_filter.isDisplayed(), true);
		Assert.assertEquals(Audio_option_in_filter.isDisplayed(), true);
//		Assert.assertEquals(video_Option_inFilter.isDisplayed(), true);
//		Assert.assertEquals(vBook_Option_inFilter.isDisplayed(), true);
//		Logger.log("filter options is not displayed");
//		jsClick(All_option_in_filter);
	}

	public void click_eBook_in_filter() {
		WaitForWebElement(eBook_option_in_filter);
		javascriptScroll(eBook_option_in_filter);
//		jsClick(eBook_option_in_filter);
//		WaitForWebElement(eBook_icon_validation);
//		for (int i = 0; i < eBook_icon_validation.size(); i++) {
//			Assert.assertTrue(eBook_icon_validation.get(i).isDisplayed());
//		}
	}

	public void click_more_option_And_return() {
		WaitForWebElement(more_Options);
		ClickOnWebElement(more_Options);
		waitFor(3000);
		ClickOnWebElement(return_option);
	}

	public void suspendHold() {
		ClickOnWebElement(more_Options);
		ClickOnWebElement(suspend_Hold_cta);
	}

	public void UnsuspendHold() {
		waitFor(2000);
		ClickOnWebElement(unsuspend_Hold_cta);
	}

	public void click_primaryCta_placeHold() {
		waitFor(2000);
		jsClick(validate_placeHold_primaryCta);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_primaryCta_checkout() {
		waitFor(2000);
		jsClick(validate_checkout_primary);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_secondaryCta_removewishlist() {
		DriverManager.getDriver().navigate().refresh();
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(3000);
		jsClick(Click_remove_Wishlist_secondaryCta);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_primaryCTa_removeHold() {
		waitFor(2000);
		jsClick(click_primaryCta_removeHold);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_seconadryCta_removeHold() {
		DriverManager.getDriver().navigate().refresh();
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(3000);
		jsClick(secondaryCta_removeHold);
		DriverManager.getDriver().navigate().refresh();
	}

	public void click_SuspendHold() {
		DriverManager.getDriver().navigate().refresh();
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		WaitForWebElement(click_secodaryCta_suspendHold);
		// waitFor(2000);
		jsClick(click_secodaryCta_suspendHold);
		DriverManager.getDriver().navigate().refresh();
	}

	public void holdScreenCta() {
		if (isElementPresent(suspend_Hold_cta)) {
			jsClick(click_second_moreOption);
			WaitForWebElement(removeHold);
			if (isElementPresent(addToWish)) {
				Assert.assertTrue(addToWish.isDisplayed());
			} else if (isElementPresent(removeWish)) {
				Assert.assertTrue(removeWish.isDisplayed());
			}
		} else if (isElementPresent(unsuspend_Hold_cta)) {
			jsClick(click_second_moreOption);
			WaitForWebElement(removeHold);
			if (isElementPresent(addToWish)) {
				Assert.assertTrue(addToWish.isDisplayed());
			} else if (isElementPresent(removeWish)) {
				Assert.assertTrue(removeWish.isDisplayed());
			}
		}
	}

	public void secondaryCta_AddToWishListAndRemoveWishlist() {
		if (isElementPresent(addToWish)) {
			ClickOnWebElement(addToWish);
			DriverManager.getDriver().navigate().refresh();
			WaitForWebElement(btn_more_Option);

		} else {
			waitFor(2000);
			ClickOnWebElement(removeWish);
			DriverManager.getDriver().navigate().refresh();
			WaitForWebElement(btn_more_Option);
		}
	}

	public void click_removeTitle() {
		WaitForWebElement(primaryCta_Removetitle);
		jsClick(primaryCta_Removetitle);
	}

	public void clickHolds() {
//       javaScriptScrollToEnd();
		// javascriptScroll(children_carousel);
		waitFor(2000);
		WaitForWebElement(btn_PlaceHolds.get(0));
		int sum = btn_PlaceHolds.size();
		System.out.println(sum);
		for (int i = 0; i < btn_PlaceHolds.size(); i++) {
			String HoldButton = btn_PlaceHolds.get(i).getText();
			System.out.println(HoldButton);
			System.out.println(HoldButton.contains("Place Hold"));
			if (HoldButton.contains("Place Hold")) {
				waitFor(3000);
				ClickOnWebElement(btn_PlaceHolds.get(1));
				break;
			}

		}
		waitFor(2000);
	}

	public void removeHoldForSuccessMsg() {
		waitFor(2000);
		jsClick(click_primaryCta_removeHold);
		WaitForWebElement(success_msg);
	}

	public void suspendHoldForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(2000);
		jsClick(click_secodaryCta_suspendHold);
		WaitForWebElement(success_msg);
	}

	public void addToWishlistForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(2000);
		jsClick(addToWish);
		WaitForWebElement(success_msg);
	}

	public void removeWishlistForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(2000);
		jsClick(removeWish);
		WaitForWebElement(success_msg);
	}

	public void cancelRecommendationForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		jsClick(btn_more_Option);
		waitFor(2000);
		jsClick(cancel_recommendation);
		WaitForWebElement(success_msg);
	}

	public void returnForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		ClickOnWebElement(more_Options);
		waitFor(2000);
		ClickOnWebElement(return_option);
		WaitForWebElement(success_msg);
	}

	public void renewForSuccessMsg() {
		WaitForWebElement(btn_more_Option);
		ClickOnWebElement(more_Options);
		waitFor(2000);
		ClickOnWebElement(renew_option);
	}

	public void validateRenewOption() {
		WaitForWebElement(btn_more_Option);
		jsClick(more_Options);
		waitFor(2000);
		if (isElementPresent(renew_option)) {
			System.out.println("renew option is displayed");

		} else {
			System.out.println("renew option is not displayed");
		}
	}

	public void clickCheckOutOldUi() {
		WaitForWebElement(checkoutFromMenuOldUI);
		ClickOnWebElement(checkoutFromMenuOldUI);

	}

	public void clickGrid() {
		WaitForWebElement(btn_GridView);
		ClickOnWebElement(btn_GridView);
	}

	public void clickTitleInCheckoutScreen() {
		for (int i = 0; i < titlesInCheckout.size(); i++) {
			ClickOnWebElement(titlesInCheckout.get(0));

		}
	}

	public void eBookSecondaryCtaHistoryScreen() {
		if (isElementPresent(primaryCta_readNow)) {
			Assert.assertTrue(primaryCta_readNow.isDisplayed());
			Assert.assertTrue(return_option.isDisplayed());
		} else {
			Assert.assertTrue(addToWish.isDisplayed());
		}
	}

	public void audioBookSecondaryCtaHistoryScreen() {
		if (isElementPresent(secondaryCta_ListenNow)) {
			Assert.assertTrue(secondaryCta_ListenNow.isDisplayed());
			Assert.assertTrue(return_option.isDisplayed());

		} else {
			Assert.assertTrue(addToWish.isDisplayed());
		}
	}

	public void validate_ereader_screen() {
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			Logger.log("User able to view and click primary CTA was verified manually");
		} else if (System.getProperty("browser").equalsIgnoreCase("Safari")) {
			Logger.log("User able to view and click primary CTA was verified manually");
		} else {
				visibilityWait(primaryCta_readNow);
				jsClick(primaryCta_readNow);
				waitFor(2000);
				ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
				DriverManager.getDriver().switchTo().window(tabs.get(1));
				waitFor(2000);
				visibilityWait(header_navbar);
				Assert.assertTrue(isElementPresent(header_navbar));
				DriverManager.getDriver().close();
				DriverManager.getDriver().switchTo().window(tabs.get(0));
				waitFor(2000);
			
		}
	}
	
	public void validate_ereader_Tier3screen() {
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			Logger.log("User able to view and click primary CTA was verified manually");
		} else if (System.getProperty("browser").equalsIgnoreCase("Safari")) {
			Logger.log("User able to view and click primary CTA was verified manually");
		} else {
				visibilityWait(Tier3_primaryCta_readNow);
				jsClick(Tier3_primaryCta_readNow);
				ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
				DriverManager.getDriver().switchTo().window(tabs.get(1));
				visibilityWait(header_navbar);
				Assert.assertTrue(isElementPresent(header_navbar));
				DriverManager.getDriver().close();
				DriverManager.getDriver().switchTo().window(tabs.get(0));
				waitFor(2000);
			
			
		}
	}
	public int ReaderPagenumber() {
		String page = Reader_pageNumber.getText();
		String pagano = page.substring(5, 6).trim();
		int page_number = Integer.parseInt(pagano);
		return page_number;
		
	}
	
	public void EbookReader_ReadFewPagesFromTier3() {
			jsClick(Tier3_primaryCta_readNow);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			inVisibilityWait(Reader_spinner);
			visibilityWait(Reader_container);
			mouseHover(DriverManager.getDriver(), Reader_headerbar);
//			jsClick(Reader_headerbar);
			visibilityWait(Reader_pageNumber);
			int initial_pageNo = ReaderPagenumber();
			System.out.println("initial page number------"+initial_pageNo);
//			Assert.assertEquals(initial_pageNo==1, true);
			for (int i = 0; i <=5; i++) {
				mouseHover(DriverManager.getDriver(), Reader_headerbar);
				visibilityWait(Reader_RightArrow);
				jsClick(Reader_RightArrow);
				waitFor(2000);
			}
			visibilityWait(Reader_container);
			mouseHover(DriverManager.getDriver(), Reader_headerbar);
			jsClick(Reader_headerbar);
			int afterMovedfewpages_no = ReaderPagenumber();
			System.out.println("After moved to few pages:------"+afterMovedfewpages_no);
			Assert.assertEquals(initial_pageNo!=0, true);
			waitFor(2000);
			 DriverManager.getDriver().close();
			 DriverManager.getDriver().switchTo().window(tabs.get(0));
		
	}
	
	public void validate_LastReadedPagesFromMystuff_Ebook() {
		jsClick(primaryCta_readNow);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		inVisibilityWait(Reader_spinner);
		visibilityWait(Reader_container);
		mouseHover(DriverManager.getDriver(), Reader_headerbar);
//		jsClick(Reader_headerbar);
		int LastReaded_pageNo = ReaderPagenumber();
		System.out.println("Last readed page number------"+LastReaded_pageNo);
		Assert.assertEquals(LastReaded_pageNo!=0, true);
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		
	}
	
	public void validate_LastListenedTimingFromMystuff_EAudio() {
		boolean b =true;
		jsClick(primaryCta_listenNow);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		inVisibilityWait(Reader_spinner);
		visibilityWait(EAudio_nextbtn);
		waitFor(2000);
//		int LastListened_timing = get_EAudioPlayerTiming();
		if (EAudio_sliderbar.getAttribute("aria-valuenow")!=null) {
			b =true;
			
		}else {
			b=false;
		}
		waitFor(2000);
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		
	}
	
	
	public int get_EAudioPlayerTiming() {
		String get_timing = EAudio_playerTiming.getText();
		String current_timing = get_timing.substring(6,7);
		int EaudioPlayer_timing = Integer.parseInt(current_timing);
		return EaudioPlayer_timing;

	}
	
	public void EAudio_ListenFewPagesFromTier3() {
		jsClick(tier3ListenCTA);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		inVisibilityWait(Reader_spinner);
		visibilityWait(EAudio_nextbtn);
		jsClick(EAudio_nextbtn);
		waitFor(2000);
		int get_EAudioPlayerTiming = get_EAudioPlayerTiming();
		Assert.assertEquals(get_EAudioPlayerTiming!=0, true);
		waitFor(2000);
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		
    }
	

	public void validate_audiobook_screen() {
		waitFor(2000);
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			Logger.log("User able to view and click primary CTA was verified manually");
		} else if (System.getProperty("browser").equalsIgnoreCase("Safari")) {
			waitFor(2000);
			Logger.log("User able to view and click primary CTA was verified manually");
		} else {
			waitForDocumentToLoad();
			visibilityWait(primaryCta_listenNow);
			jsClick(primaryCta_listenNow);
			waitFor(4000);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			WaitForWebElement(header_navbar);
			Assert.assertTrue(isElementPresent(header_navbar));
			DriverManager.getDriver().close();
			DriverManager.getDriver().switchTo().window(tabs.get(0));
			waitFor(2000);
		}
	}
	
	public void validate_audiobook_screen_Tier3() {
		waitFor(2000);
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			Logger.log("User able to view and click primary CTA was verified manually");
		} else if (System.getProperty("browser").equalsIgnoreCase("Safari")) {
			waitFor(2000);
			Logger.log("User able to view and click primary CTA was verified manually");
		} else {
			waitForDocumentToLoad();
			visibilityWait(primaryCta_listenNow_Tier3);
			jsClick(primaryCta_listenNow_Tier3);
			waitFor(4000);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			WaitForWebElement(header_navbar);
			Assert.assertTrue(isElementPresent(header_navbar));
			DriverManager.getDriver().close();
			DriverManager.getDriver().switchTo().window(tabs.get(0));
			waitFor(2000);
		}
	}
	
	public void validate_BookFomat_historyScreen() {
		for (int i = 0; i < Bookformat.size(); i++) {
			if (Bookformat.get(i).getText().equalsIgnoreCase(" eBook ")) {
				Logger.log("Format of this title is eBook");
			}
			else {
				Logger.log("Fomrat of this title is eAudio");
			}
		}

	}
	
	public int pills_CheckoutCount() {
		String count = getCheckoutCount().getText();
		int CheckoutCount = Integer.parseInt(count);
		return CheckoutCount;
	}
	
	public int mystuffpills_getHoldCount() {
		String count = HoldsCount.getText();
		int HoldtCount = Integer.parseInt(count);
		return HoldtCount;
	}
	
	public int mystuffpills_getWishListCount() {
		String count = WishListCount.getText();
		int WishlistCount = Integer.parseInt(count);
		return WishlistCount;
	}
	
	public int mystuffpills_getHistoryCount() {
		String count = CheckoutHistoryCount.getText();
		int HistoryCount = Integer.parseInt(count);
		return HistoryCount;
	}
	
	public void verify_CheckoutpillsCount() {
		int pills_CheckoutCount = pills_CheckoutCount();
		int titleCard_count = mystuffcardimg.size();
		if (pills_CheckoutCount == titleCard_count ) {
			Assert.assertEquals(pills_CheckoutCount!=0, true);
		}

	}
	
	public void click_ReturnCTA() {
		visibilityWait(btn_Return);
		javascriptScroll(btn_Return);
		jsClick(btn_Return);
		waitFor(2000);

	}
	
	public void Tier3_MoreoptionsDropdwn() {
		javascriptScroll(Tier3_moreoptions);
		jsClick(Tier3_moreoptions);
		visibilityWait(btn_Return);

	}
	
	
	public void clickReturnCTA_Tier3() {
		jsClick(btn_Return);
		waitFor(2000);
	}
	
	public void Return_confirmCTA() {
		visibilityWait(return_confirm);
		jsClick(return_confirm);
		waitFor(2000);

	}
	
	public void clickCheckout_Tier3() {
	javascriptScroll(tier3Checkout);
	jsClick(tier3Checkout);
	waitFor(2000);
	}
	
	public void checkout_FromCheckoutHisory() {
		visibilityWait(checkoutHistory_SecondaryCTA);
		jsClick(checkoutHistory_SecondaryCTA);
		waitForDocumentToLoad();

	}
	
	public void Add_Wishlist() {
		if (Thirdparty_Wishlist.getAttribute("aria-label").equalsIgnoreCase("Wishlist selected")) {
			jsClick(Thirdparty_Wishlist);
			visibilityWait(ToastMsg_Wishlist);
			Assert.assertEquals(ToastMsg_Wishlist.getText().contains("You have removed"), true);
			System.out.println("Wishlist removed successfully");
			jsClick(Thirdparty_Wishlist);
			waitFor(2000);
			visibilityWait(ToastMsg_Wishlist);
			Assert.assertEquals(ToastMsg_Wishlist.getText().contains("added"), true);
		} else {
			waitFor(2000);
			jsClick(Thirdparty_Wishlist);
			visibilityWait(ToastMsg_Wishlist);
			Assert.assertEquals(ToastMsg_Wishlist.getText().contains("added to your Wishlist"), true);
			System.out.println("Wishlist added successfully");
		}
	}
	
	
}
