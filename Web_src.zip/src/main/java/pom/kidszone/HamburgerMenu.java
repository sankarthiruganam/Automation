package pom.kidszone;

import java.util.ArrayList;
import java.util.List;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class HamburgerMenu extends CommonAction {

	public HamburgerMenu(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_btnHamburgerMenu")
	private WebElement link_hamburgerMenu;

	@FindBy(xpath = "//button[@aria-label='Navigation Menu']")
	private WebElement link_old_hamburgerMenu;

	@FindBy(id = "loc_profiles")
	private WebElement link_Profiles;

	@FindBy(xpath = "//a[normalize-space()='Programs']")
	private WebElement link_Programs;

	@FindBy(xpath = "//a[@id='breadcrumb-link-1']")
	private WebElement txt_MyPrograms;

	@FindBy(id = "loc_linkCheckouts")
	private WebElement link_Checkouts;

	@FindBy(xpath = "//h2[normalize-space()='Checkouts']")
	private WebElement txt_CheckoutLandingPage;

	@FindBy(id = "loc_linkHolds")
	private WebElement link_Holds;

	@FindBy(xpath = "//h2[normalize-space()='Holds']")
	private WebElement txt_HoldsPage;

	@FindBy(id = "loc_linkHelp")
	private WebElement link_Help;

	@FindBy(id = "loc_linkMyShelf")
	private WebElement link_MyShelf;

	@FindBy(xpath = "(//*[@class='mat-tab-links'])")
	private WebElement myShelfTab;

	@FindBy(xpath = "(//a[normalize-space()='MYSHELF'])")
	private WebElement old_link_MyShelf;

	@FindBy(xpath = "//div[@class='mat-tab-links']")
	private WebElement logo_ShelfPage;

	@FindBy(id = "loc_textalertcontent")
	private WebElement alert_PopUpMessage;

	@FindBy(id = "loc_linkSignOut")
	private WebElement link_SignOut;

	@FindBy(id = "btnLogout")
	private WebElement logout_Btn;

	@FindBy(id = "loc_labelGoals&Insights")
	private WebElement text_MyShelf_Page;

	@FindBy(xpath = "//span[@class='mat-expansion-indicator ng-tns-c79-2 ng-trigger ng-trigger-indicatorRotate ng-star-inserted']")
	private WebElement accordion_text;

	@FindBy(id = "loc_labelGoals&Insights")
	private WebElement text_GoalsandInsgights;

	@FindBy(xpath = "//carousel[@class='goals-badge-carousel carousel ng-star-inserted']//div[@class='carousel-arrow carousel-arrow-next']")
	private WebElement caraousel_right;

	@FindBy(xpath = "//carousel[@class='goals-badge-carousel carousel ng-star-inserted']//div[@class='carousel-arrow carousel-arrow-prev']")
	private WebElement caraousel_left;

	@FindBy(xpath = "//*[@id='topHeaderRow']/div[1]/span/button")
	private WebElement icon_Profile;

	@FindBy(xpath = "//*[@class='kz-main kz-profile-section']")
	private WebElement icon_Profilenew;

	@FindBy(id = "loc_profileImg")
	private WebElement profile_icon_Settings;

	@FindBy(id = "btnLogout")
	private WebElement signOutOldUi;

	@FindBy(xpath = "//button[normalize-space()='View settings']")
	private WebElement link_ViewSettings;

	@FindBy(xpath = "//*[@id='EnableTracking']")
	private WebElement checkbox_Insights;

	@FindBy(xpath = "//a[@aria-label='profile']")
	private WebElement profile_Icon;

	@FindBy(xpath = "//button[normalize-space()='Yes']")
	private WebElement Btn_Yes;

	@FindBy(id = "loc_cancelbtn")
	private WebElement Btn_No;

	@FindBy(id = "loginBtn")
	private WebElement logInButton;

	@FindBy(xpath = "//button[normalize-space()='UPDATE SETTINGS']")
	private WebElement btn_UpdateSettings;

	@FindBy(id = "loc_linkLibrary")
	private WebElement navigationMenu_btn_library;

	@FindBy(xpath = "//button[@aria-label='Navigation Menu']")
	private WebElement old_LibraryMenu_link;

	@FindBy(id = "menuClosebtn")
	private WebElement navigationMenu_btn_closeCTA;

	@FindBy(id = "loc_txtAvailability")
	private WebElement libraryscreen_txt;

	@FindBy(id = "loc_linkFeaturedLists")
	private WebElement navigationMenu_btn_featuredLists;

	@FindBy(id = "browseBySubject")
	private WebElement navigationMenu_btn_OldbrowseBySubject;

	@FindBy(id = "loc_linkBrowserBySubject")
	private WebElement navigationMenu_btn_browseBySubject;

	@FindBy(id = "loc_txtjuvenile fiction")
	private WebElement navigationMenu_btn_kidbrowseBySubject;

	@FindBy(id = "sub-menu-list")
	private WebElement menu_browsebysubjectLists;

	@FindBy(id = "availabilityTypeLabel")
	private WebElement menu_browsebysubject_Navhome;

	@FindBy(id = "subMenu-nav-close")
	private WebElement menu_browsebysubject_closeCTA;

	@FindBy(xpath = "//mat-icon[text()='close']")
	private List<WebElement> teenmenu_browsebysubject_closeCTA;

	@FindBy(id = "sub-menu")
	private WebElement Teenmenu_browsebysubject_submenu;

	@FindBy(id = "loc_linkPrograms")
	private WebElement navigationMenu_btn_programs;

	@FindBy(id = "loc_linkPatronSupport")
	private WebElement navigationMenu_btn_patronSupport;

	@FindBy(xpath = "//span[@class='text-truncate menu-item-text']")
	private List<WebElement> adult_menu_Level1browseBysubject;

	@FindBy(id = "loc_txtAvailability")
	private WebElement Magiclibraryscreen_txt;

	@FindBy(xpath = "//h1[text()='Featured Reading Program ']")
	private WebElement axisuser_librarypage;

	@FindBy(xpath = "//a[text()='MYSHELF']")
	private WebElement Btn_old_myshelf;

	@FindBy(id = "collections")
	private WebElement collectionsOldUi;

	@FindBy(xpath = "//*[contains(text(),'MY LIBRARY')]")
	private WebElement myLibraryOldUI;

	@FindBy(id = "myStaffPicks")
	private WebElement featuredListOldUi;

	@FindBy(xpath = "//*[contains(text(),'PROGRAMS')]")
	private WebElement programsOldUi;

	@FindBy(xpath = "//*[contains(text(),'HOLDS')]")
	private WebElement holdsOldUi;

	@FindBy(xpath = "//*[contains(text(),'PROFILES')]")
	private WebElement profilesOldUi;

	@FindBy(xpath = "//*[@class='tab-program']")
	private WebElement programsOldUiPage;

	@FindBy(xpath = "//*[contains(text(),'CHECKOUTS')]")
	private WebElement checkOutOldUi;

	@FindBy(xpath = "//*[@id='mystuff-cat'][contains(text(),'Checkouts')]")
	private WebElement checkOutOldUiPage;

	@FindBy(id = "nav-close")
	private WebElement close_menu;

	@FindBy(xpath = "//a[text()='MY LIBRARY']")
	private WebElement mylibrary_menu;

	@FindBy(xpath = "//div[@class='homepage-filterArea ng-star-inserted']")
	public WebElement mylibrary_homepage;
	
	@FindBy(id = "loc_txtyoung_adult_fiction")
	public WebElement browseBySubject_adultFiction;
	
	@FindBy(id = "sub-menu-browse-by-subject")
	public WebElement browseBySubject_options;
	
	@FindBy(xpath = "//span[contains(text(),'young adult fiction')]")
	public WebElement tilelist_youngAdultFiction;

	@FindBy(xpath = "//div[@class='kz-header-view ng-star-inserted']")
	public WebElement library_topNavigationbar;


	
	@FindBy(id = "loc_txtCheckouts")
	public WebElement checkout_Screen;

	public WebElement getCheckOutOldUi() {
		return checkOutOldUi;
	}

	public WebElement getCheckOutOldUiPage() {
		return checkOutOldUiPage;
	}

	public WebElement getProgramsOldUiPage() {
		return programsOldUiPage;
	}

	public WebElement getProfilesOldUi() {
		return profilesOldUi;
	}

	public WebElement getHoldsOldUi() {
		return holdsOldUi;
	}

	public WebElement getProgramsOldUi() {
		return programsOldUi;
	}

	public WebElement getFeaturedListOldUi() {
		return featuredListOldUi;
	}

	public WebElement getMyLibraryOldUI() {
		return myLibraryOldUI;
	}

	public WebElement getLink_Checkouts() {
		return link_Checkouts;
	}

	public WebElement getCollectionsOldUi() {
		return collectionsOldUi;
	}

	public WebElement getMyShelfTab() {
		return myShelfTab;
	}

	public WebElement getLink_hamburgerMenu() {
		return link_hamburgerMenu;
	}

	public WebElement getSignOutOldUi() {
		return signOutOldUi;
	}

	public WebElement getBtn_old_myshelf() {
		return Btn_old_myshelf;
	}

	public WebElement getLink_Programs() {
		return link_Programs;
	}

	public WebElement getLink_MyShelf() {
		return link_MyShelf;
	}

	public WebElement getOld_link_MyShelf() {
		return old_link_MyShelf;
	}

	public WebElement getNavigationMenu_btn_library() {
		return navigationMenu_btn_library;
	}

	public WebElement getNavigationMenu_btn_featuredLists() {
		return navigationMenu_btn_featuredLists;
	}

	public WebElement getNavigationMenu_btn_OldbrowseBySubject() {
		return navigationMenu_btn_OldbrowseBySubject;
	}

	public WebElement getNavigationMenu_btn_programs() {
		return navigationMenu_btn_programs;
	}

	public WebElement getNavigationMenu_btn_browseBySubject() {
		return navigationMenu_btn_browseBySubject;
	}

	public WebElement getMagiclibraryscreen_txt() {
		return Magiclibraryscreen_txt;
	}

	public WebElement getTeenmenu_browsebysubject_submenu() {
		return Teenmenu_browsebysubject_submenu;
	}

	public WebElement getMenu_browsebysubjectLists() {
		return menu_browsebysubjectLists;
	}

	public WebElement getNavigationMenu_btn_patronSupport() {
		return navigationMenu_btn_patronSupport;
	}

	public WebElement getLibraryscreen_txt() {
		return libraryscreen_txt;
	}

	public WebElement getAlert_PopUpMessage() {
		return alert_PopUpMessage;
	}

	public WebElement getLogo_ShelfPage() {
		return logo_ShelfPage;
	}

	public WebElement getText_GoalsandInsgights() {
		return text_GoalsandInsgights;
	}

	public WebElement getText_MyShelf_Page() {
		return text_MyShelf_Page;
	}

	public WebElement getLink_Help() {
		return link_Help;
	}

	public WebElement getTxt_HoldsPage() {
		return txt_HoldsPage;
	}

	public WebElement getLink_Profiles() {
		return link_Profiles;
	}

	public WebElement getTxt_CheckoutLandingPage() {
		return txt_CheckoutLandingPage;
	}

	public WebElement getTxt_MyPrograms() {
		return txt_MyPrograms;
	}

	public WebElement getLink_Holds() {
		return link_Holds;
	}

	public WebElement getLink_SignOut() {
		return link_SignOut;
	}

	public WebElement getLink_old_hamburgerMenu() {
		return link_old_hamburgerMenu;
	}

	public WebElement getNavigationMenu_btn_closeCTA() {
		return navigationMenu_btn_closeCTA;
	}

	/******************************************************
	 * Action methods
	 * 
	 * @return
	 *****************************************************/

	public void click_HamburgerMenu() {
		
		visibilityWait(link_hamburgerMenu);
		jsClick(link_hamburgerMenu);
		waitFor(2000);
//		waitFor(5000);
//		if (isElementPresent(link_hamburgerMenu)) {
//			jsClick(link_hamburgerMenu);
//			waitFor(2000);
//		} else {
//			waitFor(2000);
//			javascriptScroll(link_old_hamburgerMenu);
//			jsClick(link_old_hamburgerMenu);
//		}
	}

	public void click_Profiles() {
		waitFor(2000);
		ClickOnWebElement(link_Profiles);
		waitFor(6000);
	}

	public void click_AvatarIcon() {
		waitFor(2000);
		ClickOnWebElement(profile_Icon);
		waitFor(4000);

	}

	public void click_Programs() {
		waitFor(2000);
		ClickOnWebElement(link_Programs);
		waitFor(2000);

	}

	public void click_Checkouts() {
		visibilityWait(link_Checkouts);
		jsClick(link_Checkouts);
		// ClickOnWebElement(link_Checkouts);
		//waitFor(7000);
		WaitForWebElement(checkout_Screen);

	}

	public void click_Holds() {
		waitFor(2000);
		ClickOnWebElement(link_Holds);
		waitFor(7000);

	}

	public void click_Help() {
		waitFor(2000);
		waitFor(2000);
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			Logger.log("User able to view Help page and verified manually");
		} else {
			jsClick(link_Help);
			waitFor(4000);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			waitFor(5000);
			DriverManager.getDriver().close();
			DriverManager.getDriver().switchTo().window(tabs.get(0));
			waitFor(4000);
		}
	}

	public void click_MyShelf() {
		if (link_MyShelf.isDisplayed()) {
			jsClick(link_MyShelf);
			visibilityWait(myShelfTab);
		} else {
			javascriptScroll(old_link_MyShelf);
			jsClick(old_link_MyShelf);
		}
		waitForDocumentToLoad();
	}

	public void click_featuredList() {
		waitFor(2000);
		jsClick(navigationMenu_btn_featuredLists);
		waitFor(2000);

	}

	public void click_SignOut() {
		waitFor(2000);
		jsClick(link_SignOut);
		WaitForWebElement(alert_PopUpMessage);
	}

	public void click_accordion() {
		try {
			WaitForWebElement(accordion_text);
			ClickOnWebElement(accordion_text);
		} catch (Exception e) {

			Logger.log("Accordion is not displayed");
		}

	}

	public void click_RightAccordion() {
		waitFor(2000);
//		for (int i = 0; i <= 1; i++) {
		ClickOnWebElement(caraousel_right);
		waitFor(2000);
//		}
	}

	public void click_LeftAccordion() {
		waitFor(2000);
		Assert.assertTrue(isElementPresent(caraousel_left));
//		for (int i = 0; i <= 1; i++) {
		ClickOnWebElement(caraousel_left);
		waitFor(3000);
//		}
	}

	public void click_ProfileIcon() {
		waitFor(2000);
		if (isElementPresent(icon_Profilenew)) {
			Logger.log("User is in profile page");
		} else {
			jsClick(icon_Profile);
			WaitForWebElement(link_ViewSettings);
		}

	}

	public void click_ProfileAccount() {
		waitFor(2000);
		ClickOnWebElement(profile_icon_Settings);
	}

	public void click_YesButton() {
		waitFor(2000);
		ClickOnWebElement(Btn_Yes);

	}

	public void click_NoButton() {
		waitFor(2000);
		ClickOnWebElement(Btn_No);

	}

	public void click_ViewSettings() {
		waitFor(2000);
		jsClick(link_ViewSettings);

	}

	public void click_UpdateSettings() {
		waitFor(2000);
		ClickOnWebElement(btn_UpdateSettings);

	}

	public void select_CheckboxInsights() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("scroll(0,250);");
		waitFor(2000);
		if (checkbox_Insights.getAttribute("checked") != null)
			checkbox_Insights.click();
	}

	public boolean view_libraryOption() {
		boolean b = true;
		waitFor(2000);
		isElementPresent(navigationMenu_btn_library);
		return b;

	}

	public void click_library() {
		WaitForWebElement(navigationMenu_btn_library);
//		javascriptScroll(navigationMenu_btn_library);
		ClickOnWebElement(navigationMenu_btn_library);
		visibilityWait(libraryscreen_txt);
	}

	public void axis360_libraryMenu() {
		WaitForWebElement(old_LibraryMenu_link);
		jsClick(old_LibraryMenu_link);
	}

	public void humbergerMenuclick_closeCTA() {
		waitFor(2000);
		ClickOnWebElement(navigationMenu_btn_closeCTA);
		waitFor(2000);

	}

	public boolean View_featuredLists() {
		waitFor(2000);
		boolean b = true;
		isElementPresent(navigationMenu_btn_featuredLists);
		return b;
	}

	public boolean View_browseBySubject() {
		waitFor(2000);
		boolean b = true;
		isElementPresent(navigationMenu_btn_browseBySubject);
		return b;
	}

	public void adult_menu_Level1browseBysubject() {
		for (int i = 0; i < adult_menu_Level1browseBysubject.size(); i++) {
			isElementPresent(adult_menu_Level1browseBysubject.get(1));
			break;
		}
		System.out.println("user is able to view level one subjects list in the sidebar based on adult profile type");

	}

	public void click_level1Subject() {
//		visibilityWait(adult_menu_Level1browseBysubject.get(1));
//		jsClick(adult_menu_Level1browseBysubject.get(1));
//		waitFor(2000);
//		//ClickOnWebElement(adult_menu_Level1browseBysubject.get(1));
		javascriptScroll(browseBySubject_adultFiction);
		visibilityWait(browseBySubject_adultFiction);
		jsClick(browseBySubject_adultFiction);
	}

	public void click_browseBySubject() {
		waitFor(2000);
		if (navigationMenu_btn_browseBySubject.isDisplayed()) {
			jsClick(navigationMenu_btn_browseBySubject);
		} else if (navigationMenu_btn_kidbrowseBySubject.isDisplayed()) {
			jsClick(navigationMenu_btn_kidbrowseBySubject);
		}

	}

	public void click_oldBrowseBysubject() {
		
		jsClick(navigationMenu_btn_OldbrowseBySubject);
	}

	public void click_closeCTABrowseBysubject() {
		visibilityWait(menu_browsebysubject_closeCTA);
		jsClick(menu_browsebysubject_closeCTA);
		//ClickOnWebElement(menu_browsebysubject_closeCTA);
		if (isElementPresent(menu_browsebysubject_Navhome)) {
			System.out.println("system should navigate back to last screen");
		}
	}

	public void click_closeCTAbrowseBysubject() {
		ClickOnWebElement(teenmenu_browsebysubject_closeCTA.get(1));
		if (menu_browsebysubject_Navhome.isDisplayed()) {
			System.out.println("system should navigate back to last screen");
		}
	}

	public boolean View_programs() {
		waitFor(2000);
		boolean b = true;
		isElementPresent(navigationMenu_btn_programs);
		return b;
	}

	public boolean view_checkout() {
		waitFor(2000);
		boolean b = true;
		isElementPresent(link_Checkouts);
		return b;
	}

	public void sign_Out() {
		click_HamburgerMenu();
		click_SignOut();
		jsClick(Btn_Yes);
		WaitForWebElement(logInButton);
	}

	public void old_Logout() {
		jsClick(logout_Btn);
		waitFor(3000);
	}

	public boolean navigate_axislibrarylibraryPage() {
		boolean b = true;
		isElementPresent(axisuser_librarypage);
		return b;

	}

	public boolean notDisplayed_myshelfInaxisLib() {
		boolean b = false;
		if (isElementPresent(link_MyShelf)) {
			b = true;
			System.out.println("user should not able to view my shelf option");
		}
		return b;

	}

	public void OldMyShelf() {
		waitFor(2000);
		jsClick(Btn_old_myshelf);
		WaitForWebElement(Btn_No);
	}

	public void click_closeoldMenu() {
		WaitForWebElement(close_menu);
		jsClick(close_menu);
		waitFor(2000);
	}

	public void click_oldMylibrary() {
		visibilityWait(mylibrary_menu);
		jsClick(mylibrary_menu);
		WaitForWebElement(mylibrary_homepage);
	}
	
	public WebElement getYesButton() {
		return Btn_Yes;
	}

}
