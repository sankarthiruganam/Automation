package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class Learning_Activities extends CommonAction {

	TitleDetails title = new TitleDetails(DriverManager.getDriver());

	public Learning_Activities(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class='kz-learning-activity']")
	private WebElement learningActivitySection;

	@FindBy(xpath = "//*[@class='kz-learnings-col']")
	private List<WebElement> learnActivities;

	@FindBy(xpath = "//*[@class='learning-title']")
	private WebElement activitiesPage;

	@FindBy(xpath = "//*[@class='mat-tab-list']")
	private WebElement activityPageTabs;

	@FindBy(id = "loc_labelactivityTypes")
	private List<WebElement> activityPills;

	@FindBy(xpath = "(//*[@class='radio-group check-group ng-star-inserted'])[2]")
	private WebElement activityTypeDropDown;

	@FindBy(xpath = "//*[@class='learning-img'][1]")
	private WebElement activity1;

	@FindBy(xpath = "((//*[@class='radio-group check-group ng-star-inserted'])[2]//following::*[@class='mat-checkbox-frame'])[1]")
	private WebElement activityRadioButton;

	@FindBy(xpath = "//*[@class='breadcrumb kz-breadcrumb']//*[contains(text(),'Resource Hub')]")
	private WebElement breadCrumbLA;

	@FindBy(xpath = "//*[@class='refine-filter-head']//following::*[contains(text(),'Sort By')]")
	private WebElement sortByRefSection;

	@FindBy(xpath = "//*[contains(text(),'Resource Type')]/following::*[@class='mat-checkbox-layout']")
	private List<WebElement> activityTypes;

	@FindBy(xpath = "//*[contains(text(),'Sort By')]/following::*[@class='ui-radiobutton-label ng-star-inserted']")
	private List<WebElement> sortTypes;

	@FindBy(xpath = "//*[contains(text(),'Sort By')]//following::div[1]")
	private WebElement sortOptions;

	@FindBy(xpath = "//*[@class='refine-filter-head']")
	private WebElement refineSection;

	@FindBy(xpath = "//*[@class='refine-filter-head']//following-sibling::mat-accordion")
	private List<WebElement> refineOptions;

	@FindBy(xpath = "//*[@style='visibility: visible;']")
	private List<WebElement> subOptions;

	@FindBy(xpath = "//*[@class='mat-tab-links']//*")
	private List<WebElement> refinerPills;

	@FindBy(xpath = "(//*[@class='nav-item ng-star-inserted'])[1]")
	private WebElement refinerPills1;

	@FindBy(xpath = "//*[contains(text(),'Resource Type')]")
	private WebElement resoursceType;

	@FindBy(xpath = "(//*[@svgicon='kz-nav-close-icon'])[1]")
	private WebElement pillsCloseIcon;

	@FindBy(xpath = "(//*[@class='activity-resources-container'])")
	private List<WebElement> activityCards;

	@FindBy(xpath = "(//*[@class='card-image'])")
	private List<WebElement> activityCardCoverImage;

	@FindBy(xpath = "(//*[@class='activity-resources-container'])")
	private List<WebElement> activityCardTitle;

	@FindBy(xpath = "(//*[@class='primary-para single-ellipsis'])")
	private List<WebElement> activityCardTitleType;

	@FindBy(xpath = "(//*[@class='activity-resources-container'])")
	private List<WebElement> activityCardLinkedTitle;

	@FindBy(xpath = "//*[@class='ng-view-main-container main-container-content']")
	private WebElement titleDetailsContent;

	public List<WebElement> getActivityCardTitleType() {
		return activityCardTitleType;
	}

	public List<WebElement> getActivityCardLinkedTitle() {
		return activityCardLinkedTitle;
	}

	public List<WebElement> getActivityCardTitle() {
		return activityCardTitle;
	}

	public List<WebElement> getActivityCardCoverImage() {
		return activityCardCoverImage;
	}

	public List<WebElement> getActivityCards() {
		return activityCards;
	}

	public WebElement getRefinerPills1() {
		return refinerPills1;
	}

	public List<WebElement> getRefinerPills() {
		return refinerPills;
	}

	public WebElement getRefineSection() {
		return refineSection;
	}

	public WebElement getSortOptions() {
		return sortOptions;
	}

	public WebElement getSortByRefSection() {
		return sortByRefSection;
	}

	public WebElement getActivityPageTabs() {
		return activityPageTabs;
	}

	public WebElement getBreadCrumbLA() {
		return breadCrumbLA;
	}

	public WebElement getActivitiesPage() {
		return activitiesPage;
	}

	public List<WebElement> getLearnActivities() {
		return learnActivities;
	}

	public void clickRefineOptions() {
		for (int i = 0; i < refineOptions.size(); i++) {
			javascriptScroll(refineOptions.get(i));
			jsClick(refineOptions.get(i));
			waitFor(2000);
		}
//		Assert.assertEquals(refineOptions.size(), subOptions.size());
		Logger.log("User able to view refiner options with " + refineOptions.size() + " options");
	}

	public void checkRefine() {
		if (isElementPresent(refineSection)) {
			Assert.assertEquals(refineOptions.size(), 3);
		} else {
			Assert.assertEquals(isElementPresent(refineOptions.get(0)), false);
		}
	}

	public void selectSortOptions() {
		jsClick(sortByRefSection);
		waitFor(3000);
		javascriptScroll(sortTypes.get(1));
		String type = sortTypes.get(1).getText();
		jsClick(sortTypes.get(1));
		waitFor(3000);
		Logger.log("User able to see the sort options based on selection");
	}

	public void selectActivityType() {
		javascriptScroll(activityTypes.get(4));
		String type = activityTypes.get(4).getText();
		waitFor(3000);
		jsClick(activityTypes.get(2));
		waitFor(5000);
		System.out.println(type);
		for (int i = 0; i < activityPills.size(); i++) {
			if (activityPills.get(i).getText().contains(type)) {
				System.out.println(activityPills.get(i).getText());
				Assert.assertEquals(activityPageTabs.getText().contains(type), true);
				Logger.log("User able to see the selected activity filtered");
			} else {
				System.out.println(activityPills.get(i).getText());
				continue;
			}
		}
		Logger.log("User able to see the selected category pertained");
	}

	public void clickActivities() {
		WaitForWebElement(learnActivities.get(0));
		String activity = learnActivities.get(0).getText();
		jsClick(activity1);
		WaitForWebElement(activitiesPage);
		Assert.assertEquals(activityPageTabs.getText().contains(activity), true);
	}

	public void inspectActivity() {
		waitFor(2000);
		jsClick(resoursceType);
		WaitForWebElement(activityTypeDropDown);
		waitFor(2000);
		jsClick(activityTypeDropDown);
		waitFor(2000);
		if (System.getProperty("browser").equalsIgnoreCase("iOS")) {
			waitFor(2000);
		} else if (activityRadioButton.isSelected()) {
			waitFor(2000);
			Logger.log("Activity selected");
		}
	}

	public void clickRefinerPills() {
		javascriptScroll(refinerPills.get(1));
		int totalPills = refinerPills.size();
		jsClick(pillsCloseIcon);
		waitFor(2000);
		WaitForWebElement(refinerPills.get(0));
		Assert.assertEquals(refinerPills.size(), totalPills - 1);
	}

	public void clearAllCTA() {
		for (int i = 0; i < refinerPills.size(); i++) {
			if (refinerPills.get(i).getText().contains("Clear All")) {
				Logger.log("Refiner Pill section contains Clear All CTA");
				break;
			} else {
				continue;
			}
		}
	}

	public void clickclearAllCTA() {
		for (int i = 0; i < refinerPills.size(); i++) {
			int totalPills = refinerPills.size();
			if (refinerPills.get(i).getText().contains("Clear All")) {
				jsClick(refinerPills.get(i));
				waitFor(4000);
				WaitForWebElement(refinerPills.get(i - 1));
				Assert.assertEquals(refinerPills.size(), 4);
				break;
			} else {
				continue;
			}
		}
		waitFor(2000);
	}

	public void clickLinkedTitle() {
		javascriptScroll(activityCardLinkedTitle.get(0));
		waitFor(2000);
		jsClick(activityCardLinkedTitle.get(0));
		// WaitForWebElement(titleDetailsContent);
		if (isElementPresent(title.getTitleDetailScreen())) {
			Logger.log("User able to navigate to title details screen by clicking linked title");
		} else {
			Logger.log("No title details yet to that title");
		}
	}
}
