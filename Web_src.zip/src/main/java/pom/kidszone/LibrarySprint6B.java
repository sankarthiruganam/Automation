package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class LibrarySprint6B extends CommonAction {

	MyLibrary_Guest guest = new MyLibrary_Guest(DriverManager.getDriver());
	TitleAcrossProfile across = new TitleAcrossProfile(DriverManager.getDriver());

	public LibrarySprint6B(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "searchText")
	private WebElement searchBar;

	@FindBy(xpath = "//*[@class='ui-radiobutton ui-widget']/following-sibling::*[contains(text(),'Keyword')]")
	private WebElement keyword;

	@FindBy(xpath = "//*[contains(text(),'Requests For Library Purchase')]")
	public WebElement purchaseReq;

	@FindBy(xpath = "//button[@class='btn-primary-blue']")
	private WebElement searchButton;

	@FindBy(xpath = "//*[@class='spinner-loader advance-search-loader']")
	public WebElement advanceSearchLoader;

	@FindBy(xpath = "//*[contains(text(),' Format ')]//following::*[@aria-labelledby='menubutton']//preceding-sibling::*//*")
	private List<WebElement> categorySection;

	@FindBy(xpath = "//*[@class='kz-carousel kz-third-party-carousel ng-star-inserted']")
	private WebElement newsMagCarousel;

	@FindBy(xpath = "//*[@class='kz-carousel kz-third-party-carousel ng-star-inserted']//following-sibling::*[contains(text(),'See All')]")
	private WebElement newsMagCarouselSeeAll;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group ng-star-inserted']//*[1][contains(text(),'eBOOKS')]")
	private WebElement ebooksCarousel;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group ng-star-inserted']//*[2][contains(text(),'See All')]")
	private WebElement ebooksCarouselSeeAll;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group']//*[1][contains(text(),'Web Resources')]/following::a[1]")
	private WebElement webResCarousel;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group']//*[2][contains(text(),'See All')]")
	private WebElement webResCarouselSeeAll;

	@FindBy(xpath = "//*[@class='search-result-info']")
	private WebElement searchResultCategory;

	@FindBy(xpath = "//*[@class='thirdparty-titlewrap']")
	private WebElement searchResultCategoryThirdParty;

	@FindBy(xpath = "//*[@class='carousel-title heading-2']")
	private WebElement searchResultHeader;

	@FindBy(xpath = "//mat-icon[@svgicon='kz-filter-icon']")
	public WebElement SearchResults_Filter_mobile;

	@FindBy(xpath = "(//*[@svgicon='kz-close-black'])[2]")
	public WebElement closeIcon_mobile;

	public WebElement getSearchResultCategoryThirdParty() {
		return searchResultCategoryThirdParty;
	}

	public WebElement getSearchResultCategory() {
		return searchResultCategory;
	}

	public WebElement getSearchResultHeader() {
		return searchResultHeader;
	}

	public WebElement getWebResCarousel() {
		return webResCarousel;
	}

	public WebElement getWebResCarouselSeeAll() {
		return webResCarouselSeeAll;
	}

	public List<WebElement> getCategorySection() {
		return categorySection;
	}

	public WebElement getNewsMagCarousel() {
		return newsMagCarousel;
	}

	public WebElement getNewsMagCarouselSeeAll() {
		return newsMagCarouselSeeAll;
	}

	public WebElement getEbooksCarousel() {
		return ebooksCarousel;
	}

	public WebElement getEbooksCarouselSeeAll() {
		return ebooksCarouselSeeAll;
	}

	public void searchWithKeyword(String keyWord) {
		if (isElementPresent(advanceSearchLoader)) {
			inVisibilityWait(advanceSearchLoader);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, keyWord);
			jsClick(searchButton);
			WaitForWebElement(across.getSearchResult());
		} else {
			visibilityWait(searchBar);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, keyWord);
			javascriptScroll(searchButton);
			jsClick(searchButton);
			visibilityWait(across.getSearchResult());
		}
	}

	
	public void Enter_SearchKeyword(String keyWord) {
		visibilityWait(searchBar);
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, keyWord);
		javascriptScroll(searchButton);
		jsClick(searchButton);
		visibilityWait(across.getSearchResult());

	}
	public void searchCategory(String category) {
		javascriptScroll(categorySection.get(1));
		for (int i = 0; i < categorySection.size(); i++) {
			javascriptScroll(categorySection.get(i));
			if (categorySection.get(i).getText().contains(category)) {
				Logger.log("User able to see the refiner section with option " + category);
				waitFor(2000);
				break;
//			} else {
//				continue;
//			}
		}}
	}
	

	public void clickCategory(String category) {
		if (System.getProperty("browser").equalsIgnoreCase("Android")){
			visibilityWait(SearchResults_Filter_mobile);
			jsClick(SearchResults_Filter_mobile);
			visibilityListWait(categorySection);
			for (int i = 0; i < categorySection.size(); i++) {
				javascriptScroll(categorySection.get(i));
				if (categorySection.get(i).getText().equalsIgnoreCase(category)) {
					jsClick(categorySection.get(i));
					visibilityWait(searchResultCategory);
					Assert.assertTrue(searchResultHeader.getText().contains(category));
					Logger.log("User able to see the results based on the selection");
					waitFor(2000);
					break;
				}
			}
		}else{
			visibilityListWait(categorySection);
			for (int i = 0; i < categorySection.size(); i++) {
				javascriptScroll(categorySection.get(i));
				if (categorySection.get(i).getText().equalsIgnoreCase(category)) {
					jsClick(categorySection.get(i));
					visibilityWait(searchResultCategory);
					Assert.assertTrue(searchResultHeader.getText().contains(category));
					Logger.log("User able to see the results based on the selection");
					waitFor(2000);
					break;
				}
			}
		}

	}

	public void clickSeeAll(WebElement element) {
		javascriptScroll(element);
		jsClick(element);
		WaitForWebElement(searchResultCategory);
	}

	public void clickSeeAllNewsMag(WebElement element) {
		javascriptScroll(element);
		jsClick(element);
		WaitForWebElement(searchResultCategoryThirdParty);
	}

	@FindBy(xpath = "//label[text()='Newspapers & Magazines - 3rd party']")
	private WebElement advanceSearchpopup_newspaper_radiobtn;

	@FindBy(id = "searchText")
	private WebElement input_search;

	@FindBy(xpath = "//button[text()='Search']")
	private WebElement btn_search;

	@FindBy(xpath = "(//div[@class='third-party-card third-party-card-common'])[1]")
	private WebElement btn_searchContent;

	@FindBy(xpath = "(//div[@class='web-resources-container'])[1]")
	private WebElement btn_studysitecontent;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement search_word;

	@FindBy(xpath = "(//div[text()='Read Now'])[1]")
	private WebElement readnow_cta;

	@FindBy(xpath = "//h2[text()='Log Into Your Library']")
	private WebElement login_popup;

	@FindBy(xpath = "//label[text()='Web Resources']")
	private WebElement radiobtn_webREsource;

	@FindBy(xpath = "//button[@class='advsearch-button']")
	private WebElement old_advansearchtxt;

	@FindBy(xpath = "//label[contains(text(),'Newspapers')]")
	private WebElement old_newspaperRadiobtn;

	@FindBy(id = "searchText")
	private WebElement old_inputSearch;

	@FindBy(xpath = "(//button[@type='submit'])[2]")
	private WebElement btn_oldsearch;

	@FindBy(xpath = "(//axis360-press-reader-card[@class='card-item ng-star-inserted'])[1]")
	private WebElement btn_oldsearchContent;

	@FindBy(xpath = "//p[@class='sub-title ng-star-inserted']")
	private WebElement search_oldword;

	@FindBy(xpath = "(//a[text()='Read Now'])[1]")
	private WebElement oldreadnow_cta;

	@FindBy(xpath = "//label[@for='Study-Sites']")
	private WebElement btn_Oldstudysites;

	@FindBy(xpath = "(//axis360-title-info-card[@class='search-card-item ng-star-inserted'])[1]")
	private WebElement btn_studysitessearchContent;

	@FindBy(id = "dialogHeading")
	private WebElement login_oldpopup;

	@FindBy(xpath = "//h2[normalize-space()='Always Available']")
	private WebElement lib_Alwaysavailable;

	@FindBy(id = "advancedSearchForm")
	private WebElement advanceSearch_popup;

	@FindBy(xpath = " //h2[contains(text(),'Category ')]")
	private WebElement view_category;

	@FindBy(xpath = "//a[@class='menuitem ng-star-inserted']")
	private List<WebElement> category_options;

	@FindBy(id = "loc_txtAvailability")
	private WebElement navigate_libscreen;

	@FindBy(id = "btnSearch")
	public WebElement navigate_oldlibscreen;

	@FindBy(id = "advancedSearchForm")
	public WebElement oldadvanceSearch_popup;

	@FindBy(id = "loc_Always Available")
	public WebElement Oldalwaysavailable_radiobtn;

	@FindBy(xpath = "//div[@class='search-view-container']")
	public WebElement Alwaysavailable_content;

	@FindBy(id = "refinerBtn")
	public WebElement Refiner_old;
	
	@FindBy(xpath = "//div[@class='container kz-advanced-search']")
	public WebElement AdvanceSearch_popupOverlay;

	public WebElement getNavigate_libscreen() {
		return navigate_libscreen;
	}

	public WebElement getAdvanceSearch_popup() {
		return advanceSearch_popup;
	}

	public WebElement getLib_Alwaysavailable() {
		return lib_Alwaysavailable;
	}

	public WebElement getLogin_oldpopup() {
		return login_oldpopup;
	}

	public WebElement getBtn_studysitecontent() {
		return btn_studysitecontent;
	}

	public WebElement getBtn_studysitessearchContent() {
		return btn_studysitessearchContent;
	}

	public WebElement getBtn_Oldstudysites() {
		return btn_Oldstudysites;
	}

	public WebElement getBtn_oldsearchContent() {
		return btn_oldsearchContent;
	}

	public WebElement getOld_newspaperRadiobtn() {
		return old_newspaperRadiobtn;
	}

	public WebElement getLogin_popup() {
		return login_popup;
	}

	public WebElement getRadiobtn_webREsource() {
		return radiobtn_webREsource;
	}

	public WebElement getBtn_searchContent() {
		return btn_searchContent;
	}

	public WebElement getAdvanceSearchpopup_newspaper_radiobtn() {
		return advanceSearchpopup_newspaper_radiobtn;
	}

	/****************************************
	 * * Action Methods
	 *****************************************************/

	public void click_newspaperRadiobtn() {
		javascriptScroll(advanceSearchpopup_newspaper_radiobtn);
		jsClick(advanceSearchpopup_newspaper_radiobtn);
		waitFor(3000);

	}

	public void enter_searchContent(String content) {
		ClickOnWebElement(input_search);
		SendKeysOnWebElement(input_search, content);
		waitFor(3000);

	}

	public void click_searchCTA() {
		javascriptScroll(btn_search);
		jsClick(btn_search);
		waitFor(2000);

	}

	public void verify_searchkeyword() {
		String content = "hello";
		String text = search_word.getText();
		if (content.equals(text)) {
			System.out.println("user is able to view the newpapers & magazines based on saerch keyword ");
		} else {
			System.out.println("user is  not able to view the newpapers & magazines based on saerch keyword ");
		}

	}

	public void click_ReadnowCTA() {
		javascriptScroll(readnow_cta);
		jsClick(readnow_cta);
		waitFor(3000);

	}

	public void select_webresourceRadiobtn() {
		javascriptScroll(radiobtn_webREsource);
		jsClick(radiobtn_webREsource);
		waitFor(2000);

	}

	public void click_oldAdvanceSearch() {
		visibilityWait(old_advansearchtxt);
		jsClick(old_advansearchtxt);
		visibilityWait(AdvanceSearch_popupOverlay);

	}

	public void enter_oldsearchContent(String content) {
		ClickOnWebElement(old_inputSearch);
		SendKeysOnWebElement(old_inputSearch, content);
		waitFor(2000);

	}

	public void click_oldnewspaperRadiobtn() {
		javascriptScroll(old_newspaperRadiobtn);
		jsClick(old_newspaperRadiobtn);
		waitFor(2000);

	}

	public void click_OldsearchCTA() {
		javascriptScroll(btn_oldsearch);
		jsClick(btn_oldsearch);
		waitFor(3000);

	}

	public void verify_oldsearchkeyword() {
		String content = "hello";
		String text = search_oldword.getText();
		if (content.contains("hello")) {
			System.out.println("user is able to view the newpapers & magazines based on saerch keyword ");
		} else {
			System.out.println("user is  not able to view the newpapers & magazines based on saerch keyword ");
		}

	}

	public void click_oldReadnowCTA() {
		javascriptScroll(oldreadnow_cta);
		jsClick(oldreadnow_cta);
		waitFor(3000);

	}

	public void select_studysitesRadiobtn() {
		javascriptScroll(btn_Oldstudysites);
		jsClick(btn_Oldstudysites);
		waitFor(2000);

	}

	public void categorySection_notshownAlwaysAvailable() {
		visibilityWait(view_category);
		for (int i = 0; i < category_options.size(); i++) {
			if (!category_options.get(i).getText().equals("Always Available")) {
				System.out.println("user is not able to view always available on category section");
			} else {
				System.out.println("user is able to view always available on category section");
			}
		}

	}

	public boolean view_AlwaysAvailableCarousel() {
		javascriptScroll(lib_Alwaysavailable);
		boolean b = true;
		isElementPresent(lib_Alwaysavailable);
		return b;
	}

	public void select_oldalwaysAvailable() {
		javascriptScroll(Oldalwaysavailable_radiobtn);
		jsClick(Oldalwaysavailable_radiobtn);
		waitFor(2000);
	}
}
