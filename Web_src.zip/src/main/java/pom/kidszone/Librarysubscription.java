package pom.kidszone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

public class Librarysubscription extends CommonAction {
	
	private List<String> LibHeading = new ArrayList<>();
	ArrayList<String> items;

	public Librarysubscription(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "LibrarySearch")
	private WebElement drop_searchBy;

	@FindBy(id = "searchText")
	private WebElement txtfld_librarySearch;

	@FindBy(xpath = "//*[@id=\"search\"]/div[1]")
	private WebElement btn_search;

	@FindBy(xpath = "//a[@data-tooltip='Edit Library Settings']")
	private WebElement btn_libraryEdit;

	@FindBy(xpath = "//*[@class=\"icon_button_edit\"]")
	private WebElement btn_libraryediting;

	@FindBy(id = "CustomerID")
	private WebElement txt_customerid;

	@FindBy(id = "axis360")
	private WebElement chk_axis360;

	@FindBy(id = "kidszone")
	private WebElement chk_kidszone;

	@FindBy(xpath = "//*[@class=\"icon_button_save\"]")
	private WebElement btn_saveLibrary;

	@FindBy(xpath = "//*[@class=\"ui-icon ui-icon-closethick\"]")
	private WebElement btn_closepop;

	@FindBy(xpath = "//*[@title=\"Log Off\"]")
	private WebElement btn_logoff;

	@FindBy(id = "adultprofile")
	private WebElement chk_adultprof;

	@FindBy(id = "teenprofile")
	private WebElement chk_teenprof;

	@FindBy(id = "kidsprofile")
	private WebElement chk_kidsprof;

	@FindBy(xpath = "//*[@class='icon_action_back bread-crumb-back']")
	private WebElement btn_libraryback;

	@FindBy(id = "lsettings")
	private WebElement salesdemo_label_librarysettingmenu;

	@FindBy(id = "UserName")
	private WebElement salesdemo_txtfield_username;

	@FindBy(id = "Password")
	private WebElement salesdemo_txtfield_password;

	@FindBy(xpath = "//input[@type='submit']")
	private WebElement salesdemo_btn_login;

	@FindBy(id = "settings")
	private WebElement salesdemo_lable_setting;

	@FindBy(xpath = "//div[text()='Library Settings']")
	private WebElement salesdemo_lable_librarysetting;

	@FindBy(xpath = "//legend[text()='Profile Settings']")
	private WebElement salesdemo_txt_profilesetting;
	
	@FindBy(xpath = "//*[@class='title']")
	private List<WebElement> Carousel_Heading;

	//////////////////////////////////////
	@FindBy(id = "adult")
	private WebElement btn_adult;

	@FindBy(id = "teen")
	private WebElement btn_teen;

	@FindBy(id = "kid")
	private WebElement btn_kid;

	/*****************************
	 * Action methods
	 ************************************************/

	// 112826//

	public void verify_enable_kidszone() {
		javascriptScroll(chk_kidszone);
		waitFor(3000);
		if (chk_kidszone.isSelected()) {
			System.out.println("Kidszone already enabled");
		} else {
			ClickOnWebElement(chk_kidszone);
		}
	}

	public void verify_enable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {
			System.out.println("Axis360 already enabled");
		} else {
			ClickOnWebElement(chk_axis360);
		}
	}

	public void verify_disable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {
			ClickOnWebElement(chk_axis360);
		} else {
			System.out.println("Axis360 already disabled");

		}
	}

	public void saleslibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "530743");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void kidsnyclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "9102239");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void magiclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "70222");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void savelibrary_logoff() {
		waitFor(5000);
		ClickOnWebElement(btn_saveLibrary);
		Actions action = new Actions(DriverManager.getDriver());
		action.sendKeys(Keys.ENTER).perform();
		ClickOnWebElement(btn_logoff);
		waitFor(3000);
	}

	public void profileavailability() {
		isElementPresent(btn_adult);
		isElementPresent(btn_teen);
		isElementPresent(btn_kid);

	}

	public void profilenonavailability() {

		if (btn_adult.isDisplayed()) {
			System.out.println("Error: Kidszone also enabled, Adult profile available");
		} else {
					System.out.println("Success : Profiles are disabled as expected");
				}
	}
	
	public List<String> verify_LibraryCarousel() {
		for (WebElement Heading : Carousel_Heading) {
			String Libheading = Heading.getText();
			LibHeading.add(Libheading);
					new  ArrayList<String>(Arrays.asList(Libheading.split(",")));
		}
		
		return items;

	}

}
