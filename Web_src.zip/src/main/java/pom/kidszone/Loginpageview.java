package pom.kidszone;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Loginpageview extends CommonAction {

	public String cardNumber;
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());

	public Loginpageview(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	ExcelReader reader = new ExcelReader();

	@FindBy(id = "availabilityTypeLabel")
	private WebElement lbl_availability;

	@FindBy(id = "loginBtn")
	private WebElement btn_login_Button;

	@FindBy(id = "loginBtnMobile")
	private WebElement btn_login_Button_Mobile;

//	@FindAll({ @FindBy(id = "loginBtnMobile"), @FindBy(id = "loginBtn") })
//	private WebElement btn_login_Button;id="appBannerCloseBtn"

	@FindBy(id = "appBannerCloseBtn")
	private WebElement common_PopUp;

	@FindBy(id = "dialogHeading")
	private WebElement txt_loginpopup_Heading;

	@FindBy(xpath = "//*[@id='loginForm']/div/div[1]/label")
	private WebElement label_libraryID;

	@FindBy(xpath = "//*[@id='loginForm']/div/div[2]/label")
	private WebElement label_pin;

	@FindBy(id = "LogOnModel_UserName")
	private WebElement txt_userName_Textfield;

	@FindBy(id = "LogOnModel_Password")
	private WebElement txt_password_Textfield;

	@FindBy(xpath = "//button[text()='login']")
	private WebElement loginwithpin_btn_login;

	@FindBy(xpath = "//button[text()='login']")
	private WebElement old_loginbtn;

	@FindBy(xpath = "//h2[contains(text(),'Register')]")
	private WebElement register_txt_Register;

	@FindBy(id = "showHidePassword")
	private WebElement lnk_showHidden_Password;

	@FindBy(id = "lnkShowRegPwd")
	private WebElement lnk_contactAdmin_forPassword;

	@FindBy(id = "loc_btnLogin")
	private WebElement btn_signin;

	@FindBy(id = "loc_btnLogin")
	public WebElement btn_LoginOnlyId;

	@FindBy(id = "forgotPinLink")
	private WebElement link_forgotPin;

	@FindBy(id = "dialogHeadingForgotPin")
	private WebElement txt_forgotPin_Heading;

	@FindBy(id = "IsDialog")
	private WebElement txt_forgotPin_Subheading;

	@FindBy(id = "Username")
	private WebElement txt_forgotPin_Username_Textfield;

	@FindBy(xpath = " //h2[contains(text(), 'Log Into Your Library')]")
	private WebElement txt_login;

	@FindBy(xpath = "//button[text()='Submit']")
	private WebElement btn_forgotPin_Submit;

	@FindBy(xpath = "//button[text()='submit']")
	private WebElement btn_forgotPin_SubmitOld;

	@FindBy(xpath = "//*[@id=\'loginBackBtn\']/span/svg")
	private WebElement btn_forgotPin_Back;

	@FindBy(xpath = "//*[@id=\'forgotPinModal\']/div/div/div/div[2]/button/span/svg")
	private WebElement btn_forgotPin_Close;

	@FindBy(xpath = "//*[@id=\'loginModal\']/div/div/div/div[1]/button/span")
	private WebElement btn_close_login;

	@FindBy(id = "btnLogout")
	private WebElement btn_logout;

	@FindBy(xpath = "//label[text()='Library Card ID']")
	private WebElement loginwithid_txt_librarycardid;

	@FindBy(xpath = "//*[contains(text(),' Pin Recovery')]")
	private WebElement txt_pinrecovery;

	@FindBy(id = "SecurityQuestion")
	private WebElement txt_SecurityQuestion;

	@FindBy(id = "SecurityAnswer")
	private WebElement txt_SecurityAnswern;

	@FindBy(xpath = "(//span[contains(text(), 'Welcome, Photon2')][1])[1]")
	private WebElement txt_welcomeUsername;

	@FindBy(xpath = "//*[@id=\'SendPasswordForm\']/div[3]/button")
	private WebElement security_submit;

	@FindBy(id = "RegisterModel_UserName")
	private WebElement reg_Username;

	@FindBy(id = "RegisterModel_Password")
	private WebElement reg_Password;

	@FindBy(id = "RegisterModel_SecurityQuestion_button")
	private WebElement reg_Securityquestion;

	@FindBy(id = "RegisterModel_SecurityAnswer")
	private WebElement reg_Securityanswer;

	@FindBy(id = "RegisterModel_DisplayName")
	private WebElement reg_Displayname;

	@FindBy(id = "RegisterModel_Email")
	private WebElement reg_Email;

	@FindBy(id = "adult")
	private WebElement reg_Adult;

	@FindBy(id = "teen")
	private WebElement Reg_Teen;

	@FindBy(id = "kid")
	private WebElement Reg_Kid;

	@FindBy(xpath = "//button[text()='Register']")
	private WebElement reg_Registerbtn;

	@FindBy(xpath = "//button[contains(text(),'Done')]")
	private WebElement Addprofile_btn_done;

	@FindBy(xpath = "//a[text()='Add a teen ']")
	private WebElement Addprofile_label_addTeenprofile;

	@FindBy(xpath = "//a[contains(text(),'Add a kid')]")
	private WebElement Addprofile_label_addkidprofile;

	@FindBy(id = "react-server-root")
	private WebElement cleversso_txt_loginInformation;

	@FindBy(id = "username")
	private WebElement cleversso_txtfield_userName;

	@FindBy(id = "password")
	private WebElement cleversso_txtfield_password;

	@FindBy(id = "login-username-72433957")
	private WebElement openauthensso_txtfield_userName;

	@FindBy(id = "login-password-72433957")
	private WebElement openauthensso_txtfield_password;

	@FindBy(id = "//button[@type='submit']")
	private WebElement openauthensso_btn_singin;

	@FindBy(id = "UsernamePasswordForm--loginButton")
	private WebElement cleversso_btn_loginbtn;

	@FindBy(xpath = "//h2[contains(text(),'Sign in with an OpenAthens account')]")
	private WebElement openauthenSSO_txt_login;

	@FindBy(id = "RegistrationPassword")
	private WebElement texas_input_password;

	@FindBy(xpath = "//button[text()='Register']")
	private WebElement texas_btn_register;

	@FindBy(xpath = "//*[@class='spinner-absolute spinner-loader']")
	private WebElement loader;

	@FindBy(id = "closeButton")
	private WebElement btn_CloseOverlay;

	public WebElement getTxt_SecurityQuestion() {
		return txt_SecurityQuestion;
	}

	public WebElement getTxt_SecurityAnswern() {
		return txt_SecurityAnswern;
	}

	public WebElement getRegister_txt_Register() {
		return register_txt_Register;
	}

	public WebElement getCleversso_txt_loginInformation() {
		return cleversso_txt_loginInformation;
	}

	public WebElement getOpenauthenSSO_txt_login() {
		return openauthenSSO_txt_login;
	}

	/*****************************
	 * Action methods
	 ************************************************/

//	public void app_launch(String loginType) throws Exception {
//		if (loginType.equalsIgnoreCase("idAndPassword")) {
//			DriverManager.getDriver().get(getData("idAndPassword"));
//		} else if (loginType.equalsIgnoreCase("prefixWithPin")) {
//			DriverManager.getDriver().get(getData("prefixWithPin"));
//		} else if (loginType.equalsIgnoreCase("prefixWithOutPin")) {
//			DriverManager.getDriver().get(getData("prefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("AxisonlyprefixWithoutPin")) {
//			DriverManager.getDriver().get(getData("AxisonlyprefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("SSO")) {
//			DriverManager.getDriver().get(getData("SSO"));
//		} else if (loginType.equalsIgnoreCase("cleverSSO")) {
//			DriverManager.getDriver().get(getData("cleverSSO"));
//		} else if (loginType.equalsIgnoreCase("LMidAndPassword")) {
//			DriverManager.getDriver().get(getData("LMidAndPassword"));
//		} else if (loginType.equalsIgnoreCase("LMprefixWithoutPin")) {
//			DriverManager.getDriver().get(getData("LMprefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("LMprefixWithPin")) {
//			DriverManager.getDriver().get(getData("LMprefixWithPin"));
//		} else if (loginType.equalsIgnoreCase("LMaxis360Sales")) {
//			DriverManager.getDriver().get(getData("LMaxis360Sales"));
//		} else if (loginType.equalsIgnoreCase("manualnyc")) {
//			DriverManager.getDriver().get(getData("manualnyc"));
//		}
//
//		waitFor(5000);
//	}

	public void add_teen() {

		ClickOnWebElement(Addprofile_label_addTeenprofile);
		waitFor(3000);
	}

	public void add_kid() {

		ClickOnWebElement(Addprofile_label_addkidprofile);
		waitFor(3000);

	}

	public void updated_login() {

		isElementPresent(label_libraryID);
		Logger.log("User is able to view the Library ID");
		isElementPresent(label_pin);
		Logger.log("User is able to view the PIN Label");
		ClickOnWebElement(btn_close_login);

	}

	public void Registerdetailsps() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(reg_Securityanswer, testData.get(0).get("SecAnswer"));
		SendKeysOnWebElement(reg_Displayname, testData.get(0).get("displayname"));
		SendKeysOnWebElement(reg_Email, "Photon" + RandomStringGenerate() + "@gmail.com");
		waitFor(6000);

	}

	public void click_loginPage() {

		System.out.println(btn_login_Button.isDisplayed());

		if (btn_login_Button.isDisplayed()) {
			System.out.println("Execution happening on the Web browser, so app banner is not present");
			waitFor(5000);
			jsClick(btn_login_Button);
		} else {
			System.out.println("Execution happening on the mobile browser, so app banner is present");
			if (common_PopUp.isDisplayed()) {
				waitFor(5000);
				jsClick(common_PopUp);
			} else {

				System.out.println("Pop up is not displayed");

			}
			waitFor(5000);
			jsClick(btn_login_Button_Mobile);
		}
	}

	public void handlePopUp() {
		try {
			if (isElementPresent(common_PopUp)) {

				ClickOnWebElement(common_PopUp);
				Logger.log("Close button is clicked");

			} else {

				Logger.log("Close button is not displayed in the application");
			}

		} catch (Exception e) {
//			e.printStackTrace();
			Logger.log("Close button is not displayed in the application");
		}

	}

	public void login_page_validate() {

		try {
			WaitForWebElement(txt_loginpopup_Heading);
			Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
			Assert.assertEquals(txt_userName_Textfield.isDisplayed(), true);
			Assert.assertEquals(txt_password_Textfield.isDisplayed(), true);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clickLogin() {
		btn_login_Button.click();
	}

	public void loginwith_password_popup() throws InvalidFormatException, IOException {

		WaitForWebElement(txt_loginpopup_Heading);
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "User");
		SendKeysOnWebElement(txt_userName_Textfield, testData.get(0).get("Username"));
		SendKeysOnWebElement(txt_password_Textfield, testData.get(0).get("Password"));
		ClickOnWebElement(btn_signin);
		waitFor(5000);
		Assert.assertEquals(btn_logout.getText(), "LOGOUT");
	}

	public void clickForgotpassword() {
		jsClick(link_forgotPin);
		waitFor(3000);

	}

	public void verifyFogotpin() {
		waitFor(6000);
		Assert.assertEquals(txt_forgotPin_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_forgotPin_Username_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_forgotPin_Submit.isDisplayed(), true);
	}

	public void verifyFogotpinOldUI() {
		waitFor(6000);
		Assert.assertEquals(txt_forgotPin_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_forgotPin_Username_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_forgotPin_SubmitOld.isDisplayed(), true);
	}

	public void submitFogotpin() throws InvalidFormatException, IOException {
		SendKeysOnWebElement(txt_forgotPin_Username_Textfield, "BTAuto2");
		ClickOnWebElement(btn_forgotPin_SubmitOld);
		waitFor(2000);

	}

	public void verifyRegisterScreenwithPin() {
		waitFor(6000);
		Assert.assertEquals(reg_Username.isDisplayed(), true);
		Assert.assertEquals(reg_Password.isDisplayed(), true);
		Assert.assertEquals(reg_Securityquestion.isDisplayed(), true);
		Assert.assertEquals(reg_Securityanswer.isDisplayed(), true);
		Assert.assertEquals(reg_Displayname.isDisplayed(), true);
		Assert.assertEquals(reg_Email.isDisplayed(), true);
//		Assert.assertEquals(reg_Adult.isDisplayed(), true);
//		Assert.assertEquals(Reg_Teen.isDisplayed(), true);
//		Assert.assertEquals(Reg_Kid.isDisplayed(), true);
		Assert.assertEquals(reg_Registerbtn.isDisplayed(), true);
	}

	public void RegisterwithPin() throws InvalidFormatException, IOException {
		waitFor(6000);
		Assert.assertEquals(reg_Username.isDisplayed(), true);
		ClickOnWebElement(reg_Password);
		waitFor(6000);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(reg_Password, testData.get(0).get("RegPassword"));
		ClickOnWebElement(reg_Securityquestion);
	}

	public void Registerdetails(String displayname, String email) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(reg_Securityanswer, testData.get(0).get("SecAnswer"));
		SendKeysOnWebElement(reg_Displayname, displayname);
		SendKeysOnWebElement(reg_Email, email);
		waitFor(6000);

	}

	public void completeRegistration() {
		Assert.assertEquals(reg_Adult.isDisplayed(), true);
		ClickOnWebElement(reg_Registerbtn);
		waitFor(6000);
	}

	public void verifyRegisterScreenwithoutPin() {
		waitFor(6000);
		Assert.assertEquals(reg_Username.isDisplayed(), true);
		// Assert.assertEquals(reg_Password.isDisplayed(), true);
		Assert.assertEquals(reg_Securityquestion.isDisplayed(), true);
		Assert.assertEquals(reg_Securityanswer.isDisplayed(), true);
		Assert.assertEquals(reg_Displayname.isDisplayed(), true);
		Assert.assertEquals(reg_Email.isDisplayed(), true);
		// Assert.assertEquals(reg_Adult.isDisplayed(), true);
		// Assert.assertEquals(Reg_Teen.isDisplayed(), true);
		// Assert.assertEquals(Reg_Kid.isDisplayed(), true);
		Assert.assertEquals(reg_Registerbtn.isDisplayed(), true);
	}

	public void verifyFogotpassword() {
		waitFor(6000);
		Assert.assertEquals(txt_forgotPin_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_forgotPin_Username_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_forgotPin_Submit.isDisplayed(), true);

	}

	public void submitFogotpassword(String username) throws InvalidFormatException, IOException {
		waitFor(6000);
		SendKeysOnWebElement(txt_forgotPin_Username_Textfield, username);
		ClickOnWebElement(btn_forgotPin_Submit);
		waitFor(6000);
	}

	private void ClickOnWebElement(boolean displayed, boolean b) {
		// TODO Auto-generated method stub

	}

	public void securityQuestion() {
		Assert.assertEquals(txt_SecurityQuestion.isDisplayed(), true);
		Assert.assertEquals(txt_SecurityAnswern.isDisplayed(), true);
		Assert.assertEquals(security_submit.isDisplayed(), true);

	}

	public void onlywithLibraryid() {

		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_userName_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_LoginOnlyId.isDisplayed(), true);
	}

	public void loginwithpinview() {
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_userName_Textfield.isDisplayed(), true);
		Assert.assertEquals(txt_password_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_signin.isDisplayed(), true);

	}

	public void loginwithoutPinRegistration(String libraryid) {
		// Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		jsClick(txt_userName_Textfield);
		// ClickOnWebElement(txt_userName_Textfield);
		SendKeysOnWebElement(txt_userName_Textfield, libraryid);
		jsClick(btn_LoginOnlyId);
		// ClickOnWebElement(btn_signinonlyid);
		waitFor(4000);
	}

	public void loginwithoutPinRegistrationNew(String libraryid) {
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		SendKeysOnWebElement(txt_userName_Textfield, libraryid + RandomStringGenerate());
		ClickOnWebElement(btn_LoginOnlyId);
		waitFor(4000);
	}

	public void loginverifyonlyId() {
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		Assert.assertEquals(txt_userName_Textfield.isDisplayed(), true);
		Assert.assertEquals(btn_signin.isDisplayed(), true);
	}

	public void enterIDandPassword(String libraryid, String password) {
		ClickOnWebElement(txt_userName_Textfield);
		SendKeysOnWebElement(txt_userName_Textfield, libraryid);
		ClickOnWebElement(txt_password_Textfield);
		SendKeysOnWebElement(txt_password_Textfield, password);
	}

	public void loginwithpin_clickForgotPin() {
		waitFor(3000);
		ClickOnWebElement(link_forgotPin);
	}

	public void forgotPin_Username_Textfield(String username) throws InvalidFormatException, IOException {
		SendKeysOnWebElement(txt_forgotPin_Username_Textfield, "BTgeetha");
		ClickOnWebElement(btn_forgotPin_Submit);
		waitFor(2000);
	}

	public boolean navigate_forgotpinPage() {
		boolean b = true;
		if (txt_SecurityQuestion.isDisplayed()) {
			Assert.assertEquals(txt_SecurityQuestion.isDisplayed(), true);
		} else {
			Logger.log("User is not able to see forgot pin page");
		}
		return b;
	}

	public void enter_SecurityAnswer(String securityanswer) {
		SendKeysOnWebElement(txt_SecurityAnswern, securityanswer);
		ClickOnWebElement(btn_forgotPin_Submit);
		waitFor(2000);
	}

	public boolean view_passwordRecovery() {
		boolean b = true;
		isElementPresent(txt_pinrecovery);
		return b;
	}

	public boolean viewlogin_Page() {
		boolean b = true;
		isElementPresent(txt_login);
		return b;
	}

	public void already_signeduser_prefixloginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid);
		SendKeysOnWebElement(txt_password_Textfield, pin);
		waitFor(2000);
		jsClick(btn_LoginOnlyId);
		// inVisibilityWait(loader);
	}

	public void oldalready_signeduser_prefixloginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid);
		SendKeysOnWebElement(txt_password_Textfield, pin);
		waitFor(2000);
		ClickOnWebElement(btn_LoginOnlyId);
		waitFor(6000);

	}

	public void enter_loginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		SendKeysOnWebElement(txt_password_Textfield, pin);
		ClickOnWebElement(btn_LoginOnlyId);
	}

	public void existing_loginwithPin(String loginid, String pin) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		cardNumber = txt_userName_Textfield.getAttribute("value");
		System.out.println(cardNumber);
		SendKeysOnWebElement(txt_password_Textfield, pin);
		ClickOnWebElement(btn_LoginOnlyId);
		inVisibilityWait(btn_LoginOnlyId);
	}

	public void existing_loginwithIdPin(String pin) {
		System.out.println(cardNumber);
		SendKeysOnWebElement(txt_userName_Textfield, cardNumber);
		SendKeysOnWebElement(txt_password_Textfield, pin);
		ClickOnWebElement(btn_LoginOnlyId);
		preferenceScreen_popup();
	}

	public void enter_loginIdonly(String loginid) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		ClickOnWebElement(btn_LoginOnlyId);
		waitFor(2000);
	}

	public void enter_loginwithoutPin(String loginid) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid + RandomStringGenerate());
		ClickOnWebElement(loginwithpin_btn_login);
		waitFor(2000);
	}

	public void enter_loginIDandPassword(String loginid, String password) {
		SendKeysOnWebElement(txt_userName_Textfield, loginid);
		SendKeysOnWebElement(txt_password_Textfield, password);
		ClickOnWebElement(loginwithpin_btn_login);
		waitFor(2000);
	}

	public boolean view_updatedLoginScreen() {
		boolean b = true;
		String text = txt_welcomeUsername.getText();
		Assert.assertEquals(txt_welcomeUsername.getAttribute("title"), text);
		return b;

	}

	public void Enter_loginWithPin_cleverSSO(String username, String Password) {
		SendKeysOnWebElement(cleversso_txtfield_userName, username);
		SendKeysOnWebElement(cleversso_txtfield_password, Password);
		ClickOnWebElement(cleversso_btn_loginbtn);
		waitFor(5000);

	}

	public void Enter_login_openAuthens(String username, String Password) {
		SendKeysOnWebElement(openauthensso_txtfield_userName, username);
		SendKeysOnWebElement(openauthensso_txtfield_password, Password);
		waitFor(2000);

	}

	public void enterRandamIDandPassword(String libraryid, String password) {
		jsClick(lnk_contactAdmin_forPassword);
		waitFor(2000);
		SendKeysOnWebElement(texas_input_password, password);
		jsClick(texas_btn_register);
		waitFor(3000);
		visibilityWait(reg_Username);
		SendKeysOnWebElement(reg_Username, libraryid + RandomStringGenerate());
		waitFor(2000);
		SendKeysOnWebElement(reg_Password, password);
		waitFor(3000);
	}

	public void preferenceScreen_popup() {
		try {

			ClickOnWebElement(btn_CloseOverlay);

		} catch (Exception e) {

			Logger.log("Set Preferences Pop up is not displayed");
		}
	}

	public void click_loginbtnAuthens() {
		visibilityWait(btn_login_Button);
		findByClick(btn_login_Button);
		waitFor(2000);

	}
	
	public WebElement getReg_Username() {
		return txt_userName_Textfield;
	}
	
	public WebElement getCarouselTitle() {
		// TODO Auto-generated method stub
		return null;
	}

}
