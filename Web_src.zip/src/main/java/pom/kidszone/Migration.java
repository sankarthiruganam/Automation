package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class Migration extends CommonAction {

	public Migration(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	Profile profile = new Profile(DriverManager.getDriver());

	@FindBy(xpath = "//a[contains(text(),'See All ')]")
	private WebElement newsMag_SeeAll;

	@FindBy(xpath = "(//a[contains(text(),'See All ')])[1]")
	private WebElement newsMag_Tier1SeeAll;

	@FindBy(xpath = "//axis360-third-party-refiner-ac[@class='ng-star-inserted']")
	public WebElement newsMag_Tier2_Refiner;

	@FindBy(xpath = "//label[contains(text(),'Newspapers & Magazines')]")
	public WebElement newsMag_categories;

	@FindBy(id = "dummy")
	private WebElement newsMag_articleSeeAll;

	@FindBy(xpath = "//*[contains(text(),'Display Checkout History')]")
	public WebElement diplayCheckHisCheckBox;

	@FindBy(xpath = "//*[contains(text(),' Display Insights & Badges')]")
	public WebElement diplayInsBadCheckBox;

	@FindBy(id = "alert-dialog-title")
	public WebElement displayCheckoutPopUp;

	@FindBy(xpath = "//*[@svgicon='kz-profile-user']")
	public WebElement avatarIcon;

	@FindBy(xpath = "//*[@class='cdk-overlay-container']")
	public WebElement outsideArea;

	@FindBy(id = "alert-heading")
	public WebElement displayCheckoutPopUpHeading;

	@FindBy(id = "loc_textalertcontent")
	public WebElement displayCheckoutPopUpDesc;

	@FindBy(id = "loc_cancelbtn")
	public WebElement displayCheckoutPopUpCancel;

	@FindBy(id = "loc_confirmbtnOK")
	public WebElement displayCheckoutPopUpDisable;

	@FindBy(xpath = "//div[@class='featured-magazine ng-star-inserted']")
	public WebElement tier1_newsMag;

	@FindBy(xpath = "(//div[@role='button'])[2]")
	public WebElement Tier2_country_dropdwn;

	@FindBy(xpath = "//label[@class='ac-textBlock']")
	public List<WebElement> Tier2_country;

	@FindBy(xpath = "//label[contains(text(),'Publication Date')]")
	public WebElement Tier2_publicationDate;

	@FindBy(xpath = "//label[contains(text(),'Relevance')]")
	public WebElement Tier2_Relevence;

	@FindBy(xpath = "(//div[@id='newspaper_magazine_book-img'])[1]")
	public WebElement publicationTitle_NavTier3;

	@FindBy(xpath = "//div[@class='third-party-card-details']")
	public WebElement newsmag_tier3;

	@FindBy(xpath = "(//div[@class='ac-textBlock'])[1]")
	public WebElement Tier3_publicationName;

	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]/following::div[2]")
	public WebElement Tier3_CountrynName;

	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]")
	public WebElement Tier3_Country;

	@FindBy(xpath = "//div[contains(text(),'Read Now')]")
	public WebElement Tier3_ReadnowCTA;

	@FindBy(xpath = "//div[contains(text(),'Select Issue')]")
	public WebElement Tier3_selectIssueCTA;

	@FindBy(xpath = "//div[contains(text(),'LANGUAGE')]")
	public WebElement Tier3_Language;

	@FindBy(xpath = "//div[contains(text(),'LANGUAGE')]/following::div[2]")
	public WebElement Tier3_LanguageName;

	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]/following::div[2]")
	public WebElement Tier3_MultipleCountry;

	@FindBy(id = "countrydownarrow")
	public WebElement Tier3_MultipleCountry_downarrow;

	@FindBy(id = "countryuparrow")
	public WebElement Tier3_MultipleCountry_uparrow;

	@FindBy(id = "loc_TxtFeaturedReadingProgram")
	public WebElement FeaturedReadingprog;

	@FindBy(xpath = "(//a[contains(text(),'See All Open Programs ')])[1]")
	public WebElement seeAll_FeaturedReadingprogram;

	@FindBy(xpath = "(//*[@id='newspaper_magazine_book-img'])[2]")
	public WebElement newsPaperCard;

	@FindBy(xpath = "//*[@class='third-party-card-details']")
	public WebElement newsPaperDetailsScreen;

	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'LANGUAGE')]")
	public WebElement language;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[1]")
	public WebElement countryDetail1;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[2]")
	public WebElement countryDetail2;

	@FindBy(xpath = "//button[@title='Read']")
	public WebElement readNowCta;

	@FindBy(xpath = "//button[@title='Select Issue']")
	public WebElement selectIssueCta;

	@FindBy(id = "newspaper_magazine_title")
	public WebElement publicationName;

	@FindBy(xpath = "//*[@id='countrydownarrow']//img")
	public WebElement multipleCountryDropDwn;

	@FindBy(id = "countryuparrow")
	public WebElement multipleCountryupArrow;

	@FindBy(xpath = "//a[contains(text(),'See All ')]")
	public WebElement seeAllLibReader;

	@FindBy(xpath = "//*[@aria-label='See All Magazines']")
	public WebElement seeAllTier1Reader;

	@FindBy(xpath = "")
	public WebElement seeAllTier2Reader;

	@FindBy(id = "refine_modal_header_text_country")
	public WebElement filterCountry;

	@FindBy(xpath = "//*[@class='ac-container'][@id='cardContent2']")
	public WebElement listedCountry;

	@FindBy(xpath = "//label[@class='ac-textBlock'][contains(text(),'United States')]")
	public WebElement listedCountryUS;

	@FindBy(xpath = "//*[@class='kz-press-reader']")
	public WebElement tier1Page;

	@FindBy(xpath = "(//label[contains(text(),'Newspapers & Magazines')])[1]")
	public WebElement newsPaperCategory;

	@FindBy(xpath = "//*[@class='search-result-info']//*[contains(text(),'Publications')]")
	public WebElement newsPaperResult;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[1]")
	public WebElement mutipleCountryRefPub;

	@FindBy(xpath = "//*[@id='defaultcountrytext']")
	public WebElement countryText;

	@FindBy(xpath = "(//div[@id='newspaper_magazine_ribbon_text'])[1]")
	public WebElement multipleCountry_Ribbon;

	@FindBy(xpath = "")
	public WebElement mutipleCountryRefArt;

	@FindBy(xpath = "//*[contains(text(),'Publications')]//following::*[@svgicon='kz-right-arrow']")
	public WebElement seeAllLinkPubResult;

	@FindBy(xpath = "//*[contains(text(),'Articles')]//following::*[@svgicon='kz-right-arrow']")
	public WebElement seeAllLinkArtResult;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	public WebElement tier2Publications;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	public WebElement tier2Articles;

	@FindBy(xpath = "//*[@class='featured-card-carousel']")
	public WebElement featuredBannerPubTier1;

	@FindBy(xpath = "//a[contains(@aria-label,'See all Based')]")
	public WebElement basedOnSeeAll;

	@FindBy(xpath = "//*[@class='title-list-container']//*[contains(text(),'based on your interest')]")
	public WebElement basedOnTier2;

	@FindBy(xpath = "//*[@class='mat-card-image card-image']")
	public List<WebElement> titleCardTier2;

	@FindBy(xpath = "//*[@svgicon='kz-edit-icon']")
	public WebElement editIconBasedOnTier2;

	@FindBy(xpath = "")
	public WebElement saveCTABasedOnTier2;

	@FindBy(xpath = "//*[@class='interest-heading']")
	public WebElement intrestSurveyPage;

	@FindBy(xpath = "(//*[@alt='catagories'])")
	public List<WebElement> intrestSurveyTopics;

	@FindBy(id = "loc_btnSaveinterest")
	public WebElement intrestSurveySave;

	@FindBy(xpath = "")
	public WebElement noRecommendationDisplayed;

	@FindBy(xpath = "(//*[@id='newspaper_magazine_ribbon_text'][contains(text(),'United...')])[1]")
	public WebElement defaultCountrySorted;

	@FindBy(xpath = "//*[@class='kz-toast-msg']/*[contains(text(),'Success')]")
	private WebElement sucessMsg;

	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'ISSUE DATE')]")
	public WebElement issueDate;

	@FindBy(xpath = "//*[@class='featured-card-carousel']//*[@class='ac-textBlock adp-card-title-text-bottom']")
	public List<WebElement> readerTypeDisplayed;

	@FindBy(xpath = "//h2[contains(text(),'Publications ')]")
	public WebElement SearchResult_publicationtxt;

	@FindBy(id = "refine_modal_header_text_sort_by")
	public WebElement Refiner_sort;

	@FindBy(xpath = "//label[contains(text(),'Popularity')]")
	public WebElement Refiner_popularity;

	@FindBy(xpath = "//label[contains(text(),'Relevance')]")
	public WebElement Refiner_Relevence;

	@FindBy(xpath = "//label[contains(text(),'Publication Date')]")
	public WebElement Refiner_publicationDate;

	@FindBy(xpath = "//label[@class='ac-textBlock'][contains(text(),'International')]")
	public WebElement listedcountryInternational;

	@FindBy(id = "refine_modal_header_text_languages")
	public WebElement filterLanguage;

	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'Afrikaans')]")
	public WebElement listedlanguage;

	@FindBy(xpath = "//div[@class='mat-tab-link-container']")
	public WebElement refinerPills;

	@FindBy(xpath = "//a[contains(text(),'Clear All')]")
	public WebElement clearAllPill;

	@FindBy(xpath = "//div[@class='footer-brand-logo']")
	public WebElement BoundlessLogo_footer;

	@FindBy(xpath = "//*[@class='book-of-month-col']")
	public WebElement BookOfMonth_Widget;

	@FindBy(xpath = "//*[@class='carousel-arrow carousel-arrow-prev']")
	public WebElement leftArrow_BookOfTheMonth;

	@FindBy(xpath = "(//*[@id='kz-bookofmonth']/following::div[@class='carousel-arrow carousel-arrow-next'])[1]")
	public WebElement RightArrow_BookOfTheMonth;

	@FindBy(xpath = "//*[@class='book-of-month-wrapper']/figure/img")
	public List<WebElement> ListofTitles_BooksofTheMonth;

	@FindBy(xpath = "//*[@class='book-of-month-para']")
	public List<WebElement> titleDescription_BookOfTheMonth;

	@FindBy(xpath = "//*[@class='titledetails-bookwrapper']")
	public WebElement titleDetailPage;

	@FindBy(xpath = "//*[@class='thirdparty-tiertworightwrap']")
	public WebElement newsMag_tier2_page;

	@FindBy(xpath = "")
	public List<WebElement> TitlesIn_BookOfTheMonth;

	@FindBy(xpath = " ")
	public WebElement Featured_seeAll;
	
	@FindBy(xpath = "//*[@aria-label='See All Newspapers']")
	public WebElement newspaper_otherCarouselSeeAll;
	
	

	public boolean newspaperMagazine_tier2_RefinerDetails() {
		boolean b = true;
		Assert.assertTrue(Refiner_sort.isDisplayed());
		Assert.assertTrue(Refiner_popularity.isDisplayed());
		Assert.assertTrue(Refiner_Relevence.isDisplayed());
		Assert.assertTrue(Refiner_publicationDate.isDisplayed());
		return b;

	}

	public void click_NewsMagSeeAll() {
		visibilityWait(newsMag_SeeAll);
		javascriptScroll(newsMag_SeeAll);
		jsClick(newsMag_SeeAll);
		visibilityWait(tier1_newsMag);
	}

	public void clickNewsPaperTitleCardLib() {
		waitFor(2000);
		jsClick(newsPaperCard);
		WaitForWebElement(newsPaperDetailsScreen);
	}

	public void click_Tier1SeeAll() {
		javascriptScroll(newsMag_Tier1SeeAll);
		jsClick(newsMag_Tier1SeeAll);
		waitFor(2000);
	}

	public void verifyNewsPaperDetails() {
		waitFor(2000);
		Assert.assertTrue(publicationName.isDisplayed());
		Assert.assertTrue(language.isDisplayed());
		Assert.assertTrue(issueDate.isDisplayed());
		Assert.assertTrue(countryDetail1.isDisplayed());
		Assert.assertTrue(selectIssueCta.isDisplayed());
		Assert.assertTrue(readNowCta.isDisplayed());
	}

	public void click_newsmagCategories() {
		waitFor(2000);
		visibilityWait(newsMag_categories);
		javascriptScroll(newsMag_categories);
		jsClick(newsMag_categories);
		waitFor(2000);
	}

	public void clickBack() {
		waitFor(2000);
		DriverManager.getDriver().navigate().back();
//			jsClick(intrestSurveySave);
		WaitForWebElement(basedOnTier2);
	}

	public void displayedOrder() {
		for (int i = 0; i < readerTypeDisplayed.size(); i++) {
			if (i == 0) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Magazine"), true);
				Logger.log("Magazine Displayed First in the Order");
			} else if (i == 1) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Newspaper"), true);
				Logger.log("Newspaper Displayed Second in the Order");
			} else if (i == 2) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Magazine"), true);
				Logger.log("Magazine Displayed Third in the Order");
			} else if (i == 3) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Newspaper"), true);
				Logger.log("Newspaper Displayed Fourth in the Order");
			}
		}
	}

	public void clickDisplayCheckoutHistory() {
		jsClick(diplayCheckHisCheckBox);
		waitFor(2000);
	}

	public void clickDisplayInsightBadges() {
		jsClick(diplayInsBadCheckBox);
		waitFor(2000);
	}

	public void clickDisplayCheckoutCancel() {
		waitFor(2000);
		jsClick(displayCheckoutPopUpCancel);
		inVisibilityWait(displayCheckoutPopUp);
	}

	public void clickDisplayCheckoutDisable() {
		waitFor(2000);
		jsClick(displayCheckoutPopUpDisable);
		inVisibilityWait(displayCheckoutPopUp);
	}

	public void verify_DefaultCountrySelected() {
		javascriptScroll(Tier2_country_dropdwn);
		jsClick(Tier2_country_dropdwn);
		waitFor(2000);
		for (int i = 0; i < Tier2_country.size(); i++) {
			if (Tier2_country.get(i).isSelected()) {
				System.out.println("Default selected country is: " + Tier2_country.get(i));
				break;
			} else {

			}
		}

	}

	public void click_PublicationCarouselSeeAll() {
		waitFor(2000);
		javascriptScroll(newsMag_SeeAll);
		jsClick(newsMag_SeeAll);
		waitFor(2000);

	}

	public void click_PublicationTitle_navTier3() {
		javascriptScroll(publicationTitle_NavTier3);
		jsClick(publicationTitle_NavTier3);
		visibilityWait(newsmag_tier3);

	}

	public boolean verify_Tier3Details() {
		boolean b = true;
		Assert.assertTrue(Tier3_publicationName.isDisplayed());
		Assert.assertTrue(Tier3_ReadnowCTA.isDisplayed());
		Assert.assertTrue(Tier3_selectIssueCTA.isDisplayed());
		javascriptScroll(Tier3_Country);
		if (Tier3_Country.isDisplayed()) {
			Assert.assertTrue(Tier3_CountrynName.isDisplayed());
		} else if (Tier3_Language.isDisplayed()) {
			Assert.assertTrue(Tier3_LanguageName.isDisplayed());
		}

		return b;
	}

	public void click_multiplicCountryDownarrow() {
		visibilityWait(Tier3_MultipleCountry_downarrow);
		jsClick(Tier3_MultipleCountry_downarrow);

	}

	public void clickNewsPaperTitleCard() {
		visibilityWait(newsPaperDetailsScreen);
		jsClick(newsPaperCard);
		visibilityWait(newsPaperDetailsScreen);
	}

	public void multipleCountry() {
		if (isElementPresent(countryDetail1)) {
			waitFor(2000);
			Logger.log("First Country detail is Available");
		} else if (isElementPresent(countryDetail2)) {
			waitFor(2000);
			Logger.log("Multiple Country detail is Available");
		}
	}

	public void multipleCountryDropDown() {
		javascriptScroll(multipleCountryDropDwn);
		jsClick(multipleCountryDropDwn);
		WaitForWebElement(multipleCountryupArrow);
		waitFor(2000);
		multipleCountry();
	}

	public void multipleCountryUpArrow() {
		javascriptScroll(multipleCountryupArrow);
		jsClick(multipleCountryupArrow);
		inVisibilityWait(multipleCountryupArrow);
	}

	public void clickSeeAllReaderLib() {
		javascriptScroll(seeAllLibReader);
		jsClick(seeAllLibReader);
		WaitForWebElement(tier1Page);
	}

	public void clickSeeAllReaderTier1() {
		javascriptScroll(seeAllTier1Reader);
		jsClick(seeAllTier1Reader);
		WaitForWebElement(tier2Publications);
	}

	public void clickNewsPaperCategory() {
		javascriptScroll(newsPaperCategory);
		jsClick(newsPaperCategory);
		// WaitForWebElement(newsPaperResult);
	}

	public void clickSeeAllPubSearchResult() {
		javascriptScroll(seeAllLinkPubResult);
		jsClick(seeAllLinkPubResult);
		WaitForWebElement(tier2Publications);
	}

	public void clickSeeAllArtSearchResult() {
		javascriptScroll(seeAllLinkArtResult);
		jsClick(seeAllLinkArtResult);
		WaitForWebElement(tier2Articles);
	}

	public void clickOutsidePopUpArea() {
		javascriptScroll(profile.profileEditSection);
		jsClick(profile.profileEditSection);
	}

	public void clickBasedOnSeeAll() {
		visibilityWait(basedOnSeeAll);
		jsClick(basedOnSeeAll);
		visibilityWait(basedOnTier2);
	}

	public void clickEditIconBasedOn() {
		jsClick(editIconBasedOnTier2);
		WaitForWebElement(intrestSurveyPage);
	}

	public void updateInterestSurvey() {
		javascriptScroll(intrestSurveyTopics.get(4));
		jsClick(intrestSurveyTopics.get(4));
		javascriptScroll(intrestSurveyTopics.get(8));
		jsClick(intrestSurveyTopics.get(8));
	}

	public void clickSaveCTA() {
		waitFor(2000);
		jsClick(intrestSurveySave);
		WaitForWebElement(sucessMsg);
		WaitForWebElement(basedOnTier2);
	}

	public void clickFilterCountry() {
		jsClick(filterCountry);
		WaitForWebElement(listedCountry);
		if (listedCountryUS.isSelected()) {
			Logger.log("User able to see the selected by Default");
		}
	}

	public void selectRefiners() {
		ClickOnWebElement(Refiner_Relevence);
		WaitForWebElement(filterCountry);
		ClickOnWebElement(filterCountry);
		WaitForWebElement(listedcountryInternational);
		ClickOnWebElement(listedcountryInternational);
		WaitForWebElement(filterLanguage);
		ClickOnWebElement(filterLanguage);
		WaitForWebElement(listedlanguage);
		ClickOnWebElement(listedlanguage);

	}

	public void clickTitleInBookOfTheMonthSection() {
		visibilityListWait(ListofTitles_BooksofTheMonth);
		jsClick(ListofTitles_BooksofTheMonth.get(1));
		visibilityWait(titleDetailPage);
		Assert.assertTrue(titleDetailPage.isDisplayed());

	}

	public void countOfBookOfTheMonth() {
		boolean b=true;
		int size2 = ListofTitles_BooksofTheMonth.size();
		System.out.println("Total titles count----"+size2);
			if (ListofTitles_BooksofTheMonth.size() == 10) {
				b=true;
			}else {
				b=false;
			}
		

	}

	public void verify_MultipleTitleBooksOftheMonth() {
		boolean b = true;
		int size = ListofTitles_BooksofTheMonth.size();
		System.out.println("size----------------" + size);
		for (int i = 0; i <= size; i++) {
			if (RightArrow_BookOfTheMonth.isDisplayed()) {
				jsClick(RightArrow_BookOfTheMonth);
				Assert.assertTrue(ListofTitles_BooksofTheMonth.size() == size);
				b = true;
			} else {
				b = false;
				break;

			}

		}

	}
	
	
	public void validated_LeftAndRightArrowFor_BooksOfTheMonth() {
	if (leftArrow_BookOfTheMonth.isDisplayed()) {
		System.out.println("---------left arrow is displayed");
		Assert.assertTrue(RightArrow_BookOfTheMonth.isDisplayed());
	} else {
		System.out.println("---------Right arrow is displayed");
		jsClick(RightArrow_BookOfTheMonth);
		visibilityWait(leftArrow_BookOfTheMonth);
		Assert.assertTrue(leftArrow_BookOfTheMonth.isDisplayed());
		
	}
		
	}
	
	public void verify_DescriptionOfBooksofTheMonth() {
		boolean b=true;
		if (titleDescription_BookOfTheMonth.size()!=0) {
			b=true;
		}else {
			b=false;
		}

	}

	public void click_NewsMag_FeaturedSeeAll() {
		javascriptScroll(Featured_seeAll);
		jsClick(Featured_seeAll);

	}
	
	public void Click_newspaperMagOtherSeeAllCTA() {
		javascriptScroll(newspaper_otherCarouselSeeAll);
		jsClick(newspaper_otherCarouselSeeAll);
		visibilityWait(newsMag_tier2_page);

	}
  

}
