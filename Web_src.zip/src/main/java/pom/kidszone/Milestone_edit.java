package pom.kidszone;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;
public class Milestone_edit extends CommonAction {
	Milestone milestone = new Milestone(DriverManager.getDriver());

	public Milestone_edit(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "(//*[contains(text(),'MilestoneProg ')])[1]")
	public WebElement Joined_upcomingProg;
	
	@FindBy(xpath = "//mat-icon[@svgicon='kz-addplus']")
	public WebElement select_AddaTitle;
	
	@FindBy(xpath = "//button[contains(text(),'Search Your Library')]")
	public WebElement popup_SearchyourLibrary;
	
	@FindBy(xpath = "//button[contains(text(),'Add Your Own Title')]")
	public WebElement popup_AddyourownTitle;
	
	@FindBy(xpath = "//button[contains(text(),'Reset')]")
	public WebElement Search_Clear;
	
	@FindBy(xpath = "//mat-icon[@svgicon='close']")
	public WebElement AdvanceSearch_CloseIcon;
	
	@FindBy(id = "searchText")
	private WebElement AdvancedSearch_input;
	
	@FindBy(xpath = "//button[contains(text(),'Search')]")
	public WebElement AdvancedSearch_Search;
	
	@FindBy(xpath = "//div[@class='search-view ng-star-inserted']")
	public WebElement SearchResults_Screen;
	
	@FindBy(xpath = "(//span[contains(text(),'Add')])[1]")
	public WebElement SearchResults_AddaTitle;
	
	@FindBy(xpath = "")
	public WebElement Titles_Formats;
	
	@FindBy(xpath = "//div[@class='kz-drawer-refiners-container kz-search-refiners']")
	public WebElement SearchResults_Filter;

	@FindBy(xpath = "//mat-icon[@svgicon='kz-filter-icon']")
	public WebElement SearchResults_Filter_mobile;
	
	@FindBy(xpath = "//mat-card-title[contains(text(),'AutoMilestoneProgram_OngoingProgm ')]")
	public WebElement Activeprog_joined;
	
	@FindBy(xpath = "(//div[@class='kz-progress-bar'])")
	public WebElement Title_progress;
	
	@FindBy(xpath = "(//*[contains(text(),'Checkout')])[2]")
	public WebElement CheckoutCTA_progm;
		
	@FindBy(xpath = "(//*[contains(text(),'Place Hold')])[2]")
	public WebElement placeHoldCTA_progm;
	
	@FindBy(xpath = "(//*[contains(text(),'Read')])[2]")
	public WebElement ReadnowCTA_progm;
	
	@FindBy(xpath = "//mat-card-title[contains(text(),'Completed_BadgeProgram ')]")
	public WebElement completed_MilestoneProg;
	
	@FindBy(xpath = "(//div[@class='display-date ng-star-inserted'])[3]")
	public WebElement Reading_AllTitles;
	
	@FindBy(xpath = "//span[contains(text(),'Completed')]")
	public WebElement view_programAs_completed;
	
	@FindBy(id = "loc_txt_COMPLETED")
	public WebElement Title_Completed_Status;
	
	@FindBy(xpath = "//h2[contains(text(),'Add a Title')]")
	public WebElement own_title_page;
	
	@FindBy(xpath = "(//span[contains(text(),' *')])[1]")
	public WebElement own_title_TitleName_Mandatory;
	
	@FindBy(xpath = "(//input[@matinput])[1]")
	public WebElement own_title_TitleName;
	
	@FindBy(xpath = "//mat-label[contains(text(),'Author Name')]")
	public WebElement own_title_AuthorName;
	
	@FindBy(xpath = "(//input[@matinput])[2]")
	public WebElement own_title_AuthorName_input;
	
	@FindBy(xpath = "//mat-icon[@svgicon='kz-filter-down-arrow']")
	public WebElement own_title_dropdown;
	
	@FindBy(xpath = "//span[contains(text(),'eAudio/Audiobook')]")
	public WebElement own_title_dropdown_EAudioAudiobook;
	
	@FindBy(xpath = "//span[contains(text(),'Print Book')]")
	public WebElement own_title_dropdown_EAudioprintbook;
	
	@FindBy(xpath = "//span[contains(text(),'Video')]")
	public WebElement own_title_dropdown_video;
	
	@FindBy(xpath = "(//*[contains(text(),'Add')])[2]")
	public WebElement Add_CTA;
	
	@FindBy(xpath = "(//axis360-title-card[@class='ng-star-inserted'])[2]")
	public WebElement Default_coverimg;
	
	@FindBy(id = "loc_txtReadingList")
	public WebElement TitleDetails_ReadingList;
	
	@FindBy(xpath = "//div[@class='hidden-title disabled']")
	public WebElement Titledetails_EditReadigList;
	
	@FindBy(xpath = "//p[contains(text(),'do this')]")
	public WebElement Milestone_LetsDothis_badge;
	
	@FindBy(xpath = "//*[contains(text(),'Program completed')]")
	public WebElement Milestone_programcompleted_badge;
	
	@FindBy(xpath = "(//div[@class='carousel-arrow carousel-arrow-next'])[2]")
	public WebElement Milestone_letsdothis_badge_LeftArrow;
	
	@FindBy(id = "goals-accordion")
	public WebElement myshelf_Goalsandinsight_widget;
	
	@FindBy(xpath = "//p[contains(text(),'BadgeProgram')]")
	public WebElement Milestone_programName_badge;
	
	@FindBy(xpath = "(//*[@class='search-view-container'])[1]")
	public WebElement SearchResults_addatitle;
	
	@FindBy(xpath = "(//*[@class='mat-card-image card-image'])[1]")
	public WebElement Addedtitle_titleDetails;
	
	@FindBy(xpath = "//button[contains(text(),'Add')]")
	public WebElement Externaltitle_AddCTA;
	
	@FindBy(xpath = "(//span[text()='Mark as Done'])[1]")
	public WebElement MarkAsDone_CTA;
	
	@FindBy(xpath = "(//span[text()='Mark Not Done'])[1]")
	public WebElement MarkAsNotDone_CTA;
	
	@FindBy(id = "loc_SearchYourLibrary")
	public WebElement addtitle_OkCTA;
	
	
	
	
	
	public void click_joinedUpcomingprogram() {
		visibilityWait(Joined_upcomingProg);
		jsClick(Joined_upcomingProg);
		visibilityWait(milestone.Nav_TitleDetails);
	}
	
	public void click_AddaTitle() {
		visibilityWait(select_AddaTitle);
		javascriptScroll(select_AddaTitle);
		jsClick(select_AddaTitle);
		visibilityWait(popup_SearchyourLibrary);
	}
	
	public void select_SearchyourLibrary() {
		jsClick(popup_SearchyourLibrary);
		waitFor(2000);
	}
	
	public void click_searchCTA() {
		javascriptScroll(AdvancedSearch_Search);
		jsClick(AdvancedSearch_Search);
		waitFor(2000);
	}
	
	public void SearchResult_AddaTitles() {
		javascriptScroll(SearchResults_AddaTitle);
		jsClick(SearchResults_AddaTitle);
		waitFor(2000);

	}
	
	public void Click_CloseIcon_NavprogramDetails() {
		boolean b=true;
		visibilityWait(AdvanceSearch_CloseIcon);
		if (AdvanceSearch_CloseIcon.isDisplayed()) {
			jsClick(AdvanceSearch_CloseIcon);
			Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
		}else {
			b=false;
		}		
	}
	
	public void click_AddyourownTitles() {
		visibilityWait(popup_AddyourownTitle);
		jsClick(popup_AddyourownTitle);
	}
	
	public void click_ActiveProgram() {
		visibilityWait(Activeprog_joined);
		jsClick(Activeprog_joined);
		waitFor(2000);

	}
	
	public void view_progressforEachTitles() {
		boolean b=true;
			if (Title_progress.isDisplayed()) {
			b=true;	
			}else {
				b=false;
			}
		
	}
	
	public void view_ProgressforCheckoutCTA(String ctaStatus) {
		switch ("ctaStatus") {
		case "Checkout":
			CheckoutCTA_progm.isDisplayed();
			//Title_progress.get(0).isDisplayed();
			System.out.println("user is able to view the 0% progress");
			break;
		case "Place Hold":
			placeHoldCTA_progm.isDisplayed();
		case "Read now":
			ReadnowCTA_progm.isDisplayed();
		default:
			break;
		}
	if (CheckoutCTA_progm.isDisplayed()) {
		Title_progress.isDisplayed();
		System.out.println("user is able to view the 0% progress");
		
	}else {
		System.out.println("Checkout title is not available in the particular program");
	}

	}
	
	public void click_completedprog() {
		visibilityWait(completed_MilestoneProg);
		jsClick(completed_MilestoneProg);
		visibilityWait(milestone.Nav_TitleDetails);

	}
	
	public void Verify_authorNameOptional() {
		boolean b=true;
		String text = own_title_AuthorName.getText();
		if (text.equalsIgnoreCase("Author Name")) {
			visibilityWait(own_title_AuthorName_input);
			SendKeysOnWebElement(own_title_AuthorName_input, "APJ");
			waitFor(2000);
			Logger.log("This is not mandatory field");
			b=true;	
		}else {
			b=false;
			Logger.log("This is mandatory field");
		}
		
	}
	
	public void Select_owntitle_Dropdwn() {
		javascriptScroll(own_title_dropdown);
		jsClick(own_title_dropdown);
		visibilityWait(own_title_dropdown_EAudioAudiobook);
		Assert.assertTrue(own_title_dropdown_EAudioprintbook.isDisplayed());
		//Assert.assertTrue(own_title_dropdown_video.isDisplayed());
		jsClick(own_title_dropdown_EAudioAudiobook);
		waitFor(2000);
		
	}
	
	public void Select_AddCTA() {
		javascriptScroll(Add_CTA);
		jsClick(Add_CTA);
		try {
			jsClick(addtitle_OkCTA);
		} catch (Exception e) {
			// TODO: handle exception
		}
		visibilityWait(milestone.Nav_TitleDetails);

	}
	
	public void external_AddCTA() {
		javascriptScroll(Externaltitle_AddCTA);
		jsClick(Externaltitle_AddCTA);
		try {
			jsClick(addtitle_OkCTA);
		} catch (Exception e) {
			// TODO: handle exception
		}
		visibilityWait(milestone.Nav_TitleDetails);

	}
	
	public void verify_programCompletedBadge() {
//		int i=4;
//		while (i<=4) {
//			if (Milestone_letsdothis_badge_LeftArrow.isDisplayed()) {
//				jsClick(Milestone_letsdothis_badge_LeftArrow);
//			}
//		}
		javascriptScroll(Milestone_programcompleted_badge);
		Assert.assertTrue(isElementPresent(Milestone_programcompleted_badge));

	}
}
