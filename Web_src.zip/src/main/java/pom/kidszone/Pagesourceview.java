package pom.kidszone;

import java.io.File;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.poi.hpsf.Date;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.jsoup.Jsoup;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class Pagesourceview extends CommonAction {

	public Pagesourceview(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	ExcelReader reader = new ExcelReader();

	@FindBy(id = "availabilityTypeLabel")
	private WebElement lbl_availability;

//	@FindBy(id = "loginBtn")
//	private WebElement btn_login_Button;
	
	@FindAll({ @FindBy(id = "loginBtnMobile"), @FindBy(id = "loginBtn") })
	private WebElement btn_login_Button;

	@FindBy(id = "dialogHeading")
	private WebElement txt_loginpopup_Heading;

	@FindBy(xpath = "//*[@id='loginForm']/div/div[1]/label")
	private WebElement label_libraryID;

	@FindBy(xpath = "//*[@id='loginForm']/div/div[2]/label")
	private WebElement label_pin;

	@FindBy(id = "LogOnModel_UserName")
	private WebElement txt_userName_Textfield;

	@FindBy(id = "LogOnModel_Password")
	private WebElement txt_password_Textfield;

	@FindBy(xpath = "//input[@id='LogOnModel_UserName']")
	private WebElement loginwithpin_textfield_librarycardid;

	@FindBy(xpath = "//input[@id='LogOnModel_Password']")
	private WebElement loginwithpin_textfield_pin;
	
	@FindBy(xpath = "//button[text()='login']")
	private WebElement loginwithpin_btn_login;

	@FindBy(xpath = "//h2[contains(text(),'Register')]")
	private WebElement register_txt_Register;

	@FindBy(id = "showHidePassword")
	private WebElement lnk_showHidden_Password;

	@FindBy(id = "lnkShowRegPwd")
	private WebElement lnk_contactAdmin_forPassword;

	@FindBy(xpath = "//*[@id=\"loginForm\"]/div/div[3]/button")
	private WebElement btn_signin;

	@FindBy(xpath = "//*[contains(text(), 'login')]")
	private WebElement btn_signinwithid;

	@FindBy(xpath = "//*[@id=\'loginForm\']/div/div[2]/button")
	private WebElement btn_signinonlyid;

	@FindBy(id = "forgotPinLink")
	private WebElement link_forgotPin;

	@FindBy(id = "dialogHeadingForgotPin")
	private WebElement txt_forgotPin_Heading;

	@FindBy(id = "IsDialog")
	private WebElement txt_forgotPin_Subheading;

	@FindBy(id = "Username")
	private WebElement txt_forgotPin_Username_Textfield;

	@FindBy(xpath = " //h2[contains(text(), 'Log Into Your Library')]")
	private WebElement txt_login;

	@FindBy(xpath = "//*[@id='forgotPinForm']/div[4]/button")
	private WebElement btn_forgotPin_Submit;

	@FindBy(xpath = "//*[@id=\"loginBackBtn\"]/span/svg")
	private WebElement btn_forgotPin_Back;

	@FindBy(xpath = "//*[@id=\'forgotPinModal\']/div/div/div/div[2]/button/span/svg")
	private WebElement btn_forgotPin_Close;

	@FindBy(xpath = "//*[@id=\'loginModal\']/div/div/div/div[1]/button/span")
	private WebElement btn_close_login;

	@FindBy(id = "btnLogout")
	private WebElement btn_logout;

	@FindBy(xpath = "//label[text()='Library Card ID']")
	private WebElement loginwithid_txt_librarycardid;

	@FindBy(xpath = "//*[contains(text(),' Pin Recovery')]")
	private WebElement txt_pinrecovery;

	@FindBy(id = "SecurityQuestion")
	private WebElement txt_SecurityQuestion;

	@FindBy(id = "SecurityAnswer")
	private WebElement txt_SecurityAnswern;

	@FindBy(xpath = "(//span[contains(text(), 'Welcome, Photon2')][1])[1]")
	private WebElement txt_welcomeUsername;

	@FindBy(xpath = "//*[@id=\"SendPasswordForm\"]/div[3]/button")
	private WebElement security_submit;

	@FindBy(id = "RegisterModel_UserName")
	private WebElement reg_Username;

	@FindBy(id = "RegisterModel_Password")
	private WebElement reg_Password;

	@FindBy(id = "RegisterModel_SecurityQuestion_button")
	private WebElement reg_Securityquestion;

	@FindBy(id = "RegisterModel_SecurityAnswer")
	private WebElement reg_Securityanswer;

	@FindBy(id = "RegisterModel_DisplayName")
	private WebElement reg_Displayname;

	@FindBy(id = "RegisterModel_Email")
	private WebElement reg_Email;

	@FindBy(id = "adult")
	private WebElement reg_Adult;

	@FindBy(id = "teen")
	private WebElement Reg_Teen;

	@FindBy(id = "kid")
	private WebElement Reg_Kid;

	@FindBy(xpath = "//button[contains(text(),'Register')]")
	private WebElement reg_Registerbtn;

	@FindBy(xpath = "//button[contains(text(),'Done')]")
	private WebElement Addprofile_btn_done;

	@FindBy(xpath = "//a[text()='Add a teen ']")
	private WebElement Addprofile_label_addTeenprofile;

	@FindBy(xpath = "//a[contains(text(),'Add a kid')]")
	private WebElement Addprofile_label_addkidprofile;

	@FindBy(xpath = "//button[text()='LOGIN']")
	private WebElement SalesDemo_Btn_login;
	
	public WebElement getSalesDemo_Btn_login() {
		return SalesDemo_Btn_login;
	}

	public WebElement getTxt_SecurityQuestion() {
		return txt_SecurityQuestion;
	}

	public WebElement getTxt_SecurityAnswern() {
		return txt_SecurityAnswern;
	}

	public WebElement getRegister_txt_Register() {
		return register_txt_Register;
	}


	/****************************** Action methods************************************/

	public void imageError() {
		String error = "Image not loaded";
		boolean Error = DriverManager.getDriver().getPageSource().contains(error);

		if (Error == true)

		{
			Assert.assertTrue(false);

			System.out.println("Error Result : Image error found****");
		}

		else {
			Assert.assertTrue(true);

			System.out.println("Result : Images are loading without any error!!!!");
		}

	}

	public void pagenotfoundError() {
		String error = "Page not found";
		boolean Error = DriverManager.getDriver().getPageSource().contains(error);

		if (Error == true) {
			Assert.assertTrue(false);
			System.out.println("Error Result : Page not found****");
		} else {
			Assert.assertTrue(true);

			System.out.println("Result : Page is loading without any error!!!!");

		}
	}

	public void filenotfoundError() {
		String error = "File not found";
		boolean Error = DriverManager.getDriver().getPageSource().contains(error);

		if (Error == true) {
			Assert.assertTrue(false);
			System.out.println("Error Result : File not found****");
		} else {
			Assert.assertTrue(true);
			System.out.println("Result : Files are loading without any error!!!!");

		}
	}

	public void clickLogins() {
		waitFor(3000);
        jsClick(btn_login_Button); 
		//btn_login_Button.click();
		waitFor(5000);
	}

	public void click_SalesDemo_login() {
         ClickOnWebElement(SalesDemo_Btn_login);
	}
	
	public void login_libraryid_popups() throws InvalidFormatException, IOException {
		WaitForWebElement(txt_loginpopup_Heading);
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(txt_userName_Textfield, testData.get(0).get("Username"));
		ClickOnWebElement(btn_signin);
//		Assert.assertEquals(btn_logout.getText(), "LOGOUT");
		waitFor(5000);
	}

	public void loginwith_password_popups() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(txt_userName_Textfield, testData.get(0).get("Username"));
		SendKeysOnWebElement(txt_password_Textfield, testData.get(0).get("Password"));
		ClickOnWebElement(btn_signin);
//		Assert.assertEquals(btn_logout.getText(), "LOGOUT");
		waitFor(5000);
	}

	public void regloginwith_password() throws InvalidFormatException, IOException {
		WaitForWebElement(txt_loginpopup_Heading);
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(txt_userName_Textfield, "BTphoton" + RandomStringGenerate());
		SendKeysOnWebElement(txt_password_Textfield, testData.get(0).get("Password"));
		ClickOnWebElement(btn_signin);
		javascriptScroll(reg_Registerbtn);
		waitFor(5000);
	}

	public void regloginwithid() throws InvalidFormatException, IOException {

		WaitForWebElement(txt_loginpopup_Heading);
		Assert.assertEquals(txt_loginpopup_Heading.isDisplayed(), true);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Register");
		SendKeysOnWebElement(txt_userName_Textfield, "BTphoton" + RandomStringGenerate());
		ClickOnWebElement(btn_signinwithid);
		javascriptScroll(reg_Registerbtn);
		waitFor(5000);

	}

	public void captureScreen() throws IOException {

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();
		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG",
				new File("./src/test/resources/Data/Screenshot/" + dtf.format(now) + ".png"));

	}

	public void logout() {
		ClickOnWebElement(btn_logout);
		waitFor(6000);

	}

	public void HomecaptureScreen() throws IOException, InterruptedException {

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Homescreen.png"));

	}

	public void LogincaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Login.png"));

	}

	public void DashboardcaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Dashboard.png"));

	}

	public void RegcaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Register.png"));

	}

	public void RegvaluecaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Regval.png"));

	}

	public void ProfilecaptureScreen() throws IOException {
		waitFor(3000);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Profile.png"));

	}

	public void ProfselectcaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Profilesel.png"));

	}

	public void AddteencaptureScreen() throws IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Addteen.png"));

	}

	public void AvatarcaptureScreen() throws IOException {
		waitFor(6000);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Avatar.png"));

	}

	public void ProeditcaptureScreen() throws IOException {
		waitFor(3000);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Editicon.png"));

	}

	public void EditcaptureScreen() throws IOException {
		waitFor(5000);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Editprofile.png"));

	}

	public void DeletecaptureScreen() throws IOException {
		waitFor(4000);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/DeleteProfile.png"));

	}

	public void ProfilemanagecaptureScreen() throws IOException {
		LocalDateTime now = LocalDateTime.now();

		Screenshot screenshot = new AShot().takeScreenshot(DriverManager.getDriver());
		ImageIO.write(screenshot.getImage(), "PNG", new File("./src/test/resources/Data/Screenshot/Profilemanage.png"));

	}

}