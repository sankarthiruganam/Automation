package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class ProfileS4 extends CommonAction {

	Profile old = new Profile(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	public ProfileS4(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@svgicon='kz-profile-user']")
	public List<WebElement> profileIcon;

	@FindBy(xpath = "//p[@class='kz-sub-text mb-1 ng-star-inserted']")
	public WebElement emailid_resetpin;

	@FindBy(xpath = "//h1[contains(text(),'Create a Profile PIN')]")
	public WebElement createNewPin_popup;

	@FindBy(xpath = "//div[contains(text(),'Are you sure you want to disable your Profile PIN?')]")
	public WebElement disablepopup_content;

	@FindBy(xpath = "//h1[contains(text(),'Disable Profile PIN')]")
	public WebElement disablepopup_input_disablepin;

	@FindBy(xpath = "//p[contains(text(),'PIN not valid. Please try again.')]")
	public WebElement wrongpin_content;

	@FindBy(xpath = "//div[contains(text(),'Please add an email to enable your Profile PIN')]")
	public WebElement withoutEmail_enablepin_verbiage;

	@FindBy(id = "loc_dpProfileType")
	public WebElement profileAgeRange;

	@FindBy(xpath = "//*[@class='profile-type-name'][contains(text(),' General ')]")
	public WebElement primaryBottom;

	@FindBy(xpath = "//*[@class='profile-type-name profile-type-center'][contains(text(),'Teen')]")
	public WebElement teenBottom;

	@FindBy(xpath = "//*[@class='profile-type-name profile-type-center'][contains(text(),'Kid')]")
	public WebElement kidBottom;

	@FindBy(id = "loc_linkEdit")
	public WebElement manageProfileIcon;

	@FindBy(id = "loc_linkLearnAbout")
	public WebElement learnMoreAbout;

	@FindBy(id = "loc_textalertcontent")
	public WebElement aboutProfilePopUp;

	@FindBy(id = "loc_profileImg")
	public WebElement avatarHearder;

	@FindBy(xpath = "//*[@class='profile-user-list']")
	public WebElement profileListDropDown;

	@FindBy(xpath = "(//*[@class='kz-user-adult profile-image'])[1]")
	public WebElement primaryProfileDropDown;

	@FindBy(xpath = "(//*[@class='kz-user-teen profile-image'])[1]")
	public WebElement teenProfileDropDown;

	@FindBy(xpath = "(//*[@class='kz-user-kid profile-image'])[1]")
	public WebElement kidProfileDropDown;

	@FindBy(xpath = "//*[@svgicon='kz-logout']")
	public WebElement signOutDropDown;

	@FindBy(xpath = "//*[@svgicon='kz-settings']")
	public WebElement settingsDropDown;

	@FindBy(xpath = "//*[@svgicon='kz-manage-edit']")
	public WebElement manageProfileDropDown;

	@FindBy(xpath = "//*[@class='mat-tab-link-container']")
	public WebElement myShelfPage;

	@FindBy(id = "add-profile-button")
	public WebElement addProfileCTA;

	@FindBy(xpath = "(//*[@class='kz-alert-dialog'])[1]")
	public WebElement signOutPopUp;

	@FindBy(id = "loc_confirmbtnOK")
	public WebElement signOutOk;

	@FindBy(id = "loc_linkTeenEditProfile")
	public WebElement teenProfile;

	@FindBy(id = "loc_linkKidEditProfile")
	public WebElement kidProfile;

	@FindBy(xpath = "//*[@class='profile-details']")
	public WebElement allProfiles;

	@FindBy(xpath = "//*[@class='profile-details']")
	public List<WebElement> createdProfiles;

	@FindBy(xpath = "//button[@class='btn-nobg-bluecolor d-flex back-btn']")
	public WebElement backCta_manageProfScreen;

	@FindBy(xpath = "//*[contains(text(),'Allow PINs for other Profiles')]")
	public WebElement universal_Toggle;

	@FindBy(xpath = "(//div[@class='mat-checkbox-inner-container'])[3]/input[@aria-checked='false']")
	public WebElement checkbox_universal_Toggle;

	@FindBy(xpath = "//button[contains(text(),'Forgot PIN')]")
	public WebElement forgetpin_CTA;

	@FindBy(xpath = "//p[contains(text(),'Please enter your Profile PIN')]")
	public WebElement disable_pinpopup;

	@FindBy(xpath = "//*[@svgicon='kz-profile-user']")
	public List<WebElement> profilesIconsListed;

	@FindBy(xpath = "//span[contains(text(),'Add same email as adult')]")
	public WebElement email_checkbox;
	
	@FindBy(xpath = "(//*[@class='edit-det-sub-head adult-heading ng-star-inserted'])[1]")
	public WebElement AdultDetails_LibraryId;
	
	@FindBy(xpath = "(//*[@class='edit-det-sub-head teen-heading ng-star-inserted'])[1]")
	public WebElement TeenDetails_LibraryId;
	
	@FindBy(xpath = "//*[@class='edit-det-sub-head kid-heading ng-star-inserted']")
	public WebElement KidDetails_LibraryId;
	
	@FindBy(xpath = "(//*[@class='edit-details-value'])[1]")
	public WebElement Details_LibraryIdValue;
	
	@FindBy(xpath = "//*[contains(text(),' Checkout Limit')]")
	public WebElement Details_checkoutLimit;
	
	@FindBy(xpath = "//*[contains(text(),'eBook')]")
	public WebElement Details_ebook;
	
	@FindBy(xpath = "//*[contains(text(),'eBook/Video/vBook')]")
	public WebElement kidorTeenDetails_ebookvideovbook;
	
	@FindBy(xpath = "//*[contains(text(),'eAudio')]")
	public WebElement Details_Eaudio;
	
	@FindBy(xpath = "//*[contains(text(),'Hold Limit')]")
	public WebElement Details_HoldLimit;
	
	@FindBy(xpath = "//*[contains(text(),'Purchase Requests Limit')]")
	public WebElement Details_purchaseLimit;
	
	@FindBy(xpath = "(//*[@class='profile-adult profile-type'])[1]")
	public WebElement AdultProfileAvatar_RemovedTriangle;
	
	@FindBy(xpath = "(//*[@class='profile-teen profile-type'])[1]")
	public WebElement TeenProfileAvatar_RemovedTriangle;
	
	@FindBy(xpath = "(//*[@class='profile-kid profile-type'])[1]")
	public WebElement KidProfileAvatar_RemovedTriangle;


	public void click_Teenprofile() {
		
		WaitForWebElement(teenProfile);
		jsClick(teenProfile);
		
		login.preferenceScreen_popup();
	}

	public void click_Kidprofile() {
		visibilityWait(kidProfile);
		jsClick(kidProfile);
		waitFor(3000);
		login.preferenceScreen_popup();
	}

	public void clickLearMore() {
		jsClick(learnMoreAbout);
		visibilityWait(aboutProfilePopUp);
	}

	public void clickProfileAvatar() {
		jsClick(avatarHearder);
		visibilityWait(profileListDropDown);
	}

	public void clickPrimaryDropDownwithPin() {
		javascriptScroll(primaryProfileDropDown);
		jsClick(primaryProfileDropDown);
		waitFor(5000);
	}

	public void clickPrimaryDropDown() {
		javascriptScroll(primaryProfileDropDown);
		jsClick(primaryProfileDropDown);
		waitFor(5000);
		login.preferenceScreen_popup();
	}

	public void clickTeenDropDownwithPin() {
		javascriptScroll(teenProfileDropDown);
		jsClick(teenProfileDropDown);
		waitFor(5000);
	}

	public void clickTeenDropDown() {
		javascriptScroll(teenProfileDropDown);
		jsClick(teenProfileDropDown);
		waitFor(5000);
		login.preferenceScreen_popup();
	}

	public void clickKidDropDownwithPin() {
		javascriptScroll(kidProfileDropDown);
		jsClick(kidProfileDropDown);
		waitFor(5000);
		login.preferenceScreen_popup();
	}

	public void clickKidDropDown() {
		javascriptScroll(kidProfileDropDown);
		jsClick(kidProfileDropDown);
		waitFor(5000);
		login.preferenceScreen_popup();
	}

	public void clickManageProfDropDown() {
		javascriptScroll(manageProfileDropDown);
		jsClick(manageProfileDropDown);
		WaitForWebElement(old.profileListPage);
	}

	public void clickProfileDropDown() {
		javascriptScroll(settingsDropDown);
		jsClick(settingsDropDown);
		WaitForWebElement(old.profileEditSection);
	}

	public void clicksignOutDropDown() {
		javascriptScroll(signOutDropDown);
		jsClick(signOutDropDown);
		WaitForWebElement(signOutPopUp);
		javascriptScroll(signOutOk);
		jsClick(signOutOk);
		WaitForWebElement(login.getBtn_login_Button());
	}

	public void clickAddProfile() {
		javascriptScroll(addProfileCTA);
		jsClick(addProfileCTA);
		WaitForWebElement(old.addProfilePage);
	}

	public void clickAddKid() {
		javascriptScroll(old.Createprofile_label_AddaKid);
		jsClick(old.Createprofile_label_AddaKid);
	}

	public void createKid(String name) {
		SendKeysOnWebElement(old.Createprofile_input_displayName, name+RandomStringGenerate());
		javascriptScroll(old.Createprofile_donebtn);
		jsClick(old.Createprofile_donebtn);
		WaitForWebElement(old.getSucessMsg());
		WaitForWebElement(old.profileListPage);
		Logger.log("User created the profile successfully");
		for (int i = 0; i < createdProfiles.size(); i++) {
			if (createdProfiles.get(i).getText().contains(name)) {
				break;
			} else {
				continue;
			}
		}
	}

	public void deleteProfileIfMaximum(String name) {
		for (int i = 0; i < createdProfiles.size(); i++) {
			if (createdProfiles.get(i).getText().contains(name)) {
				waitFor(2000);
				jsClick(manageProfileIcon);
				waitFor(2000);
				jsClick(old.profilesListed.get(i));
				old.clickDeleteButton();
				old.deleteProfile();
			} else {
				continue;
			}
			Logger.log("User doesn't have new created profile");
		}
	}
	
	public void deleteProfile_max() {
	if (isElementPresent(addProfileCTA)) {
		Logger.log("user is able to create the new profile");
	}else {
		visibilityWait(manageProfileIcon);
		jsClick(manageProfileIcon);
		waitFor(2000);
		jsClick(old.profilesListed.get(1));
		old.clickDeleteButton();
		jsClick(old.deleteConfirmOk);
		visibilityWait(manageProfileIcon);
//		jsClick(manageProfileIcon);
//		waitFor(2000);
//		jsClick(old.profilesListed.get(2));
//		old.clickDeleteButton();
//		jsClick(old.deleteConfirmOk);
	}

	}

	public void createTeenIfUnavailable(String name) {
//		for (int i = 0; i < createdProfiles.size(); i++) {
		System.out.println(allProfiles.getText() + "ZZZZ");
		if (isElementPresent(teenProfile)) {
			waitFor(2000);
			Logger.log("Teen Profile Exist");
		} else {
			old.create_TeenProfile(name);
			WaitForWebElement(old.profileListPage);
			Logger.log("User created new profile");
		}
	}

	public void createKidIfUnavailable(String name) {
//		for (int i = 0; i < createdProfiles.size(); i++) {
		System.out.println(allProfiles.getText());
		if (isElementPresent(kidProfile)) {
			waitFor(2000);
			Logger.log("Kid Profile Exist");
		} else {
			old.create_KidProfile(name);
			WaitForWebElement(old.profileListPage);
			Logger.log("User created new profile");
		}
	}

	public void click_AddTeen() {
		javascriptScroll(old.Createprofile_label_AddaTeen);
		jsClick(old.Createprofile_label_AddaTeen);

	}
	
	
	public void verify_profileDetails(String profiletype) {		
		switch (profiletype) {
		case "Adult":
			javascriptScroll(AdultDetails_LibraryId);
			Assert.assertTrue(Details_LibraryIdValue.isDisplayed());
			Assert.assertTrue(Details_checkoutLimit.isDisplayed());
			Assert.assertTrue(Details_ebook.isDisplayed());
			Assert.assertTrue(Details_Eaudio.isDisplayed());
			Assert.assertTrue(Details_HoldLimit.isDisplayed());
			Assert.assertTrue(Details_purchaseLimit.isDisplayed());
			break;
		case "Teen":
			javascriptScroll(TeenDetails_LibraryId);
			Assert.assertTrue(Details_LibraryIdValue.isDisplayed());
			Assert.assertTrue(Details_checkoutLimit.isDisplayed());
			Assert.assertTrue(kidorTeenDetails_ebookvideovbook.isDisplayed());
			Assert.assertTrue(Details_Eaudio.isDisplayed());
			Assert.assertTrue(Details_HoldLimit.isDisplayed());
			Assert.assertTrue(Details_purchaseLimit.isDisplayed());
			break;
		case "Kid":	
			javascriptScroll(KidDetails_LibraryId);
			Assert.assertTrue(Details_LibraryIdValue.isDisplayed());
			Assert.assertTrue(Details_checkoutLimit.isDisplayed());
			Assert.assertTrue(kidorTeenDetails_ebookvideovbook.isDisplayed());
			Assert.assertTrue(Details_Eaudio.isDisplayed());
			Assert.assertTrue(Details_HoldLimit.isDisplayed());
			Assert.assertTrue(Details_purchaseLimit.isDisplayed());
		}
	}
	
	public void validate_TriangleType(String profileType) {
		switch (profileType) {
		case "adult":
			Assert.assertEquals(isElementPresent(AdultProfileAvatar_RemovedTriangle), false);
			break;
		case "teen":
			Assert.assertEquals(isElementPresent(TeenProfileAvatar_RemovedTriangle), false);
			break;
		case "kid":
			Assert.assertEquals(isElementPresent(KidProfileAvatar_RemovedTriangle), false);
			break;
		}

	}
	

}