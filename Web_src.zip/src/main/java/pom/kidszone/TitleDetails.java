package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class TitleDetails extends CommonAction {

	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	MyLibrary_Guest library = new MyLibrary_Guest(DriverManager.getDriver());

	public TitleDetails(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//*[@class='featured-carousel']//*[@class='kz-card-image ng-star-inserted'])[2]")
	private WebElement eBookTitle;

	@FindBy(xpath = "//*[@class='titledetails-bookwrapper']")
	private WebElement holdTitleList;

	@FindBy(xpath = "(//*[@class='kz-custom-container-secondary']/following::img)[1]")
	private WebElement available_AudiobookTitle;

	@FindBy(xpath = "((//*[@class='kz-custom-container-secondary'])[1]//following::*[@class='mat-card-image card-image'])[1]")
	private WebElement audioBookTitle;

	@FindBy(xpath = "(//*[contains(text(),'Always Available')]//..)[1]//preceding-sibling::*[@class='kz-card-image ng-star-inserted']")
	private WebElement audioTitle;

	@FindBy(xpath = "//div[@class='mat-tab-list']")
	private WebElement titleDetailScreen;

	@FindBy(xpath = "//*[@class='mat-card-image card-image']")
	private List<WebElement> libraryTitleImage;

	@FindBy(xpath = "//*[contains(text(),'More Like This')]")
	private WebElement moreLikeThisCTA;

	@FindBy(xpath = "//*[@class='kz-title-carousel ng-star-inserted']")
	private WebElement moreLikeThisTitles;

	@FindBy(xpath = "//*[@class='mat-tab-body-wrapper']")
	private WebElement moreLikeThisSection;

	@FindBy(xpath = "//*[contains(text(),'No Recommended books available')]")
	private WebElement noTitleRecommended;

	@FindBy(xpath = "(//*[contains(text(),'eAudio')])[2]")
	private WebElement audioBook;

	@FindBy(xpath = "(//*[contains(text(),'eBook')])[1]")
	private WebElement eBookDetails;

	@FindBy(xpath = "//*[contains(text(),'DOWNLOAD SIZE')]/..")
	private WebElement downLoadSize;

	@FindBy(xpath = "(//*[contains(text(),'eAudio')])[2]")
	private WebElement eAudioTitlePage;

	@FindBy(xpath = "(//p[@class='secondary-para text-to-speech ng-star-inserted'])[2]")
	private WebElement txtToSpeech;

	@FindBy(xpath = "(//*[contains(text(),'eBook')])[2]")
	private WebElement eBookTitlePage;

	@FindBy(xpath = "")
	private WebElement eReadAlong;

	@FindBy(xpath = "//*[contains(text(),'LENGTH')]//..")
	private WebElement duration;

	@FindBy(xpath = "(//*[contains(text(),'EDITION')]//..)[1]")
	private WebElement edition;

	@FindBy(xpath = "(//*[@class='primary-link'])[1]")
	private WebElement readBy;

	@FindBy(xpath = "(//*[@class='primary-link'])[1]")
	private WebElement readByAuthor;

	@FindBy(xpath = "(//*[@class='primary-link'])[1]")
	private WebElement narratedBy;

	@FindBy(xpath = "(//*[@class='primary-link'])[1]")
	private WebElement narratedByAuthor;

	@FindBy(xpath = "(//*[@class='search-result-info'])")
	private WebElement searchResultsPage;

	@FindBy(xpath = "//*[@class='mat-card mat-focus-indicator kz-card ng-star-inserted']")
	private List<WebElement> librartTitles;

	@FindBy(xpath = "(//*[contains(text(),'Place Hold')])[1]")
	private WebElement placeHoldCta;

	@FindBy(xpath = "(//*[@class='book-title-details'])[2]//*[contains(text(),'Place Hold')]")
	private WebElement placeHoldCtaTitleDetails;

	@FindBy(xpath = "(//span[contains(text(),'Remove Hold')])[1]")
	private WebElement removeHoldCta;

	@FindBy(xpath = "(//*[contains(text(),'Hold Position')])[1]")
	private WebElement holdPosition;

	@FindBy(xpath = "//*[@class='cdk-overlay-pane mat-tooltip-panel']")
	private WebElement toolTipMsg;

	@FindBy(xpath = "//*[@svgicon='kz-no-info-icon']")
	private WebElement toolTipIcon;

	@FindBy(id = "loc_textalertcontent")
	private WebElement toolTipInfo;

	@FindBy(xpath = "(//*[contains(text(),'Details')])[1]")
	private WebElement detailsTab;

	@FindBy(xpath = "(//*[contains(text(),'HOLD POSITION')])")
	private WebElement patronHoldPosition;

	@FindBy(xpath = "//*[@svgicon='close']")
	private WebElement closeToolTipInfo;

	@FindBy(xpath = "//*[contains(text(),'PATRONS ON HOLD')]")
	private WebElement patronOnHold;

	@FindBy(xpath = "(//*[contains(text(),'PATRONS ON HOLD')]//..)[2]")
	private WebElement patronHoldCount;

	@FindBy(xpath = "//*[@class='author-name hidden-xs ng-star-inserted']")
	private WebElement copiesAvailable;

	@FindBy(xpath = "(//*[contains(text(),'SUBJECT')]//..)[1]")
	private WebElement subjectColumn;

	@FindBy(xpath = "(//div[@class='custom-colunm book-title-detail primary-text subject-wrapper'])[1]")
	private WebElement subjectLevels;

	@FindBy(xpath = "(//div[@class='custom-colunm book-title-detail primary-text subject-wrapper'])[1]//*[1]")
	private WebElement subjectLevels1;

	@FindBy(xpath = "//*[@class='title-details-info']")
	private WebElement titleDetailsPage;

	@FindBy(xpath = "//p[@class='primary-para ng-star-inserted']")
	public WebElement txt_subtitle;

	@FindBy(xpath = "(//*[@class='book-of-month-img'])[1]")
	private WebElement img_titleDetails;

	@FindBy(id = "Vector")
	private WebElement img_ebookformaticon;

	@FindBy(xpath = "(//mat-icon[@class='mat-icon notranslate book-poster-icon mat-icon-no-color'])[1]")
	private WebElement img_audioformaticon;

	@FindBy(xpath = "//div[@class='kz-progress-bar']")
	private WebElement titleDetails_progressbar;

	@FindBy(xpath = "(//span[text()='Checkout'])[2]")
	public WebElement titleDetails_Checkout;

	@FindBy(xpath = "//span[text()='Checkout']")
	private List<WebElement> titleDetail_Checkout;

	@FindBy(xpath = "//*[contains(text(),'Wishlist')]")
	private WebElement titleDetails_wishlist;

	@FindBy(xpath = "//*[@svgicon='kz-share']")
	private WebElement placeHold_share;

	@FindBy(xpath = "//*[@svgicon='kz-share']")
	private WebElement titleDetails_share;

	@FindBy(xpath = "(//span[text()='Place Hold'])[1]")
	public WebElement titleDetails_placeHold;

	@FindBy(xpath = "(//button[@aria-label='more option'])[2]")
	public WebElement titleDetails_dropdown_moreoption;

	@FindBy(xpath = "//button[contains(text(),' Add to Wishlist ')]")
	public WebElement titleDetails_dropdown_addtoWishlist;

	@FindBy(xpath = "//button[contains(text(),' Remove from Wishlist ')]")
	private WebElement titleDetails_dropdown_RemoveWishlist;

	@FindBy(xpath = "//button[contains(text(),' Share ')]")
	private WebElement titleDetails_dropdown_share;

	@FindBy(xpath = "//*[@class='kz-title-carousel ng-star-inserted']/following::img[@class='mat-card-image card-image']")
	private List<WebElement> titleList;

	@FindBy(xpath = "//*[@class='card-link ng-star-inserted']")
	private List<WebElement> titleCard;

	@FindBy(xpath = "//small[text()='Wishlist']")
	public WebElement add_wishlist;

	@FindBy(xpath = "//button[contains(text(),' Suspend Hold ')]")
	private WebElement drop_suspendHold;

	@FindBy(xpath = "//button[contains(text(),' Remove Hold ')]")
	private WebElement drop_removedHold;

	@FindBy(xpath = "//div[@class='kz-card-image ng-star-inserted']/following::h3[text()='El espíritu del último verano']")
	private List<WebElement> synopsisTitle_manual;

	@FindBy(xpath = "//h2[contains(text(),' Synopsis')]")
	public WebElement txt_synopsis;

	@FindBy(id = "more")
	public WebElement txt_viewMore;

	@FindBy(id = "less")
	public WebElement txt_viewless;

	@FindBy(xpath = "((//*[@class='book-title-details'])[2]//*[contains(text(),'Remove Hold')])[1]")
	public WebElement removeHoldTitleDetails;

	@FindBy(xpath = "(//div[@class='author-name'])[1]")
	public WebElement txt_authorName;

	@FindBy(xpath = "//a[@class='primary-link']")
	public WebElement txt_authorLink;

	@FindBy(xpath = "//div[@class='search-view-container']")
	public WebElement author_resultScreen;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-filter-down-arrow'])[1]")
	public WebElement lib_drop_availabilitydrop;

	@FindBy(xpath = "//span[contains(text(),'Available Now')]")
	public WebElement lib_dropOptions_availablenow;

	@FindBy(xpath = "//span[@class='book-poster ng-star-inserted']")
	public WebElement available_formaticon;

	@FindBy(xpath = "((//*[@class='title-details-info'])[4]//div)[25]")
	public WebElement txt_isbn;

	@FindBy(xpath = "((//*[@class='title-details-info'])[4]//div)[22]")
	public WebElement publishDate;

	@FindBy(xpath = "((//*[@class='title-details-info'])[4]//div)[19]")
	public WebElement txt_publisher;

	@FindBy(xpath = "((//*[@class='title-details-info'])[4]//div)[15]")
	public WebElement txt_language;

	@FindBy(xpath = "((//*[@class='title-details-info'])[4]//div)[31]")
	public WebElement txt_ageRange;

	@FindBy(xpath = "//a[@class='btn-primary btn-primary-blue subject-btn d-flex ng-star-inserted']")
	private List<WebElement> listOf_subjectSeries;

	@FindBy(xpath = "//axis360-breadcrumb[@class='ng-star-inserted']")
	public WebElement nav_titleListScreen;

	@FindBy(xpath = "(//*[@class='title-details-info'])[3]")
	private WebElement titleDetailsInfo;

	@FindBy(xpath = "(//*[@class='btn-group book-details-menu ng-star-inserted'])[2]/*[1]")
	private WebElement formatIconInfo;

	@FindBy(xpath = "(//*[@class='btn-group book-details-menu ng-star-inserted'])[2]//*[@class='user-profile-text']")
	private WebElement profileInfo;

	@FindBy(xpath = "(//div[@class='btn-secondary-nobg user-profile-btn btn-theme ng-star-inserted'])[2]")
	private WebElement ageInfo;

	@FindBy(xpath = "(//div[@class='btn-secondary-nobg btn-secondary-fill btn-chat ng-star-inserted'])[2]")
	private WebElement langInfo;

	@FindBy(xpath = "(//*[@class='btn-group book-details-menu ng-star-inserted'])[2]/*[2]")
	private WebElement pagesTotal;

	@FindBy(xpath = "(//div[@role='listitem'])[2]")
	private WebElement durationOfAudioBook;

	@FindBy(xpath = "(//*[@class='close-icon'])[2]")
	private WebElement closeIcon;

	@FindBy(xpath = "//*[@class='login-container']//*[contains(text(),'Update Your Email')]")
	private WebElement emailNotifyPopUp;

	@FindBy(xpath = "(//*[@class='secondary-para ng-star-inserted'])[2]")
	private WebElement subjectAndDate;

	@FindBy(xpath = "//*[@class='login-container']//*[@class='description m-bottom']")
	private WebElement shortDescrip;

	@FindBy(id = "emailId")
	private WebElement emailID;

	@FindBy(id = "confirmEmailId")
	private WebElement confirmEmailID;

	@FindBy(xpath = "//*[contains(text(),'Email & confirm Email did not match.')]")
	private WebElement errToastMsg;

	@FindBy(id = "submit")
	private WebElement suBmitEmail;

	@FindBy(xpath = "//*[@class='kz-toast-msg']/*[contains(text(),'Success!')]")
	private WebElement succToastMsg;

	@FindBy(id = "loc_linkPrograms")
	private WebElement programsHamNew;

	@FindBy(id = "loc_labelMy Programs")
	private WebElement programsPageNew;

	@FindBy(xpath = "//*[@aria-labelledby='logo-title']")
	private WebElement axisOldLogo;

	@FindBy(xpath = "//*[@aria-label='profile']")
	private WebElement profileAvatar;

	@FindBy(id = "email-input")
	private WebElement emailInput;

	@FindBy(id = "loc_btnSave")
	private WebElement saveProfileButton;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement input_advanceSearch;

	@FindBy(xpath = "//button[@class='kz-searchButton']")
	private WebElement searchicon_advanceSearch;

	@FindBy(xpath = "(//img[@class='mat-card-image card-image'])[1]")
	public WebElement searchicon_titleresultScreen;
	
	@FindBy(xpath = "(//*[text()='Read'])[2]")
	public WebElement titleDetail_ReadCTa;
	
	@FindBy(xpath = "//span[text()='eAudio']")
	public WebElement titleDetail_eAudio_formatIcon;
	
	@FindBy(xpath = "(//div[@class='kz-card-image ng-star-inserted'])[1]")
	public WebElement Title_thru_search;
	
	@FindBy(xpath = "(//span[text()='Listen'])[2]")
	public WebElement titleDetail_ListenCta;
	
	@FindBy(xpath = "//h2[contains(text(),'Teen Only')]")
	private WebElement Carousel_teen;

	@FindBy(xpath = " //*[contains(text(),' Return ')]")
	public WebElement titleDetail_Return;
	
	@FindBy(xpath = " //*[contains(text(),'Renew ')]")
	public WebElement titleDetail_Renew;
	
	@FindBy(xpath = "(//div[contains(text(),'Details')])[1]")
	public WebElement Detailstab;
	
	@FindBy(xpath = "(//*[@class='primary-heading-2 line ng-star-inserted'])[2]")
	public WebElement HoldPosition;
	
	@FindBy(id = "loc_confirmbtnOK")
	public WebElement titleDetail_Return_confirmCTA;
	
	public WebElement getAxisOldLogo() {
		return axisOldLogo;
	}

	public WebElement getSuccToastMsg() {
		return succToastMsg;
	}

	public WebElement getSuBmitEmail() {
		return suBmitEmail;
	}

	public WebElement getErrToastMsg() {
		return errToastMsg;
	}

	public WebElement getEmailID() {
		return emailID;
	}

	public WebElement getConfirmEmailID() {
		return confirmEmailID;
	}

	public WebElement getShortDescrip() {
		return shortDescrip;
	}

	public WebElement getEmailNotifyPopUp() {
		return emailNotifyPopUp;
	}

	public WebElement getSubjectAndDate() {
		return subjectAndDate;
	}

	public WebElement getTxtToSpeech() {
		return txtToSpeech;
	}

	public WebElement getPagesTotal() {
		return pagesTotal;
	}

	public WebElement getDurationOfAudioBook() {
		return durationOfAudioBook;
	}

	public WebElement getAgeInfo() {
		return ageInfo;
	}

	public WebElement getFormatIconInfo() {
		return formatIconInfo;
	}

	public WebElement getProfileInfo() {
		return profileInfo;
	}

	public WebElement getLangInfo() {
		return langInfo;
	}

	public WebElement getTitleDetailsInfo() {
		return titleDetailsInfo;
	}

	public WebElement getTitleDetailsPage() {
		return titleDetailsPage;
	}

	public WebElement getSubjectColumn() {
		return subjectColumn;
	}

	public WebElement getSubjectLevels() {
		return subjectLevels;
	}

	public WebElement getCopiesAvailable() {
		return copiesAvailable;
	}

	public WebElement getPatronOnHold() {
		return patronOnHold;
	}

	public WebElement getPatronHoldCount() {
		return patronHoldCount;
	}

	public WebElement getPatronHoldPosition() {
		return patronHoldPosition;
	}

	public WebElement getToolTipIcon() {
		return toolTipIcon;
	}

	public WebElement getHoldPosition() {
		return holdPosition;
	}

	public WebElement getSearchResultsPage() {
		return searchResultsPage;
	}

	public WebElement getReadBy() {
		return readBy;
	}

	public WebElement getReadByAuthor() {
		return readByAuthor;
	}

	public WebElement getNarratedBy() {
		return narratedBy;
	}

	public WebElement getNarratedByAuthor() {
		return narratedByAuthor;
	}

	public WebElement getEdition() {
		return edition;
	}

	public WebElement getDuration() {
		return duration;
	}

	public WebElement getTitleDetails_placeHold() {
		return titleDetails_placeHold;
	}

	public WebElement getTitleDetails_progressbar() {
		return titleDetails_progressbar;
	}

	public WebElement getImg_audioformaticon() {
		return img_audioformaticon;
	}

	public WebElement getImg_ebookformaticon() {
		return img_ebookformaticon;
	}

	public WebElement getImg_titleDetails() {
		return img_titleDetails;
	}

	public WebElement getDownLoadSize() {
		return downLoadSize;
	}

	public WebElement getAudioBook() {
		return audioBook;
	}

	public WebElement geteBookDetails() {
		return eBookDetails;
	}

	public WebElement getTitleDetailScreen() {
		return titleDetailScreen;
	}

	public WebElement getMoreLikeThisCTA() {
		return moreLikeThisCTA;
	}

	public void clickRemoveHoldTitleDetails() {
		jsClick(removeHoldTitleDetails);
		WaitForWebElement(placeHoldCtaTitleDetails);
	}

	public void clickSubjects() {
		WaitForWebElement(subjectLevels1);
		javascriptScroll(subjectLevels1);
		ClickOnWebElement(subjectLevels1);
		waitFor(2000);
		WaitForWebElement(titleDetailsPage);
	}

	public void searchEbook() {
		visibilityWait(library.getFormatDropdown());
		jsClick(library.getFormatDropdown());
		visibilityWait(library.geteBook());
		library.addEbook();
	}

	public void clickEbook() {
		javascriptScroll(titleList.get(1));
		jsClick(titleList.get(1));
		WaitForWebElement(holdTitleList);
	}

	public void Click_availableEbook() {
		library.clickAvailability();
		javascriptScroll(titleList.get(1));
		//visibilityWait(titleList.get(1));
		jsClick(titleList.get(1));
		visibilityWait(titleDetailScreen);
		//waitFor(2000);
		/*
		 * visibilityWait(titleDetail_Checkout.get(0));
		 * javascriptScroll(titleDetail_Checkout.get(0));
		 * 
		 * for (int i = 0; i < titleDetail_Checkout.size(); i++) { if
		 * (isElementPresent(titleDetails_Checkout)) { jsClick(titleList.get(i)); break;
		 * } else { Logger.log("User is not able to view checkout"); } }
		 */
	}

	public void clickClosePopUp() {
		waitFor(2000);
		javascriptScroll(closeIcon);
		ClickOnWebElement(closeIcon);
	}

	public void recommendedTitleSection() {
		if (isElementPresent(moreLikeThisTitles)) {
			Logger.log("User able to see the recommended titles in More Like This section");
		} else if (noTitleRecommended.isDisplayed()) {
			Logger.log("User didn't have the recommended titles in More Like This section");
		}
	}

	public void searchAudiobook() {
		javascriptScroll(library.getFormatDropdown());
		jsClick(library.getFormatDropdown());
		visibilityWait(library.getAudioBook());
		jsClick(library.getAudioBook());
		visibilityWait(available_AudiobookTitle);
		// WaitForWebElement(audioBookTitle);
	}

	public void clickAudiobook() {
		javascriptScroll(titleList.get(1));
		ClickOnWebElement(titleList.get(1));
		WaitForWebElement(holdTitleList);
	}

	public void Click_availableAudioBook() {
		visibilityWait(available_AudiobookTitle);
		javascriptScroll(available_AudiobookTitle);
		jsClick(available_AudiobookTitle);
		// Click_availableEbook();
//		//jsClick(available_AudiobookTitle);
		WaitForWebElement(holdTitleList);
	}

	public void Click_AudioBook() {
		javascriptScroll(audioTitle);
		jsClick(audioTitle);
		WaitForWebElement(holdTitleList);
	}

	public void clickMoreLikeThisCta() {
		javascriptScroll(moreLikeThisCTA);
		jsClick(moreLikeThisCTA);
		// ClickOnWebElement(moreLikeThisCTA);
		WaitForWebElement(moreLikeThisSection);
	}

	public void noRecommendedTitles(String text) {
		if (isElementPresent(moreLikeThisTitles)) {
			Logger.log("User able to see the recommended titles in More Like This section");
		} else if (noTitleRecommended.isDisplayed()) {
			Assert.assertEquals(noTitleRecommended.getText(), text);
			Logger.log("User didn't have the recommended titles in More Like This section");
		}
	}

	public void textToSpeech() {
		if (isElementPresent(txtToSpeech)) {
			Logger.log("User able to see the Text to Speech Text");
		} else if (isElementPresent(eReadAlong)) {
			Logger.log("User able to see the EReadAlong Text if text to speech is not available");
		}
	}

	public void hrsAndMinute() {
		if (duration.getText().contains("h")) {
			Logger.log("Duration of the title is more than One Hour");
		} else {
			Logger.log("Duration of the title is less than One Hour");
		}
		if (duration.getText().contains("m")) {
			Logger.log("Minutes available for the Title");
		} else {
			Logger.log("Minutes not available for the Title");
		}
	}

	public void clickNarrator() {
		javascriptScroll(narratedByAuthor);
		String narratorName = narratedByAuthor.getText();
		ClickOnWebElement(narratedByAuthor);
		WaitForWebElement(searchResultsPage);
		if (searchResultsPage.getText().contains(narratorName)) {
			Logger.log("User able to navigate to search results page for that author");
		}
	}

	public void clickHoldTitle() {
		waitFor(5000);
		WaitForWebElement(libraryTitleImage.get(0));
		for (int i = 0; i < librartTitles.size(); i++) {
			if (librartTitles.get(i).getText().contains("Place Hold")) {
				waitFor(2000);
				javascriptScroll(libraryTitleImage.get(i));
				waitFor(2000);
				jsClick(libraryTitleImage.get(i));
				WaitForWebElement(titleDetailScreen);
				break;
			}
		}
	}

	public void clickHoldAudioTitle() {
		WaitForWebElement(audioBookTitle);
		javascriptScroll(audioBookTitle);
		ClickOnWebElement(audioBookTitle);
		WaitForWebElement(titleDetailScreen);
	}

	public void clickHoldCta() {
		waitFor(2000);
		javascriptScroll(placeHoldCta);
		jsClick(placeHoldCta);
		WaitForWebElement(succToastMsg);
		waitFor(2000);
		if (isElementPresent(removeHoldCta)) {
			Logger.log("Title placed on Hold");
		}
	}

	public void clickDetailsTab() {
		waitFor(2000);
		javascriptScroll(detailsTab);
		jsClick(detailsTab);
		waitFor(5000);
	}

	public void deleteEmailFromProfile() {
		WaitForWebElement(profileAvatar);
		ClickOnWebElement(profileAvatar);
		WaitForWebElement(emailInput);
		javascriptScroll(emailInput);
		waitFor(2000);
		emailInput.clear();
		waitFor(2000);
		SendKeysOnWebElement(emailInput, "");
		waitFor(2000);
		ClickOnWebElement(saveProfileButton);
		WaitForWebElement(succToastMsg);
	}

	public void inspToolTip(String text) {
		WaitForWebElement(holdPosition);
		javascriptScroll(holdPosition);
		WaitForWebElement(toolTipMsg);
		Assert.assertEquals(toolTipMsg.getText(), text);
		waitFor(2000);
	}

	public void clickToolTip(String text) {
		javascriptScroll(toolTipIcon);
		jsClick(toolTipIcon);
		WaitForWebElement(toolTipInfo);
		Assert.assertEquals(toolTipInfo.getText(), text);
		waitFor(2000);
		ClickOnWebElement(closeToolTipInfo);
		waitFor(2000);
	}

	public void verify_subTitle() {
		try {
			isElementPresent(txt_subtitle);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void primaryActionas_checkoutORplaceHold() {
		if (isElementPresent(titleDetails_Checkout)) {
			javascriptScroll(titleDetails_Checkout);
			Assert.assertTrue(isElementPresent(titleDetails_wishlist));
			Assert.assertTrue(isElementPresent(titleDetails_share));
		} else if (isElementPresent(titleDetails_placeHold)) {
			ClickOnWebElement(titleDetails_dropdown_moreoption);
			
			if (isElementPresent(titleDetails_dropdown_addtoWishlist)) {
				visibilityWait(titleDetails_dropdown_addtoWishlist);
				// WaitForWebElement(titleDetails_dropdown_addtoWishlist);
				Assert.assertTrue(isElementPresent(titleDetails_dropdown_addtoWishlist));
				Assert.assertTrue(isElementPresent(titleDetails_dropdown_share));
			} else {
				Logger.log("User is not able to view wishlist CTA ");
			}
		}
	}
	
	public void verify_PrimaryCTA() {
		if (isElementPresent(titleDetails_Checkout)) {
		Assert.assertTrue(titleDetails_Checkout.isDisplayed());
		Assert.assertTrue(titleDetails_wishlist.isDisplayed());
		Assert.assertTrue(titleDetails_share.isDisplayed());
		javascriptScroll(titleDetails_Checkout);
		jsClick(titleDetails_Checkout);
		waitFor(2000);
		visibilityWait(titleDetails_dropdown_moreoption);
		jsClick(titleDetails_dropdown_moreoption);
		visibilityWait(titleDetail_Return);
		Assert.assertTrue(titleDetail_Return.isDisplayed());
		Assert.assertTrue(titleDetail_Renew.isDisplayed());
		}else {
			visibilityWait(titleDetails_dropdown_moreoption);
			jsClick(titleDetails_dropdown_moreoption);
			visibilityWait(titleDetail_Return);
			jsClick(titleDetail_Return);
			visibilityWait(titleDetail_Return_confirmCTA);
			jsClick(titleDetail_Return_confirmCTA);
			waitFor(2000);
			Assert.assertTrue(titleDetails_Checkout.isDisplayed());
			Assert.assertTrue(titleDetails_wishlist.isDisplayed());
			Assert.assertTrue(titleDetails_share.isDisplayed());
			javascriptScroll(titleDetails_Checkout);
			jsClick(titleDetails_Checkout);
			waitFor(2000);
			visibilityWait(titleDetails_dropdown_moreoption);
			jsClick(titleDetails_dropdown_moreoption);
			visibilityWait(titleDetail_Return);
			Assert.assertTrue(titleDetail_Return.isDisplayed());
			Assert.assertTrue(titleDetail_Renew.isDisplayed());
		}

	}

	public void verify_notshowingWishList() {
		if (isElementPresent(titleDetails_wishlist)) {
			Logger.log("User is able to view wish list cta");
		} else {
			Logger.log("User is able to view wish list cta in secondary action");
		}

	}

	public void click_placeHoldtitle() {
		WaitForWebElement(titleList.get(4));
		waitFor(5000);
		javascriptScroll(titleCard.get(4));
		for (int i = 0; i < titleCard.size(); i++) {
			if (titleCard.get(i).getText().contains("Place Hold")) {
				jsClick(titleList.get(i));
				Logger.log("User Placed title on hold");
				break;
			} else {
				continue;
			}
		}
	}

	public void add_wishlist() {
		if (isElementPresent(add_wishlist)) {
			Logger.log("Already added the titles from wishlist");
			javascriptScroll(add_wishlist);
			ClickOnWebElement(add_wishlist);
			waitFor(2000);
		} else if (isElementPresent(titleDetails_dropdown_moreoption)) {
			javascriptScroll(titleDetails_dropdown_moreoption);
			jsClick(titleDetails_dropdown_moreoption);
			// ClickOnWebElement(titleDetails_dropdown_moreoption);
			WaitForWebElement(titleDetails_dropdown_addtoWishlist);
			jsClick(titleDetails_dropdown_addtoWishlist);
			// ClickOnWebElement(titleDetails_dropdown_addtoWishlist);
			waitFor(2000);
		}
	}

	public void click_addWishlistCTA() {
		visibilityWait(add_wishlist);
		jsClick(add_wishlist);
		// ClickOnWebElement(add_wishlist);
		waitFor(2000);

	}

	public void click_removeWishlist() {
		jsClick(add_wishlist);
		waitFor(2000);

	}

	public void remove_wishList() {
		if (isElementPresent(add_wishlist)) {
			Logger.log("Already added the titles from wishlist");
			javascriptScroll(add_wishlist);
			ClickOnWebElement(add_wishlist);
			waitFor(2000);
			ClickOnWebElement(add_wishlist);
		} else if (isElementPresent(titleDetails_dropdown_moreoption)) {
			javascriptScroll(titleDetails_dropdown_moreoption);
			jsClick(titleDetails_dropdown_moreoption);
			// ClickOnWebElement(titleDetails_dropdown_moreoption);
			WaitForWebElement(titleDetails_dropdown_addtoWishlist);
			jsClick(titleDetails_dropdown_addtoWishlist);
			// ClickOnWebElement(titleDetails_dropdown_addtoWishlist);
			waitFor(2000);
			jsClick(titleDetails_dropdown_addtoWishlist);
		}

	}

	public void click_checkout() {
		javascriptScroll(titleDetails_Checkout);
		ClickOnWebElement(titleDetails_Checkout);
		waitFor(3000);

	}

	public void click_placeHold() {
		javascriptScroll(titleDetails_placeHold);
		jsClick(titleDetails_placeHold);
		waitFor(3000);
	}

	public void addtoWishlist_placeHold() {
		visibilityWait(titleDetails_dropdown_moreoption);
		jsClick(titleDetails_dropdown_moreoption);
		// ClickOnWebElement(titleDetails_dropdown_moreoption);
		waitFor(2000);
		if (isElementPresent(titleDetails_dropdown_addtoWishlist)) {
			jsClick(titleDetails_dropdown_addtoWishlist);
			System.out.println("user is able to view the add to wishlist cta");
		} else {
			System.out.println("user is able to view the remove wishlist cta");
		}

	}

	public void removeWishlist_placeHold() {
		visibilityWait(titleDetails_dropdown_moreoption);
		jsClick(titleDetails_dropdown_moreoption);
		// ClickOnWebElement(titleDetails_dropdown_moreoption);
		waitFor(2000);
		jsClick(titleDetails_dropdown_RemoveWishlist);
		// ClickOnWebElement(titleDetails_dropdown_RemoveWishlist);
		waitFor(5000);

	}

	public void verify_share() {
		if (isElementPresent(titleDetails_share)) {
			System.out.println("user is able to view share option");
		} else {
			javascriptScroll(titleDetails_dropdown_moreoption);
			jsClick(titleDetails_dropdown_moreoption);
			waitFor(2000);
			isElementPresent(placeHold_share);
		}
	}

	public void click_suspendHold() {
		ClickOnWebElement(titleDetails_dropdown_moreoption);
		waitFor(2000);
		ClickOnWebElement(drop_suspendHold);
		waitFor(2000);

	}

	public void reume_suspendedHold() {
		click_placeHold();
		click_suspendHold();
	}

	public void click_RemoveHold() {
		ClickOnWebElement(titleDetails_dropdown_moreoption);
		waitFor(2000);
		ClickOnWebElement(drop_removedHold);
		waitFor(2000);

	}

	public void launch_manualTexas(String url) {
		DriverManager.getDriver().get(url);
		waitFor(4000);
	}

	public void click_synopsisTitle() {
		for (int i = 0; i < synopsisTitle_manual.size(); i++) {
			jsClick(synopsisTitle_manual.get(i));
			break;
		}
		waitFor(3000);
	}

	public void click_viewMore() {
		visibilityWait(txt_viewMore);
		jsClick(txt_viewMore);
		visibilityWait(txt_viewless);

	}

	public void click_viewLess() {
		visibilityWait(txt_viewless);
		jsClick(txt_viewless);
		// ClickOnWebElement(txt_viewless);
		// visibilityWait(txt_viewless);
	}

	public void view_readingProgress() {
		try {
			isElementPresent(titleDetails_progressbar);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void click_AuthorLink() {
		// for (int i = 0; i < txt_authorLink.size(); i++) {
		jsClick(txt_authorLink);
		// ClickOnWebElement(txt_authorLink);
		// jsClick(txt_authorLink.get(i));
		// break;
		// }
		visibilityWait(author_resultScreen);
	}

	public void clickCheckoutOldUi() {
		library.clickHamOldUi();
		ClickOnWebElement(ham.getCheckOutOldUi());
		WaitForWebElement(ham.getCheckOutOldUiPage());
	}

	public void select_availablenowdrop() {
		visibilityWait(lib_drop_availabilitydrop);
		jsClick(lib_drop_availabilitydrop);
		visibilityWait(lib_dropOptions_availablenow);
		// WaitForWebElement(lib_dropOptions_availablenow);
		jsClick(lib_dropOptions_availablenow);
		// ClickOnWebElement(lib_dropOptions_availablenow);
		waitFor(2000);
	}

	public void click_bookSeries() {
		visibilityWait(listOf_subjectSeries.get(0));
		javascriptScroll(listOf_subjectSeries.get(0));
		jsClick(listOf_subjectSeries.get(0));
		WaitForWebElement(nav_titleListScreen);
		if (isElementPresent(searchicon_titleresultScreen)) {
			Logger.log("Title displayed");
		} else {
			javascriptScroll(listOf_subjectSeries.get(1));
			jsClick(listOf_subjectSeries.get(1));
			WaitForWebElement(nav_titleListScreen);
		}
	}

	public boolean view_bookSeriesCTA() {
		visibilityWait(listOf_subjectSeries.get(0));
		javascriptScroll(listOf_subjectSeries.get(0));
		boolean b = true;
		isElementPresent(listOf_subjectSeries.get(0));
		return b;
	}

	public void enterEmailandConfirmEmail(String email, String confirmEmail) {
		WaitForWebElement(emailNotifyPopUp);
		SendKeysOnWebElement(emailID, email);
		waitFor(2000);
		SendKeysOnWebElement(confirmEmailID, confirmEmail);
		waitFor(2000);
	}

	public void clickSubMit() {
		waitFor(2000);
		ClickOnWebElement(suBmitEmail);
		waitFor(1000);
	}

	public void copiesInspect(String text, String text1) {
		Character num1 = copiesAvailable.getText().charAt(8);
		Character num2 = copiesAvailable.getText().charAt(13);
		System.out.println(text + num1 + " of " + num2 + text1);
		String fullText = text + num1 + " of " + num2 + text1;
		Assert.assertEquals(copiesAvailable.getText().contains(fullText), true);
	}

	public void waitForSuccessMsg() {
		waitFor(1000);
		WaitForWebElement(succToastMsg);
	}

	public void waitForHoldPosition() {
//		DriverManager.getDriver().navigate().refresh();
		WaitForWebElement(detailsTab);
		clickDetailsTab();
	}

	public void clickPrograms() {
		WaitForWebElement(programsHamNew);
		ClickOnWebElement(programsHamNew);
		WaitForWebElement(programsPageNew);
	}

	public void clickProgramsOldUi() {
		library.clickHamOldUi();
		ClickOnWebElement(ham.getProgramsOldUi());
		WaitForWebElement(ham.getProgramsOldUiPage());
	}

	public boolean view_authorName() {
		javascriptScroll(txt_authorName);
		boolean b = true;
		txt_authorName.isDisplayed();
		return b;
	}

	public void view_formatsTitle() {
		visibilityWait(available_formaticon);
		isElementPresent(available_formaticon);
		waitFor(2000);
	}

	public void verify_viewMore() {
		visibilityWait(txt_viewMore);
		javascriptScroll(txt_viewMore);
		txt_viewMore.isDisplayed();

	}

	public void click_AdvanceSearch() {
		visibilityWait(input_advanceSearch);
		jsClick(input_advanceSearch);
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			waitFor(2000);
			SendKeysOnWebElement(input_advanceSearch, "Story of the NFL");
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			waitFor(2000);
			SendKeysOnWebElement(input_advanceSearch, "Hungry Piggies");
			waitFor(2000);
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA1")) {
			waitFor(2000);
			SendKeysOnWebElement(input_advanceSearch, "Turning the Tide");
			waitFor(2000);
		}
		waitFor(2000);
		jsClick(searchicon_advanceSearch);
		//jsClick(Title_thru_search);
		waitFor(2000);
		visibilityWait(searchicon_titleresultScreen);
		jsClick(searchicon_titleresultScreen);
		// WaitForWebElement(searchicon_titleresultScreen);
	}

	public void click_AdvanceSearchtitle() {
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, "Lucky Stars");
		jsClick(searchicon_advanceSearch);
		waitFor(3000);

	}

	public void click_AdvanceSearchaudiotitle() {
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, "Lucky Charm");
		jsClick(searchicon_advanceSearch);
		waitFor(3000);

	}

	public void click_synapsisTitle() {
		javascriptScroll(searchicon_titleresultScreen);
		jsClick(searchicon_titleresultScreen);
		waitFor(2000);
	}

	public boolean view_ProgDetailsTab() {
		visibilityWait(txt_isbn);
		javascriptScroll(txt_isbn);
		boolean b = true;
		publishDate.isDisplayed();
		txt_publisher.isDisplayed();
		txt_language.isDisplayed();
		txt_ageRange.isDisplayed();
		return b;
	}

	public void removeHoldAndPlaceHold() {
		if (isElementPresent(removeHoldCta)) {
			javascriptScroll(removeHoldCta);
			jsClick(removeHoldCta);
			WaitForWebElement(placeHoldCta);
		} else {
			Logger.log("No Remove Hold CTA populated");
		}
	}
	
	
	public void click_DetailsTab() {
	try {
		visibilityWait(Detailstab);
		jsClick(Detailstab);
		waitFor(2000);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}
}
