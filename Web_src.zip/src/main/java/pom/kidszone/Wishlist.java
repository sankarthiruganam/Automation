	package pom.kidszone;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

public class Wishlist extends CommonAction {

	Holds hold = new Holds(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginPageView = new Loginpageview(DriverManager.getDriver());

	public Wishlist(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),' Wishlist')]")
	private WebElement wishlist;

	@FindBy(id = "loc_txtWishlist")
	private WebElement wishlistPage;

	@FindBy(xpath = "(//*[@class='mystuff-grids ng-star-inserted'])[1]")
	private WebElement wishlistTitle;
																													
	@FindBy(xpath = "//*[@class='no-stuffs ng-star-inserted']")
	private WebElement wishlistText;

	@FindBy(xpath = "(//*[@class='hero-container'])[1]")
	private WebElement homePage;

	@FindBy(xpath = "//*[@id='loc_labelWishlist']/*[@class='count ng-star-inserted']")
	private WebElement wishCount;

	@FindBy(id = "loc_btnFilter")
	private WebElement filterIcon;

	@FindBy(id = "loc_btnSort") 
	private WebElement sortIcon; 

	@FindBy(id = "breadcrumb-link-1")
	private WebElement breadCrumb;

	@FindBy(xpath = "(//button[@aria-label='more option'])[3]")
	private WebElement moreOptions;

	@FindBy(xpath = "(//button[@alt='add to wishlist'])")
	private WebElement addToWish;

	@FindBy(id = "loc_linkLibrary")
	private WebElement hamLibrary;

	@FindBy(xpath = "(//button[@aria-label='more option'])[1]")
	private WebElement secCtaOptions;

	@FindBy(xpath = "(//button[@alt='remover from wishlist'])[1]")
	private WebElement removeWish;

	@FindBy(xpath = "(//button[@class='kz-card-btn kz-card-btn-grid primary-action ng-star-inserted'])[1]")
	private WebElement primaryCta;
	
	@FindBy(id = "loc_btnSort")
	private WebElement sortButton;
	
	@FindBy(xpath = "//*[@class='cdk-overlay-pane']")
	private WebElement sortOptions;
	
	@FindBy(id = "loc_Recently Added")
	private WebElement latestWish;
	
	@FindBy(id = "loc_Ratings")
	private WebElement rating;
	
	@FindBy(id = "loc_A-Z")
	private WebElement aToZ;
	
	@FindBy(xpath = "//*[@id='loc_labelCheckouts']/*[@class='count ng-star-inserted']")
	private WebElement checkOutCount;
	
	@FindBy(id = "loc_txtCheckouts")
	private WebElement checkOutPage;
	
	@FindBy(xpath = "(//button[@aria-label='more option'])")
	private WebElement CheckOutSecCta;
	
	@FindBy(xpath = "(//*[@class='mat-ripple mat-menu-ripple'])[1]")
	private WebElement returnTitle;
	
	@FindBy(xpath = "//*[contains(text(),'Remove')]")
	public WebElement secondaryCta_Remove;

	public WebElement getAddToWish() {
		return addToWish;
	}
	
	public WebElement getHamLibrary() {
		return hamLibrary;
	}
	
	public WebElement getLatestWish() {
		return latestWish;
	}

	public WebElement getPrimaryCta() {
		return primaryCta;
	}

	public WebElement getSecCtaOptions() {
		return secCtaOptions;
	}

	public WebElement getRemoveWish() {
		return removeWish;
	}

	public WebElement getBreadCrumb() {
		return breadCrumb;
	}

	public WebElement getFilterIcon() {
		return filterIcon;
	}

	public WebElement getSortIcon() {
		return sortIcon;
	}

	public WebElement getHomePage() {
		return homePage;
	}

	public WebElement getWishlistTitle() {
		return wishlistTitle;
	}

	public WebElement getWishlistText() {
		return wishlistText;
	}

	public WebElement getWishlistPage() {
		return wishlistPage;
	}

	public WebElement getWishlist() {
		return wishlist;
	}

	public WebElement getWishCount() {
		return wishCount;
	}

	public void idlogin(String id) {
		javascriptScroll(hold.getUserId());
		SendKeysOnWebElement(hold.getUserId(), id);
		ClickOnWebElement(loginPageView.btn_LoginOnlyId);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		//WaitForWebElement(hold.getLibraryPage());
	}

	public void clickWishlist() {
		javascriptScroll(wishlist);
		jsClick(wishlist);
		WaitForWebElement(wishlistPage);
	}

	public boolean wishListTitleAbsent() {
		boolean b = false;
		if (isElementPresent(wishlistTitle)) {
			b = true;
		}
		return b;
	}

	public void backCta() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(hold.getHoldPage());
	}

	public void addtitle() {
		WaitForWebElement(moreOptions);
		javascriptScroll(moreOptions);
		jsClick(moreOptions);
		waitFor(4000);
		if (isElementPresent(addToWish)) {
			jsClick(addToWish);
			waitFor(5000);
			ham.click_HamburgerMenu();
			hold.myShelfClick();
			clickWishlist();
		} 
		else if (isElementPresent(removeWish)){
			ham.click_HamburgerMenu();
			hold.myShelfClick();
			clickWishlist();
		}
	}

	public void addtoWishList() {
		javascriptScroll(ham.getLink_hamburgerMenu());
		jsClick(ham.getLink_hamburgerMenu());
		WaitForWebElement(hamLibrary);
		jsClick(hamLibrary);
		WaitForWebElement(hold.getLibraryPage());
		addtitle();
	}

	public void removeWishList() {
			WaitForWebElement(secCtaOptions);
			jsClick(secCtaOptions);
			//WaitForWebElement(removeWish);
			javascriptScroll(removeWish);
			jsClick(removeWish);
			DriverManager.getDriver().navigate().refresh();
			WaitForWebElement(wishlistPage);
	}
	
	public void wishRemoveCount() {
		DriverManager.getDriver().navigate().refresh();
		WaitForWebElement(wishlistPage);
//		Assert.assertTrue(wishCount.getText().contains("0"));
	}

	public void clickSecActions() {
		WaitForWebElement(secCtaOptions);
		jsClick(secCtaOptions);
		WaitForWebElement(removeWish);
		Assert.assertTrue(removeWish.isDisplayed());
	}
	
	public void sortClick() {
		WaitForWebElement(sortButton);
		jsClick(sortButton);
		WaitForWebElement(latestWish);
	}
	
	public void sortOptions(String str1, String str2, String str3) {
		javascriptScroll(latestWish);
		Assert.assertTrue(latestWish.isDisplayed());
		Assert.assertTrue(rating.isDisplayed());
		Assert.assertTrue(aToZ.isDisplayed());
		jsClick(sortButton);
//		Assert.assertTrue(latestWish.getText().equals(str1));
//		Assert.assertTrue(rating.getText().equals(str2));
//		Assert.assertTrue(aToZ.getText().equals(str3));
	}
	
//	public void ClearTitlesIncheckOut() {
//		ham.click_HamburgerMenu();
//		hold.myShelfClick();
//		if (checkOutCount.getText().contains("[1-9]")) {
//			ClickOnWebElement(checkOutCount);
//			WaitForWebElement(checkOutPage);
//			do {
//				returnTitleFromCheckout();
//			} while (checkOutCount.getText().contains("0"));
//		}
//	}
	
//	public void moveAndVerifyTheTitleinCheckout() {
//		WaitForWebElement(primaryCta);
//		String authorName;
//		authorName = hold.getAuthorName().getText();
//		ClickOnWebElement(primaryCta);
//		WaitForWebElement(wishlistText);
//		DriverManager.getDriver().navigate().refresh();
//		ClickOnWebElement(checkOutCount);
//		WaitForWebElement(checkOutPage);
//		hold.getAuthorName().equals(authorName);
//	}
	
//	public void returnTitleFromCheckout() {
//		javascriptScroll(CheckOutSecCta);
//		ClickOnWebElement(CheckOutSecCta);
//		WaitForWebElement(returnTitle);
//		jsClick(returnTitle);
//		DriverManager.getDriver().navigate().refresh();
//		WaitForWebElement(checkOutPage);
//	}
	
//	public void removeAndAddWishlist() {
//		jsClick(removeWish);
//		WaitForWebElement(moreOptions);
//		jsClick(moreOptions);
//		WaitForWebElement(addToWish);
//		javascriptScroll(addToWish);
//		jsClick(addToWish);	
//}
	
}
