package eyesmanager;

import org.openqa.selenium.WebDriver;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.FileLogger;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.config.Configuration;
import com.applitools.eyes.selenium.BrowserType;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.visualgrid.model.ChromeEmulationInfo;
import com.applitools.eyes.visualgrid.model.DesktopBrowserInfo;
import com.applitools.eyes.visualgrid.model.DeviceName;
import com.applitools.eyes.visualgrid.model.IosDeviceInfo;
import com.applitools.eyes.visualgrid.model.IosDeviceName;
import com.applitools.eyes.visualgrid.model.ScreenOrientation;
import com.applitools.eyes.visualgrid.services.RunnerOptions;
import com.applitools.eyes.visualgrid.services.VisualGridRunner;

import io.cucumber.java.Scenario;

public class EyesSetup {
	
	public static Eyes eyes;
	
	// UltraFast Grid Runner Variables//

	private final String appName = "kidzone-axisweb";
	private final String batchName = "Rel1.3.2_VisualUI_Web";
	private final int viewPortWidth = 1440;
	private final int viewPortHeight = 740;
	String myEyesServer = "https://eyesapi.applitools.com/";
	private String apiKey = System.getProperty("visualApiKey");//"VJ1d3kQtEHQ108TPMSgXWakGsYYZmC75MkuwgPLCy7HWQ110";
	private EyesRunner runner = null;
	private Configuration suiteConfig;
	

	public Eyes getEyes(WebDriver driver, Scenario scenario) {
		runner = new VisualGridRunner(new RunnerOptions().testConcurrency(10));
		suiteConfig = new Configuration();
		System.out.println("scenario name: " + scenario.getName());
		setEyesConfiguration(scenario, suiteConfig);
		System.out.println("suite config details: " + suiteConfig);
//		suiteConfig.setLayoutBreakpoints(true);
		eyes = new Eyes(runner);
		eyes.setConfiguration(suiteConfig);
		eyes.open(driver);
		//eyes.setLogHandler(new StdoutLogHandler(false));
		eyes.setLogHandler(new FileLogger("C:\\Users\\udayakumar_v\\Desktop\\Updated_work\\Visual_UI_Logs\\file.log",true,true));

		return eyes;
	}

	private void setEyesConfiguration(Scenario scenario, Configuration suiteConfig) {
		suiteConfig
				// Visual Grid configurations
				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.CHROME))
//				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.CHROME_ONE_VERSION_BACK))
//				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.CHROME_TWO_VERSIONS_BACK))
				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.FIREFOX))
				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.SAFARI))
				.addBrowser(new DesktopBrowserInfo(viewPortWidth, viewPortHeight, BrowserType.EDGE_CHROMIUM))
				.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_X, ScreenOrientation.PORTRAIT))
				.addBrowser(new ChromeEmulationInfo(DeviceName.Galaxy_S20, ScreenOrientation.PORTRAIT))
				.addBrowser(new ChromeEmulationInfo(DeviceName.Galaxy_S20, ScreenOrientation.LANDSCAPE))
				.addBrowser(new ChromeEmulationInfo(DeviceName.Galaxy_Note_10, ScreenOrientation.PORTRAIT))
				.addBrowser(new IosDeviceInfo(IosDeviceName.iPad_Pro_3, ScreenOrientation.LANDSCAPE))
				.addBrowser(new IosDeviceInfo(IosDeviceName.iPad_Pro_3, ScreenOrientation.PORTRAIT))		
				.setViewportSize(new RectangleSize(viewPortWidth, viewPortHeight))
				.setApiKey(apiKey).setServerUrl(myEyesServer).setAppName(appName).setBatch(new BatchInfo(batchName))
				//.setEnvironmentName("QA")
				.setTestName(scenario.getName()).setForceFullPageScreenshot(false);
		// TODO: https://applitools.com/docs/topics/overview/overview-writing-tests-with-vg.html?Highlight=ultrafast%20grid%20implementation 

	}

}