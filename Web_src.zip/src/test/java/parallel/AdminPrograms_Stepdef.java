package parallel;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AdminPrograms;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;



public class AdminPrograms_Stepdef extends CommonAction {

	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	AdminPrograms adminPrograms = new AdminPrograms(DriverManager.getDriver());
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	

	/*********************************************************************************************/
	
	//131404
	
	
	@Given("User launch the BTadmin url")
	public void user_launch_the_b_tadmin_url() throws Exception {
		login.login_BTAdmin();
	}
	@Given("User launch the Library admin axis url")
	public void user_launch_the_library_admin_axis_url() throws Exception {
		login.login_LMaxis360Sales();
	}
	
	@Given("User launch the LM admin kidszone url")
	public void user_launch_the_lm_admin_kidszone_url() throws Exception {
		login.login_LMidAndPassword();
	}
	
	@Given("user launch the axis and kidszone LM Admin Site url")
	public void user_launch_the_axis_and_kidszone_lm_admin_site_url() throws Exception {
		login.Login_LMprefixWithPin(); 
	}
	@Given("user is logged in as admin {string} and {string}")
	public void user_is_logged_in_as_admin_and(String username, String password) {
		admin.admin_login(username, password);    
	}
	
	@Then("user select on library management section")
	public void user_select_on_library_management_section() {
		admin.library_settings();	  
	}

	@Then("search the library {string} and edit the library")
	public void search_the_library_and_edit_the_library(String library) {
		admin.library_SearchAdmin(library);
	}
	
	@Then("click on programs navigate to my programs")
	public void click_on_programs_navigate_to_my_programs() {
		adminPrograms.click_programsCTA();
		Assert.assertTrue(adminPrograms.getSalesdemoLib_Btn_CreateprogramsCTA().isDisplayed());
	}

	@Then("user click on create program cta")
	public void user_click_on_create_program_cta() {
		adminPrograms.click_createProgramCTA();
	}

	@Then("user should not see profile type option")
	public void user_should_not_see_profile_type_option() {
	adminPrograms.notSee_profileTypeOption();
		//adminPrograms.notSee_profileTypeOption();
	}
	@When("user enter {string} and set ProgramType, Start Date, End Date")
	public void user_enter_something_and_set_programtype_start_date_end_date(String programName) throws Throwable {
		adminPrograms.enter_ProgramName(programName) ;
		adminPrograms.enter_setProgramType();
		adminPrograms.program_startDate();
		adminPrograms.program_endDate();
		adminPrograms.click_endDate();
	}

	@Then("user should able to select all profile type for the program")
	public void user_should_able_to_select_all_profile_type_for_the_program() throws Throwable {
		adminPrograms.click_profileTypeAll();
	}
	@And("click on save cta")
    public void click_on_save_cta() throws Throwable {
		adminPrograms.click_SaveCTA();
    }
	@Then("user should able to select adult and teen profile type for the program")
	public void user_should_able_to_select_adult_and_teen_profile_type_for_the_program() {
		adminPrograms.click_profileTypeAdult();
		adminPrograms.click_profileTypeTeen();
	}

	@Then("user should able to select teen and kid profile type for the program")
	public void user_should_able_to_select_teen_and_kid_profile_type_for_the_program() {
		adminPrograms.click_profileTypeTeen();
		adminPrograms.click_profileTypeKid();
	}

	@Then("user should able to select adult and kid profile type for the program")
	public void user_should_able_to_select_adult_and_kid_profile_type_for_the_program() {
		adminPrograms.click_profileTypeAdult();
		adminPrograms.click_profileTypeKid();
	}

	@Then("user not select any profile type for the program")
	public void user_not_select_any_profile_type_for_the_program() {
		adminPrograms.not_selectprofileType();
	}

	@Then("click on publish cta")
	public void click_on_publish_cta() {
		adminPrograms.click_publishProgm();
	}

	@Then("user should see error message")
	public void user_should_see_error_message() {
	   Assert.assertEquals(adminPrograms.getSalesdemoLib_errormsg_notselectProfiletype().isDisplayed(), true);
	}
	
	//131406
	
	@Then("user click on active programs cta")
	public void user_click_on_active_programs_cta() {
		adminPrograms.click_ActiveProgram();
	}

	@Then("select program navigate to program title page")
	public void select_program_navigate_to_program_title_page() {
		adminPrograms.select_alreadyCreatedprograms();
	}
	
	@Then("User set filter as profile type All")
	public void user_set_filter_as_profile_type_All() {
		adminPrograms.clickfilter_viewProfileTypes();
		adminPrograms.selectDropdown_profiletypeAll();
	}


	@Then("user click on edit program and navigate to edit program screen")
	public void user_click_on_edit_program_and_navigate_to_edit_program_screen() {
		adminPrograms.click_editProgram();
		Assert.assertTrue( adminPrograms.getTxt_NaveditReadingProgram().isDisplayed());
	}

	@Then("user should able to see profile selection pre-populated data for the program")
	public void user_should_able_to_see_profile_selection_pre_populated_data_for_the_program() {
		adminPrograms.view_profileDetails();
	}

	@Then("user should able to review and edit user profile type")
	public void user_should_able_to_review_and_edit_user_profile_type() {
		adminPrograms.click_profileTypes();
	}
	
	@Then("user should not view adult profile type")
	public void user_should_not_view_adult_profile_type() {
		Assert.assertFalse(adminPrograms.getProfileTypeTab().getText().contains("Adult"));
	}
	
	@Then("user should view adult profile type")
	public void user_should_view_adult_profile_type() {
		Assert.assertTrue(adminPrograms.getProfileTypeTab().getText().contains("Adult"));
	}

	@Then("user click on save cta to update the program")
	public void user_click_on_save_cta_to_update_the_program() {
		adminPrograms.click_SaveCTA();
	}
	
	@Then("admin should view all the existing programs mapped to adult profile by default")
	public void admin_should_view_all_the_existing_programs_mapped_to_adult_profile_by_default() {
	   Assert.assertTrue(adminPrograms.getFilter_defaultAdultprofileType().isDisplayed());
	   Logger.log("user should view adult profile by default");
	}
	/*
	@Given("user should not view adult profile type")
	public void user_should_not_view_adult_profile_type() {
		adminPrograms.notShowing_adultOption();
	}
	@Given("user should view adult profile type")
	public void user_should_view_adult_profile_type() {
	   Assert.assertEquals(adminPrograms.view_AdultprofileTypes(), true);
	}
	*/
	
	@Then("profile setting change axis to kidszone library only")
	public void profile_setting_change_axis_to_kidszone_library_only() {
		admin.enable_axistoKidzone();
	}

	@Then("click on save cta to update the subscription")
	public void click_on_save_cta_to_update_the_subscription() {
		admin.saveCTA_libpage();
	}

	@Then("admin should not view all the existing programs mapped to adult profile by default")
	public void admin_should_not_view_all_the_existing_programs_mapped_to_adult_profile_by_default() {
		Assert.assertFalse(adminPrograms.getFilter_defaultAdultprofileType().isDisplayed());
		Logger.log("user should not view adult profile by default");
	}
	//131408
	
	@Then("user click on duplicate program and navigate to create program screen")
	public void user_click_on_duplicate_program_and_navigate_to_create_program_screen() {
		adminPrograms.click_duplicateProgram();
		Assert.assertTrue(adminPrograms.getTxt_createReadingProgm().isDisplayed());
	}

	@Then("user should able to see profile type selection pre-populated data for the duplicated program")
	public void user_should_able_to_see_profile_type_selection_pre_populated_data_for_the_duplicated_program() {
		adminPrograms.view_profileDetails();
	}

	@Then("user should able to update the program details including profile type selection")
	public void user_should_able_to_update_the_program_details_including_profile_type_selection() {
		adminPrograms.click_profileTypes();
	}

	@Then("select program navigate to program details screen")
	public void select_program_navigate_to_program_details_screen() {
		adminPrograms.select_alreadyCreatedprograms();
		Assert.assertTrue(adminPrograms.getTxt_NavprofileDetailscreen().isDisplayed());
	}

	@Then("user should able to see profile type selection on program detail screen")
	public void user_should_able_to_see_profile_type_selection_on_program_detail_screen() {
	   Assert.assertTrue(adminPrograms.getTxt_profiledetailscreen_profile().isDisplayed());
		adminPrograms.not_seeprofileType();
	}
	@When("user should not able to see profile type selection on program detail screen")
	public void user_should_not_able_to_see_profile_type_selection_on_program_detail_screen() {
	  // Assert.assertFalse(adminPrograms.getTxt_profiledetailscreen_profile().isDisplayed());
	}
	//131410
	
	@Given("user on my program screen")
	public void user_on_my_program_screen() {
		Assert.assertTrue(adminPrograms.getSalesdemoLib_Btn_CreateprogramsCTA().isDisplayed());
	}

	@When("user should be able to view option to filter and view programs for each profile type")
	public void user_should_be_able_to_view_option_to_filter_and_view_programs_for_each_profile_type() {
		adminPrograms.clickfilter_viewProfileTypes();
	}

	@Then("user set filter as profile type all")
	public void user_set_filter_as_profile_type_all() {
		adminPrograms.selectDropdown_profiletypeAll();
	}

	@Then("user should view programs enabled for all profiles")
	public void user_should_view_programs_enabled_for_all_profiles() {
		adminPrograms.view_programEnabled();
	}

	@Given("click on draft program navigate to draft screen")
	public void click_on_draft_program_navigate_to_draft_screen() {
		adminPrograms.click_drafprogram();
	}

	@Given("click on active program navigate to active screen")
	public void click_on_active_program_navigate_to_active_screen() {
		adminPrograms.click_ActiveProgram();
	}

	@Given("click on closed program navigate to closed screen")
	public void click_on_closed_program_navigate_to_closed_screen() {
		adminPrograms.view_programEnabled();
	}

	@Then("user set filter as profile type adult")
	public void user_set_filter_as_profile_type_adult() {
		adminPrograms.selectDropdown_profileTypeadult();
	}

	@Then("user should view programs enabled for adult profiles")
	public void user_should_view_programs_enabled_for_adult_profiles() {
		adminPrograms.view_programEnabled();
	}

	@Then("user set filter as profile type teen")
	public void user_set_filter_as_profile_type_teen() {
		adminPrograms.selectDropdown_profileTypeTeen();
	}

	@Then("user should view programs enabled for teen profiles")
	public void user_should_view_programs_enabled_for_teen_profiles() {
		adminPrograms.view_programEnabled();
	}

	@Then("user set filter as profile type kid")
	public void user_set_filter_as_profile_type_kid() {
		adminPrograms.selectDropdown_profileTypekid();
	}

	@Then("user should view programs enabled for kid profiles")
	public void user_should_view_programs_enabled_for_kid_profiles() {
		adminPrograms.view_programEnabled();
	}
	
	@Given("admin user should be able to view selected profile for a program on program card")
	public void admin_user_should_be_able_to_view_selected_profile_for_a_program_on_program_card() {
		adminPrograms.view_programEnabled();
	}
	
	@Then("user should not view adult profile type in filter option")
	public void user_should_not_view_adult_profile_type_in_filter_option() {
	 adminPrograms.dropdown_notshowing_adultprofileType();
	}
	
//143107
	@Given("library has kidszone subscription")
	public void library_has_kidszone_subscription() {
		Logger.log("library has kidszone subscription");
	}

	@When("admin clicks on a home cta")
	public void admin_clicks_on_a_home_cta() {
		adminPrograms.click_home_cta();
	}

	@Then("admin should be able to view the library management screen navigation in admin portal home for library admin")
	public void admin_should_be_able_to_view_the_library_management_screen_navigation_in_admin_portal_home_for_library_admin() {
	    adminPrograms.click_settings_cta();
	    Assert.assertTrue(adminPrograms.library_management_screen());
	}
	
//143108
	@Then("admin should be able to view the library management screen navigation in Library actions screen for baker and taylor admin portal")
	public void admin_should_be_able_to_view_the_library_management_screen_navigation_in_library_actions_screen_for_baker_and_taylor_admin_portal() {
		Assert.assertTrue(adminPrograms.library_management_screen());
	}

	/******************************************************sprint5A LM announcement *************************************/
	
	//131396
	
	@When("user lands on home page")
	public void user_lands_on_home_page() {
		Assert.assertTrue(admin.getHome_page().isDisplayed());
	}

	@Then("user should be able to view the announcements navigation in admin portal for library admin")
	public void user_should_be_able_to_view_the_announcements_navigation_in_admin_portal_for_library_admin() {
	   admin.select_announcements();
	}

	//131741
	
	@When("user click on {string} cta option from library header")
	public void user_click_on_cta_option_from_library_header(String string) {
	    admin.click_libAdministration();
	}

	@When("user should be able to view the announcements navigation in Library adminstration screen for baker and taylor admin portal")
	public void user_should_be_able_to_view_the_announcements_navigation_in_library_adminstration_screen_for_baker_and_taylor_admin_portal() {
	   admin.click_announcementEditicon();
	}

	@When("user navigates to announcements screen")
	public void user_navigates_to_announcements_screen() {
	   Assert.assertEquals(admin.getNav_announcement().isDisplayed(), true);
	}

	@Then("user should be able to view url {string} if preview of the url could not be rendered")
	public void user_should_be_able_to_view_url_if_preview_of_the_url_could_not_be_rendered(String url) throws InvalidFormatException, IOException {
	   admin.enter_urlDetails(url);
	   admin.select_preview();
	   Assert.assertEquals(isElementPresent(admin.url_txtinAnnouncement),false );
	   
	}
	
	@When("user should be able to view and click the announcements navigation in home page")
	public void user_should_be_able_to_view_and_click_the_announcements_navigation_in_home_page() {
		 admin.select_announcements();
		 admin.click_announcementEditicon();
	}
	
	
	
}