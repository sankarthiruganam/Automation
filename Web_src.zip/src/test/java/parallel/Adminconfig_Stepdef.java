package parallel;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AdminPrograms;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Pagesourceview;

public class Adminconfig_Stepdef extends CommonAction {
	
	ExcelReader reader = new ExcelReader();
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Pagesourceview page = new Pagesourceview(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	AdminPrograms programs = new AdminPrograms(DriverManager.getDriver());

	@Given("the user launch the application url")
	public void the_user_launch_the_application_url() throws Throwable {
		login.Login_texas();

	}

	@When("the user entering {string} and {string}")
	public void the_user_entering_something_and_something(String username, String password) throws Throwable {
		admin.admin_login(username, password);
	}

	@Then("the user should see manage library site settings")
	public void the_user_should_see_manage_library_site_settings() throws Throwable {
		Assert.assertEquals(admin.getBtn_librarymanagementMenu().isEnabled(), true);
		admin.library_settings();

	}

	@And("the user navigates to the library site settings in b&t admin portal")
	public void the_user_navigates_to_the_library_site_settings_in_bt_admin_portal() throws Throwable {
		admin.library_search();

	}

	@And("the user should see patron profile management section in the library settings screen")
	public void the_user_should_see_patron_profile_management_section_in_the_library_settings_screen()
			throws Throwable {
		Logger.log("User able to see patron profile management section in the library settings screen");

	}

	@And("the user should select the checkbox to enable the kids profile for the library")
	public void the_user_should_select_the_checkbox_to_enable_the_kids_profile_for_the_library() throws Throwable {
		admin.enablekidsprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether kids profile enabled")
	public void the_user_should_check_the_db_whether_kids_profile_enabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enablekidsprof();

	}

	@And("the user should unselect the checkbox to disable the kids profile for the library")
	public void the_user_should_unselect_the_checkbox_to_disable_the_kids_profile_for_the_library() throws Throwable {
		admin.disablekidsprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether kids profile disabled")
	public void the_user_should_check_the_db_whether_kids_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disablekidsprof();

	}

	// 109404//

	@And("the user should select the checkbox to enable the teen profile for the library")
	public void the_user_should_select_the_checkbox_to_enable_the_teen_profile_for_the_library() throws Throwable {
		admin.enableteenprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether teen profile enabled")
	public void the_user_should_check_the_db_whether_teen_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enableteenprof();

	}

	@And("the user should unselect the checkbox to disable the teen profile for the library")
	public void the_user_should_unselect_the_checkbox_to_disable_the_teen_profile_for_the_library() throws Throwable {
		admin.disableteenprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether teen profile disable")
	public void the_user_should_check_the_db_whether_teen_profile_disable() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disablekidsprof();

	}

	// 109405//

	@And("the user should select the checkbox to enable the adult profile for the library")
	public void the_user_should_select_the_checkbox_to_enable_the_adult_profile_for_the_library() throws Throwable {
		admin.enableadultprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether adult profile enabled")
	public void the_user_should_check_the_db_whether_adult_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enableadultprof();

	}

	@And("the user should unselect the checkbox to disable the adult profile for the library")
	public void the_user_should_unselect_the_checkbox_to_disable_the_adult_profile_for_the_library() throws Throwable {
		admin.disableadultprof();
		admin.savelibrary();
	}

	@And("the user should check the db whether adult profile disable")
	public void the_user_should_check_the_db_whether_adult_profile_disable() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disablekidsprof();

	}

	// 109406//

	@Given("the user launch the {string} url")
	public void the_user_launch_the_something_url(String strArg1) throws Throwable {
		List<Map<String, String>> testData = reader
				.getData(System.getProperty("user.dir") + "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		login.Login_texas();

	}

	@Given("the user in management library setting")
	public void the_user_in_management_library_setting() throws Throwable {
		Logger.log("User is in management library setting");
	}

	@When("the user enters the username {string} and password {string} shared by the client")
	public void the_user_enters_the_username_something_and_password_something_shared_by_the_client(String strArg1,
			String strArg2) throws Throwable {
		admin.admin_relogin();
	}

	@When("the user enable adult profile in the setting")
	public void the_user_enable_adult_profile_in_the_setting() throws Throwable {
		admin.enableadultprof();

	}

	@When("the user enable teen profile in the setting")
	public void the_user_enable_teen_profile_in_the_setting() throws Throwable {
		admin.enableteenprof();
	}

	@When("the user enable kid profile in the setting")
	public void the_user_enable_kid_profile_in_the_setting() throws Throwable {
		admin.enablekidsprof();
	}

	@And("the user click on library in menu and select the library")
	public void the_user_click_on_library_in_menu_and_select_the_library() throws Throwable {
		admin.library_settings();
	}

	@And("the user see the library settings screen")
	public void the_user_see_the_library_settings_screen() throws Throwable {
		admin.library_search();
		admin.enable_kidszone();
	}

	@And("the user should enable the Kidszone subscription")
	public void the_user_should_enable_the_Kidszone_subscription() throws Throwable {
		Logger.log("User enabled the Kidszone subscription");
	}

	@Then("the user should select the checkbox to enable the programs for adult profile")
	public void the_user_should_select_the_checkbox_to_enable_the_programs_for_adult_profile() throws Throwable {
		admin.enable_adultprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for adult profile enabled")
	public void the_user_should_check_the_db_whether_programs_for_adult_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_adultprogram();

	}

	@Then("the user should unselect the checkbox to disable the programs for adult profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_programs_for_adult_profile() throws Throwable {
		admin.disable_adultprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for adult profile disabled")
	public void the_user_should_check_the_db_whether_programs_for_adult_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_adultprogram();

	}

	@Then("the user should select the checkbox to enable the programs for teen profile")
	public void the_user_should_select_the_checkbox_to_enable_the_programs_for_teen_profile() throws Throwable {
		admin.enable_teenprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for teen profile enabled")
	public void the_user_should_check_the_db_whether_programs_for_teen_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_teenprogram();

	}

	@Then("the user should unselect the checkbox to disable the programs for teen profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_programs_for_teen_profile() throws Throwable {
		admin.disable_teenprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for teen profile disabled")
	public void the_user_should_check_the_db_whether_programs_for_teen_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_teenprogram();

	}

	@Then("the user should select the checkbox to enable the programs for kid profile")
	public void the_user_should_select_the_checkbox_to_enable_the_programs_for_kid_profile() throws Throwable {
		admin.enable_kidsprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for kid profile enabled")
	public void the_user_should_check_the_db_whether_programs_for_kid_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_kidsprogram();

	}

	@Then("the user should unselect the checkbox to disable the programs for kid profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_programs_for_kid_profile() throws Throwable {
		admin.disable_kidsprogram();
		admin.savelibrary();
	}

	@And("the user should check the db whether programs for kid profile disabled")
	public void the_user_should_check_the_db_whether_programs_for_kid_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_kidsprogram();

	}

	// 109407//

	@Then("the user should select the checkbox to enable the insights and goals for adult profile")
	public void the_user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_adult_profile()
			throws Throwable {
		admin.enable_adultinsight();
		admin.savelibrary();
	}

	@And("the user should check the db whether insights and goals for adult profile enabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_adult_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_adultinsight();

	}

	@Then("the user should unselect the checkbox to disable the insights and goals for adult profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_adult_profile()
			throws Throwable {
		admin.disable_adultinsight();
		admin.savelibrary();

	}

	@And("the user should check the db whether insights and goals for adult profile disabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_adult_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_adultinsight();

	}

	@Then("the user should select the checkbox to enable the insights and goals for teen profile")
	public void the_user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_teen_profile()
			throws Throwable {
		admin.enable_teeninsight();
		admin.savelibrary();
	}

	@And("the user should check the db whether insights and goals for teen profile enabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_teen_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_teeninsight();

	}

	@Then("the user should unselect the checkbox to disable the insights and goals for teen profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_teen_profile()
			throws Throwable {
		admin.disable_teeninsight();
		admin.savelibrary();

	}

	@And("the user should check the db whether insights and goals for teen profile disabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_teen_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_teeninsight();

	}

	@Then("the user should select the checkbox to enable the insights and goals for kid profile")
	public void the_user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_kid_profile()
			throws Throwable {
		admin.enable_kidsinsight();
		admin.savelibrary();
	}

	@And("the user should check the db whether insights and goals for kid profile enabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_kid_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_kidsinsight();

	}

	@Then("the user should unselect the checkbox to disable the insights and goals for kid profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_kid_profile()
			throws Throwable {
		admin.disable_kidsinsight();
		admin.savelibrary();
	}

	@And("the user should check the db whether insights and goals for kid profile disabled")
	public void the_user_should_check_the_db_whether_insights_and_goals_for_kid_profile_disabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_kidsinsight();
	}

	// 109408//

	@Then("the user should select the checkbox to enable the recommendations for adult profile")
	public void the_user_should_select_the_checkbox_to_enable_the_recommendations_for_adult_profile() throws Throwable {
		admin.enable_adultrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for adult profile enabled")
	public void the_user_should_check_the_db_whether_recommendations_for_adult_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_adultrecomm();

	}

	@Then("the user should unselect the checkbox to disable the recommendations for adult profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_recommendations_for_adult_profile()
			throws Throwable {
		admin.disable_adultrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for adult profile disabled")
	public void the_user_should_check_the_db_whether_recommendations_for_adult_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_adultrecomm();
	}

	@Then("the user should select the checkbox to enable the recommendations for teen profile")
	public void the_user_should_select_the_checkbox_to_enable_the_recommendations_for_teen_profile() throws Throwable {
		admin.enable_teenrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for teen profile enabled")
	public void the_user_should_check_the_db_whether_recommendations_for_teen_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_teenrecomm();

	}

	@Then("the user should unselect the checkbox to disable the recommendations for teen profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_recommendations_for_teen_profile()
			throws Throwable {
		admin.disable_teenrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for teen profile disabled")
	public void the_user_should_check_the_db_whether_recommendations_for_teen_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_teenrecomm();

	}

	@Then("the user should select the checkbox to enable the recommendations for kid profile")
	public void the_user_should_select_the_checkbox_to_enable_the_recommendations_for_kid_profile() throws Throwable {
		admin.enable_kidrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for kid profile enabled")
	public void the_user_should_check_the_db_whether_recommendations_for_kid_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_kidrecomm();

	}

	@Then("the user should unselect the checkbox to disable the recommendations for kid profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_recommendations_for_kid_profile()
			throws Throwable {
		admin.disable_kidrecomm();
		admin.savelibrary();
	}

	@And("the user should check the db whether recommendations for kid profile disabled")
	public void the_user_should_check_the_db_whether_recommendations_for_kid_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_kidrecomm();

	}

	// 109409//

	@Then("the user should select the checkbox to enable the webpathexpress for adult profile")
	public void the_user_should_select_the_checkbox_to_enable_the_webpathexpress_for_adult_profile() throws Throwable {
		admin.enable_adultwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for adult profile enabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_adult_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_adultwebpathex();

	}

	@Then("the user should unselect the checkbox to disable the webpathexpress for adult profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_adult_profile()
			throws Throwable {
		admin.disable_adultwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for adult profile disabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_adult_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_adultwebpathex();

	}

	@Then("the user should select the checkbox to enable the webpathexpress for teen profile")
	public void the_user_should_select_the_checkbox_to_enable_the_webpathexpress_for_teen_profile() throws Throwable {
		admin.enable_teenwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for teen profile enabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_teen_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_teenwebpathex();

	}

	@Then("the user should unselect the checkbox to disable the webpathexpress for teen profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_teen_profile()
			throws Throwable {
		admin.disable_teenwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for teen profile disabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_teen_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_teenwebpathex();

	}

	@Then("the user should select the checkbox to enable the webpathexpress for kid profile")
	public void the_user_should_select_the_checkbox_to_enable_the_webpathexpress_for_kid_profile() throws Throwable {
		admin.enable_kidwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for kid profile enabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_kid_profile_enabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_kidwebpathex();

	}

	@Then("the user should unselect the checkbox to disable the webpathexpress for kid profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_kid_profile() throws Throwable {
		admin.disable_kidwebpathex();
		admin.savelibrary();
	}

	@And("the user should check the db whether webpathexpress for kid profile disabled")
	public void the_user_should_check_the_db_whether_webpathexpress_for_kid_profile_disabled() throws Throwable {
		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_kidwebpathex();

	}

	// 109410//

	@Then("the user should select the checkbox to enable the pressreader for adult profile")
	public void the_user_should_select_the_checkbox_to_enable_the_pressreader_for_adult_profile() throws Throwable {
		admin.enable_adultpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for adult profile enabled")
	public void the_user_should_check_the_db_whether_pressreader_for_adult_profile_enabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_adultpressreader();

	}

	@Then("the user should unselect the checkbox to disable the pressreader for adult profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_pressreader_for_adult_profile() throws Throwable {
		admin.disable_adultpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for adult profile disabled")
	public void the_user_should_check_the_db_whether_pressreader_for_adult_profile_disabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_adultpressreader();

	}

	@Then("the user should select the checkbox to enable the pressreader for teen profile")
	public void the_user_should_select_the_checkbox_to_enable_the_pressreader_for_teen_profile() throws Throwable {
		admin.enable_teenpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for teen profile enabled")
	public void the_user_should_check_the_db_whether_pressreader_for_teen_profile_enabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_teenpressreader();

	}

	@Then("the user should unselect the checkbox to disable the pressreader for teen profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_pressreader_for_teen_profile() throws Throwable {
		admin.disable_teenpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for teen profile disabled")
	public void the_user_should_check_the_db_whether_pressreader_for_teen_profile_disabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_teenpressreader();

	}

	@Then("the user should select the checkbox to enable the pressreader for kid profile")
	public void the_user_should_select_the_checkbox_to_enable_the_pressreader_for_kid_profile() throws Throwable {
		admin.enable_kidpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for kid profile enabled")
	public void the_user_should_check_the_db_whether_pressreader_for_kid_profile_enabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.enable_kidpressreader();

	}

	@Then("the user should unselect the checkbox to disable the pressreader for kid profile")
	public void the_user_should_unselect_the_checkbox_to_disable_the_pressreader_for_kid_profile() throws Throwable {
		admin.disable_kidpressreader();
		admin.savelibrary();
	}

	@And("the user should check the db whether pressreader for kid profile disabled")
	public void the_user_should_check_the_db_whether_pressreader_for_kid_profile_disabled() throws Throwable {

		/*
		 * List<Map<String, String>> testData = reader
		 * .getData(System.getProperty("user.dir") +
		 * "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		 * admin.app_launch(testData.get(5).get("loginType")); admin.admin_relogin();
		 * admin.library_settings();
		 */

		admin.libraryback_navigation();
		admin.library_search();
		admin.disable_kidpressreader();

	}

//133623

	@Given("admin is on home page and user click on {string} cta option from library header")
	public void admin_is_on_home_page_and_user_click_on_cta_option_from_library_header(String string) {
		admin.click_library_administration();
	}

	@Given("user should be able to view the announcements navigation in Library actions screen for library admin portal")
	public void user_should_be_able_to_view_the_announcements_navigation_in_library_actions_screen_for_library_admin_portal() {
		admin.click_edit_cta_announcement();
	}

	@Given("library should have published announcement")
	public void library_should_have_published_announcement() {
		Assert.assertEquals(admin.getView_published_announcement().isDisplayed(), true);
	}

	@When("user should be able to view and click the unpublish cta")
	public void user_should_be_able_to_view_and_click_the_unpublish_cta() {
		admin.click_unpublish_cta();
	}

	@Then("user should be able to view confirmation prompt to unpublish announcement")
	public void user_should_be_able_to_view_confirmation_prompt_to_unpublish_announcement() {
		Assert.assertEquals(admin.getUnpublish_dialogbox().isDisplayed(), true);
	}

	@Then("user should be able to confirm and unpublish the announcement")
	public void user_should_be_able_to_confirm_and_unpublish_the_announcement() {
		admin.click_okCta();
	}

	@Then("teen user should not be able to view the announcement section if unpublished by the admin")
	public void teen_user_should_not_be_able_to_view_the_announcement_section_if_unpublished_by_the_admin() {
		Assert.assertEquals(isElementPresent(admin.getView_library_announcement()), false);
	}

	@Then("adult user should not be able to view the announcement section if unpublished by the admin")
	public void adult_user_should_not_be_able_to_view_the_announcement_section_if_unpublished_by_the_admin() {
		Assert.assertEquals(isElementPresent(admin.getView_library_announcement()), false);
	}

	@Then("kid user should not be able to view the announcement section if unpublished by the admin")
	public void kid_user_should_not_be_able_to_view_the_announcement_section_if_unpublished_by_the_admin() {
		Assert.assertEquals(isElementPresent(admin.getView_library_announcement()), false);
	}

	@When("user lands on library screen")
	public void user_lands_on_library_screen() {
		Assert.assertEquals(admin.getAdvanced_search().isDisplayed(), true);
	}
//133624

	@When("user lands on announcement screen")
	public void user_lands_on_announcement_screen() {
		Assert.assertEquals(admin.getAnnouncement_screen().isDisplayed(), true);
	}

	@Then("user should be able to view preview of published announcement in the published announcement section")
	public void user_should_be_able_to_view_preview_of_published_announcement_in_the_published_announcement_section() {
		admin.click_preview_cta();
	}

	@Then("user shoud not be able to view announcement section in library admin portal")
	public void user_shoud_not_be_able_to_view_announcement_section_in_library_admin_portal() {
		Assert.assertEquals(isElementPresent(admin.getView_library_announcement()), false);
	}
//133622

	@Then("teen user should be able to view the updated announcemet published by the admin for teen user")
	public void teen_user_should_be_able_to_view_the_updated_announcemet_published_by_the_admin_for_teen_user() {
		Assert.assertEquals(admin.getView_library_announcement().isDisplayed(), true);
	}

	@Then("Adult user should be able to view the updated announcemet published by the admin for teen profile")
	public void adult_user_should_be_able_to_view_the_updated_announcemet_published_by_the_admin_for_teen_profile() {
		Assert.assertEquals(admin.getView_library_announcement().isDisplayed(), true);
	}

	@Then("kid user should be able to view the updated announcemet published by the admin for teen profile")
	public void kid_user_should_be_able_to_view_the_updated_announcemet_published_by_the_admin_for_teen_profile() {
		Assert.assertEquals(admin.getView_library_announcement().isDisplayed(), true);
	}

	@Then("adult user should not be able to view the announcement section if library has kidszone and axis {int} subscription")
	public void adult_user_should_not_be_able_to_view_the_announcement_section_if_library_has_kidszone_and_axis_subscription(
			Integer int1) {
		Assert.assertEquals(isElementPresent(admin.getView_library_announcement()), false);
	}

	@Then("kid user should be able to view the updated announcemet published by the admin for kid user")
	public void kid_user_should_be_able_to_view_the_updated_announcemet_published_by_the_admin_for_kid_user() {
		Assert.assertEquals(admin.getView_library_announcement().isDisplayed(), true);
	}

	@Given("user click on preview cta")
	public void user_click_on_preview_cta() {
		admin.click_preview_cta();
	}

	@Given("publish cta should enable when admin has input valid fields and preview is generated for the unpublished announcement")
	public void publish_cta_should_enable_when_admin_has_input_valid_fields_and_preview_is_generated_for_the_unpublished_announcement() {
		Assert.assertEquals(admin.getBtn_publish().isEnabled(), true);
	}

	@When("user should be able to view and click the publish cta")
	public void user_should_be_able_to_view_and_click_the_publish_cta() {
		admin.click_publish_cta();
	}

	@Then("user should be able to view confirmation prompt to publish announements if other announcements is currently published")
	public void user_should_be_able_to_view_confirmation_prompt_to_publish_announements_if_other_announcements_is_currently_published() {
		Assert.assertEquals(admin.getUnpublish_dialogbox().isDisplayed(), true);
	}

	@Then("user should be able to confirm and publish the new announcement")
	public void user_should_be_able_to_confirm_and_publish_the_new_announcement() {
		admin.click_okCta();
	}

	@Then("system should publish the current announcement on publish and save the announcement details on publishing")
	public void system_should_publish_the_current_announcement_on_publish_and_save_the_announcement_details_on_publishing() {
		Logger.log("system published the current announcement on publish and save the announcement details on publishing");
	}

	@Then("user should be able to view confirmation prompt to publish announements if no announcements is currently published")
	public void user_should_be_able_to_view_confirmation_prompt_to_publish_announements_if_no_announcements_is_currently_published() {
		Logger.log("user able to view confirmation prompt to publish announements if no announcements is published");
	}
	

	
	/****************************************REL 1.3.3 
	 * @throws IOException 
	 * @throws InvalidFormatException *****************************************************/
	
	@When("user navigate to home page and click on library management page and click program from top menu")
	public void user_navigate_to_home_page_and_click_on_library_management_page_and_click_program_from_top_menu() throws InvalidFormatException, IOException {
	   admin.library_search();
	   programs.click_programsCTA();
	}

	@Then("user should be able to view programs section and click create program option")
	public void user_should_be_able_to_view_programs_section_and_click_create_program_option() {
	  programs.click_createProgramCTA();
	}

	@Then("user should be able to view right side modal popup with all necessary fields")
	public void user_should_be_able_to_view_right_side_modal_popup_with_all_necessary_fields() {
	   Assert.assertTrue(programs. getCreateProgram_tab().isDisplayed());
	}

	@Then("user should be able to view Add Titles cta for all program types except milestone program which is optional field")
	public void user_should_be_able_to_view_add_titles_cta_for_all_program_types_except_milestone_program_which_is_optional_field() {
	   programs.select_ProgramTypeDropdwn();
	   programs.click_addTitle();
	   visibilityWait(programs.getSalesdemoLib_input_actualsearchResults());
	   ClickOnWebElement(programs.getSalesdemoLib_input_actualsearchResults());
	   SendKeysOnWebElement(programs.getSalesdemoLib_input_actualsearchResults(), "the");
	   jsClick(programs.searchicon);
	   visibilityWait(programs.addTitles.get(1));
	   javascriptScroll(programs.addTitles.get(1));	 
	 for (int i = 1; i <=3 ; i++) {
		 jsClick(programs.addTitles.get(i)) ;		
	}
		 
	
	
	
	  
	   
	}

	
	@Then("user should be able to view start date and end date which is mandatory field and remainder which is optional field")
	public void user_should_be_able_to_view_start_date_and_end_date_which_is_mandatory_field_and_remainder_which_is_optional_field() {
		programs.program_startDate();
		programs.click_endDate();
	}

	@Then("user should be able to view remainder which is optional field")
	public void user_should_be_able_to_view_remainder_which_is_optional_field() {
	  System.out.println("Reminder which is optional field");
	}

	@Then("user should be able to view goal objective which is mandatory field with maximum limit of {int} characters")
	public void user_should_be_able_to_view_goal_objective_which_is_mandatory_field_with_maximum_limit_of_characters(Integer int1) {
	   javascriptScroll(programs.Goal_programs);
	   SendKeysOnWebElement(programs.Goal_programs, "Testing purpose");
	   waitFor(2000);
	}

	@Then("user from library admin should be able to view PROFILE TYPE \\(SELECT AT LEAST ONE)")
	public void user_from_library_admin_should_be_able_to_view_profile_type_select_at_least_one() {
		visibilityWait(programs.program_profileType);
	  Assert.assertTrue(programs.program_profileType.isDisplayed());
	  programs.click_profileTypeAll();
	}

	@Then("user should be able to view save draft and publish cta")
	public void user_should_be_able_to_view_save_draft_and_publish_cta() {
	  Assert.assertTrue(programs.SaveDraft_cta.isDisplayed());
	  Assert.assertTrue(programs.Publish_cta.isDisplayed());
	}

	@Given("user click library edit settings and navigate to library admin page and click program from top menu")
	public void user_click_library_edit_settings_and_navigate_to_library_admin_page_and_click_program_from_top_menu() {
	   
	}

	@Then("user should be able to view program name which is mandatory field with maximum limit of {int} characters and program description which is optional")
	public void user_should_be_able_to_view_program_name_which_is_mandatory_field_with_maximum_limit_of_characters_and_program_description_which_is_optional(Integer int1) {
	   
	}

	@Then("user from BT admin should be able to view PROFILE TYPE CHECK \\(SELECT AT LEAST ONE)")
	public void user_from_bt_admin_should_be_able_to_view_profile_type_check_select_at_least_one() {
	   
	}
	
	@Then("user should be able to view {string} which is mandatory field with maximum limit of {int} characters")
	public void user_should_be_able_to_view_which_is_mandatory_field_with_maximum_limit_of_characters(String programname, Integer int1) {
	   programs.enter_programName(programname);
	
	}
	@Then("user should be able to view program {string} which is optional")
	public void user_should_be_able_to_view_program_which_is_optional(String description) {
	  javascriptScroll(programs.description);
	  SendKeysOnWebElement(programs.description, description);
	}

	@Then("user should be able to view {string} of titles to complete field to titles to be added in the program")
	public void user_should_be_able_to_view_of_titles_to_complete_field_to_titles_to_be_added_in_the_program(String string) {
	  
	}
	
	@Given("user navigates to home page and click program from top menu")
	public void user_navigates_to_home_page_and_click_program_from_top_menu() {
		 programs.click_programsCTA();
	}
	
}