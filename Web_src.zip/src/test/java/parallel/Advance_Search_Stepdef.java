package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Advance_Search;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Myprograms;
import pom.kidszone.Profilecreation;
import pom.kidszone.TitleListScreen;

public class Advance_Search_Stepdef extends CommonAction {

	Advance_Search search = new Advance_Search(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	TitleListScreen titleList = new TitleListScreen(DriverManager.getDriver());
	Myprograms myprogram = new Myprograms(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());

	// 150811

	@When("user types a keyword in the search bar")
	public void user_types_a_keyword_in_the_search_bar() {
		search.enter_text_in_Advance_Search_();
	}

	@When("click on search icon on the search bar to perform the search")
	public void click_on_search_icon_on_the_search_bar_to_perform_the_search() {
		search.click_searchIcon();
	}

	@Then("user should be able to view the sub-title indicating total number of results for search keyword")
	public void user_should_be_able_to_view_the_sub_title_indicating_total_number_of_results_for_search_keyword() {
		Assert.assertTrue(isElementPresent(search.getResults_for_search()));
	}

	@Then("user should be able to view following categories results based on the keyword searched in a carousel format in below priority")
	public void user_should_be_able_to_view_following_categories_results_based_on_the_keyword_searched_in_a_carousel_format_in_below_priority() {
		search.validate_results_in_carousel_format();
	}

	@Then("user should be able to view eBooks and eAudio and video and vBooks and comics and activity resources and web resources")
	public void user_should_be_able_to_view_e_books_and_e_audio_and_video_and_v_books_and_comics_and_activity_resources_and_web_resources() {
		Assert.assertTrue(isElementPresent(search.getValidate_eBooks_eAudio_Video()));
//		Assert.assertTrue(isElementPresent(search.getValidate_Activity_resources()));
		Assert.assertTrue(isElementPresent(search.getValidate_Web_resources()));
	}

	@Then("user should be able to view the number of results for each category in parenthesis")
	public void user_should_be_able_to_view_the_number_of_results_for_each_category_in_parenthesis() {
		search.validate_results_for_each_parathesis();
	}

	@Then("user should be able to view number format if less than {int} should be number format any number more than {int} will be in “1k+” “2k+” format")
	public void user_should_be_able_to_view_number_format_if_less_than_should_be_number_format_any_number_more_than_will_be_in_1k_2k_format(
			Integer int1, Integer int2) {
		Logger.log("Availability less than 999 are displayed as number");
	}

	@Then("user should be able to view page breadcrumbs")
	public void user_should_be_able_to_view_page_breadcrumbs() {
		Assert.assertTrue(isElementPresent(search.getPage_Breadcrumb()));
	}

	@Then("user should be able to view left panel with categories and refiners")
	public void user_should_be_able_to_view_left_panel_with_categories_and_refiners() {
		Assert.assertTrue(isElementPresent(search.getCategory_in_left_panel()));
		Assert.assertTrue(isElementPresent(search.getRefiners_in_left_panel()));
	}

	@Then("user should be able to view {string} highlighted by default on left panel after search has been initiated")
	public void user_should_be_able_to_view_highlighted_by_default_on_left_panel_after_search_has_been_initiated(
			String string) {
		Assert.assertTrue(isElementPresent(search.getAll_option_in_left_panel()));
	}

	@Then("user should be able to view {string} text under Refine in left panel")
	public void user_should_be_able_to_view_text_under_refine_in_left_panel(String string) {
		Assert.assertTrue(isElementPresent(search.getChoose_category_in_left_panel()));
	}

	@Then("user should be able to view {string} cta as a link to expand on all results for each category")
	public void user_should_be_able_to_view_cta_as_a_link_to_expand_on_all_results_for_each_category(String string) {
		search.validate_seeAllCta();
	}

	@Then("user should be able to view a chevron on the category carousel indicating scroll")
	public void user_should_be_able_to_view_a_chevron_on_the_category_carousel_indicating_scroll() {
		search.validate_results_in_carousel_format();
	}

	@Then("user should be able to view card details as title cover image and format icon and title name and author name")
	public void user_should_be_able_to_view_card_details_as_title_cover_image_and_format_icon_and_title_name_and_author_name() {
		search.validate_TitleImage();
		search.validate_FormatIcon();
		search.validate_AuthorName_And_title();
	}

	@Then("user should be able to view primary and secondary ctas based on the type of content")
	public void user_should_be_able_to_view_primary_and_secondary_ctas_based_on_the_type_of_content() {
		search.validate_primaryCta();
	}

	// 150813

	@When("user selects the advanced search option under the search bar")
	public void user_selects_the_advanced_search_option_under_the_search_bar() {
		search.click_advanceSearch();
	}

	@Then("user should be able to view search bar within the advanced search modal")
	public void user_should_be_able_to_view_search_bar_within_the_advanced_search_modal() {
		Assert.assertTrue(isElementPresent(search.getSearchBar_in_advancesearch()));
	}

	@Then("user should be able to refine their search using advanced search options under the category type and collection and availability and format and attributes")
	public void user_should_be_able_to_refine_their_search_using_advanced_search_options_under_the_category_type_and_collection_and_availability_and_format_and_attributes() {
		Assert.assertTrue(isElementPresent(search.getTypeOption_in_advanceSearch()));
		Assert.assertTrue(isElementPresent(search.getCollections_in_advanceSearch()));
		Assert.assertTrue(isElementPresent(search.getAvailability_in_advanceSearch()));
		Assert.assertTrue(isElementPresent(search.getFormat_in_advance_Search()));
		Assert.assertTrue(isElementPresent(search.getAttributes_in_advance_search()));

	}

	@Then("user should be able to select only one option within type and collection category")
	public void user_should_be_able_to_select_only_one_option_within_type_and_collection_category() {
		search.select_options_in_type();
		search.select_options_in_collections();
	}

	@When("user should be able to multi- select within availability and format and attributes refiners")
	public void user_should_be_able_to_multi_select_within_availability_and_format_and_attributes_refiners() {
		search.select_options_in_Availability();
		search.select_options_in_Format();
		search.select_options_in_Attributes();
	}

	@When("user should be able to view cta's 'Clear' to clear all selections")
	public void user_should_be_able_to_view_cta_s_clear_to_clear_all_selections() {
		Assert.assertTrue(isElementPresent(search.getClearAll_cta()));
	}

	@When("user should be able to click on clear cta")
	public void user_should_be_able_to_click_on_clear_cta() {
		search.click_clearAll();
	}

	@When("system should unselect the selected options and keyword should retains")
	public void system_should_unselect_the_selected_options_and_keyword_should_retains() {
		Logger.log("selected options are unselected");
	}

	@When("user should be able to view {string} to close the advanced search modal at any time")
	public void user_should_be_able_to_view_to_close_the_advanced_search_modal_at_any_time(String string) {
		search.click_close_Icon_in_advanceSearch();
	}

	@When("user should be able to open the advance search modal and able to view entered keyword and selected options")
	public void user_should_be_able_to_open_the_advance_search_modal_and_able_to_view_entered_keyword_and_selected_options() {
		search.click_advanceSearch();
		Logger.log("user able to view entered keyword and selected options");
	}

	// 150814

	@Given("user is on search result screen and click on {string} category in refine panel")
	public void user_is_on_search_result_screen_and_click_on_category_in_refine_panel(String string) {
		search.click_eBook_from_refiners();
	}

	@When("user is able to view ebooks in listing screen")
	public void user_is_able_to_view_ebooks_in_listing_screen() {
		Logger.log("view ebooks in listing screen");
	}

	@Then("user should be able to view expanded results for the ebooks category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_ebooks_category_in_a_list_view() {
		Logger.log("able to view expanded results for ebooks");
	}

	@Then("user should be able to view category pills for ebooks sub category")
	public void user_should_be_able_to_view_category_pills_for_ebooks_sub_category() {
		Assert.assertTrue(isElementPresent(search.geteBooks_pill()));
	}

	@Then("user should be able to view the search results for the titles from general collection and always available collection")
	public void user_should_be_able_to_view_the_search_results_for_the_titles_from_general_collection_and_always_available_collection() {
		Logger.log("search results are based on general collections");
	}

	@Then("user should be able to view the search results for the titles from general collection as always available collection")
	public void user_should_be_able_to_view_the_search_results_for_the_titles_from_general_collection_as_always_available_collection() {
		search.click_alwaysAvailable_in_collections();
	}

	@Then("user should be able to view the sort order for the results based on popularity")
	public void user_should_be_able_to_view_the_sort_order_for_the_results_based_on_popularity() {
		search.click_sort_option_in_refiner();
	}

	@Then("system should be able to displayed all ebooks at first category")
	public void system_should_be_able_to_displayed_all_ebooks_at_first_category() {
		Logger.log("ebooks are displayed as first category");
	}

	@Then("user should be able to view the {int} results lazy load as user scrolls down")
	public void user_should_be_able_to_view_the_results_lazy_load_as_user_scrolls_down(Integer int1) {
		Logger.log("lazy load cannot be automated");
	}

	@When("user is able to view audiobook in listing screen")
	public void user_is_able_to_view_audiobook_in_listing_screen() {
		Logger.log("audiobooks in listing screen");
	}

	@Then("user should be able to view expanded results for the eAudio category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_e_audio_category_in_a_list_view() {
		Logger.log("able to view expanded results for audiobooks");
	}

	@Then("user should be able to view category pills for eAudio sub category")
	public void user_should_be_able_to_view_category_pills_for_e_audio_sub_category() {
		Logger.log("User able to view the category pills for eAudio sub category");
	}

	@Then("system should be able to displayed all audiobooks that next to ebook category")
	public void system_should_be_able_to_displayed_all_audiobooks_that_next_to_ebook_category() {
		Logger.log("cannot be automated");
	}

	// 155077

	@When("user taps on the {string} cta for a category")
	public void user_taps_on_the_cta_for_a_category(String string) {
		search.click_seeAll_cta();
	}

	@Then("user should be able to view expanded results for the category they selected")
	public void user_should_be_able_to_view_expanded_results_for_the_category_they_selected() {
		Logger.log("expanded results are viewed");
	}

	@Then("user should not be able to view the {string} cta if already selected")
	public void user_should_not_be_able_to_view_the_cta_if_already_selected(String string) {
		search.not_view_seeAll_cta();
	}

	// 155078

	@When("user taps on the category from the left panel under the {string} title")
	public void user_taps_on_the_category_from_the_left_panel_under_the_title(String string) {
		search.click_ActivityResource();
	}

	// 150815

	@Given("user is on search result screen")
	public void user_is_on_search_result_screen() {
		search.click_searchIcon();
	}

	@When("user is on activity resources list screen")
	public void user_is_on_activity_resources_list_screen() {
		search.click_ActivityResource();
	}

	@When("user is able to click on {string} cta for activity resource category")
	public void user_is_able_to_click_on_cta_for_activity_resource_category(String string) {
		search.click_SeeAllCTA();
	}

	@Then("user should be able to view expanded results for the activity resources category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_activity_resources_category_in_a_list_view() {
		Assert.assertTrue(isElementPresent(search.getCategory_in_left_panel()));
	}

	@Then("user should be able to view the activity resource card title")
	public void user_should_be_able_to_view_the_activity_resource_card_title() {
		Assert.assertEquals(isElementPresent(search.getActivityResource_cardTitle()), true);
	}

	@Then("user should be able to view the sort order for the results based on relevance")
	public void user_should_be_able_to_view_the_sort_order_for_the_results_based_on_relevance() {
		Assert.assertTrue(search.view_sort());
		Logger.log("user is able to view sort order");
	}

	@Then("user should be able to view the results lazy load as user scrolls down")
	public void user_should_be_able_to_view_the_results_lazy_load_as_user_scrolls_down() {
		Logger.log("currently lazy load not yet implemented");
	}

	@Then("user should be able to view activity resources as a category only if library has enabled the flag for its patrons")
	public void user_should_be_able_to_view_activity_resources_as_a_category_only_if_library_has_enabled_the_flag_for_its_patrons() {
		Logger.log("Activity resources should be enabled in admin portal");
	}

	@Given("user is in my library page")
	public void user_is_in_my_library_page() {
		Assert.assertTrue(isElementPresent(titleList.getNav_libraryScreen()));
	}

	@When("user initiates the search")
	public void user_initiates_the_search() {
		search.enter_text_in_Advance_Search_();
		search.click_searchIcon();
	}

	@Then("user will land on search result page")
	public void user_will_land_on_search_result_page() {
		Assert.assertTrue(isElementPresent(search.getPage_Breadcrumb()));
	}

	@Then("user expands the activity reasource category")
	public void user_expands_the_activity_reasource_category() {
		Assert.assertTrue(isElementPresent(search.getCategory_in_left_panel()));
	}

	@Then("system should auto filter the search results based on teen profile")
	public void system_should_auto_filter_the_search_results_based_on_teen_profile() {
		Assert.assertTrue(isElementPresent(search.getCategory_section()));
	}

	@Then("system should auto filter the search results based on kid profile")
	public void system_should_auto_filter_the_search_results_based_on_kid_profile() {
		Assert.assertTrue(isElementPresent(search.getCategory_section()));
	}
//155078

	@Then("user should be able to view expanded results for the category they selected dynamically populate")
	public void user_should_be_able_to_view_expanded_results_for_the_category_they_selected_dynamically_populate() {
		Logger.log("expanded results are viewed");
		Assert.assertTrue(search.view_sort());

	}

	@Then("user should be able to view the selected category highlighted on left panel")
	public void user_should_be_able_to_view_the_selected_category_highlighted_on_left_panel() {
		Logger.log("selected category highlighted on left panel");
		Assert.assertTrue(isElementPresent(search.getTxt_WebResources()));
	}

	@Then("user should be able to toggle between all other categories to see the respective expanded results")
	public void user_should_be_able_to_toggle_between_all_other_categories_to_see_the_respective_expanded_results() {
		search.click_web_resources();
		search.click_activity_resources();
		// search.SelectAll_categories();
	}

	// 155080

	@When("user able to view {string} selected as default in refine left panel and user selects a category from left hand panel")
	public void user_able_to_view_selected_as_default_in_refine_left_panel_and_user_selects_a_category_from_left_hand_panel(
			String string) {
		Assert.assertTrue(isElementPresent(search.getTxt_all()));
	}

	@Then("user should be able to view only those refiner drawers based on the category selected")
	public void user_should_be_able_to_view_only_those_refiner_drawers_based_on_the_category_selected() {
		Assert.assertTrue(isElementPresent(search.getTxt_Refine()));
	}

	@Then("user should be able to view the sub- categories under each main category and refiner")
	public void user_should_be_able_to_view_the_sub_categories_under_each_main_category_and_refiner() {
		Assert.assertTrue(isElementPresent(search.getTxt_subtitles()));
	}

	@Then("user should be able to select the category {string} and")
	public void user_should_be_able_to_select_the_category_and(String string) {
		search.select_EbooksEAudio();
	}

	@Then("user should be able to view the following refiner {string}")
	public void user_should_be_able_to_view_the_following_refiner(String string) {
		search.view_subRefinerBeforeSelectEbooks();
		Logger.log("user should be able to view the following refiner options");

	}

	@Then("user should be able to make only one selection within one refiner drawer")
	public void user_should_be_able_to_make_only_one_selection_within_one_refiner_drawer() {
		search.onlyone_selectioninRefiner();
	}

	@Then("user should be able to view the previous drawer automatically close when they open another drawer and make a selection")
	public void user_should_be_able_to_view_the_previous_drawer_automatically_close_when_they_open_another_drawer_and_make_a_selection() {
		Logger.log("cannot automate previous drawer automatically close when the open another drawer");
	}

	@Then("user should be able to view refined results dynamically populate as and when they make selections on the refine section")
	public void user_should_be_able_to_view_refined_results_dynamically_populate_as_and_when_they_make_selections_on_the_refine_section() {
		Assert.assertTrue(search.view_sort());
		Logger.log("user able to view refined results dynamically populate");
	}

	@Then("user should be able to clear all refiners when they select another category from the left panel under static header")
	public void user_should_be_able_to_clear_all_refiners_when_they_select_another_category_from_the_left_panel_under_static_header() {
//		search.click_clearAll();
	}

	// 155082

	@Then("user should be able to view newspapers & magazines and articles")
	public void user_should_be_able_to_view_newspapers_magazines_and_articles() {
		Logger.log("Newspapers & Magazines carousel will be shown once enabled from Third party");
	}

	@Given("recommendation is enabled for library")
	public void recommendation_is_enabled_for_library() {
		Logger.log("recommendation is enabled for library admin portal ");
	}

	@Given("user landing on home page")
	public void user_landing_on_home_page() {
		Assert.assertTrue(isElementPresent(search.getLanding_homepage()));
	}

	@Then("user should be able to view the text {string} in addition to {string}")
	public void user_should_be_able_to_view_the_text_in_addition_to(String string, String string2) {
		Logger.log("User verified the UI manually");
	}

	@Then("user should be able to view  the cta {string} for only those libraries that enabled the {string} flag and will be redirected to {string} page where they can search and perform necessary action")
	public void user_should_be_able_to_view_the_cta_for_only_those_libraries_that_enabled_the_flag_and_will_be_redirected_to_page_where_they_can_search_and_perform_necessary_action(
			String string, String string2, String string3) {
		Logger.log("Flag will be shown once after the settings enabled from Library");
	}

	@When("user searches in search bar")
	public void user_searches_in_search_bar() {
		search.enterkeyword_Advance_Search_();
	}

	@When("user enter the keyword has no results across all categories and click on search icon")
	public void user_enter_the_keyword_has_no_results_across_all_categories_and_click_on_search_icon() {
		search.click_searchIcon();
	}

	@Then("user should be able to view page with {int} search results")
	public void user_should_be_able_to_view_page_with_search_results(Integer int1) {
		Logger.log("Flag will be shown once after the settings enabled from Library");
	}

	@Then("user should be able to view log in pop up when user selects checkout and read now and request to purchase ctas")
	public void user_should_be_able_to_view_log_in_pop_up_when_user_selects_checkout_and_read_now_and_request_to_purchase_ctas() {
		Assert.assertTrue(isElementPresent(search.getCheckoutCTA_advanceSearch()));
		Logger.log("user is able to view checkout or read now CTAs in advance search screen");
	}

//155085

	@When("user is on edit profile screen for adult profile")
	public void user_is_on_edit_profile_screen_for_adult_profile() {
		myprogram.click_avatar();

	}

	@Then("user should be able to view option to change the screen to high contrast view")
	public void user_should_be_able_to_view_option_to_change_the_screen_to_high_contrast_view() {
		profile.editAdultProfile();
		profile.select_AdultProfile();
	}

	@Then("user should be able to enabled the high contrast view")
	public void user_should_be_able_to_enabled_the_high_contrast_view() {
		search.enable_highContrast();
	}

	@Then("user should be able to view high contrast view")
	public void user_should_be_able_to_view_high_contrast_view() {
		Assert.assertTrue(search.view_highContrast());
	}

	@Then("user should be able to disabled the high contrast view")
	public void user_should_be_able_to_disabled_the_high_contrast_view() {
		Logger.log("user already disabled the high contrast view");
		Assert.assertEquals(isElementPresent(search.checkbox_highContrast), false);
		// search.disable_highContrast();
	}

	@Then("user should be able to view profile based teen theme for adult user")
	public void user_should_be_able_to_view_profile_based_teen_theme_for_adult_user() {
		Logger.log("cannot automate theme based scenerios and UI will be verified manually");
	}

	// 150817

	@Given("flag has been enabled in the admin")
	public void flag_has_been_enabled_in_the_admin() {
		Logger.log("Flag will be enabled from admin");
	}

	@Given("user is on search result screen and click on see all for web reasource category")
	public void user_is_on_search_result_screen_and_click_on_see_all_for_web_reasource_category() {
		
	}

	@When("user is on web resources list screen")
	public void user_is_on_web_resources_list_screen() {

	}

	@Then("user should be able to view expanded results for the web Resources category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_web_resources_category_in_a_list_view() {

	}

	@Then("user should be able to view the web resource card title and weblink")
	public void user_should_be_able_to_view_the_web_resource_card_title_and_weblink() {

	}

	@Then("user should be able to view description and subjects")
	public void user_should_be_able_to_view_description_and_subjects() {

	}

	@Then("user should be language and interest level and a display image")
	public void user_should_be_language_and_interest_level_and_a_display_image() {

	}

	@Then("user should be able to view web resources results through web path express")
	public void user_should_be_able_to_view_web_resources_results_through_web_path_express() {

	}

}
