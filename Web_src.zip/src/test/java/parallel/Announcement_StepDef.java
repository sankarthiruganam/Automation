package parallel;

import java.util.List;
import java.util.Map;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AdminPrograms;
import pom.kidszone.Announcement_Admin;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary_Guest;

public class Announcement_StepDef extends CommonAction {

	ExcelReader reader = new ExcelReader();
	Announcement_Admin admin = new Announcement_Admin(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	AdminPrograms adminPrograms = new AdminPrograms(DriverManager.getDriver());
	MyLibrary_Guest library_Guest = new MyLibrary_Guest(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("admin is on home page and user should navigate to library list by tapping on library management")
	public void admin_is_on_home_page_and_user_should_navigate_to_library_list_by_tapping_on_library_management() {
		admin.libraryMgmtClick();
	}

	@Given("user search and select the {string} from library management-library list page")
	public void user_search_and_select_the_from_library_management_library_list_page(String libraryName) {
		admin.searchLibrary(libraryName);
	}

	@Given("user should navigate to library management-library settings page by clicking on edit icon")
	public void user_should_navigate_to_library_management_library_settings_page_by_clicking_on_edit_icon() {
		admin.clickEditIcon();
		Assert.assertTrue(admin.getLibraryPage().isDisplayed());
	}

	@When("user should be able to view and click on publish button with url {string}")
	public void user_should_be_able_to_view_and_click_on_publish_button_with_url(String url) {
		admin.publishCase(url);
	}

	@Then("user should be able to publish the announcements section")
	public void user_should_be_able_to_publish_the_announcements_section() {
		Assert.assertTrue(admin.getPublishedSection().isDisplayed());
		Logger.log("User able to publish the announcements section");
	}

	@Then("user should be able to publish only when admin has input valid headline and title and description")
	public void user_should_be_able_to_publish_only_when_admin_has_input_valid_headline_and_title_and_description() {
		Logger.log("User able to publish only when admin has input valid headline and title and description");
	}

	@Given("User launch the LM admin kidszone newyorl url")
	public void user_launch_the_lm_admin_kidszone_newyorl_url() throws Exception {
		List<Map<String, String>> testData = reader
				.getData(System.getProperty("user.dir") + "/src/test/resources/Data/Webdata.xlsx", "Testdata");
		login.Login_LMprefixWithoutPin();
	}

	@Given("user should be able to click the announcements navigation in home page")
	public void user_should_be_able_to_click_the_announcements_navigation_in_home_page() {
		admin.clickAnnouncementCTA();
	}

	@Given("user should be navigated to announcements screen with url {string}")
	public void user_should_be_navigated_to_announcements_screen_with_url(String url) {
		Assert.assertTrue(admin.getAnnounceMentPage().isDisplayed());	
		admin.unPublishCase(url);
	}

	@When("user should be able to view and click on unpublish button")
	public void user_should_be_able_to_view_and_click_on_unpublish_button() {
		admin.clickUnPublish();
	}

	@Then("user should be able to unpublish the announcements section")
	public void user_should_be_able_to_unpublish_the_announcements_section() {
		Assert.assertFalse(isElementPresent(admin.getPublishedSection()));
		Logger.log("User able to Unpublish the announcements section");
	}
	
	@When("user should be able to view the announcement published by the admin")
	public void user_should_be_able_to_view_the_announcement_published_by_the_admin() {
		Assert.assertTrue(library_Guest.getAnnouncementSection().isDisplayed());
	}

	@Then("user should not view the announcements section on my library screen when unpublished")
	public void user_should_not_view_the_announcements_section_on_my_library_screen_when_unpublished() {
		Assert.assertFalse(isElementPresent(admin.getPublishedSection()));
		Logger.log("user not able to view the announcements section on my library screen when unpublished");
	}

	@Then("user should be able to view the announcements navigation in Library actions screen for baker and taylor admin portal")
	public void user_should_be_able_to_view_the_announcements_navigation_in_library_actions_screen_for_baker_and_taylor_admin_portal() {
		Assert.assertTrue(admin.getLibraryAnnouncement().isDisplayed());
	}

	@Then("user should logout the application by clicking on log off option")
	public void user_should_logout_the_application_by_clicking_on_log_off_option() {
		admin.clickLogOff();
	}

	@Given("User click on {string} cta option from Library Header")
	public void user_click_on_cta_option_from_Library_Header(String string) {
		admin.clickSubMenu();
		Assert.assertTrue(admin.getLibraryAdministration().isDisplayed());
	}

	@Given("User should be able to view the announcements navigation in Library adminstration screen for baker and taylor admin portal")
	public void user_should_be_able_to_view_the_announcements_navigation_in_library_adminstration_screen_for_baker_and_taylor_admin_portal() {
		Assert.assertTrue(admin.getAnnouncementNaviLibrary().isDisplayed());
		admin.clickAnnounceLibraryCTA();
	}

	@Given("User click on {string} cta option from library header")
	public void user_click_on_cta_option_from_library_header(String string) {
		admin.clickSubMenu();
	}
}
