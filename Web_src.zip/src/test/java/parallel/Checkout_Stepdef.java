package parallel;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.MyshelfvideosVbooks;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Checkout_Stepdef extends CommonAction {

	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	MyshelfvideosVbooks myshelfpage = new MyshelfvideosVbooks(DriverManager.getDriver());
	
	private int pills_CheckoutCount;
	private int mystuffpills_getWishListCount;

	@And("user should be able to view quick navigation ctas as a carousel on top with checkouts highlighted and number of titles checked out")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_checkouts_highlighted_and_number_of_titles_checked_out()
			throws Throwable {
		WaitForWebElement(checkout.btn_CtaCheckouts);
		Assert.assertTrue(checkout.btn_CtaCheckouts.isDisplayed());
	}

	@When("User navigate to library screen and checkout the titles")
	public void user_navigate_to_library_screen_and_checkout_the_titles() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_library();
		checkout.click_checkout();
	}

	@Then("user should be able to view checkouts screen with theme rendered based on library subscription and adult profile type")
	public void user_should_be_able_to_view_checkouts_screen_with_theme_rendered_based_on_library_subscription_and_adult_profile_type()
			throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_CheckoutLandingPage().isDisplayed());
	}

	@Then("user should be able to view checkouts screen with theme rendered based on library subscription and teen profile type")
	public void user_should_be_able_to_view_checkouts_screen_with_theme_rendered_based_on_library_subscription_and_teen_profile_type()
			throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_CheckoutLandingPage().isDisplayed());
	}

	@And("user should be able to view titles checked by that user only")
	public void user_should_be_able_to_view_titles_checked_by_that_user_only() throws Throwable {
		Logger.log("cannot be automated");

	}

	@And("user should be able to view titles sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_checked_out_first_by_default()
			throws Throwable {
		Assert.assertTrue(checkout.getBtn_SortIcon().isDisplayed());
	}

	@And("user should be able to view filter and sort option for the titles")
	public void user_should_be_able_to_view_filter_and_sort_option_for_the_titles() throws Throwable {
		Assert.assertTrue(checkout.getBtn_FilterIcon().isDisplayed());
	}

	@And("user should be able to view option to view titles as list view and grid view")
	public void user_should_be_able_to_view_option_to_view_titles_as_list_view_and_grid_view() throws Throwable {
		Assert.assertTrue(checkout.getBtn_GridView().isDisplayed());
	}

	@And("user should be able to view titles listed as list view by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_by_default() throws Throwable {
		Logger.log("By default list view is displayed");
	}

	@And("user should be able to click on list and grid view icon to switch between list view and grid view")
	public void user_should_be_able_to_click_on_list_and_grid_view_icon_to_switch_between_list_view_and_grid_view()
			throws Throwable {
		Assert.assertTrue(checkout.getBtn_GridView().isDisplayed());
	}

	@And("user should be able to click on back cta to navigate back to last screen")
	public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() throws Throwable {
		Logger.log("Already user is in Checkouts screen");
	}

	@And("user should be able to view bread crumb navigation for the screen")
	public void user_should_be_able_to_view_bread_crumb_navigation_for_the_screen() throws Throwable {
		Assert.assertTrue(checkout.getLink_BreadCrumb().isDisplayed());
	}

	@And("user should be able to updated my stuff screen for user with adult profile type and kidszone subscription")
	public void user_should_be_able_to_updated_my_stuff_screen_for_user_with_adult_profile_type_and_kidszone_subscription()
			throws Throwable {
		Logger.log("Adult profile with kidszone subscription is updated in my stuff screen");
	}

	@And("user should not be able to updated my stuff screen for user with adult profile type and axis360 subscription")
	public void user_should_not_be_able_to_updated_my_stuff_screen_for_user_with_adult_profile_type_and_axis360_subscription()
			throws Throwable {
		Logger.log("Adult profile with kidszone subscription is updated in my stuff screen");
	}

	@And("user should not be able to updated my stuff screen for user with adult profile type and kidszone and axis360 subscription")
	public void user_should_not_be_able_to_updated_my_stuff_screen_for_user_with_adult_profile_type_and_kidszone_and_axis360_subscription()
			throws Throwable {
		Logger.log("Adult profile with kidszone subscription and axis 360 is updated in my stuff screen");
	}

	@Then("user should be able to view checkouts screen with theme rendered based on library subscription and kid profile type")
	public void user_should_be_able_to_view_checkouts_screen_with_theme_rendered_based_on_libray_subscription_and_profile_type()
			throws Throwable {
		Logger.log("Adult profile with kidszone subscription and axis 360 is updated in my stuff screen");
	}

	@And("no title is checked out")
	public void no_title_is_checked_out() throws Throwable {
		Logger.log("Title is not checkout out");
	}

	@And("user should be able to view no title checked out screen")
	public void user_should_be_able_to_view_no_title_checked_out_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getCheckouts_ListViewDisplay()), false);

	}

	@And("user should be able to view titles listed as list view by default and sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_and_sorted_by_latest_title_checked_out_first_by_default()
			throws Throwable {
//		Assert.assertTrue(checkout.getCheckouts_ListViewDisplay().isDisplayed());
	}

	@And("user should be able to view each title listed as a card")
	public void user_should_be_able_to_view_each_title_listed_as_a_card() throws Throwable {
		Assert.assertTrue(checkout.getTitle_Card_Display().isDisplayed());
	}

	@And("user should be able view title cover image and title name and author name on card")
	public void user_should_be_able_view_title_cover_image_and_title_name_and_author_name_on_card() throws Throwable {
		// DriverManager.getDriver().navigate().refresh();
//		WaitForWebElement(checkout.getTitle_Name());
//		Assert.assertTrue(checkout.getTitle_Name().isDisplayed());
		visibilityWait(checkout.title_Card_Display);
		Assert.assertTrue(checkout.title_Card_Display.isDisplayed());
	}

	@And("user should be able view title due date")
	public void user_should_be_able_view_title_due_date() throws Throwable {
		Assert.assertTrue(isElementPresent(checkout.getTitle_Duration()));
	}

	@And("user should be able to view number of days remaining for title return and checkout expiry")
	public void user_should_be_able_to_view_number_of_days_remaining_for_title_return_and_checkout_expiry()
			throws Throwable {
		Assert.assertTrue(checkout.getTitle_Duration().isDisplayed());
	}

	@And("user should be able to view number of hours remaining for title return and cechout expiry when only one day is left")
	public void user_should_be_able_to_view_number_of_hours_remaining_for_title_return_and_cechout_expiry_when_only_one_day_is_left()
			throws Throwable {
		Logger.log("Only available if the title is started to read");
	}

	@And("user should be able to view primary action for the title as a button")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button() throws Throwable {
		Assert.assertTrue(checkout.getBtn_title_group().isDisplayed());
	}

	@And("user should be able to view more options cta to view secondary actions available for the title")
	public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title()
			throws Throwable {
		Assert.assertTrue(checkout.getBtn_more_Option().isDisplayed());
	}

	@And("user should be able to click in more options cta and view secondary actions for the title")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title()
			throws Throwable {
		checkout.click_moreOption();
		Assert.assertTrue(checkout.getBtn_Return().isDisplayed());

	}

	@And("user should be able to view reading progress of the title as a progress bar and percentage on the card")
	public void user_should_be_able_to_view_reading_progress_of_the_title_as_a_progress_bar_and_percentage_on_the_card()
			throws Throwable {
		Logger.log("Reading progress bar cannot be validated");
	}

	@And("user should be able to view download progress during downloading title and with cancel cta to cancel download and pause cta to pause download")
	public void user_should_be_able_to_view_download_progress_during_downloading_title_and_with_cancel_cta_to_cancel_download_and_pause_cta_to_pause_download()
			throws Throwable {
		Logger.log("Currently download and pause cta feature is not testable");
	}

	@And("user should be able to click on card other than primary and secondary cta area to navigate to title details screen")
	public void user_should_be_able_to_click_on_card_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen()
			throws Throwable {
		checkout.click_TitleCard();
	}

	@Given("user is on checkout screen")
	public void user_is_on_checkout_screen() throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_CheckoutLandingPage().isDisplayed());
	}

	@When("user should be able to click on sort to view sort options")
	public void user_should_be_able_to_click_on_sort_to_view_sort_options() throws Throwable {
		checkout.click_Sort();
	}

	@And("user should view the titles sorted with latest checked out title first by default")
	public void user_should_view_the_titles_sorted_with_latest_checked_out_title_first_by_default() throws Throwable {
		Logger.log("Latest checkout title is checked out by default");
	}

	@Then("user click on 'Due date' in sort option")
	public void user_click_on_due_date_in_sort_option() throws Throwable {
		checkout.click_DueDate();
	}

	@And("user should view the titles sorted with due date")
	public void user_should_view_the_titles_sorted_with_due_date() throws Throwable {
		Logger.log("Titles are sorted out with due date");
	}

	@And("user should view the titles sorted with a to z")
	public void user_should_view_the_titles_sorted_with_a_to_z() throws Throwable {
		Logger.log("Titles are sorted out with A to Z");
	}

	@When("user click on menu and select profile")
	public void user_click_on_menu_and_select_profile() throws Throwable {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
	}

	@And("user select the teen profile")
	public void user_select_the_teen_profile() throws Throwable {
		checkout.select_TeenProfile();
	}

	@And("user on my shelf screen as default landing screen")
	public void user_on_my_shelf_screen_as_default_landing_screen() throws Throwable {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
	}

	@And("user click on checkout cta in quick navigation")
	public void user_click_on_checkout_cta_in_quick_navigation() throws Throwable {
		myshelf.click_CheckoutCta();
	}

	@And("user click on 'A to Z' in options")
	public void user_click_on_a_to_z_in_options() throws Throwable {
		checkout.click_AtoZ();
	}

//	@And("user select the kid profile")
//	public void user_select_the_kid_profile() throws Throwable {
//		checkout.select_KidProfile();
//	}

	@And("user should be able to view sort options as 'latest checkout' 'due date' and 'A to Z'")
	public void user_should_be_able_to_view_sort_options_as_latest_checkout_due_date_and_a_to_z() throws Throwable {
		Assert.assertTrue(checkout.getSort_Latest_Checkout().isDisplayed());
		Assert.assertTrue(checkout.getSort_AtoZ().isDisplayed());
		Assert.assertTrue(checkout.getSort_Due_Date().isDisplayed());
	}

	@Given("user on library screen if my shelf not set as default percentage")
	public void user_on_library_screen_if_my_shelf_not_set_as_default_percentage() throws Throwable {
		Logger.log("Library screen is set as default landing page");
	}

	@When("user click on menu and click checkout")
	public void user_click_on_menu_and_click_checkout() throws Throwable {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@And("user should not view sort options")
	public void user_should_not_view_sort_options() throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getBtn_SortIcon()), false);
	}

	@When("user clicks on checkout from menu oldUI")
	public void user_clicks_on_checkout_from_menu_old_ui() {
		checkout.clickCheckOutOldUi();
	}

	@Then("user should be able to view checkouts screen with theme rendered based on library subscription and adult profile type oldUI")
	public void user_should_be_able_to_view_checkouts_screen_with_theme_rendered_based_on_library_subscription_and_adult_profile_type_old_ui() {
		Logger.log("UI cannot be automated");
	}

	@Then("user should be able to view quick navigation ctas as a carousel on top with checkouts highlighted and number of titles checked out oldUI")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_checkouts_highlighted_and_number_of_titles_checked_out_old_ui() {
		Logger.log("UI cannot be automated");
	}

	@When("user click on menu and click checkout old UI")
	public void user_click_on_menu_and_click_checkout_old_ui() {
		profile.click_MenuOnly();
		checkout.clickCheckOutOldUi();
	}

	@Then("user click on grid icon")
	public void user_click_on_grid_icon() {
		checkout.clickGrid();
	}

	@Then("user should be able to view titles listed as grid view by default and sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_listed_as_grid_view_by_default_and_sorted_by_latest_title_checked_out_first_by_default() {
		Logger.log("Titles are listed as grid view br default");
	}

	@Then("user should be able to view primary action for the title as a button Grid")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button_grid() {
		Assert.assertTrue(checkout.getPrimaryCta_readNow().isDisplayed());
	}

	@Then("user should be able to click on card in Grid View other than primary and secondary cta area to navigate to title details screen")
	public void user_should_be_able_to_click_on_card_in_grid_view_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() {
		checkout.clickTitleInCheckoutScreen();
	}

	@Then("user should be able to view primary action and secondary action for the title as a button in history screen")
	public void user_should_be_able_to_view_primary_action_and_secondary_action_for_the_title_as_a_button_in_history_screen() {
		Assert.assertTrue(checkout.primaryCta_Removetitle.isDisplayed());
		checkout.click_moreOption();
		Assert.assertTrue(checkout.secondaryCta_Checkout.isDisplayed());
		Assert.assertTrue(checkout.secondaryCta_AddtoWishlist.isDisplayed());

	}

//139224

	@Given("history is disabled in user preferences")
	public void history_is_disabled_in_user_preferences() {
		Logger.log("history is disabled in user preferences");
	}

	@Then("user should not be able to view History CTA in the top quick navigation CTA carousel")
	public void user_should_not_be_able_to_view_history_cta_in_the_top_quick_navigation_cta_carousel() {
		Assert.assertEquals(isElementPresent(checkout.getHistory_cta()), false);
	}

	@Then("user should not be able to view History CTA in the My Stuff page")
	public void user_should_not_be_able_to_view_history_cta_in_the_my_stuff_page() {
		Assert.assertEquals(isElementPresent(checkout.getHistory_cta_in_axis360Only()), false);
	}

	@When("user clicks on checkouts navigates to checkouts screen")
	public void user_clicks_on_checkouts_navigates_to_checkouts_screen() {
		checkout.click_Checkouts();
	}

	@When("user clicks  on holds navigates to holds screen")
	public void user_clicks_on_holds_navigates_to_holds_screen() {
		checkout.click_HoldsCta();
	}

	@When("user clicks on recommendations navigates to recommendations screen")
	public void user_clicks_on_recommendations_navigates_to_recommendations_screen() {
		checkout.click_RecommendationsCta();
	}

	@When("user clicks on wishlist navigates to wishlist screen")
	public void user_clicks_on_wishlist_navigates_to_wishlist_screen() {
		checkout.click_WishListCta();
	}

	@When("user lands on My stuff page")
	public void user_lands_on_my_stuff_page() {
		Assert.assertEquals(checkout.getMyStuff_validation().isDisplayed(), true);
	}

//139225

	@Then("user should be able to view quick navigation cta for Checkouts screen with title count for each of the section")
	public void user_should_be_able_to_view_quick_navigation_cta_for_checkouts_screen_with_title_count_for_each_of_the_section() {
		Logger.log(
				"user able to view quick navigation cta for Checkouts screen with title count for each of the section");
	}

	@Then("navigates back to the My shelf page")
	public void navigates_back_to_the_my_shelf_page() {
		checkout.click_homeCta();
	}

	@Then("user should be able to view quick navigation cta for Holds screen with title count for each of the section")
	public void user_should_be_able_to_view_quick_navigation_cta_for_holds_screen_with_title_count_for_each_of_the_section() {
		Logger.log("user able to view quick navigation cta for Holds screen with title count for each of the section");
	}

	@Then("user should be able to view quick navigation cta for Wishlist screen with title count for each of the section")
	public void user_should_be_able_to_view_quick_navigation_cta_for_wishlist_screen_with_title_count_for_each_of_the_section() {
		Logger.log(
				"user able to view quick navigation cta for Wishlist screen with title count for each of the section");
	}

	@Then("user should be able to view quick navigation cta for Checkout History screen with title count for each of the section")
	public void user_should_be_able_to_view_quick_navigation_cta_for_checkout_history_screen_with_title_count_for_each_of_the_section() {
		Logger.log(
				"user able to view quick navigation cta for Checkout History screen with title count for each of the section");
	}

//139229

	@Then("user should be able to view the search icon")
	public void user_should_be_able_to_view_the_search_icon() {
		Assert.assertTrue(checkout.search_Icon());
	}

	@Then("user should be able to click on search icon to view the search bar in the screen")
	public void user_should_be_able_to_click_on_search_icon_to_view_the_search_bar_in_the_screen() {
		checkout.click_SearchIcon();
	}

	@Then("user should be able input characters and initiate the search for the titles from that screen")
	public void user_should_be_able_input_characters_and_initiate_the_search_for_the_titles_from_that_screen() {
		checkout.sendTextFromSearchBar();
	}

	@Then("user should be able to view the results based on search string from the titles checked out")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_checked_out() {
		Logger.log("user able to view the results based on search string from the titles checked out");
	}

	@When("user should be able to view the results based on search string from the titles on hold")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_on_hold() {
		Logger.log("user able to view the results based on search string from the titles on hold");
	}

	@When("user should be able to view the results based on search string from the titles in Wishlist")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_in_wishlist() {
		Logger.log("user able to view the results based on search string from the titles in Wishlist");
	}

	@When("user clicks on history cta navigates to history screen")
	public void user_clicks_on_history_cta_navigates_to_history_screen() {
		checkout.click_HistoryCta();
	}

	@When("user should be able to view the results based on search string from the titles in history")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_in_history() {
		Logger.log("user able to view the results based on search string from the titles in history");
	}

	@Given("no title in checkout and holds and wishlist and purchase request and history and download screen")
	public void no_title_in_checkout_and_holds_and_wishlist_and_purchase_request_and_history_and_download_screen() {
		Logger.log("no title in checkout and holds and wishlist and purchase request and history and download screen");
	}

	@Then("user should not able to view the search icon")
	public void user_should_not_able_to_view_the_search_icon() {
		Assert.assertEquals(isElementPresent(checkout.getBtn_search_icon()), false);
	}

	@Then("user should be able to view the results based on search string from the titles recommended")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_recommended() {
		Logger.log("user able to view the results based on search string from the titles recommended");
	}

	@Then("user should be able to view primary and secondary actions for audiobooks in checkout histrory screen")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audiobooks_in_checkout_histrory_screen() {
		checkout.click_moreOption();
		checkout.audioBookSecondaryCtaHistoryScreen();
	}

	@Then("user should be able to view primary and secondary actions for ebooks in checkout histrory screen")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_in_checkout_histrory_screen() {
		checkout.click_moreOption();
		checkout.eBookSecondaryCtaHistoryScreen();
	}

//139228

	@When("clicks on Checkout button on titles")
	public void clicks_on_checkout_button_on_titles() {
		checkout.click_checkout();
	}

	@Then("user should be able to view success message on completion of the action")
	public void user_should_be_able_to_view_success_message_on_completion_of_the_action() {
		checkout.success_Message();
	}

	@Given("clicks on Remove Hold on titles")
	public void clicks_on_remove_hold_on_titles() {
		checkout.removeHoldForSuccessMsg();
	}

	@Given("clicks on Suspend Hold on titles")
	public void clicks_on_suspend_hold_on_titles() {
		checkout.suspendHoldForSuccessMsg();
	}

	@Given("clicks on Activate Hold on titles")
	public void clicks_on_activate_hold_on_titles() {
		checkout.UnsuspendHold();
	}

	@Given("clicks on Add to Wishlist on titles")
	public void clicks_on_add_to_wishlist_on_titles() {
		checkout.addToWishlistForSuccessMsg();
	}

	@Given("clicks on Remove from Wishlist on titles")
	public void clicks_on_remove_from_wishlist_on_titles() {
		checkout.removeWishlistForSuccessMsg();
	}

	@When("clicks on Cancel Recommendation on titles")
	public void clicks_on_cancel_recommendation_on_titles() {
		checkout.cancelRecommendationForSuccessMsg();
	}

	@Then("user clicks on Return title button on titles")
	public void user_clicks_on_return_title_button_on_titles() {
		checkout.click_more_option_And_return();
	}
//139229

	@Then("user should be able to view error message on failure to complete the action")
	public void user_should_be_able_to_view_error_message_on_failure_to_complete_the_action() {
		checkout.failure_Message();
	}

	@When("clicks on Remove on title")
	public void clicks_on_remove_on_title() {
		checkout.click_removeTitle();
	}

	@When("clicks on Return title button on titles")
	public void clicks_on_return_title_button_on_titles() {
		checkout.returnForSuccessMsg();
	}

	@When("clicks on Renew title button on titles")
	public void clicks_on_renew_title_button_on_titles() {
		checkout.renewForSuccessMsg();
	}

//139226

	@Then("user should be able to click on filter to view the filter options {string}")
	public void user_should_be_able_to_click_on_filter_to_view_the_filter_options(String string) {
		checkout.click_Filter();
		checkout.filter_Options();

	}

	@Then("user should be able to view titles filtered based on options selected")
	public void user_should_be_able_to_view_titles_filtered_based_on_options_selected() {
		checkout.click_eBook_in_filter();
	}

	@Then("user should be able to select attributes across multiple filter options")
	public void user_should_be_able_to_select_attributes_across_multiple_filter_options() {
		checkout.click_Sort();
		checkout.click_AtoZ();
	}

//139227

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks() {
		Assert.assertEquals(checkout.getValidate_placeHold_primaryCta().isDisplayed(), true);
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getCancel_recommendation().isDisplayed(), true);
	}

	@Then("user should be able to click on primary button {string} and put title on hold")
	public void user_should_be_able_to_click_on_primary_button_and_put_title_on_hold(String string) {
		checkout.click_primaryCta_placeHold();
	}

	@Then("user should be able to click on {string} and cancel the recommendation for the title")
	public void user_should_be_able_to_click_on_and_cancel_the_recommendation_for_the_title(String string) {
		checkout.click_cancel__recommendation();
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks in Wishlist screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_in_wishlist_screen() {
		/*
		 * Assert.assertEquals(checkout.getValidate_checkout_primary().isDisplayed(),
		 * true); checkout.click_moreOption();
		 * Assert.assertEquals(checkout.getClick_remove_Wishlist_secondaryCta().
		 * isDisplayed(), true);
		 */
	}

//	@Then("user should be able to click on primary button {string} title available in the wishlist screen")
//	public void user_should_be_able_to_click_on_primary_button_title_available_in_the_wishlist_screen(String string) {
//		checkout.click_primaryCta_checkout();
//	}

	@Then("user should be able to click on {string} and remove the title from the Wishlist")
	public void user_should_be_able_to_click_on_and_remove_the_title_from_the_wishlist(String string) {
		checkout.click_secondaryCta_removewishlist();
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for place hold in Wishlist screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_place_hold_in_wishlist_screen() {
		Assert.assertEquals(checkout.getValidate_placeHold_primaryCta().isDisplayed(), true);
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getClick_remove_Wishlist_secondaryCta().isDisplayed(), true);
	}

	@Then("user should be able to click on	 primary button {string} and resume the suspended hold for the title")
	public void user_should_be_able_to_click_on_primary_button_and_resume_the_suspended_hold_for_the_title(
			String string) {
		checkout.click_primaryCTa_removeHold();
	}

	@Then("user should be able to click on {string} and suspend the hold temporarily for the title put on hold")
	public void user_should_be_able_to_click_on_and_suspend_the_hold_temporarily_for_the_title_put_on_hold(
			String string) {
		checkout.click_SuspendHold();
	}

	@Then("user should be able to click on button {string} and remove the title from hold")
	public void user_should_be_able_to_click_on_button_and_resume_the_suspended_hold_for_the_title(String string) {
		checkout.click_primaryCTa_removeHold();
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for place hold in Recommendations screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_place_hold_in_recommendations_screen() {
		Assert.assertEquals(checkout.getValidate_placeHold_primaryCta().isDisplayed(), true);
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getCancel_recommendation().isDisplayed(), true);
	}

	@Then("user should be able to click on {string} and add the title to the Wishlist")
	public void user_should_be_able_to_click_on_and_add_the_title_to_the_wishlist(String string) {
		checkout.click_moreOption();
		checkout.secondaryCta_AddToWishListAndRemoveWishlist();
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for hold screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_hold_screen() {
		/*
		 * Assert.assertEquals(checkout.getClick_removeHold().isDisplayed(), true);
		 * checkout.click_moreOption();
		 * Assert.assertEquals(checkout.getClick_suspendHold().isDisplayed(), true);
		 * <<<<<<< HEAD Assert.assertEquals(checkout.getAddToWish().isDisplayed(),
		 * true); ======= Assert.assertEquals(checkout.getAddToWish().isDisplayed(),
		 * true)
		 */
		Logger.log("currently audio title not displayed");
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for checkout screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_checkout_screen()
			throws IOException, Exception {
		waitForDocumentToLoad();
		pagescrollDown();
		Assert.assertEquals(checkout.getPrimaryCta_readNow().isDisplayed(), true);
		checkout.click_moreOption();
		javascriptScroll(checkout.getReturn_option());
		Assert.assertEquals(checkout.getReturn_option().isDisplayed(), true);
		Assert.assertEquals(checkout.getRenew_option().isDisplayed(), true);
	}

	@Then("user should be able to click on primary button {string} and navigate to ereader online and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_ereader_online_and_navigate_back_to_checkout_screen(
			String string) {
		checkout.validate_ereader_screen();
	}

	@Then("user should be able to click on {string} and return the title and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_and_return_the_title_and_navigate_back_to_checkout_screen(
			String string) {
		checkout.click_moreOption();
	}

	@Then("user should be able to click on {string} and renew the ebook and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_and_renew_the_ebook_and_navigate_back_to_checkout_screen(
			String string) {
		Logger.log("renew option is displayed only few hours before due date hour ends");
	}

	@Then("user should be able to click on primary button {string} and navigate to audioplayer online and navigate back to checkout screen")
	public void user_should_be_able_to_click_on_primary_button_and_navigate_to_audioplayer_online_and_navigate_back_to_checkout_screen(
			String string) {
		checkout.validate_audiobook_screen();
	}

	@Given("title on Hold")
	public void title_on_hold() {
		Logger.log("title is on Hold");
	}

	@Given("hold Suspended")
	public void hold_suspended() {
		Logger.log("hold is Suspended");
	}

	@Then("user should be able to click on {string} and remove the title from the Wishlist in hold screen")
	public void user_should_be_able_to_click_on_and_remove_the_title_from_the_wishlist_in_hold_screen(String string) {
		checkout.click_moreOption();
		checkout.secondaryCta_AddToWishListAndRemoveWishlist();
	}

	@Then("user should be able to click on button {string} and resume the suspended hold for the title in hold screen")
	public void user_should_be_able_to_click_on_button_and_resume_the_suspended_hold_for_the_title_in_hold_screen(
			String string) {
		checkout.click_seconadryCta_removeHold();
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for holded titles in Recommendations screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_holded_titles_in_recommendations_screen() {
		Assert.assertEquals(checkout.getClick_removeHold().isDisplayed(), true);
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getClick_suspendHold().isDisplayed(), true);
		Assert.assertEquals(checkout.getCancel_recommendation().isDisplayed(), true);
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks for titles suspended in Recommendations screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_titles_suspended_in_recommendations_screen() {
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getSecondaryCta_removeHold().isDisplayed(), true);
		Assert.assertEquals(checkout.getCancel_recommendation().isDisplayed(), true);

	}

	@Then("user should be able to click on button {string} and resume the suspended hold for the title in recommendations Screen")
	public void user_should_be_able_to_click_on_button_and_resume_the_suspended_hold_for_the_title_in_recommendations_screen(
			String string) {
		checkout.click_primaryCTa_removeHold();

	}

	@Then("user should be able to click on primary button {string}")
	public void user_should_be_able_to_click_on_primary_button(String string) {
		checkout.click_removeTitle();
	}

	@Then("user should be able to view the pop up to confirm for the {string} action and remove the title from checkout history of the user")
	public void user_should_be_able_to_view_the_pop_up_to_confirm_for_the_action_and_remove_the_title_from_checkout_history_of_the_user(
			String string) {
		Logger.log(
				"user able to view the pop up to confirm the action and remove the title from checkout history of the user");
	}

	@Then("user should be able to click on {string} and navigate to ereader online")
	public void user_should_be_able_to_click_on_and_navigate_to_ereader_online(String string) {
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getPrimaryCta_readNow().isDisplayed(), true);
	}

	@Then("user should be able to click on {string}")
	public void user_should_be_able_to_click_on(String string) {
		checkout.click_moreOption();
		checkout.returnDropdown();
	}

	@Then("user should be able to click on {string} and navigate to audioplayer online and navigate back to checkout history screen")
	public void user_should_be_able_to_click_on_and_navigate_to_audioplayer_online_and_navigate_back_to_checkout_history_screen(
			String string) {
		Assert.assertEquals(checkout.getSecondaryCta_ListenNow().isDisplayed(), true);
	}

	@Then("user should be able to view and perform primary and secondary actions for audiobooks for checkout screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_audiobooks_for_checkout_screen() {
		Assert.assertEquals(checkout.getPrimaryCta_listenNow().isDisplayed(), true);
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getReturn_option().isDisplayed(), true);
	}

	@Then("user should be able to view and perform primary and secondary actions for ebooks and audiobooks in checkout histrory screen")
	public void user_should_be_able_to_view_and_perform_primary_and_secondary_actions_for_ebooks_and_audiobooks_in_checkout_histrory_screen() {
		Assert.assertEquals(checkout.getPrimaryCta_Removetitle().isDisplayed(), true);
		checkout.click_moreOption();
		checkout.eBookSecondaryCtaHistoryScreen();
	}

	@Then("user should be able to click on 'Renew'option")
	public void user_should_be_able_to_click_on_renew_option() {
		Logger.log("renew option is displayed");
	}

	@Then("user should be able to view primary and secondary actions for ebooks and audiobooks for hold screen")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_and_audiobooks_for_hold_screen() {
		checkout.click_moreOption();
		Assert.assertEquals(checkout.getSecondaryCta_removeHold().isDisplayed(), true);
		Assert.assertEquals(checkout.getAddToWish().isDisplayed(), true);
	}

	@When("user should navigates to tier3 screen and tap on checkout cta")
	public void user_should_navigates_to_tier3_screen_and_tap_on_checkout_cta() {
		checkout.clickCheckout_Tier3();
	}

	@When("verify eBook reader should be opened and close the reader")
	public void verify_e_book_reader_should_be_opened_and_close_the_reader() {
		checkout.validate_ereader_Tier3screen();
	}

	@When("user navigates to my shelf and lands on checkout screen")
	public void user_navigates_to_my_shelf_and_lands_on_checkout_screen() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@When("verify the title count in myshelf checkout")
	public void verify_the_title_count_in_myshelf_checkout() {
		checkout.verify_CheckoutpillsCount();
	}

	@When("user should be able to return the eBook title in mystuff screen")
	public void user_should_be_able_to_return_the_e_book_title_in_mystuff_screen() {
		int before_CheckoutCount = checkout.pills_CheckoutCount();
		System.out.println("before checkout count------"+before_CheckoutCount);
		javaScriptScrollToEnd();
		checkout.click_moreOption();
		checkout.click_ReturnCTA();
		checkout.Return_confirmCTA();
		int AfterReturn_checkoutCount = checkout.pills_CheckoutCount();
		System.out.println(" After checkout count------"+AfterReturn_checkoutCount);
		boolean b = true;
		if (before_CheckoutCount == AfterReturn_checkoutCount - 1) {
			b = true;
		} else {
			b = false;
		}
	}

	@When("verify eAudio reader should be opened and close the reader")
	public void verify_e_audio_reader_should_be_opened_and_close_the_reader() {
		checkout.validate_audiobook_screen_Tier3();
	}

	@When("user should be able to return tha eAudio title in mystuff screen")
	public void user_should_be_able_to_return_tha_e_audio_title_in_mystuff_screen() {
		int before_CheckoutCount = checkout.pills_CheckoutCount();
		System.out.println("before checkout count------"+before_CheckoutCount);
		javaScriptScrollToEnd();
		checkout.click_moreOption();
		checkout.click_ReturnCTA();
		checkout.Return_confirmCTA();
		int AfterReturn_checkoutCount = checkout.pills_CheckoutCount();
		System.out.println("After checkout count------"+before_CheckoutCount);
		boolean b = true;
		if (before_CheckoutCount == AfterReturn_checkoutCount - 1) {
			b = true;
		} else {
			b = false;
		}
	}

	@Then("user should be able to return tha vbook title in mystuff screen")
	public void user_should_be_able_to_return_tha_vbook_title_in_mystuff_screen() {
		int before_CheckoutCount = checkout.pills_CheckoutCount();
		System.out.println("before checkout count------"+before_CheckoutCount);
		javaScriptScrollToEnd();
		checkout.click_moreOption();
		checkout.click_ReturnCTA();
		checkout.Return_confirmCTA();
		int AfterReturn_checkoutCount = checkout.pills_CheckoutCount();
		System.out.println("After checkout count------"+before_CheckoutCount);
		boolean b = true;
		if (before_CheckoutCount == AfterReturn_checkoutCount - 1) {
			b = true;
		} else {
			b = false;
		}
	}

	@When("user should be able to return tha eBook title in title details screen")
	public void user_should_be_able_to_return_tha_e_book_title_in_title_details_screen() {
		checkout.Tier3_MoreoptionsDropdwn();
		checkout.clickReturnCTA_Tier3();
		checkout.Return_confirmCTA();
		visibilityWait(checkout.tier3Checkout);
		Assert.assertTrue(checkout.tier3Checkout.isDisplayed());

	}

	@When("user should be able to return tha eAudio title in title details screen")
	public void user_should_be_able_to_return_tha_e_audio_title_in_title_details_screen() {
		checkout.Tier3_MoreoptionsDropdwn();
		checkout.clickReturnCTA_Tier3();
		checkout.Return_confirmCTA();
	}

	@Given("user read the few pages of eBook from the reader and close the reader")
	public void user_read_the_few_pages_of_e_book_from_the_reader_and_close_the_reader() {
		checkout.EbookReader_ReadFewPagesFromTier3();

	}

	@Given("user verify the last readed page in EBook and close the reader")
	public void user_verify_the_last_readed_page_in_e_book_and_close_the_reader() {
		checkout.validate_LastReadedPagesFromMystuff_Ebook();

	}

	@Given("user read the few pages of eAudio from the reader and close the reader")
	public void user_read_the_few_pages_of_e_audio_from_the_reader_and_close_the_reader() {
		checkout.EAudio_ListenFewPagesFromTier3();
	}

	@Given("user verify the last readed page in EAudio and close the reader")
	public void user_verify_the_last_readed_page_in_e_audio_and_close_the_reader() {
		checkout.validate_LastListenedTimingFromMystuff_EAudio();
	}

	@Given("user select the eBook from search results screen and tap on wishlist cta")
	public void user_select_the_e_book_from_search_results_screen_and_tap_on_wishlist_cta() {
		
	}


	@When("user verify added titles in wishlist and tap on checkout cta")
	public void user_verify_added_titles_in_wishlist_and_tap_on_checkout_cta() {
		checkout.Add_Wishlist();
	}

	@When("user verify eBook reader is opened and close the reader")
	public void user_verify_e_book_reader_is_opened_and_close_the_reader() {
		checkout.validate_ereader_screen();
	}

	@When("user removes the titles from checkouts screen")
	public void user_removes_the_titles_from_checkouts_screen() {
		pills_CheckoutCount = checkout.pills_CheckoutCount();
		Logger.log("Checkout Count----"+pills_CheckoutCount);
		visibilityWait(checkout.getCheckoutCount());
		jsClick(checkout.getCheckoutCount());
		 checkout.click_moreOption();
		 checkout.clickReturnCTA_Tier3();
			checkout.Return_confirmCTA();
		
	}

	@When("user should not be able to view this title in the myshelf checkout and wishlist")
	public void user_should_not_be_able_to_view_this_title_in_the_myshelf_checkout_and_wishlist() {
		int CheckoutCount = checkout.pills_CheckoutCount();
		Logger.log("Checkout Count----"+CheckoutCount);
		Assert.assertEquals(CheckoutCount == pills_CheckoutCount, true);
		
	}
	
	@Given("user get the count of title in myshelf checkout and wishlist and holds")
	public void user_get_the_count_of_title_in_myshelf_checkout_and_wishlist_and_holds() {
	  pills_CheckoutCount = checkout.pills_CheckoutCount();
	  Logger.log("Checkout Count----"+pills_CheckoutCount);
	  int mystuffpills_getHoldCount = checkout.mystuffpills_getHoldCount();
	  Logger.log("Hold Count----"+mystuffpills_getHoldCount);
	  mystuffpills_getWishListCount = checkout.mystuffpills_getWishListCount();
	  Logger.log("Wishlist Count----"+mystuffpills_getWishListCount);
	}

	@Given("user navigates to myshelf checkout history")
	public void user_navigates_to_myshelf_checkout_history() {
		myshelfpage.Click_CheckoutHistory();
		visibilityWait(myshelfpage.Nav_mystuffScreen);
		Assert.assertTrue(myshelfpage.Nav_mystuffScreen.isDisplayed());
	}
	
	@Given("user verify the title count in myshelf checkout history")
	public void user_verify_the_title_count_in_myshelf_checkout_history() {
		int mystuffpills_getHistoryCount = checkout.mystuffpills_getHistoryCount();
		Assert.assertTrue(mystuffpills_getHistoryCount!=0);
	}

	@Given("user should add the any one title to wishlist")
	public void user_should_add_the_any_one_title_to_wishlist() {
		waitForDocumentToLoad();
		javaScriptScrollToEnd();
		checkout.click_moreOption();
		visibilityWait(checkout.secondaryCta_AddtoWishlist);
		jsClick(checkout.secondaryCta_AddtoWishlist);
		
	}

	@Given("user should checkout the anyone title in myshelf checkout history")
	public void user_should_checkout_the_anyone_title_in_myshelf_checkout_history() {
		javaScriptScrollToEnd();
		checkout.click_moreOption();
		checkout.checkout_FromCheckoutHisory();
		javaScriptScrollToEnd();
		checkout.click_moreOption();
	}

	@Given("user verify added titles myshelf wishlist and remove from wishlist")
	public void user_verify_added_titles_myshelf_wishlist_and_remove_from_wishlist() throws Exception {
		visibilityWait(checkout.WishListCount);
		jsClick(checkout.WishListCount);
		int getWishListCount = checkout.mystuffpills_getWishListCount();
		Assert.assertEquals(getWishListCount == mystuffpills_getWishListCount+1, true);
		pagescrollDown();
		try {
			checkout.click_moreOption();
			visibilityWait(checkout.WishListSecondaryCTA_Remove);
			jsClick(checkout.WishListSecondaryCTA_Remove);
		} catch (Exception e) {
			jsClick(checkout.WishListSecondaryCTA_Remove);checkout.click_moreOption();
			visibilityWait(checkout.WishListSecondaryCTA_Remove);
			jsClick(checkout.WishListSecondaryCTA_Remove);
			e.printStackTrace();
		}
		visibilityWait(checkout.WishListCount);
		int AfterRemoved_wishlistCount = checkout.mystuffpills_getWishListCount();
		Assert.assertEquals(AfterRemoved_wishlistCount == mystuffpills_getWishListCount, true);
		
	}

	@Given("user should be able to verify that added on myshelf checkout and Remove the title")
	public void user_should_be_able_to_verify_that_added_on_myshelf_checkout_and_remove_the_title() {
	   visibilityWait(checkout.getCheckoutCount());
	   jsClick(checkout.getCheckoutCount());
	   int getCheckoutCount = checkout.pills_CheckoutCount();
	   Assert.assertEquals(getCheckoutCount == pills_CheckoutCount+1, true);
	   javaScriptScrollToEnd();
	   checkout.click_moreOption();
	   checkout.returnDropdown();
	   int AfterRemoved_CheckoutCount = checkout.pills_CheckoutCount();
	   Assert.assertEquals(AfterRemoved_CheckoutCount == pills_CheckoutCount, true);
	}
	
	@Given("user tap on wishlist cta in tier3 page")
	public void user_tap_on_wishlist_cta_in_tier3_page() {
	    
	}


}
