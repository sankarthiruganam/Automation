package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.History;
import pom.kidszone.Holds;
import pom.kidszone.Recommendations;
import pom.kidszone.Wishlist;

public class History_StepDef {

	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	Holds hold = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	Recommendations recommend = new Recommendations(DriverManager.getDriver());
	History history = new History(DriverManager.getDriver());

	@When("user lands on history screen")
	public void user_lands_on_history_screen() {
		ham.click_HamburgerMenu();
		hold.myShelfClick();
		history.clickHistory();
	}

	@When("no title in history")
	public void no_title_in_history() {
		history.noHistoryCount();
	}

	@Then("user should be able to view history screen with theme rendered based on library subscription and adult profile type")
	public void user_should_be_able_to_view_history_screen_with_theme_rendered_based_on_library_subscription_and_adult_profile_type() {
		Logger.log("user able to view history screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to view no title history screen")
	public void user_should_be_able_to_view_no_title_history_screen() {
		Assert.assertTrue(history.getNoStuffText().isDisplayed());
	}

	@Then("user should be able to view history screen with theme rendered based on library subscription and teen profile type")
	public void user_should_be_able_to_view_history_screen_with_theme_rendered_based_on_library_subscription_and_teen_profile_type() {
		Logger.log("user able to view history screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to view history screen with theme rendered based on library subscription and kid profile type")
	public void user_should_be_able_to_view_history_screen_with_theme_rendered_based_on_library_subscription_and_kid_profile_type() {
		Logger.log("user able to view history screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to view quick navigation ctas as a carousel on top with history highlighted and number of titles in history")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_history_highlighted_and_number_of_titles_in_history() throws Exception {
		hold.holdClick();
		history.clickHistory();
	}

	@Then("user should be able to view checked out titles history for that user only")
	public void user_should_be_able_to_view_checked_out_titles_history_for_that_user_only() {
		Logger.log("user able to view checked out titles history for that user only");
	}

	@Then("user should be able to click on back cta to navigate Back to last screen")
	public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() {
		history.navigateBackCta();
		history.clickHistory();
	}
	
	@When("user has titles in the history")
	public void user_has_titles_in_the_history() {
		Assert.assertTrue(history.getHistoryTitles().isDisplayed());
	}

	@When("checkout history is enabled in the preferences")
	public void checkout_history_is_enabled_in_the_preferences() {
		Assert.assertTrue(history.getHistoryPage().isDisplayed());
	}
	
	@Then("user should be able view last checked out date for the title")
	public void user_should_be_able_view_last_checked_out_date_for_the_title() {
		Logger.log("user able to view last checked out date for the title");
	}
	
	@Then("user should be able to view sort options as latest checkout and due date and A-Z")
	public void user_should_be_able_to_view_sort_options_as_latest_checkout_and_due_date_and_a_z() {
		history.sortOptions();
	}
	
	@When("user switch to grid view for history screen")
	public void user_switch_to_grid_view_for_history_screen() {
		hold.clickGrid();
		hold.gridViewDisplayed();
	}

	@Then("user should be able to view titles listed as grid view and sorted by latest title checked out first by default")
	public void user_should_be_able_to_view_titles_listed_as_grid_view_and_sorted_by_latest_title_checked_out_first_by_default() {
		Logger.log("User able to view titles in Grid view and sorted by latest by default");
	}
	
	@Then("user should be able to click in more options cta and view Secondary Actions for the title")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title() {
		history.secCtaActions();
		Assert.assertTrue(history.getSecCta1().isDisplayed());
	}
	
	@When("user land on history screen")
	public void user_land_on_history_screen() {
		ham.click_HamburgerMenu();
		history.clickHistoryHamOldUi();
	}

	@Then("user should be able to view Quick navigation ctas as a carousel on top with history highlighted and number of titles in history")
	public void user_should_be_able_to_view_Quick_navigation_ctas_as_a_carousel_on_top_with_history_highlighted_and_number_of_titles_in_history() {
	history.quickCtaOldUi();
	}

	@Then("user should be able to click on Back Cta to navigate Back to last screen")
	public void user_should_be_able_to_click_on_Back_Cta_to_navigate_back_to_last_screen() {
	history.navigateBackCtaOldUi();
	}
}
