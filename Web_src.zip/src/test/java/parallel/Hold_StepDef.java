package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Profilecreation;
import pom.kidszone.TitleDetails;

public class Hold_StepDef extends CommonAction {

	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginpage = new Loginpageview(DriverManager.getDriver());
	Holds hold = new Holds(DriverManager.getDriver());
	Checkouts checkout= new Checkouts(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	TitleDetails details=new TitleDetails(DriverManager.getDriver());

	@Given("user launch the {string}")
	public void user_launch_the(String string) throws Throwable {
		login.Login_PrefixWithPin();
	}

	@Given("user click on login button after user enter Axisandkidszone subscription only {string} and {string}")
	public void user_click_on_login_button_after_user_enter_axisandkidszone_subscription_only_and(String id,
			String pass) {
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		hold.logInClick();
		hold.admin_login(id, pass);
	}

	@Given("user click on login button after user enter kidszone subscription only {string} and {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_only_and(String id, String pass) {
		profile.readInAppClose();
		hold.logInClick();
		hold.admin_login(id, pass);
	}

	// 139196

	@Given("user Logged in as adult user")
	public void user_logged_in_as_adult_user() {
		Logger.log("User is logged in as Adult User");
	}

	@When("user Lands on library page")
	public void user_lands_on_library_page() {
		Assert.assertTrue(hold.getLibraryPage().isDisplayed());
	}

	@Then("user Should not be able to view the {string} option in hamburger menu based on profile")
	public void user_should_not_be_able_to_view_the_option_in_hamburger_menu_based_on_profile(String string) {
		ham.click_HamburgerMenu();
		Assert.assertFalse(ham.notDisplayed_myshelfInaxisLib());
		Logger.log("user not able to view my shelf option");
	}

	@Given("user logged in as teen user")
	public void user_logged_in_as_teen_user() {
		Logger.log("User is logged in as Teen User");
	}

	@Given("user click on {string} option from Hamburger menu")
	public void user_click_on_option_from_hamburger_menu(String string) {
		ham.click_HamburgerMenu();
		hold.myShelfClick();
	}

	@Given("user navigates to {string} page")
	public void user_navigates_to_page(String string) {
		Assert.assertTrue(hold.getMyShelfTab().isDisplayed());
	}

	@Given("user click on {string}")
	public void user_click_on(String string) throws Exception {
		hold.holdClick();
	}

	@Given("No title is on hold")
	public void no_title_is_on_hold() {
		Logger.log("No titles shown for User");
	}

	@When("user lands on Holds screen")
	public void user_lands_on_holds_screen() {
		Assert.assertTrue(hold.getHoldPage().isDisplayed());
	}

	@Then("user should be able to view no title on hold screen {string}")
	public void user_should_be_able_to_view_no_title_on_hold_screen(String noStuffText) {
		Assert.assertTrue(hold.getNoStuffHold().isDisplayed());
//		Assert.assertTrue(hold.getNoStuffHold().getText().contains(noStuffText));
	}

	@Given("user logged in as kid user")
	public void user_logged_in_as_kid_user() {
		Logger.log("User is logged in as Kid User");
	}

	@Given("user Launch the {string}")
	public void user_Launch_the(String string) throws Throwable {
		login.Login_texas();
		
	}
	
	// 139197

	@Given("user has put titles on hold")
	public void user_has_put_titles_on_hold() {
		Assert.assertTrue(hold.getTitleInHold().isDisplayed());
	}

	@Then("user should be able to view titles listed as list view by default and sorted by latest title put on hold first by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_and_sorted_by_latest_title_put_on_hold_first_by_default() {
		Assert.assertTrue(hold.getTitleListView().isDisplayed());
	}

	@Then("user should be able view title cover image, title name and author name on card")
	public void user_should_be_able_view_title_cover_image_title_name_and_author_name_on_card() {
		Assert.assertTrue(hold.getCoverImage().isDisplayed());
		Assert.assertTrue(hold.getTitleName().isDisplayed());
		Assert.assertTrue(hold.getAuthorName().isDisplayed());
	}

	@Then("user should be able view hold position for the title")
	public void user_should_be_able_view_hold_position_for_the_title() {
		visibilityWait(hold.getHoldPosition());
		Assert.assertTrue(isElementPresent(hold.getHoldPosition()));
		javaScriptScrollToEnd();
	}

	@Then("user should be able to view tool tip icon and tool tip for the hold position")
	public void user_should_be_able_to_view_tool_tip_icon_and_tool_tip_for_the_hold_position() {
		Assert.assertTrue(hold.getToolTipIcon().isDisplayed());
	}

	@Then("user should be able to view Primary action for the title as a button")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button() {
		hold.primaryAction();
	}

	@Then("user should be able to view more options cta to view Secondary actions available for the title")
	public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title() {
		Assert.assertTrue(hold.getMoreOptions().isDisplayed());
	}

	@Then("user should be able to click in more options cta and view Secondary actions for the title")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title() {
		hold.secondaryAction();
	}

	@Then("user should be able to click on card other than Primary and Secondary cta area to navigate to title details screen")
	public void user_should_be_able_to_click_on_card_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() {
		hold.clickTitle();
		//hold.navigateBack();
	}
	
	@Then("user should be able to view primary action and secondary action for the hold title as a button")
	public void user_should_be_able_to_view_primary_action_and_secondary_action_for_the_hold_title_as_a_button() {
		//Assert.assertTrue(hold.primaryCta_RemoveHold.isDisplayed());
		checkout.click_moreOption();
		Assert.assertTrue(hold.secondaryCta_SuspendHold.isDisplayed());
		Assert.assertTrue(checkout.addToWish.isDisplayed());
	}

	// 139198

	@Then("user should be able to click on sort to view Sort options")
	public void user_should_be_able_to_click_on_sort_to_view_sort_options() {
		hold.clickSort();
	}

	@Then("user should be able to view titles sorted based on options selected")
	public void user_should_be_able_to_view_titles_sorted_based_on_options_selected() {
		Logger.log("User able to view the Sort options based on the selection");
	}

	@Then("user should be able to view sort options {string}")
	public void user_should_be_able_to_view_sort_options(String sortSubOptions) {
		hold.sortOptions();
	}

	@Then("user should view the titles sorted with latest title put on hold first by default {string}")
	public void user_should_view_the_titles_sorted_with_latest_title_put_on_hold_first_by_default(String string) {
		Logger.log("User able to view the titles sorted based on the options selected");
	}
	
	
	@Then("user should view format Icon of the eBook titles")
	public void user_should_view_format_icon_of_the_e_book_titles() {
	    Assert.assertTrue(details.getImg_ebookformaticon().isDisplayed());
	}

	@Then("user should view format Icon of the eAudio titles")
	public void user_should_view_format_icon_of_the_e_audio_titles() {
	    Assert.assertTrue(details.getImg_audioformaticon().isDisplayed());
	}

	// 139199

	@Given("user should be able to click on Grid view icon and titles are listed as grid view format")
	public void user_should_be_able_to_click_on_grid_view_icon_and_titles_are_listed_as_grid_view_format() {
		Logger.log("User able to view the Grid view format after clicked on Grid view Icon");
	}

	@When("user switch to grid view for holds screen")
	public void user_switch_to_grid_view_for_holds_screen() {
		hold.clickGrid();
	}

	@Then("user should be able to view titles listed as grid view and sorted by latest title put on hold first by default")
	public void user_should_be_able_to_view_titles_listed_as_grid_view_and_sorted_by_latest_title_put_on_hold_first_by_default() {
		Logger.log("User able to view the title list in Grid view by latest title put on hold by default");
	}

	@Then("user should be able to view each title listed as a tile")
	public void user_should_be_able_to_view_each_title_listed_as_a_tile() {
		Logger.log("User able to view each title listed as a title");
	}

	@Then("user should be able view title cover image with title format icon")
	public void user_should_be_able_view_title_cover_image_with_title_format_icon() {
		hold.titleGridDetails();
	}

	@Then("user should be able to click on title image other than primary and secondary cta area to navigate to title details screen")
	public void user_should_be_able_to_click_on_title_image_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() {
		hold.clickTitle();
		Assert.assertTrue(hold.getTitleList().isDisplayed());
	}

	// 139195

	@Given("user click on login button after User enter axis360 only {string}")
	public void user_click_on_login_button_after_user_enter_axis360_only(String id) {
//		hold.logInClick();
		loginpage.click_loginPage();
		hold.adult_login_Pop_Up(id);
	}

	@Then("user should be able to navigate to Holds screen")
	public void user_should_be_able_to_navigate_to_holds_screen() {
		Assert.assertTrue(hold.getHoldMenu().isDisplayed());
		Assert.assertTrue(hold.getHoldPage().isDisplayed());
	}

	@Then("user should be able to view quick navigation ctas as a carousel on top with Holds highlighted and number of titles on hold")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_holds_highlighted_and_number_of_titles_on_hold() {
		hold.holdsHighlight();
	}

	@Then("user should be able to view titles put on hold by that user only")
	public void user_should_be_able_to_view_titles_put_on_hold_by_that_user_only() {
		Assert.assertTrue(hold.getTitleInHold().isDisplayed());
		Logger.log("User able to view the titles which put on hold by the same user only");
	}

	@Then("user should be able to view titles sorted by latest title put on hold first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_put_on_hold_first_by_default() {
		Logger.log("User able to view the latest title put on hold");
	}

	@Then("user should be able to click on List view icon and titles are listed as list view format")
	public void user_should_be_able_to_click_on_list_view_icon_and_titles_are_listed_as_list_view_format() {
		hold.listView();
	}

	@Then("user should be able to view the bread crumb navigation for the screen")
	public void user_should_be_able_to_view_the_bread_crumb_navigation_for_the_screen() {
		hold.clickTitle();
		Assert.assertTrue(hold.getTitleList().isDisplayed());
		hold.navigateBack();
	}

	// 139203

	@Given("user should be redirected to the Home page")
	public void user_should_be_redirected_to_the_home_page() {
		ham.navigate_axislibrarylibraryPage();
	}

	@Given("user is clicking on profiles from hamburger menu")
	public void user_is_clicking_on_profiles_from_hamburger_menu() {
		hold.clickProfile();
	}

	@Given("Enter the parent pin {string}")
	public void enter_the_parent_pin(String pin) {
		profile.Enter_setPin(pin);
		hold.clickSubmit();
	}

	@Given("user is on Profile management page")
	public void user_is_on_profile_management_page() {
		Assert.assertTrue(hold.getProfileScreen().isDisplayed());
	}

	@Given("user click on Adult profile")
	public void user_click_on_adult_profile() {
		hold.clickAdultProfile();
	}

	@Given("user click on teen profile")
	public void user_click_on_teen_profile() {
		hold.clickTeenProfile();
	}

	@Then("user should be able to view the hold position for each title on the card")
	public void user_should_be_able_to_view_the_hold_position_for_each_title_on_the_card() {
		Assert.assertTrue(hold.getTitleInHold().isDisplayed());
		Assert.assertTrue(hold.getHoldPosition().isDisplayed());
	}

	@Then("user should be able to view tool tip icon for the hold position")
	public void user_should_be_able_to_view_tool_tip_icon_for_the_hold_position() {
		Assert.assertTrue(hold.getToolTipIcon().isDisplayed());
	}

	@Then("user should be able to click on tool tip icon to view the description")
	public void user_should_be_able_to_click_on_tool_tip_icon_to_view_the_description() {
		hold.clickToolTip();
	}

	@Then("user should be able to view the {string} alert popup message with Ok button")
	public void user_should_be_able_to_view_the_alert_popup_message_with_ok_button(String header) {
		Assert.assertTrue(isElementPresent(hold.getHoldsInfoOK()));
	}

	@Then("user should be able to view the {string} description {string}")
	public void user_should_be_able_to_view_the_description(String header, String description) {
		hold.holdsInfo(header,description);
	}

	@Then("user should be able to click on {string} button to close the popup")
	public void user_should_be_able_to_click_on_button_to_close_the_popup(String string) {
		hold.holdsInfoClose();
	}

	@Given("user click on kid profile")
	public void user_click_on_kid_profile() {
		hold.clickKidProfile();
	}

	@Given("user enters the prefix {string} and pin {string}")
	public void user_enters_the_prefix_and_pin(String id, String pass) {
		hold.logInClick();
		hold.admin_login(id, pass);
	}
	
	@Given("Add the title On Hold")
	public void add_the_title_on_hold() {
		hold.addTitleHold();
	}

}
