package parallel;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Login;

public class LibraryAdminpage_Stepdef {

	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("user launch the application url")
	public void user_launch_the_application_url() throws Exception {
		login.Login_texas();
	}

	@When("user enters the username {string} and password {string} shared by the client")
	public void user_enters_the_username_and_password_shared_by_the_client(String username, String password) {
		admin.admin_login(username, password);    
	}

	@When("user click on library in menu and select the library")
	public void user_click_on_library_in_menu_and_select_the_library() {
		admin.library_settings();
	}

	@Given("user is in library settings screen")
	public void user_is_in_library_settings_screen() throws InvalidFormatException, IOException {
	   //admin.txt_librarysettingpage.isDisplayed();
	   admin.library_search();
	}

	@Given("user should enable the kids zone subscription")
	public void user_should_enable_the_kids_zone_subscription() throws IOException, Exception {	
		admin.enable_kidszone();	
		}

	@Given("user should enabled kids profile for that library")
	public void user_should_enabled_kids_profile_for_that_library() {
		admin.verify_enable_kidprofile();
		admin.savelibrary_logoff();
	}

	@Given("user launch the demo admin application url")
	public void user_launch_the_demo_admin_application_url() throws Exception {
		login.login_BTAdmin();
	}

	@When("user entering {string} and {string} and click login cta")
	public void user_entering_and_and_click_login_cta(String username, String password) {
		 admin.login_salesdemo(username, password);
	}

	@Then("user click on settings cta in menu")
	public void user_click_on_settings_cta_in_menu() {
	   admin.click_settingmenu();
	}

	@Then("user click on library settings card")
	public void user_click_on_library_settings_card() {
		admin.click_settingcard();
	}

	@Then("user should see patron profile management section in the library settings screen")
	public void user_should_see_patron_profile_management_section_in_the_library_settings_screen() {
	    admin.verify_profileManagementscreen();
	}

	@Then("user should select the checkbox to enable the kids profile for the library")
	public void user_should_select_the_checkbox_to_enable_the_kids_profile_for_the_library() {
	    admin.verify_enable_kidprofile();
	    Logger.log("kids profile checkbox should be enable");
	}


	@Given("user should disable the kids zone subscription")
	public void user_should_disable_the_kids_zone_subscription() {
		admin.verify_disable_kidszone();
	}

	@Given("user should disable kids profile for that library")
	public void user_should_disable_kids_profile_for_that_library() {
		admin.verify_disable_kidprfile();
		admin.savelibrary_logoff();
	}


	@Then("user should unselect the checkbox to disable the kids profile for the library")
	public void user_should_unselect_the_checkbox_to_disable_the_kids_profile_for_the_library() {
		admin.verify_disable_kidprfile();
		Logger.log("kids profile checkbox not selected");
	}


	@Then("user should see the kids profile checkbox disable if kids profile not enabled in the B&T admin portal")
	public void user_should_see_the_kids_profile_checkbox_disable_if_kids_profile_not_enabled_in_the_b_t_admin_portal() {
		admin.verify_disable_kidprfile();
		Logger.log("kids profile not enabled in the B&T admin portal");		
	}

	@Given("user should disable all the profiles zone subscription")
	public void user_should_disable_all_the_profiles_zone_subscription() {
		admin.disable_allPrfiles(); 
		admin.savelibrary_logoff();
	}

	@Then("user should not disable all the profiles from the library admin portal at least one profile should be enabled")
	public void user_should_not_disable_all_the_profiles_from_the_library_admin_portal_at_least_one_profile_should_be_enabled() {
		admin.disable_allPrfiles(); 
	}

	@Given("user should enabled teen profile for that library")
	public void user_should_enabled_teen_profile_for_that_library() {
		admin.verify_enable_teenprofile();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the teen profile for the library")
	public void user_should_select_the_checkbox_to_enable_the_teen_profile_for_the_library() {
		admin.verify_enable_teenprofile();
	}

	@Given("user should disable teen profile for that library")
	public void user_should_disable_teen_profile_for_that_library() {
		admin.verify_disable_teenprfile();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the teen profile for the library")
	public void user_should_unselect_the_checkbox_to_disable_the_teen_profile_for_the_library() {
		admin.verify_disable_teenprfile();
		Logger.log("kids profile checkbox not selected");
	}

	@Then("user should see the teen profile checkbox disable if teen profile not enabled in the B&T admin portal")
	public void user_should_see_the_teen_profile_checkbox_disable_if_teen_profile_not_enabled_in_the_b_t_admin_portal() {
		admin.verify_disable_teenprfile();
		Logger.log("kids profile checkbox not selected");
	}
	
	@Given("user should enabled adult profile for that library")
	public void user_should_enabled_adult_profile_for_that_library() {
		admin.verify_enable_adultprofile();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the adult profile for the library")
	public void user_should_select_the_checkbox_to_enable_the_adult_profile_for_the_library() {
		admin.verify_enable_teenprofile();
		
	}

	@Given("user should disable adult profile for that library")
	public void user_should_disable_adult_profile_for_that_library() {
		admin.verify_disable_adultprfile();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the adult profile for the library")
	public void user_should_unselect_the_checkbox_to_disable_the_adult_profile_for_the_library() {
		admin.verify_disable_adultprfile();
	}

	@Then("user should see the adult profile checkbox disable if adult profile not enabled in the B&T admin portal")
	public void user_should_see_the_teen_profile_checkbox_disable_if_adult_profile_not_enabled_in_the_b_t_admin_portal() {
		admin.verify_disable_adultprfile();
		Logger.log("kids profile checkbox not selected");
		
	}

	@Given("user should enable programs for adult profile for that library")
	public void user_should_enable_programs_for_adult_profile_for_that_library() {
		admin.enable_adultprogram();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the programs for adult profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_programs_for_adult_profile_in_the_library() {
		admin.enable_adultprogram();
		Logger.log("adult profile programs should be enable");
	}

	@Given("user should disable programs for adult profile for that library")
	public void user_should_disable_programs_for_adult_profile_for_that_library() {   
		admin.disable_adultprogram();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the programs for adult profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_programs_for_adult_profile_in_the_library() {
		admin.disable_adultprogram();
		Logger.log("adult profile programs should be disable");
	}

	@Then("user should see the programs checkbox disable for adult profile if programs not enabled for adult profile in the B&T admin portal")
	public void user_should_see_the_programs_checkbox_disable_for_adult_profile_if_programs_not_enabled_for_adult_profile_in_the_b_t_admin_portal() {
		admin.disable_adultprogram();
		Logger.log("adult profile programs should be disable");
	}

	@Given("user should enable programs for kid profile for that library")
	public void user_should_enable_programs_for_kid_profile_for_that_library() {
		admin.enable_kidsprogram();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the programs for kid profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_programs_for_kid_profile_in_the_library() {
		admin.enable_kidsprogram();
	}

	@Given("user should disable programs for kid profile for that library")
	public void user_should_disable_programs_for_kid_profile_for_that_library() {
		admin.disable_kidsprogram();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the programs for kid profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_programs_for_kid_profile_in_the_library() {
		admin.disable_kidsprogram();
		Logger.log("kid profile programs should be disable");
		
	}

	@Then("user should see the programs checkbox disable for kid profile if programs not enabled for kid profile in the B&T admin portal")
	public void user_should_see_the_programs_checkbox_disable_for_kid_profile_if_programs_not_enabled_for_kid_profile_in_the_b_t_admin_portal() {
		admin.disable_kidsprogram();
		Logger.log("kid profile programs should be disable");
	}
	
	@Given("user should enable programs for teen profile for that library")
	public void user_should_enable_programs_for_teen_profile_for_that_library() {
	   admin.enable_teenprogram();
	   admin.savelibrary_logoff();
	   
	}

	@Then("user should select the checkbox to enable the programs for teen profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_programs_for_teen_profile_in_the_library() {
		 admin.enable_teenprogram();
		 Logger.log("teen profile programs should be enable");
		 
	}

	@Given("user should disable programs for teen profile for that library")
	public void user_should_disable_programs_for_teen_profile_for_that_library() {
		admin.disable_teenprogram();
	}

	@Then("user should unselect the checkbox to disable the programs for teen profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_programs_for_teen_profile_in_the_library() {
		admin.disable_teenprogram();
		Logger.log("teen profile programs should be disable");
		
	}

	@Then("user should see the programs checkbox disable for teen profile if programs not enabled for teen profile in the B&T admin portal")
	public void user_should_see_the_programs_checkbox_disable_for_teen_profile_if_programs_not_enabled_for_teen_profile_in_the_b_t_admin_portal() {
		admin.disable_teenprogram();
		Logger.log("teen profile programs should be disable");
	}
	
	@Given("user should enable insights and goals for kid profile for that library")
	public void user_should_enable_insights_and_goals_for_kid_profile_for_that_library() {
		admin.enable_kidsinsight();
		admin.savelibrary_logoff();		
	}
	@Then("user should select the checkbox to enable the insights and goals for kid profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_kid_profile_in_the_library() {
		admin.enable_kidsinsight();
		Logger.log("kid profile insigts and goals should be enable");
	}

	@Given("user should disable insights and goals for kid profile for that library")
	public void user_should_disable_insights_and_goals_for_kid_profile_for_that_library() {
		admin.disable_kidsinsight();
		admin.savelibrary_logoff();	
	}

	@Then("user should unselect the checkbox to disable the insights and goals for kid profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_kid_profile_in_the_library() {
		admin.disable_kidsinsight();
		Logger.log("kid profile insigts and goals should be disable");
	}

	@Then("user should see the insights and goals checkbox disable for kid profile if insights and goals not enabled for kid profile in the B&T admin portal")
	public void user_should_see_the_insights_and_goals_checkbox_disable_for_kid_profile_if_insights_and_goals_not_enabled_for_kid_profile_in_the_b_t_admin_portal() {
		admin.disable_kidsinsight();
		Logger.log("kid profile insigts and goals should be disable");
	}
	
	
	@Given("user should enable insights and goals for adult profile for that library")
	public void user_should_enable_insights_and_goals_for_adult_profile_for_that_library() {
	   admin.enable_adultinsight();
	   admin.savelibrary_logoff();
	   
	}

	@Then("user should select the checkbox to enable the insights and goals for adult profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_adult_profile_in_the_library() {
		admin.enable_adultinsight();
		Logger.log("adult profile insigts and goals should be enable");
	}

	@Given("user should disable insights and goals for adult profile for that library")
	public void user_should_disable_insights_and_goals_for_adult_profile_for_that_library() {
		admin.disable_adultinsight();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the insights and goals for adult profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_adult_profile_in_the_library() {
		admin.disable_adultinsight();
		Logger.log("adult profile insigts and goals should be disable");
	}

	@Then("user should see the insights and goals checkbox disable for adult profile if insights and goals not enabled for adult profile in the B&T admin portal")
	public void user_should_see_the_insights_and_goals_checkbox_disable_for_adult_profile_if_insights_and_goals_not_enabled_for_adult_profile_in_the_b_t_admin_portal() {
		admin.disable_adultinsight();
		Logger.log("adult profile insigts and goals should be disable");
	}

	@Given("user should enable insights and goals for teen profile for that library")
	public void user_should_enable_insights_and_goals_for_teen_profile_for_that_library() {
	    admin. enable_teeninsight();
	    admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the insights and goals for teen profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_insights_and_goals_for_teen_profile_in_the_library() {
		admin. enable_teeninsight();
		Logger.log("teen profile insigts and goals should be enable");
		
	}

	@Given("user should disable insights and goals for teen profile for that library")
	public void user_should_disable_insights_and_goals_for_teen_profile_for_that_library() {
		admin.disable_teeninsight();
		admin.savelibrary_logoff();
		
	}

	@Then("user should unselect the checkbox to disable the insights and goals for teen profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_insights_and_goals_for_teen_profile_in_the_library() {
		admin.disable_teeninsight();
		Logger.log("teen profile insigts and goals not enable");
	}

	@Then("user should see the insights and goals checkbox disable for teen profile if insights and goals not enabled for teen profile in the B&T admin portal")
	public void user_should_see_the_insights_and_goals_checkbox_disable_for_teen_profile_if_insights_and_goals_not_enabled_for_teen_profile_in_the_b_t_admin_portal() {
		admin.disable_teeninsight();
		Logger.log("teen profile insigts and goals not enable");
	}

	@Given("user should enable recommendations for kid profile for that library")
	public void user_should_enable_recommendations_for_kid_profile_for_that_library() {
		admin.enable_kidrecomm();
		admin.savelibrary_logoff();
		
	}

	@Then("user should select the checkbox to enable the recommendations for kid profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_recommendations_for_kid_profile_in_the_library() {
		admin.enable_kidrecomm();
		Logger.log("kid profile recommendations should enable");
	}

	@Given("user should disable recommendations for kid profile for that library")
	public void user_should_disable_recommendations_for_kid_profile_for_that_library() {
	 admin.disable_kidrecomm();
	 admin.savelibrary_logoff();
	 
	}

	@Then("user should unselect the checkbox to disable the recommendation for kid profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_recommendation_for_kid_profile_in_the_library() {
		admin.disable_kidrecomm();
	}

	@Then("user should see the recommendation checkbox disable for kid profile if recommendation not enabled for kid profile in the B&T admin portal")
	public void user_should_see_the_recommendation_checkbox_disable_for_kid_profile_if_recommendation_not_enabled_for_kid_profile_in_the_b_t_admin_portal() {
		admin.disable_kidrecomm();
		Logger.log("kid profile recommendations not enable");
	}
	
	@Given("user should enable recommendations for teen profile for that library")
	public void user_should_enable_recommendations_for_teen_profile_for_that_library() {
		 admin.enable_teenrecomm();
		 admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the recommendations for teen profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_recommendations_for_teen_profile_in_the_library() {
		admin.enable_teenrecomm();
	}

	@Given("user should disable recommendations for teen profile for that library")
	public void user_should_disable_recommendations_for_teen_profile_for_that_library() {
		admin.disable_teenrecomm();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the recommendation for teen profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_recommendation_for_teen_profile_in_the_library() {
		admin.disable_teenrecomm();
		Logger.log("teen profile recommendations not enable");
	}

	@Then("user should see the recommendation checkbox disable for teen profile if recommendation not enabled for teen profile in the B&T admin portal")
	public void user_should_see_the_recommendation_checkbox_disable_for_teen_profile_if_recommendation_not_enabled_for_teen_profile_in_the_b_t_admin_portal() {
		admin.disable_teenrecomm();
		Logger.log("teen profile recommendations not enable");
	}
	@Given("user should enable recommendations for adult profile for that library")
	public void user_should_enable_recommendations_for_adult_profile_for_that_library() {
	    admin.enable_adultrecomm();
	    admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the recommendations for adult profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_recommendations_for_adult_profile_in_the_library() {
		 admin.enable_adultrecomm();
	}

	@Given("user should disable recommendations for adult profile for that library")
	public void user_should_disable_recommendations_for_adult_profile_for_that_library() {
		admin.disable_adultrecomm();
		admin.savelibrary_logoff();		
	}
	@Then("user should unselect the checkbox to disable the recommendation for adult profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_recommendation_for_adult_profile_in_the_library() {
		admin.disable_adultrecomm();
		Logger.log("adult profile recommendations not enable");		
	}
	@Then("user should see the recommendation checkbox disable for adult profile if recommendation not enabled for adult profile in the B&T admin portal")
	public void user_should_see_the_recommendation_checkbox_disable_for_adult_profile_if_recommendation_not_enabled_for_adult_profile_in_the_b_t_admin_portal() {
		admin.disable_adultrecomm();
		Logger.log("adult profile recommendations not enable");
	}
	
	@Given("user should enable webpathexpress for adult profile for that library")
	public void user_should_enable_webpathexpress_for_adult_profile_for_that_library() {
		admin.enable_adultwebpathex();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the webpathexpress for adult profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_webpathexpress_for_adult_profile_in_the_library() {
		admin.enable_adultwebpathex();
		Logger.log("adult profile webpathexpress is enable");
	}

	@Given("user should disable webpathexpress for adult profile for that library")
	public void user_should_disable_webpathexpress_for_adult_profile_for_that_library() {
		admin.disable_adultwebpathex();
		admin.savelibrary_logoff();
		
	}
	@Then("user should unselect the checkbox to disable the webpathexpress for adult profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_adult_profile_in_the_library() {
		admin.disable_adultwebpathex();
		Logger.log("adult profile webpathexpress is not enable");
	}

	@Then("user should see the webpathexpress checkbox disable for adult profile if webpathexpress not enabled for adult profile in the B&T admin portal")
	public void user_should_see_the_webpathexpress_checkbox_disable_for_adult_profile_if_webpathexpress_not_enabled_for_adult_profile_in_the_b_t_admin_portal() {
		admin.disable_adultwebpathex();
		Logger.log("adult profile webpathexpress is not enable");
	}

	@Given("user should enable webpathexpress for teen profile for that library")
	public void user_should_enable_webpathexpress_for_teen_profile_for_that_library() {
		admin.enable_teenwebpathex();
		admin.savelibrary_logoff();
	}

	@Then("user should select the checkbox to enable the webpathexpress for teen profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_webpathexpress_for_teen_profile_in_the_library() {
		admin.enable_teenwebpathex();
		Logger.log("teen profile webpathexpress is enable");
	}

	@Given("user should disable webpathexpress for teen profile for that library")
	public void user_should_disable_webpathexpress_for_teen_profile_for_that_library() {
	   admin.disable_teenwebpathex();
	   admin.savelibrary_logoff();   
	}

	@Then("user should unselect the checkbox to disable the webpathexpress for teen profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_teen_profile_in_the_library() {
		admin.disable_teenwebpathex();
		Logger.log("teen profile webpathexpress is not enable");
	}

	@Then("user should see the webpathexpress checkbox disable for teen profile if webpathexpress not enabled for teen profile in the B&T admin portal")
	public void user_should_see_the_webpathexpress_checkbox_disable_for_teen_profile_if_webpathexpress_not_enabled_for_teen_profile_in_the_b_t_admin_portal() {
		admin.disable_teenwebpathex();
		Logger.log("teen profile webpathexpress is not enable");
	}

	@Given("user should enable webpathexpress for kid profile for that library")
	public void user_should_enable_webpathexpress_for_kid_profile_for_that_library() {
		admin.enable_kidwebpathex();
		admin.savelibrary_logoff(); 
	}

	@Then("user should select the checkbox to enable the webpathexpress for kid profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_webpathexpress_for_kid_profile_in_the_library() {
		admin.enable_kidwebpathex();
		Logger.log("kid profile webpathexpress is enable");
	}

	@Given("user should disable webpathexpress for kid profile for that library")
	public void user_should_disable_webpathexpress_for_kid_profile_for_that_library() {
	    admin.disable_kidwebpathex();
	    admin.savelibrary_logoff(); 
	}

	@Then("user should unselect the checkbox to disable the webpathexpress for kid profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_webpathexpress_for_kid_profile_in_the_library() {
		 admin.disable_kidwebpathex();
		 Logger.log("kid profile webpathexpress is not enable");
	}

	@Then("user should see the webpathexpress checkbox disable for kid profile if webpathexpress not enabled for kid profile in the B&T admin portal")
	public void user_should_see_the_webpathexpress_checkbox_disable_for_kid_profile_if_webpathexpress_not_enabled_for_kid_profile_in_the_b_t_admin_portal() {
		admin.disable_kidwebpathex();
		Logger.log("kid profile webpathexpress is not enable");
	}

	@Given("user should enable pressreader for adult profile for that library")
	public void user_should_enable_pressreader_for_adult_profile_for_that_library() {
	    admin.enable_adultpressreader();
	    admin.savelibrary_logoff(); 
	}

	@Then("user should select the checkbox to enable the pressreader for adult profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_pressreader_for_adult_profile_in_the_library() {
		admin.enable_adultpressreader();
		Logger.log("kid profile pressreader is enable");
	}

	@Given("user should disable pressreader for adult profile for that library")
	public void user_should_disable_pressreader_for_adult_profile_for_that_library() {
	    admin.disable_adultpressreader();
	    admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the pressreader for adult profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_pressreader_for_adult_profile_in_the_library() {
		admin.disable_adultpressreader();
		Logger.log("adult profile pressreader is not enable");
	}

	@Then("user should see the pressreader checkbox disable for adult profile if pressreader not enabled for adult profile in the B&T admin portal")
	public void user_should_see_the_pressreader_checkbox_disable_for_adult_profile_if_pressreader_not_enabled_for_adult_profile_in_the_b_t_admin_portal() {
		admin.disable_adultpressreader();
		Logger.log("adult profile pressreader is not enable");
	}
	
	@Given("user should enable pressreader for teen profile for that library")
	public void user_should_enable_pressreader_for_teen_profile_for_that_library() {
	   admin.enable_teenpressreader();
	   admin.savelibrary_logoff();
	   
	}

	@Then("user should select the checkbox to enable the pressreader for teen profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_pressreader_for_teen_profile_in_the_library() {
		 admin.enable_teenpressreader();
		 Logger.log("teen profile pressreader is not enable");	 
	}

	@Given("user should disable pressreader for teen profile for that library")
	public void user_should_disable_pressreader_for_teen_profile_for_that_library() {
		admin.disable_teenpressreader();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the pressreader for teen profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_pressreader_for_teen_profile_in_the_library() {
		admin.disable_teenpressreader();
		Logger.log("teen profile pressreader is not enable");
	}

	@Then("user should see the pressreader checkbox disable for teen profile if pressreader not enabled for teen profile in the B&T admin portal")
	public void user_should_see_the_pressreader_checkbox_disable_for_teen_profile_if_pressreader_not_enabled_for_teen_profile_in_the_b_t_admin_portal() {
		admin.disable_teenpressreader();
		Logger.log("teen profile pressreader is not enable");
	}

	@Given("user should enable pressreader for kid profile for that library")
	public void user_should_enable_pressreader_for_kid_profile_for_that_library() {
		admin.enable_kidpressreader();
		admin.savelibrary_logoff();
		
	}

	@Then("user should select the checkbox to enable the pressreader for kid profile in the library")
	public void user_should_select_the_checkbox_to_enable_the_pressreader_for_kid_profile_in_the_library() {
		admin.enable_kidpressreader();
		Logger.log("kid profile pressreader is enable");
	}

	@Given("user should disable pressreader for kid profile for that library")
	public void user_should_disable_pressreader_for_kid_profile_for_that_library() {
		admin.disable_kidpressreader();
		admin.savelibrary_logoff();
	}

	@Then("user should unselect the checkbox to disable the pressreader for kid profile in the library")
	public void user_should_unselect_the_checkbox_to_disable_the_pressreader_for_kid_profile_in_the_library() {
		admin.enable_kidpressreader();
		Logger.log("kid profile pressreader is not enable");
	}

	@Then("user should see the pressreader checkbox disable for kid profile if pressreader not enabled for kid profile in the B&T admin portal")
	public void user_should_see_the_pressreader_checkbox_disable_for_kid_profile_if_pressreader_not_enabled_for_kid_profile_in_the_b_t_admin_portal() {
		admin.enable_kidpressreader();
		Logger.log("kid profile pressreader is not enable");
	}

	}