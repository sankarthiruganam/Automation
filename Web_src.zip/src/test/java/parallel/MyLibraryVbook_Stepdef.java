package parallel;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;

public class MyLibraryVbook_Stepdef extends CommonAction {

	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());
	
	Eyes eyes = EyesManager.getEyes();

	/*******************************************************/
	@Given("library should have vbooks carousel configured in drupal,subscription to vbooks third party and vbook carousel enabled in library admin")
	public void library_should_have_vbooks_carousel_configured_in_drupal_subscription_to_vbooks_third_party_and_vbook_carousel_enabled_in_library_admin() {
		Logger.log("user should enabled the vbook configured in drupal,library admin and third party");
	}

	@Then("user should be able to view VBook categories in the carousel format")
	public void user_should_be_able_to_view_v_book_categories_in_the_carousel_format() {
		Assert.assertTrue(vbook.view_vbookCarouselFormat());
	}

	@Then("user should be able to view VBook title in the carousel format")
	public void user_should_be_able_to_view_v_book_title_in_the_carousel_format() {
		Assert.assertTrue(vbook.view_vbookCarouselFormat());
	}

	@Then("user should be able to view VBooks title card with cover image with primary")
	public void user_should_be_able_to_view_v_books_title_card_with_cover_image_with_primary() {		
		vbook.view_coverimgAndprimaryCTA();
		//vbook.click_vbookTitleCard();
		
	}
	
	@Then("user should be able to view VBooks title card with cover image")
	public void user_should_be_able_to_view_v_books_title_card_with_cover_image() {
		vbook.view_coverimgAndprimaryCTA();
	}

	@Then("user should be able to click on VBooks title card")
	public void user_should_be_able_to_click_on_v_books_title_card() {
		vbook.click_vbookTitleCard();
	}

	@Then("user click checkout the VBook and not started watching the VBook")
	public void user_click_checkout_the_v_book_and_not_started_watching_the_v_book() {
		vbook.click_CheckoutAsprimaryCTA();
	}

	@Then("user click checkout the VBook and start watching the VBook and exist the player")
	public void user_click_checkout_the_v_book_and_start_watching_the_v_book_and_exist_the_player() {
		vbook.click_vbookTitleCard();
		//vbook.click_PlayCTA();

	}

	@When("user should be able to navigate VBooks level {int} page")
	public void user_should_be_able_to_navigate_v_books_level_page(Integer int1) {
		vbook.Click_level1page();
	}

	@When("user should view format dropdown with option eBook, eAudio, VBooks & videos")
	public void user_should_view_format_dropdown_with_option_e_book_e_audio_v_books_videos() {
		vbook.View_FormatOptions();
	}

	@When("user selects the VBooks format from the dropdown")
	public void user_selects_the_v_books_format_from_the_dropdown() {
		vbook.select_Vbooks();
	}

	@Then("System should filter the VBooks titles based on the selected filter option are default as available now")
	public void system_should_filter_the_v_books_titles_based_on_the_selected_filter_option_are_default_as_available_now() {
		Assert.assertTrue(vbook.getAvailability_AvailableNow_dropdwn().isDisplayed());
	}

	@Then("user should be able to view titles specific to the selected format")
	public void user_should_be_able_to_view_titles_specific_to_the_selected_format() {
		Logger.log("user should be able to view titles specific to the selected format");
	}

	@Then("user should able to view these videos with different categories based on drupal configuration")
	public void user_should_able_to_view_these_videos_with_different_categories_based_on_drupal_configuration() {
		Logger.log("User able to view the videos with different categories based on Drupal Configuration");
	}

	@Then("User should be able to view video categories in the carousel format for Mr Billie and Checkers TV")
	public void user_should_be_able_to_view_video_categories_in_the_carousel_format_for_mr_billie_and_checkers_tv() {
		Assert.assertTrue(vbook.Widget_SnoozersAdventure.isDisplayed());
		//Assert.assertTrue(vbook.getCheckersTV().isDisplayed());
	}

	@Then("User should be able to view these videos categories for each publisher covering with individual carousel configured in admin portal")
	public void user_should_be_able_to_view_these_videos_categories_for_each_publisher_covering_with_individual_carousel_configured_in_admin_portal() {
		Logger.log(
				"User able to view the categories for each publisher covering with individual carousel configured in admim portal");
	}

	@Then("User clicking on the category should redirected to tier {int} title list page")
	public void user_clicking_on_the_category_should_redirected_to_tier_title_list_page(Integer int1) {
		//vbook.clickMrBillie();
		jsClick(vbook.Widget_SnoozersAdventure);
		Assert.assertTrue(vbook.getTier2Page().isDisplayed());
	}
	
	@Given("library should have VBook carousel configured in drupal")
	public void library_should_have_v_book_carousel_configured_in_drupal() {
	    Logger.log("Drupal configuration cannot be automated");
	}

	@Given("library should have subscription to VBook third party and VBook carousel enabled by library admin")
	public void library_should_have_subscription_to_v_book_third_party_and_v_book_carousel_enabled_by_library_admin() {
	    Logger.log("Admin dependency cannot be automated");
	}

	@Then("user should able to view these VBooks with different categories based on drupal configuration")
	public void user_should_able_to_view_these_v_books_with_different_categories_based_on_drupal_configuration() {
		Assert.assertTrue(vbook.view_vbookWidgetCarousel());
	}

	@Then("user should be able to view VBook categories carousel as per API response")
	public void user_should_be_able_to_view_v_book_categories_carousel_as_per_api_response() {
		Logger.log("Line depends on API response");
	}
	
	@Then("user should be able to view specific number of VBooks categories in the carousel as per drupal")
	public void user_should_be_able_to_view_specific_number_of_v_books_categories_in_the_carousel_as_per_drupal() {
		Logger.log("Drupal configuration cannot be automated");
	}

	@Then("user should be able click on any VBook category")
	public void user_should_be_able_click_on_any_v_book_category() {
	  video.clickVBookSeeAll();
		//video.click_vbookWidgetSeeAll();
	}
	
	//182530
	
	@When("user should be able click on see all CTA on the widget to navigate to VBooks level {int} landing screen")
	public void user_should_be_able_click_on_see_all_cta_on_the_widget_to_navigate_to_v_books_level_landing_screen(Integer int1) {
	    vbook.click_VBookSeeAllOnWidget();
	    
	}
	
	//182553
	
	@When("user click see all CTA of 3rd party VBook carousel in library page")
	public void user_click_see_all_cta_of_3rd_party_v_book_carousel_in_library_page() {
		vbook.click_vbookSeeAllCTA();
	}
	
	/***********************************VisualUI**************************/
	
	@Then("capture the screenshot of Video categories in the carousel format")
	public void capture_the_screenshot_of_video_categories_in_the_carousel_format() {
	    eyes.checkWindow("VideoCategoriesInCaroueselFormat");
	}
	
	@Then("capture the screenshot of title with default image")
	public void capture_the_screenshot_of_title_with_default_image() {
	    eyes.checkWindow("TitleWithDefaultImage");
	}

	@Then("capture the screenshot of Tier {int} page")
	public void capture_the_screenshot_of_tier_page(Integer int1) {
	    eyes.checkWindow("TierThreePage");
	}

	@Then("capture the screenshot of videos title card with cover image with primary")
	public void capture_the_screenshot_of_videos_title_card_with_cover_image_with_primary() {
	    eyes.checkWindow("VideosTitleCardWithCoverImageAsPrimary");
	}

	@Then("capture the screenshot of primary CTA as checkout")
	public void capture_the_screenshot_of_primary_cta_as_checkout() {
	    eyes.checkWindow("PrimaryCtaCheckout");
	}

	@Then("capture the screenshot of primary CTA as Play")
	public void capture_the_screenshot_of_primary_cta_as_play() {
	    eyes.checkWindow("PrimaryCtaPlay");
	}

	@Then("capture the screenshot of primary CTA as Resume")
	public void capture_the_screenshot_of_primary_cta_as_resume() {
	    eyes.checkWindow("PrimaryCtaResume");
	}

	@Then("capture the screenshot of VBook categories in the carousel format")
	public void capture_the_screenshot_of_v_book_categories_in_the_carousel_format() {
	    eyes.checkWindow("VBookCategoriesInCarouselFormat");
	}

	@Then("capture the screenshot of VBook titles in the carousel format")
	public void capture_the_screenshot_of_v_book_titles_in_the_carousel_format() {
	    eyes.checkWindow("VBookTitlesInCarouselFormat");
	}

	@Then("capture the screenshot of VBooks title card with cover image with primary")
	public void capture_the_screenshot_of_v_books_title_card_with_cover_image_with_primary() {
	    eyes.checkWindow("VBookTitleCardWithCoverImageAsPrimary");
	}

	@Then("capture the screenshot of Video categories of Mr Billie and Checkers TV")
	public void capture_the_screenshot_of_video_categories_of_mr_billie_and_checkers_tv() {
		eyes.checkWindow("VideoCategoriesOfMrBillieAndCheckersTV");
	}

	@Then("capture the screenshot of tier {int} title list page")
	public void capture_the_screenshot_of_tier_title_list_page(Integer int1) {
		eyes.checkWindow("TierTwoPage");
	}

	@Then("capture the screenshot of tier {string} title list page")
	public void capture_the_screenshot_of_tier_title_list_page(String string) {
	    eyes.checkWindow("TierOnePage");
	}

	@Then("capture the screenshot of VBook categories of Mr Billie and Checkers TV")
	public void capture_the_screenshot_of_v_book_categories_of_mr_billie_and_checkers_tv() {
		eyes.checkWindow("VBookCategoriesOfMrBillieAndCheckersTV");
	}
	
	@Then("capture the screenshot of VBooks title card with cover image")
	public void capture_the_screenshot_of_VBooks_title_card_with_cover_image() {
		eyes.checkWindow("VBooksWithCoverImage");
	}
	
//	@When("user clicks on video widget See All CTA")
//	public void user_clicks_on_video_widget_see_all_cta() {
//	   video.click_videoWidgetSeeAll();
//	}
	
//	@Then("user should be able to view videos title card with cover image")
//	public void user_should_be_able_to_view_videos_title_card_with_cover_image() {
//		jsClick(video.Lib_videoCarousel_videotitleCoverimg);
//	}
	
	@When("user clicks on vbook widget See All CTA")
	public void user_clicks_on_vbook_widget_see_all_cta() {
	   video.click_vbookWidgetSeeAll();
	}
	
//	@Then("user clicks on video widget See All CTA after selected format")
//	public void user_clicks_on_video_widget_see_all_cta_after_selected_format() {
//	   video.click_afterFormatSelected_videoWidgetSeeAll();
//	}
	

	@Then("user should be able to view left and right arrow on the respective sides of vBook carousel")
	public void user_should_be_able_to_view_left_and_right_arrow_on_the_respective_sides_of_vBook_carousel() {
	    Assert.assertTrue(vbook.getVBookCarousel_nextButton().isDisplayed());
	}
	
	@Then("user should be able to select left and right arrow to swipe left and right side in the vBook carousel")
	public void user_should_be_able_to_select_left_and_right_arrow_to_swipe_left_and_right_side_in_the_vBook_carousel() {
	    vbook.click_VBookCarouselLeftRightButton();
	}



}
