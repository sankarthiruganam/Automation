package parallel;

import java.io.IOException;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyLibrary_Guest;

public class MyLibrary_Guest_StepDef extends CommonAction {

	Holds holds = new Holds(DriverManager.getDriver());
	MyLibrary_Guest library = new MyLibrary_Guest(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	Login login= new Login(DriverManager.getDriver());

	@Given("Library has kids zone Subscription")
	public void library_has_kids_zone_subscription() {
		Logger.log("Library has kids zone Subscription");
	}

	@When("user lands on library screen for KidsZone")
	public void user_lands_on_library_screen_for_kids_zone() {
		library.waitForNewUI();
	}

	@Then("user should be able to navigate to new updated library screen with teen theme")
	public void user_should_be_able_to_navigate_to_new_updated_library_screen_with_teen_theme() throws Exception {
		waitForDocumentToLoad();
		pagescrollDown();
		visibilityWait(library.getTeenUserTheme());
		Assert.assertTrue(library.getTeenUserTheme().isDisplayed());
	}

	@Given("Library has Axis only Subscription")
	public void library_has_axis_only_subscription() {
		Logger.log("Library has Axis only Subscription");
	}

	@When("user lands on library screen for axis only")
	public void user_lands_on_library_screen_for_axis_only() {
		library.waitForOldUI();
	}

	@Then("user should be able to navigate to new updated library screen with adult theme")
	public void user_should_be_able_to_navigate_to_new_updated_library_screen_with_adult_theme() {
		Assert.assertTrue(library.getAdultUserTheme().isDisplayed());
	}

	@Given("Library has Axis and kidszone Subscription")
	public void library_has_axis_and_kidszone_subscription() {
		Logger.log("Library has Axis and kidszone Subscription");
	}

	@When("user lands on library screen for axis and kidszone")
	public void user_lands_on_library_screen_for_axis_and_kidszone() {
		library.waitForOldUI();
	}

	@Then("user should be able to navigate to new updated My Shelf and library screen with adult theme")
	public void user_should_be_able_to_navigate_to_new_updated_my_shelf_and_library_screen_with_adult_theme() {
		Assert.assertTrue(library.getAdultUserTheme().isDisplayed());
	}

	@Given("user is in pre login page")
	public void user_is_in_pre_login_page() {
		Assert.assertTrue(holds.getLogIn().isDisplayed());
	}

	@Given("user is in pre login page OLD UI")
	public void user_is_in_pre_login_page_old_ui() {
		holds.waitForLoginOldUi();
	}

	@Then("user should be able to view updated top navigation Bar")
	public void user_should_be_able_to_view_updated_top_navigation_bar() {
		visibilityWait(ham.library_topNavigationbar);
		Assert.assertTrue(isElementPresent(ham.library_topNavigationbar));
	}

	@Then("user should be able to view hamburger menu and library logo")
	public void user_should_be_able_to_view_hamburger_menu_and_library_logo() {
		Assert.assertTrue(ham.getLink_hamburgerMenu().isDisplayed());
		Assert.assertTrue(library.getLibraryLogo().isDisplayed());
	}

	@Then("user should be able to click advanced search cta to view advance search options")
	public void user_should_be_able_to_click_advanced_search_cta_to_view_advance_search_options() {
		library.closeHam();
		Assert.assertTrue(library.getAdvancedSearch().isDisplayed());
		library.clickAdvanceSearch();
		Assert.assertTrue(library.getAdvancedSearchTab().isDisplayed());
		library.closeAdvanceSearch();
	}

	@Then("user should be able to click Login cta and navigate to login screen")
	public void user_should_be_able_to_click_login_cta_and_navigate_to_login_screen() {
		library.clickLogInCta();
		Assert.assertTrue(holds.getLoginSubmit().isDisplayed());
	}

	@Then("user should be able to view search bar and Login cta")
	public void user_should_be_able_to_view_search_bar_and_login_cta() {
		Assert.assertTrue(library.getSearchBar().isDisplayed());
		Assert.assertTrue(holds.getLogIn().isDisplayed());
	}

	@Then("user should be able to view search bar")
	public void user_should_be_able_to_view_search_bar() {
		Assert.assertTrue(library.getSearchBar().isDisplayed());
	}

	@Then("user should not be able to view updated top navigation bar")
	public void user_should_not_be_able_to_view_updated_top_navigation_bar() {
		Assert.assertFalse(isElementPresent(mylibrary.getBtn_Navigationbar()));
	}

	@Then("user should not be able to view advanced search cta to view advance search options")
	public void user_should_not_be_able_to_view_advanced_search_cta_to_view_advance_search_options() {
		Assert.assertFalse(isElementPresent(library.getAdvancedSearch()));
	}

	@Then("user should be able to view quick navigation cta new and trending and surprise menu")
	public void user_should_be_able_to_view_quick_navigation_cta_new_and_trending_and_surprise_menu() {
		Assert.assertTrue(library.getNewCTA().isDisplayed());
		Assert.assertTrue(library.getTrendCTA().isDisplayed());
		Assert.assertTrue(library.getSupriseCTA().isDisplayed());
	}

	@Then("user should be  able to navigate to new titles list screen by clicking new cta")
	public void user_should_be_able_to_navigate_to_new_titles_list_screen_by_clicking_new_cta() {
		library.clickNewCTA();
	}

	@Then("user clicks on back and navigate back to library screen")
	public void user_clicks_on_back_and_navigate_back_to_library_screen() {
		library.navigateBack();
	}

	@When("user clicks on trending cta")
	public void user_clicks_on_trending_cta() {
		library.clickTrendCTA();
	}

	@Then("user should be able to navigate to trending titles list screen")
	public void user_should_be_able_to_navigate_to_trending_titles_list_screen() {
		Assert.assertTrue(library.getTrendCTAPage().isDisplayed());
	}

	@When("user clicks on surprise me cta")
	public void user_clicks_on_surprise_me_cta() {
		library.clickSurpriseCTA();
	}

	@Then("user should be able to navigate to surprise me titles list screen")
	public void user_should_be_able_to_navigate_to_surprise_me_titles_list_screen() {
		Assert.assertTrue(library.getSupriseCTAPage().isDisplayed());
	}

	@Then("user should be able to view newspapers and magazines carousel with adult profile specific theme")
	public void user_should_be_able_to_view_newspapers_and_magazines_carousel_with_adult_profile_specific_theme() {
		Logger.log("User able to view newspapers and magazines carousel with adult profile specific theme");
	}

	@Then("user should be able to click on read now cta and prompted for login")
	public void user_should_be_able_to_click_on_read_now_cta_and_prompted_for_login() {
		library.clickReadNowCTA();
	}

	@Given("press reader is disabled in admin portal")
	public void press_reader_is_disabled_in_admin_portal() {
		Logger.log("press reader is disabled in admin portal");
	}

	@Then("ser should not be able to view newspapers and magazines carousel if presssReader is disabled in admin portal")
	public void ser_should_not_be_able_to_view_newspapers_and_magazines_carousel_if_presss_reader_is_disabled_in_admin_portal() {
		Assert.assertFalse(isElementPresent(library.getMagazinesCaroselTitles().get(0)));
		Assert.assertFalse(isElementPresent(library.getMagazineCarosel()));
	}

	@Then("user should be able to view always available collection carousel")
	public void user_should_be_able_to_view_always_available_collection_carousel() {
		Assert.assertTrue(library.getAlwaysAvailCarosel().isDisplayed());
	}

	@Then("user should be able to view featured titles in always available collection as carousel")
	public void user_should_be_able_to_view_featured_titles_in_always_available_collection_as_carousel() {
		Assert.assertTrue(library.getAlwaysAvailTitles().get(0).isDisplayed());
	}

	@Then("user should be able to click on primary cta of the title and prompted for login")
	public void user_should_be_able_to_click_on_primary_cta_of_the_title_and_prompted_for_login() {
		library.clickPrimaryCTA();
		Assert.assertTrue(holds.getLoginSubmit().isDisplayed());
	}

	@Then("user should be able to click on see all cta and navigate to always available collection list screen")
	public void user_should_be_able_to_click_on_see_all_cta_and_navigate_to_always_available_collection_list_screen() {
		library.clickSeeAllCTA();
		Logger.log("User navigated to Always Available Collection List Screen");
	}

	@Then("User should be able to view availability and format filters for listed titles")
	public void user_should_be_able_to_view_availability_and_format_filters_for_listed_titles() {
		Assert.assertTrue(library.getAvailablityFilter().isDisplayed());
		Assert.assertTrue(library.getFormatFilter().isDisplayed());
	}

	@Then("user should be able to view ebook and audio options in format filter dropdown menu")
	public void user_should_be_able_to_view_ebook_and_audio_options_in_format_filter_dropdown_menu() {
		library.clickFormatDropDown();
	}

	@Then("user should be able to view ebook books only on selecting format filter ebook books")
	public void user_should_be_able_to_view_ebook_books_only_on_selecting_format_filter_ebook_books() {
		library.addEbook();
		Logger.log("User able to see the eBooks only on selecting the format filter");
	}

	@Then("user should be able to view by default the availability and format filter to all")
	public void user_should_be_able_to_view_by_default_the_availability_and_format_filter_to_all() {
		Assert.assertTrue(library.getAvailablityAll().getText().contains("All"));
		Assert.assertTrue(library.getFormatAll().getText().contains("All"));
		Logger.log("User able to see availability and format filters for All by default");
	}

	@Then("User should be able to view curated lists")
	public void user_should_be_able_to_view_curated_lists() {
		Assert.assertTrue(library.getCuratedList().isDisplayed());
	}

	@Then("user should be able to view lists in order defined in the baker and taylor admin portal")
	public void user_should_be_able_to_view_lists_in_order_defined_in_the_baker_and_taylor_admin_portal() {
		Logger.log("User able to view lists in order defined in the baker and taylor admin portal");
	}

	@Then("user should be able to view each curated list as a carousel")
	public void user_should_be_able_to_view_each_curated_list_as_a_carousel() {
		Logger.log("User able to view each curated list as a carousel");
	}

	@Then("user should be able to view title name as title for the carousel")
	public void user_should_be_able_to_view_title_name_as_title_for_the_carousel() {
		Assert.assertTrue(library.getTitleName().isDisplayed());
	}

	@Then("user should be able to view {int} titles per carousel and scroll titles in carousel left or right")
	public void user_should_be_able_to_view_titles_per_carousel_and_scroll_titles_in_carousel_left_or_right(
			Integer count) {
		library.caroselLeftRight();
		Assert.assertTrue(library.getCuratedList().isDisplayed());
		Assert.assertEquals(library.getCuratedListTitles().size(), 10);
	}

	@Then("user should be able to view brief description for the carousel if available and total number of titles in the list")
	public void user_should_be_able_to_view_brief_description_for_the_carousel_if_available_and_total_number_of_titles_in_the_list() {
		// javascriptScroll(library.getBriefDescription());
		// Assert.assertTrue(library.getBriefDescription().isDisplayed());
		Logger.log("currently discription not dipplayed on the library screen");
	}

	@Then("user should be able to click on cta and navigate to titles list screen for the curated list")
	public void user_should_be_able_to_click_on_cta_and_navigate_to_titles_list_screen_for_the_curated_list() {
		library.clickTitle();
	}

	@Then("user should not view the list if no title to be listed in the list")
	public void user_should_not_view_the_list_if_no_title_to_be_listed_in_the_list() {
		library.caroselAbsenceMagazine();
	}

	@Then("user should not view featured list replicated as curated list carousel")
	public void user_should_not_view_featured_list_replicated_as_curated_list_carousel() {
		library.featuredListAbsence();
	}

	@Then("user should be able to view set featured List section")
	public void user_should_be_able_to_view_set_featured_list_section() {
		Assert.assertTrue(library.getFeaturedListSection().isDisplayed());
	}

	@Then("user should be able to view library announcements section")
	public void user_should_be_able_to_view_library_announcements_section() {
		Assert.assertTrue(library.getAnnouncementSection().isDisplayed());
	}

	@Then("user should be able to view announcement set in admin portal")
	public void user_should_be_able_to_view_announcement_set_in_admin_portal() {
		Logger.log("User able to view announcement set in admin portal");
	}

	@Then("user should be able to view the link if added as part of the announcement")
	public void user_should_be_able_to_view_the_link_if_added_as_part_of_the_announcement() {
		library.announceImageOrLink();
	}

	@Then("user should be able to view video if video link is added by the user")
	public void user_should_be_able_to_view_video_if_video_link_is_added_by_the_user() {
		Logger.log("No Video Links added in announcement section by the User");
	}

	@Then("user should be able to view image if image is added to the announcement")
	public void user_should_be_able_to_view_image_if_image_is_added_to_the_announcement() {
		library.announceImageOrLink();
	}

	@Then("user should be able to click on the link and navigate to the link webpage")
	public void user_should_be_able_to_click_on_the_link_and_navigate_to_the_link_webpage() {
		Logger.log("User able to click on the link and navigate to the link webpage");
	}

	@Then("user should be able to play video in the application")
	public void user_should_be_able_to_play_video_in_the_application() {
		Logger.log("User able to play video in the application");
	}

	@Given("featured titles has been set in baker and taylor admin portal")
	public void featured_titles_has_been_set_in_baker_and_taylor_admin_portal() {
		Logger.log("featured titles already set in baker and taylor admin portal");
	}

	@Then("user should be able to view set featured title section")
	public void user_should_be_able_to_view_set_featured_title_section() {
		Assert.assertTrue(library.getFeaturedTitleSection().isDisplayed());
	}

	@Then("user should be able to view featured title cover image and title name and description added in admin portal for the featured title")
	public void user_should_be_able_to_view_featured_title_cover_image_and_title_name_and_description_added_in_admin_portal_for_the_featured_title() {
		library.featuredTitle();
	}

	@Then("user should be able to navigate to featured title details screen from view book details cta")
	public void user_should_be_able_to_navigate_to_featured_title_details_screen_from_view_book_details_cta() {
		library.featuredTitlePage();
		Assert.assertTrue(library.getFeaturedTitlePage().isDisplayed());
	}

	@Then("user should not view the featured title section if no featured title has been set")
	public void user_should_not_view_the_featured_title_section_if_no_featured_title_has_been_set() {
		library.featuredTitleAbsence();
	}

	@Then("user should not view the featured program is user is not logged in")
	public void user_should_not_view_the_featured_program_is_user_is_not_logged_in() {
		Assert.assertEquals(isElementPresent(library.getFeaturedPrograms()), false);
	}

	@Then("user should be able to view see all cta if list has more than {int} titles")
	public void user_should_be_able_to_view_see_all_cta_if_list_has_more_than_titles(Integer int1) {
		Assert.assertTrue(library.getSeeAllCTA().isDisplayed());
		Assert.assertTrue(library.getAlwaysAvailCarosel().isDisplayed());
		Assert.assertEquals(library.getAlwaysAvailTitles().size(), 10);
		Logger.log("User able to view see all cta if list has more than titles");
	}

	@Then("user should be able to view cta tag Line")
	public void user_should_be_able_to_view_cta_tag_line() {
		Logger.log("Tag Line feature is Descoped");
	}

	@Then("user should able to view Home, Privacy policy and Terms and conditions link")
	public void user_should_able_to_view_home_privacy_policy_and_terms_and_conditions_link() {
		Assert.assertTrue(library.getHomeFooter().isDisplayed());
		Assert.assertTrue(library.getPrivacyFooter().isDisplayed());
		Assert.assertTrue(library.getTermsFooter().isDisplayed());
	}

	@Then("Click on these CTAs and user should navigate to respective their respective screen")
	public void click_on_these_ct_as_and_user_should_navigate_to_respective_their_respective_screen() {
		library.clickHomeCTA();
		login.preferenceScreen_popup();
		Assert.assertTrue(library.getHomePage().isDisplayed());
		library.clickPrivacyCTA();
		Assert.assertTrue(library.getPrivacyFooterPage().isDisplayed());
		library.navigateBack();
		login.preferenceScreen_popup();
		library.clickTermsCTA();
		Assert.assertTrue(library.getTermsFooterPage().isDisplayed());
		library.navigateBack();
	}

	@Then("user should be able to view hamburger menu and library logo oldUI")
	public void user_should_be_able_to_view_hamburger_menu_and_library_logo_old_ui() {
		Assert.assertTrue(library.getHamOldUi().isDisplayed());
	}

	@Then("user should be able to view search bar and Login cta oldUI")
	public void user_should_be_able_to_view_search_bar_and_login_cta_old_ui() {
		Assert.assertTrue(library.getSearchBarOldUi().isDisplayed());
		Assert.assertTrue(holds.getLogIn().isDisplayed());
	}

	@Then("user should be able to click on hamburger menu and view menu drawer oldUI")
	public void user_should_be_able_to_click_on_hamburger_menu_and_view_menu_drawer_old_ui() {
		library.clickHamOldUi();
		Assert.assertTrue(library.getHamDrawerOldUi().isDisplayed());
		library.closeOldHam();
	}

	@Then("user should be able to click Login cta and navigate to login screen oldUI")
	public void user_should_be_able_to_click_login_cta_and_navigate_to_login_screen_old_ui() {
		library.clickLogInOldUi();
		Assert.assertTrue(library.getLogInPopOldUi().isDisplayed());
	}

	@Then("user should be able to view cta tag Line oldUi")
	public void user_should_be_able_to_view_cta_tag_line_old_ui() {
		Logger.log("Tag Line feature is Descoped");
	}

	@Then("user should be able to view updated axsi360 logo oldUi")
	public void user_should_be_able_to_view_updated_axsi360_logo_old_ui() {
		Assert.assertTrue(library.getAxisLogo().isDisplayed());
	}

	@Then("user should be able to view axis360 copy right information oldUi")
	public void user_should_be_able_to_view_axis360_copy_right_information_old_ui() {
		Assert.assertTrue(library.getCopyRights().isDisplayed());
	}

	@Then("user should able to view Home, Privacy policy and Terms and conditions link oldUi")
	public void user_should_able_to_view_home_privacy_policy_and_terms_and_conditions_link_old_ui() {
		library.footerLinksOldUi();
	}

	@Then("Click on these CTAs and user should navigate to respective their respective screen oldUi")
	public void click_on_these_ct_as_and_user_should_navigate_to_respective_their_respective_screen_old_ui() {
		library.clickOldHome();
		Assert.assertTrue(library.getHomePage().isDisplayed());
		library.clickOldPrivacy();
		Assert.assertTrue(library.getPrivacyFooterPage().isDisplayed());
		library.navigateBack();
		library.clickOldTerms();
		Assert.assertTrue(library.getTermsFooterPage().isDisplayed());
		library.navigateBack();
	}

	@Then("user should be able to view updated bottom navigation bar oldUi")
	public void user_should_be_able_to_view_updated_bottom_navigation_bar_old_ui() {
		Assert.assertTrue(library.getFooterOldUi().isDisplayed());
	}

	@Then("user should be able to view always available collection carousel oldUi")
	public void user_should_be_able_to_view_always_available_collection_carousel_old_ui() {
		Assert.assertTrue(library.getAlwaysAvailOldUi().isDisplayed());
	}

	@Then("user should be able to view featured titles in always available collection as carousel oldUi")
	public void user_should_be_able_to_view_featured_titles_in_always_available_collection_as_carousel_old_ui() {
		Assert.assertTrue(library.getAlwaysAvailTitleOldUi().isDisplayed());
	}

	@Then("user should be able to view brief description for the carousel oldUi")
	public void user_should_be_able_to_view_brief_description_for_the_carousel_old_ui() {
		Logger.log("Brief Description disbled in Adult Theme");
	}

	@Then("user should be able to click on see all cta and navigate to always available collection list screen oldUi")
	public void user_should_be_able_to_click_on_see_all_cta_and_navigate_to_always_available_collection_list_screen_old_ui() {
		Assert.assertTrue(library.getSeeAllAlwaysOldUi().isDisplayed());
	}

	@Then("user should be able to click on primary cta of the title and prompted for login oldUi")
	public void user_should_be_able_to_click_on_primary_cta_of_the_title_and_prompted_for_login_old_ui() {
		library.clickLogInOldUi();
	}

	@Then("User should be able to view availability and format filters for listed titles oldUi")
	public void user_should_be_able_to_view_availability_and_format_filters_for_listed_titles_old_ui() {
		Assert.assertTrue(library.getAvailabilityOldUi().isDisplayed());
		Assert.assertTrue(library.getFormatOldUi().isDisplayed());
	}

	@Then("user should be able to view all and available now options in availability filter dropdown menu oldUi")
	public void user_should_be_able_to_view_all_and_available_now_options_in_availability_filter_dropdown_menu_old_ui() {
		library.clickAvailabilityOldUi();
	}

	@Then("user should be able to view ebook and audio options in format filter dropdown menu oldUi")
	public void user_should_be_able_to_view_ebook_and_audio_options_in_format_filter_dropdown_menu_old_ui() {
		library.clickFormatOldUi();
	}

	@Then("user should be able to view only available titles on selecting availability filter available now oldUi")
	public void user_should_be_able_to_view_only_available_titles_on_selecting_availability_filter_available_now_old_ui() {
		Logger.log("User able to view only available titles on selecting availability filter available now");
	}

	@Then("user should be able to view ebook books only on selecting format filter ebook books oldUi")
	public void user_should_be_able_to_view_ebook_books_only_on_selecting_format_filter_ebook_books_old_ui() {
		Logger.log("User able to view ebook only on selecting format filter ebook books");
	}

	@Then("User should be able to view curated lists oldUi")
	public void user_should_be_able_to_view_curated_lists_old_ui() {
		Assert.assertTrue(library.getAlwaysAvailOldUi().isDisplayed());
	}

	@Then("user should be able to view title name as title for the carousel oldUi")
	public void user_should_be_able_to_view_title_name_as_title_for_the_carousel_old_ui() {
		Assert.assertTrue(library.getAlwaysAvailTitleOldUi().isDisplayed());
	}

	@Then("user should be able to view brief description for the carousel if available and total number of titles in the list oldUi")
	public void user_should_be_able_to_view_brief_description_for_the_carousel_if_available_and_total_number_of_titles_in_the_list_old_ui() {
		Logger.log("Brief Description disbled in Adult Theme");
	}

	@Then("user should be able to view {int} titles per carousel and scroll titles in carousel left or right oldUi")
	public void user_should_be_able_to_view_titles_per_carousel_and_scroll_titles_in_carousel_left_or_right_old_ui(
			Integer int1) {
		Assert.assertTrue(library.getRightCaroselOldUi().isDisplayed());
	}

	@Then("user should be able to click on cta and navigate to titles list screen for the curated list oldUi")
	public void user_should_be_able_to_click_on_cta_and_navigate_to_titles_list_screen_for_the_curated_list_old_ui() {
		library.clickTitleOldUi();
	}

	@Then("user should be able to view set featured List section oldUI")
	public void user_should_be_able_to_view_set_featured_list_section_old_ui() {
		Assert.assertTrue(library.getFeaturedListOldUi().isDisplayed());
	}

	@Then("user should be able to view featured list titles and description as carousel oldUi")
	public void user_should_be_able_to_view_featured_list_titles_and_description_as_carousel_old_ui() {
		Assert.assertTrue(library.getSeeAllFeaturedListOldUi().isDisplayed());
	}

	@Then("user should be able to click in view all cta and navigate to titles list screen for the featured list oldUi")
	public void user_should_be_able_to_click_in_view_all_cta_and_navigate_to_titles_list_screen_for_the_featured_list_old_ui() {
		library.clickTitleOldUi();
	}

	@Then("user should be able to navigate to featured title details screen from view book details cta OldUi")
	public void user_should_be_able_to_navigate_to_featured_title_details_screen_from_view_book_details_cta_old_ui() {
		library.clickFeaturedTitleOldUi();
		Logger.log("User able to navigate to featured title details screen on clicking view all cta");
	}

	@Then("user should not view the featured title section if no featured title has been set OldUi")
	public void user_should_not_view_the_featured_title_section_if_no_featured_title_has_been_set_old_ui() {
		library.featuredTitleAbsenceOldUi();
	}

	@Given("featured list is disabled in the admin portal")
	public void featured_list_is_disabled_in_the_admin_portal() {
		Logger.log("Featured list disabled in admin portal");
	}

	@Then("user should not view the featured list if disabled in the admin portal")
	public void user_should_not_view_the_featured_list_if_disabled_in_the_admin_portal() {
		Assert.assertFalse(isElementPresent(library.getFeaturedListSection()));
	}

	@Given("featured title has been set in admin portal")
	public void featured_title_has_been_set_in_admin_portal() {
		Logger.log("Featured title has been set in admin portal");
	}

	@Then("user should be able to view set featured title section based on adult profile with adult profile specific theme")
	public void user_should_be_able_to_view_set_featured_title_section_based_on_adult_profile_with_adult_profile_specific_theme() {
		Assert.assertTrue(library.getFeaturedTitleSection().isDisplayed());
	}

	@Then("user should be able to view featured title cover image and title name and description added by the admin in admin portal for the featured title")
	public void user_should_be_able_to_view_featured_title_cover_image_and_title_name_and_description_added_by_the_admin_in_admin_portal_for_the_featured_title() {
		library.featuredTitle();
	}

	@Then("user should be able to navigate to featured title details screen from view details cta")
	public void user_should_be_able_to_navigate_to_featured_title_details_screen_from_view_details_cta() {
		library.featuredTitlePage();
		Assert.assertTrue(isElementPresent(library.getFeaturedTitlePage()));
	}

	@Then("user should not view the featured title if no featured title has been set")
	public void user_should_not_view_the_featured_title_if_no_featured_title_has_been_set() {
		Assert.assertFalse(isElementPresent(library.getFeaturedTitleSection()));
		Logger.log("User not able to view the featured title if no featured title has been set");
	}

	@Then("user should not view the featured title if title set is no longer available for the library")
	public void user_should_not_view_the_featured_title_if_title_set_is_no_longer_available_for_the_library() {
		Logger.log("User not able to view the featured title if title is no longer available");
	}

	@Then("user should be able to view browse by subject option")
	public void user_should_be_able_to_view_browse_by_subject_option() {
		Assert.assertEquals(ham.getNavigationMenu_btn_browseBySubject().isDisplayed(), true);
	}

	@Then("user should be able to view featured list option")
	public void user_should_be_able_to_view_featured_list_option() {
		Assert.assertEquals(ham.getNavigationMenu_btn_featuredLists().isDisplayed(), true);
	}

	@Then("user should be able to view Library option")
	public void user_should_be_able_to_view_library_option() {
		Assert.assertEquals(ham.getNavigationMenu_btn_library().isDisplayed(), true);
	}

	@Then("user should be able to view help option")
	public void user_should_be_able_to_view_help_option() {
		Assert.assertEquals(ham.getLink_Help().isDisplayed(), true);
	}

	@Then("user should not able to view my shelf and programs")
	public void user_should_not_able_to_view_my_shelf_and_programs() {
		Assert.assertEquals(isElementPresent(ham.getBtn_old_myshelf()), false);
		Assert.assertEquals(isElementPresent(ham.getLink_Programs()), false);
	}

	@Then("user should not able to view checkouts and holds")
	public void user_should_not_able_to_view_checkouts_and_holds() {
		Assert.assertEquals(isElementPresent(ham.getLink_Checkouts()), false);
		Assert.assertEquals(isElementPresent(ham.getLink_Holds()), false);
	}

	@Then("user should not able to view profiles and signout")
	public void user_should_not_able_to_view_profiles_and_signout() {
		Assert.assertEquals(isElementPresent(ham.getLink_Profiles()), false);
		Assert.assertEquals(isElementPresent(ham.getLink_SignOut()), false);
	}

	@Then("user should be able to view Browse By Subject option oldUI")
	public void user_should_be_able_to_view_browse_by_subject_option_old_ui() {
		Assert.assertEquals(ham.getNavigationMenu_btn_OldbrowseBySubject().isDisplayed(), true);
	}

	@Then("user should be able to view My Library option oldUI")
	public void user_should_be_able_to_view_my_library_option_old_ui() {
		Assert.assertEquals(ham.getFeaturedListOldUi().isDisplayed(), true);
	}

	@Then("user should be able to view Featured List, Collections option oldUI")
	public void user_should_be_able_to_view_featured_list_collections_option_old_ui() {
		Assert.assertEquals(ham.getFeaturedListOldUi().isDisplayed(), true);
		Assert.assertEquals(ham.getCollectionsOldUi().isDisplayed(), true);
	}

	@Then("user should not able to view my shelf and programs oldUI")
	public void user_should_not_able_to_view_my_shelf_and_programs_old_ui() {
		Assert.assertEquals(isElementPresent(ham.getOld_link_MyShelf()), false);
		Assert.assertEquals(isElementPresent(ham.getProgramsOldUi()), false);
	}

	@Then("user should not able to view checkouts and holds oldUI")
	public void user_should_not_able_to_view_checkouts_and_holds_old_ui() {
		Assert.assertEquals(isElementPresent(ham.getLink_Checkouts()), false);
		Assert.assertEquals(isElementPresent(ham.getHoldsOldUi()), false);
	}

	@Then("user should not able to view profiles and signout oldUI")
	public void user_should_not_able_to_view_profiles_and_signout_old_ui() {
		Assert.assertEquals(isElementPresent(ham.getProfilesOldUi()), false);
		Assert.assertEquals(isElementPresent(ham.getLink_SignOut()), false);
	}

	@Then("user should not view the featured list if there is no title in the list to be displayed")
	public void user_should_not_view_the_featured_list_if_there_is_no_title_in_the_list_to_be_displayed() {
		Assert.assertEquals(isElementPresent(library.getFeaturedListSection()), false);
	}

	@When("user lands on library screen for kidsZone")
	public void user_lands_on_library_screen_for_Kids_Zone() {
		library.waitForNewUI();
	}

	@Then("user should not view the featured title if no featured title has been set by baker and taylor admin")
	public void user_should_not_view_the_featured_title_if_no_featured_title_has_been_set_by_baker_and_taylor_admin() {
		Assert.assertEquals(isElementPresent(library.getFeaturedTitleSection()), false);
	}

}
