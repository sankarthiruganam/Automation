package parallel;

import com.driverfactory.DriverManager;
import pom.kidszone.Loginpageview;

public class Newuserregistration_Stepdef {

	Hooks hooks = new Hooks();
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());

//	@Given("^user has new version of axis 360 app$")
//	public void user_has_new_version_of_axis_360_app() throws Throwable {
//		DriverManager.getDriver().get("https://demo.axis360.baker-taylor.com/");
//		loginpageUpdatedui.clickLogin();
//	}
//
//	@When("^user enters the {String} and {String} and Clicks on sign in button and navigate to registration screen$")
//	public void user_enters_the_something_and_something_and_clicks_on_sign_in_button_and_navigate_to_registration_screen(
//			String loginid, String pin, String strArg1, String strArg2) throws Throwable {
//		    loginpageUpdatedui.loginwithpinregistration();
//		
//	}
//
//	@Then("^user should be able to view updated user registration screen$")
//	public void user_should_be_able_to_view_updated_user_registration_screen() throws Throwable {
//		throw new PendingException();
//	}
//
//	@Given("^user has latest version of the Axis360 app$")
//	public void user_has_latest_version_of_the_axis360_app() throws Throwable {
//		DriverManager.getDriver().get("https://demo.axis360.baker-taylor.com/");
//	}
//
//	@When("^user navigates to registration screen from login screen$")
//	public void user_navigates_to_registration_screen_from_login_screen() throws Throwable {
//		throw new PendingException();
//	}
//
//	@Then("^user should be able to view updated only Login ID required registration screen$")
//	public void user_should_be_able_to_view_updated_only_login_id_required_registration_screen() throws Throwable {
//		throw new PendingException();
//	}

}
