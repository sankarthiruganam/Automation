package parallel;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Pagesourceview;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Pagesource_Stepdef {

	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Pagesourceview page=new Pagesourceview(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("user verify Launch application with Kidszone or Axis360 subscription")
    public void user_verify_launch_application_with_kidszone_or_axis360_subscription() throws Throwable {
		login.Login_PrefixWithPin();
		
		  page.HomecaptureScreen(); 
		  page.imageError(); 
		  page.pagenotfoundError();
		  page.filenotfoundError();
		 

    }

		
    @When("user click on Login")
    public void user_click_on_login() throws Throwable {
    	page.clickLogins();
		page.LogincaptureScreen(); 
		page.pagenotfoundError();
		 
    }

    @Then("Click on Logout")
    public void click_on_logout() throws Throwable {
    	Logger.log("User clicks on Logout");
    }
    
    @And("Enter new credentials username with prefix and pin")
    public void enter_new_credentials_username_with_prefix_and_pin() throws Throwable {
    	page.loginwith_password_popups();
    	page.DashboardcaptureScreen();
	    page.pagenotfoundError(); 
	    hamburgerMenu.click_HamburgerMenu();
	    hamburgerMenu.click_SignOut();
	    hamburgerMenu.click_YesButton();
//	    page.logout();
		 
    }

    @And("Click on login and verify new user registeration screen")
    public void click_on_login_and_verify_new_user_registeration_screen() throws Throwable {
    	page.clickLogins();
    	page.regloginwith_password();
    	page.RegcaptureScreen();
    	loginpageUpdatedui.RegisterwithPin();
    	page.RegvaluecaptureScreen();
		page.pagenotfoundError();
    	loginpageUpdatedui.Registerdetailsps();
    	    	
    }

    @And("Enter all fields and click on register button")
    public void enter_all_fields_and_click_on_register_button() throws Throwable {
    	loginpageUpdatedui.completeRegistration();
    	 page.pagenotfoundError();
    	 page.ProfilemanagecaptureScreen();
     	 
        
    }

    @And("Verify Initial Pin screen and confirm {string}")
    public void verify_initial_pin_screen_and_confirm_pin(String pin) throws Throwable {
    	//profilepageview.parentalPinsetup(pin);
    	//page.pagenotfoundError();
    	//page.captureScreen();
    }

    @And("Verify Profile management screen and click on Add profile")
    public void verify_profile_management_screen_and_click_on_add_profile() throws Throwable {
    	login.Login_PrefixWithoutPin();
		loginpageUpdatedui.click_loginPage();
		profilepageview.loginwithPin();
		profilepageview.parentalPin();
		page.pagenotfoundError();
    	page.ProfilecaptureScreen();
    }

    @And("Verify New profile screen and enter display name and select Teen option")
    public void verify_new_profile_screen_and_enter_display_name_and_select_teen_option() throws Throwable {
    	profilepageview.createNewprofile();
    	page.pagenotfoundError();
    	page.ProfselectcaptureScreen();
    	
    }

    @And("Verify Add a teen screen and click on select Avatar")
    public void verify_add_a_teen_screen_and_click_on_select_avatar() throws Throwable {
    	loginpageUpdatedui.add_teen();
    	page.pagenotfoundError();
    	page.AddteencaptureScreen();
    }

    @And("Verify Avatar screen and select any Avatar")
    public void verify_avatar_screen_and_select_any_avatar() throws Throwable {
    	profilepageview.Clickavatar();
    	page.AvatarcaptureScreen();
    	page.imageError();
    }

    @And("Verify done button enabled and click on done button")
    public void verify_done_button_enabled_and_click_on_done_button() throws Throwable {
    	profilepageview.displaynamepass();
    	//page.captureScreen();
    	page.imageError();
    }

    @And("Verify new profiles added screen and click on edit option")
    public void verify_new_profiles_added_screen_and_click_on_edit_option() throws Throwable {
    	profile.click_menu();
    	profilepageview.parentalPin();
    	profilepageview.profileEdit();
    	//wait(3000);
    	page.ProeditcaptureScreen();
    	page.imageError();
    	profile.getManageProf_pencilIcon_editProfile().get(3).click();
    
    }

    @And("Verify Pencil icon for newly created profile and click on Pencil icon")
    public void verify_pencil_icon_for_newly_created_profile_and_click_on_pencil_icon() throws Throwable {
        Logger.log("UI verified Manually");
    }

    @And("Verify Edit profile screen and enter {string} name")
    public void verify_edit_profile_screen_and_enter_dispname_name(String dispname) throws Throwable {
    	page.EditcaptureScreen();
    	profilepageview.displayNameChange(dispname);
    	
    }

    @And("Verify Save button and delete button enable and click on save")
    public void verify_save_button_and_delete_button_enable_and_click_on_save() throws Throwable {
    	profilepageview.profileEdit();
    	profile.getManageProf_pencilIcon_editProfile().get(3).click();
    	profilepageview.deleteProfile();
    	page.DeletecaptureScreen();
    	page.imageError();
    }
}
