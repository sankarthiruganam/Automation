package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.driverfactory.manager.ChromeDriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Myprograms;
import pom.kidszone.ProfileS4;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Profilecreation_Stepdef extends CommonAction {

	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	Myprograms myprogram = new Myprograms(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	ChromeDriverManager chrome = new ChromeDriverManager();
	ProfileS4 profileNew = new ProfileS4(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

//	@Given("User launch the {string} url")
//	public void user_launch_the_url(String string) throws Exception {
//		List<Map<String, String>> testData = reader.getData(System.getProperty("user.dir") + "/src/test/resources/Data/Webdata.xlsx", "Testdata");
//		loginpageUpdatedui.app_launch(testData.get(3).get("loginType"));
//		waitFor(5000);
//	}
	
	@Given("User launches the {string} url for login with password")
	public void user_launches_the_url_for_login_with_password(String string) throws Exception {
		login.Login_texas();
	}
	
	@Given("user clicks on Login button")
	public void user_clicks_on_login_button() {
		loginpageUpdatedui.click_loginPage();
		
	}

	@When("user enters the prefix {string} and pin {string} shared by the client")
	public void user_enters_the_prefix_and_pin_shared_by_the_client(String loginid, String pin) {
		loginpageUpdatedui.enter_loginwithPin(loginid, pin);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
	}

	@Given("user is in Register page and validate the prefix is repopulated in library ID")
	public void user_is_in_register_page_and_validate_the_prefix_is_repopulated_in_library_id() {
		profile.verify_registerPage_prefixRepopulate();
	}

	@Given("user set the Pin {string} for login")
	public void user_set_the_pin_for_login(String Pin) {
		profile.registerPage_set_Pin(Pin);
	}

	@Given("user selects the security question")
	public void user_selects_the_security_question() {
		Logger.log("user select the security question");

	}
	@Given("user enters the security answer {string}")
	public void user_enters_the_security_answer(String securityanswer) {
		profile.enter_securityAnswer(securityanswer);
	}
	@Given("user enters the displayName {string}")
	public void user_enters_the_displayName(String displayname) {
		profile.enter_DisplayName(displayname);
	}

	@Given("user enters the email address {string}")
	public void user_enters_the_email_address(String email) {
		profile.enter_EmailAddress(email);
	}

	@When("User selects the adult {string} profile type")
	public void user_selects_the_adult_profile_type(String adult) {
		profile.select_profile(adult);
	}

	@When("User selects the teen {string} profile type")
	public void user_selects_the_teen_profile_type(String teen) {
		profile.select_profile(teen);
	}

	@When("User selects the kid {string} profile type")
	public void user_selects_the_kid_profile_type(String kid) {
		profile.select_profile(kid);
	}

	@When("user clicks on Register button")
	public void user_clicks_on_register_button() {
		profile.click_RegisterButton();
		profile.preferenceScreen_popup();
		profile.readInAppClose();

	}
	@Then("user should navigate to the Profile Set Pin")
	public void user_should_navigate_to_the_profile_set_pin() {
		waitFor(15000);
		hamburgerMenu.click_HamburgerMenu();
		profilepageview.menu_adultProfile();
		Assert.assertEquals(profile.getTxt_profileManagementPin().isDisplayed(), true);
		
	}
	
	@Then("new user should navigate to the Profile Set Pin")
	public void new_user_should_navigate_to_the_profile_set_pin() {
		profile.preferenceScreen_popup();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		
		
	}
	@Then("teen user should navigate to the Profile Set Pin")
	public void teen_user_should_navigate_to_the_profile_set_pin() {
		profile.preferenceScreen_popup();
		profile.log_Out();
	}

	@Then("kid user should navigate to the Profile Set Pin")
	public void kid_user_should_navigate_to_the_profile_set_pin() {
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		profile.log_Out();
	}

//	@When("Already signed user enters the prefix {string} and pin {string} shared by the client")
//	public void already_signed_user_enters_the_prefix_and_pin_shared_by_the_client(String loginid, String pin) {
//		loginpageUpdatedui.already_signeduser_prefixloginwithPin(loginid, pin);
//		profile.preferenceScreen_popup();
//		profile.readInAppClose();
//	}

	@When("adult Already signed user enters the prefix {string} and pin {string} shared by the client")
	public void adult_already_signed_user_enters_the_prefix_and_pin_shared_by_the_client(String loginid, String pin) {
		loginpageUpdatedui.oldalready_signeduser_prefixloginwithPin(loginid,pin);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
	}
	@Then("user should be redirected to the home page")
	public void user_should_be_redirected_to_the_home_page() throws InterruptedException {
		profile.verify_homeScreenNav();
		Logger.log("user is in home page");
	}

	@Then("User is clicking on Profiles from Menu")
	public void user_is_clicking_on_profiles_from_menu() {
		hamburgerMenu.click_HamburgerMenu();
		//profile.click_MenuOnly();
		profilepageview.menu_adultProfile();

	}

	@Then("user enter the parent Pin {string}")
	public void enter_the_parent_pin(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickSubmit();
	}
	@And("user set the parent Pin {string}")
	public void user_set_the_parent_Pin(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickDone();
	}

	@Given("user is in the manage profile screen")
	public void user_is_in_the_manage_profile_screen() {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
	}

	@When("user clicks on the create new profile cta {string}")
	public void user_clicks_on_the_create_new_profile_cta(String string) {
		profile.clickOnAddCTA();
	}

	@Then("user views the profile creation page with options {string}")
	public void user_views_the_profile_creation_page_with_options(String teen) {
		Assert.assertTrue(profile.getAddprofile_txt_addprofile().isDisplayed());
	}

	@Then("user selects the Add a teen")
	public void user_selects_the_add_a_teen() {
		profile.create_addTeenProfile();
	}

	@Then("user views the profile creation page with options kid {string}")
	public void user_views_the_profile_creation_page_with_options_kid(String kid) {
		Assert.assertTrue(profile.getAddprofile_txt_addprofile().isDisplayed());
	}

	@Then("user selects the Add a kid")
	public void user_selects_the_add_a_kid() {
		profile.create_addkidProfile();

	}

	@Then("user enters the profile details like display name {string}\\(mandatory),upload image\\(optional)")
	public void user_enters_the_profile_details_like_display_name_mandatory_upload_image_optional(String displayname) {
		profile.Addprofile_enterDisplayName(displayname);

	}

	@Then("user enters the profile details like display name {string} \\(mandatory),select avatar\\(optional)")
	public void user_enters_the_profile_details_like_display_name_mandatory_select_avatar_optional(String displayname) {
		profile.select_avatar(displayname);
	}

	@Then("kid user enters the profile details like display name {string}\\(mandatory),upload image\\(optional)")
	public void kid_user_enters_the_profile_details_like_display_name_mandatory_upload_image_optional(
			String displayname) {
		profile.Addprofile_enterDisplayName(displayname);
		Logger.log("kid profile shouldn’t show upload image option");
		Assert.assertEquals(profile.kidProfile_notShowingUploadimg(), false);
	}
	@Then("user clicks on the done button")
	public void user_clicks_on_the_done_button() {
		profile.addprofle_donebtn();
	}
	@Then("user should view an error message when authentication failed")
	public void user_should_view_an_error_message_when_authentication_failed() {
		Logger.log("user should view and error message");
		//profile.log_Out();
	}
	@Then("user navigates to profiles page by displaying the toast message as {string} in the bottom of the screen")
	public void user_navigates_to_profiles_page_by_displaying_the_toast_message_as_in_the_bottom_of_the_screen(
			String string) {
		WaitForWebElement(profile.getProfile_errormessage_createTeenprofile());
		try {
			Assert.assertTrue(isElementPresent(profile.getProfile_errormessage_createTeenprofile()));
			Logger.log("Teen profile has been created successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("Toast msg not displayed");
		}	
//		profile.log_Out();
	}

	@Then("user navigates to profiles page by displaying the toast message as kid {string} in the bottom of the screen")
	public void user_navigates_to_profiles_page_by_displaying_the_toast_message_as_kid_in_the_bottom_of_the_screen(
			String string) {	
		try {
			Assert.assertTrue(profile.getProfile_errormessage_createKidprofile().isDisplayed());
			Logger.log("kid profile has been created successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("Toast msg not displayed");
		}
		
//		profile.log_Out();
	}

	@Then("user navigates to profile manage page")
	public void user_navigates_to_profile_manage_page() {
		profile.manageprofielScreenNav();
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
	}

	@Then("user views the recent accessed profile highlighted")
	public void user_views_the_recent_accessed_profile_highlighted() {
		profile.recent_profileHighlighted();
		profile.log_Out();
	}

	/******************************************** Manage profile*********************************************/

	// 112867
	@Then("user already setup the parent pin")
	public void user_already_setup_the_parent_pin() {
		profile.getTxt_profileManagementPin().isDisplayed();
		Logger.log("user already setup the parent pin");

	}

	@Given("user already selected the profile on browser with cache")
	public void user_already_selected_the_profile_on_browser_with_cache() {
		Logger.log("user already selected the profile on browser with cache");

	}

	@Then("user navigate to home screen")
	public void user_navigate_to_home_screen() {
		profile.verify_homeScreenNav();
		Logger.log("user is on home screen");
		profile.log_Out();
		
	}

	@Then("user navigate to parental {string} screen")
	public void user_navigate_to_parental_screen(String Pin) {
		profile.Enter_setPin(Pin);
	}

	@Then("user enter the correct pin navigate to manage profile screen")
	public void user_enter_the_correct_pin_navigate_to_manage_profile_screen() {
		// Assert.assertTrue(profile.Addprofile_txt_profile.isDisplayed());
		Logger.log("user is on manage profile screen");
	}

	@Then("user should be able to view the existing profile list")
	public void user_should_be_able_to_view_the_existing_profile_list() {
		profile.profDisplayCheck();
				
	}

//112875

	@Given("user not selected the profile already on browser with cache")
	public void user_not_selected_the_profile_already_on_browser_with_cache() {
		// profile.notSelectedProfileAlready_withbrowserCache();
//		profile.click_menu();
		profile.click_MenuOnly();
		profilepageview.menu_adultProfile();
	}

	@When("user navigate to parental pin screen")
	public void user_navigate_to_parental_pin_screen() {
		profile.getTxt_profileManagementPin().isDisplayed();
		Logger.log("user is on parental pin screen");

	}

	@Then("user enter the correct {string} navigate to manage profile screen")
	public void user_enter_the_correct_navigate_to_manage_profile_screen(String Pin) {
//		profile.handlePopUp();
		profile.Enter_setPin(Pin);
		profile.clickSubmit();
	}

	@Then("user should able to view the existing profile list")
	public void user_should_able_to_view_the_existing_profile_list() {
		profile.profDisplayCheck();
	}

	@Then("user clicks on edit cta in the manage profile screen")
	public void user_clicks_on_edit_cta_in_the_manage_profile_screen() {
		profile.click_manageProf_Edit_button();
	}

	@Then("user should see edit pen icon option in each of the profile available")
	public void user_should_see_edit_pen_icon_option_in_each_of_the_profile_available() {
		profile.verify_eachProfile_Penicon();
	}
	
	@When("User click pen icon on the profile avatar")
	public void user_click_pen_icon_on_the_profile_avatar() {
		profile.getManageProf_pencilIcon_editProfile().get(3).click();
	}

	@Then("system should be able to redirect the user to profile detail page")
	public void system_should_be_able_to_redirect_the_user_to_profile_detail_page() {
		Assert.assertTrue(isElementPresent(profile.getManageProf_txt_editicon()));
	}

	@Then("user should be able to view the profile details auto populated in the edit profile page")
	public void user_should_be_able_to_view_the_profile_details_auto_populated_in_the_edit_profile_page() {
		// Assert.assertTrue(profile.editprofile_txt_profileType.isDisplayed());
		Logger.log("profile details auto populated in the edit profile page");
	}

	@Then("user should be able to view the profile avatar, display name, parental email.")
	public void user_should_be_able_to_view_the_profile_avatar_display_name_parental_email() {
		Assert.assertTrue(profile.profileDetails_autoPopulated());
	}

	@Then("user should also view the library information like the library name, check out limit, hold limit, recommendation limit counts")
	public void user_should_also_view_the_library_information_like_the_library_name_check_out_limit_hold_limit_recommendation_limit_counts() {
		Assert.assertTrue(profile.library_information());
	}

	@Then("user also able to see the view checkout history button to view the history of check out done")
	public void user_also_able_to_see_the_view_checkout_history_button_to_view_the_history_of_check_out_done() {
		Assert.assertTrue(profile.getManageProf_txt_checkoutHistory().isDisplayed());
		javascriptScroll(profile.getManageProf_txt_insightbadgesCheckbox());
		Assert.assertTrue(profile.getManageProf_txt_insightbadgesCheckbox().isDisplayed());
	}

//112883
	@Then("user can view the profile listed in manage profile page")
	public void user_can_view_the_profile_listed_in_manage_profile_page() {
		profile.profDisplayCheck();
		profile.log_Out();

	}
//112891

	@Then("user already created {int} profile")
	public void user_already_created_profile(Integer int1) {
		profile.verify_create5ProfileOnly();
	}

	@Then("user should not see the add profile cta")
	public void user_should_not_see_the_add_profile_cta() {
		Assert.assertTrue(profile.addProfilevalidation());
	}
//112899

	@Given("existing user already set the parent pin")
	public void existing_user_already_set_the_parent_pin() {		
		Logger.log("user has already set the parent pin");
	}

	@When("user in home screen")
	public void user_in_home_screen() {
		profile.verify_homeScreenNav();
		Logger.log("user is on home page");
	}
	
	@When("user is in home screen")
	public void user_is_in_home_screen() {

		Logger.log("user is on home page");
	}

	@Then("user click on the {string} option from the menu")
	public void user_click_on_the_option_from_the_menu(String string) {
		profile.click_menu();
	}

	@Then("user should redirect to the parental pin screen")
	public void user_should_redirect_to_the_parental_pin_screen() {
		Assert.assertTrue(profile.getTxt_profileManagementPin().isDisplayed());
	}

	@Then("user enters {string} on successful authentication redirected to manage profile page")
	public void user_enters_on_successful_authentication_redirected_to_manage_profile_page(String Pin) {
		profile.Enter_setPin(Pin);
		profile.clickSubmit();
	}

	@Then("user should be able to view the list of existing profiles")
	public void user_should_be_able_to_view_the_list_of_existing_profiles() {
		profile.profDisplayCheck();
	}

	//125345
	
	@When("user clicks on user avatar in top header")
	public void user_clicks_on_user_avatar_in_top_header() {		
	   myprogram.click_avatar();
	}

	@Then("user should be able to view pop up with basic profile information and limits")
	public void user_should_be_able_to_view_pop_up_with_basic_profile_information_and_limits() {
		profile.getManageProf_edit_button().click();
		profile.getManageProf_pencilIcon_editProfile().get(5).click();
		Assert.assertTrue(profile.editprofile_txtfield_displayName.isDisplayed());
	}

	@Then("user should be able to view user avatar and display name and email if available")
	public void user_should_be_able_to_view_user_avatar_and_display_name_and_email_if_available() {
		profile.getEdidProf_avatar().isDisplayed();
		profile.profileDetails_autoPopulated();
	}

	@Then("user should be able to view view my checkouts")
	public void user_should_be_able_to_view_view_my_checkouts() {
	   Assert.assertEquals(profile.getManageProf_txt_checkoutHistory().isDisplayed(), true);
	}

	@Then("user should be able to view hold")
	public void user_should_be_able_to_view_hold() {
		 Assert.assertEquals(profile.getManageProf_txt_holdLimit().isDisplayed(), true);
	}

	@Then("user should be able to view recommends limit set by library for the patron")
	public void user_should_be_able_to_view_recommends_limit_set_by_library_for_the_patron() {
		Assert.assertEquals(profile.getManageProf_txt_RecommendationLimit().isDisplayed(), true);
	}

	@Then("user should be able to view view my interest cta and navigate to my interests screen on clicking the cta")
	public void user_should_be_able_to_view_view_my_interest_cta_and_navigate_to_my_interests_screen_on_clicking_the_cta() {
	   profile.click_viewMyinterest();
	}

	@Then("user should be able to view logout cta and logout by clicking this cta")
	public void user_should_be_able_to_view_logout_cta_and_logout_by_clicking_this_cta() {
		//hamburgerMenu.sign_Out();
		profile.log_Out();
	}
	
	@Then("user should be able to view logout cta")
	public void user_should_be_able_to_view_logout_cta() {
		profile.log_Out();
	}
	//132817
	
	@When("user navigates to edit profile screen")
	public void user_navigates_to_edit_profile_screen() {
		Assert.assertTrue(profile.profileDetails_autoPopulated());
		Logger.log("user navigate to edit profile screen");
	}

	@When("recommendations are enabled for the library")
	public void recommendations_are_enabled_for_the_library() {
		Logger.log("recommendations are enabled for the library");
	}

	@Then("user is able to view CTA for interest survey")
	public void user_is_able_to_view_cta_for_interest_survey() {
	    profile.click_interestSurvey();
	}

	@Then("user is able to navigate to interest survey from the CTA")
	public void user_is_able_to_navigate_to_interest_survey_from_the_cta() {
	   Assert.assertEquals(profile.getNav_myinterestScreen().isDisplayed(), true);
	   Logger.log("user is able to navigate to interest survey screen");
	}

	//132818
	
	@Then("user is able to view option to set my Shelf as default landing page")
	public void user_is_able_to_view_option_to_set_my_shelf_as_default_landing_page() {
		 Logger.log("user is able to view enable the my shelf option");
		//profilepageview.enable_myshelfDefaultLandingPage();
	}

	@Then("user is able set my shelf as default landing page")
	public void user_is_able_set_my_shelf_as_default_landing_page() {
		profilepageview.manageProfile_saveCTA();
		//profile.click_yesConfirmpopup();
		Logger.log("user is able set my shelf as default landing page");
		
	}
	
	@Then("user should be able to view signout cta")
	public void user_should_be_able_to_view_signout_cta() {
		hamburgerMenu.old_Logout();
	}
	
	@Then("user should be able to view logout cta OldUI")
	public void user_should_be_able_to_view_logout_cta_old_ui() {
		//hamburgerMenu.getSignOutOldUi().click();
		hamburgerMenu.sign_Out();
	}

	@Then("system should navigate user to my shelf on login if my shelf is set as default landing page")
	public void system_should_navigate_user_to_my_shelf_on_login_if_my_shelf_is_set_as_default_landing_page() {
		Assert.assertTrue(hamburgerMenu.getText_MyShelf_Page().isDisplayed());
		Logger.log("system should navigate to my shelf screen");
	}
	
	@Then("user disable my shelf as default landing page")
	public void user_disable_my_shelf_as_default_landing_page() {
		profilepageview.disable_myshelfDefaultLandingPage();
		profilepageview.manageProfile_saveCTA();
		profile.click_yesConfirmpopup();
	}

	@Then("system should navigate user to library on login if my shelf is not set as default landing page")
	public void system_should_navigate_user_to_library_on_login_if_my_shelf_is_not_set_as_default_landing_page() {
	    Assert.assertTrue(isElementPresent(profile.getTxt_libraryscreen_availability()));
	    Logger.log("system should navigate to library screen");
	}
		 
	 @And("clicks on Place on Hold on titles")
	public void clicks_on_Place_on_Hold_on_titles() {
		checkout.clickHolds();
	}

	 @Given("user select kid profile via hamburger menu")
	 public void user_select_kid_profile_via_hamburger_menu() {
		 hamburgerMenu.click_HamburgerMenu();
		 hamburgerMenu.click_Profiles();
		 profile.select_Kidprofile();
		 waitFor(2000);
		 
	 }
//	 @Given("user select teen profile via hamburger menu")
//	 public void user_select_teen_profile_via_hamburger_menu() {
//		 hamburgerMenu.click_HamburgerMenu();
//		 hamburgerMenu.click_Profiles();
//		 profile.select_Teenprofile();
//		 waitFor(2000);
//		 
//	 }

	 @When("user select kid profile for old UI")
	 public void user_select_kid_profile_for_old_ui() {
//			profile.click_MenuOnly();
//			profilepageview.menu_adultProfile();
		    profileNew.click_Kidprofile() ;
			waitFor(2000);
	 }
	 
	 @When("user select teen profile for old UI")
	 public void user_select_teen_profile_for_old_ui() {
//			profile.click_MenuOnly();
//			profilepageview.menu_adultProfile();
		   profileNew.click_Teenprofile() ;
			waitFor(2000);
	 }
	 
}
