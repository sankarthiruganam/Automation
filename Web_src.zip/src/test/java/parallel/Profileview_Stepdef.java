package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Loginpageview;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;

public class Profileview_Stepdef extends CommonAction {

	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());

	@When("user already have adult profile")
	public void user_already_have_adult_profile() throws Throwable {
		profile.verify_AlreadyAdultProfile();
	}

	@Then("user should not be able to view profile type adult")
	public void user_should_not_be_able_to_view_profile_type_adult() throws Throwable {
		Assert.assertTrue(profile.verify_shouldnotshowAdultProfile());
	}

	@And("user should be able to view the profileavatar ,displayname, parentalemail")
	public void user_should_be_able_to_view_the_profileavatar_displayname_parentalemail() throws Throwable {
		profilepageview.displayNameGet();
	}

	@And("user should be able to view delete the profile option")
	public void user_should_be_able_to_view_delete_the_profile_option() throws Throwable {
		profile.view_deleteProfile_option();
	}

	@And("user clicks on delete profile")
	public void user_clicks_on_delete_profile() throws Throwable {
		profile.getEditProf_btn_deleteProfile().click();
	}

	@And("system ask for the confirmation with Yes or No")
	public void system_ask_for_the_confirmation_with_yes_or_no() throws Throwable {
		profile.confirmation_popup();
	}

	@And("user selecting 'Yes' from the popup profile will be deleted and redirect to manage profile page")
	public void user_selecting_yes_from_the_popup_profile_will_be_deleted_and_redirect_to_manage_profile_page()
			throws Throwable {
		profile.getEditProf_btn_deleteProfilePopup().click();
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
		Logger.log("user redirect to manage profile page");
	}

	@And("user selecting 'No' from the popup profile will not be deleted")
	public void user_selecting_no_from_the_popup_profile_will_not_be_deleted() throws Throwable {
		profile.getEditProf_btn_deleteProfilePopup().click();
		Logger.log("profile will not be deleted");

	}

	// 113038 //

	@And("user should be able to edit 'displayname' in edit profile page and clicks save button")
	public void user_should_be_able_to_edit_displayname_in_edit_profile_page_and_clicks_save_button() throws Throwable {
		profilepageview.editDisplayname();
	}

	@And("user should be able to view all the profiles in the manage profile page")
	public void user_should_be_able_to_view_all_the_profiles_in_the_manage_profile_page() throws Throwable {
		profile.profDisplayCheck();
	}

	// 112004 //

	@And("user click kid pen icon on the profile avatar")
	public void user_click_kid_pen_icon_on_the_profile_avatar() throws Throwable {
//		profile.getManageProf_pencilIcon_editProfile().get(5).click();
		jsClick(profile.getManageProf_pencilIcon_editProfile().get(5));
	}

	@And("user click teen pen icon on the profile avatar")
	public void user_click_teen_pen_icon_on_the_profile_avatar() throws Throwable {
		profile.getManageProf_pencilIcon_editProfile().get(3).click();
	}

	@And("user must be able to view the profile details auto populated in the edit profile page")
	public void user_must_be_able_to_view_the_profile_details_auto_populated_in_the_edit_profile_page()
			throws Throwable {
		Logger.log("profile details auto populated in the edit profile page");

	}

	@And("user should be able to view the 'Kid 012' link to change the profile from kid to teen")
	public void user_should_be_able_to_view_the_kid_012_link_to_change_the_profile_from_kid_to_teen() throws Throwable {
		profilepageview.select_profileType_Teen();
	}

	@And("user should be able to edit {string} in profile page and clicks save button")
	public void user_should_be_able_to_edit_kid_something_in_profile_page_and_clicks_save_button(String dispname)
			throws Throwable {
		profilepageview.displayNameChange(dispname);
	}

	@Given("user should be able to view the teen'Teen {int}' link to change the profile from teen to kid")
	public void user_should_be_able_to_view_the_teen_teen_link_to_change_the_profile_from_teen_to_kid(Integer int1) {
		// profilepageview.select_profileType_Kid();
		Logger.log("user able to view the teen'Teen link to change the profile from teen to kid");
	}

	@Then("edited details should be updated in the system and user able to view the saved details")
	public void edited_details_should_be_updated_in_the_system_and_user_able_to_view_the_saved_details() {
		Logger.log("user able to view the saved details");
	}

	@Then("setup the profile pin {string} and confirm pin")
	public void setup_the_profile_pin_and_confirm_pin(String pin) {
		profile.Enter_setupParentalPin(pin);
	}

	@Then("check new user profile is created for adult")
	public void check_new_user_profile_is_created_for_adult() {
		profile.verify_AlreadyAdultProfile();
	}

	/******************************************
	 * 112995
	 *******************************************************/
	@When("user already added the profile image for teen profile")
	public void user_already_added_the_profile_image_for_teen_profile() {
		Logger.log("user already added the profile image for teen profile");
	}

	@When("user already added the profile image for kid profile")
	public void user_already_added_the_profile_image_for_kid_profile() {
		Logger.log("user already added the profile image for kid profile");
	}

	@Then("teen user navigated to profile detail screen click on edit pen icon on the profile")
	public void teen_user_navigated_to_profile_detail_screen_click_on_edit_pen_icon_on_the_profile() {
//		profile.getManageProf_pencilIcon_editProfile().get(2).click();
		jsClick(profile.getManageProf_pencilIcon_editProfile().get(1));
	}

	@Then("kid user navigated to profile detail screen click on edit pen icon on the profile")
	public void kid_user_navigated_to_profile_detail_screen_click_on_edit_pen_icon_on_the_profile() {
		profile.getManageProf_pencilIcon_editProfile().get(4).click();

	}

	@Then("user selects profile image from select avatar system displays the list of images added")
	public void user_selects_profile_image_from_select_avatar_system_displays_the_list_of_images_added() {
		WaitForWebElement(profilepageview.getEditprofile_icon_profileimg());
		profilepageview.getEditprofile_icon_profileimg().click();
	}

	@Then("user selects the {string}")
	public void user_selects_the(String string) {
		waitFor(3000);
		profilepageview.getEditprofile_img_listofavatar().get(0).click();
	}

	@Then("user clicks on the save button")
	public void user_clicks_on_the_save_button() {
		profilepageview.afterselectAvatar_save();

	}

	// 132219

	@When("user is on edit profile screen")
	public void user_is_on_edit_profile_screen() {
		profile.profileDetails_autoPopulated();
		Logger.log("user is on edit profile screen");
	}

	@When("user selects Kid profile")
	public void user_selects_kid_profile() {
		profilepageview.select_kidProfile();
	}

	@When("user has interests preferences set and recommendations are enabled for the library")
	public void user_has_interests_preferences_set_and_recommendations_are_enabled_for_the_library() {
		profilepageview.manageProfile_saveCTA();
		profile.click_yesConfirmpopup();
		Logger.log("user has enable interests preference and recommendation ");
	}

	@When("user changes profile type teen")
	public void user_changes_profile_type_teen() {
		profilepageview.select_profileType_Teen();
	}

	@When("user changes profile type kid")
	public void user_changes_profile_type_kid() {
		// profilepageview.select_profileType_Kid();
		profilepageview.select_kidProfile();
	}

	@Then("user is able to view confirmation message on changing profile type that interest survey preferences will be reset")
	public void user_is_able_to_view_confirmation_message_on_changing_profile_type_that_interest_survey_preferences_will_be_reset() {
		profilepageview.manageProfile_saveCTA();
		profilepageview.interestSurvey_popupDisplay();
	}

	@Then("user is able to confirm to change the profile type")
	public void user_is_able_to_confirm_to_change_the_profile_type() {
		profile.click_yesConfirmpopup();
	}

	@Then("user is able to cancel and discard the profile change")
	public void user_is_able_to_cancel_and_discard_the_profile_change() {
		profile.click_NoPopup();
	}

	@When("user selects Teen profile")
	public void user_selects_teen_profile() {
		profilepageview.select_profileType_Teen();
	}

	@When("user change profile type kid")
	public void user_change_profile_type_kid() {
		profilepageview.select_kidProfile();
	}

}