package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.RatingsAndReviews;

public class RatingsandReviews_Stepdef extends CommonAction {

	RatingsAndReviews ratings= new RatingsAndReviews(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());
	
	
	//146919
	
	@Given("user has not rated the title")
	public void user_has_not_rated_the_title() {
	    Logger.log("title is not rated");
	}

	@When("user is on title details screen not rated by him")
	public void user_is_on_title_details_screen_not_rated_by_him() {
	    ratings.click_title_in_Children();
	}

	@Then("user should be able to view rating for the title based on average of ratings input for that title by the patrons of that library")
	public void user_should_be_able_to_view_rating_for_the_title_based_on_average_of_ratings_input_for_that_title_by_the_patrons_of_that_library() {
	    Assert.assertTrue(isElementPresent(ratings.getView_reviews()));
	}

	@Then("user should be able to view rating with one star as minimum and {int} stars as maximum")
	public void user_should_be_able_to_view_rating_with_one_star_as_minimum_and_stars_as_maximum(Integer int1) {
	    Assert.assertTrue(isElementPresent(ratings.getView_ratings()));
	}

	@Then("system should show submitted ratings and calculate average rating based on the submitted ratings only and in blue colour")
	public void system_should_show_submitted_ratings_and_calculate_average_rating_based_on_the_submitted_ratings_only_and_in_blue_colour() {
		Assert.assertTrue(isElementPresent(ratings.getView_reviews()));
	}

	@Then("user should be able to view rating as text based on average of ratings input for that title by the patrons of that library from total number of ratings")
	public void user_should_be_able_to_view_rating_as_text_based_on_average_of_ratings_input_for_that_title_by_the_patrons_of_that_library_from_total_number_of_ratings() {
		Assert.assertTrue(isElementPresent(ratings.getView_reviews()));
	}
	
	//146920
	
	@Given("user has rated the title")
	public void user_has_rated_the_title() {
	    Logger.log("title is rated");
	}

	@When("user is on title details screen rated by him")
	public void user_is_on_title_details_screen_rated_by_him() {
	    ratings.click_rated_title();
	}

	@Then("user should be able to view rating for the title based on rating given by the user")
	public void user_should_be_able_to_view_rating_for_the_title_based_on_rating_given_by_the_user() {
		Assert.assertTrue(isElementPresent(ratings.getView_ratings()));
	}

	@Then("user should see the rating starts in the blue color when user has rated the title")
	public void user_should_see_the_rating_starts_in_the_blue_color_when_user_has_rated_the_title() {
		Assert.assertTrue(isElementPresent(ratings.getRating_stars()));
	}

	//146921
	
	@Given("user has not submitted the rating")
	public void user_has_not_submitted_the_rating() {
	    Logger.log("rating not submitted");
	}

	@When("user is on title details screen to submit rating")
	public void user_is_on_title_details_screen_to_submit_rating() {
	    ratings.click_title_to_rate();
	}

	@When("user clicks on start ratings")
	public void user_clicks_on_start_ratings() {
		ratings.click_start_ratings();
	}

	@Then("user should be able to view the drawer to select and submit the rating")
	public void user_should_be_able_to_view_the_drawer_to_select_and_submit_the_rating() {
		Assert.assertTrue(isElementPresent(ratings.getValidate_ratings_drawer()));
	}

	@Then("user should be able to select the rating to rate title given by the user in theme color")
	public void user_should_be_able_to_select_the_rating_to_rate_title_given_by_the_user_in_theme_color() {
	    ratings.click_stars();
	}

	@Then("user should be able to view the success toast message on successful submission of rating")
	public void user_should_be_able_to_view_the_success_toast_message_on_successful_submission_of_rating() {
		Assert.assertTrue(isElementPresent(ratings.getSuccess_toast_msg()));
	}

	@Then("success message should be {string}")
	public void success_message_should_be(String string) {
		ratings.validate_success_msg();
	}

	@Then("user should be able to view the rating submitted by the user on the title details page")
	public void user_should_be_able_to_view_the_rating_submitted_by_the_user_on_the_title_details_page() {
		Assert.assertTrue(isElementPresent(ratings.getView_ratings()));
	}
	
	@Given("user has submitted the rating")
	public void user_has_submitted_the_rating() {
	    Logger.log("rating submitted");
	}

	@When("user is on title details screen to update rating")
	public void user_is_on_title_details_screen_to_update_rating() {
		ratings.click_title_to_rate();
	}

	@Then("user should be able to update the rating given by the user in theme color")
	public void user_should_be_able_to_update_the_rating_given_by_the_user_in_theme_color() {
	    ratings.click_Stars_to_update();
	}

	//146922
	
	@When("user is on title details screen for which he has submitted reviews")
	public void user_is_on_title_details_screen_for_which_he_has_submitted_reviews() {
	    ratings.click_rated_title();
	}

	@When("user should be able to view number of reviews submitted for the title that means count displayed below the star rating")
	public void user_should_be_able_to_view_number_of_reviews_submitted_for_the_title_that_means_count_displayed_below_the_star_rating() {
		Assert.assertTrue(isElementPresent(ratings.getView_reviews()));
	}

	@Then("user should be able to view reviews submitted by the patrons and the user")
	public void user_should_be_able_to_view_reviews_submitted_by_the_patrons_and_the_user() {
	    ratings.click_details_Tab();
	}

	@Then("user should be able to view the review submitted by the user as first review")
	public void user_should_be_able_to_view_the_review_submitted_by_the_user_as_first_review() {
	    Logger.log("submitted review is viewed as first review");
	}
	
	@Given("rating and review is enable in admin")
	public void rating_and_review_is_enable_in_admin() {
	    Logger.log("ratings and reviews enabled");
	}

	@When("user is on title details screen for ebook")
	public void user_is_on_title_details_screen_for_ebook() {
		 ratings.click_rated_title();
	}

	@Then("user should be able to view rating star and review session in ebook titles details screen")
	public void user_should_be_able_to_view_rating_star_and_review_session_in_ebook_titles_details_screen() {
		Assert.assertTrue(isElementPresent(ratings.getView_reviews()));
		Assert.assertTrue(isElementPresent(ratings.getView_ratings()));
	}
	
	//146923
	
	@Given("user has submitted review for that title")
	public void user_has_submitted_review_for_that_title() {
	    Logger.log("review submitted");
	}
	
	@When("user is on title details screen for which review has been approved")
	public void user_is_on_title_details_screen_for_which_review_has_been_approved() {
	    ratings.click_rated_title();
	    ratings.click_details_Tab();
	}

	@When("user clicks on write review cta")
	public void user_clicks_on_write_review_cta() {
	    ratings.click_write_review_cta();
	}

	@Then("user should be navigated to review input screen with the review submitted by the user")
	public void user_should_be_navigated_to_review_input_screen_with_the_review_submitted_by_the_user() {
		Assert.assertTrue(isElementPresent(ratings.getValidate_review_input_screen()));
	}

	@Then("user should be able to view the message for review that has been approved by admin {string} which is approved")
	public void user_should_be_able_to_view_the_message_for_review_that_has_been_approved_by_admin_which_is_approved(String string) {
		ratings.validate_approved_msg();
	}

	@Then("user should not be able to edit the review once submitted")
	public void user_should_not_be_able_to_edit_the_review_once_submitted() {
	    Logger.log("review cannot be edited once submitted");
	}
	
	//146924
	
	@Given("admin has rejected the review submitted by the user")
	public void admin_has_rejected_the_review_submitted_by_the_user() {
		Logger.log("user has rejected the review");
	}

	@When("user navigates to title details screen for rejected review")
	public void user_navigates_to_title_details_screen_for_rejected_review() {
	    ratings.click_rejectedReview_title();
	    ratings.click_details_Tab();
	}

	@Then("user should be able to click write a review cta and navigate to write a review screen")
	public void user_should_be_able_to_click_write_a_review_cta_and_navigate_to_write_a_review_screen() {
		ratings.write_review();
		Assert.assertTrue(isElementPresent(ratings.getValidate_review_input_screen()));
	}

	@Then("user should be able to write maximum {int} characters review")
	public void user_should_be_able_to_write_maximum_characters_review(Integer int1) {
		Assert.assertTrue(isElementPresent(ratings.getCharacter_limit()));
	}

	@Then("user should be able to submit the review by clicking submit cta")
	public void user_should_be_able_to_submit_the_review_by_clicking_submit_cta() {
	    ratings.click_submit_cta();
	}

	@Then("system should submit the review to admin for approval")
	public void system_should_submit_the_review_to_admin_for_approval() {
	    Logger.log("system update the review");
	}
	
	//147167
	
	@Given("user has not submitted the review for the title yet")
	public void user_has_not_submitted_the_review_for_the_title_yet() {
	    Logger.log("review not submitted");
	}

	@When("user is on title details screen to submit review")
	public void user_is_on_title_details_screen_to_submit_review() {
	    ratings.click_title_to_review();
	    ratings.click_details_Tab();
	}

	@Then("user should be able to view success confirmation message of review submission")
	public void user_should_be_able_to_view_success_confirmation_message_of_review_submission() {
		ratings.click_submit_cta();
		Assert.assertTrue(isElementPresent(ratings.getSuccess_toast_msg()));
		
	}

	@Then("message should be {string} heading and {string}")
	public void message_should_be_heading_and(String string, String string2) {
		ratings.validate_success_msg_for_review_submit();
	}
	
	@When("user clicks on {string} title and navigates to titles details page")
	public void user_clicks_on_title_and_navigates_to_titles_details_page(String TitleType) {
		ratings.clickAlltypeTitle_NavTitleDetailspage(TitleType);
	}

	@When("user should be able to view star rating with count and Reviews")
	public void user_should_be_able_to_view_star_rating_with_count_and_reviews() {
	   ratings.verify_starRatingWithCount();
	}

	@When("system should show as {string} if the title being added new and user comes as first")
	public void system_should_show_as_if_the_title_being_added_new_and_user_comes_as_first(String verbiage) {
	  visibilityWait(ratings.StarRating_txt);
	  Assert.assertEquals(ratings.StarRating_txt.getText(), verbiage);
	  
	}

	@When("user by clicking on star rating system should open a window to provide rating")
	public void user_by_clicking_on_star_rating_system_should_open_a_window_to_provide_rating() {
	    jsClick(ratings.StarRating_txt);
	    visibilityWait(ratings.getValidate_review_input_screen());
	    Assert.assertEquals(ratings.getValidate_review_input_screen().isDisplayed(), true);
	}

	@When("user should be able to provide review in the same page")
	public void user_should_be_able_to_provide_review_in_the_same_page() {
	  SendKeysOnWebElement(ratings.getValidate_review_input_screen(), "write a review");
	  
	}
}


