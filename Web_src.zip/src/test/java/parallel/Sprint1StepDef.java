package parallel;

import java.io.IOException;



import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AdminDashboardPage;
import pom.kidszone.PatronDashboardPage;

public class Sprint1StepDef {

	Hooks hooks = new Hooks();
	AdminDashboardPage admin;
	PatronDashboardPage patron;
	

	@Given("Verify B&T Admin user able to login to B&T Admin Portal")
	public void verify_b_t_admin_user_able_to_login_to_b_t_admin_portal() throws InvalidFormatException, IOException {
//		hooks.launchBrowser();
//		DriverManager.getDriver().get("https://btadminqa.axis360.org/Admin/Login");
//		admin.btAdminLogin();
	}
	@When("Verify B&T Admin access to manage library site settings")
	public void verify_b_t_admin_access_to_manage_library_site_settings() {
		admin.accessbtAdminLibrarySettings();

	}

	@And("Verify B&T Admin user enable all sections in library settings")
	public void verify_b_t_admin_user_enable_all_sections_in_library_settings() {
		admin.btAdminEnableLibrarySetting();
	}

	@And("Verify  B&T Admin user disable all sections in library settings")
	public void verify_b_t_admin_user_disable_all_sections_in_library_settings() {
		admin.btAdminDisableLibrarySetting();
	}

	@And("Verify  B&T Admin user able to Logout from Application")
	public void verify_b_t_admin_user_able_to_logout_from_application() {
		admin.btAdminLogout();
	}

	@And("Verify Admin user able to login to Admin Portal")
	public void verify_admin_user_able_to_login_to_admin_portal() throws InvalidFormatException, IOException {
//		hooks.launchBrowser();
		DriverManager.getDriver().get("https://demo.axis360qa.baker-taylor.com/admin");
		admin = new AdminDashboardPage(DriverManager.getDriver());
		admin.adminLogin();

	}

	@And("Verify Admin access to manage library site settings")
	public void verify_admin_access_to_manage_library_site_settings() {
		admin.accessAdminLibrarySettings();
	}

	@And("Verify Admin user enable all sections in library settings")
	public void verify_admin_user_enable_all_sections_in_library_settings() {
		Logger.log("All sections enabled in library settings");
	}

	@And("Verify Admin user disable all sections in library settings")
	public void verify_admin_user_disable_all_sections_in_library_settings() {
		Logger.log("All sections disabled in library settings");
	}

	@And("Verify Admin user able to Logout from Application")
	public void verify_admin_user_able_to_logout_from_application() {
		admin.adminLogout();
	}

	@And("Verify Patron user able to Login to application with id and pin")
	public void verify_patron_user_able_to_login_to_application_with_id_and_pin() throws InvalidFormatException, IOException {
//		hooks.launchBrowser();
		DriverManager.getDriver().get("https://demo.axis360.baker-taylor.com/");
		patron = new PatronDashboardPage(DriverManager.getDriver());
		patron.patronLogin();
		
		
	}

	@And("Verify user able to login with only id")
	public void verify_user_able_to_login_with_only_id() {
	}

	@And("Verify user able to Login using SSO")
	public void verify_user_able_to_login_using_sso() {
	}

	@And("Verify user able to view updated ui in Login screen")
	public void verify_user_able_to_view_updated_ui_in_login_screen() {
	}

	@And("Verify user able to view updated ui in Registration screen")
	public void verify_user_able_to_view_updated_ui_in_registration_screen() {
	}

	@And("Verify user able to create new profile by giving all mandatory input fields")
	public void verify_user_able_to_create_new_profile_by_giving_all_mandatory_input_fields() {
	}

	@And("Verify user able to navigate Axis360  home screen based on profile selected and library subscription")
	public void verify_user_able_to_navigate_axis360_home_screen_based_on_profile_selected_and_library_subscription() {
	}

	@And("Verify user able to navigate Kids Zone home screen based on profile selected and library subscription")
	public void verify_user_able_to_navigate_kids_zone_home_screen_based_on_profile_selected_and_library_subscription() {
	}

	@And("Verify user able to view the existing profiles when I navigate to manage profile screen")
	public void verify_user_able_to_view_the_existing_profiles_when_i_navigate_to_manage_profile_screen() {
	}

	@And("Verify User able to edit existing profile details like display name, email, Phone\\(optional)")
	public void verify_user_able_to_edit_existing_profile_details_like_display_name_email_phone_optional() {
	}

	@And("Verify User able to update profile avatar by selecting from list of avatars available")
	public void verify_user_able_to_update_profile_avatar_by_selecting_from_list_of_avatars_available() {
	}

	@And("Verify user able to delete profile Photo")
	public void verify_user_able_to_delete_profile_photo() {
	}

	@And("User should be able to view delete the profile option")
	public void user_should_be_able_to_view_delete_the_profile_option() {
	}

	@Then("Verify user able to logout from application")
	public void verify_user_able_to_logout_from_application() {
	}

}
