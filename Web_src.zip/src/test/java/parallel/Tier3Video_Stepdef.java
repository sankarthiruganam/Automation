package parallel;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.MyshelfvideosVbooks;
import pom.kidszone.SearchResults_Vbooks;
import pom.kidszone.Tier3_Videobooks;

public class Tier3Video_Stepdef extends CommonAction {

	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	Tier3_Videobooks tier3 = new Tier3_Videobooks(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	MyshelfvideosVbooks myshelf = new MyshelfvideosVbooks(DriverManager.getDriver());
	
	Eyes eyes = EyesManager.getEyes();

	/*******************************************************/

	@Then("user should able to view checkout action CTA for available video title")
	public void user_should_able_to_view_checkout_action_cta_for_available_video_title() {
		visibilityWait(video.checkoutButton);
		javascriptScroll(video.checkoutButton);
		Assert.assertTrue(video.checkoutButton.isDisplayed());
	}

//	@Then("user should not able to view secondary cta")
//	public void user_should_not_able_to_view_secondary_cta() {
//	    Assert.assertEquals(isElementPresent(tier3.tier1_secodaryCTA_return), false);
//	}

	@When("user not started watching the checkout video title")
	public void user_not_started_watching_the_checkout_video_title() {
		Logger.log("user not started watching the checkout video title");
	}

	@When("user click on checkout button in Tier3 page")
	public void user_click_on_checkout_button_in_tier3_page() {
		tier3.clickCheckoutTier3();
	}

	@Then("user should able to view play action CTA for that video title")
	public void user_should_able_to_view_play_action_cta_for_that_video_title() {
		search. verify_PlayCTA();
	}

	@Then("user should able to view play CTA after renew the title")
	public void user_should_able_to_view_play_cta_after_renew_the_title() {
		Assert.assertTrue(isElementPresent(tier3.tier3_RenewCTA));
		//tier3.viewPlayCTA_afterRenewTitle();
	}

	@Then("user should able to view checkout CTA after return the title")
	public void user_should_able_to_view_checkout_cta_after_return_the_title() {
		tier3.viewCheckoutCTA_afterReturnTitle();
	}

	@When("user started watching and exit from checkout video title")
	public void user_started_watching_and_exit_from_checkout_video_title() {
		Logger.log("user started watching and exit from checkout video title");
	}

	@Then("user should able to view resume action CTA for that video title")
	public void user_should_able_to_view_resume_action_cta_for_that_video_title() {
		WaitForWebElement(video.ResumeCta);
		javascriptScroll(video.ResumeCta);
		Assert.assertTrue(video.ResumeCta.isDisplayed());
	}

	@Then("user should able to view resume CTA after renew the title")
	public void user_should_able_to_view_resume_cta_after_renew_the_title() {
		tier3.viewResumeCTA_afterRenewTitle();
	}

	@When("user started watching and finished the checkout video title")
	public void user_started_watching_and_finished_the_checkout_video_title() {
		tier3.viewCheckoutCTA_afterReturnTitle();
	}

	@Then("user should be able to view the video carousel for the related or suggested title")
	public void user_should_be_able_to_view_the_video_carousel_for_the_related_or_suggested_title() {
		tier3.view_SuggestedCarousel();
	}

	@Then("user should be able to view the VBook carousel for the related\\/suggested title")
	public void user_should_be_able_to_view_the_v_book_carousel_for_the_related_suggested_title() {
		tier3.view_SuggestedCarousel();
	}

	@Then("user should be able to view carousel only if the titles are available for the specific carousel")
	public void user_should_be_able_to_view_carousel_only_if_the_titles_are_available_for_the_specific_carousel() {
		tier3.verify_SuggestedTitle();
	}

	@Then("user should be able to view see all CTA in the carousel if title count is more than are equal to {int}")
	public void user_should_be_able_to_view_see_all_cta_in_the_carousel_if_title_count_is_more_than_are_equal_to(
			Integer int1) {
		tier3.verify_morethen10Tittle_SeeAllCTA();
	}

	@Then("user should get redirected to the List page by clicking on see all CTA")
	public void user_should_get_redirected_to_the_list_page_by_clicking_on_see_all_cta() {
		tier3.click_SeeAllCTA_tier3();
	}

	@Given("user click on see all CTA in video carousel")
	public void user_click_on_see_all_cta_in_video_carousel() {
		tier3.click_SeeAllCTA_tier3();
	}

	@Then("user should be able to navigate to video title list page")
	public void user_should_be_able_to_navigate_to_video_title_list_page() {
		Assert.assertTrue(tier3.Nav_tier2page.isDisplayed());
	}

	@Then("user should be able to view the list of video titles based on the configuraion in drupal")
	public void user_should_be_able_to_view_the_list_of_video_titles_based_on_the_configuraion_in_drupal() {
		Logger.log("user should be able to view the list of video titles based on the configuraion in drupal");
	}

//	@Given("user navigate to title detail page by click on VBook title card")
//	public void user_navigate_to_title_detail_page_by_click_on_v_book_title_card() {
//	    tier3.click_TitleCardTier1Vbook();
//	}

	@Then("user should be able to view the VBook Title detail page with Title Heading, Title Image, VBook Icon and Description")
	public void user_should_be_able_to_view_the_v_book_title_detail_page_with_title_heading_title_image_v_book_icon_and_description() {
		Assert.assertTrue(video.getTitleHeadingTier3().isDisplayed());
		Assert.assertTrue(video.getTitleImageTier3().isDisplayed());
		Assert.assertTrue(video.getVideoIconTier3().isDisplayed());
		// Assert.assertTrue(video.getTitleDescriptionTier3().isDisplayed());
	}

	@Then("user should be able to view VBook title details based on metadata")
	public void user_should_be_able_to_view_v_book_title_details_based_on_metadata() {
		Logger.log("user should be able to view VBook title details based on metadata");
	}

	@Then("user should be able to view default video title image if the title image is not available")
	public void user_should_be_able_to_view_default_video_title_image_if_the_title_image_is_not_available() {
		Logger.log("User able to view the default video title image if title image not available");
	}

	@Then("user should be able to view the video title icon")
	public void user_should_be_able_to_view_the_video_title_icon() {
		Assert.assertTrue(video.getVideoIconTier3().isDisplayed());
		Logger.log("User able to view the video title icon displayed");
	}

	@Then("user should be able to view the icon with blue background")
	public void user_should_be_able_to_view_the_icon_with_blue_background() {
		Logger.log("User able to view the icon with blue background");
	}

	@Then("user should be able to view the VBook title icon")
	public void user_should_be_able_to_view_the_v_book_title_icon() {
		Assert.assertTrue(search.getVbooks_icon().isDisplayed());
	}

	@Then("user should be able to view list details based on the API response")
	public void user_should_be_able_to_view_list_details_based_on_the_api_response() {
		search.titleDetailSectionDisplayed();
	}

	@Then("user should not be able to view list details if there is no response from API")
	public void user_should_not_be_able_to_view_list_details_if_there_is_no_response_from_api() {
		search.titleDetailSectionDisplayed();
	}

	@Then("user should be able to view the action CTA for Resume")
	public void user_should_be_able_to_view_the_action_cta_for_resume() {
		Assert.assertTrue(video.ResumeCta.isDisplayed());
	}
	
	@Then("user navigate to title detail page by click on video title card in Tier2")
	public void user_navigate_to_title_detail_page_by_click_on_video_title_card_in_tier2() {
		video.click_TitleCardTier2VBook();
	}
	
/***************************************visual ui********************************************************/
	
	
	@Then("capture the screenshot of Video Title detail page with Title Heading, Title Image, Video Icon and Description")
	public void capture_the_screenshot_of_video_title_detail_page_with_title_heading_title_image_video_icon_and_description() {
	   eyes.checkWindow(" Video Title detail page");
	}

	@Then("capture the screenshot of primary CTA")
	public void capture_the_screenshot_of_primary_cta() {
		 eyes.checkWindow("PrimaryCTA");
	}

	@Then("capture the screenshot of video title details based on metadata")
	public void capture_the_screenshot_of_video_title_details_based_on_metadata() {
		 eyes.checkWindow("video title details based on metadata");
	}

	@Then("capture the screenshot of video carousel for the related or suggested title")
	public void capture_the_screenshot_of_video_carousel_for_the_related_or_suggested_title() {
		eyes.checkWindow("video carousel for the related or suggested title");
	}

	@Then("capture the screenshot of VBook title card")
	public void capture_the_screenshot_of_v_book_title_card() {
		eyes.checkWindow("VBook title card");
	}

	@Then("capture the screenshot of VBook Title detail page with Title Heading, Title Image, VBook Icon and Description")
	public void capture_the_screenshot_of_v_book_title_detail_page_with_title_heading_title_image_v_book_icon_and_description() {
		eyes.checkWindow("VBook Title detail page with Title Heading, Title Image, VBook Icon and Description");
	}

	@Then("capture the screenshot of VBook title details based on metadata")
	public void capture_the_screenshot_of_v_book_title_details_based_on_metadata() {
		eyes.checkWindow("VBook title details based on metadata");
	}

	@Then("capture the screenshot of related\\/suggested title carousel")
	public void capture_the_screenshot_of_related_suggested_title_carousel() {
		eyes.checkWindow("related/suggested title carousel");
	}

	@Then("capture the screenshot of title detail page by click on suggested video title card")
	public void capture_the_screenshot_of_title_detail_page_by_click_on_suggested_video_title_card() {
		eyes.checkWindow("title detail page by click on suggested video title card");
	}

	@Then("capture the screenshot of VBook carousel for the related\\/suggested title")
	public void capture_the_screenshot_of_v_book_carousel_for_the_related_suggested_title() {
		eyes.checkWindow("vbook carousel for suggested video title card");
	}

	@Then("capture the screenshot of see all CTA of 3rd party carousel in library page for VBook")
	public void capture_the_screenshot_of_see_all_cta_of_3rd_party_carousel_in_library_page_for_v_book() {
		eyes.checkWindow("see all CTA of 3rd party carousel in library page for VBook");
	}

	@Then("capture the screenshot of see all CTA of VBook carousel in tier {int} page")
	public void capture_the_screenshot_of_see_all_cta_of_v_book_carousel_in_tier_page(Integer int1) {
		eyes.checkWindow("see all CTA of VBook carousel in tier 2 page");
	}

	@Then("capture the screenshot of VBook title list page")
	public void capture_the_screenshot_of_v_book_title_list_page() {
		eyes.checkWindow("VBook title list page");
	}

	@Then("capture the screenshot of VBook icon with blue background")
	public void capture_the_screenshot_of_v_book_icon_with_blue_background() {
		eyes.checkWindow("VBook icon with blue background");
	}

	@Then("capture the screenshot of VBooks title tier {int} page")
	public void capture_the_screenshot_of_v_books_title_tier_page(Integer int1) {
		eyes.checkWindow("VBooks title tier {int} page");
	}

	@Then("capture the screenshot of See all option for the Tier {int} page carousels")
	public void capture_the_screenshot_of_see_all_option_for_the_tier_page_carousels(Integer int1) {
		eyes.checkWindow("See all option for the Tier {int} page carousels");
	}

	@Then("capture the screenshot of Tier {int} page after clicking on see all")
	public void capture_the_screenshot_of_tier_page_after_clicking_on_see_all(Integer int1) {
		eyes.checkWindow("Tier 3 page after clicking on see all");
	}

	@Then("capture the screenshot of tier {int} title details page")
	public void capture_the_screenshot_of_tier_title_details_page(Integer int1) {
		eyes.checkWindow("Tier 3 details page");
	}

	
//	@Then("capture the screenshot of VBook categories in the carousel format")
//	public void capture_the_screenshot_of_v_book_categories_in_the_carousel_format() {
//		eyes.checkWindow("VBook categories in the carousel format");
//	}

	@Then("capture the screenshot of Tier {int} listing page")
	public void capture_the_screenshot_of_tier_listing_page(Integer int1) {
		eyes.checkWindow("Tier 2 listing page");
	}

	@Then("capture the screenshot of left and right arrow on the respective sides of carousel")
	public void capture_the_screenshot_of_left_and_right_arrow_on_the_respective_sides_of_carousel() {
		eyes.checkWindow("Tier2 left and right arrow on the respective sides of carousel");
	}

	@Then("capture the screenshot of Video carousel in tier {int} page")
	public void capture_the_screenshot_of_video_carousel_in_tier_page(Integer int1) {
		eyes.checkWindow("Video carousel in tier 2 page");
	}

	@Then("capture the screenshot of Popularity sort by default")
	public void capture_the_screenshot_of_Popularity_sort_by_default() {
		eyes.checkWindow("Popularity sort by default");
	}

	@Then("capture the screenshot of refiner section at left side of the page")
	public void capture_the_screenshot_of_refiner_section_at_left_side_of_the_page() {
		eyes.checkWindow("Tier2 Refiner section at left side of the page");
	}

	@Then("capture the screenshot of tier {int} page")
	public void capture_the_screenshot_of_tier_page(Integer int1) {
		eyes.checkWindow("Tier1 page");
	}

	@Then("capture the screenshot of checkout action CTA for available Video title")
	public void capture_the_screenshot_of_checkout_action_cta_for_available_video_title() {
		eyes.checkWindow("checkout action CTA for available Video title");
	}

	@Then("capture the screenshot of play action CTA for that Video title")
	public void capture_the_screenshot_of_play_action_cta_for_that_video_title() {
		eyes.checkWindow("play action CTA for that Video title");
	}

	@Then("capture the screenshot of title detail page by click on video title card in Tier2")
	public void capture_the_screenshot_of_title_detail_page_by_click_on_video_title_card_in_tier2() {
		eyes.checkWindow("title detail page by click on video title card in Tier2");
	}

	@Then("capture the screenshot of VBook title listed with Title Image")
	public void capture_the_screenshot_of_v_book_title_listed_with_title_image() {
		eyes.checkWindow("VBook title listed with Title Image");  
	}

	@Then("capture the screenshot of VBook icon in the title card")
	public void capture_the_screenshot_of_v_book_icon_in_the_title_card() {
		eyes.checkWindow("VBook icon in the title card");  
	}

	@Then("capture the screenshot of vbook refiner section to filter the titles")
	public void capture_the_screenshot_of_vbook_refiner_section_to_filter_the_titles() {
		eyes.checkWindow("vbook refiner section to filter the titles");  
	}

	@Then("capture the screenshot of see all CTA of 3rd party VBook carousel in library page")
	public void capture_the_screenshot_of_see_all_cta_of_3rd_party_v_book_carousel_in_library_page() {
		eyes.checkWindow("see all CTA of 3rd party VBook carousel in library page"); 
	}

	@Then("capture the screenshot of VBook carousel in tier {int} page")
	public void capture_the_screenshot_of_v_book_carousel_in_tier_page(Integer int1) {
		eyes.checkWindow("VBook carousel in tier 2 page"); 
	}

	@Then("capture the screenshot of checkout the available title")
	public void capture_the_screenshot_of_checkout_the_available_title() {
		eyes.checkWindow("checkout available title"); 
	}

	@Then("capture the screenshot of play action CTA for that VBook title")
	public void capture_the_screenshot_of_play_action_cta_for_that_v_book_title() {
		eyes.checkWindow("play action CTA for that VBook title"); 
	}

	@Then("capture the screenshot of VBook list page")
	public void capture_the_screenshot_of_v_book_list_page() {
		eyes.checkWindow("VBook list page"); 
	}

	@Then("capture the screenshot of publishers, Age range, language, author, illustrator, series or session name under refine section")
	public void capture_the_screenshot_of_publishers_age_range_language_author_illustrator_series_or_session_name_under_refine_section() {
		eyes.checkWindow("Refiner Details"); 
	}

	@Then("capture the screenshot of filter checkbox option and click search CTA")
	public void capture_the_screenshot_of_filter_checkbox_option_and_click_search_cta() {
		eyes.checkWindow("Tier2 filter checkbox option and click search CTA"); 
	}
	
	@Then("capture the screenshot of primary CTA of VBook")
	public void capture_the_screenshot_of_primary_cta_of_v_book() {
	    eyes.checkWindow("VBookPrimaryCTA");
	}
	
	@Then("user should be able to view primary CTA")
	public void user_should_be_able_to_view_primary_cta() {
	    javascriptScroll(tier3.tier3_CheckoutCTA);
	    Assert.assertTrue(tier3.tier3_CheckoutCTA.isDisplayed());
	}

}
