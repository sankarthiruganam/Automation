package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.History;
import pom.kidszone.Holds;
import pom.kidszone.LibrarySprint6B;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary_Guest;
import pom.kidszone.Profilecreation;
import pom.kidszone.Profileviewudpate;
import pom.kidszone.TitleAcrossProfile;
import pom.kidszone.TitleDetails;
import pom.kidszone.TitleListScreen;
import pom.kidszone.Wishlist;

public class TitleAcrossProfiles_StepDef extends CommonAction {
	Loginpageview login = new Loginpageview(DriverManager.getDriver());
	TitleListScreen titleList = new TitleListScreen(DriverManager.getDriver());
	TitleDetails title = new TitleDetails(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Profileviewudpate profilepageview = new Profileviewudpate(DriverManager.getDriver());
	TitleAcrossProfile titleAction = new TitleAcrossProfile(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	History history = new History(DriverManager.getDriver());
	MyLibrary_Guest library = new MyLibrary_Guest(DriverManager.getDriver());
	TitleDetails titleDetail = new TitleDetails(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	LibrarySprint6B library1 = new LibrarySprint6B(DriverManager.getDriver());

	@When("user clicks checkout cta for ebook title in always available carousal")
	public void user_clicks_checkout_cta_for_ebook_title_in_always_available_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_checkoutTitles();
	}

	@Then("user should be able to view the popup for informing user that title has already been checked out by other mapped profile")
	public void user_should_be_able_to_view_the_popup_for_informing_user_that_title_has_already_been_checked_out_by_other_mapped_profile() {
		Assert.assertEquals(isElementPresent(titleAction.getInformating_popup()), true);
	}

	@Then("user should be able to view add to Wishlist CTA")
	public void user_should_be_able_to_view_add_to_wishlist_cta() {
		Assert.assertTrue(titleAction.getBtn_addtowishlist().isDisplayed());

	}

	@Then("user should be able to view the popup for informing user that title has already been placed on hold by other mapped profile")
	public void user_should_be_able_to_view_the_popup_for_informing_user_that_title_has_already_been_placed_on_hold_by_other_mapped_profile() {
		titleAction.notificationPopUp();
	}

	@Then("user should able to view add to wishlist CTA in popup")
	public void user_should_able_to_view_add_to_wishlist_cta_in_popup() {
		Assert.assertTrue(titleAction.getAlertButton().isDisplayed());
	}

	@Then("user should be able to click on {string} icon to dismiss the popup")
	public void user_should_be_able_to_click_on_icon_to_dismiss_the_popup(String string) {
		Assert.assertTrue(titleAction.getCloseIcon().isDisplayed());
		titleAction.clickCloseIcon();
	}

	@When("User searching the title in Adult Profile")
	public void user_searching_the_title_in_adult_profile() {
		titleAction.titleNameSearchToAdult();
		jsClick(titleAction.search_titlecard);
		waitFor(2000);
	}

	@When("user search and checkout the title with multiple copies {string} and {string}")
	public void user_search_and_checkout_the_title_with_multiple_copies_and(String QAtitle, String UATtitle) {
		titleAction.searchTitle_Multitplecopy(QAtitle, UATtitle);
		jsClick(titleAction.firstTitle_searchscreen);
		titleAction.checkoutTitleinProfile();
	}

	@When("user search the same tilte in Kid profile {string} and {string}")
	public void user_search_the_same_tilte_in_kid_profile_and(String QAtitle, String UATtitle) {
		titleAction.switchKidProfile();
		titleAction.searchTitle_Multitplecopy(QAtitle, UATtitle);
		jsClick(titleAction.firstTitle_searchscreen);
	}

	@When("user search the same tilte in Teen profile {string} and {string}")
	public void user_search_the_same_tilte_in_teen_profile_and(String QAtitle, String UATtitle) {
		titleAction.switchTeenProfile();
		titleAction.searchTitle_Multitplecopy(QAtitle, UATtitle);
		jsClick(titleAction.firstTitle_searchscreen);
	}
	
	@When("user search the same tilte in Adult profile {string} and {string}")
	public void user_search_the_same_tilte_in_adult_profile_and(String QAtitle, String UATtitle) {
		titleAction.switchAdultProfile();
		titleAction.searchTitle(QAtitle, UATtitle);
		jsClick(titleAction.firstTitle_searchscreen);
	}

//	@When("user search and checkout the title with multiple copies {string}")
//	public void user_search_and_checkout_the_title_with_multiple_copies(String titleName) {
//		titleAction.searchTitle(titleName);
//		titleAction.checkoutTitleinProfile();
//	}
//
//	@When("user search the same tilte in Adult profile {string}")
//	public void user_search_the_same_tilte_in_adult_profile(String titleName) {
//		titleAction.switchAdultProfile();
//		titleAction.searchTitle(titleName);
//	}
//
//	@When("user search the same tilte in Kid profile {string}")
//	public void user_search_the_same_tilte_in_kid_profile(String titleName) {
//		titleAction.switchKidProfile();
//		titleAction.searchTitle(titleName);
//	}
//
//	@When("user search the same tilte in Teen profile {string}")
//	public void user_search_the_same_tilte_in_teen_profile(String titleName) {
//		titleAction.switchTeenProfile();
//		titleAction.searchTitle(titleName);
//	}

	@When("user click on the Checkout CTA")
	public void user_click_on_the_checkout_cta() {
		titleAction.checkoutTitle();
		WaitForWebElement(titleAction.getInformating_popup());
	}

	@Then("user should be able to click on {string} CTA to add the title to Wishlist for that profile")
	public void user_should_be_able_to_click_on_cta_to_add_the_title_to_wishlist_for_that_profile(String string) {
		titleAction.clickPrimaryCta();
		titleAction.clickWishListCta();
		Logger.log("User added the title to Wishlist");
	}

	@Then("User should be able to click on the {string} CTA to add the title to Wishlist for that profile")
	public void user_should_be_able_to_click_on_the_cta_to_add_the_title_to_wishlist_for_that_profile(String string) {
		titleAction.click_addtoWishlist();
	}

	@Then("user should be able to click on {string} icon to dismiss the popup and navigate back to the title screen")
	public void user_should_be_able_to_click_on_icon_to_dismiss_the_popup_and_navigate_back_to_the_title_screen(
			String string) {
		titleAction.wish_closeicon_popup();
	}

	@When("user clicks checkout cta for ebook title in curated carousal")
	public void user_clicks_checkout_cta_for_ebook_title_in_curated_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_checkoutTitles();
	}

	@Given("user clicks on myshelf option in menulist")
	public void user_clicks_on_myshelf_option_in_menulist() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
	}

	@Given("user lands on myshelf screen")
	public void user_lands_on_myshelf_screen() {
		Assert.assertTrue(isElementPresent(titleAction.getLanding_myshelfscreen()));
	}

	@When("user clicks checkout cta for ebook title")
	public void user_clicks_checkout_cta_for_ebook_title() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_checkoutTitles();
	}

	@Given("user clicks on wishlist from quick navigation in myshelf screen")
	public void user_clicks_on_wishlist_from_quick_navigation_in_myshelf_screen() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@Given("user should be able to view checkout as a primary cta if the title is available to checkout")
	public void user_should_be_able_to_view_checkout_as_a_primary_cta_if_the_title_is_available_to_checkout() {
		titleAction.click_adultWishlistcheckoutTitles();
	}

	@When("user clicks checkout cta for eAudio title")
	public void user_clicks_checkout_cta_for_e_audio_title() {

	}

	@Given("user clicks on checkout history from quick navigation in myshelf screen")
	public void user_clicks_on_checkout_history_from_quick_navigation_in_myshelf_screen() {
		history.clickHistory();
		titleAction.click_checkoutsonAnyscreen();
	}

	@Then("user should navigate back to the title screen")
	public void user_should_navigate_back_to_the_title_screen() {
//		title.clickCloseIcon();
		Assert.assertTrue(titleAction.titleDetails.isDisplayed());
	}

	@When("user should navigate to whishlist screen by clicking wishlist CTA in quick navigation")
	public void user_should_navigate_to_whishlist_screen_by_clicking_wishlist_cta_in_quick_navigation() {
		library.clickHamNew();
		holds.myShelfClick();
		wish.clickWishlist();
	}

	@When("user should be able to view Place Hold as a primary cta if the title is available to place on hold")
	public void user_should_be_able_to_view_place_hold_as_a_primary_cta_if_the_title_is_available_to_place_on_hold() {
		Assert.assertTrue(holds.getPrimaryCta().isDisplayed());
	}

	@When("user click on hold CTA")
	public void user_click_on_hold_cta() {
		titleAction.clickPrimaryCta();
	}

//	@Then("user should be able to click on {string} CTA")
//	public void user_should_be_able_to_click_on_cta(String string) {
//		
//	}

	@When("user should navigate to title details screen by clicking on any titles in library screen")
	public void user_should_navigate_to_title_details_screen_by_clicking_on_any_titles_in_library_screen() {
		titleAction.clickTitleCard();
	}

	@When("user should be able to view Place Hold as a primary cta if the titles is available to place on hold")
	public void user_should_be_able_to_view_place_hold_as_a_primary_cta_if_the_titles_is_available_to_place_on_hold() {
		titleAction.clickPrimaryCta();
		Assert.assertTrue(titleAction.getPrimaryCta().getText().contains("Place Hold"));
	}

	@Given("User switch to Teen Profile")
	public void user_switch_to_teen_profile() {
		titleAction.switchTeenProfile();
	}

	@Given("Place the Title on Hold")
	public void place_the_title_on_hold() {
		titleDetail.clickHoldTitle();
		titleDetail.clickHoldCta();
	}

	@When("User searching the title in Kid Profile")
	public void user_searching_the_title_in_kid_profile() {
		titleAction.titleNameSearchToKid();
		jsClick(titleAction.search_titlecard);
		waitFor(2000);
	}

	@When("User switch to Kid Profile")
	public void user_switch_to_kid_profile() {
		titleAction.switchKidProfile();
	}

	@When("user click on hold CTA in My Shelf screen")
	public void user_click_on_hold_cta_in_my_shelf_screen() {
		titleAction.clickPrimaryCtaMyShef();
	}

	@When("user click on hold CTA in title Detail Screen")
	public void user_click_on_hold_cta_in_title_detail_screen() {
		titleDetail.click_placeHold();
	}

	@When("User searching the title in Teen Profile")
	public void user_searching_the_title_in_teen_profile() {
		titleAction.titleNameSearchToTeen();
		jsClick(titleAction.search_titlecard);
		waitFor(2000);
		
		
	}

//	@When("user click on hold CTA in Wishlist screen")
//	public void user_click_on_hold_cta_in_wishlist_screen() {
//		title.clickPrimaryCtaMyShef();
//	}
//	
	@Given("adult user should be able to view checkout as a primary CTA if the title is available to checkout")
	public void adult_user_should_be_able_to_view_checkout_as_a_primary_cta_if_the_title_is_available_to_checkout() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_Adulthistory();

	}

	@Given("user clicks on history option in menulist")
	public void user_clicks_on_history_option_in_menulist() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		// hamburgerMenu.click_MyShelf();
		// hamburgerMenu.click_HamburgerMenu();
		profile.select_Kidprofile();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@Given("user should be able to view checkout as a secondary cta if the title is available to checkout")
	public void user_should_be_able_to_view_checkout_as_a_secondary_cta_if_the_title_is_available_to_checkout() {
		titleAction.click_Adulthistory();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
		history.clickHistory();
		titleAction.click_checkoutsonAnyscreen();
	}

	@Given("user clicks on wishlist option in menulist")
	public void user_clicks_on_wishlist_option_in_menulist() {
		profile.click_MenuOnly();
		profilepageview.menu_adultProfile();
		profile.select_Kidprofile();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
		wish.clickWishlist();
	}

	@Given("user lands on landing screen")
	public void user_lands_on_landing_screen() {
		Assert.assertTrue(isElementPresent(titleAction.getLanding_myshelfscreen()));
	}

	@Given("user clicks advanced search cta")
	public void user_clicks_advanced_search_cta() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
	}

	@Given("user eters any keyword and clicks search cta")
	public void user_eters_any_keyword_and_clicks_search_cta() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@Given("user navigates to search result screen")
	public void user_navigates_to_search_result_screen() {
		titleAction.click_checkoutTitles();
	}

	@Given("user clicks checkout cta if the title is available to checkout")
	public void user_clicks_checkout_cta_if_the_title_is_available_to_checkout() {
		titleAction.lib_clickCheckout();
	}

	@Given("user able to view the login prompt")
	public void user_able_to_view_the_login_prompt() {
		Assert.assertTrue(isElementPresent(titleAction.getLoginpage_popup()));
	}

	@And("user enter kidszone subscription only {string} and {string} ")
	public void user_enter_kidszone_subscription_only(String libraryid, String password) {

	}

	@Then("user lands on landing page")
	public void user_lands_on_landing_page() {
		Assert.assertEquals(admin.getAdvanced_search().isDisplayed(), true);
		System.out.println("user is on landing page");
	}

	@Then("user should be able to view the pop-up for informing user that title has already been checked out by other mapped profile")
	public void user_should_be_able_to_view_the_pop_up_for_informing_user_that_title_has_already_been_checked_out_by_other_mapped_profile() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_checkoutTitles();
	}

	@When("user enter kidszone subscription only {string}")
	public void user_enter_kidszone_subscription_only(String id) {
		login.loginwithoutPinRegistration(id);
	}

//Recommendation

	@Given("user switch to profile")
	public void user_switch_to_profile() throws InterruptedException {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		Thread.sleep(2000);
	}

	@Given("user clicks on advanced search option")
	public void user_clicks_on_advanced_search_option() {
		titleAction.click_purchaseRequest();
		// titleAction.click_advanceSearch();
	}

	@Given("user click on advanced search option")
	public void user_click_on_advanced_search_option() {
		titleAction.click_advanceSearch();
	}

	@Given("user search the title with titles to recommend option")
	public void user_search_the_title_with_titles_to_recommend_option() {
		titleAction.Search_RecommendedTitles();
	}

	@Given("user navigates to result screen")
	public void user_navigates_to_result_screen() {
		Assert.assertTrue(isElementPresent(titleAction.getSearch_resultScreen()));
	}

	@Given("user click purchase Request Cta for Advance search")
	public void user_click_purchase_request_cta_for_advance_search() {
		visibilityWait(library1.purchaseReq);
		jsClick(library1.purchaseReq);
		library1.click_searchCTA();
	}

	@When("user clicks on purchase Request CTA for a title")
	public void user_clicks_on_purchase_request_cta_for_a_title() {
		// titleAction.click_purchaseRequest();
		titleAction.nav_Recommendation();
	}

	@Given("user clicks on purchase Request CTA")
	public void user_clicks_on_purchase_request_cta() {
		titleAction.clickon_purchaseRequest();
	}

	@Then("user should be able to view the pop-up for informing user that title has already been requested for purchase by other mapped profile")
	public void user_should_be_able_to_view_the_pop_up_for_informing_user_that_title_has_already_been_requested_for_purchase_by_other_mapped_profile() {
		WaitForWebElement(titleAction.getInformating_popup());
		Assert.assertEquals(isElementPresent(titleAction.getInformating_popup()), true);
	}

	@Then("user should be able to click on {string} icon to dismiss the pop-up and navigate back to the title screen")
	public void user_should_be_able_to_click_on_icon_to_dismiss_the_pop_up_and_navigate_back_to_the_title_screen(
			String string) {

	}

	@When("kid user clicks checkout cta for ebook title in always available carousal")
	public void kid_user_clicks_checkout_cta_for_ebook_title_in_always_available_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		checkout.click_checkout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_kidcheckoutTitles();
	}

	@When("kid user clicks checkout cta for ebook title in curated carousal")
	public void kid_user_clicks_checkout_cta_for_ebook_title_in_curated_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_kidcheckoutTitles();
	}

	@When("kid user clicks checkout cta for ebook title")
	public void kid_user_clicks_checkout_cta_for_ebook_title() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_kidcheckoutTitles();
	}

	@Given("kid user clicks on wishlist from quick navigation in myshelf screen")
	public void kid_user_clicks_on_wishlist_from_quick_navigation_in_myshelf_screen() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		/*
		 * hamburgerMenu.click_HamburgerMenu(); hamburgerMenu.click_Profiles();
		 * profile.select_Teenprofile(); hamburgerMenu.click_HamburgerMenu();
		 * hamburgerMenu.click_MyShelf(); titleAction.click_wishlist();
		 */
	}

	@Given("kids user should be able to view checkout as a primary cta if the title is available to checkout")
	public void kids_user_should_be_able_to_view_checkout_as_a_primary_cta_if_the_title_is_available_to_checkout() {
		titleAction.click_kidWishlistcheckoutTitles();
	}

	@Given("kid user should be able to view checkout as a primary CTA if the title is available to checkout")
	public void kid_user_should_be_able_to_view_checkout_as_a_primary_cta_if_the_title_is_available_to_checkout() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
	}

	@Given("kid user clicks advanced search cta")
	public void kid_user_clicks_advanced_search_cta() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		titleAction.lib_clickCheckout();
	}

	@Given("kid user navigates to search result screen")
	public void kid_user_navigates_to_search_result_screen() {
		titleAction.click_kidcheckoutTitles();
	}

	@Then("kid user should be able to view the pop-up for informing user that title has already been checked out by other mapped profile")
	public void kid_user_should_be_able_to_view_the_pop_up_for_informing_user_that_title_has_already_been_checked_out_by_other_mapped_profile() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_kidcheckoutTitles();
	}

	@When("teen user clicks checkout cta for ebook title in always available carousal")
	public void teen_user_clicks_checkout_cta_for_ebook_title_in_always_available_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_teencheckoutTitles();
	}

	@When("teen user clicks checkout cta for ebook title in curated carousal")
	public void teen_user_clicks_checkout_cta_for_ebook_title_in_curated_carousal() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_teencheckoutTitles();
	}

	@When("teen user clicks checkout cta for ebook title")
	public void teen_user_clicks_checkout_cta_for_ebook_title() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_teencheckoutTitles();
	}

	@Given("teen user clicks on wishlist from quick navigation in myshelf screen")
	public void teen_user_clicks_on_wishlist_from_quick_navigation_in_myshelf_screen() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
	}

	@Given("teens user should be able to view checkout as a primary cta if the title is available to checkout")
	public void teens_user_should_be_able_to_view_checkout_as_a_primary_cta_if_the_title_is_available_to_checkout() {
		titleAction.click_teenWishlistcheckoutTitles();
	}

	@Given("teen user clicks advanced search cta")
	public void teen_user_clicks_advanced_search_cta() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
	}

	@Given("teen user navigates to search result screen")
	public void teen_user_navigates_to_search_result_screen() {
		titleAction.click_teencheckoutTitles();
	}

	@Then("teen user should be able to view the pop-up for informing user that title has already been checked out by other mapped profile")
	public void teen_user_should_be_able_to_view_the_pop_up_for_informing_user_that_title_has_already_been_checked_out_by_other_mapped_profile() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		titleAction.lib_clickCheckout();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Checkouts();
		titleAction.click_kidcheckoutTitles();
	}
}
