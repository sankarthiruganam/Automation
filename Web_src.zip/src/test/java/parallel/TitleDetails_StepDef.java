package parallel;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import eyesmanager.EyesManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Login;
import pom.kidszone.MyLibrary_Guest;
import pom.kidszone.TitleDetail;
import pom.kidszone.TitleDetails;
import pom.kidszone.TitleListScreen;

public class TitleDetails_StepDef extends CommonAction {
	Login login = new Login(DriverManager.getDriver());
	TitleListScreen titleList = new TitleListScreen(DriverManager.getDriver());
	TitleDetails title = new TitleDetails(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	MyLibrary_Guest library = new MyLibrary_Guest(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	TitleDetail title1 = new TitleDetail(DriverManager.getDriver());
	
	Eyes eyes = EyesManager.getEyes();

	@Given("user taps on the title card of an ebook")
	public void user_taps_on_the_title_card_of_an_ebook() {
		title.searchEbook();
		title.clickEbook();
	}

	@Given("user search the title")
	public void user_search_the_title() {
		title.click_AdvanceSearchtitle();
		title.click_synapsisTitle();
	}

	@Given("user search the audio title")
	public void user_search_the_audio_title() {
		title.click_AdvanceSearchaudiotitle();
		title.click_synapsisTitle();
	}

	@When("user is on title details screen of an ebook")
	public void user_is_on_title_details_screen_of_an_ebook() {
		Assert.assertEquals(isElementPresent(title.getTitleDetailScreen()), true);
	}

//	@Then("user should be able to view recommended titles based on the title being viewed")
//	public void user_should_be_able_to_view_recommended_titles_based_on_the_title_being_viewed() {
//		title.clickMoreLikeThisCta();
//		title.recommendedTitleSection();
//	}

	@Then("user should be able to view {string} displayed if no title to be recommended")
	public void user_should_be_able_to_view_displayed_if_no_title_to_be_recommended(String text) {
		title.noRecommendedTitles(text);
	}

	@Then("user should be able to view recommended titles as first carousel of {string} tab")
	public void user_should_be_able_to_view_recommended_titles_as_first_carousel_of_tab(String text) {
		Assert.assertEquals(title.getMoreLikeThisCTA().getText(), text);
	}

	@Then("user should be able to view each title as title card")
	public void user_should_be_able_to_view_each_title_as_title_card() {
		Logger.log("UI Verified Manually");
	}

	@Given("user taps on the title card of an available audio book")
	public void user_taps_on_the_title_card_of_an_available_audio_book() {
		title.searchAudiobook();
		title.Click_availableAudioBook();
	}

	@Given("user taps on the title card of an audio book")
	public void user_taps_on_the_title_card_of_an_audio_book() {
		title.searchAudiobook();
		title.Click_AudioBook();
	}

	@When("user is on title details screen of an audio book")
	public void user_is_on_title_details_screen_of_an_audio_book() {
		Assert.assertEquals(title.getTitleDetailScreen().isDisplayed(), true);
	}

	@Then("user should be able to view size of the title file")
	public void user_should_be_able_to_view_size_of_the_title_file() {
		title.clickDetailsTab();
		Assert.assertTrue(title.getDownLoadSize().isDisplayed());
		Assert.assertEquals(title.getDownLoadSize().getText().contains("DOWNLOAD SIZE"), true);
	}

	@When("user taps on the title card of an ebook oldUI")
	public void user_taps_on_the_title_card_of_an_ebook_old_ui() {
		library.clickTitleOldUi();
	}

	@Then("user should be navigated to title details screen OldUI")
	public void user_should_be_navigated_to_title_details_screen_old_ui() {
		Assert.assertTrue(library.getTitleDetailsOldUi().isDisplayed());
	}

	@Then("user should be able to view text to speech for the titles that have text to speech")
	public void user_should_be_able_to_view_text_to_speech_for_the_titles_that_have_text_to_speech() {
		title.textToSpeech();
	}

	@Then("user should not be able to view text to speech if text to speech is not available for the title or if eRead Along is available")
	public void user_should_not_be_able_to_view_text_to_speech_if_text_to_speech_is_not_available_for_the_title_or_if_e_read_along_is_available() {
		title.textToSpeech();
	}

	@Then("user should be able to view text to speech for the titles that have text to speech OldUI")
	public void user_should_be_able_to_view_text_to_speech_for_the_titles_that_have_text_to_speech_old_ui() {
		Logger.log("Text to speech text is unavailable for adult theme");
	}

	@Then("user should be able to view duration of the audio book")
	public void user_should_be_able_to_view_duration_of_the_audio_book() {
		//title.clickDetailsTab();
		Assert.assertEquals(title.getDuration().isDisplayed(), true);
	}

//	@Then("user should be able to view duration as {string}")
//	public void user_should_be_able_to_view_duration_as(String text) {
//		Logger.log("User able to view only Hours if no minutes available");
//	}

	@Then("user should be able to view duration as {string} if no minute available to be displayed")
	public void user_should_be_able_to_view_duration_as_if_no_minute_available_to_be_displayed(String text) {
		Logger.log("user able to view duration as Hours if no minute available to be displayed");
	}

	@Then("user should be able to view duration as {string} if title is less than one hour")
	public void user_should_be_able_to_view_duration_as_if_title_is_less_than_one_hour(String text) {
		title.hrsAndMinute();
	}

	@Then("user should be able to view edition for the audio book")
	public void user_should_be_able_to_view_edition_for_the_audio_book() {
		title.clickDetailsTab();
		Assert.assertEquals(title.getEdition().isDisplayed(), true);
	}

	@Then("user should be able to view narrator names for the audio book titles as read by narrated by attribute")
	public void user_should_be_able_to_view_narrator_names_for_the_audio_book_titles_as_read_by_narrated_by_attribute() {
		//Assert.assertEquals(title.getReadBy().isDisplayed(), true);
		title.click_DetailsTab();
		Assert.assertTrue(title.titleDetail_ListenCta.isDisplayed());
		Assert.assertEquals(title.getNarratedBy().isDisplayed(), true);
	}

	@Then("user should be able to view narrator names for Read By Narrated by as ctas")
	public void user_should_be_able_to_view_narrator_names_for_read_by_narrated_by_as_ctas() {
		Assert.assertEquals(title.getReadByAuthor().isDisplayed(), true);
		Assert.assertEquals(title.getNarratedByAuthor().isDisplayed(), true);
	}

	@Then("user should able to see the length of an audio book")
	public void user_should_able_to_see_the_length_of_an_audio_book() {
		Assert.assertEquals(title.getDurationOfAudioBook().isDisplayed(), true);
	}

	@Then("user should be able to click on narrator name")
	public void user_should_be_able_to_click_on_narrator_name() {
		title.clickNarrator();
	}

	@Then("navigate to search results screen with search results for that narrator")
	public void navigate_to_search_results_screen_with_search_results_for_that_narrator() {
		Assert.assertEquals(title.getSearchResultsPage().isDisplayed(), true);
	}

	@When("user taps on the title card of an ebook with a hold position")
	public void user_taps_on_the_title_card_of_an_ebook_with_a_hold_position() {
		title.searchEbook();
		title.clickHoldTitle();
		title.clickHoldCta();
	}

	@Then("user taps on details tab")
	public void user_taps_on_details_tab() {
		title.clickDetailsTab();
	}

	@Then("user should be able to view hold position of the patron for the title")
	public void user_should_be_able_to_view_hold_position_of_the_patron_for_the_title() {
		//title.waitForHoldPosition();
		visibilityWait(title.getHoldPosition());
		Assert.assertTrue(title.getHoldPosition().isDisplayed());
	}

	@Then("user should be able to view tool tip for the hold position")
	public void user_should_be_able_to_view_tool_tip_for_the_hold_position() {
		Assert.assertTrue(title.getPatronHoldPosition().isDisplayed());
	}

	@Then("user taps on the tool tip")
	public void user_taps_on_the_tool_tip() {
		Assert.assertTrue(title.getToolTipIcon().isDisplayed());
	}

	@Then("user should be able to view the tool tip verbiage displayed as {string}")
	public void user_should_be_able_to_view_the_tool_tip_verbiage_displayed_as(String text) {
//		title.inspToolTip(text);
		title.clickToolTip(text);
	}

	@Then("Remove the title from Hold")
	public void remove_the_title_from_hold() {
		title.clickRemoveHoldTitleDetails();
	}

	@Then("user should be able to view patrons on hold count for the title")
	public void user_should_be_able_to_view_patrons_on_hold_count_for_the_title() {
		try {
			Assert.assertTrue(title.getPatronOnHold().isDisplayed());
			Assert.assertTrue(title.getPatronHoldCount().isDisplayed());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user should be able to view {string} for the title i.e. {string}")
	public void user_should_be_able_to_view_for_the_title_i_e(String text, String text1) {
		try {
			javascriptScroll(title.getCopiesAvailable());
			Assert.assertTrue(title.getCopiesAvailable().isDisplayed());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(title.getCopiesAvailable().getText());
//		System.out.println(text+"0 of 1"+text1);
//		title.copiesInspect(text, text1);
		// Assert.assertEquals(title.getCopiesAvailable().getText().contains(text +
		// "[0-9]" + " of " + "[0-9]" + text1),true);
	}

	@When("user taps on the title card of an ebook with unlimited copies for always available collection")
	public void user_taps_on_the_title_card_of_an_ebook_with_unlimited_copies_for_always_available_collection() {
		title.searchAudiobook();
		title.Click_availableAudioBook();
	}

//	@Then("user should be able to view {string} for the title i.e. unlimited {string}")
//	public void user_should_be_able_to_view_for_the_title_i_e_unlimited(String text, String text1) {
//		Assert.assertEquals(title.getCopiesAvailable().getText().contains(text1), true);
//		Assert.assertEquals(title.getCopiesAvailable().getText().contains("9999"), true);
//	}

	@Then("user should be able to view {string} for the title i.e. unlimited copies")
	public void user_should_be_able_to_view_for_the_title_i_e_unlimited_copies(String text) {
		Assert.assertEquals(title.getCopiesAvailable().getText().contains(text), true);
	}

	@When("user taps on the title card of an ebook with unlimited copies for general collection")
	public void user_taps_on_the_title_card_of_an_ebook_with_unlimited_copies_for_general_collection() {
		title.Click_availableAudioBook();
		Assert.assertEquals(title.getCopiesAvailable().isDisplayed(), true);
	}

	@When("user taps on the title card of an audio book with unlimited copies for general collection")
	public void user_taps_on_the_title_card_of_an_audio_book_with_unlimited_copies_for_general_collection() {
		title.Click_availableAudioBook();
		Assert.assertEquals(title.getCopiesAvailable().isDisplayed(), true);
	}

	@When("user taps on the title card of an audio book with unlimited copies for always available collection")
	public void user_taps_on_the_title_card_of_an_audio_book_with_unlimited_copies_for_always_available_collection() {
		title.searchAudiobook();
		title.Click_availableAudioBook();
		Assert.assertEquals(title.getCopiesAvailable().isDisplayed(), true);
	}

	@Then("user should be able to view Level {int} and Level {int} subjects mapped to the title based on bisac")
	public void user_should_be_able_to_view_level_and_level_subjects_mapped_to_the_title_based_on_bisac(Integer int1,
			Integer int2) {
		title.clickDetailsTab();
		Assert.assertEquals(title.getSubjectColumn().isDisplayed(), true);
		Assert.assertEquals(title.getSubjectLevels().isDisplayed(), true);
	}

	@Then("user should be able to view subjects as cta")
	public void user_should_be_able_to_view_subjects_as_cta() {
		Logger.log("User able to view subjects as CTAs");
	}

	@Then("user should be able to click on a subject")
	public void user_should_be_able_to_click_on_a_subject() {
		title.clickSubjects();
	}

	@Then("navigate to titles list screen for that subject")
	public void navigate_to_titles_list_screen_for_that_subject() {
		Assert.assertEquals(title.getTitleDetailsPage().isDisplayed(), true);
	}

	@Then("user should be able to view subtitle of an ebook if available")
	public void user_should_be_able_to_view_subtitle_of_an_ebook_if_available() {
		title.verify_subTitle();
	}

	@And("user should be able to view subtitle of an audio book if available")
	public void user_should_be_able_to_view_subtitle_of_an_audio_book_if_available() {
		title.verify_subTitle();
	}

	@And("user should not be able to view subtitle if the ebook does not have a subtitle")
	public void user_should_not_be_able_to_view_subtitle_if_the_ebook_does_not_have_a_subtitle() {
		Assert.assertEquals(isElementPresent(title.txt_subtitle), false);
	}

	@And("user should be able to view title cover image")
	public void user_should_be_able_to_view_title_cover_image() throws Throwable {
		Assert.assertTrue(isElementPresent(title.getImg_titleDetails()));
	}

	@And("user should be able to view the ebook format icon on the title cover image")
	public void user_should_be_able_to_view_the_ebook_format_icon_on_the_title_cover_image() {
		Assert.assertTrue(isElementPresent(title.getImg_ebookformaticon()));
	}

	@And("user should be able to view the audio book format icon on the title cover image")
	public void user_should_be_able_to_view_the_audio_book_format_icon_on_the_title_cover_image() {
		Assert.assertTrue(title.titleDetail_eAudio_formatIcon.isDisplayed());
	}

	@Then("user should be able to view the title reading progress based on last read location in the title")
	public void user_should_be_able_to_view_the_title_reading_progress_based_on_last_read_location_in_the_title() {
		title.view_readingProgress();
		// Assert.assertEquals(isElementPresent(title.getTitleDetails_progressbar()),
		// true);
	}

	@Then("user should be able to view the title reading progress based on last listened location in the title")
	public void user_should_be_able_to_view_the_title_reading_progress_based_on_last_listened_location_in_the_title() {
		title.view_readingProgress();
		// Assert.assertEquals(isElementPresent(title.getTitleDetails_progressbar()),
		// true);
	}

	@Then("user should not be able to view the reading progress if insights preferences are disabled in the user preferences")
	public void user_should_not_be_able_to_view_the_reading_progress_if_insights_preferences_are_disabled_in_the_user_preferences() {
		Assert.assertEquals(isElementPresent(title.getTitleDetails_progressbar()), false);
	}

	@Then("user should not be able to view the reading progress if title progress or last read location of the title is not available")
	public void user_should_not_be_able_to_view_the_reading_progress_if_title_progress_or_last_read_location_of_the_title_is_not_available() {
		Assert.assertEquals(isElementPresent(title.getTitleDetails_progressbar()), false);
	}

	@When("user taps on the available title card of an ebook")
	public void user_taps_on_the_available_title_card_of_an_ebook() {
		title.searchEbook();
		title.Click_availableEbook();
	}

	@Then("user should be able to view primary and secondary action when title has more than one actions available other than add or remove to wishlist and share")
	public void user_should_be_able_to_view_primary_and_secondary_action_when_title_has_more_than_one_actions_available_other_than_add_or_remove_to_wishlist_and_share() {
		 title.verify_PrimaryCTA();
	}


	@Then("user should not be able to view wishlist cta and share cta as separate icons when secondary cta is shown")
	public void user_should_not_be_able_to_view_wishlist_cta_and_share_cta_as_separate_icons_when_secondary_cta_is_shown() {
		title.verify_notshowingWishList();
	}

	@When("user taps on the avilable title card of an audio book")
	public void user_taps_on_the_avilable_title_card_of_an_audio_book() {
		title.searchEbook();
		title.Click_availableAudioBook();
	}

	@Then("user should be able to view wishlist cta on title details screen when title has only one action available other than add to wishlist and share")
	public void user_should_be_able_to_view_wishlist_cta_on_title_details_screen_when_title_has_only_one_action_available_other_than_add_to_wishlist_and_share() {
		title.primaryActionas_checkoutORplaceHold();
	}

	@Then("user should be able to view wishlist CTA on title details screen when title has only one action available other than add to wishlist and share")
	public void user_should_be_able_to_view_wishlist_CTA_on_title_details_screen_when_title_has_only_one_action_available_other_than_add_to_wishlist_and_share() {
		title.click_checkout();
	}

	@Then("user should be able to view the wishlist icon for title not in wishlist")
	public void user_should_be_able_to_view_the_wishlist_icon_for_title_not_in_wishlist() {
		Logger.log("cannot automate wishlist icon for title not in wishlist");
	}

	@Then("user should be able to click the icon to add a title to wishlist")
	public void user_should_be_able_to_click_the_icon_to_add_a_title_to_wishlist() {
		title.add_wishlist();
	}

	@Then("User should be able to view the confirmation toast message for adding title from the wishlist")
	public void user_should_be_able_to_view_the_confirmation_toast_message_for_adding_title_from_the_wishlist() {
		Logger.log("wrongly displayed confirmation toast message");
	}

	@Then("user should be able to view wishlist cta on title details screen when title has only one action available other than remove to wishlist and share")
	public void user_should_be_able_to_view_wishlist_cta_on_title_details_screen_when_title_has_only_one_action_available_other_than_remove_to_wishlist_and_share() {
		title.primaryActionas_checkoutORplaceHold();
	}

	@Then("user should be able to view the wishlist icon for title that is in the wishlist")
	public void user_should_be_able_to_view_the_wishlist_icon_for_title_that_is_in_the_wishlist() {
		Assert.assertTrue(isElementPresent(title.add_wishlist));
	}

	@Then("user should be able to click the icon to remove a title from wishlist and view the icon for the title not in the wishlist")
	public void user_should_be_able_to_click_the_icon_to_remove_a_title_from_wishlist_and_view_the_icon_for_the_title_not_in_the_wishlist() {
		title.remove_wishList();
	}

	@Then("user should be able to view the confirmation toast message for removing title from the wishlist")
	public void user_should_be_able_to_view_the_confirmation_toast_message_for_removing_title_from_the_wishlist() {
		Logger.log("wrongly displayed confirmation toast message");
	}

	@Then("user should not be able to view the wishlist icon for the title checked out")
	public void user_should_not_be_able_to_view_the_wishlist_icon_for_the_title_checked_out() {
		Assert.assertEquals(isElementPresent(title.add_wishlist), false);
	}

	@Then("user should be able to view primary and secondary actions for ebooks when title available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_available() {
//		Logger.log("user able to view checkout has primary actions");
		// title.primaryActionas_checkoutORplaceHold();
		visibilityWait(title.titleDetail_ReadCTa);
		Assert.assertTrue(title.titleDetail_ReadCTa.isDisplayed());
		jsClick(title.titleDetails_dropdown_moreoption);
		Assert.assertTrue(checkout.renew_option.isDisplayed());
		Assert.assertTrue(checkout.return_option.isDisplayed());
		jsClick(checkout.return_option);
		visibilityWait(checkout.return_confirm);
		jsClick(checkout.return_confirm);
	}

	@Then("user should be able to see checkout primary action")
	public void user_should_be_able_to_see_checkout_primary_action() {
		Assert.assertTrue(title.titleDetails_Checkout.isDisplayed());
		jsClick(title.titleDetails_Checkout);
	}

	@Then("click on {string} and add the title to the wishlist")
	public void click_on_and_add_the_title_to_the_wishlist(String string) {
		title.click_addWishlistCTA();
	}

	@Then("click on {string} and remove the title from the wishlist")
	public void click_on_and_remove_the_title_from_the_wishlist(String string) {
		title.click_removeWishlist();
	}

	@Then("user should be able to see {string}")
	public void user_should_be_able_to_see(String string) {
		title.verify_share();
	}

	@Then("user should be able to view primary and secondary actions for audio book when title available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_available() {
		title.primaryActionas_checkoutORplaceHold();
	}

	@When("user taps on the not avilable title card of an ebook")
	public void user_taps_on_the_not_avilable_title_card_of_an_ebook() {
		title.searchEbook();
		title.click_placeHoldtitle();
	}

	@Then("user should be able to view primary and secondary actions for ebooks when title not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_not_available() {
//		javascriptScroll(title.titleDetails_placeHold);
		// title.primaryActionas_checkoutORplaceHold();
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 25);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete';"));
		javascriptScroll(holds.primaryCta_RemoveHold);
		Assert.assertTrue(holds.primaryCta_RemoveHold.isDisplayed());
		visibilityWait(checkout.click_second_moreOption);
		jsClick(checkout.click_second_moreOption);
		visibilityWait(holds.secondaryCta_SuspendHold);
		Assert.assertTrue(holds.secondaryCta_SuspendHold.isDisplayed());
		jsClick(checkout.click_second_moreOption);
		
	}

	@Then("user should be able to click on {string} and put title on hold")
	public void user_should_be_able_to_click_on_and_put_title_on_hold(String string) {
		title.removeHoldAndPlaceHold();
		visibilityWait(title.titleDetails_placeHold);
		jsClick(title.titleDetails_placeHold);
		waitFor(2000);
		// Assert.assertTrue(isElementPresent(title.titleDetails_placeHold));
	}

	@Then("user click on Add to Wishlist and add the title to the wishlist")
	public void user_click_on_add_to_wishlist_and_add_the_title_to_the_wishlist() {
		title.addtoWishlist_placeHold();
	}

	@Then("user click on Remove From Wishlist and remove the title from the wishlist")
	public void user_click_on_remove_from_wishlist_and_remove_the_title_from_the_wishlist() {
		title.removeWishlist_placeHold();
	}

	@When("user taps on the not avilable title card of an audio book")
	public void user_taps_on_the_not_avilable_title_card_of_an_audio_book() {
		title.searchAudiobook();
		title.Click_AudioBook();
	}

	@Then("user should be able to view primary and secondary actions for audio book when title not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_not_available() {
		title.primaryActionas_checkoutORplaceHold();
	}

	@Then("user should be able to view primary and secondary actions for ebooks when title on hold")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_on_hold() {
		Assert.assertTrue(isElementPresent(title.titleDetails_placeHold));
	}

	@Then("user should be able to click on {string} and remove hold put on the title")
	public void user_should_be_able_to_click_on_and_remove_hold_put_on_the_title(String string) {
		title.click_placeHold();
		Logger.log("user is able to view remove hold option");

	}

	@Then("user should be able to click on Suspend Hold and suspend the hold temporarily for the title put on hold")
	public void user_should_be_able_to_click_on_suspend_hold_and_suspend_the_hold_temporarily_for_the_title_put_on_hold() {
		title.click_suspendHold();
	}

	@Then("user should be able to view primary and secondary actions for audio book when title on hold")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_on_hold() {
		Logger.log("User able to view the Priamry and Secondary actions for Audio Book");
	}

	@Then("user should be able to view primary and secondary actions for ebooks when title hold suspended")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_hold_suspended() {
		Assert.assertTrue(isElementPresent(title.titleDetails_placeHold));
	}

	@Then("user should be able to view primary and secondary actions for audio book when title hold suspended")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_hold_suspended() {
		Logger.log("User able to view the Priamry and Secondary actions for Audio Book");
	}

	@Then("should be able to click on {string} and resume the suspended hold for the title")
	public void should_be_able_to_click_on_and_resume_the_suspended_hold_for_the_title(String string) {
		title.reume_suspendedHold();
	}

	@Then("user should be able to click on Remove Hold and remove hold put on the title")
	public void user_should_be_able_to_click_on_remove_hold_and_remove_hold_put_on_the_title() {
		title.click_RemoveHold();
	}

	@Given("user launch the manual kidszone texas library {string} url")
	public void user_launch_the_manual_kidszone_texas_library_url(String url) {
		title.launch_manualTexas(url);
	}

	@Given("user should be navigated to myshelf screen")
	public void user_should_be_navigated_to_myshelf_screen() {
		// hamburgerMenu.click_HamburgerMenu();
		// hamburgerMenu.click_MyShelf();
		title.click_AdvanceSearch();
		//title.click_synapsisTitle();
		// title.click_synopsisTitle();
	}

	@Then("user should be able to view title synopsis")
	public void user_should_be_able_to_view_title_synopsis() {
		if (title.txt_synopsis.isDisplayed()) {
			visibilityWait(title.txt_synopsis);
			Assert.assertTrue(title.txt_synopsis.isDisplayed());
		} else {
			Logger.log("Synopsis not available for the title");
		}
	}

//	@Then("user should be able to view {string} cta to view complete synopsis if synopsis content does not fit the default height")
//	public void user_should_be_able_to_view_cta_to_view_complete_synopsis_if_synopsis_content_does_not_fit_the_default_height(
//			String string) {
//		Assert.assertTrue(isElementPresent(title.txt_viewMore));
//	}
//
//	@Then("user should be able to click on view all to view the complete synopsis")
//	public void user_should_be_able_to_click_on_view_all_to_view_the_complete_synopsis() {
//		title.click_viewMore();
//	}
//
//	@Then("user should be able to view {string} cta when synopsis is expanded")
//	public void user_should_be_able_to_view_cta_when_synopsis_is_expanded(String string) {
//		Assert.assertTrue(isElementPresent(title.txt_viewless));
//	}
//
//	@Then("user should be able to click on view less to collapse synopsis to default height")
//	public void user_should_be_able_to_click_on_view_less_to_collapse_synopsis_to_default_height() {
//		title.click_viewLess();
//	}
//
//	@Then("user should not be able to view synopsis if no synopsis are available")
//	public void user_should_not_be_able_to_view_synopsis_if_no_synopsis_are_available() {
//		Assert.assertEquals(isElementPresent(title.txt_synopsis), false);
//	}
//
//	@Then("user should be able to view tabs more like this, related items and details")
//	public void user_should_be_able_to_view_tabs_more_like_this_related_items_and_details() {
//		Assert.assertTrue(titleList.view_moreLikeThisAndReleateditems());
//	}
//
//	@Then("user should be able to view tab {string} tab is opened by default")
//	public void user_should_be_able_to_view_tab_tab_is_opened_by_default(String string) {
//		titleList.select_morelikethisLink();
//	}
//
//	@Then("user should be able to view recommendations based on title carousel")
//	public void user_should_be_able_to_view_recommendations_based_on_title_carousel() {
//		titleList.click_Releateditems();
//	}
//
//	@Then("user should be able to view title in series carousel")
//	public void user_should_be_able_to_view_title_in_series_carousel() {
//		titleList.click_details();
//	}
//
//	@When("user click on related items tab")
//	public void user_click_on_related_items_tab() {
//		titleList.click_Releateditems();
//		Logger.log("user is able to click on related items tab");
//	}
//
//	@Then("user should be able to see {string} tab open")
//	public void user_should_be_able_to_see_tab_open(String string) {
//		Logger.log("currently none of the titles displayed in releated items");
//	}
//
//	@Then("user should be able to view learning activities")
//	public void user_should_be_able_to_view_learning_activities() {
//		Logger.log("currently none of the titles displayed in releated items");
//
//	}

	// 145707

	@Then("user should be able to view author names for the title")
	public void user_should_be_able_to_view_author_names_for_the_title() {
		visibilityWait(title.txt_authorName);
		javascriptScroll(title.txt_authorName);
		Assert.assertEquals(title.view_authorName(), true);
		Logger.log("user is able to view author name");
	}

	@Then("user should be able to view author names as a link")
	public void user_should_be_able_to_view_author_names_as_a_link() {
		Assert.assertTrue(title.txt_authorName.isDisplayed());
		Logger.log("user is able to view author link");
	}

	@Then("user click on author name")
	public void user_click_on_author_name() {
		title.click_AuthorLink();
	}

	@Then("user click on author name of audio book")
	public void user_click_on_author_name_of_audio_book() {
		title.clickNarrator();
	}

	@Then("user should navigate to search results screen with search results for that author")
	public void user_should_navigate_to_search_results_screen_with_search_results_for_that_author() {
		visibilityWait(title.author_resultScreen);
		Assert.assertEquals(title.author_resultScreen.isDisplayed(), true);
	}

	@Given("user click on the title card of an ebook")
	public void user_click_on_the_title_card_of_an_ebook() {
		waitForDocumentToLoad();
		title.select_availablenowdrop();
		title.searchEbook();
		title.clickEbook();
	}

	@Given("user click on the title card of an audio book")
	public void user_click_on_the_title_card_of_an_audio_book() {
		waitForDocumentToLoad();
		title.select_availablenowdrop();
		title.searchAudiobook();
		title.Click_availableAudioBook();
	}

	@Then("user should be able to view available formats for the title")
	public void user_should_be_able_to_view_available_formats_for_the_title() {
		// Assert.assertEquals(isElementPresent(title.available_formaticon), true);
		title.view_formatsTitle();
	}

	@Then("User should be able to view ISBN for the title")
	public void user_should_be_able_to_view_isbn_for_the_title() {
		//title.view_ProgDetailsTab();
		Assert.assertTrue(title.txt_isbn.isDisplayed());
	}

	@Then("User should be able to view Publisher for the title")
	public void user_should_be_able_to_view_publisher_for_the_title() {
		 Assert.assertTrue(title.txt_publisher.isDisplayed());
	}

	@Then("User should be able to view Release date for the title")
	public void user_should_be_able_to_view_release_date_for_the_title() {
		 Assert.assertTrue(title.publishDate.isDisplayed());
	}

	@Then("User should be able to view the date in the format {string}")
	public void user_should_be_able_to_view_the_date_in_the_format(String string) {
		 Assert.assertTrue(title.publishDate.isDisplayed());
	}

	@Then("User should be able to view Language for the title")
	public void user_should_be_able_to_view_language_for_the_title() {
//		visibilityWait(title.txt_language);
		Assert.assertTrue(title.txt_language.isDisplayed());

	}

	@Then("User should be able to view Age Levels for the title")
	public void user_should_be_able_to_view_age_levels_for_the_title() {
		visibilityWait(title.txt_ageRange);
		Assert.assertTrue(title.txt_ageRange.isDisplayed());
	}

	@Given("user should be able to see details tab open")
	public void user_should_be_able_to_see_details_tab_open() {
		visibilityWait(title.txt_publisher);
		Assert.assertTrue(title.txt_publisher.isDisplayed());
	}

	@Given("user should be able to view name of the books series as cta")
	public void user_should_be_able_to_view_name_of_the_books_series_as_cta() {
		Assert.assertTrue(title.view_bookSeriesCTA());
	}

	@When("user clicks on book series")
	public void user_clicks_on_book_series() {
		title.click_bookSeries();
	}

	@Then("user should be able to navigate to title list screen for the titles in the series")
	public void user_should_be_able_to_navigate_to_title_list_screen_for_the_titles_in_the_series() {
		// Assert.assertTrue(isElementPresent(title.getTitleDetailScreen()));
		Logger.log("user should be navigate to title list screen");
		visibilityWait(title.searchicon_titleresultScreen);
		jsClick(title.searchicon_titleresultScreen);
	}

	@Then("user should be able to view estimated wait time for the title")
	public void user_should_be_able_to_view_estimated_wait_time_for_the_title() {
		Logger.log("Estimated wait time will be available only when titles available");
	}

	@Then("user should be able to view selected title information on title details screen")
	public void user_should_be_able_to_view_selected_title_information_on_title_details_screen() {
		Assert.assertEquals(title.getTitleDetailsInfo().isDisplayed(), true);
	}

	@Then("user should be able to view format as an icon")
	public void user_should_be_able_to_view_format_as_an_icon() {
		Assert.assertEquals(isElementPresent(title.getImg_audioformaticon()), true);
	}

	@Then("user should be able to view profile as an icon based on title age\\/audience level")
	public void user_should_be_able_to_view_profile_as_an_icon_based_on_title_age_audience_level() {
		Assert.assertEquals(title.getProfileInfo().isDisplayed(), true);
	}

	@Then("user should be able to view age based on title audience level as an icon")
	public void user_should_be_able_to_view_age_based_on_title_audience_level_as_an_icon() {
		Assert.assertEquals(title.getAgeInfo().isDisplayed(), true);
	}

	@Then("user should be able to view language of the title as an icon")
	public void user_should_be_able_to_view_language_of_the_title_as_an_icon() {
		Assert.assertEquals(title.getLangInfo().isDisplayed(), true);
	}

	@Then("user should be able to view number of pages for ebook")
	public void user_should_be_able_to_view_number_of_pages_for_ebook() {
		Assert.assertEquals(title.getPagesTotal().isDisplayed(), true);
	}

	@Then("user should be able to view text to speech as text or eread-along if applicable")
	public void user_should_be_able_to_view_text_to_speech_as_text_or_eread_along_if_applicable() {
		Assert.assertEquals(title.getTxtToSpeech().isDisplayed(), true);
	}

	@Then("user should be able to view subject as text and view release date as text")
	public void user_should_be_able_to_view_subject_as_text_and_view_release_date_as_text() {
		Assert.assertEquals(title.getTxtToSpeech().isDisplayed(), true);
		Logger.log("user is able to view subject as release date");
	}

	@Then("user should be able to view duration for audiobooks as icon")
	public void user_should_be_able_to_view_duration_for_audiobooks_as_icon() {
		Assert.assertEquals(title.getDurationOfAudioBook().isDisplayed(), true);
	}

	@Given("click on the title with title status as {string}")
	public void click_on_the_title_with_title_status_as(String string) {
		title.clickHoldTitle();
	}

	@When("user clicks on the {string} button")
	public void user_clicks_on_the_button(String string) {
		title.click_placeHold();
	}

	@Then("system to check if the email is set up for the Standalone Teen user profile, if yes, then system should not show popup with notification to update email")
	public void system_to_check_if_the_email_is_set_up_for_the_standalone_teen_user_profile_if_yes_then_system_should_not_show_popup_with_notification_to_update_email() {
		Assert.assertEquals(isElementPresent(title.getEmailNotifyPopUp()), false);
		Logger.log("Email notification pop-up not shown if user already registered with email");
	}

	@Then("system to check if the email is set up for the Standalone Teen profile, if NO, then system should show popup with notification to update email")
	public void system_to_check_if_the_email_is_set_up_for_the_standalone_teen_profile_if_no_then_system_should_show_popup_with_notification_to_update_email() {
		Assert.assertEquals(isElementPresent(title.getEmailNotifyPopUp()), true);
		Logger.log("Email notification pop-up shown if user is not registered with email");
	}

	@Then("user should be able to click on {string} button to close the pop up")
	public void user_should_be_able_to_click_on_button_to_close_the_pop_up(String string) {
		title.clickClosePopUp();
	}

	@Then("user should be able to view pop up with heading {string}")
	public void user_should_be_able_to_view_pop_up_with_heading(String text) {
		Assert.assertEquals(title.getEmailNotifyPopUp().getText().contains(text), true);
	}

	@Then("user should be able to view short description as {string}")
	public void user_should_be_able_to_view_short_description_as(String description) {
		Assert.assertEquals(title.getShortDescrip().getText().contains(description), true);
	}

	@Then("user should be able to view text box to enter the {string}")
	public void user_should_be_able_to_view_text_box_to_enter_the(String emailID) {
		Assert.assertEquals(title.getEmailID().isDisplayed(), true);
	}

	@Then("user should be able to view {string} button to submit")
	public void user_should_be_able_to_view_button_to_submit(String button) {
		Assert.assertEquals(title.getSuBmitEmail().isDisplayed(), true);
		title.clickSubMit();
	}

	@Then("system should show success toast message {string} after entering valid email address")
	public void system_should_show_success_toast_message_after_entering_valid_email_address(String succToastMsg) {
		title.waitForSuccessMsg();
		Assert.assertEquals(title.getSuccToastMsg().isDisplayed(), true);
	}

	@Then("user should be able to view the title status as {string}")
	public void user_should_be_able_to_view_the_title_status_as(String string) {
		Logger.log("User able to view the title status");
	}

	@Then("user should be able to update the {string} and {string}")
	public void user_should_be_able_to_update_the_and(String emailID, String confirmEmailID) {
		title.enterEmailandConfirmEmail(emailID, confirmEmailID);
		title.clickSubMit();
	}

	@Then("system should show error message {string} if the email and confirm email did not match")
	public void system_should_show_error_message_if_the_email_and_confirm_email_did_not_match(String errToastMsg) {
		Assert.assertEquals(title.getErrToastMsg().getText().contains(errToastMsg), true);
	}

	@Then("user should be able to view text box to enter the Confirm {string}")
	public void user_should_be_able_to_view_text_box_to_enter_the_confirm(String confirmEmailId) {
		Assert.assertEquals(title.getConfirmEmailID().isDisplayed(), true);
	}

	@Then("system should show success toast message {string} and {string} after entering valid email address")
	public void system_should_show_success_toast_message_and_after_entering_valid_email_address(String success,
			String holdMsg) {
		title.waitForSuccessMsg();
		Assert.assertEquals(title.getSuccToastMsg().isDisplayed(), true);
		Assert.assertEquals(title.getSuccToastMsg().getText().contains(success), true);
		Assert.assertEquals(title.getSuccToastMsg().getText().contains(holdMsg), true);
	}

	@When("user taps on the title card of an ebook with a Hold position")
	public void user_taps_on_the_title_card_of_an_ebook_with_a_Hold_position() {
		title.searchEbook();
		title.clickHoldTitle();
	}

	@Then("Placing the title on Hold")
	public void placing_the_title_on_hold() {
		title.clickHoldCta();
	}

	@Then("user should be able to view boundless logo in the footer as per mock")
	public void user_should_be_able_to_view_boundless_logo_in_the_footer_as_per_mock() {
		javaScriptScrollToEnd();
		Assert.assertEquals(library.getBoundLessLogo().isDisplayed(), true);
	}

	@When("user clicks on programs option in menu list")
	public void user_clicks_on_programs_option_in_menu_list() {
		library.clickHamNew();
		title.clickPrograms();
	}

	@When("user clicks on checkout option in menu list")
	public void user_clicks_on_checkout_option_in_menu_list() {
		library.clickHamNew();
		library.clickCheckOuts();
	}

	@When("user lands on checkout tab in my stuff screen")
	public void user_lands_on_checkout_tab_in_my_stuff_screen() {
		Logger.log("User landed on checkout Page");
	}

	@When("user lands on programs screen")
	public void user_lands_on_programs_screen() {
		Logger.log("User landed on programs Page");
	}

	@Then("user should be able to view current axis360 logo")
	public void user_should_be_able_to_view_current_axis360_logo() {
		javaScriptScrollToEnd();
		Assert.assertEquals(title.getAxisOldLogo().isDisplayed(), true);
		Logger.log("User able to view axis360 Logo");
	}

	@Then("user should not be able to view boundless logo in the footer")
	public void user_should_not_be_able_to_view_boundless_logo_in_the_footer() {
		Assert.assertEquals(isElementPresent(library.getBoundLessLogo()), false);
		Logger.log("User not able to view Boundless Logo");
	}

	@When("user clicks on programs in menu list")
	public void user_clicks_on_programs_in_menu_list() {
		title.clickProgramsOldUi();
	}

	@When("user clicks on checkout option in menu list oldUI")
	public void user_clicks_on_checkout_option_in_menu_list_old_ui() {
		title.clickCheckoutOldUi();
	}

	@Then("user should be able to view {string} cta to view complete synopsis if synopsis content does not fit the default height")
	public void user_should_be_able_to_view_cta_to_view_complete_synopsis_if_synopsis_content_does_not_fit_the_default_height(
			String string) {
		if (isElementPresent(title.txt_viewMore)) {
			Assert.assertTrue(title.txt_viewMore.isDisplayed());
		} else {
			Logger.log("View More CTA is not Available");
		}
	}

	@Then("user should be able to click on view all to view the complete synopsis")
	public void user_should_be_able_to_click_on_view_all_to_view_the_complete_synopsis() {
		title.click_viewMore();
	}

	@Then("user should be able to view {string} cta when synopsis is expanded")
	public void user_should_be_able_to_view_cta_when_synopsis_is_expanded(String string) {
		if (isElementPresent(title.txt_viewless)) {
			Assert.assertTrue(title.txt_viewless.isDisplayed());
		} else {
			Logger.log("View Less CTA is not Available");
		}
	}

	@Then("user should be able to click on view less to collapse synopsis to default height")
	public void user_should_be_able_to_click_on_view_less_to_collapse_synopsis_to_default_height() {
		title.click_viewLess();
	}

	@Then("user should not be able to view synopsis if no synopsis are available")
	public void user_should_not_be_able_to_view_synopsis_if_no_synopsis_are_available() {
		Assert.assertEquals(isElementPresent(title.txt_synopsis), false);
	}

	@Then("user should be able to view tabs more like this, related items and details")
	public void user_should_be_able_to_view_tabs_more_like_this_related_items_and_details() {
		Assert.assertTrue(titleList.view_moreLikeThisAndReleateditems());
	}

	@Then("user should be able to view tab {string} tab is opened by default")
	public void user_should_be_able_to_view_tab_tab_is_opened_by_default(String string) {
		titleList.select_morelikethisLink();
	}

	@Then("user should be able to view recommendations based on title carousel")
	public void user_should_be_able_to_view_recommendations_based_on_title_carousel() {
		titleList.click_Releateditems();
	}

	@Then("user should be able to view title in series carousel")
	public void user_should_be_able_to_view_title_in_series_carousel() {
		titleList.click_details();
	}

	@When("user click on related items tab")
	public void user_click_on_related_items_tab() {
		titleList.click_Releateditems();
		Logger.log("user is able to click on related items tab");
	}

	@Then("user should be able to see {string} tab open")
	public void user_should_be_able_to_see_tab_open(String string) {
		Logger.log("currently none of the titles displayed in releated items");
	}

	@Then("user should be able to view learning activities")
	public void user_should_be_able_to_view_learning_activities() {
		Logger.log("currently none of the titles displayed in releated items");
	}

	@When("user taps on the title card of an audio book with a hold position")
	public void user_taps_on_the_title_card_of_an_audio_book_with_a_hold_position() {
		title.searchAudiobook();
		title.clickHoldAudioTitle();
	}

	@Given("Deleting the email from profile settings")
	public void deleting_the_email_from_profile_settings() {
		title.deleteEmailFromProfile();
	}
	
	@Then("user click on Add to Wishlist and add the title to the wishlist from details page")
	public void user_click_on_add_to_wishlist_and_add_the_title_to_the_wishlist_from_details_page() {
			if (isElementPresent(holds.WishListSelected_Detailspage)) {
				Logger.log("----Already added wishlist");
			}else {
				visibilityWait(holds.WishList_Detailspage);
				jsClick(holds.WishList_Detailspage);
			}
		
	}

	@Then("user click on Remove From Wishlist and remove the title from the wishlist from details page")
	public void user_click_on_remove_from_wishlist_and_remove_the_title_from_the_wishlist_from_details_page() {
		if (isElementPresent(holds.WishListSelected_Detailspage)) {
			visibilityWait(holds.WishListSelected_Detailspage);
			jsClick(holds.WishListSelected_Detailspage);
		}else {
			Logger.log("----Already removed wishlist");
		}
	}
	
	@Given("user have already submitted the review and waiting for admin approval")
	public void user_have_already_submitted_the_review_and_waiting_for_admin_approval() {
		Logger.log("user submitted the review and waiting for the Admin Approval");
	}
	
	@Then("user should be able to view the featured reading program section")
	public void user_should_be_able_to_view_the_featured_reading_program_section() {
		visibilityWait(title1.library_FeaturedProgram);
	   Assert.assertTrue(title1.library_FeaturedProgram.isDisplayed());
	}
	
	@When("user clicks on any titles in the featured reading program")
	public void user_clicks_on_any_titles_in_the_featured_reading_program() {
	    ClickOnWebElement(title1.firstTitle_FeaturedProgram);
	    visibilityWait(title1.programDetailPage);
	}

	@Then("user should navigate to the program details")
	public void user_should_navigate_to_the_program_details() {
		visibilityWait(title1.programDetailPage);
	    Assert.assertTrue(title1.programDetailPage.isDisplayed());
	}
	@Given("user clicks on the Join program CTA from Program details")
	public void user_clicks_on_the_join_program_cta_from_program_details() {
		visibilityWait(title1.joinProgramCta);
	    jsClick(title1.joinProgramCta);
	    try {
			jsClick(title1.Cta_Ok);
		} catch (Exception e) {
			// TODO: handle exception
		}
	    visibilityWait(title1.leaveProgramCta);
	    ClickOnWebElement(title1.leaveProgramCta);
	    visibilityWait(title1.Cta_Ok);
	    ClickOnWebElement(title1.Cta_Ok);
	}
	
/*****************************************vidual UI*********************/
	
	@Then("capture the screenshot of checkout action CTA for available video title")
	public void capture_the_screenshot_of_checkout_action_cta_for_available_video_title() {
	   eyes.checkWindow("checkout Action CTA for Available video title");
	}
	
	@Then("capture the screenshot of title with play cta in video title card")
	public void capture_the_screenshot_of_title_with_play_cta_in_video_title_card() {
		 eyes.checkWindow("Title with play cta in video title card");
	}

	@Then("capture the screenshot of title card in my stuff page")
	public void capture_the_screenshot_of_title_card_in_my_stuff_page() {
		eyes.checkWindow("Title card in MystuffPage");
	}

	@Then("capture the screenshot of play action CTA for that video title")
	public void capture_the_screenshot_of_play_action_cta_for_that_video_title() {
		eyes.checkWindow("play Action CTA for video title");
	}

	@Then("capture the screenshot of play CTA after renew the title")
	public void capture_the_screenshot_of_play_cta_after_renew_the_title() {
		eyes.checkWindow("play CTA for Renew title");
	}

	@Then("capture the screenshot of checkout CTA after return the title")
	public void capture_the_screenshot_of_checkout_cta_after_return_the_title() {
		eyes.checkWindow("checkout CTA after Return the title");
	}

	@Then("capture the screenshot of started watching and exit from checkout video title")
	public void capture_the_screenshot_of_started_watching_and_exit_from_checkout_video_title() {
		eyes.checkWindow("started watching and exit from checkout video title");
	}

	@Then("capture the screenshot of resume action CTA for that video title")
	public void capture_the_screenshot_of_resume_action_cta_for_that_video_title() {
		eyes.checkWindow("Resume action CTA for video title");
	}

	@Then("capture the screenshot of resume CTA after renew the title")
	public void capture_the_screenshot_of_resume_cta_after_renew_the_title() {
		eyes.checkWindow("Resume CTA after renew the title");
	}

	@Then("capture the screenshot of title detail page by click on vbook title card")
	public void capture_the_screenshot_of_title_detail_page_by_click_on_vbook_title_card() {
		eyes.checkWindow("Title detail page by click on vbook title card");
	}

	@Then("capture the screenshot of checkout action CTA for available vbook title")
	public void capture_the_screenshot_of_checkout_action_cta_for_available_vbook_title() {
		eyes.checkWindow("checkout Action CTA for available vbook title");
	}

	@Then("capture the screenshot of title detail page by click on title with play cta in video title card")
	public void capture_the_screenshot_of_title_detail_page_by_click_on_title_with_play_cta_in_video_title_card() {
		eyes.checkWindow("Title detail page by click on title with play cta in video title card");
	}

	@Then("capture the screenshot of play action CTA for that vbook title")
	public void capture_the_screenshot_of_play_action_cta_for_that_vbook_title() {
		eyes.checkWindow("play action CTA for vbook title");
	}

	@Then("capture the screenshot of title detail page by click on resume cta in video title card")
	public void capture_the_screenshot_of_title_detail_page_by_click_on_resume_cta_in_video_title_card() {
		eyes.checkWindow("Title detail page by click on resume cta in video title card");
	}

	@Then("capture the screenshot of popup {string} with message and OK CTA")
	public void capture_the_screenshot_of_popup_with_message_and_ok_cta(String string) {
		eyes.checkWindow("popup with message and ok CTA");
	}

	@Then("capture the screenshot of dismiss the pop-up and remain on the same page")
	public void capture_the_screenshot_of_dismiss_the_pop_up_and_remain_on_the_same_page() {
		eyes.checkWindow("dismiss the popup and remain on the same page");
	}

	@Then("capture the screenshot of VBooks categories in the carousel format")
	public void capture_the_screenshot_of_v_books_categories_in_the_carousel_format() {
		eyes.checkWindow("VBooks categories in the carousel format");  
	}

	@Then("capture the screenshot of success toast message {string}")
	public void capture_the_screenshot_of_success_toast_message(String string) {
		eyes.checkWindow("success toast message for You have checked out");  
	}

	@Then("capture the screenshot of toast message upon user clicking on the renewe title action CTA")
	public void capture_the_screenshot_of_toast_message_upon_user_clicking_on_the_renewe_title_action_cta() {
		eyes.checkWindow("success toast message for You have checked out");  
	}

	@Then("capture the screenshot of success toast message {string} and {string}")
	public void capture_the_screenshot_of_success_toast_message_and(String string, String string2) {
		eyes.checkWindow("success toast message Your loan for and has been renewed");  
	}

	@Then("capture the screenshot of toast message upon user clicking on the return title action CTA")
	public void capture_the_screenshot_of_toast_message_upon_user_clicking_on_the_return_title_action_cta() {
		eyes.checkWindow("toast message upon user clicking on the return title action CTA");  
	}



}
