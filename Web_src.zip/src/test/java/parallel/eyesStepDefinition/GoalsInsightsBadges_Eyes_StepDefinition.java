package parallel.eyesStepDefinition;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyShelfscreen;
import pom.kidszone.Profilecreation;

public class GoalsInsightsBadges_Eyes_StepDefinition {

	Eyes eyes = EyesManager.getEyes();
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	MyShelfscreen myshelf = new MyShelfscreen(DriverManager.getDriver());

	@Then("capture the screenshot of the minutesReadPopupScreen")
	public void capture_the_screenshot_of_the_minutesReadPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_ReadingGoal().isDisplayed());
		eyes.checkWindow("LoginScreen");
	}
	
	@Then("capture the screenshot of the error message {string}")
	public void capture_the_screenshot_of_the_errorMessage(String errorMsg) {
		Assert.assertEquals(myshelf.getTxt_MinsErrorMsg().getText(), errorMsg);
		eyes.checkWindow("InvalidInputErrorMessage");
	}
	
	@Then("capture the screenshot of the minutesListenedPopupScreen")
	public void capture_the_screenshot_of_the_minutesListenedPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_ListeningGoal().isDisplayed());
		eyes.checkWindow("minutesListenedPopupScreen");
	}
	
	@Then("capture the screenshot of the goalsStreakPopupScreen")
	public void capture_the_screenshot_of_the_goalsStreakPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_Set_StreakGoal().isDisplayed());
		eyes.checkWindow("goalsStreakPopupScreen");
	}
	
	@Then("capture the screenshot of the monthlyReadGoalPopupScreen")
	public void capture_the_screenshot_of_the_monthlyReadGoalPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_Set_MonthlyBookGoal().isDisplayed());
		eyes.checkWindow("monthlyReadGoalPopupScreen");
	}
	
	@Then("capture the screenshot of the monthlylistenedGoalPopupScreen")
	public void capture_the_screenshot_of_the_monthlylistenedGoalPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_ListenedMonth().isDisplayed());
		eyes.checkWindow("monthlyReadGoalPopupScreen");
	}
	
	@Then("capture the screenshot of the yearlyReadGoalPopupScreen")
	public void capture_the_screenshot_of_the_yearlyReadGoalPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_Set_YearGoal().isDisplayed());
		eyes.checkWindow("yearlyReadGoalPopupScreen");
	}
	
	@Then("capture the screenshot of the yearlylistenedGoalPopupScreen")
	public void capture_the_screenshot_of_the_yearlylistenedGoalPopupScreen() {
		Assert.assertTrue(myshelf.getPopup_ListenedYear().isDisplayed());
		eyes.checkWindow("yearlyReadGoalPopupScreen");
	}
}
