package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfileFeedBackS4 {
	
	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of newly created kid profile")
	public void capture_the_screenshot_of_newly_created_kid_profile() {
	    eyes.checkWindow("NewlyCreatedKidProfile");
	}
	
	
	@Then("capture the screenshot of Edit icon for each profile on the manage profile screen")
	public void capture_the_screenshot_of_edit_icon_for_each_profile_on_the_manage_profile_screen() {
		eyes.checkWindow("Edit icon for each profile on the manage profile screen");
	}

	@Then("capture the screenshot of Adult profile setting page")
	public void capture_the_screenshot_of_adult_profile_setting_page() {
		eyes.checkWindow("Adult profile setting page");
	}
	@Then("capture the screenshot of Adult profile Enable pin popup")
	public void capture_the_screenshot_of_adult_profile_enable_pin_popup() {
		eyes.checkWindow("Adult profile Enable pin popup");
	}

	@Then("capture the screenshot of Add a profile screen")
	public void capture_the_screenshot_of_add_a_profile_screen() {
		eyes.checkWindow("Add a profile screen");
	}

	@Then("capture the screenshot of already set profile pin popup")
	public void capture_the_screenshot_of_already_set_profile_pin_popup() {
		eyes.checkWindow("Already set profile pin popup");
	}

	@Then("capture the screenshot of reset profile popup prompt")
	public void capture_the_screenshot_of_forgot_profile_pin_prompt() {
		eyes.checkWindow("Reset profile popup prompt");
	}
	@Then("capture the screenshot of user enters the one time pin")
	public void capture_the_screenshot_of_user_enters_the_incorrect_pin_popup() {
		eyes.checkWindow("user enters the one time pin");
	}

	@Then("capture the screenshot of Leave page popup with cancel and leave CTA")
	public void capture_the_screenshot_of_leave_page_popup_with_cancel_and_leave_cta() {
		eyes.checkWindow("Leave page popup with cancel and leave CTA");
	}

	@Then("capture the screenshot at the bottom of profile setting page for Adult profile")
	public void capture_the_screenshot_at_the_bottom_of_profile_setting_page_for_adult_profile() {
		eyes.checkWindow("At the bottom of profile setting page for Adult profile");
	}

	@Then("capture the screenshot of AdultProfile_disable pin popup")
	public void capture_the_screenshot_of_adult_profile_disable_pin_popup() {
		eyes.checkWindow("AdultProfile_disable pin popup");
	}
	@Then("capture the screenshot of confirm the pin action")
	public void capture_the_screenshot_of_confirm_the_pin_action() {
		eyes.checkWindow("confirmation pin action");
	}


}
