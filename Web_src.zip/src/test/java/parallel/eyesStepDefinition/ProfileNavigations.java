package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfileNavigations {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of profile selection which is not available in registration screen")
	public void capture_the_screenshot_of_profile_selection_which_is_not_available_in_registration_screen() {
	    eyes.checkWindow("Registration Screen Without Profile Selection Options");
	}

	@Then("capture the screenshot, at the top of Select avatar screen for Adult profile")
	public void capture_the_screenshot_at_the_top_of_select_avatar_screen_for_adult_profile() {
		 eyes.checkWindow("At the top of Select avatar screen for Adult profile");
	}


	@Then("capture the screenshot, at the bottom of Select avatar screen for adult profile")
	public void capture_the_screenshot_at_the_bottom_of_select_avatar_screen_for_adult_profile() {
		 eyes.checkWindow("At the bottom of Select avatar screen for Adult profile");
	}
	
	@Then("capture the screenshot of Teen profile details screen")
	public void capture_the_screenshot_of_teen_profile_details_screen() {
		 eyes.checkWindow("Teen profile details screen");
	}
	
}
