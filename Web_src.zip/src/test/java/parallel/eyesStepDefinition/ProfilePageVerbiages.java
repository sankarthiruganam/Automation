package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfilePageVerbiages {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("captue the screenshot of line error message {string}")
	public void captue_the_screenshot_of_line_error_message(String string) {
	    eyes.checkWindow("Adult profile_Error message of invalid mail id");
	}
	
	@Then("capture the screenshot of inline error message {string}")
	public void captue_the_screenshot_of_inline_error_message(String string) {
	    eyes.checkWindow("Teen profile_Error message of invalid mail id");
	}

	@Then("captue the screenshot of error popup with {string} with {string} cta")
	public void captue_the_screenshot_of_error_popup_with_with_cta(String string, String string2) {
	    eyes.checkWindow("Email notification popup for adult profile");
	}

	@Then("captue the screenshot of save alert message {string} with CTA - Cancel\\/Leave Page")
	public void captue_the_screenshot_of_save_alert_message_with_cta_cancel_leave_page(String string) {
	    eyes.checkWindow("Leave page popup for Adult profile");
	}

	@Then("capture the screenshot of {string} as teen profile type in my profile screen")
	public void capture_the_screenshot_of_as_teen_profile_type_in_my_profile_screen(String string) {
	    eyes.checkWindow("TeenAsProfileType_profile details screen");
	}
	
	@Then("capture the screenshot of {string} as kid profile type in my profile screen")
	public void capture_the_screenshot_of_as_kid_profile_type_in_my_profile_screen(String string) {
	    eyes.checkWindow("KidAsProfileType_profile details screen");
	}
	
	@Then("capture the screenshot of {string} as profile type in my profile screen")
	public void captue_the_screenshot_of_as_profile_type_in_my_profile_screen(String string) {
	    eyes.checkWindow("GeneralAdultAsProfileType_profile details screen");
	}

	
}
