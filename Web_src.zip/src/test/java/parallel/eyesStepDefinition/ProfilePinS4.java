package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfilePinS4 {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of updated profile details")
	public void capture_the_screenshot_of_updated_profile_details() {
		 eyes.checkWindow("Adultprofile_updated profile details");
	}


	@Then("capture the screenshot of Teen profile enable pin")
	public void capture_the_screenshot_of_teen_profile_enable_pin() {
		 eyes.checkWindow("Teen profile enable pin process and bottom of profile details screen");
	}
	
	@Then("capture the screenshot At the bottom of kid profile details screen and toggle button in active state")
	public void capture_the_screenshot_at_the_bottom_of_kid_profile_details_screen_and_toggle_button_in_active_state() {
		 eyes.checkWindow("At the bottom of kid profile details screen and toggle button in active state");
	}
	
	@Then("capture the screenshot of Adult profile create pin popup with done cta")
	public void capture_the_screenshot_of_adult_profile_create_pin_popup_with_done_cta() {
		 eyes.checkWindow("AdultProfile_create pin popup with done cta (pin without masked)");
	}

	@Then("capture the screenshot of Teen profile create pin popup with done cta")
	public void capture_the_screenshot_of_teen_profile_create_pin_popup_with_done_cta() {
		 eyes.checkWindow("TeenProfile_create pin popup with done cta (pin with masked)");
	}
	
	@Then("capture the screenshot of Adult profile universal toggle and enable my profile pin button in the disabled state")
	public void capture_the_screenshot_of_adult_profile_universal_toggle_and_enable_my_profile_pin_button_in_the_disabled_state() {
		eyes.checkWindow("AdultProfile_universal toggle is disabled state");
	}

	@Then("capture the screenshot of Teen profile should not show the Enable my profile pin button if disabled the universal toggle for adult profile")
	public void capture_the_screenshot_of_teen_profile_should_not_show_the_enable_my_profile_pin_button_if_disabled_the_universal_toggle_for_adult_profile() {
		eyes.checkWindow("TeenProfile_should not show 'Enable My profile pin' toggle if the adult user disabled the universal toggle ");
	}
	@Then("capture the screenshot of kid profile should not show the Enable my profile pin button if disabled the universal toggle for adult profile")
	public void capture_the_screenshot_of_kid_profile_should_not_show_the_enable_my_profile_pin_button_if_disabled_the_universal_toggle_for_adult_profile() {
		eyes.checkWindow("KidProfile_should not show 'Enable My profile pin' toggle if the adult user disabled the universal toggle ");
	}
	
	@Then("capture the screenshot of should not show toast message with inline errors if user enters the wrong pin for Adult profile")
	public void capture_the_screenshot_of_should_not_show_toast_message_with_inline_errors_if_user_enters_the_wrong_pin_for_adult_profile() {
		eyes.checkWindow("AdultProfile_should not show toast message with inline errors if user enters the wrong pin for profile Edit screen");
	}
	
	@Then("capture the screenshot of should not show toast message with inline errors if user enters the wrong pin for profile landing screen")
	public void capture_the_screenshot_of_should_not_show_toast_message_with_inline_errors_if_user_enters_the_wrong_pin_for_profile_landing_screen() {
		eyes.checkWindow("AdultProfile_should not show toast message with inline errors if user enters the wrong pin for profile Landing screen");
	}
	
	@Then("capture the screenshot of should not show toast message with inline errors if user enters the wrong pin with forget cta for kid profile")
	public void capture_the_screenshot_of_should_not_show_toast_message_with_inline_errors_if_user_enters_the_wrong_pin_with_forget_cta_for_kid_profile() {
		eyes.checkWindow("KidProfile_should not show toast message with inline errors if user enters the wrong pin with forget cta");
	}

	@Then("capture the screenshot of should not show toast message with inline errors if user enters the wrong pin with forget cta for Teen profile")
	public void capture_the_screenshot_of_should_not_show_toast_message_with_inline_errors_if_user_enters_the_wrong_pin_with_forget_cta_for_teen_profile() {
		eyes.checkWindow("TeenProfile_should not show toast message with inline errors if user enters the wrong pin with forget cta");
	}

	
}