package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfileSettings {

	Eyes eyes = EyesManager.getEyes();
	
	
	@Then("captue the screenshot of Auto checkout available holds as updated verbiage")
	public void captue_the_screenshot_of_auto_checkout_available_holds_as_updated_verbiage() {
	    eyes.checkWindow("AutoCheckoutAvailableHoldsVerbiage_Adult profile");
	}

	@Then("capture the screenshot of Auto checkout available holds as updated verbiage for Teen profile")
	public void capture_the_screenshot_of_auto_checkout_available_holds_as_updated_verbiage_for_teen_profile() {
		 eyes.checkWindow("AutoCheckoutAvailableHoldsVerbiage_Teen profile");
	}
	@Then("capture the screenshot of Auto checkout available holds as updated verbiage for Kid profile")
	public void capture_the_screenshot_of_auto_checkout_available_holds_as_updated_verbiage_for_kid_profile() {
		 eyes.checkWindow("AutoCheckoutAvailableHoldsVerbiage_Kid profile");
	}
	
	@Then("capture the screenshot of toast message of profile deleted for Teen profile")
	public void capture_the_screenshot_of_toast_message_of_profile_deleted_for_teen_profile() {
		eyes.checkWindow("Toast message of profile deleted for Teen profile");
	}

	@Then("capture the screenshot of toast message of profile deleted for kid profile")
	public void capture_the_screenshot_of_toast_message_of_profile_deleted_for_kid_profile() {
		eyes.checkWindow("Toast message of profile deleted for Kid profile");
	}

	@Then("capture the screenshot of enable email notification popup for adult profile")
	public void capture_the_screenshot_of_enable_email_notification_popup_for_adult_profile() {
		 eyes.checkWindow("Enable email notification popup for adult profile");
	}
	
	@Then("capture the screenshot of Add same email as adult flag from teen profile details screen")
	public void capture_the_screenshot_of_add_same_email_as_adult_flag_from_teen_profile_details_screen() {
		eyes.checkWindow("Add same email as adult flag from teen profile details screen");
	}

	@Then("captue the screenshot of General Adult as profile type in my profile screen")
	public void captue_the_screenshot_of_general_adult_as_profile_type_in_my_profile_screen() {
		eyes.checkWindow("General Adult as profile type in my profile screen");
	}

	@Then("captue the screenshot of Teen {int}-{int} as profile type in my profile screen")
	public void captue_the_screenshot_of_teen_as_profile_type_in_my_profile_screen(Integer int1, Integer int2) {
		eyes.checkWindow("Teen as profile type in my profile screen");
	}
	@Then("captue the screenshot of Kid {int}-{int} as profile type in my profile screen")
	public void captue_the_screenshot_of_kid_as_profile_type_in_my_profile_screen(Integer int1, Integer int2) {
		eyes.checkWindow("Kid as profile type in my profile screen");
	}

}
