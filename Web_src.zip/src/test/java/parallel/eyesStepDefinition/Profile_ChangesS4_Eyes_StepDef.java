package parallel.eyesStepDefinition;


import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;


public class Profile_ChangesS4_Eyes_StepDef {
	
	Eyes eyes = EyesManager.getEyes();
	
	
	@Then("capture the screenshot of Adult user not able to view profile option in the hamburger menu")
	public void capture_the_screenshot_of_adult_user_not_able_to_view_profile_option_in_the_hamburger_menu() {
		  eyes.checkWindow("Adultuser not able to view profile option in Hamburger menu");
	}

	@Then("capture the screenshot of Teen user not able to view profile option in the hamburger menu")
	public void capture_the_screenshot_of_teen_user_not_able_to_view_profile_option_in_the_hamburger_menu() {
		 eyes.checkWindow("Teenuser not able to view profile option in Hamburger menu");
	}
	
	@Then("capture the screenshot of Kid user not able to view profile option in the hamburger menu")
	public void capture_the_screenshot_of_kid_user_not_able_to_view_profile_option_in_the_hamburger_menu() {
		 eyes.checkWindow("Kiduser not able to view profile option in Hamburger menu");
	}	
	
	@Then("capture the screenshot of Adult profile Mylibrary page")
	public void capture_the_screenshot_of_adult_profile_mylibrary_page() {
		 eyes.checkWindow("AdultProfile_MyLibaryPage");
	}
	
	@Then("capture the screenshot of Teen profile Mylibrary page")
	public void capture_the_screenshot_of_teen_profile_mylibrary_page() {
		 eyes.checkWindow("TeenProfile_MyLibaryPage");
	}
	
	@Then("capture the screenshot of Kid profile Mylibrary page")
	public void capture_the_screenshot_of_kid_profile_mylibrary_page() {
		 eyes.checkWindow("KidProfile_MyLibaryPage");
	}
	
	@Then("capture the screenshot of Manage profile screen after registration")
	public void capture_the_screenshot_of_manage_profile_screen_after_registration() {
		 eyes.checkWindow("At the top of ManageProfileScreen_AfterRegistration");
	}
	
	@Then("capture the screenshot at the bottom  of Manage profile screen")
	public void capture_the_screenshot_of_bottom_manage_profile_screen() {
		eyes.checkWindow("At the bottom of ManageProfileScreen_AfterRegistration");
	}
	
	@Then("capture the screenshot of Adult profile avatar on the Header as a square shape 36X36 size")
	public void capture_the_screenshot_of_adult_profile_avatar_on_the_header_as_a_square_shape_36x36_size() {
		eyes.checkWindow("Adult profile avatar icon on the header as square shape");
	}
	
	@Then("Capture the screenshot of profile dropdown options in the header for Adult profile")
	public void capture_the_screenshot_of_profile_dropdown_options_in_the_header_for_adult_profile() {
		eyes.checkWindow("Profile dropdown option for Adult profile(Options for profiles, ManageProfileCTA, ProfileSettings,singoutCTA),");
	}
	
	@Then("Capture the screenshot of dropdown menu with all created profiles")
	public void capture_the_screenshot_of_dropdown_menu_with_all_created_profiles() {
		eyes.checkWindow("Adult profile dropdown menu with All Created profiles");
	}
	
	@Then("Capture the screenshot of profile dropdown options in the header for Teen profile")
	public void capture_the_screenshot_of_profile_dropdown_options_in_the_header_for_Teen_profile() {
		eyes.checkWindow("Profile dropdown option for Teen profile(Options For profiles, ManageProfileCTA, ProfileSettings,singoutCTA),");
	}
	
}
