package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class SearchSuggestion_Eyes_StepDef {

	Eyes eyes = EyesManager.getEyes();

	@Then("capture the screenshot of the initiateSearchScreen")
	public void capture_the_screenshot_of_the_initiate_search_screen() {
		eyes.checkWindow("initiateSearchScreen");
	}

	@Then("capture the screenshot of the updatedInitiateSearchScreen")
	public void capture_the_screenshot_of_the_updated_initiate_search_screen() {
		eyes.checkWindow("updatedInitiateSearchScreen");
	}

	@Then("capture the screenshot of the updatedSearchSuggestionScreen")
	public void capture_the_screenshot_of_the_updated_search_suggestion_screen() {
		eyes.checkWindow("updatedSearchSuggestionScreen");
	}

	@Then("capture the screenshot of the searchClearedScreen")
	public void capture_the_screenshot_of_the_search_cleared_screen() {
		eyes.checkWindow("searchClearedScreen");
	}

	@Then("capture the screenshot of parental pin setup")
	public void capture_the_screenshot_of_parental_pin_setup() {
		eyes.checkWindow("parentalPinSetupScreen");
	}

	@Then("capture the screenshot of profile page")
	public void capture_the_screenshot_of_profile_page() {
		eyes.checkWindow("profilePageSetupScreen");
	}

	@Then("capture the screenshot of manage profile edit page")
	public void capture_the_screenshot_of_manage_profile_edit_page() {
		eyes.checkWindow("manageProfileEditScreen");
	}

	@Then("capture the screenshot of profile detail page")
	public void capture_the_screenshot_of_profile_detail_page() {
		eyes.checkWindow("profileDetailScreen");
	}

}
