package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class TitleDetailsAndHolds {

	Eyes eyes = EyesManager.getEyes();
	
	@Then("captue the screenshot of breacrumbs in title details page")
	public void captue_the_screenshot_of_breacrumbs_in_title_details_page() {
	    eyes.checkWindow("BreadCrumbsInTitleDetailsPage_Adult profile");
	}
	

	@Then("capture the screenshot of breacrumbs in title details page for Teen profile")
	public void capture_the_screenshot_of_breacrumbs_in_title_details_page_for_teen_profile() {
		 eyes.checkWindow("BreadCrumbsInTitleDetailsPage_Teen profile");
	}

	@Then("captue the screenshot of Also Available Section as carousel")
	public void captue_the_screenshot_of_also_available_section_as_carousel() {
	    eyes.checkWindow("AlsoAvailableSection");
	}

	@Then("captue the screenshot of Titles Like This Section undet More Like This")
	public void captue_the_screenshot_of_titles_like_this_section_undet_more_like_this() {
	    eyes.checkWindow("TitlesLikeThisSection_Teen profile");
	}

	@Then("captue the screenshot of Other Titles in Series")
	public void captue_the_screenshot_of_other_titles_in_series() {
	    eyes.checkWindow("OtherTitlesInSeries_Teen profile");
	}

	@Then("captue the screenshot of hold without email Id")
	public void captue_the_screenshot_of_hold_without_email_id() {
	    eyes.checkWindow("HoldWithoutEmailId_Adult profile");
	}

	@Then("captue the screenshot of Hold confirmed popup")
	public void captue_the_screenshot_of_hold_confirmed_popup() {
	    eyes.checkWindow("HoldConfirmedPopup_Adult profile");
	}
}
