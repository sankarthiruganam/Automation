import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.functions.ExpectedCondition;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class Chrome115Check {

	//private static WebDriver driver;
	public static void main(String[] args) {
		
//	//	System.setProperty("webdriver.chrome.driver", "/Users/sankarthirugnan/Documents/Chrome/chromedriver-mac-arm64/chromedriver");
//		ChromeOptions options=new ChromeOptions();
//		options.setBinary("/Users/sankarthirugnan/Documents/Chrome/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing");
//		WebDriver driver =new ChromeDriver(options);
//		driver.manage().window().maximize();
//		driver.navigate().to("https://www.google.com/");  
	//	ChromeOptions options=new ChromeOptions();
	//	options.setBrowserVersion("117");
		WebDriver driver =new ChromeDriver();
		Actions actions=new Actions(driver);
		driver.manage().window().maximize();
		driver.navigate().to("https://autokidsi.boundlessuat.baker-taylor.com/ng/view/library");
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("//button[@class='kz-login']"))).click();
		WebElement ele= driver.findElement(By.id("LogOnModel_UserName"));
		actions.contextClick(ele).perform();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", ele);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==='complete';"));
		
		
//		
	

	}

	

}
