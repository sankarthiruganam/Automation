
public class FirstCharacterPrintTest {

	public static void main(String[] args) {
		
		String s="India is my Country";
		
		char[] c=s.toCharArray();
		for(int i=0;i<c.length;i++)
		{
			if(c[i]!=' ' && (i==0 ||c[i-1]==' '))
			{
				System.out.print(c[i]);
			}
		}
		
	}
}
