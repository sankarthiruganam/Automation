
public class Honda extends Bike{

	void run()
	{
		System.out.println("Running suff");
	}
}
