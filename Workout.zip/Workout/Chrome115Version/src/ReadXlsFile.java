import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadXlsFile {

	public static void main(String[] args) throws IOException {
		
		File file=new File("");
		FileInputStream fis=new FileInputStream(file);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet= wb.getSheetAt(0);
		Iterator<Row> itr=sheet.iterator();
		while(itr.hasNext())
		{
			Row row=itr.next();
			Iterator<Cell> celliterator=row.iterator();
			while(celliterator.hasNext())
			{
			Cell cell=	celliterator.next();
			switch (cell.getCellType())               
			{  
	//		case cell.CELL_TYPE_STRING:    //field that represents string cell type  
			System.out.print(cell.getStringCellValue() + "\t\t\t");  
			break;  
	//		case Cell.CELL_TYPE_NUMERIC:    //field that represents number cell type  
			System.out.print(cell.getNumericCellValue() + "\t\t\t");  
			break;  
			default;

			}
		}
	}
	}
}
