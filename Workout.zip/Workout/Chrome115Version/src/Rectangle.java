
public class Rectangle implements Drawable{

	public void draw()
	{
		System.out.println("Drwa");
	}
}
