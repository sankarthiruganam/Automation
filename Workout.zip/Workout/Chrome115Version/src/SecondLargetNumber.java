
public class SecondLargetNumber {

	public static void main(String[] args) {
		
		int a[] = {3,5,6,7,9};
		int temp,size;
		size=a.length;
		for(int i=0;i<size;i++)
		{
			for (int j=i+1;j<size;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println(a[size-2]);
		
		
	}
}

