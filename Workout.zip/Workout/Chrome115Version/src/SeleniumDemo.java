import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org .openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumDemo {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		WebDriverWait wait =new WebDriverWait(driver,Duration.ofMillis(1000));
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(2000));
		File scrfile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrfile, new File(""));
		
		
		highLightElement()
		{
			for (int i=0;i<2;i++)
			{
				JavascriptExecutor js=(JavascriptExecutor)driver;
				js.executeScript("arguments[0].setAttribute('style',arguments[1]);"elel)
				
			}
		}
		
		WindowHandles()
		{
			
			String childWindow=driver.getWindowHandle();
			Set<String> AllWindow=driver.getWindowHandles();
			Iterator iterator=AllWindow.iterator();
			while(iterator.hasNext())
			{
				String childwin=iterator.next();
				if(!childWindow.equalsIgnoreCase(childWindow))
				{
					driver.switchTo().window(childwin);
				}
			}
			
			
		}
				
		
	}
}
