
public class TestAbstraction2 {

	public static void main(String[] args) {
		
		Bike obj= new Honda();
		obj.run();
		
		
	}
}
