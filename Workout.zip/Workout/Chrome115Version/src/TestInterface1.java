
public class TestInterface1 {

	public static void main(String[] args) {
		
		Drawable d= new Rectangle();
		d.draw();
	}
}
