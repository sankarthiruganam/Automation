package com.browser;

public class ActivityTask {
public static void main(String[] args) {
	Robot robot= new Robot();
}
}
