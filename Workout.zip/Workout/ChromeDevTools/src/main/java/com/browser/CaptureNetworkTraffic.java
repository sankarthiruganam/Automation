package com.browser;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v114.performance.Performance;
import org.openqa.selenium.devtools.v114.performance.model.Metric;

import junit.framework.Assert;



class  CaptureNetworkTraffic {
	
	public static void main(String[] args) throws InterruptedException {
		
		 ChromeDriver driver = new ChromeDriver();
		 driver.get("chrome://settings/clearBrowserData");
		 driver.findElement(By.xpath("//settings-ui")).sendKeys(Keys.ENTER);
		    DevTools devTools = driver.getDevTools();
		    devTools.createSession();
		    devTools.send(Performance.enable(Optional.empty()));
	        driver.get("https://autokidstexas.axis360qa4.baker-taylor.com/");
	       // Thread.sleep(1000);
	        driver.findElement(By.id("loginBtn")).click();
	        Thread.sleep(1000);
	        driver.findElement(By.id("LogOnModel_UserName")).sendKeys("BTAuto");
	        driver.findElement(By.id("LogOnModel_Password")).sendKeys("password");
			driver.findElement(By.id("loc_btnLogin")).click();
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("location.reload(true);");
	        List<Metric> metrics = devTools.send(Performance.getMetrics());
	        List<String> metricNames = metrics.stream()
	                .map(o -> o.getName())
	                .collect(Collectors.toList());

	        devTools.send(Performance.disable());
	        
	        for (Metric m: metrics)
	        {
	        	
	        	System.out.println(m.getName()+ "::" +m.getValue() );
	        	
	        }

	        List<String> metricsToCheck = Arrays.asList(
	                "Timestamp", "Documents", "Frames", "JSEventListeners",
	                "LayoutObjects", "MediaKeySessions", "Nodes",
	                "Resources", "DomContentLoaded", "NavigationStart");
	        
	        

//	        metricsToCheck.forEach( metric -> System.out.println(metric +
//	                " is : " + metrics.get(metricNames.indexOf(metric)).getValue()));
	        for (Metric m: metrics)
	        {
	        	if(m.getName().equalsIgnoreCase("DomContentLoaded"))
	        	{
	        		
	        		long seconds = TimeUnit.MILLISECONDS.toSeconds(m.getValue().longValue());
	        //		System.out.println("DomContentLoaded in Seconds :" +seconds);

	        	}
	        	
	        }
	        driver.close();
	        driver.quit();
	    }
	
		
	
   

}
