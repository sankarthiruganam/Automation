package com.browser;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class Demo {
	
	private static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		


		ChromeOptions options = new ChromeOptions();
		options.addArguments("--ignore-certificate-errors");
		options.addArguments("--disable-web-security");
		options.addArguments("--disable-site-isolation-trials");
		options.addArguments("--disable-blink-features=AutomationControlled");
		options.addArguments("--disable-extensions");
		options.addArguments("--remote-allow-origins=*");
		options.setPageLoadStrategy(PageLoadStrategy.NONE);
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
	//	WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(options);
	//	driver.get("https://simmer-b.kfc-digital.io");
		driver.get("https://www.google.com/");
	//	int size = driver.findElements(By.tagName("iframe")).size();
	//	System.out.println("lll"+size);
//		Thread.sleep(60000);
//		WebElement ele=driver.findElement(By.xpath("//figure[@class='ProfileButton_icon-account__ZXM7z']"));
//		highLighterMethod(driver,ele);
//		
//		ele.click();
//		Thread.sleep(50000);
//		driver.findElement(By.xpath("//input[@class='email-input text-input']")).click();
//		driver.findElement(By.xpath("//input[@class='email-input text-input']")).sendKeys("sankart@gmail.com");
//		driver.findElement(By.xpath("//input[@class='password-input text-input']")).click();
//		driver.findElement(By.xpath("//input[@class='password-input text-input']")).sendKeys("sankart");
//		driver.findElement(By.xpath("//button[@type='submit']")).click();
	//	driver.quit();
	//	driver.close();
		
	}
	public static void highLighterMethod(WebDriver driver, WebElement ele){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
	}
	

}
