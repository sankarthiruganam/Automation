import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;

import lombok.SneakyThrows;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.proxy.CaptureType;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.MethodName.class)
public class BrowserMobProxyExample {
	WebDriver driver;
	BrowserMobProxyServer proxy;
	Proxy seleniumProxy;

	@BeforeAll
	public void setup() throws UnknownHostException {
		// Proxy Operations
		proxy = new BrowserMobProxyServer();
		proxy.start(8080);
		seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
		String hostIp = Inet4Address.getLocalHost().getHostAddress();
		seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
		seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
		proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
		System.setProperty("webdriver.chrome.driver", "/Users/sankarthirugnan/Documents/Chrome/chromedriver");
		System.setProperty("webdriver.chrome.whitelistedIps", "");
		DesiredCapabilities seleniumCapabilities = new DesiredCapabilities();
		seleniumCapabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		seleniumCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--allow-insecure-localhost");
		options.addArguments("--ignore-urlfetcher-cert-requests");
		options.addArguments("--ignore-ssl-errors=yes");
		options.addArguments("--ignore-certificate-errors");
		seleniumCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(seleniumCapabilities);
	}

	@Test
	public void browserMobProxyTest() throws InterruptedException, IOException {
		WebDriverWait wait = new WebDriverWait(driver, 90);
		proxy.newHar("BTPerformance");
		driver.get("http://autokidssales.axis360qa5.baker-taylor.com");
		driver.manage().window().maximize();
		JavascriptExecutor j = (JavascriptExecutor) driver;
		if (j.executeScript("return document.readyState").toString().equals("complete")) {
			System.out.println("Page has loaded");
		}
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("loginBtn"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("LogOnModel_UserName"))).sendKeys("BTAuto");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'login')]"))).click();
		Thread.sleep(3000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toggle"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("Id"))).click();
		WebElement ele = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'Children')]")));
		scrollingDown(ele);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toggle"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'PROGRAMS')]"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("mat-tab-label-0-1"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toggle"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'CHECKOUTS')]"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@href,'#wishlist')]"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'RECOMMEND')]")))
				.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@href,'#history')]"))).click();
		Har har = proxy.getHar();
		File harFile = new File("BTPerformance.har");
		har.writeTo(harFile);
	}

	@AfterAll
	public void teardown() {
		proxy.stop();
		driver.quit();
	}

	public void scrollingDown(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wt = new WebDriverWait(driver, 100);
		wt.until(ExpectedConditions.visibilityOf(element));
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}
}