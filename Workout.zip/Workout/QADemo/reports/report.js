$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "def13966-c216-4e78-adcf-001e937cef51",
    "feature": "validate the Element features",
    "scenario": "validate the Element features",
    "start": 1702552866883,
    "group": 1,
    "content": "",
    "tags": "@tag,@tag2,",
    "end": 1702552911133,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});