package com.driverFactory;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverFactory {

	public WebDriver getDriver() throws IOException {
		WebDriver driver;
		String browser = "CHROME";
		BrowserList browserType = BrowserList.valueOf(browser.toUpperCase());
		switch (browserType) {

		case CHROME:
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			break;
		default:
			throw new IOException();
		}
		return driver;
	}

	public enum BrowserList {
		CHROME, IE, SAFARI, FIREFOX
	}
}
