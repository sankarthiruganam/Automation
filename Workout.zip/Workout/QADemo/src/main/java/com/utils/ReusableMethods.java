package com.utils;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverFactory.DriverManager;

public class ReusableMethods {

	public static WebDriver driver = null;
	public static WebDriverWait wait = null;

	public ReusableMethods() {
		wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(20));
	}

	public void ClickOnWebElement(WebElement element) {
		WebElement ele = wait.until(ExpectedConditions.visibilityOf(element));
		ele.click();

	}

	public void jsClick(WebElement element) {
		WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(element));
		JavascriptExecutor jscript = (JavascriptExecutor) DriverManager.getDriver();
		jscript.executeScript("arguments[0].click();", ele);
	}

	public void sendKeysValue(WebElement element, String value) {
		WebElement ele = wait.until(ExpectedConditions.visibilityOf(element));
		ele.clear();
		ele.sendKeys(value);

	}
}
