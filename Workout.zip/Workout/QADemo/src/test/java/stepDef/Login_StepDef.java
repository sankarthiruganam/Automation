package stepDef;


import com.PageObject.ElementsPage;
import com.PageObject.HandleMultipleWindows;
import com.driverFactory.DriverManager;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login_StepDef {

	ElementsPage elePage= new ElementsPage(DriverManager.getDriver());
	HandleMultipleWindows windowsPage=new HandleMultipleWindows(DriverManager.getDriver());

	@Given("user launch the {string}")
	public void user_launch_the(String url) {DriverManager.getDriver().get(url);
	}

	@When("user the select the Elements")
	public void user_the_select_the_Elements() {
		elePage.clickOnElementIcon();
	}

	@When("user select the text box")
	public void user_select_the_text_box() {
		elePage.selectTextBox();
	}

	@When("user enter the name {string} and email {string}")
	public void user_enter_the_name_and_email(String name, String email) {
		elePage.enterUserNameandEmail(name,email);
	}

	@When("user enter the address {string} and permanentAddress {string}")
	public void user_enter_the_address_and_permanentAddress(String address1, String address2) {
		elePage.enterAddress(address1, address2);
	}

	@Then("user submit the Forms")
	public void user_submit_the_Forms() {
		elePage.sumitTextForm();
	}
	@And("user the select the alertFrame")
	public void user_the_select_the_alertFrame()
	{
		windowsPage.clickAlertFrame();
	}
	@And("user select Browserwindow")
	public void user_select_Browserwindow()
	{
		windowsPage.clickBrowserWindow();
	}
	@And("Handled newTab")
    public void handledNewTab() {
		windowsPage.handleNewTab();	
    }
	
	
}
