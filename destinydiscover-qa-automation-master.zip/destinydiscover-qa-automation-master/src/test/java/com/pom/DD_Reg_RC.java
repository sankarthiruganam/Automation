package com.pom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import cucumber.api.java.en.Then;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class DD_Reg_RC extends CapabilitiesAndWebDriverUtils {

	public static final Logger logger = LogManager.getLogger(DD_Reg_RC.class);
	static ExcelReader reader = new ExcelReader();
	public static User_Landing_Page ULP = new User_Landing_Page();
	public static CreateChallengeAddTitles addTitle = new CreateChallengeAddTitles();

	public DD_Reg_RC() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/*******************************************************RC Creator - Reusable Method***********************************************/

	public void saveChMandatoryCheck() throws IOException {
		Assert.assertTrue(CreateAChallengeBasicChallengeDetails.saveChallengeBtn.isDisplayed());
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.saveChallengeBtn);
		logger.info(getData("platformName") + " _ Tap on Save Challenge #Pass");
		waitFor(5000);
		try {
			Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.rcPageHeader_lbl.isDisplayed());
			logger.info(getData("platformName") + " _ User Navigates to Rc Page #Pass");
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/saveMandatoryCheck.png");
			ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		} catch (Exception e) {
			logger.info(getData("platformName") + " _ User Not able to save chl without mandatory fields #Pass");
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/saveMandatoryCheck.png");
		}
	}

	public void duplicateChallengeName() throws IOException {
		waitFor(2000);
		SendKeysOnMobileElement(CreateAChallengeBasicChallengeDetails.challengeName, RC_SmokePage.actualchallenegeName);
		hideMobileKeyboard();
		logger.info(getData("platformName") + " - Entered Challenge Name as :" + RC_SmokePage.actualchallenegeName
				+ "  #Pass");
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/CreateChallange/ChallengeNameEntered.png");
	}

	public void duplicateAlertCheck() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData1 = reader.getData("./Data/MobileData.xlsx", "Create challenge");
		waitFor(9000);
		Assert.assertTrue(CreateAChallengeBasicChallengeDetails.duplicateChNameAlert.isDisplayed());
		Assert.assertEquals(CreateAChallengeBasicChallengeDetails.duplicateChNameAlert.getText(),
				testData1.get(0).get("dulpicateChName_Alert"));
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/CreateChallenge/duplicateChallenge.png");
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.duplicateChNameAlertOKBtn);
		logger.info(getData("platformName") + " - Duplicate Challenge Name Validation  #Pass");
		waitFor(2000);
	}

	public void saveChallengeTap() throws IOException {
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.saveChallengeBtn);
		logger.info(getData("platformName") + " - Save challenge button tapped  #Pass");
	}

	public void addFriendCTATap() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "AddFriends");
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.addFriendCTA);
		logger.info(getData("platformName") + " - Add friend button clicked #Pass");
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddFriendPage.png");
		Assert.assertEquals(CreateChallengeAddFriends.searchHeader.getText(), testData.get(0).get("lbl_Header"));
		waitForElementDisplayed(CreateChallengeAddFriends.addToChallenge);
	}

	public void addSameFriendCheck() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "AddFriends");
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			SendKeysOnMobileElement(CreateChallengeAddFriends.searchBox, testData.get(1).get("inp_friendName"));
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddFriendInput.png");
			waitFor(10000);
			List<MobileElement> userNamelist = CreateChallengeAddFriends.recentSearchfriendList;
			logger.info(getData("platformName") + " - Suggested Friend List Size : " + userNamelist.size() + " #Pass");
			List<MobileElement> inviteOption = CreateChallengeAddFriends.inviteOptionList;
			for (int i = 0; i <= userNamelist.size() - 1; i++) {
				ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(i));
				waitFor(2000);
				String addChallengeTxt1 = CreateChallengeAddFriends.addToChallenge.getText();
				ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(i));
				waitFor(2000);
				String addChallengeTxt2 = CreateChallengeAddFriends.addToChallenge.getText();
				Assert.assertEquals(addChallengeTxt1, addChallengeTxt2);
				logger.info(getData("platformName") + " - user not able to add same friend twice #Pass");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddFriendPage_FriendAdded.png");
				ClickOnMobileElement(CreateChallengeAddFriends.addToChallenge);
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			SendKeysOnMobileElement(CreateChallengeAddFriends.searchBox, testData.get(1).get("inp_friendName"));
			CreateChallengeAddFriends.searchBox.sendKeys(Keys.ENTER);
			waitFor(7000);
			ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(0));
			waitFor(2000);
			ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(0));
			waitFor(3000);
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddFriendPage_FriendAdded.png");
			Assert.assertTrue(CreateChallengeAddFriends.useralreadyaddedpopuptxt.isDisplayed());
			ClickOnMobileElement(CreateChallengeAddFriends.popUpOkBtn);
			logger.info(getData("platformName") + " - user not able to add same friend twice #Pass");
			ClickOnMobileElement(CreateChallengeAddFriends.addToChallenge);
		}

	}

	public void removeFriend() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "AddFriends");
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			SendKeysOnMobileElement(CreateChallengeAddFriends.searchBox, testData.get(1).get("inp_friendName"));
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			SendKeysOnMobileElement(CreateChallengeAddFriends.searchBox, testData.get(0).get("inp_friendName"));
			CreateChallengeAddFriends.searchBox.sendKeys(Keys.ENTER);
		}
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddFriendInput.png");
		waitFor(8000);
		List<MobileElement> userNamelist = CreateChallengeAddFriends.recentSearchfriendList;
		logger.info(getData("platformName") + " - Suggested Friend List Size : " + userNamelist.size() + " #Pass");
		List<MobileElement> inviteOption = CreateChallengeAddFriends.inviteOptionList;
		ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(0));
		String addChallengeTxt1 = CreateChallengeAddFriends.addToChallenge.getText();
		ClickOnMobileElement(CreateChallengeAddFriends.removeFriendfromSearchPage);
		String addChallengeTxt2 = CreateChallengeAddFriends.addToChallenge.getText();
		if (addChallengeTxt1.equals(addChallengeTxt2)) {
			logger.info(getData("platformName") + " - Friend not removed from search page #Fail");
			Assert.assertTrue(false);
		} else {
			logger.info(getData("platformName") + " - Friend removed from search page #Pass");
		}
		ClickOnMobileElement(CreateChallengeAddFriends.inviteOptionList.get(0));
		ClickOnMobileElement(CreateChallengeAddFriends.addToChallenge);
		CreateChallengeAddFriends.removeFriendFromChallenge();
	}

	public void addTitleCTATap() {
		swipeDown();
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.addTitlesCTA);
		waitFor(3000);
		Assert.assertTrue(CreateChallengeAddTitles.filterIcon.isDisplayed());
	}

	public void addSameTitleCheck() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Add Titles");
		SendKeysOnMobileElement(CreateaChallengeSearchTitleResultsListView.searchTextBox,
				testData.get(1).get("Title_Keyword"));
		waitFor(7000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			ClickOnMobileElement(CreateChallengeAddTitles.keywordSuggestionList.get(0));
			waitFor(5000);
			ClickOnMobileElement(CreateChallengeAddTitles.filterIcon);
			ClickOnMobileElement(CreateChallengeAddTitles.filterPagePlusIcon.get(1));
			waitFor(1000);
			ClickOnMobileElement(CreateChallengeAddTitles.subfilterSelcetion.get(2));
			waitFor(1000);
			ClickOnMobileElement(CreateChallengeAddTitles.filterApplyButton);
			waitFor(15000);
			ClickOnMobileElement(CreateChallengeAddTitles.title_MoreOptions.get(0));
			String addChal = CreateChallengeAddTitles.MoreOption_lbl.get(2).getText();
			System.out.println("Before Tap : " + addChal);
			ClickOnMobileElement(CreateChallengeAddTitles.addToChallengeButton);
			waitFor(7000);
			ClickOnMobileElement(CreateChallengeAddTitles.title_MoreOptions.get(0));
			String removeChal = CreateChallengeAddTitles.MoreOption_lbl.get(2).getText();
			System.out.println("After Tap : " + removeChal);
			try {
				if (addChal.equals(removeChal)) {
					logger.info(" --" + getData("platformName")
							+ " - Add to challenge button should turn into Remove from challenge after taping #Fail");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/CreateChallenge/Add_remove.png");
				}
			} catch (Exception e) {
				logger.info(" --" + getData("platformName")
						+ " - Add to challenge button should turn into Remove from challenge after taping #Pass");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/CreateChallenge/Add_remove.png");
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			CreateaChallengeSearchTitleResultsListView.searchTextBox.sendKeys(Keys.ENTER);
			ClickOnMobileElement(CreateChallengeAddTitles.filterIcon);
			waitFor(8000);
			ClickOnMobileElement(CreateChallengeAddTitles.availablePlusIcon);// need to update for iOS
			waitFor(1000);
			ClickOnMobileElement(CreateChallengeAddTitles.subfilterSelcetion.get(1));
			waitFor(1000);// need to update for iOS
			ClickOnMobileElement(CreateChallengeAddTitles.filterApplyButton);
			waitFor(18000);
			ClickOnMobileElement(CreateChallengeAddTitles.title_MoreOptions.get(0));
			waitFor(1000);
			ClickOnMobileElement(CreateChallengeAddTitles.addToChallengeButton);
			waitFor(1000);
			ClickOnMobileElement(CreateChallengeAddTitles.title_MoreOptions.get(0));
			waitFor(3000);
			try {
				if (CreateChallengeAddTitles.removeFromChallengeButton.isDisplayed()) {
					logger.info(" --" + getData("platformName")
							+ " - Add to challenge button should turn into Remove from challenge after taping #Pass");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/CreateChallenge/Add_remove.png");
				}
			} catch (Exception e) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/CreateChallenge/Add_remove.png");
				logger.info(" --" + getData("platformName") + " - Add to challenge button displayed #Fail");
				Assert.assertTrue(false);
			}
			logger.info(" --" + getData("platformName") + " - Not able to add same title again #Pass");

		}

	}

	public void myStuffNav() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(2000);
		Assert.assertTrue(destinyLogo.isDisplayed());
		logger.info(getData("platformName") + " - User is on Home page by defaut #Pass");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/HomePage.png");
		try {
		ClickOnMobileElement(footer_MyStuffMenu);
		}
		catch(Exception e) {
			Actions s=new Actions(driver);
			s.click(footer_MyStuffMenu).build().perform();
		}
		waitFor(4000);
		Assert.assertEquals(myStuff_PageHeader.getText(), testData.get(0).get("myStuff_PageHeader"));
		Assert.assertTrue(myStuff_Checkouts.isDisplayed());
		Assert.assertTrue(myStuff_Recent.isDisplayed());
		Assert.assertTrue(myStuff_Holds.isDisplayed());
		Assert.assertTrue(myStuff_Assigned.isDisplayed());
		logger.info(getData("platformName")
				+ " - User navigtes to My Stuff Landing page after tapping on MyStuff Bottom menu #Pass");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/MyStuffPage.png");
	}

	public void addTitlefromMyStuff() throws IOException {
		ClickOnMobileElement(myStuff_Checkouts);
		waitFor(3000);
		System.out.println("Mystuff more size"+myStuff_moremenu.size());
		if (myStuff_moremenu.size() != 0) {
			try {
				ClickOnMobileElement(myStuff_moremenu.get(0));
				ClickOnMobileElement(checkout_AddNewChlBtn);
				waitFor(4000);
				swipeDown();
				waitFor(2000);
				Assert.assertTrue(CreateAChallengeBasicChallengeDetails.removeTitleXIcon.get(0).isDisplayed());
				logger.info(getData("platformName") + " - added titie id displayed ");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage.png");
			} catch (Exception e) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage.png");
			}
			waitFor(3000);
			ClickOnMobileElement(pageBackButton);
			ClickOnMobileElement(discardOkButton);	
		} else {
			logger.info(getData("platformName") + " - No titles checked out ");
		}
		ClickOnMobileElement(myStuff_Recent);
		waitFor(3000);
		if (myStuff_moremenu.size() != 0) {
			try {
				ClickOnMobileElement(myStuff_moremenu.get(0));
				ClickOnMobileElement(recent_AddNewChlBtn);
				waitFor(4000);
				swipeDown();
				Assert.assertTrue(CreateAChallengeBasicChallengeDetails.removeTitleXIcon.get(0).isDisplayed());
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage1.png");
			} catch (Exception e) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage1.png");
			}
			waitFor(3000);
			ClickOnMobileElement(pageBackButton);
			ClickOnMobileElement(discardOkButton);	
		} else {
			logger.info(getData("platformName") + " - No titles are read recently ");
		}
		ClickOnMobileElement(myStuff_Holds);
		waitFor(3000);
		if (myStuff_moremenu.size() != 0) {
			try {
				ClickOnMobileElement(myStuff_moremenu.get(0));
				ClickOnMobileElement(hold_AddNewChlBtn);
				waitFor(4000);
				swipeDown();
				Assert.assertTrue(CreateAChallengeBasicChallengeDetails.removeTitleXIcon.get(0).isDisplayed());
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage2.png");
			} catch (Exception e) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage2.png");
			}
			waitFor(3000);
			ClickOnMobileElement(pageBackButton);
			ClickOnMobileElement(discardOkButton);
		} else {
			logger.info(getData("platformName") + " - No titles are put on hold ");
		}
		ClickOnMobileElement(myStuff_Assigned);
		waitFor(3000);
		if (myStuff_moremenu.size() != 0) {
			try {
				ClickOnMobileElement(myStuff_moremenu.get(0));
				ClickOnMobileElement(assign_AddNewChlBtn);
				waitFor(4000);
				swipeDown();
				Assert.assertTrue(CreateAChallengeBasicChallengeDetails.removeTitleXIcon.get(0).isDisplayed());
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage3.png");
			} catch (Exception e) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage3.png");
			}

		} else {
			logger.info(getData("platformName") + " - No title assigned");
		}
	}

	public void discoverNav() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(5000);
		try {
			ClickOnMobileElement(footer_DiscoverMenu);
			waitFor(5000);
		}
		catch(Exception e)
		{
			Actions s=new Actions(driver);
			s.click(footer_DiscoverMenu).build().perform();
			System.out.println("Action Clicked");
		}

//		Assert.assertEquals(ULP.discover_PageHeader.getText(),testData.get(0).get("discover_pageHeader"));
		Assert.assertTrue(discover_AudioBooks_lbl.isDisplayed());
		Assert.assertTrue(discover_Ebooks_lbl.isDisplayed());
		logger.info(getData("platformName")
				+ " - User navigtes to Discover Landing page after tapping on Discover Bottom menu #Pass ");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/DiscoverPage.png");
	}

	public void addTitlefromDiscover() throws IOException {
		waitFor(3000);
		for (int i = 0; i <= 4; i++) {
			if (myStuff_moremenu.size() != 0) {
				try {
					ClickOnMobileElement(myStuff_moremenu.get(0));
					ClickOnMobileElement(recent_AddNewChlBtn);
					waitFor(4000);
					swipeDown();
					Assert.assertTrue(CreateAChallengeBasicChallengeDetails.removeTitleXIcon.get(0).isDisplayed());
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage1.png");
					logger.info(getData("platformName")+ "Discover page add title to challenge  #Pass ");
				} catch (Exception e) {
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/ULP/checkoutPage1.png");
				}
				waitFor(3000);
				ClickOnMobileElement(pageBackButton);
				ClickOnMobileElement(discardOkButton);	
				break;
			} else {
				if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
				ClickOnMobileElement(discoverPg_RightArrow);
				}
			}
		}
	}

	public void addTitlefromHome() throws IOException {
		swipeDown();
		swipeDown();
		System.out.println("Swipe happens");
		waitFor(3000);
		ClickOnMobileElement(myStuff_moremenu.get(0));
		System.out.println("clicked");
		int moreMenu = acList.size();
		System.out.println(moreMenu);
		if (moreMenu > 2 && moreMenu > 4) {
			waitFor(1000);
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddTitlehome.png");
			ClickOnMobileElement(recent_AddNewChlBtn);
			logger.info(getData("platformName") + " _ Added to Challenge #Pass");
			waitFor(5000);
		} else if (moreMenu > 2 && moreMenu <= 4) {
			waitFor(1000);
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/CreateChallenge/AddTitlehome.png");
			ClickOnMobileElement(hold_AddNewChlBtn);
			logger.info(getData("platformName") + " _ Added to Challenge #Pass");
		}
		waitFor(3000);
		ClickOnMobileElement(pageBackButton);
		ClickOnMobileElement(discardOkButton);	
	}

	public void activeChallengeCheck() throws IOException {
		waitFor(7000);
		if (lbl_ActiveChallenges.size() != 0) {
			if (getData("platformName").equalsIgnoreCase("android")
					|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
				Assert.assertTrue(BookClubLandingScreen.challengeList.get(0).isDisplayed());
			}
			if (getData("platformName").equalsIgnoreCase("iOS")
					|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
				Assert.assertTrue(BookClubLandingScreen.challengeList.get(5).isDisplayed());
			}
			logger.info(getData("platformName") + " - Active Challenges are displayed");

		} else {
			logger.info(getData("platformName") + " - No Active ch available to display");
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/activechallenge.png");
			Assert.assertTrue(false);
		}

	}

	public void draftChallengesCheck() throws IOException {
		waitFor(8000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			for (int i = 0; i <= 10; i++) {
				try {
					MobileElement findElement = (MobileElement) driver.findElement(
							MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
									+ ".scrollIntoView(new UiSelector().text(\"DRAFT CHALLENGES\"))"));
					ClickOnMobileElement(findElement);
					Assert.assertTrue(findElement.isDisplayed());
					logger.info(getData("platformName") + " - Draft ch is displayed #Pass");
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/Draft_Ch.png");
					break;
				} catch (Exception e) {
					if (i == 10) {
						logger.info(getData("platformName") + " - No Draft ch available to display");
					}
				}
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			for (int i = 0; i <= 25; i++) {
				if (lbl_DraftChallenge.size() == 0) {
					swipeDown();
				} else if (lbl_DraftChallenge.size() != 0) {
					Assert.assertTrue(BookClubLandingScreen.challengeList.get(5).isDisplayed());
					logger.info(getData("platformName") + " - Draft Challenge available to display");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/RC/draftchallenge.png");
					break;
				} else if (i == 25) {
					logger.info(getData("platformName") + " - Draft Challenge not available to display");
					Assert.assertTrue(false);
				}
			}
		}
	}

	public void closedChallengesCheck() throws IOException {
		waitFor(8000);
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
			for (int i = 0; i <= 10; i++) {
				try {
					MobileElement findElement = (MobileElement) driver.findElement(
							MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
									+ ".scrollIntoView(new UiSelector().text(\"CLOSED CHALLENGES\"))"));
					ClickOnMobileElement(findElement);
					Assert.assertTrue(findElement.isDisplayed());
					logger.info(getData("platformName") + " - Closed ch is displayed #Pass");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/RC/Closed_Ch.png");
					break;
				} catch (Exception e) {
					if (i == 10) {
						logger.info(getData("platformName") + " - No Closed ch available to display");
					}
				}
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			for (int i = 0; i <= 25; i++) {
				if (lbl_ClosedChallenge.size() == 0) {
					swipeDown();
				} else if (lbl_ClosedChallenge.size() != 0) {
					Assert.assertTrue(BookClubLandingScreen.challengeList.get(5).isDisplayed());
					logger.info(getData("platformName") + " - Closed Challenge available to display");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/RC/closedchallenge.png");
					break;
				} else if (i == 25) {
					logger.info(getData("platformName") + " - No Closed challenges available to display");
					Assert.assertTrue(false);
				}
			}
		}
	}
	public void setReadByDtTap() throws IOException {
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			ClickOnMobileElement(CreateAChallengeSetReadbyDate.calenderIcon);
		waitFor(1000);
		String startDate = Integer.toString(getCurrentDate());
		System.out.println(startDate);
		MobileElement sd = (MobileElement) driver.findElement(By.xpath("//android.view.View[@text='"+ startDate +"']"));
		System.out.println(sd.getText());
		waitFor(1000);
		ClickOnMobileElement(sd);
		waitFor(1000);
		ClickOnMobileElement(CreateAChallengeSetReadbyDate.calenderIconOK);
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.dateOpt);
			int currentDate = getCurrentDate();
			System.out.println("CurrentDate " + currentDate);
			String date = Integer.toString(currentDate);
			SendKeysOnMobileElementList(CreateAChallengeSetReadbyDate.iOSDate.get(0), date);
			ClickUsingXandYCords(CreateAChallengeBasicChallengeDetails.iosDontBtn);
			waitFor(3000);
			String afterset = CreateAChallengeSetReadbyDate.aftetSetDateInCCpage.getText();
			String setdate = afterset.substring(8, 9);
			System.out.println("SetDate:" + setdate);
			if (date.equalsIgnoreCase(setdate)) {
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/SetDate.png");
				logger.info(getData("platformName") + " - User Able to set Curent date as end date #Fail");
				Assert.assertTrue(false);
			} else {
				logger.info(getData("platformName") + " - User not  Able to set Curent date as end date #Pass");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/RC/SetCurrentDate.png");

			}
		}
	}
	
	public void endDateCheck() throws IOException {
		swipeDown();
   		 if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		String startDate = Integer.toString(getCurrentDate());
		String setdt = CreateAChallengeSetReadbyDate.calenderIcon.getText();
		String[] split = setdt.split(",");
		if (split[0].contains(startDate)) {

			logger.info(getData("platformName") + " User able to create a challenge with current dt as end date");
			Assert.assertTrue(false);
		} else {
			logger.info(getData("platformName") + " User not able to create a challenge with current dt as end date");
		} 
    	     }
	}

/******************************************************RC Edit - Reusable Methods***********************************************/

	public void closeChallenge() {
		waitFor(3000);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.moreIcon);
		ClickOnMobileElement(closeChallengeBtn);
		ClickOnMobileElement(closePrgPop_okBtn);
		waitFor(5000);
	}

	public void closedChallengeValidation() throws IOException {
		waitFor(8000);
		for (int i = 0; i <= 10; i++) {
			try {
				MobileElement findElement = (MobileElement) driver
						.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
								+ ".scrollIntoView(new UiSelector().text(\"CLOSED CHALLENGES\"))"));
				ClickOnMobileElement(findElement);
				Assert.assertTrue(findElement.isDisplayed());
				logger.info(getData("platformName") + " - Closed ch is displayed #Pass");
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/Closed_Ch.png");
				break;
			} catch (Exception e) {
				if (i == 10) {
					logger.info(getData("platformName") + " - No Closed ch available to display");
				}
			}
		}
		for (int i = 0; i <= 10; i++) {
			try {
				System.out.println(CreateAChallengeBasicChallengeDetails.actualchallenegeName);
				String challengeNameToTap = CreateAChallengeBasicChallengeDetails.actualchallenegeName;
				MobileElement findElement = (MobileElement) driver
						.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
								+ ".scrollIntoView(new UiSelector().text(\"" + challengeNameToTap + "\"))"));
				System.out.println(findElement.getText());
				logger.info(getData("platformName") + " -Closed Challenge found under Closed Challenge #Pass ");
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/Closed_Chl.png");
				break;
			} catch (Exception e) {
				if (i == 10) {
					logger.info(getData("platformName") + " - Closed ch not available to display...Checking again!!!");
				}
			}
		}
	}

/*******************************************************RC Participant - Reusable Methods 
 * @throws IOException ***********************************************/

	public void navToActiveChallenge() throws IOException {
		waitFor(3000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		ClickOnMobileElement(challengeList.get(0));
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			ClickOnMobileElement(challengeList.get(6));
		}
		try {
			waitFor(5000);
			ClickOnMobileElement(ReadingChallengeAcceptRejectChallenge.accpetChallegeButton);
			waitFor(3000);
			ClickOnMobileElement(ReadingChallengeAcceptRejectChallenge.cnfPage_GoToChallenge);
			waitFor(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void participantRCDetailScreen() throws InvalidFormatException, IOException {
		logger.info(" --" + getData("platformName") + " -- Creator RC details Page Validation Start -- ");
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "RC Details Screen");
		List<Map<String, String>> testData1 = reader.getData("./Data/MobileData.xlsx", "Reminder and End date");
		List<Map<String, String>> testData2 = reader.getData("./Data/MobileData.xlsx", "Create challenge");
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.rcPageHeader_lbl.isDisplayed());
		logger.info(
				" --" + getData("platformName") + " - Challenge Name is displayed as RC details page Header  #Pass");
		waitFor(7000);
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.moreIcon.isDisplayed());

		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertEquals(CreateAChallengeCreatorRCDetailsScreen.creatorAvatar.isDisplayed(), true);
		} 

		logger.info(" --" + getData("platformName") + " - Challenge Created By : "
				+ CreateAChallengeCreatorRCDetailsScreen.creatorName.getText());
//		Assert.assertEquals(creatorName.getText(), testData.get(2).get("defVal_Creatorname"));
		Assert.assertEquals(CreateAChallengeCreatorRCDetailsScreen.createDate.isDisplayed(), true);
		logger.info(" --" + getData("platformName") + " - Challenge Created Date : "
				+ CreateAChallengeCreatorRCDetailsScreen.createDate.getText());
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.readingChallengeIcon.isDisplayed());
			logger.info(" --" + getData("platformName") + "- Challenge Icon is displayed ");
		}
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.readingChallenge_lbl.isDisplayed());
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.challengeName.isDisplayed());
		logger.info(" --" + getData("platformName") + "- Challenge Name is displayed ");
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.challengeDesc.isDisplayed());
		logger.info(" --" + getData("platformName") + "- Challenge Desc is displayed ");
		logger.info(" --" + getData("platformName")
				+ " - CreatorName,CreatorAvatar,CreatedDate,Ch_Name,Ch_Description,ReadyBydate,Reminder Assertion #Pass");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RCDetailPage/RC Page.png");

		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.readingList_lbl.isDisplayed());
		} else {
			Assert.assertEquals(CreateAChallengeCreatorRCDetailsScreen.readingList_lbl.isDisplayed(), true);
		}
		if (CreateAChallengeCreatorRCDetailsScreen.challengeTitleList.size() != 0) {
			for (int i = 0; i <= CreateAChallengeCreatorRCDetailsScreen.challengeTitleList.size() - 1; i++) {
				Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.challengeTitleList.get(i).isDisplayed());
			}
			if (CreateAChallengeCreatorRCDetailsScreen.challengeTitleList.size() > 2) {
				horizontalSwipe(CreateAChallengeCreatorRCDetailsScreen.challengeTitleList);
			}
			logger.info(" --" + getData("platformName") + " - Challenge Titles are displayed #Pass");
		} else {
			Assert.assertTrue(false);
			logger.info(" --" + getData("platformName") + " - Challenge Titles are displayed #Fail");
		}
		swipeDown();
		waitFor(8000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.participants_lbl.isDisplayed());
		} 
		if (CreateAChallengeCreatorRCDetailsScreen.partipantsAvatar.size() != 0) {
			for (int i = 0; i <= CreateAChallengeCreatorRCDetailsScreen.partipantsAvatar.size() - 1; i++) {
				if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {

				Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.partipantsAvatar.get(i).isDisplayed());
				Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.participantsList.get(i).isDisplayed());
				Assert.assertTrue(
						CreateAChallengeCreatorRCDetailsScreen.participantProgresspercent.get(i).isDisplayed());
				}
				if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
				String participantdetails = CreateAChallengeCreatorRCDetailsScreen.partipantsAvatar.get(i).getAttribute("value");
				logger.info(" --" + getData("platformName") + participantdetails +" - Challenge participants are displayed #Pass");
			}}
			if (CreateAChallengeCreatorRCDetailsScreen.participantsList.size() > 5) {
				horizontalSwipe(CreateAChallengeCreatorRCDetailsScreen.participantsList);
			}
			logger.info(" --" + getData("platformName") + " - Challenge participants are displayed #Pass");
		} else {
			Assert.assertTrue(false);
			logger.info(" --" + getData("platformName") + " - Challenge participants are displayed #Fail");
		}
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/RCDetailPage/RC Participants.png");

		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.moreIcon);
		waitFor(2000);
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.leaveChallengeActionBtn.isDisplayed());
		Assert.assertEquals(CreateAChallengeCreatorRCDetailsScreen.leaveChallengeActionBtn.getText(),
				testData.get(0).get("leave ChallengeBtn_lbl"));
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/RCDetailPage/RC_page_More_actionbtns .png");
		logger.info(" --" + getData("platformName") + "RC page More action buttons Validation #Pass");
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.cancelChallengeActionBtn);
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/RCDetailPage/NavBack_RCpage .png");
		logger.info(getData("platformName") + " --- Preview Screen Validation End --- ");
	}

	public void addSameUser() throws IOException, InvalidFormatException {
		for (int i = 0; i <= 10; i++) {
			try {
				System.out.println(CreateAChallengeBasicChallengeDetails.actualchallenegeName);
				String challengeNameToTap = CreateAChallengeBasicChallengeDetails.actualchallenegeName;
				MobileElement findElement = (MobileElement) driver
						.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
								+ ".scrollIntoView(new UiSelector().text(\"" + challengeNameToTap + "\"))"));
				System.out.println(findElement.getText());
				ClickOnMobileElement(findElement);
				logger.info(getData("platformName") + " -Challenge found ");
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/RC/Chl.png");
				break;
			} catch (Exception e) {
				if (i == 10) {
					logger.info(getData("platformName") + " -ch not available...Checking again!!!");
				}
			}
		}
		waitFor(5000);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.moreIcon);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.editChallengeActionBtn);
		waitFor(3000);
		RC_SmokePage.searchAndAddFriend();
		ClickOnMobileElement(CreateAChallengeBasicChallengeDetails.startChallengeBtn);
		waitFor(5000);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
	}


	/*********************************************  RC Message center - Reusable Methods *************************************/


	public void messageCenterNav() throws IOException, InvalidFormatException {
		waitFor(5000);
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "MessageCenter");
		ClickOnMobileElement(Message_Center.messageCenterIcon);
		waitFor(5000);
		Assert.assertEquals(Message_Center.pageHeader_lbl.getText(), testData.get(0).get("lbl_Header"));
		logger.info(getData("platformName")
				+ " - user taped on message centre icon, navigating to messsage center page  #pass");
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/MessageCenter/landing page.png");
	}

	public void messageCenterDetailScreenNav() throws IOException {
		waitFor(5000);
		System.out.println("MessageHeader size :" + Message_Center.messageHeader.size());
		ClickOnMobileElement(Message_Center.messageHeader.get(0));
		waitFor(5000);
		Assert.assertTrue(Message_Center.msgDetailsPage_msgHeader.isDisplayed());
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/MessageCenter/Msg Detail Page.png");
	}

	public void decreaseCount() throws IOException {
		ClickOnMobileElement(Message_Center.rcpageBackButton);
		ClickOnMobileElement(Message_Center.pageBackIcon);
		waitFor(3000);
		String afterUnreadCount = Message_Center.unReadCountOnBellIcon.getText();
		System.out.println("After reading one message : " + Message_Center.unReadCountOnBellIcon.getText());
		if (afterUnreadCount.equals(Message_Center.unReadMsgCount)) {
			logger.info(getData("platformName") + " Message count not decreased ");
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/MC/unreadcount.png");
		} else {
			logger.info(getData("platformName") + " Message count decreased ");
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/MC/unreadcount.png");
		}
	}

	public void msgCenterScroll() throws InvalidFormatException, IOException {
		messageCenterNav();
		for (int i = 0; i < 5; i++) {
			swipeDown();
			waitFor(4000);
		}
	}

	public void markAsUnread() {
		waitFor(3000);
		ClickOnMobileElement(Message_Center.editBtn);
		ClickOnMobileElement(Message_Center.selectAllBtn);
		ClickOnMobileElement(Message_Center.markButton);
		ClickOnMobileElement(Message_Center.markasUnReadOption);
		waitFor(8000);
	}

	public void markAsRead() {
		waitFor(3000);
		ClickOnMobileElement(Message_Center.editBtn);
		ClickOnMobileElement(Message_Center.selectAllBtn);
		ClickOnMobileElement(Message_Center.markButton);
		ClickOnMobileElement(Message_Center.markasReadOption);
		waitFor(8000);
	}

	public void increaseCount() throws IOException {
		ClickOnMobileElement(Message_Center.pageBackIcon);
		waitFor(3000);
		try {
			String afterUnreadCount=Message_Center.unReadCountOnBellIcon.getText();
			System.out.println("After reading one message : "+Message_Center.unReadCountOnBellIcon.getText());
			if (afterUnreadCount.equals(Message_Center.unReadMsgCount)) {
				logger.info(getData("platformName")+" Message count not increased ");
				Screenshots.takeScreenshot(driver,"./Screenshots/"+getData("platformName")+"/MC/unreadcount.png");
			} else {
				logger.info(getData("platformName")+" Message count increased ");
				Screenshots.takeScreenshot(driver,"./Screenshots/"+getData("platformName")+"/MC/unreadcount.png");
			}
			
		} catch (Exception e) {
			logger.info(getData("platformName")+" User dont have unread meassage ");
			Screenshots.takeScreenshot(driver,"./Screenshots/"+getData("platformName")+"/MC/unreadcount.png");
		}
	}
	
	public int getCurrentDate()
	{
	    Calendar calendar = Calendar.getInstance();
	    Date today = calendar.getTime();
	    calendar.add(Calendar.DAY_OF_YEAR, 0);
	    Date tomorrow = calendar.getTime();
		return tomorrow.getDate();
		
	}
		
/*********************************************************Locators***************************************************/	

	@AndroidFindBy(xpath = "//*[@text='ACTIVE CHALLENGES']")
	@iOSXCUITFindBy(xpath = "//*[@value='ACTIVE CHALLENGES']")
	public static List<MobileElement> lbl_ActiveChallenges;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='more menu']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton")
	public static List<MobileElement> myStuff_moremenu;

	@AndroidFindBy(xpath = "(//*[@resource-id='com.follett.fss.searchread.stage:id/option_view'])[5]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Include in New Challenge']")
	public static MobileElement checkout_AddNewChlBtn;

	@AndroidFindBy(xpath = "(//*[@resource-id='com.follett.fss.searchread.stage:id/option_view'])[4]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Include in New Challenge']")
	public static MobileElement recent_AddNewChlBtn;

	@AndroidFindBy(xpath = "(//*[@resource-id='com.follett.fss.searchread.stage:id/option_view'])[3]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Include in New Challenge']")
	public static MobileElement hold_AddNewChlBtn;

	@AndroidFindBy(xpath = "(//*[@resource-id='com.follett.fss.searchread.stage:id/option_view'])[3]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Include in New Challenge']")
	public static MobileElement assign_AddNewChlBtn;

	@AndroidFindBy(xpath = "com.follett.fss.searchread.stage:id/right_arrow")
	@iOSXCUITFindBy(xpath = "//*[@name='Destiny Discover']")
	public static MobileElement discoverPg_RightArrow;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//*[@name='Destiny Discover']")
	public static MobileElement destinyLogo;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_my_stuff")
	@iOSXCUITFindBy(xpath = "//*[@name='MY STUFF']")
	public static MobileElement footer_MyStuffMenu;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Stuff']")
	public static MobileElement myStuff_PageHeader;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Checkouts']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Checkouts']")
	public static MobileElement myStuff_Checkouts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Recent']")
	@iOSXCUITFindBy(xpath= "//XCUIElementTypeButton[@name='Recent']")
	public static MobileElement myStuff_Recent;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Holds']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Holds']")
	public static MobileElement myStuff_Holds;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Assigned']")
	@iOSXCUITFindBy(xpath= "//XCUIElementTypeButton[@name='Assigned']")
	public static MobileElement myStuff_Assigned;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_discover")
	@iOSXCUITFindBy(xpath= "//*[@name='DISCOVER']")
	public static MobileElement footer_DiscoverMenu;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//*[@name='Destiny Discover']")
	public static MobileElement discover_PageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_ebooks_header_view")
	@iOSXCUITFindBy(xpath = "//*[@name='eBooks']")
	public static MobileElement discover_Ebooks_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_see_all_ebooks_button")
	@iOSXCUITFindBy(xpath = "//*[@name='See all'][1]")
	public static MobileElement discover_Ebooks_SeeAll;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//*[@name='eBooks']")
	public static MobileElement discover_Ebooks_ListPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_audiobooks_header_view")
	@iOSXCUITFindBy(xpath = "//*[@name='Audiobooks']")
	public static MobileElement discover_AudioBooks_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_see_all_audiobooks_button")
	@iOSXCUITFindBy(xpath = "//*[@name='See all'][2]")
	public static MobileElement discover_AudioBooks_SeeAll;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//*[@name='Audiobooks']")
	public static MobileElement discover_Audiobooks_ListPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/material_cover_image_view")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> discover_titleImage;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_back")
	@iOSXCUITFindBy(xpath = "//*[@name='Back']")
	public static MobileElement discover_ListPageBackBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/close_challenge_text")
	public static MobileElement closeChallengeBtn;

	@AndroidFindBy(xpath = "//*[@text='OK']")
	public static MobileElement closePrgPop_okBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/parentLayout")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> challengeList;

	@iOSXCUITFindBy(xpath = "//*[@value='DRAFT CHALLENGES']")
	public static List<MobileElement> lbl_DraftChallenge;

	@iOSXCUITFindBy(xpath = "//*[@value='CLOSED CHALLENGES']")
	public static List<MobileElement> lbl_ClosedChallenge;
    
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Back']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Back']")
	public static MobileElement pageBackButton;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/option_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton")
	public static List<MobileElement> acList;
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	@iOSXCUITFindBy(xpath = "//*[@name='OK']")
	public static MobileElement discardOkButton;

}

