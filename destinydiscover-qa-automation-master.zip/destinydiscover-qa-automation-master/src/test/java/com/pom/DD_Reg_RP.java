package com.pom;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class DD_Reg_RP extends CapabilitiesAndWebDriverUtils {
	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger(Login.class);
	BookClubParticipantRPDetailsScreenPage bookclubRp = new BookClubParticipantRPDetailsScreenPage();
	MyPrograms myProgram = new MyPrograms();
	OpenProgram openProgram = new OpenProgram();
	Message_Center messageCenter = new Message_Center();

	public DD_Reg_RP() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
/***********************************************RP Creator - Reusable methods***************************************/
	
	public void activeProgramSection() throws IOException {
		logger.info(getData("platformName") + " - Switching to my Program landing page #Pass");
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/Reading_Program/MyPrg_Landing_page.png");
		waitFor(3000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			if (myProgram.myprogramslist.size() != 0) {
				Assert.assertTrue(myProgram.activeprogram_lbl.isDisplayed());
				logger.info(getData("platformName") + " - Active Programs are displayed #Pass");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/Reading_Program/ActiveProgram.png");
			} else {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/Reading_Program/ActiveProgramFail.png");
				logger.info(getData("platformName") + " - Active Programs are not  displayed #Fail");
				Assert.assertTrue(false);
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			if (myProgram.myprogramslist.size() != 0) {
				Assert.assertTrue(myProgram.activeprogram_lbl.isDisplayed());
				logger.info(getData("platformName") + " - Active Programs are displayed #Pass");
			} else {
				logger.info(getData("platformName") + " - Active Programs are not  displayed #Fail");
				Assert.assertTrue(false);
			}
		}
	}
	
	public void draftProgramSection() throws IOException {
		
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			if (myProgram.draftprogram.size() != 0) {
				Assert.assertTrue(myProgram.draftprogram.get(0).isDisplayed());
				logger.info(getData("platformName") + " - Draft Programs are displayed #Pass");
			} else {
				logger.info(getData("platformName") + " - Draft Programs are not  displayed #Fail");
				Assert.assertTrue(false);
			}
		}
	}

	public void closedProgramSection() throws IOException {
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			for (int i = 0; i <= 20; i++) {
				try {
					MobileElement findElement = (MobileElement) driver.findElement(
							MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
									+ ".scrollIntoView(new UiSelector().text(\"CLOSED PROGRAMS\"))"));
					ClickOnMobileElement(findElement);
					Assert.assertTrue(findElement.isDisplayed());
					logger.info(getData("platformName") + " - Closed Program is displayed #Pass");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/Reading_Program/Closed Program.png");
					break;
				} catch (Exception e) {
					if (i == 20) {
						logger.info(getData("platformName") + " - No Closed Program available to display");
					}
				}
			}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			for (int i = 0; i <= 25; i++) {
				if (myProgram.closedProgram_lbl.size() == 0) {
					swipeDown();
				}
				if (myProgram.closedProgram_lbl.size() > 0) {
					logger.info(" --" + getData("platformName") + " - Closed Program validation pass -- ");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/Reading_Program/ClosedProgramPage.png");
				}
				if (i == 25) {
					logger.info(getData("platformName") + " - No Closed Program available to display");
					Screenshots.takeScreenshot(driver,
							"./Screenshots/" + getData("platformName") + "/Reading_Program/ClosedProgramFail.png");
					Assert.assertTrue(false);
				}
			}
		}
	}

	public void onGoingProgramSection() throws IOException {
		waitFor(8000);
		if (openProgram.openprogramList.size() != 0) {
			Assert.assertTrue(openProgram.onGoingProgram_lbl.isDisplayed());
			logger.info(getData("platformName") + " - onGoing Programs are displayed #Pass");
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/Reading_Program/ongoing program.png");
		} else {
			logger.info(getData("platformName") + " - onGoing Programs are not displayed #Fail");
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/Reading_Program/ongoing programFail.png");
			Assert.assertTrue(false);
		}
	}

	public void upComingProgramSection() throws IOException {
		waitFor(7000);
		for (int i = 0; i <= 25; i++) {
			while (openProgram.upComingProgram_lbl.size() == 0) {
				swipeDown();
				waitFor(4000);
			}
			if (openProgram.upComingProgram_lbl.size() != 0) {
				Assert.assertTrue(openProgram.upComingProgram_lbl.get(0).isDisplayed());
				swipeDown();
				logger.info(getData("platformName") + " - Upcoming Program is displayed #Pass");
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/Reading_Program/upcoming program.png");
				waitFor(3000);
				break;
			}
			if (i == 25) {
				Screenshots.takeScreenshot(driver,
						"./Screenshots/" + getData("platformName") + "/Reading_Program/upcoming programFail.png");
				logger.info(getData("platformName") + " - Upcoming Programs are not displayed #Fail");
				Assert.assertTrue(false);
			}
		}
	}

	public void myProgramsDetailsScreenValidation() throws IOException {
		waitFor(4000);
		try {
			ClickOnMobileElement(myProgram.myprogramslist.get(0));
		} catch (Exception e) {
			ClickOnMobileElement(myProgram.myprogramslist.get(0));
		}
		waitFor(7000);
		Assert.assertTrue(myProgram.createdDate.isDisplayed());
		logger.info(getData("platformName") + " - Program created Date is Displayed #Pass");
		Assert.assertTrue(myProgram.createdUser.isDisplayed());
		logger.info(getData("platformName") + " - Program creator name is Displayed #Pass");

		waitFor(8000);
		Assert.assertTrue(myProgram.readingProgram_lbl.isDisplayed());
		Assert.assertTrue(myProgram.readingProgramName.isDisplayed());
		logger.info(getData("platformName") + " - Program Name is Displayed #Pass");
		Assert.assertTrue(myProgram.desc.isDisplayed());
		logger.info(getData("platformName") + " - Program description is Displayed #Pass");
		Assert.assertTrue(myProgram.startDate.isDisplayed());
		logger.info(getData("platformName") + " - Program Start Date is Displayed #Pass");
		Assert.assertTrue(myProgram.endDate.isDisplayed());
		logger.info(getData("platformName") + " - Program End Date is Displayed #Pass");
		Assert.assertTrue(myProgram.status_lbl.isDisplayed());
		Assert.assertTrue(myProgram.status_text.isDisplayed());
		logger.info(getData("platformName") + " - Program Status is Displayed #Pass");
		Assert.assertTrue(myProgram.visibility_text.isDisplayed());
		logger.info(getData("platformName") + " - Program Visibility is Displayed #Pass");
		waitFor(3000);
		Assert.assertTrue(myProgram.type_text.isDisplayed());
		logger.info(getData("platformName") + " - Program Type is Displayed #Pass");
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(myProgram.readingList_Lbl.isDisplayed());
		}

		Assert.assertTrue(myProgram.titleList.get(0).isDisplayed());
		logger.info(getData("platformName") + " - Program titles are Displayed #Pass");
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/Reading_Program/ProgramDetail_page.png");
		if (myProgram.titleList.size() > 2) {
			horizontalSwipe(myProgram.titleList);
		} else {
			for (int i = 0; i <= myProgram.titleList.size() - 1; i++) {
				Assert.assertTrue(myProgram.titleList.get(i).isDisplayed());
			}
		}
		swipeDown();
		swipeDown();
		swipeDown();
		waitFor(5000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(myProgram.participants_lbl.isDisplayed());
		}
		if (detailpage_participantsList.size() != 0) {
			logger.info("Participants list displayed #Pass");
			for (int i = 0; i <= detailpage_participantsList.size() - 1; i++) {
				if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {

					Assert.assertTrue(detailpage_participantsList.get(i).isDisplayed());
					logger.info(getData("platformName") + " - Program Participant :"
							+ detailpage_participantsList.get(i).getText());
				}
			}

			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/Reading_Program/Participant_List.png");
			try {
				swipeDown();
				if (detailpage_participantsList.size() >= 10) {
					swipeDown();
					swipeDown();
					waitFor(5000);
					for (int i = 0; i <= detailpage_participantsList.size() - 1; i++) {
						logger.info(getData("platformName") + " - Program Participant :"
								+ detailpage_participantsList.get(i).getText());
					}
				} else {
					logger.info(getData("platformName") + " - Participant size is less than 10 #Pass");
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName")
							+ "/Reading_Program/Participant_List_LoadMore.png");
				}
			} catch (Exception e) {
			}
		} else {
			logger.info(getData("platformName") + " - No Participants available to display");
			Screenshots.takeScreenshot(driver,
					"./Screenshots/" + getData("platformName") + "/Reading_Program/Participant_List.png");
			Assert.assertTrue(false);
		}
		logger.info(getData("platformName") + " - MyProgram Details Screen Validation #pass");
		ClickOnMobileElement(myProgram.backBtn);
		Screenshots.takeScreenshot(driver,
				"./Screenshots/" + getData("platformName") + "/Reading_Program/Landing_page.png");
		waitFor(5000);
	}

	public void navigateToMyProgram() throws IOException {
		waitFor(3000);
		ClickOnMobileElement(myProgram.myProgram_tab);
		waitFor(8000);
		logger.info(getData("platformName") + " -Navigate to My program page #pass");

	}
	
	public void adminMyPrgcardValidation() throws IOException {
		waitFor(3000);
		Assert.assertTrue(myPrg_PrgiconAdminUser.get(0).isDisplayed());		
		logger.info(getData("platformName") + " Program icon is displayed in program card #pass");
		Assert.assertTrue(myPrg_PrgNameAdminUser.get(0).isDisplayed());
		logger.info(getData("platformName") + " Program Name is displayed in program card #pass");
		Assert.assertTrue(myPrg_PrgdescAdminUser.get(0).isDisplayed());
		logger.info(getData("platformName") + " Program Desc is displayed in program card #pass");
		Assert.assertTrue(myPrg_PrgendDtAdminUser.get(0).isDisplayed());
		logger.info(getData("platformName") + " Program enddate is displayed in program card #pass");
	}
	
/************************************************Locators**************************************************/
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/participant_creator_name_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[3]/XCUIElementTypeOther")
	public static List<MobileElement> detailpage_participantsList;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/program_image")
	public static List<MobileElement> myPrg_PrgiconAdminUser;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/program_readby_text")
	public static List<MobileElement> myPrg_PrgNameAdminUser;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/program_readby_text")
	public static List<MobileElement> myPrg_PrgendDtAdminUser;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/description_books")
	public static List<MobileElement> myPrg_PrgdescAdminUser;
	

}
