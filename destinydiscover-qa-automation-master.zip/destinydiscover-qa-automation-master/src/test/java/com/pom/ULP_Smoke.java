package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class ULP_Smoke extends CapabilitiesAndWebDriverUtils{
	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();
	
	public ULP_Smoke() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	public static void inSightCarousel() throws IOException {
		waitFor(5000);
		Assert.assertTrue(inSights_lbl.isDisplayed());
		if (inSights_Image.size()>1) {
			horizontalSwipeAndriod(inSights_Image);
			logger.info(getData("platformName") + " -  Insights is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Insights.png");
		}	
	}
	
	public static void goalSetting() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
		ClickOnMobileElement(inSights_Image.get(0));
		Assert.assertTrue(inSights_SetGoalsPageHeader.isDisplayed());
		logger.info(getData("platformName") + " -  Set Goal page Header is displayed #Pass");
		Assert.assertTrue(inSights_GoalsDesc.isDisplayed());
		logger.info(getData("platformName") + " -  Set Goal page Desccription is displayed #Pass");
		Assert.assertTrue(inSights_TargetSettingField.isDisplayed());
		Assert.assertTrue(inSights_GoalsmetricsText.isDisplayed());
		Assert.assertTrue(inSights_SetGoalBtn.isDisplayed());
		logger.info(getData("platformName") + " -  Set Goal button is displayed #Pass");
		try {
			ClickOnMobileElement(inSights_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " -  Goal Removed");
			waitFor(10000);
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(inSights_SetGoalBtn);	
		} catch (Exception e) {
			ClickOnMobileElement(inSights_SetGoalBtn);
		}
		Assert.assertTrue(inSights_SetGoalsPageHeader.isDisplayed());
		logger.info(getData("platformName") + " - User not abled to set Goal without entering target goal input #Pass");
		waitFor(5000);
		SendKeysOnMobileElement(inSights_TargetSettingField, testData.get(0).get("Goal_Target"));
		waitFor(5000);
		Assert.assertTrue(inSights_SetGoalBtn.isEnabled());
		logger.info(getData("platformName") + " -  Set Goal button is enabled after entering target goal input #Pass");
		waitFor(5000);
		try {
			ClickOnMobileElement(inSights_SetGoalBtn);
			logger.info(getData("platformName") + " -  Set Goal button clicked #Pass");
			
		} catch (Exception e) {
			ClickOnMobileElement(inSights_SetGoalBtn);
			logger.info(getData("platformName") + " -  Set Goal button clicked #Pass");
		}
		waitFor(10000);
		ClickOnMobileElement(inSights_Image.get(1));
		logger.info(getData("platformName") + " -  Insight clicked ");
		if (inSights_RemoveGoalBtn.size()!=0) {
			logger.info(getData("platformName") + " -  Remove Goal button is displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RemoveGoal.png");
			ClickOnMobileElement(inSights_RemoveGoalBtn.get(0));
		}
	  }
	if (getData("platformName").equalsIgnoreCase("ios")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			waitFor(8000);
			Actions s=new Actions(driver);
			s.click(inSights_Image.get(0)).build().perform();
			ClickOnMobileElement(inSights_Image.get(0));
			System.out.println("Insights Image Clicked");

			waitFor(3000);
			String goalsheader = inSights_SetGoalsPageHeader.getText();
			System.out.println("Goals:" + goalsheader);
			Assert.assertTrue(inSights_SetGoalsPageHeader.isDisplayed());

			logger.info(getData("platformName") + " -  Set Goal page Header is displayed #Pass");
			Assert.assertTrue(inSights_GoalsDesc.isDisplayed());
			logger.info(getData("platformName") + " -  Set Goal page Desccription is displayed #Pass");
			Assert.assertTrue(inSights_GoalsmetricsText.isDisplayed());
			Assert.assertTrue(inSights_SetGoalBtn.isDisplayed());
			logger.info(getData("platformName") + " -  Set Goal button is displayed #Pass");
			try {
				if (inSights_RemoveGoalBtn.get(0).isDisplayed())
				ClickOnMobileElement(inSights_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				Actions ss=new Actions(driver);
				ss.click(inSights_Image.get(1)).build().perform();
				Assert.assertEquals(inSights_SetGoalBtn.isEnabled(), false);
				ClickOnMobileElement(inSights_SetGoalBtn);
				logger.info(getData("platformName")
						+ " -  Set Goal button is not enabled without entering target goal input #Pass");
				ClickOnMobileElement(inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(inSights_SetGoalBtn);
				logger.info(getData("platformName")
						+ " -  Set Goal button is enabled after entering target goal input #Pass");

			} catch (Exception e) {
				Assert.assertEquals(inSights_SetGoalBtn.isEnabled(), false);
				ClickOnMobileElement(inSights_SetGoalBtn);
				logger.info(getData("platformName")
						+ " -  Set Goal button is not enabled without entering target goal input #Pass");

				ClickOnMobileElement(inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(inSights_SetGoalBtn);
				logger.info(getData("platformName")
						+ " -  Set Goal button is enabled after entering target goal input #Pass");
			}
		}	
	}
	
	public static void badgesCarousel() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
		waitFor(5000);
		Assert.assertTrue(badges_lbl.isDisplayed());
		logger.info(getData("platformName") + " -  Badges lable is Displayed #Pass");
		if (badges_Image.size()>2) {
			horizontalSwipeAndriod(badges_Image);
			logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
		}
		else {
			Assert.assertTrue(badges_Image.get(0).isDisplayed());
			logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
		}
		try {
			ClickOnMobileElement(badges_SeeAllBtn);
			waitFor(5000);
			logger.info(getData("platformName") + " -  Badges carousel Seeall page is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/BadgesSeeAll.png");
			Assert.assertEquals(badges_PageHeader.getText(),testData.get(0).get("Badges_Header_lbl"));
			logger.info(getData("platformName") + " - Badges Assertion done");
			try {
				ClickOnMobileElement(homeBtn);
			} catch (Exception e) {
				waitFor(3000);
				ClickOnMobileElement(homeBtn);
			}
			logger.info(getData("platformName") + " - Home Button clicked");
			waitFor(5000);
		}catch (Exception e) {
			logger.info(getData("platformName") + " -  Badges carousel SeeAll button is not Displayed");
		}
		swipeDown();
		waitFor(5000);
	}
		 if (getData("platformName").equalsIgnoreCase("ios")
				 || getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			 
			   swipeDown();
				waitFor(4000);
				String badges = badges_lbl.getText();
				logger.info(getData("platformName") + " -  Badges lable is Displayed " + badges + "##pass");


				System.out.println(badges_Image.size());
				if (badges_Image.size() > 2) {
					horizontalSwipeAndriod(badges_Image);
					logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
				} else {
					Assert.assertTrue(badges_Image.get(0).isDisplayed());
					logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
				}
				swipeDown();
				
		 }
	}
	
	public static void challengeandprogramCarousel() throws IOException {
		
		Assert.assertTrue(chPrg_lbl.isDisplayed());
		if (chPrgList.size()>1) {
			horizontalSwipeAndriod(chPrgList);
			logger.info(getData("platformName") + " -  RC/RP carousel is Displayed #Pass");
		}
		else {
			Assert.assertTrue(chPrgList.get(0).isDisplayed());
			logger.info(getData("platformName") + " -  RC/RP carousel is Displayed #Pass");
		}
		ClickOnMobileElement(chPrgSeeAll_Btn);
		Assert.assertTrue(lbl_BooKClub_Header.isDisplayed());
		Assert.assertTrue(challenges.isDisplayed());
		Assert.assertTrue(myPrograms.isDisplayed());
		Assert.assertTrue(openPrograms.isDisplayed());
		logger.info(getData("platformName") + " -  Book club landing page header,challenges,myProgram,Openrogram Tab are displayed #Pass");
		logger.info(getData("platformName") + " -  User navigates to listing page after taping SeeAll from home page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/ListingPage.png");
		ClickOnMobileElement(homeBtn);
		waitFor(10000);
		swipeDown();
	}
	
	public static void challengeNavigation() throws IOException {
		ClickOnMobileElement(chPrgList.get(0));
		waitFor(5000);
		Assert.assertTrue(CreateAChallengeCreatorRCDetailsScreen.pageBackButton.isDisplayed());
		logger.info(getData("platformName") + " -  User navigates to correcponding RC/RP Detail page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/DetailPage.png");
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		waitFor(10000);
		swipeDown();
	}
	
	public static  void ourSuggestionCarousel() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(5000);
		Assert.assertTrue(otherSuggestion_lbl.isDisplayed());
		Assert.assertTrue(basedOnIntrest_lbl.isDisplayed());
		if (ourSuggestion_Title.size()>2) {
			horizontalSwipeAndriod(ourSuggestion_Title);
		}
		ClickOnMobileElement(basedOnIntrestSeeAll_Btn);
		waitFor(5000);
		Assert.assertEquals(seeAll_listingPageHeader.isDisplayed(),true);
		logger.info(getData("platformName") + " -  User navigates to suggestion carousel listing page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Based_on_intrest.png");
		ClickOnMobileElement(seeAll_listingPageBackButton);
		waitFor(5000);
		swipeDown();
		swipeDown();
		Assert.assertTrue(basedOnIsbn_lbl.isDisplayed());
		ClickOnMobileElement(basedOnIsbnSeeAll_Btn);
		waitFor(5000);
		Assert.assertEquals(seeAll_listingPageHeader.isDisplayed(),true);
		logger.info(getData("platformName") + " -  User navigates to second suggestion carousel listing page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Based_on_isbn.png");
		ClickOnMobileElement(seeAll_listingPageBackButton);
		waitFor(5000);
		swipeDown();
	}
	
	public static void matTypeAndMoreIconValidation() throws IOException {
		try {
			if (ourSuggestion_MatStaus.size()>4 && ourSuggestion_MoreIcon.size()>=4) {
				logger.info(getData("platformName") + " -  Material type and more icon is displayed for all the titles #Pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MatType.png");
			}
		}
		catch (Exception e) {
			logger.info(getData("platformName") + " -  Material type and more icon is displayed for all the titles #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MatType.png");
		}
	}
	
/********************************************* User landing Page - 1.6.23 **********************q********************************/
	
	@iOSXCUITFindBy(id = "HOME")
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_home")
	public static MobileElement homeBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Challenges\"]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Challenges\"]")
	public static MobileElement challenges;

	@AndroidFindBy(xpath = "//*[@text='My Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='My Programs']")
	public static MobileElement myPrograms;

	@AndroidFindBy(xpath = "//*[@text='Open Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Open Programs']")
	public static MobileElement openPrograms;
	
	@AndroidFindBy(xpath = "//*[@text='Book Club']")
	@iOSXCUITFindBy(xpath = "//*[@name=\"Book Club\"]")
	public static MobileElement lbl_BooKClub_Header;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/insights_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Insights\"]")
	public static MobileElement inSights_lbl; 
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/insights_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeStaticText")
	public static List<MobileElement> inSights_Image;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/goals_heading_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[1]")
	public static MobileElement inSights_SetGoalsPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/goals_desc_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
	public static MobileElement inSights_GoalsDesc;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/goals_info_text")
	@iOSXCUITFindBy(xpath = "//*[@name='* Metrics are based on digital content only']")
	public static MobileElement inSights_GoalsmetricsText;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/button_set_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Set Goal']")
	public static MobileElement inSights_SetGoalBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/target_goal_edit_text")
	@iOSXCUITFindBy(xpath = "/XCUIElementTypeOther/XCUIElementTypeTextField")
	public static MobileElement inSights_TargetSettingField;

	@iOSXCUITFindBy(xpath = "//*[@value='Enter your target goal']")
	public static MobileElement inSights_enteryourgoaltextboxbeforeenter;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/daily_count_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeStaticText[3]")
	public static MobileElement inSights_DailyCount;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/button_remove_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Remove Goal']")
	public static List<MobileElement> inSights_RemoveGoalBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/badges_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Badges\"]")
	public static MobileElement badges_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/badge_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeStaticText")
	public static List<MobileElement> badges_Image;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/badges_see_all_text")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"See All\"])[1]")
	public static MobileElement badges_SeeAllBtn;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Accounts\"]")
	public static MobileElement badges_PageHeader;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/challenge_programs_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"READING CHALLENGES & PROGRAMS\"]")
	public static MobileElement chPrg_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/challenges_programs_see_all_text")
	@iOSXCUITFindBy(xpath = "//*[@name='See All']")
	public static MobileElement chPrgSeeAll_Btn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/book_cover_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[3]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> chPrgList;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/interest_recommendation_text")
	//@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Based on your preference\"]")
	public static MobileElement otherSuggestion_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/interest_recommendation_header_text")
	@iOSXCUITFindBy(xpath = "//*[@name='Based on your preference']")
	public static MobileElement basedOnIntrest_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/interest_recommendation_see_all_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"See All\"][3]")
	public static MobileElement basedOnIntrestSeeAll_Btn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"You are on the Destiny Discover landing screen. Scroll to view the entire page\"]")
	public static MobileElement seeAll_listingPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_back")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Back\"]")
	public static MobileElement seeAll_listingPageBackButton;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/material_cover_image_view")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[3]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> ourSuggestion_Title;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/material_status_image_view")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeTable/XCUIElementTypeCell[4]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
	public static List<MobileElement> ourSuggestion_MatStaus;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/material_status_view")
	public static List<MobileElement> ourSuggestion_MatStausText;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/more_option_image_view")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeTable/XCUIElementTypeCell[4]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton")
	public static List<MobileElement> ourSuggestion_MoreIcon;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/isbn_recommendation_header_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[5]/XCUIElementTypeStaticText")
	public static MobileElement basedOnIsbn_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/isbn_recommendation_see_all_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"See All\"][4]")
	public static MobileElement basedOnIsbnSeeAll_Btn;

}
