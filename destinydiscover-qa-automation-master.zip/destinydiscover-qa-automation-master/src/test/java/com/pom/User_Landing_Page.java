package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class User_Landing_Page extends CapabilitiesAndWebDriverUtils{
	
	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();
	
	public User_Landing_Page() {
		
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	public static void headerAssertion() throws IOException, InvalidFormatException {	
		waitFor(5000);
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		Assert.assertEquals(destinyLogo.getText(),testData.get(0).get("Logo_lbl"));
		logger.info(getData("platformName") + " -  Destiny Discover page header is displayed #Pass");
		Assert.assertTrue(globalSearchIcon.isDisplayed());
		logger.info(getData("platformName") + " -  Global search Icon is displayed #Pass");
		Assert.assertTrue(Message_Center.messageCenterIcon.isDisplayed());
		logger.info(getData("platformName") + " -  Notification Icon is displayed #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/PageHeader.png");
	}
	
	public static void msgCenterNavigation() throws IOException, InvalidFormatException {
		waitFor(3000);
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "MessageCenter");
		ClickOnMobileElement(Message_Center.messageCenterIcon);
		waitFor(15000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertEquals(Message_Center.pageHeader_lbl.getText(), testData.get(0).get("lbl_Header"));

		}

		if (getData("platformName").equalsIgnoreCase("ios")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			Assert.assertEquals(Message_Center.pageHeader_lbl.getText(), testData.get(1).get("lbl_Header"));

		}

		logger.info(getData("platformName")
				+ " - user taped on message centre icon, navigating to messsage center page  #pass");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/landing page.png");
		try {
			if (Message_Center.messageHeader.size()!=0) {
				logger.info(getData("platformName")+ " - user able to see list of notification recieved  #pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Notifications.png");
			}
		} catch (Exception e) {
			logger.info(getData("platformName")+ " - No messages displayed in the notitfication listing page");
		}
		ClickOnMobileElement(Message_Center.pageBackIcon);
		Assert.assertTrue(Message_Center.messageCenterIcon.isDisplayed());
		logger.info(getData("platformName")+ " - Navigating back to home page after tap on back button in messsage center page  #pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Aftertaping back btn.png");
		waitFor(10000);
	}
	
	public static void rcrpNameValidation() throws IOException {
		try {
			Assert.assertTrue(rcRP_progress.get(0).isDisplayed());
			Assert.assertTrue(rcRP_Name.get(0).isDisplayed());
			Assert.assertTrue(rcRP_image.get(0).isDisplayed());
			logger.info(getData("platformName") + " - User can able to see RC/RpName progress and cover image  #pass");
		}
		catch(Exception e) {	
			logger.info(getData("platformName") + " - User can able to see RC/RpName progress and cover image #Fail");
		}		
	}

	public static void rcrpCarouselValidation() throws IOException {
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		try {
			Assert.assertTrue(ULP_Smoke.chPrg_lbl.isDisplayed());
			for (int i = 0; i<=3; i++) {
				if (ULP_Smoke.chPrgList.size()>1) {
					horizontalSwipeAndriod(ULP_Smoke.chPrgList);
					logger.info(getData("platformName") + " -  RC/RP carousel is Displayed #Pass");
					Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RCRP_Carousel.png");
				}
				else {
					Assert.assertTrue(ULP_Smoke.chPrgList.get(0).isDisplayed());
					logger.info(getData("platformName") + " -  RC/RP carousel is Displayed #Pass");
					Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RCRP_Carousel.png");
				}
			}
		} catch (Exception e) {
			logger.info(getData("platformName") + " -  RC/RP carousel not displayed ");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RCRP_Carousel.png");
		}}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(3000);
			String chall = ULP_Smoke.chPrg_lbl.getText();
			System.out.println("Label:"+chall);
			System.out.println("RPSize "+ULP_Smoke.chPrgList.size());
			if (ULP_Smoke.chPrgList.size()>1) {
				horizontalSwipeAndriod(ULP_Smoke.chPrgList);
				logger.info(getData("platformName") + " -  RC/RP carousel is Displayed #Pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RCRP_Carousel.png");
			}
			else {
				logger.info(getData("platformName") + " -  RC/RP carousel not Displayed #Fail");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RCRP_Carousel.png");
			}
			
	}}
	
	public static void rcrpSeeAllNavigation() throws IOException {
		ClickOnMobileElement(ULP_Smoke.chPrgSeeAll_Btn);
		waitFor(5000);
		Assert.assertTrue(lbl_BooKClub_Header.isDisplayed());
		Assert.assertTrue(challenges.isDisplayed());
		Assert.assertTrue(myPrograms.isDisplayed());
		Assert.assertTrue(openPrograms.isDisplayed());
		logger.info(getData("platformName") + " -  Book club landing page header,challenges,myProgram,Openrogram Tab are displayed #Pass");
		logger.info(getData("platformName") + " -  User navigates to listing page after taping SeeAll from home page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/ListingPage.png");
		ClickOnMobileElement(homeBtn);
		waitFor(10000);
		swipeDown();
	}
	
	public static void recommendationOneCarousel() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(5000);
		Assert.assertTrue(ULP_Smoke.otherSuggestion_lbl.isDisplayed());
		Assert.assertTrue(ULP_Smoke.basedOnIntrest_lbl.isDisplayed());
		ClickOnMobileElement(ULP_Smoke.basedOnIntrestSeeAll_Btn);
		waitFor(5000);
//		Assert.assertEquals(ULP_Smoke.seeAll_listingPageHeader.getText(), testData.get(0).get("SeeALL_ListPage_Header1"));
		Assert.assertTrue(ULP_Smoke.seeAll_listingPageHeader.isDisplayed());
		logger.info(getData("platformName") + " -  User navigates to Your Classmates enjoyed carousel listing page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Based_on_classmetread.png");
		ClickOnMobileElement(ULP_Smoke.seeAll_listingPageBackButton);
		waitFor(5000);
	}
	
	public static void recommendationTwoCarousel() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		swipeDown();
		swipeDown();
		Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
		ClickOnMobileElement(ULP_Smoke.basedOnIsbnSeeAll_Btn);
		waitFor(5000);
//		Assert.assertEquals(ULP_Smoke.seeAll_listingPageHeader.getText(), testData.get(0).get("SeeALL_ListPage_Header2"));
		Assert.assertTrue(ULP_Smoke.seeAll_listingPageHeader.isDisplayed());
		logger.info(getData("platformName") + " -  User navigates to Because you enjoyed carousel listing page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Based_on_isbn.png");
		ClickOnMobileElement(ULP_Smoke.seeAll_listingPageBackButton);
		waitFor(5000);
		swipeDown();
	}
	
	public static void moreAndMAtTypeIconValidation() throws IOException {
			for (int i = 0; i<3; i++) {
				try {
					waitFor(5000);
					horizontalSwipeAndriod(ULP_Smoke.ourSuggestion_Title);
					if (ULP_Smoke.ourSuggestion_MatStaus.size()>4 && ULP_Smoke.ourSuggestion_MoreIcon.size()>=4) {
						logger.info(getData("platformName") + " -  Material type and more icon is displayed for all the titles #Pass");
						Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MatType.png");
					}
				}
				catch (Exception e) {
					logger.info(getData("platformName") + " -  Material type and more icon is displayed for all the titles #Fail");
					Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MatType.png");
				}
			}
	}
	
	public static void bottomMenuNavigation() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(5000);
		Assert.assertTrue(destinyLogo.isDisplayed());
		logger.info(getData("platformName") + " - User is on Home page by defaut #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/HomePage.png");
		ClickOnMobileElement(footer_MyStuffMenu);
		waitFor(3000);
		Assert.assertEquals(myStuff_PageHeader.getText(),testData.get(0).get("myStuff_PageHeader"));
		Assert.assertTrue(myStuff_Checkouts.isDisplayed());
		Assert.assertTrue(myStuff_Recent.isDisplayed());
		Assert.assertTrue(myStuff_Holds.isDisplayed());
		Assert.assertTrue(myStuff_Assigned.isDisplayed());
		logger.info(getData("platformName") + " - User navigtes to My Stuff Landing page after tapping on MyStuff Bottom menu #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MyStuffPage.png");
		ClickOnMobileElement(bookClubOption);
		Assert.assertTrue(lbl_BooKClub_Header.isDisplayed());
		Assert.assertTrue(challenges.isDisplayed());
		Assert.assertTrue(myPrograms.isDisplayed());
		Assert.assertTrue(openPrograms.isDisplayed());
		logger.info(getData("platformName") + " - User navigtes to BookClub Landing page after tapping on BookClub Bottom menu #Pass ");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/BookClubPage.png");
		ClickOnMobileElement(footer_DiscoverMenu);
		waitFor(5000);
		Assert.assertEquals(discover_PageHeader.getText(),testData.get(0).get("discover_pageHeader"));
		Assert.assertTrue(discover_AudioBooks_lbl.isDisplayed());
		Assert.assertTrue(discover_Ebooks_lbl.isDisplayed());
		logger.info(getData("platformName") + " - User navigtes to Discover Landing page after tapping on Discover Bottom menu #Pass ");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/DiscoverPage.png");
		ClickOnMobileElement(homeBtn);
		waitFor(10000);
	}
	
	public static void recentReadBook() {
		
		for (int i = 0; i < 2; i++) {
			try {
				Assert.assertTrue(recentReadTitle_Image.isDisplayed());
				Assert.assertTrue(recentReadTitle_Title.isDisplayed());
				Assert.assertTrue(recentReadTitle_Author.isDisplayed());
				Assert.assertTrue(recentReadTitle_RightArrow.isDisplayed());
				logger.info(getData("platformName") + " - User able to see recently read book in minimized Fashion #Pass ");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Recentread_Book.png");	
			} catch (Exception e) {
				swipeUp();
			}
		}
	}
	
	public static void recentBookDisappear() throws IOException {
		swipeDown();
		swipeDown();
		try {
			Assert.assertTrue(recentReadTitle_Image.isDisplayed());
			Assert.assertTrue(recentReadTitle_Title.isDisplayed());
			Assert.assertTrue(recentReadTitle_Author.isDisplayed());
			Assert.assertTrue(recentReadTitle_RightArrow.isDisplayed());
			logger.info(getData("platformName") + " - User should not see recently read book in minimized Fashion after scroll down #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RecentreadDisappear.png");	

		} catch (Exception e) {
			logger.info(getData("platformName") + " - User should not see recently read book in minimized Fashion after scroll down #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/RecentreadDisappear.png");	

		}
		swipeUp();
		swipeUp();
		try {
			waitFor(2000);
			Assert.assertTrue(recentReadTitle_Image.isDisplayed());
			Assert.assertTrue(recentReadTitle_Title.isDisplayed());
			Assert.assertTrue(recentReadTitle_Author.isDisplayed());
			Assert.assertTrue(recentReadTitle_RightArrow.isDisplayed());
			logger.info(getData("platformName") + " - User should see recently read book in minimized Fashion when user scroll up #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Recentreadappear.png");	

		} catch (Exception a) {
			logger.info(getData("platformName") + " - User should see recently read book in minimized Fashion when user scroll up #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Recentreadappear.png");	
		}
	}

	public static void openRecentReadBook() throws IOException, InterruptedException {
		try {
			ClickOnMobileElement(recentReadTitle_RightArrow);
			System.out.println("Right Arrrow Clicked");
		} catch (Exception e) {
			Actions s=new Actions(driver);
			s.click(recentReadTitle_RightArrow).build().perform();		
			System.out.println("Touch Action Clicked");
		}
		logger.info(getData("platformName") + " - User Taped on recent read book #Pass");
		waitFor(8000);
		Assert.assertTrue(reader_CloseButton.isDisplayed());
		logger.info(getData("platformName") + " - Taping on recent read book should launch reader #Pass");
		ClickOnMobileElement(reader_CloseButton);
		waitFor(5000);
	}
	
	public static void discoverPageNavigation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		ClickOnMobileElement(footer_DiscoverMenu);
		waitFor(5000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		Assert.assertEquals(discover_PageHeader.getText(),testData.get(0).get("discover_pageHeader"));
		}
		if (getData("platformName").equalsIgnoreCase("ios")
				|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
			IsDisplayedMobileElement(discover_PageHeader);
		}
		Assert.assertTrue(discover_AudioBooks_lbl.isDisplayed());
		Assert.assertTrue(discover_Ebooks_lbl.isDisplayed());
		logger.info(getData("platformName") + " - User navigtes to Discover Landing page after tapping on Discover Bottom menu #Pass ");
		waitFor(5000);
	}
	
	public static void carouselValidation() throws IOException {
		waitFor(10000);
		for (int i = 0; i < 2; i++) {
			horizontalSwipeAndriod(discover_titleImage);
		}
		logger.info(getData("platformName") + " - User can scroll right to see the other title in carousel #Pass ");
	}
	
	public static void listingPageValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		ClickOnMobileElement(discover_Ebooks_SeeAll);
		waitFor(5000);
		Assert.assertEquals(discover_Ebooks_ListPageHeader.getText(), testData.get(0).get("ebooks_pageHeader"));
		logger.info(getData("platformName") + " - User Navigates to eBook Listing page after taping on seeAll button #Pass ");
       try {
    	   waitFor(8000);
    	   for (int i = 0; i<= discover_titleImage.size()-1; i++) {
    		   	Assert.assertTrue(discover_titleImage.get(i).isDisplayed());
    	   }
    	   swipeDown();
    	   logger.info(getData("platformName") + " - eBook Title images are displayed  #Pass ");
		   Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/eBookListingPage.png");	
    	   ClickOnMobileElement(discover_ListPageBackBtn);
    	   logger.info(getData("platformName") + " - Navigating back to Discover landing page #Pass ");
    	   waitFor(10000);
       } catch (Exception e) {
    	   logger.info(getData("platformName") + " - Title image displayed in Listing page #Fail ");
    	   ClickOnMobileElement(discover_ListPageBackBtn);
    	   logger.info(getData("platformName") + " - Navigating back to Discover landing page #Pass ");
    	   waitFor(5000);
       }
   		waitFor(4000);
		try {
			ClickOnMobileElement(discover_AudioBooks_SeeAll);
		}
		catch(Exception e) {
			Actions a=new Actions(driver);
			a.click(discover_AudioBooks_SeeAll).build().perform();
			System.out.println("Audio Books See all Clicked");
		}
	   waitFor(5000);
	   Assert.assertEquals(discover_Audiobooks_ListPageHeader.getText(), testData.get(0).get("audioBooks_pageHeader"));
	   logger.info(getData("platformName") + " - User Navigates to AudioBook Listing page after taping on seeAll button #Pass ");
	   try {
    	   waitFor(8000);
    	   for (int i = 0; i<= discover_titleImage.size()-1; i++) {
    		   	Assert.assertTrue(discover_titleImage.get(i).isDisplayed());
    	   }
    	   swipeDown();
    	   logger.info(getData("platformName") + " - AudioBook Title images are displayed  #Pass ");
		   Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/AudioBookListingPage.png");	
    	   ClickOnMobileElement(discover_ListPageBackBtn);
    	   logger.info(getData("platformName") + " - Navigating back to Discover landing page #Pass ");
    	   waitFor(10000);
       } catch (Exception e) {
    	   logger.info(getData("platformName") + " - Title image displayed in Listing page #Fail "); 	   
    	   ClickOnMobileElement(discover_ListPageBackBtn);
    	   logger.info(getData("platformName") + " - Navigating back to Discover landing page #Pass ");
    	   waitFor(5000);
       }     
	}
	
	public static void moreIconValidation() throws IOException {
		Assert.assertTrue(footerMoreIcon.isDisplayed());
		logger.info(getData("platformName") + " - Footer more icon is diaplyed #Pass ");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/ULP/FooterMoreIcon.png");
		try {
			ClickOnMobileElement(footerMoreIcon);
		}
		catch(Exception e) {
			Actions s=new Actions(driver);
			s.click(footerMoreIcon).build().perform();
			System.out.println("Action Footer Menu Clicked");
		}
		waitFor(3000);
	}
	
	public static void moreOptionValidation() throws IOException {	
		Assert.assertTrue(downloadsButton.isDisplayed());
		logger.info(getData("platformName") + " - Downloads button is displayed in More options #Pass ");
		Assert.assertTrue(accountsButton.isDisplayed());
		logger.info(getData("platformName") + " - Accounts button is displayed in More options #Pass ");
		Assert.assertTrue(aboutButton.isDisplayed());
		logger.info(getData("platformName") + " - About button is displayed in More options #Pass ");
		Assert.assertTrue(logOutButton.isDisplayed());
		logger.info(getData("platformName") + " - Log out button is displayed in More options #Pass ");
        Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MoreMenuOptions.png");		
	}
	
	public static void downLoadsValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		ClickOnMobileElement(downloadsButton);
		waitFor(10000);
		Assert.assertEquals(downloads_ListPageHeader.getText(), testData.get(0).get("downloads_pageHeader"));
		for (int i = 0; i<=downloads_TitleCoverImage.size()-1; i++) {
			Assert.assertTrue(downloads_TitleCoverImage.get(i).isDisplayed());		
			Assert.assertTrue(downloads_ExpiresText.get(i).isDisplayed());		
			Assert.assertTrue(downloads_ExpiresDate.get(i).isDisplayed());		
		}
		logger.info(getData("platformName") + " - Downloads page titlecover image,ExpiresDate Displyed #Pass ");
		try {
			Assert.assertTrue(downloads_DownloadNowbtn.get(0).isDisplayed());
			logger.info(getData("platformName") + " - Download Now button is Displayed #Pass ");
			swipeDown();
	        Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/DownloadsPage.png");		
			ClickOnMobileElement(homeBtn);
			waitFor(5000);
		} catch (Exception e) {
			ClickOnMobileElement(homeBtn);
			waitFor(5000);
		}	
	}
	
	
/********************************************* User landing Page - 1.6.24 ******************************************************/
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='BOOK CLUB']")
	@iOSXCUITFindBy(xpath = "//*[@name='Book Club tab']")
	public static MobileElement bookClubOption;
	
	@AndroidFindBy(xpath = "//*[@text='Book Club']")
	@iOSXCUITFindBy(xpath = "//*[@name=\"Book Club\"]")
	public static MobileElement lbl_BooKClub_Header;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Challenges\"]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Challenges\"]")
	public static MobileElement challenges;
	
	@AndroidFindBy(xpath = "//*[@text='My Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='My Programs']")
	public static MobileElement myPrograms;

	@AndroidFindBy(xpath = "//*[@text='Open Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Open Programs']")
	public static MobileElement openPrograms;
	
	@iOSXCUITFindBy(id = "HOME")
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_home")
	public static MobileElement homeBtn;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//*[@name='Destiny Discover']")
	public static MobileElement destinyLogo;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_global_search_icon")
	@iOSXCUITFindBy(xpath = "//*[@name='Search']")
	public static MobileElement globalSearchIcon;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/reading_list_progress_bar")
	@iOSXCUITFindBy(xpath = "//*[@name='Search']")
	public static List<MobileElement> rcRP_progress;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/tv_title_text")
	public static List<MobileElement> rcRP_Name;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/book_cover_image")
	public static List<MobileElement> rcRP_image;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/recent_read_book_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeImage[1]")
	public static MobileElement recentReadTitle_Image;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/recent_read_book_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]")
	public static MobileElement recentReadTitle_Title;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/recent_read_page_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeStaticText[2]")
	public static MobileElement recentReadTitle_Author;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/ic_arrow")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeImage[2]")
	public static MobileElement recentReadTitle_RightArrow;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/reader_close_button")
	@iOSXCUITFindBy(xpath = "//*[@name='Close']")
	public static MobileElement reader_CloseButton;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_my_stuff")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[@name=\"My Stuff tab\"]")
	public static MobileElement footer_MyStuffMenu;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"My Stuff\"]")
	public static MobileElement myStuff_PageHeader;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Checkouts']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"My Stuff\"]")
	public static MobileElement myStuff_Checkouts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Recent']")
	@iOSXCUITFindBy(accessibility = "Recent")
	public static MobileElement myStuff_Recent;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Holds']")
	@iOSXCUITFindBy(accessibility = "Holds")
	public static MobileElement myStuff_Holds;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Assigned']")
	@iOSXCUITFindBy(accessibility = "Assigned")
	public static MobileElement myStuff_Assigned;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_discover")
	@iOSXCUITFindBy(accessibility = "Discover tab")
	public static MobileElement footer_DiscoverMenu;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(accessibility = "You are on the Destiny Discover landing screen. Scroll to view the entire page")
	public static MobileElement discover_PageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_ebooks_header_view")
	@iOSXCUITFindBy(accessibility = "eBooks")
	public static MobileElement discover_Ebooks_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_see_all_ebooks_button")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"See All\"][1]")
	public static MobileElement discover_Ebooks_SeeAll;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"You are on the Destiny Discover landing screen. Scroll to view the entire page\"]")
	public static MobileElement discover_Ebooks_ListPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_audiobooks_header_view")
	@iOSXCUITFindBy(xpath = "//*[@name='Audiobooks']")
	public static MobileElement discover_AudioBooks_lbl;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/library_see_all_audiobooks_button")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" Audiobooks See All\"]")
	public static MobileElement discover_AudioBooks_SeeAll;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='You are on the Destiny Discover landing screen. Scroll to view the entire page']")
	public static MobileElement discover_Audiobooks_ListPageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/material_cover_image_view")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> discover_titleImage;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_back")
	@iOSXCUITFindBy(xpath = "//*[@name=\"Back\"]")
	public static MobileElement discover_ListPageBackBtn;
	
	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"MORE\"]/android.view.ViewGroup/android.widget.TextView")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"MORE\"]")
	public static MobileElement footerMoreIcon;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/logout_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Log out\"]")
	public static MobileElement logOutButton;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/download_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Downloads\"]")
	public static MobileElement downloadsButton;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/about_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"About\"]")
	public static MobileElement aboutButton;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/account_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Accounts\"]")
	public static MobileElement accountsButton;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Downloads\"]")
	public static MobileElement downloads_ListPageHeader;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/item_material_book_list_cover_image_view")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> downloads_TitleCoverImage;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/downloaded_book_download_button")
	public static List<MobileElement> downloads_DownloadNowbtn;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/item_material_book_list_book_title")
	public static List<MobileElement> downloads_TitleName;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/downloaded_book_expires_title_view")
	public static List<MobileElement> downloads_ExpiresText;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/downloaded_book_expires_view")
	public static List<MobileElement> downloads_ExpiresDate;
		
}
	