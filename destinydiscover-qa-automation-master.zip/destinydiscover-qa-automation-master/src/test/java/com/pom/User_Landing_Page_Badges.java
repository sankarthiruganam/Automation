package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.PaintStyle.TextureAlignment;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class User_Landing_Page_Badges extends CapabilitiesAndWebDriverUtils {

	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();
	
	ULP_Smoke ulpPage = new ULP_Smoke();

	public User_Landing_Page_Badges() {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static void badgesCarousel() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		waitFor(5000);
		Assert.assertTrue(badges_lbl.isDisplayed());
		logger.info(getData("platformName") + " -  Badges lable is Displayed #Pass");
		if (badges_Image.size()>2) {
			for (int i = 0; i < 3; i++) {
				horizontalSwipeAndriod(badges_Image);
			}
			logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
		}
		else {
			Assert.assertTrue(badges_Image.get(0).isDisplayed());
			logger.info(getData("platformName") + " -  Badges carousel is Displayed #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Badges.png");
		}
	}
	
	public static void badgesSeeAllBtn() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		try {
			Assert.assertTrue(badges_SeeAllBtn.isDisplayed());
			logger.info(getData("platformName") + " -  Badges carousel Seeall page is Displayed #Pass");
			ClickOnMobileElement(badges_SeeAllBtn);
			waitFor(5000);
			Assert.assertTrue(badges_PageHeader.isDisplayed());
			Assert.assertEquals(badges_PageHeader.getText(),testData.get(0).get("Badges_Header_lbl"));
			logger.info(getData("platformName") + " -  User navigates to listing Page #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/BadgesSeeAll.png");
					
		}catch (Exception e) {
			logger.info(getData("platformName") + " -  Badges carousel SeeAll button is not Displayed");
		}
		waitFor(5000);
	}
	
	public static void badgeDuplicationValidation() throws IOException {
		List<String> badgeNameList = new ArrayList<String>(); 
		Set<String> badgeNameSet = new HashSet<>(); 
		 for (int i = 0; i<=badges_NameInfo.size()-1; i++) {
			 if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			Assert.assertTrue(badges_Image.get(i).isDisplayed());
			Assert.assertTrue(badges_NameInfo.get(i).isDisplayed());
			 }
			
			if (getData("platformName").equalsIgnoreCase("iOS")
						|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
				 waitFor(4000);
				 //Assert.assertTrue(badges_imageAccountPage.get(i).isDisplayed());
				 System.out.println("Images :" +badges_imageAccountPage.size());
				 System.out.println("Images :" +badges_NameInfo.size());
				 System.out.println(badges_NameInfo.get(i).getText());
			 }
			
			
			String name = badges_NameInfo.get(i).getText();
			if (i>8) {
				swipeDown();
			}
			logger.info(getData("platformName") + " -  Displayed Badge : "+badges_NameInfo.get(i).getText());
			badgeNameList.add(name);
		}
		 
		badgeNameSet.addAll(badgeNameList);
		
		if (badgeNameList.size()==badgeNameSet.size()) {
			
			logger.info(getData("platformName") + " -  Badges are not repeated #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/BadgesRepeat.png");	
		
		} else {
			logger.info(getData("platformName") + " -  Badges are not repeated #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/BadgesRepeat.png");
			Assert.assertTrue(false);
		}
		try {
			ClickOnMobileElement(badges_close);
			waitFor(5000);
			ClickOnMobileElement(homeBtn);
		} catch (Exception e) {
			waitFor(3000);
			ClickOnMobileElement(homeBtn);
		}
		waitFor(5000);
		
	}

	
	/********************************************** User landing Page - 1.6.28 ******************************************************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[@name=\"Home tab\"]")
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_home")
	public static MobileElement homeBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Challenges\"]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Challenges\"]")
	public static MobileElement challenges;

	@AndroidFindBy(xpath = "//*[@text='My Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='My Programs']")
	public static MobileElement myPrograms;

	@AndroidFindBy(xpath = "//*[@text='Open Programs']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Open Programs']")
	public static MobileElement openPrograms;
	
	@AndroidFindBy(xpath = "//*[@text='Book Club']")
	@iOSXCUITFindBy(xpath = "//*[@name=\"Book Club\"]")
	public static MobileElement lbl_BooKClub_Header;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/insights_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Insights\"]")
	public static MobileElement inSights_lbl; 

	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/badges_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Badges\"]")
	public static MobileElement badges_lbl;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/badge_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther")
	public static List<MobileElement> badges_Image;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/badges_see_all_text")
	@iOSXCUITFindBy(xpath="(//XCUIElementTypeStaticText[@name=\"See all\"])[1]")
	public static MobileElement badges_SeeAllBtn;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Accounts\"]")
	public static MobileElement badges_PageHeader;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/daily_info_text")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeStaticText")
	public static List<MobileElement> badges_NameInfo;
	
	
	@iOSXCUITFindBy(xpath="XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeImage")
	public static List<MobileElement> badges_imageAccountPage;
		
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name=\"Close\"]")
	public static MobileElement badges_close;
	
}
