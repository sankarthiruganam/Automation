package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.PaintStyle.TextureAlignment;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class User_Landing_Page_Goals extends CapabilitiesAndWebDriverUtils {

	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();
	
	ULP_Smoke ulpPage = new ULP_Smoke();

	public User_Landing_Page_Goals() {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static void defaultGoalValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		waitFor(2000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		
		if (insight_GoalText.get(0).getText().contains("/")) {
			ClickOnMobileElement(inSights_Image.get(0));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Reading Goal Removed successfully #Pass");
			waitFor(5000);
			Assert.assertEquals(insight_Name.get(0).getText(),testData.get(0).get("insight_lbl"));
			if (insight_GoalText.get(0).getText().equals("0")) {
				logger.info(getData("platformName") + " - Reading insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Reading insight has some progress to display #Pass ");
			}
		}
		else {
			if (insight_GoalText.get(0).getText().equals("0")) {
				logger.info(getData("platformName") + " - Reading insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Reading insight insight has some progress to display #Pass ");
			}		
		}
		if (insight_GoalText.get(1).getText().contains("/")) {
				ClickOnMobileElement(inSights_Image.get(1));
				ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				logger.info(getData("platformName") + " - Streak Goal Removed successfully #Pass");
				waitFor(5000);
				Assert.assertEquals(insight_Name.get(1).getText(),testData.get(1).get("insight_lbl"));
				if (insight_GoalText.get(1).getText().equals("0")) {
					logger.info(getData("platformName") + " - Streak insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Streak insight has some progress to display #Pass ");
				}
		}
		else {
			if (insight_GoalText.get(1).getText().equals("0")) {
				logger.info(getData("platformName") + " - Streak insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Streak insight has some progress to display #Pass ");
			}		
		}
		horizontalSwipeAndriod(inSights_Image);
		if (insight_GoalText.get(1).getText().contains("/")) {
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Book per month Goal Removed successfully #Pass");
			waitFor(5000);
			horizontalSwipeAndriod(inSights_Image);
			Assert.assertEquals(insight_Name.get(1).getText(),testData.get(2).get("insight_lbl"));
			if (insight_GoalText.get(1).getText().equals("0")) {
				logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
			}
		}
		else {
			if (insight_GoalText.get(1).getText().equals("0")) {
				logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
			}
		}
		ClickOnMobileElement(insight_rightArrow);
		waitFor(3000);
		if (insight_GoalText.get(0).getText().contains("/")) {		
			ClickOnMobileElement(inSights_Image.get(0));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Book per year Goal Removed successfully #Pass");
			waitFor(5000);
			ClickOnMobileElement(insight_rightArrow);
// 			Assert.assertEquals(insight_Name.get(0).getText(),testData.get(3).get("insight_lbl"));
			if (insight_GoalText.get(0).getText().equals("0")) {
				logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
			}		
		}
		else {
			if (insight_GoalText.get(0).getText().equals("0")) {
				logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
			}		
		}
		if (insight_GoalText.get(1).getText().contains("/")) {
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Listening Goal Removed successfully #Pass");
			waitFor(5000);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(insight_rightArrow);
			Assert.assertEquals(insight_Name.get(1).getText(),testData.get(4).get("insight_lbl"));
			if (insight_GoalText.get(1).getText().equals("0")) {
				logger.info(getData("platformName") + " - Listening insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Listening insight has some progress to display #Pass ");
			}		
		}
		else  {	
			if (insight_GoalText.get(1).getText().equals("0")) {
				logger.info(getData("platformName") + " - Listening insight Default Value 0 displayed #Pass ");	
			}else {
				logger.info(getData("platformName") + " - Listening insight has some progress to display #Pass ");
			}		
		}
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Insights/defaultValueDisplay.png");
		ClickOnMobileElement(insight_leftArrow);
		ClickOnMobileElement(insight_leftArrow);
		}
		
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			
			waitFor(7000);
			if (insight_GoalText.get(0).getText().contains("/")) {
				Actions acts=new Actions(driver);
				acts.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				logger.info(getData("platformName") + " - Reading Goal Removed successfully #Pass");
				waitFor(7000);
				Assert.assertEquals(insight_Name.get(0).getText(),testData.get(0).get("insight_lbl"));
				if (insight_GoalText.get(1).getText().equals("0")) {
					logger.info(getData("platformName") + " - Reading insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Reading insight has some progress to display #Pass ");
				}
			}
			else {
				if (insight_GoalText.get(1).getText().equals("0")) {
					logger.info(getData("platformName") + " - Reading insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Reading insight insight has some progress to display #Pass ");
				}		
			}
			if (insight_GoalText.get(1).getText().contains("/")) {
				
				  Actions acts=new Actions(driver);
				   acts.click(inSights_Image.get(1)).build().perform();					
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
					logger.info(getData("platformName") + " - Streak Goal Removed successfully #Pass");
					waitFor(8000);
					Assert.assertEquals(insight_Name.get(0).getText(),testData.get(1).get("insight_lbl"));
					if (insight_GoalText.get(0).getText().equals("0")) {
						logger.info(getData("platformName") + " - Streak insight Default Value 0 displayed #Pass ");	
					}else {
						logger.info(getData("platformName") + " - Streak insight has some progress to display #Pass ");
					}
			}
			else {
				if (insight_GoalText.get(0).getText().equals("0")) {
					logger.info(getData("platformName") + " - Streak insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Streak insight has some progress to display #Pass ");
				}		
			}	
			horizontalSwipeAndriod(inSights_Image);
			if (insight_GoalText.get(0).getText().contains("/")) {
				ClickOnMobileElement(inSights_Image.get(0));
				ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				logger.info(getData("platformName") + " - Book per month Goal Removed successfully #Pass");
				waitFor(5000);
				horizontalSwipeAndriod(inSights_Image);
				Assert.assertEquals(insight_Name.get(0).getText(),testData.get(2).get("insight_lbl"));
				if (insight_GoalText.get(1).getText().equals("0")) {
					logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
				}
			}
			else {
				if (insight_GoalText.get(1).getText().equals("0")) {
					logger.info(getData("platformName") + " - Books per month insight Default Value 0 displayed #Pass ");	
				}else {
					logger.info(getData("platformName") + " - Books per month insight has some progress to display #Pass ");
				}
			}	
		}
	}
	
	public static void setGoalWithValidInput() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		waitFor(2000);
		ClickOnMobileElement(inSights_Image.get(0));
		waitFor(2000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Reading Goal Setting is successful with valid input #Pass");
		waitFor(5000);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(2000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Streak Goal Setting is successful  with valid input #Pass");
		waitFor(5000);
		horizontalSwipeAndriod(inSights_Image);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Books per month Goal Setting is successful  with valid input #Pass");
		waitFor(8000);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(inSights_Image.get(0));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Books per year Goal Setting is successful  with valid input #Pass");
		waitFor(8000);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/validInput.png");
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Listen Goal Setting is successful  with valid input #Pass");
		waitFor(5000);
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(8000);
			Actions s = new Actions(driver);
			s.click(inSights_Image.get(0)).build().perform();
		
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(9000);
				Actions ss = new Actions(driver);
				ss.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful with valid input #Pass");

			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful with valid input #Pass");
			}
			waitFor(9000);
			Actions se = new Actions(driver);
			se.click(inSights_Image.get(1)).build().perform();
			
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				Actions s1 = new Actions(driver);
				s1.click(inSights_Image.get(1)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful  with valid input #Pass");

			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful  with valid input #Pass");
			}
		}
	}
	
	public static void closeSetGoalPage() throws IOException {
		waitFor(7000);
		String before = insight_GoalText.get(0).getText();
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
			ClickOnMobileElement(inSights_Image.get(0));
			Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
			navBack();
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			Actions ac=new Actions(driver);
			ac.click(inSights_Image.get(0)).build().perform();
			waitForElementDisplayed(SetGoal_PageHeader);
			waitFor(3000);
			swipeDown1();
			System.out.println("Swipe down Happens");
		}
		try {
			waitFor(5000);
			Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
			logger.info(getData("platformName") + " - Set Goal page is closing after swiping down #Fail ");
		} catch (Exception e) {
			logger.info(getData("platformName") + " - Set Goal page is closing after swiping down #Pass ");
		}
		waitFor(5000);
		System.out.println("User is on Home page");
		String after = insight_GoalText.get(0).getText();
		Assert.assertEquals(after, before);
	}
	
	public static void errorMsgValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		
		ClickOnMobileElement(inSights_Image.get(0));
		Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("invalid_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
		logger.info(getData("platformName") + " - User not able to click the set goal button with invalid input #Pass ");
		Assert.assertTrue(SetGoal_TargetErrorMsg.isDisplayed());
		Assert.assertEquals(SetGoal_TargetErrorMsg.getText(), testData.get(0).get("errorMsg"));
		logger.info(getData("platformName") + " - Error msg displayed for invalid input #Pass ");
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/errorMsg.png");
		SetGoal_TargetSettingField.clear();
		navBack();
		}
		
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(7000);
			Actions se = new Actions(driver);
			se.click(inSights_Image.get(0)).build().perform();
			
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				// ClickOnMobileElement(inSights_Image.get(1));
				Actions s1 = new Actions(driver);
				s1.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("invalid_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
				logger.info(getData("platformName") + " - User not able to click the set goal button with invalid input #Pass ");
				Assert.assertTrue(SetGoal_TargetErrorMsg.isDisplayed());
				Assert.assertEquals(SetGoal_TargetErrorMsg.getText(), testData.get(0).get("errorMsg"));
				logger.info(getData("platformName") + " - Error msg displayed for invalid input #Pass ");
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/errorMsg.png");
				swipeDown1();
			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("invalid_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				Assert.assertTrue(SetGoal_PageHeader.isDisplayed());
				logger.info(getData("platformName") + " - User not able to click the set goal button with invalid input #Pass ");
				Assert.assertTrue(SetGoal_TargetErrorMsg.isDisplayed());
				Assert.assertEquals(SetGoal_TargetErrorMsg.getText(), testData.get(0).get("errorMsg"));
				logger.info(getData("platformName") + " - Error msg displayed for invalid input #Pass ");
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/errorMsg.png");
				swipeDown1();
			}
		}
	}
	
	public static void goalTrackValidation() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		 if (insight_GoalText.get(0).getText().contains("/")) {
			logger.info(getData("platformName") + " - Goal is already been set for the insigth and its been tracked #Pass ");
			logger.info(getData("platformName") + " - Goal track : " + insight_GoalText.get(0).getText());
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/GoalTrack.png");
		 }
		 else {
			String before = insight_GoalText.get(0).getText();
			ClickOnMobileElement(inSights_Image.get(0));
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			waitFor(5000);
			String after = insight_GoalText.get(0).getText();
			if (after.contains("/")) {
				logger.info(getData("platformName") + " - Goal is set for the insight and its been tracked #Pass ");
				logger.info(getData("platformName") + " - Goal track : " + insight_GoalText.get(0).getText());	
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/GoalTrack.png");
			}
		}
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(9000);
			if (insight_GoalText.get(0).getText().contains("/")) {
				logger.info(getData("platformName") + " - Goal is already been set for the insigth and its been tracked #Pass ");
				logger.info(getData("platformName") + " - Goal track : " + insight_GoalText.get(0).getText());
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/GoalTrack.png");
			 }
			Actions act =new Actions(driver);
			act.click(inSights_Image.get(0)).build().perform();
			waitFor(4000);
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				// ClickOnMobileElement(inSights_Image.get(1));
				String before = insight_GoalText.get(0).getText();
				Actions s1 = new Actions(driver);
				s1.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				waitFor(6000);
				String after = insight_GoalText.get(0).getText();
				System.out.println(insight_GoalText.get(0).getText());
				
				if (after.contains("/")) {
					logger.info(getData("platformName") + " - Goal is set for the insight and its been tracked #Pass ");
					logger.info(getData("platformName") + " - Goal track : " + insight_GoalText.get(0).getText());	
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/GoalTrack.png");
					System.out.println("Contains /");
				}
			} catch (Exception e) {
				waitFor(1000);
				
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				waitFor(8000);
				String after = insight_GoalText.get(0).getText();
				
				if (after.contains("/")) {
					logger.info(getData("platformName") + " - Goal is set for the insight and its been tracked #Pass ");
					logger.info(getData("platformName") + " - Goal track : " + insight_GoalText.get(0).getText());	
					Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/GoalTrack.png");

			}}	
		}	 
	}
	
	public static void metricValidation() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");

		if (insight_GoalText.get(0).getText().contains("/")) {		
			String goalMetric = insight_GoalText.get(0).getText();
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric1.png");
			if (getData("platformName").equalsIgnoreCase("android")
					|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {

				ClickOnMobileElement(inSights_Image.get(0));
			}
			if (getData("platformName").equalsIgnoreCase("iOS")
					|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
				Actions s=new Actions(driver);
				s.click(inSights_Image.get(0)).build().perform();
			}
			waitFor(3000);
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			waitFor(5000);
			String insightMetric = insight_GoalText.get(0).getText();
			if(goalMetric.equals(insightMetric)) {
				logger.info(getData("platformName") + " - Insight and goal metric are different #Fail");	
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric2.png");
			} else {
				logger.info(getData("platformName") + " - Insight and goal metric are different #Pass");	
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric2.png");
			}	
		}
		else {
			String insightMetric = insight_GoalText.get(0).getText();
			Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric1.png");
			if (getData("platformName").equalsIgnoreCase("android")
					|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
				ClickOnMobileElement(inSights_Image.get(0));
				waitFor(3000);
				SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(SetGoal_SetGoalBtn);
			}
			if (getData("platformName").equalsIgnoreCase("iOS")
					|| getData("platformName").equalsIgnoreCase("BrowserStackios")) {
				Actions s=new Actions(driver);
				s.click(inSights_Image.get(0)).build().perform();
				waitFor(3000);
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(SetGoal_SetGoalBtn);
			}
			waitFor(8000);
			String goalMetric = insight_GoalText.get(0).getText();
			if(goalMetric.equals(insightMetric)) {
				logger.info(getData("platformName") + " - Insight and goal metric are different #Fail");	
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric2.png");
			} else {
				logger.info(getData("platformName") + " - Insight and goal metric are different #Pass");	
				Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/Metric2.png");
			}	
		}
	}
	
	public static void setGoalNewTarget() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		waitFor(8000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		ClickOnMobileElement(inSights_Image.get(0));
		waitFor(2000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("newGoal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Reading Goal Setting is successful with New input #Pass");
		waitFor(5000);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(2000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("newGoal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Streak Goal Setting is successful  with New input #Pass");
		waitFor(5000);
		horizontalSwipeAndriod(inSights_Image);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("newGoal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Books per month Goal Setting is successful  with New input #Pass");
		waitFor(8000);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(inSights_Image.get(0));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("newGoal_Target"));
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Books per year Goal Setting is successful  with New input #Pass");
		waitFor(8000);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(insight_rightArrow);
		ClickOnMobileElement(inSights_Image.get(1));
		waitFor(3000);
		SetGoal_TargetSettingField.clear();
		SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("newGoal_Target"));
		Screenshots.takeScreenshot(driver, "./Screenshots/" + getData("platformName") + "/Goals/NewInput.png");
		ClickOnMobileElement(SetGoal_SetGoalBtn);
		logger.info(getData("platformName") + " - Listen Goal Setting is successful  with New input #Pass");
		waitFor(5000);
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			
			Actions s=new Actions(driver);
			s.click(inSights_Image.get(1)).build().perform();
			
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(9000);
				Actions ss = new Actions(driver);
				ss.click(inSights_Image.get(1)).build().perform();

				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("newGoal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful with New input #Pass");

			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("newGoal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful with New input #Pass");

			}
			waitFor(8000);
			Actions se = new Actions(driver);
			se.click(inSights_Image.get(0)).build().perform();
			
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				// ClickOnMobileElement(inSights_Image.get(1));
				Actions s1 = new Actions(driver);
				s1.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("newGoal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful  with New input #Pass");

			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("newGoal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful  with New input #Pass");
			}	
		}
	}
	
	/********************************************** User landing Page - 1.6.26 ******************************************************/

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(id = "//*[@name=\"Destiny Discover\"]")
	public static MobileElement destinyLogo;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_global_search_icon")
	@iOSXCUITFindBy(id = "//*[@name=\"Search\"]")
	public static MobileElement globalSearchIcon;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/insights_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> inSights_Image;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/goals_heading_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[1]")
	public static MobileElement SetGoal_PageHeader;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/goals_desc_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText[2]")
	public static MobileElement SetGoalPage_Desc;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/target_goal_edit_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
	public static MobileElement SetGoal_TargetSettingField;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/target_goal_error_message")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Please enter a whole number between 1 and 999\"]")
	public static MobileElement SetGoal_TargetErrorMsg;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/button_set_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Set Goal']")
	public static MobileElement SetGoal_SetGoalBtn;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/button_remove_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Remove Goal']")
	public static List<MobileElement> SetGoal_RemoveGoalBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/daily_count_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]")
	public static List<MobileElement> insight_GoalText;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/daily_info_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText")
	public static List<MobileElement> insight_Name;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/days_info_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]")
	public static List<MobileElement> insight_GoalDesc;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/left_insights_arrow")
	public static MobileElement insight_leftArrow;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/right_insights_arrow")
	public static MobileElement insight_rightArrow;
	
	@iOSXCUITFindBy(xpath = "//*[@name='Remove Goal']")
	public static List<MobileElement> t;

	
}
