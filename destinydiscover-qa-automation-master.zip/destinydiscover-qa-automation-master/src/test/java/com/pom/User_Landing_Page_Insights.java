package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class User_Landing_Page_Insights extends CapabilitiesAndWebDriverUtils {

	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();

	ULP_Smoke ulpPage = new ULP_Smoke();

	public User_Landing_Page_Insights() {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static void insight() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		waitFor(5000);
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
			Assert.assertTrue(insight_Name.get(0).isDisplayed());
			logger.info(getData("platformName") + " - First insight in carousel : " + insight_Name.get(0).getText());
			Assert.assertTrue(insight_Name.get(1).isDisplayed());
			logger.info(getData("platformName") + " - Second insight in carousel : " + insight_Name.get(1).getText());
			horizontalSwipeAndriod(insight_Name);
			Assert.assertTrue(insight_Name.get(1).isDisplayed());
			logger.info(getData("platformName") + " - Third insight in carousel : " + insight_Name.get(1).getText());
			ClickOnMobileElement(insight_rightArrow);
			Assert.assertTrue(insight_Name.get(0).isDisplayed());
			logger.info(getData("platformName") + " - Fourth insight in carousel : " + insight_Name.get(0).getText());
			Assert.assertTrue(insight_Name.get(1).isDisplayed());
			logger.info(getData("platformName") + " - Fifth insight in carousel : " + insight_Name.get(1).getText());
			ClickOnMobileElement(insight_leftArrow);
			ClickOnMobileElement(insight_leftArrow);
		}
		if (getData("platformName").equalsIgnoreCase("ios")
				|| getData("platformName").equalsIgnoreCase("Browserstackios")) {

			logger.info(getData("platformName") + " - First insight in carousel : " + insight_Name.get(1).getText());
			logger.info(getData("platformName") + " - Second insight in carousel : " + insight_Name.get(0).getText());
			horizontalSwipe(insight_Name);

		}
	}

	public static void setGoalPageValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		waitFor(2000);
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
			ClickOnMobileElement(inSights_Image.get(0));
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(0).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(0).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Reading Goal Set Page is diplayed with the proper header and desc #Pass");
			SetGoal_TargetSettingField.clear();
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			logger.info(getData("platformName") + " - Reading Goal Setting is successful #Pass");
			waitFor(8000);
			ClickOnMobileElement(inSights_Image.get(1));
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(1).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(1).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Streak Goal Set Page is diplayed with the proper header and desc #Pass");
			SetGoal_TargetSettingField.clear();
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			logger.info(getData("platformName") + " - Streak Goal Setting is successful #Pass");
			waitFor(8000);
			horizontalSwipeAndriod(inSights_Image);
			ClickOnMobileElement(inSights_Image.get(1));
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(2).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(2).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Book per month Goal Set Page is diplayed with the proper header and desc #Pass");
			SetGoal_TargetSettingField.clear();
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			logger.info(getData("platformName") + " - Books per month Goal Setting is successful #Pass");
			waitFor(8000);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(inSights_Image.get(0));
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(3).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(3).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Books per year Goal Set Page is diplayed with the proper header and desc #Pass");
			SetGoal_TargetSettingField.clear();
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			logger.info(getData("platformName") + " - Books per year Goal Setting is successful #Pass");
			waitFor(8000);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(inSights_Image.get(1));
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(4).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(4).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Listening Goal Set Page is diplayed with the proper header and desc #Pass");
			SetGoal_TargetSettingField.clear();
			SendKeysOnMobileElement(SetGoal_TargetSettingField, testData.get(0).get("Goal_Target"));
			ClickOnMobileElement(SetGoal_SetGoalBtn);
			logger.info(getData("platformName") + " - Listen Goal Setting is successful #Pass");
			waitFor(5000);
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			ClickOnMobileElement(inSights_Image.get(0));
			System.out.println("Image Clicked");
			waitFor(3000);
			Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(0).get("setGoal_headerlbl"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(0).get("setGoal_Desclbl")));
			logger.info(getData("platformName")
					+ " - Reading Goal Set Page is diplayed with the proper header and desc #Pass");

			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(9000);
				Actions ss = new Actions(driver);
				ss.click(inSights_Image.get(0)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful #Pass");

			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Reading Goal Setting is successful #Pass");

			}
			waitFor(9000);
			Actions sa = new Actions(driver);
			sa.click(inSights_Image.get(1)).build().perform();
			System.out.println("Image2 Clicked");
			waitFor(3000);
		    Assert.assertEquals(SetGoal_PageHeader.getText(), testData.get(1).get("setGoal_headerlbl"));
			System.out.println(SetGoalPage_Desc.getText());
			String des = SetGoalPage_Desc.getText();
			String subdes = des.substring(39, 52);
			System.out.println(subdes);
			Assert.assertEquals(subdes, testData.get(1).get("setGoal_Desclbl_iOS"));
			Assert.assertTrue(SetGoalPage_Desc.getText().contains(testData.get(1).get("setGoal_Desclbl_iOS")));
			logger.info(getData("platformName")
					+ " - Streak Goal Set Page is diplayed with the proper header and desc #Pass");

			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				System.out.println("Remove button clicked");
				waitFor(8000);
				Actions s1 = new Actions(driver);
				s1.click(inSights_Image.get(1)).build().perform();
				ClickOnMobileElement(SetGoal_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful #Pass");
			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
				logger.info(getData("platformName") + " - Streak Goal Setting is successful #Pass");
			}
			waitFor(5000);


		}
	}

	public static void defaultInsightValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "Insights");
		waitFor(2000);
		if (getData("platformName").equalsIgnoreCase("Android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackAndroid")) {
			ClickOnMobileElement(inSights_Image.get(0));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Reading Goal Removed successfully #Pass");
			waitFor(5000);
			Assert.assertEquals(insight_Name.get(0).getText(), testData.get(0).get("insight_lbl"));
			logger.info(getData("platformName") + " - Reading Goal default Value displayed is : "
					+ insight_GoalText.get(0).getText());
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Streak Goal Removed successfully #Pass");
			waitFor(5000);
			Assert.assertEquals(insight_Name.get(1).getText(), testData.get(1).get("insight_lbl"));
			logger.info(getData("platformName") + " - Sreak Goal default Value displayed is : "
					+ insight_GoalText.get(1).getText());
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Book per month Goal Removed successfully #Pass");
			waitFor(5000);
			ClickOnMobileElement(insight_rightArrow);
			Assert.assertEquals(insight_Name.get(1).getText(), testData.get(2).get("insight_lbl"));
			logger.info(getData("platformName") + " - Books per month default Value displayed is : "
					+ insight_GoalText.get(1).getText());
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(inSights_Image.get(0));
			waitFor(3000);
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Book per year Goal Removed successfully #Pass");
			waitFor(5000);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(insight_rightArrow);
			Assert.assertEquals(insight_Name.get(0).getText(), testData.get(3).get("insight_lbl"));
			logger.info(getData("platformName") + " - Books per year default Value displayed is : "
					+ insight_GoalText.get(0).getText());
			ClickOnMobileElement(inSights_Image.get(1));
			ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
			logger.info(getData("platformName") + " - Listening Goal Removed successfully #Pass");
			waitFor(5000);
			ClickOnMobileElement(insight_rightArrow);
			ClickOnMobileElement(insight_rightArrow);
			Assert.assertEquals(insight_Name.get(1).getText(), testData.get(4).get("insight_lbl"));
			logger.info(getData("platformName") + " - Listening default Value displayed is : "
					+ insight_GoalText.get(1).getText());
			ClickOnMobileElement(insight_leftArrow);
			ClickOnMobileElement(insight_leftArrow);
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(8000);
			Actions s = new Actions(driver);
			s.click(inSights_Image.get(0)).build().perform();
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				logger.info(getData("platformName") + " - Reading Goal Removed successfully #Pass");
				//waitFor(7000);
				Assert.assertEquals(insight_Name.get(0).getText(), testData.get(0).get("insight_lbl"));
				logger.info(getData("platformName") + " - Reading Goal default Value displayed is : "
						+ insight_GoalText.get(0).getText());
			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
			}
			waitFor(8000);
			s.click(inSights_Image.get(1)).build().perform();
			logger.info(getData("platformName") + " - Reading Goal Removed successfully #Pass");
			try {
				if (SetGoal_RemoveGoalBtn.get(0).isDisplayed())
					ClickOnMobileElement(SetGoal_RemoveGoalBtn.get(0));
				logger.info(getData("platformName") + " - Streak Goal Removed successfully #Pass");
				waitFor(5000);
				Assert.assertEquals(insight_Name.get(1).getText(), testData.get(1).get("insight_lbl"));
				logger.info(getData("platformName") + " - Sreak Goal default Value displayed is : "
						+ insight_GoalText.get(1).getText());
			} catch (Exception e) {
				ClickOnMobileElement(ULP_Smoke.inSights_enteryourgoaltextboxbeforeenter);
				SendKeysOnMobileElement(ULP_Smoke.inSights_SetGoalBtn, testData.get(0).get("Goal_Target"));
				ClickOnMobileElement(ULP_Smoke.inSights_SetGoalBtn);
			}
		}
	}

	/**********************************************
	 * User landing Page - 1.6.26
	 ******************************************************/

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(id = "//*[@name=\"Destiny Discover\"]")
	public static MobileElement destinyLogo;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_global_search_icon")
	@iOSXCUITFindBy(id = "//*[@name=\"Search\"]")
	public static MobileElement globalSearchIcon;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/insights_image")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> inSights_Image;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/goals_heading_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[1]")
	public static MobileElement SetGoal_PageHeader;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/goals_desc_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText[2]")
	public static MobileElement SetGoalPage_Desc;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/target_goal_edit_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
	public static MobileElement SetGoal_TargetSettingField;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/button_set_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Set Goal']")
	public static MobileElement SetGoal_SetGoalBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/button_remove_goal")
	@iOSXCUITFindBy(xpath = "//*[@name='Remove Goal']")
	public static List<MobileElement> SetGoal_RemoveGoalBtn;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/daily_count_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]")
	public static List<MobileElement> insight_GoalText;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/daily_info_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
	public static List<MobileElement> insight_Name;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/days_info_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]")
	public static List<MobileElement> insight_GoalDesc;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/left_insights_arrow")
	@iOSXCUITFindBy(xpath = "//*[@name='CarouselRightArrow'][1]")
	public static MobileElement insight_leftArrow;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/right_insights_arrow")
	@iOSXCUITFindBy(xpath = "//*[@name='CarouselRightArrow'][1]")
	public static MobileElement insight_rightArrow;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"READ THIS YEAR\"]")
	public static List<MobileElement> readThisYear_txt;

}
