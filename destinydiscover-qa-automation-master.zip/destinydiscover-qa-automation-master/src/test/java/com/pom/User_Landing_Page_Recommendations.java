package com.pom;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.PaintStyle.TextureAlignment;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.Assert;

public class User_Landing_Page_Recommendations extends CapabilitiesAndWebDriverUtils {

	static ExcelReader reader = new ExcelReader();
	public static final Logger logger = LogManager.getLogger();
	
	ULP_Smoke ulpPage = new ULP_Smoke();

	public User_Landing_Page_Recommendations() {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static void defaultRecommendation() throws IOException {
		
		waitFor(5000);
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		swipeDown();
		swipeDown();
		Assert.assertTrue(ULP_Smoke.otherSuggestion_lbl.isDisplayed());
		Assert.assertTrue(ULP_Smoke.basedOnIntrest_lbl.isDisplayed());
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_intrestrightArrow);
		}
		logger.info(getData("platformName") + " -  User able to see default recommedation carousel in home page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel.png");
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_intrestleftArrow);
		}
		swipeDown();
		Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_isbnrightArrow);
		}
		logger.info(getData("platformName") + " -  User able to see Second default recommedation carousel in home page #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel.png");
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_isbnleftArrow);
		}}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			swipeDown();
			swipeDown();
			System.out.println("Swipe down happens");
			Assert.assertTrue(ULP_Smoke.basedOnIntrest_lbl.isDisplayed());
			Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
			logger.info(getData("platformName") + " -  User able to see default recommedation carousel in home page #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel.png");
			
			swipeDown();
			Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
			logger.info(getData("platformName") + " -  User able to see Second default recommedation carousel in home page #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel.png");
			
		}
	}
	
	public static void intrestTitleValidation() throws IOException {
		ClickOnMobileElement(footerMoreIcon);
		ClickOnMobileElement(accountsButton);
		waitFor(8000);
		Assert.assertTrue(accounts_PageHeader.isDisplayed());
		Assert.assertTrue(accounts_intrestSurveyTab.isDisplayed());
		try {
			Assert.assertTrue(accounts_intrestSurveyTab.isSelected());
			logger.info(getData("platformName") + " -  Intrest survey is selected by default #Pass");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/survey_page.png");
			
		} catch (Exception e) {
			logger.info(getData("platformName") + " -  Intrest survey is not selected by default");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/survey_page.png");
			ClickOnMobileElement(accounts_intrestSurveyTab);
			waitFor(8000);
		}
		for (int i = 0; i<=2; i++) {
			for (int j = 0; j<=intrest_Name.size()-1; j++) {
				if (getData("platformName").equalsIgnoreCase("android")
						|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
					Assert.assertTrue(intrest_Image.get(j).isDisplayed());
					Assert.assertTrue(intrest_Name.get(j).isDisplayed());
				}
				if (getData("platformName").equalsIgnoreCase("iOS")
						|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
					 WaitForMobileElement(intrest_Image.get(0));
		             WaitForMobileElement(intrest_Name.get(0));
				}		
			}
			swipeDown();
		}	
		swipeUp();
		swipeUp();
		waitFor(2000);
		logger.info(getData("platformName") + " -  Intrest survey Title and image is diplayed #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/intrest.png");
	}
	
	public static void intrestSelection() throws IOException {
		try {
			if(intrest_SaveIntrest.isEnabled()) {
				logger.info(getData("platformName") + " - Save intrest button is already enabled");
				ClickOnMobileElement(intrest_SaveIntrest);
				waitFor(5000);
				Assert.assertTrue(accounts_PageHeader.isDisplayed());
			}
		} catch (Exception e) {
			ClickOnMobileElement(intrest_SaveIntrest);
			waitFor(5000);
			Assert.assertTrue(accounts_PageHeader.isDisplayed());
		}
		logger.info(getData("platformName") + " -  User not able to tap save intrest without selcting the intrest #Pass");
		for (int i = 0; i<=5; i++) {
			if (intrest_Name.get(i).isSelected()) {
				logger.info(getData("platformName") + " - First intrest is already selected -Swiping down");
				swipeDown();
			}else {
				ClickOnMobileElement(intrest_Name.get(i));
				logger.info(getData("platformName") + " - intrest selected #Pass");
				waitFor(4000);
				Assert.assertTrue(intrest_Name.get(i).isEnabled());
			}	
		}
		logger.info(getData("platformName") + " -  User able to select their own choice #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/intrestSelection.png");
	}
	
	public static void submitPreference() throws IOException {
		Assert.assertTrue(intrest_SaveIntrest.isEnabled());
		logger.info(getData("platformName") + " -  Save Interest button is enabled after selecting the Intrest #Pass");
		try {
			ClickOnMobileElement(intrest_SaveIntrest);
		}
		catch(Exception e) {
			Actions s=new Actions(driver);
			s.click(intrest_SaveIntrest).build().perform();
			System.out.println("Save interest btn clicked");
		}
		waitFor(10000);
	}
	
	public static void afterSaveIntrest() {
		ClickOnMobileElement(homeBtn);
		waitFor(10000);
		swipeDown();
		swipeDown();
		swipeDown();
		Assert.assertTrue(ULP_Smoke.basedOnIntrest_lbl.isDisplayed());
		Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
	}
	
	public static  void recommendatioCarouselSwipe() throws IOException {
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_intrestrightArrow);
		}
		logger.info(getData("platformName") + " -  User able to swipe right in recommendation carousel #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel1.png");
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_intrestleftArrow);
		}
		logger.info(getData("platformName") + " -  User able to swipe left in recommendation carousel #Pass");
		Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_isbnrightArrow);
		}
		logger.info(getData("platformName") + " - User able to swipe right in second recommendation carousel #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Rec_Def_Carousel2.png");
		for (int i = 0; i<=3; i++) {
			ClickOnMobileElement(Recom_isbnleftArrow);
		}
		logger.info(getData("platformName") + " - User able to swipe left in second recommendation carousel #Pass");
	}
	
	public static void matTypeValidation() throws IOException {
		
		for (int i = 0; i <=3; i++) {
			if (ourSuggestion_MatStaus.size()==4 && ourSuggestion_MatStausText.size()==4 ) {
				Assert.assertTrue(true);				
				logger.info(getData("platformName") + " - Material type icon and text displayed #Pass");
			}
//			else {
//				Assert.assertTrue(false);								
//			}
			ClickOnMobileElement(Recom_intrestrightArrow);
		}
		logger.info(getData("platformName") + " - Material type icon and text displayed for all the titles in first recommendation carousel #Pass");
		
		for (int i = 0; i <=3; i++) {
			if (ourSuggestion_MatStaus.size()==4 && ourSuggestion_MatStausText.size()==4 ) {
				Assert.assertTrue(true);				
				logger.info(getData("platformName") + " - Material type icon and text displayed #Pass");
				}
//			else {
//				Assert.assertTrue(false);								
//			}
			ClickOnMobileElement(Recom_isbnrightArrow);
		}
		logger.info(getData("platformName") + " - Material type icon and text displayed for all the titles in Second recommendation carousel #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MatTypeIcon.png");

	}
	
	public static void titleMoreOptions() throws IOException {
		for (int i = 0; i <=ourSuggestion_MoreIcon.size()-1; i++) {
			ClickOnMobileElement(ourSuggestion_MoreIcon.get(i));
			if (ourSuggestion_MoreOption.size()>=1) {
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/MoreOpt.png");
				for (int j = 0; j <=ourSuggestion_MoreOption.size()-1; j++) {
					logger.info(getData("platformName") + " - Displayed More option : "+ourSuggestion_MoreOption.get(j).getText());
				}
				ClickOnMobileElement(ourSuggestion_MoreOption.get(ourSuggestion_MoreOption.size()-1));
			}
			else {
				logger.info(getData("platformName") + " - More Option are not displayed");
				Assert.assertTrue(false);
			}
		}	
	}
	
	public static void basedonPreferenceCarousel() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		Assert.assertTrue(ULP_Smoke.basedOnIntrest_lbl.isDisplayed());
		Assert.assertEquals(ULP_Smoke.basedOnIntrest_lbl.getText(), testData.get(0).get("Recommed_lbl"));
		if (ULP_Smoke.ourSuggestion_Title.size()!=0) {
			logger.info(getData("platformName") + " Based on Preference carousel is Displayed #Pass");
		}
	}
	
	public static void becauseyouEnjoyedCarousel() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/MobileData.xlsx", "ULP");
		Assert.assertTrue(ULP_Smoke.basedOnIsbn_lbl.isDisplayed());
		if (ULP_Smoke.basedOnIsbn_lbl.getText().contains(testData.get(0).get("Recommend_lbl2"))) {
			logger.info(getData("platformName") + " Because You enjoyed carousel is Displayed #Pass");
		}

	}
	
	public static void savebuttonValidation() throws IOException {
		ClickOnMobileElement(footerMoreIcon);
		ClickOnMobileElement(accountsButton);
		waitFor(8000);
		if (intrest_SaveIntrest.isEnabled()) {
			logger.info(getData("platformName") + " Save Intrest is already enabled #Fail");
			Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/save intrest.png");
		}
		else{
			ClickOnMobileElement(intrest_Name.get(8));
			if (intrest_SaveIntrest.isEnabled()) {
				logger.info(getData("platformName") + " Save Intrest is enabled after selecting one preference #Pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/save intrest.png");		
			}
			else {
				logger.info(getData("platformName") + " Save Intrest is enabled after selecting one preference #Fail");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/save intrest.png");
			}
			ClickOnMobileElement(intrest_Name.get(8));
		}
		
	}
	
	public static  void preferenceHighlightValidation() throws IOException {
		System.out.println(intrest_Image.get(7).getAttribute("clickable"));
		if (intrest_Image.get(7).getAttribute("clickable").equals("true")) {
			ClickOnMobileElement(intrest_Image.get(7));	
			String fgColor = intrest_Image.get(7).getCssValue("color");
			String bgColor = intrest_Image.get(7).getCssValue("background-color");
			if (!fgColor.equals(bgColor)) {
				logger.info(getData("platformName") + " Selected preference s highlighted #Pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Highlight.png");
				ClickOnMobileElement(intrest_Image.get(7));
			}
			else {
				logger.info(getData("platformName") + " Selected preference s highlighted #Fail");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Highlight.png");
			}
		}
		else {
			MobileElement element = (MobileElement)driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"GeographyUnSelected\"]"));
			String fgColor = element.getCssValue("color");
			System.out.println(fgColor);
			String bgColor = element.getCssValue("background-color");
			System.out.println(fgColor);
			if (!fgColor.equals(bgColor)) {
				logger.info(getData("platformName") + " Selected preference s highlighted #Pass");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Highlight.png");
				ClickOnMobileElement(intrest_Preference);
			}
			else {
				logger.info(getData("platformName") + " Selected preference s highlighted #Fail");
				Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/Highlight.png");
			}
		}
	}
	
	public static void unselectPreference() throws IOException {
		ClickOnMobileElement(intrest_Image.get(10));
		logger.info(getData("platformName") + " Preference Selected ");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/SelectPreference.png");
		ClickOnMobileElement(intrest_Image.get(10));
		logger.info(getData("platformName") + " Preference UnSelected #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/UnSelectPreference.png");
	}
	
	public static void newPreferenceSelection() throws IOException {
		ClickOnMobileElement(intrest_Image.get(10));
		Assert.assertTrue(intrest_Image.get(10).isEnabled());
		logger.info(getData("platformName") + " Select new Preference #Pass");
		Screenshots.takeScreenshot(driver,"./Screenshots/" + getData("platformName") + "/ULP/SelectNewPreference.png");
		ClickOnMobileElement(intrest_Image.get(10));
	}
	
	
	/********************************************** User landing Page - 1.6.28 ******************************************************/

	@iOSXCUITFindBy(xpath= "//XCUIElementTypeCell[@name=\"Home tab\"]")
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/menu_engage_home")
	public static MobileElement homeBtn;
	
	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"MORE\"]/android.view.ViewGroup/android.widget.TextView")
	@iOSXCUITFindBy(xpath= "//XCUIElementTypeCell[@name=\"More tab\"]")
	public static MobileElement footerMoreIcon;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/account_text")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Accounts\"]")
	public static MobileElement accountsButton;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath= "//XCUIElementTypeStaticText[@name=\"Destiny Discover\"]")
	public static MobileElement destinyLogo;

	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_global_search_icon")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Search\"]")
	public static MobileElement globalSearchIcon;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/right_interest_arrow")
	public static MobileElement Recom_intrestrightArrow;
	
	@AndroidFindBy(id ="com.follett.fss.searchread.stage:id/left_interest_arrow")
	public static MobileElement Recom_intrestleftArrow;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/right_isbn_arrow")
	public static MobileElement Recom_isbnrightArrow;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/left_isbn_arrow")
	public static MobileElement Recom_isbnleftArrow;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/nav_title")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Accounts\"]")
	public static MobileElement accounts_PageHeader;
	
	@AndroidFindBy(xpath = "//*[@text='Interest Survey']")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name=\"Interest Survey\"]")
	public static MobileElement accounts_intrestSurveyTab;
	
	@AndroidFindBy(xpath = "//*[@text='Badges']")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name=\"Badges\"]")
	public static MobileElement accounts_BadgesTab;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/interest_name_text")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther")
	public static List<MobileElement> intrest_Name;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/image")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell")
	public static List<MobileElement> intrest_Image;
	
	@AndroidFindBy(id = "com.follett.fss.searchread.stage:id/saveInterestBt")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Save Interests\"]")
	public static MobileElement intrest_SaveIntrest;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/material_status_image_view")
	public static List<MobileElement> ourSuggestion_MatStaus;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/material_status_view")
	public static List<MobileElement> ourSuggestion_MatStausText;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/material_cover_image_view")
	public static List<MobileElement> ourSuggestion_Title;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/more_option_image_view")
	public static List<MobileElement> ourSuggestion_MoreIcon;
	
	@AndroidFindBy(id="com.follett.fss.searchread.stage:id/option_text")
	public static List<MobileElement> ourSuggestion_MoreOption;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"GeographyUnSelected\"]")
	public static MobileElement intrest_Preference;
	
	
}
