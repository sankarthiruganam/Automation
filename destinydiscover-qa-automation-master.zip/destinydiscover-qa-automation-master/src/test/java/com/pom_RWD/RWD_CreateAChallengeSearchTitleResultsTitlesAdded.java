package com.pom_RWD;

import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class RWD_CreateAChallengeSearchTitleResultsTitlesAdded extends CapabilitiesAndWebDriverUtils{
	public RWD_CreateAChallengeSearchTitleResultsTitlesAdded()  {

		
	}

	

}
