package com.pom_RWD;

import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class RWD_CreateAChallengeSearchTitlesDefaultState extends CapabilitiesAndWebDriverUtils{
	
public RWD_CreateAChallengeSearchTitlesDefaultState()  {
		
	}

}
