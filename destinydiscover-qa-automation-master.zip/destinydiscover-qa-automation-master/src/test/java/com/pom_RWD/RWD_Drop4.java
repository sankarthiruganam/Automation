package com.pom_RWD;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

public class RWD_Drop4 extends CapabilitiesAndWebDriverUtils {

	static ExcelReader reader = new ExcelReader();
	private static final Logger logger = LogManager.getLogger();
	SoftAssert softAssert = new SoftAssert();
	List<Map<String, String>> testData;

	public RWD_Drop4() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//h2[text()='Badges']")
	public WebElement Rwdbadges;

	@FindBy(xpath = "//li[text()='HOME']")
	public WebElement Rwdhome;

	@FindBy(xpath = "//*[@aria-label='more']")
	public WebElement RwdMore;

	@FindBy(xpath = "//*[@role='menuitem']")
	public WebElement RwdMenuItem;

	@FindBy(xpath = "//span[text()='IN']")
	public WebElement RwdInbadge;

	@FindBy(xpath = "//span[text()='OUT']")
	public WebElement RwdOutbadge;

	@FindBy(xpath = "//label[text()='Other Recommendations']")
	public WebElement RwdRecommendations;

	@FindBy(xpath = "//h3[text()='Based on your preference']")
	public WebElement Rwdpreference;

	@FindBy(xpath = "//button[text()='Save Interests']")
	public WebElement RwdSaveInterest;

	@FindBy(xpath = "//button[text()=' Interest Survey ']")
	public WebElement Rwdinterrestsurvey;

	@FindBy(xpath = "//*[@class='intrst-main-survy']")
	public WebElement Rwdparrentclass;

	@FindBy(xpath = "//*[@alt='Mountains ']")
	public WebElement RwdRecommadbook;

	@FindBy(xpath = "//*[@aria-label='Open profile options window']")
	public static WebElement menu_profileIcon;

	@FindBy(xpath = "//mat-error[text()='Please enter a whole number between 1 and 999 ']")
	public WebElement Rwderrormsg;

	@FindBy(xpath = "//span[text()='Remove Goal']")
	public WebElement Rwdremovegoal;

	@FindBy(xpath = "//*[@class='insight-item ng-star-inserted']")
	public WebElement RwdInsights;

	@FindBy(xpath = "//*[@class='modal-header']")
	public WebElement RwdModalheader;

	@FindBy(xpath = "//*[@class='modal-info']")
	public WebElement Rwdmodalinfo;

	@FindBy(xpath = "//*[@class='mat-icon notranslate icon-keyboard material-icons mat-icon-no-color']")
	public WebElement Rwdgoalclose;

	@FindBy(xpath = "//h2[text()='Insights']")
	public WebElement Rwdinsights;

	@FindBy(xpath = "//*[@class='badges-container']")
	public List<WebElement> Rwdbadgescontainer;

	@FindBy(xpath = "//button[@class='achev-seeall-btn']")
	public WebElement Rwdseeall;

	@FindBy(xpath = "//span[text()='Set Goal']")
	public WebElement Rwdsetgoal;

	@FindBy(id = "goal-input")
	public WebElement RwdgoalInput;

	@FindBy(xpath = "//mat-icon[text()='close']")
	public WebElement Rwdcloseicon;

	@FindBy(xpath = "//*[contains(text(),'You have no messages')]")
	public WebElement RWDnoMessages;

	@FindBy(xpath = "//*[@class='msg-close']")
	public WebElement msgclose;

	@FindBy(xpath = "//div[@class='content-name-head']")
	public List<WebElement> RWDInviteText;

	@FindBy(xpath = "//span[@class='msg-badge-count ng-star-inserted']")
	public WebElement msgNotificationCount;

	@FindBy(xpath = "//*[@class='msg-icon-button icon-bg mr-rgt ng-star-inserted']")
	public WebElement RWDMessagecenter;

	public void viewEarnedbadges() throws IOException {

		waitFor(4000);
		if (ElementisPresent(Rwdbadges)) {
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges lable are displayed #Pass");
			for (int i = 0; i < Rwdbadgescontainer.size(); i++) {
				if (Rwdbadgescontainer.get(i).isDisplayed()) {
					Assert.assertEquals(Rwdbadgescontainer.get(i).isDisplayed(), true);
					logger.info("All Badges are displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/badges/badges.png");
				}
			}
		} else {
			logger.info("No badges are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}

	}

	public void seeallBadges() throws IOException {
		waitFor(2000);
		if (ElementisPresent(Rwdbadges)) {
			ClickOnWebElement(Rwdseeall);
			waitFor(2000);
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges lable are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/allbadges.png");
			for (int i = 0; i < Rwdbadgescontainer.size(); i++) {
				if (Rwdbadgescontainer.get(i).isDisplayed()) {
					Assert.assertEquals(Rwdbadgescontainer.get(i).isDisplayed(), true);
					logger.info("All Badges are displayed #Pass");

				}

			}
			ClickOnWebElement(Rwdcloseicon);
		} else {
			logger.info("No badges are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}

	}

	public void verifydublicatebadges() throws IOException {

		HashSet<String> optionNames = new HashSet<>();
		if (ElementisPresent(Rwdbadges)) {
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges lable are displayed #Pass");
			for (int i = 0; i < Rwdbadgescontainer.size(); i++) {
				if (optionNames.contains(Rwdbadgescontainer.get(i).getText())) {
					softAssert.assertTrue(false, "Same badges are availbe twise");
					;
					logger.info("Same badges are availbe twise #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/badges/dublicatebadges.png");
				} else {
					logger.info("Unique badges are avilable not dublicate #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/badges/uniquebadges.png");
				}
			}
		} else {
			logger.info("No badges are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}

	}

	public void messageDetails() throws IOException {
		if (ElementisPresent(msgNotificationCount)) {
			Assert.assertTrue(msgNotificationCount.isEnabled());
			logger.info("Message Center Bell icon Displayed #Pass");
			Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/messagecenterBellIcon.png");
			logger.info("Unread Messages Displayed in top of hamburger Menu #Pass");

		} else {
			logger.info("Message Center Bell icon Not Displayed");
			Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/messagecenterNotBellIcon.png");
		}
		logger.info("User able to click on bell icon to navigate to messages listing page #Pass");
		ClickOnWebElement(RWDMessagecenter);
		if (ElementisPresent(RWDnoMessages)) {
			Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/noMessages.png");
			logger.info("Login into message Center! You have No Messages! #Pass");
			ClickOnWebElement(msgclose);
		} else {
			logger.info("Login into Message Center #Pass");
			for (WebElement Allele : RWDInviteText) {
				Allele.click();
				waitFor(4000);
				logger.info("User able to view the message details in an expanded fashion​ #Pass");
				Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/MessageDetails.png");
				break;
			}
		}

	}

	public void setpersonalgoal() throws IOException {
		waitFor(4000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					waitFor(3000);

				}
				logger.info("set reading goal popup showing #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void checkDefaultInsights() throws IOException {

		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
				}

			}
			logger.info("Insights progrss bar is available #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/insightsprogrss.png");
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void viewgoal() throws IOException {
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
				}
				logger.info("Insights progrss bar is available #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/insights/insightsprogrss.png");
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void checkprogress() throws IOException {

		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
				}
				logger.info("Insights progrss bar is available #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/insights/insightsprogrss.png");
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void checkgoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					Assert.assertEquals(RwdModalheader.isDisplayed(), true);
					logger.info("Goal header is showing #Pass");
					Assert.assertEquals(Rwdmodalinfo.isDisplayed(), true);
					logger.info("Goal header info is showing #Pass");
					ClickOnWebElement(Rwdgoalclose);
					logger.info(
							"verify user able to click on the close icon to close the set reading goal pop-up #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					waitFor(3000);
					break;

				}

			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void setgoal() throws IOException {
		waitFor(4000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					logger.info("set reading goal popup showing #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("personal goal value entered #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void removegoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					logger.info("set reading goal popup showing #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					Assert.assertEquals(Rwdremovegoal.isDisplayed(), true);
					logger.info("Remove button enabled #Pass");
					ClickOnWebElement(Rwdremovegoal);
					logger.info("personal goal removed  #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void checkinvalidsetgoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					logger.info("set reading goal popup showing #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "1000");
					waitFor(1000);
					Assert.assertEquals(Rwderrormsg.getText().trim(), "Please enter a whole number between 1 and 999");
					ClickOnWebElement(Rwdsetgoal);
					logger.info(
							"If user tries to click on Set Goal CTA by entering an invalid value getting error#Pass");
					ClickOnWebElement(Rwdgoalclose);
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void readingperday() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(0).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(0));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(0).isDisplayed(),
							true);
					logger.info("mins of reading per day goal displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/readingpopuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("set the goal mins of reading per day #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void listeningperday() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(1).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(1));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(1).isDisplayed(),
							true);
					logger.info("mins of listening per day goal displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/listeningpopuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("set the goal mins of listening per day #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void streakgoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(2).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(2));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(2).isDisplayed(),
							true);
					logger.info("streak goal displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/streakpopuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("set the goal for streak #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void monthlygoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(3).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(3));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(3).isDisplayed(),
							true);
					logger.info("monthly goal displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/monthlypopuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("set the monthly goal #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}

	}

	public void yearlygoal() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(4).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(4));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(4).isDisplayed(),
							true);
					logger.info("yearly goal displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/yearlypopuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					logger.info("set the yearly goal #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void updateInterestSurvey() throws IOException, InvalidFormatException {
		waitFor(6000);
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Recommendation");
		ClickOnWebElement(menu_profileIcon);
		ClickOnWebElement(Rwdinterrestsurvey);
		waitFor(4000);
		Screenshots.takeScreenshot(driver, "Screenshots/Interrestsurvey/Home.png");
		logger.info("Nagivated to interrestsurvey Page #Pass");
		for (int i = 0; i < Rwdparrentclass.findElements(By.tagName("button")).size(); i++) {
			if (Rwdparrentclass.findElements(By.tagName("button")).get(i).getAttribute("title")
					.equalsIgnoreCase(testData.get(0).get("selectnewperference"))) {
				jsClick(Rwdparrentclass.findElements(By.tagName("button")).get(i));
				jsClick(Rwdparrentclass.findElements(By.tagName("button")).get(i));
				ClickOnWebElement(RwdSaveInterest);
				waitFor(2000);
				logger.info("Updated interrestsurvey successfully #Pass");
				break;
			} else {
			}

		}

	}

	public void viewtitledesc() throws IOException {
		waitFor(4000);
		javaScriptScrollToEnd();
		waitFor(2000);
		javascriptScroll(RwdRecommendations);
		if (ElementisPresent(RwdRecommendations)) {
			javascriptScroll(Rwdpreference);
			Assert.assertEquals(RwdRecommadbook.isDisplayed(), true);
			logger.info("titles availble based on the recommendation #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/Recommendation/title.png");
		} else {
			logger.info(" recommendation carousel not available  #Pass");
		}

	}

	public void checkInOutbadges() throws IOException {

		javaScriptScrollToEnd();
		waitFor(2000);
		javascriptScroll(RwdRecommendations);
		if (ElementisPresent(RwdRecommendations)) {
			javascriptScroll(Rwdpreference);
			Assert.assertEquals(RwdRecommadbook.isDisplayed(), true);
			Assert.assertEquals(RwdInbadge.isDisplayed(), true);
			logger.info("titles IN badge availble based on the recommendation #Pass");

		} else {
			logger.info(" recommendation carousel not available  #Pass");
		}

	}

	public void checkMoreoptions() throws IOException {
		waitFor(3000);
		javaScriptScrollToEnd();
		waitFor(2000);
		javascriptScroll(RwdRecommendations);
		if (ElementisPresent(RwdRecommendations)) {
			javascriptScroll(Rwdpreference);
			waitFor(2000);
			jsClick(RwdMore);
			waitFor(3000);
			Assert.assertEquals(RwdMenuItem.isDisplayed(), true);
			Screenshots.takeScreenshot(driver, "Screenshots/Recommendation/moremenutitle.png");
			logger.info("More menu item availble based on the recommendation title #Pass");

		} else {
			logger.info(" recommendation carousel not available  #Pass");
		}
	}

	public void listofpreferencedisplay() throws InvalidFormatException, IOException {
		waitFor(6000);
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Recommendation");
		ClickOnWebElement(menu_profileIcon);
		ClickOnWebElement(Rwdinterrestsurvey);
		waitFor(4000);
		Screenshots.takeScreenshot(driver, "Screenshots/Interrestsurvey/Home.png");
		logger.info("Nagivated to interrestsurvey Page #Pass");
		for (int i = 0; i < Rwdparrentclass.findElements(By.tagName("button")).size(); i++) {
			if (Rwdparrentclass.findElements(By.tagName("button")).get(i).isDisplayed()) {
				waitFor(2000);
				logger.info("List of preference displayed #Pass"
						+ Rwdparrentclass.findElements(By.tagName("button")).get(i).getAttribute("title"));
				break;
			} else {
				logger.info("interrestsurvey not displayed successfully #Pass");
			}
			break;

		}

	}

	public void recommendationcarousel() {

		javaScriptScrollToEnd();
		javascriptScroll(RwdRecommendations);
		if (ElementisPresent(RwdRecommendations)) {
			Assert.assertEquals(RwdRecommendations.isDisplayed(), true);
			logger.info(" recommendation carousel is available  #Pass");
		} else {
			logger.info(" recommendation carousel not available  #Pass");
		}
	}

}
