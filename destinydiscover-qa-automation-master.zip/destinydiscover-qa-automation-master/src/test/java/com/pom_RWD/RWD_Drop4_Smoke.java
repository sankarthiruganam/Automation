package com.pom_RWD;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

public class RWD_Drop4_Smoke extends CapabilitiesAndWebDriverUtils {
	//private static final Logger logger = LogManager.getLogger();
	static ExcelReader reader = new ExcelReader();
	public String chlngName = challengeName();
	Rwd_RC rc= new Rwd_RC();
	RWD_RP rp= new RWD_RP();

	public RWD_Drop4_Smoke() {
		PageFactory.initElements(driver, this);
	}
	
	public void RP_RC_Carousel() throws InvalidFormatException, IOException {
		//List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Drop4");
		Screenshots.takeScreenshot(driver, "Screenshots/DestinyDiscover/RP_RC_Carousel.png");
		WaitForWebElement(Home);
		waitFor(8000);
		ClickOnWebElement(Home);
		WaitForWebElement(rc.RWDbookClubOptionWeb);
		waitFor(8000);
		javascriptScroll(RP_RC_Carousel_Header);
		
		Assert.assertTrue(ElementisPresent(RP_RC_Carousel_Header),"Reading Programs and Challenges Carousel is not present");
		logger.info(RP_RC_Carousel_Header.getText()+" Carousel is displayed #Pass");
		
		Assert.assertTrue(ElementisPresent(seeAll_RP_RC),"See All button for Reading Programs and Challenges Carousel is not present");
		logger.info("See All button for Reading Programs and Challenges Carousel is displayed #Pass");
		
	}
	
	public void RP_RC_details(boolean image,boolean name, boolean progress) {
		if(RP_RC.size()>0) {
			for (int i=0; i<=RP_RC.size()-1; i++) {
				if(image == true) {
					Assert.assertTrue(ElementisPresent(RP_RC_image.get(i)));
					logger.info(i+" :Reading program and Challenges title image is displayed for all the items #Pass");
					break;
				}
				if(name == true) {
					Assert.assertTrue(ElementisPresent(RP_RC_name.get(i)));
					logger.info(i+" :Reading program and Challenges name is displayed for all the items #Pass");
					break;
				}
				if(progress= true) {
					// progress bar is not showing for all the items in this carousel
					//Assert.assertTrue(ElementisPresent(RP_RC_progress.get(i)));
					//logger.info("Reading program and Challenges progress bar is displayed for all the items #Pass");
				}
				/*
				 * if(i==RP_RC.size()) { break; }
				 */
			}
		}
	}
	
	public void rc_Details() throws InvalidFormatException, IOException {
		//List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Drop4");
		Screenshots.takeScreenshot(driver, "Screenshots/DestinyDiscover/RC_Details.png");
		if(RC.size()>0) {
			logger.info("Reading challenge is available #Pass");
			//javascriptScroll(RC.get(0));
			ClickOnWebElement(RC.get(0));
			logger.info("Clicked on Reading challenge to view the details #Pass");
			RC_participantView();
		}
		else{
			logger.info("Reading challenge is not available inside the carousel");
		}
	}
	
	public void rp_Details() throws IOException, InvalidFormatException {
	//	List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Drop4");
		Screenshots.takeScreenshot(driver, "Screenshots/DestinyDiscover/RP_Details.png");
		if(RP.size()>0) {
			logger.info("Reading program is available #Pass");
			javascriptScroll(RP.get(0));
			jsClick(RP.get(0));
			logger.info("Clicked on Reading program to view the details #Pass");
			RP_participantView();
		}
		else {
			logger.info("Reading program is not available inside the carousel");
		}
	}
	
	public void RC_participantView() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "Participant screen");
		
		WaitForWebElement(rc.lbl_readingChallengeHeader);
		logger.info(rc.lbl_readingChallengeHeader.getText()+" Header is present #Pass");
		Screenshots.takeScreenshot(driver,"Screenshots/ParticipantScreen/ParticipantScreen.png");
		Assert.assertTrue(ElementisPresent(rc.breadcrumbList),"BreadCrumb is not available for participant");
		logger.info("Breadcrumb is available for participant #Pass");
		Assert.assertEquals(ElementisPresent(rc.participantChallengeName),true); 
		logger.info("Created challenge name is available for participant #Pass");
		Screenshots.takeScreenshot(driver,"Screenshots/ParticipantScreen/ReadingChallenge.png");		
		try{
			Assert.assertEquals(ElementisPresent(rc.participantChallengeDesc),true); 
			logger.info("Created challenge Description are available for Invited user #Pass");
		}
		catch(Exception e) {
			logger.info("Created challenge Description is not available #Pass");
		}
		Assert.assertTrue(rc.avatar.isDisplayed(),"Participant Avatar is not available");
		logger.info("Participant Avatar is available for participant #Pass");
		Assert.assertTrue(rc.createdUser.isDisplayed(),"Created user profile is not available");
		logger.info("Created user profile is available for participant #Pass");
		//Assert.assertEquals(rc.RWDreportabusebtn.getText().trim(), testData1.get(0).get("lbl_reportAbuse").trim());
		//logger.info("Report abuse button is available for participant #Pass");
		String leaveChlg=rc.leaveChlng.getText().substring(0, 15);
		Assert.assertEquals(leaveChlg, testData1.get(0).get("lbl_leaveChlg").trim());
		logger.info("Leave challenge button is available for participant #Pass");
	//	Assert.assertEquals(rc.Readinglist1.getText().trim().contains(testData1.get(0).get("lbl_readingList").trim()),true);
		logger.info("Reading list header is available for participant #Pass");
		rc.titles();  //Reading list validation
		rc.participants(); //Participant list validation
		Screenshots.takeScreenshot(driver,"Screenshots/ParticipantScreen/ReadingChallenge1.png");
		logger.info("--Participant screen validation Completed--");
	}
	
	
	public void RP_participantView() {
		WaitForWebElement(rp.readingProgramHeader);
		waitFor(9000);
		Assert.assertTrue(ElementisPresent(rp.readingProgramHeader), "Reading program header is not displayed #Fail");
		logger.info("Reading program header is displayed #Pass");
		
		Assert.assertEquals(ElementisPresent(rp.lbl_readinglist), true);
		logger.info("Reading list header is available #Pass");

		Assert.assertEquals(ElementisPresent(rp.lbl_participantlist), true);
		logger.info("Participant list header is available #Pass");

		Assert.assertEquals(ElementisPresent(rp.lbl_startDate), true);
		logger.info("Start date is available #Pass");
		waitFor(1000);
		Assert.assertEquals(ElementisPresent(rp.lbl_endDate), true);
		logger.info("End date is available #Pass");

		Assert.assertTrue(rc.avatar.isDisplayed(),"Participant Avatar is not available");
		logger.info("Participant Avatar is available for participant #Pass");
		
		Assert.assertTrue(RP_createdUser.isDisplayed(),"Created user profile is not available");
		logger.info("Created user profile is available for participant #Pass");
		
	}
	public void badgemsg() {
		for(int i=0; i<= rc.msgHeader.size()-1; i++ ) {
			//System.out.println(i +" : "+ rc.msgHeader.get(i).getText());
			try {
				if(rc.msgHeader.get(i).getText().equalsIgnoreCase("You earned a shiny new Badge!")) {
					javascriptScroll(badge_msg);
					logger.info("Awarded badge message is available in message centre #Pass");
					jsClick(rc.msgclose);
					WaitForWebElement(Home);
					break;
				}
				else {
					javaScriptScrollToEnd();
				}
			}
			catch(Exception e) {
				javascriptScroll(rc.msgHeader.get(i));
			}
				
		}
	}
	
	public void updateInterestSurvey() throws IOException {
		waitFor(6000);
		ClickOnWebElement(menu_profileIcon);
		ClickOnWebElement(Rwdinterrestsurvey);
		waitFor(4000);
		Screenshots.takeScreenshot(driver, "Screenshots/Interrestsurvey/Home.png");
		logger.info("Nagivated to interrestsurvey Page #Pass");
		jsClick(RwdAnimals);
		jsClick(RwdEconomics);
		waitFor(2000);
		ClickOnWebElement(RwdSaveInterest);
		waitFor(2000);
		logger.info("Updated interrestsurvey successfully #Pass");

	}

	public void viewnewsAnnouncements() throws IOException {
		waitFor(9000);
		Assert.assertEquals(Rwdnews.isDisplayed(), true);
		logger.info("User able to view news and Announcements widget #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/HomePage/Newspage.png");
		Assert.assertEquals(Rwdnewstext.isDisplayed(), true);
		logger.info("User able to view news and Announcements Text #Pass");

	}

	public void searchBooks() throws IOException, InvalidFormatException {

		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(2000);
		ClickOnWebElement(RwdsearchIcon);
		WaitForWebElement(txt_SearchInput);
		Screenshots.takeScreenshot(driver, "Screenshots/SearchPage/searchpage.png");
		logger.info("Title search header is available #Pass");
		SendKeysOnWebElement(txt_SearchInput, testData1.get(0).get("titleName"));
		waitFor(5000);
		Screenshots.takeScreenshot(driver, "Screenshots/SearchPage/AddTitle_SuggestedResult.png");
		logger.info("Suggested result header is available #Pass");
		SendKeysEnter(txt_SearchInput);
		waitFor(5000);

	}

	public void checkprogressofInsights() throws IOException {
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.size(); i++) {
				if (RwdInsights.get(i).isDisplayed())
				{
					Assert.assertEquals(RwdInsights.get(i).isDisplayed(), true);
					logger.info("Insights progrss bar is available #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/insights/insightsprogrss.png");
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void setgoal() throws IOException {
		waitFor(9000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.size(); i++) {
				if (RwdInsights.get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.get(i));
					Assert.assertEquals(RwdInsights.get(i).isDisplayed(), true);
					logger.info("set reading goal popup showing #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					RwdgoalInput.clear();
					SendKeysOnWebElement(RwdgoalInput, "5");
					ClickOnWebElement(Rwdsetgoal);
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void removegoal() throws IOException {
		waitFor(9000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.size(); i++) {
				if (RwdInsights.get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.get(i));
					Assert.assertEquals(RwdInsights.get(i).isDisplayed(), true);
					logger.info("set reading goal popup showing #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
					Assert.assertEquals(Rwdremovegoal.isDisplayed(), true);
					ClickOnWebElement(Rwdremovegoal);
					logger.info("Remove button enabled #Pass");
					break;
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
		}
	}

	public void viewbadges() throws IOException {
		waitFor(4000);
		if (ElementisPresent(Rwdbadges)) {
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges lable are displayed #Pass");
			for (int i = 0; i < Rwdbadgescontainer.size(); i++) {
				if (Rwdbadgescontainer.get(i).isDisplayed()) {
					Assert.assertEquals(Rwdbadgescontainer.get(i).isDisplayed(), true);
					logger.info("All Badges are displayed #Pass");
				}
			}
		} else {
			logger.info("No badges are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}
	}

	public void seeallviewbadges() throws IOException {
		waitFor(2000);
		if (ElementisPresent(Rwdbadges)) {
			ClickOnWebElement(Rwdseeall);
			waitFor(2000);
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges lable are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/allbadges.png");
			for (int i = 0; i < Rwdbadgescontainer.size(); i++) {
				if (Rwdbadgescontainer.get(i).isDisplayed()) {
					Assert.assertEquals(Rwdbadgescontainer.get(i).isDisplayed(), true);
					logger.info("All Badges are displayed #Pass");

				}

			}
			ClickOnWebElement(Rwdcloseicon);
		} else {
			logger.info("No badges are displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}
	}
	
	@FindBy(xpath="//*[text()='You earned a shiny new Badge!']")
	public WebElement badge_msg;
	
	@FindBy(id="pd-prflname")
	public WebElement RP_createdUser;
	
	@FindBy(xpath = "//a[text()=' Home ']")
	public WebElement Home;
	
	@FindBy(xpath="//h2[text()='Reading Programs and Challenges']")
	public WebElement RP_RC_Carousel_Header;
	
	@FindBy(xpath="//button[@class='achev-seeall-btn ng-star-inserted']")
	public WebElement seeAll_RP_RC;
	
	@FindBy(xpath="//*[@class='mat-card mat-focus-indicator trail-rc-section readerchallenge-program ng-star-inserted']")
	public List<WebElement> RP_RC;
	
	@FindBy(xpath="//*[@class='poster-backgrd trail-rc-banner']")
	public List<WebElement> RP_RC_image;
	
	@FindBy(xpath="//*[@class='trail-elip']")
	public List<WebElement> RP_RC_name;
	
	@FindBy(xpath="//*[@class='progress-bar']")
	public List<WebElement> RP_RC_progress;
	
	@FindBy(xpath="//*[@class='trail-rc-icon poster-challenge']")
	public List<WebElement> RC;
	
	@FindBy(xpath="//*[@class='trail-rc-icon poster-program']")
	public List<WebElement> RP;
	
	@FindBy(xpath = "//h2[text()='Insights']")
	public WebElement Rwdinsights;

	@FindBy(xpath = "//button[text()=' Interest Survey ']")
	public WebElement Rwdinterrestsurvey;

	@FindBy(xpath = "//mat-icon[text()='close']")
	public WebElement Rwdcloseicon;

	@FindBy(xpath = "//h2[text()='Badges']")
	public WebElement Rwdbadges;

	@FindBy(xpath = "//*[@class='badges-container']")
	public List<WebElement> Rwdbadgescontainer;

	@FindBy(xpath = "//button[@class='achev-seeall-btn']")
	public WebElement Rwdseeall;

	@FindBy(id = "head-menu-list-home")
	public WebElement RwdhomeScreen;

	@FindBy(id = "goal-input")
	public WebElement RwdgoalInput;

	@FindBy(xpath = "//button[@class='search-Icon-Button icon-bg']")
	public WebElement RwdsearchIcon;

	@FindBy(xpath = "//button[@title='Government']")
	public WebElement RwdAnimals;

	@FindBy(xpath = "//button[@title='Economics']")
	public WebElement RwdEconomics;
	
	@FindBy(xpath = "//button[text()='Save Interests']")
	public WebElement RwdSaveInterest;

	@FindBy(xpath = "//span[text()='Set Goal']")
	public WebElement Rwdsetgoal;

	@FindBy(xpath = "//div[text()=' Set Listening Goal ']")
	public WebElement Rwdsetlistinggoal;

	@FindBy(xpath = "//span[text()='Remove Goal']")
	public WebElement Rwdremovegoal;

	@FindBy(xpath = "//*[text()=' News & Announcements ']")
    public WebElement Rwdnews;

	@FindBy(xpath = "//*[@class='newsStandText']")
	public WebElement Rwdnewstext;

	@FindBy(xpath = "//*[@class='insight-item ng-star-inserted']")
	public List<WebElement> RwdInsights;

	@FindBy(xpath = "//*[@class='insight-item-main avg-read watch-goal']")
	public By RwdInsightsread;

	@FindBy(xpath = "//*[@class='insight-item-main avg-listener']")
	public WebElement RwdInsightslistener;

	@FindBy(xpath = "//*[@class='insight-item-main current-streak watch-goal']")
	public WebElement RwdInsightsstreakwatch;

	@FindBy(xpath = "//*[@class='insight-item-main yearly-insight watch-goal']")
	public WebElement RwdyearlyWatch;

	@FindBy(xpath = "//*[@aria-label='Open profile options window']")
	public static WebElement menu_profileIcon;

	@FindBy(xpath = "//input[@id='searchInput']")
	public WebElement txt_SearchInput;
}
