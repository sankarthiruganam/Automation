package com.pom_RWD;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

import org.testng.Assert;

public class RWD_Drop4_ULP extends CapabilitiesAndWebDriverUtils{
	private static final Logger logger = LogManager.getLogger();
	static ExcelReader reader = new ExcelReader();
	Rwd_RC rc = new Rwd_RC();

	public RWD_Drop4_ULP() {
		PageFactory.initElements(driver, this);
	}
	
	public void homepageValidation() throws IOException {
		Screenshots.takeScreenshot(driver, "Screenshots/DestinyDiscover/Home.png");
		WaitForWebElement(HomeMenu);
		waitFor(8000);
	}
	
	public void headerValidaion() {
		Assert.assertEquals(ElementisPresent(globalHeader), true);
		logger.info("User able to view the global header #Pass");
	}
	
	public void headerMenuValidation() {
		Assert.assertEquals(ElementisPresent(headerLogo), true);
		logger.info("User able to view the header logo #Pass");
		
		Assert.assertEquals(ElementisPresent(headerText1), true);
		logger.info("User able to view the header title1 #Pass");
		
		Assert.assertEquals(ElementisPresent(headerText2), true);
		logger.info("User able to view the header title2 #Pass");
		
		Assert.assertEquals(ElementisPresent(HomeMenu), true);
		logger.info("User able to view the home menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(MyStuffMenu), true);
		logger.info("User able to view the mystuff menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(BookClubMenu), true);
		logger.info("User able to view the bookclub menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(DiscoverMenu), true);
		logger.info("User able to view the discover menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(CollectionsMenu), true);
		logger.info("User able to view the collection menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(MoreMenu), true);
		logger.info("User able to view the more menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(messageCenterMenu), true);
		logger.info("User able to view the message centre menu in header #Pass");
		
		Assert.assertEquals(ElementisPresent(SearchMenu), true);
		logger.info("User able to view the Search menu in header #Pass");
	}
	
	public void logoValidation() {
		jsClick(headerLogo);
		logger.info("Clicked on Destiny Discover logo #Pass");
		WaitForWebElement(headerLogo);
		waitFor(4000);
		Assert.assertTrue(ElementisPresent(ActiveHome), "Home menu is not enabled #Fail");
		logger.info("Navigated to Home screen #Pass");
	}
	
	public void globalMenuValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Drop4");
		if(Menu.size()>0) {
			System.out.println(Menu.size());
			for(int i=0;i<=Menu.size();i++) {
				Assert.assertEquals(Menu.get(i).getText().contains(testData.get(i).get("MenuName")), true);
				logger.info(Menu.get(i).getText()+" menu is present #Pass");
				ClickOnWebElement(Menu.get(i));
				logger.info("Clicked on "+Menu.get(i).getText()+" menu #Pass");
				if(Menu.get(i).getText().contains("My Stuff")) {
					ClickOnWebElement(btn_checkout);
				}
				if(Menu.get(i).getText().contains("My Stuff") || Menu.get(i).getText().contains("Book Club") || Menu.get(i).getText().contains("Discover") || Menu.get(i).getText().contains("Collections") || Menu.get(i).getText().contains("More")) {
					WaitForWebElement(breadCrumb);
					waitFor(8000);
					Assert.assertEquals(breadCrumb.getText().equalsIgnoreCase(testData.get(i).get("MenuName")), true);
					logger.info("Navigated to "+breadCrumb.getText()+" page #Pass");
				}
			}
		}
	}
	
	public void Messagecenter() throws IOException {
		waitFor(7000);
		if (ElementisPresent(rc.msgNotificationCount)) {
			Assert.assertTrue(rc.msgNotificationCount.isEnabled());
			logger.info("Message Center Bell icon Displayed #Pass");
		} else {
			logger.info("Message Center Bell icon Not Displayed");
		}
		ClickOnWebElement(messageCenterMenu);
		if (ElementisPresent(rc.RWDnoMessages)) {
			logger.info("Login into message Center! You have No Messages! #Pass");
			ClickOnWebElement(rc.msgclose);
		} else if(rc.msgHeader.size()>0) {
			Assert.assertTrue(ElementisPresent(rc.msgHeader.get(1)), "Messsages not displayed #Fail");
			logger.info("Notifications/Messages are displayed #Pass");
			ClickOnWebElement(rc.msgclose);
		}
	}
	
	public void insightValidation() {
		Assert.assertTrue(ElementisPresent(insight_header),"Insight header is not displayed #Fail");
		logger.info("Insights header is dispalyed #Pass");
		if(insights.size()>0 && insights.size()<=5) {
			for(int i=0;i<=insights.size()-1;i++) {
				logger.info(insightNames.get(i).getText()+" Insight is displayed #Pass");
				Assert.assertTrue(ElementisPresent(insightdetails.get(i)), "Insight details are not present for "+insightNames.get(i).getText());
				logger.info("Insight details are present for "+insightNames.get(i).getText());
			}
		}else {
			logger.info("Insights are not displayed #Fail");
		}
	}
	
	public void badgesValidation() throws IOException {
		waitFor(4000);
		if (ElementisPresent(Rwdbadges)) {
			Assert.assertEquals(Rwdbadges.isDisplayed(), true);
			logger.info("Badges Header is displayed #Pass");
			if(list_Badges.size()>=0) {
				logger.info(list_Badges.size()+": List of badges are displayed #Pass");
			}
		} else {
			logger.info("Badges header is not displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}
	}
	public void badgeSeeAllvalidation() throws IOException {
		if (ElementisPresent(Rwdbadges)) {
			if(list_Badges.size()>=0) {
				Assert.assertTrue(ElementisPresent(badgesSeeAll), "See all button for badges is not displayed #Fail");
				logger.info("See All button is enabled and displayed for Badges #Pass");
				Assert.assertTrue(ElementisPresent(badgesSeeAll), "See all for badges is not displayed #Fail");
				ClickOnWebElement(badgesSeeAll);
				logger.info("SeeAll button is clicked #Pass");
				WaitForWebElement(badges_Popup);
				logger.info("Badges popup and "+list_Badges.size()+": no of badges displayed #Pass");
				Assert.assertTrue(ElementisPresent(badges_Popup_close));
				ClickOnWebElement(badges_Popup_close);
				logger.info("Badges pop-up closed #Pass");
				WaitForWebElement(ActiveHome);
			}
			else {
				logger.info(list_Badges.size()+" No badges displayed");
			}
		} else {
			logger.info("Badges header is not displayed #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/badges/Nobadges.png");
		}
	}
	public void newsWidgetValidation() {
		Assert.assertTrue(ElementisPresent(newsWidget), "News and Announcement widget is not displayed #Fail");
		logger.info("News and Announcement widget is displayed #Pass");
		Assert.assertTrue(ElementisPresent(newsWidget_header), "News and Announcement header is not displayed #Fail");
		logger.info("News and Announcement header is displayed #Pass");
		
	}
	
	public void RP_RC_details(boolean image,boolean name, boolean progress) {
		if(RP_RC.size()>0) {
			for (int i=0; i<=RP_RC.size()-1; i++) {
				if(image == true) {
					Assert.assertTrue(ElementisPresent(RP_RC_image.get(i)));
					logger.info(i+" :Reading program and Challenges title image is displayed for all the items #Pass");
					break;
				}
				if(name == true) {
					Assert.assertTrue(ElementisPresent(RP_RC_name.get(i)));
					logger.info(i+" :Reading program and Challenges name is displayed for all the items #Pass");
					break;
				}
				if(progress= true) {
					// progress bar is not showing for all the items in this carousel
					//Assert.assertTrue(ElementisPresent(RP_RC_progress.get(i)));
					//logger.info("Reading program and Challenges progress bar is displayed for all the items #Pass");
				} 
			}
		}
	}
	
	public void RP_RC_SeeAll() {
		Assert.assertTrue(ElementisPresent(seeAll_RP_RC), "See All button is not displayed #Fail");
		logger.info("See All button is displayed #Pass");
		ClickOnWebElement(seeAll_RP_RC);
		WaitForWebElement(Active_bookClub);
		Assert.assertTrue(ElementisPresent(Active_bookClub), "Not Navigated to book club menu #Fail");
		logger.info("Navigated to book club landing page #Pass");
	}
	
	public void customCarouselValidation() {
		ClickOnWebElement(HomeMenu);
		WaitForWebElement(ActiveHome);
		waitFor(5000);
		javascriptScroll(seeAll_RP_RC);
		Assert.assertTrue(ElementisPresent(customCarousel_Header), "Custom Carousel Header is not available #Fail");
		logger.info("Custom Carousel Header is available #Pass");
		Assert.assertTrue(ElementisPresent(customCarousel_SeeAll), "Custom Carousel SeeAll button is not available #Fail");
		logger.info("Custom Carousel SeeAll button is available #Pass");
		
	}
	
	public void recommendationCarouselValidation() {
		javascriptScroll(customCarousel_Header);
		Assert.assertTrue(ElementisPresent(RecommendationCarousel_Header), "Recommendation Carousel Header is not available #Fail");
		logger.info("Recommendation Carousel Header is available #Pass");
		Assert.assertTrue(ElementisPresent(RecommendationCarousel_SeeAll), "Recommendation Carousel SeeAll button is not available #Fail");
		logger.info("Recommendation Carousel SeeAll button is available #Pass");
	}
	
	public void footerValidation() {
		javascriptScroll(footer);
		Assert.assertTrue(ElementisPresent(footer),"Footer is not displayed #Fail");
		logger.info("Footer is present #Pass");
	}
	
	public void discoverValidation() {
		WaitForWebElement(DiscoverMenu);
		ClickOnWebElement(DiscoverMenu);
		WaitForWebElement(breadCrumb);
		Assert.assertTrue(ElementisPresent(Active_Discover),"Discover page is highlighted #Fail");
		logger.info("Discover page is opened and highlighted #Pass");
	}
	
	public void carouselSeeAllValidation() {
		int Carousel =Carousel_List.size();
		if(Carousel>0) {
			for(int i=0;i<Carousel-1;i++) {
				waitFor(4000);
				WaitForWebElement(Carousel_List.get(i));
			//	String CarouselName = Carousel_List.get(i).getText();
				if(Carousel_List.get(i).getText().equalsIgnoreCase("Popular Titles")) {
					logger.info("See All button is not available for Popular Titles carousel");
				}else {
					logger.info(Carousel_List.get(i).getText()+" :See All button is clicked #Pass");
					ClickOnWebElement(SeeAll_List.get(i));
					waitFor(8000);
					if(breadCrumb.getText().equalsIgnoreCase("Collections")) {
						Assert.assertTrue(breadCrumb.getText().equalsIgnoreCase("Collections"));
						logger.info(breadCrumb.getText()+" BreadCrumb text");
						ClickOnWebElement(discover);
						WaitForWebElement(Active_Discover);
						logger.info("Back to Discover page #Pass");
					}else {
						WaitForWebElement(breadCrumb1);
						logger.info(breadCrumb1.getText()+" BreadCrumb text");
			//			Assert.assertTrue(breadCrumb1.getText().equalsIgnoreCase(CarouselName),"Navigated to wrong landing page #Fail");
						ClickOnWebElement(DiscoverMenu);
						WaitForWebElement(Active_Discover);
						logger.info("Back to Discover page #Pass");
					}
				}
			}
		}
	}
	
	public void salutationValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "Drop4");
		ClickOnWebElement(HomeMenu);
		waitFor(3000);
		WaitForWebElement(ActiveHome);
		Assert.assertTrue(ElementisPresent(toolbar_welcome_txt), "Salutation text is not present in toolbar #Fail");
		logger.info("Salutation text is present in toolbar #Pass");
		
		String user = toolbar_welcome_txt.getText().substring(14,18);
		System.out.println(user+":User name");
		Assert.assertTrue(user.equalsIgnoreCase(testData.get(0).get("UserName")),"logged in user is not matched #Fail");
		logger.info(toolbar_welcome_txt.getText()+" logged in user is matched #Pass");
	}
	
	public void moreMenuValidation() {
		ClickOnWebElement(HomeMenu);
		waitFor(3000);
		WaitForWebElement(ActiveHome);
		ClickOnWebElement(MoreMenu);
		waitFor(1000);
		Assert.assertTrue(ElementisPresent(More_list),"More menu options are not displayed #Fail");
		logger.info("More menu Options are displayed #Pass");
	}
	
	public void moreOptionsValidation() {
		Assert.assertTrue(ElementisPresent(More_backOfc),"More menu-BackOffice option is not displayed #Fail");
		logger.info("More menu-BackOffice option is displayed #Pass");
		
		Assert.assertTrue(ElementisPresent(More_help),"More menu-help option is not displayed #Fail");
		logger.info("More menu-help option is displayed #Pass");
	}
	
	public void moreMenuLandingValidation() {
		ClickOnWebElement(More_backOfc);
		WaitForWebElement(backofc_DD);
		Assert.assertTrue(ElementisPresent(backofc_DD),"Back Office page is not opened #Fail");
		logger.info("Back Office page is opened #Pass");
		ClickOnWebElement(backofc_DD);
		WaitForWebElement(ActiveHome);
		waitFor(3000);
		
	}
	@FindBy(xpath="//span[text()='Destiny Discover']")
	public WebElement backofc_DD;
	
	@FindBy(id="head-menu-mob-help")
	public WebElement More_help;
	
	@FindBy(id="hdmen-more-back")
	public WebElement More_backOfc;
	
	@FindBy(id="mat-menu-panel-0")
	public WebElement More_list;
	
	@FindBy(id="head-menu-list-discv")
	public WebElement discover;
	
	@FindBy(xpath="//div[@class='fss-ms-header-std']/mat-toolbar/div/span[contains(text(),'Welcome back')]")
	public WebElement toolbar_welcome_txt;
	
	@FindBy(xpath = "//*[@class='title-carousel']/div/a[text()=' SEE ALL ']")
	public List<WebElement> SeeAll_List;
	
	@FindBy(xpath = "//*[@class='title-carousel']/div/h3")
	public List<WebElement> Carousel_List;
	
	@FindBy(xpath="//*[@class='spanmenu active' and @id='head-menu-list-discv']")
	public WebElement Active_Discover;
	
	@FindBy(xpath = "//p[text()='© 2021 Follett School Solutions. All Rights Reserved.']")
	public WebElement footer;
	
	@FindBy(xpath="//*[@aria-label='See All , Based on your preference']")
	public WebElement RecommendationCarousel_SeeAll;
	
	@FindBy(xpath="//h3[text()='Based on your preference']")
	public WebElement RecommendationCarousel_Header;
	
	@FindBy(xpath="//*[@aria-label='See All , Non Engage Custom Crousal']")
	public WebElement customCarousel_SeeAll;
	
	@FindBy(xpath="//h3[text()='Non Engage Custom Crousal']")
	public WebElement customCarousel_Header;
	
	@FindBy(xpath="//*[@class='spanmenu active' and @id='head-menu-list-book']")
	public WebElement Active_bookClub;
	
	@FindBy(xpath="//h2[text()='Reading Programs and Challenges']")
	public WebElement RP_RC_Carousel_Header;
	
	@FindBy(xpath="//button[@class='achev-seeall-btn ng-star-inserted']")
	public WebElement seeAll_RP_RC;
	
	@FindBy(xpath="//*[@class='mat-card mat-focus-indicator trail-rc-section readerchallenge-program ng-star-inserted']")
	public List<WebElement> RP_RC;
	
	@FindBy(xpath="//*[@class='poster-backgrd trail-rc-banner']")
	public List<WebElement> RP_RC_image;
	
	@FindBy(xpath="//*[@class='trail-elip']")
	public List<WebElement> RP_RC_name;
	
	@FindBy(xpath = "//*[@class='news-banner']/h2")
	public WebElement newsWidget_header;
	
	@FindBy(xpath = "//*[@class='news-achev-main']")
	public WebElement newsWidget;
	
	@FindBy(xpath = "//*[@class='badge-popmain']/div/mat-icon")
	public WebElement badges_Popup_close;
	
	@FindBy(xpath = "//*[@class='badge-popmain']")
	public WebElement badges_Popup;
	
	@FindBy(xpath = "//*[@class='fss-badges-main']/div/button[text()=' SEE ALL ']")
	public WebElement badgesSeeAll;
	
	@FindBy(xpath ="//*[@class='badges-pref badges-desk']/div/div/div[@class='badges-widget ng-star-inserted']")
	public List<WebElement> list_Badges;
	
	@FindBy(xpath = "//h2[text()='Badges']")
	public WebElement Rwdbadges;
	
	@FindBy(xpath="//*[@class='insight-pref insightpref-desk']/div/div/fss-ms-insights/div/div[@class='widget-set']")
	public List<WebElement> insightdetails;
	
	@FindBy(xpath="//*[@class='insight-pref insightpref-desk']/div/div/fss-ms-insights/div/span[@class='widget-name ng-star-inserted']")
	public List<WebElement> insightNames;
	
	@FindBy(xpath="//div[@class='insight-pref insightpref-desk']/div/div/fss-ms-insights/div[@class='insight-widget']")
	public List<WebElement> insights;
	
	@FindBy(xpath="//h2[text()='Insights']")
	public WebElement insight_header;
	
	@FindBy(xpath="//*[text()=' Checkouts ']")
	public WebElement btn_checkout;
	
	@FindBy(xpath="//a[@class='navbar-brand hd-left']")
	public WebElement globalHeader;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/a/img")
	public WebElement headerLogo;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/a/span[1]")
	public WebElement headerText1;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/a/span[2]")
	public WebElement headerText2;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item")
	public List<WebElement> Menu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[1]")
	public WebElement HomeMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[2]")
	public WebElement MyStuffMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[3]")
	public WebElement BookClubMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[4]")
	public WebElement DiscoverMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[5]")
	public WebElement CollectionsMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[6]")
	public WebElement MoreMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/div/button[@class='msg-icon-button icon-bg mr-rgt ng-star-inserted']")
	public WebElement messageCenterMenu;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/div/button[@class='search-Icon-Button icon-bg']")
	public WebElement SearchMenu;
	
	@FindBy(xpath="//*[@class='spanmenu active' and @aria-label='home']")
	public WebElement ActiveHome;
	
	@FindBy(xpath="//*[@class='breadcrumb-item']")
	public WebElement breadCrumb;
	
	@FindBy(xpath="//*[@class='breadcrumb-item']/a")
	public WebElement breadCrumb1;
	
}
