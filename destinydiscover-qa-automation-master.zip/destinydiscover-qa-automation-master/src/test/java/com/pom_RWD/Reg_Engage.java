package com.pom_RWD;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

public class Reg_Engage extends CapabilitiesAndWebDriverUtils {

/*Class reference*/
	
	private static final Logger logger = LogManager.getLogger();
	static ExcelReader reader = new ExcelReader();
	RWD_RP_Smoke rp= new RWD_RP_Smoke();
	RWD_RP rp1= new RWD_RP();
	RWD_RC_Smoke rc = new RWD_RC_Smoke();
	Rwd_RC rc1 = new Rwd_RC();
	RWD_Drop4_ULP home = new RWD_Drop4_ULP();
	
/*Global Varialbles*/	
	
	static String progName; 
	public static String name1;
	public static String lastPrgName;
	static String unpublishPrg;
	static String chlngName;
	static int beforemsgCount;
	public static String updatedprogname;
/*	static String progName = "Automation_RP_"+ generateRandomNumber();
	public static String name = existing_RP_Name.getText();
*/
	
	public Reg_Engage() {
		PageFactory.initElements(driver, this);
	}
	
/********************************************Reusable Action Methods*************************************************/	
	
	public void Create_RP() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		logger.info("-- Create Program validation started--");
		ClickOnWebElement(rp.btn_createProgram);
		WaitForWebElement(rp.lbl_CreateProgrm);
		System.out.println(rp.lbl_CreateProgrm.getText());
		Assert.assertEquals(rp.lbl_CreateProgrm.getText(), testData.get(0).get("lbl_CreateProgram"));
		logger.info("Create program header is available #Pass");
	}
	
	public String RP_Name(String name) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		name1 = existing_RP_Name.getText();
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		System.out.println(name1);
		SendKeysOnWebElement(rp.inp_progName, name1);
		logger.info("Program name entered #Pass");
		return name1;
	}
	
	public String Enter_RP_Name(String name) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		SendKeysOnWebElement(rp.inp_progName, name);
		logger.info("Program name entered #Pass");
		return name;
	}
	
	public void mandatoryDetails() throws InvalidFormatException, IOException {
		rp.startDate();
		rp.endDate();
		rp.assignStudent();
		rp.addTitle();
	}
	
	public void publishRP() {
		Assert.assertEquals(ElementisPresent(rp.btn_publish), true);
		waitFor(1000);
		jsClick(rp.btn_publish);
		logger.info("Publish program button is available and clicked #Pass");
	}
	
	public void private_RP() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		Assert.assertEquals(rp.rb_private.getText(), testData.get(0).get("lbl_private"));
		logger.info("Private radio button is available #Pass");
		ClickOnWebElement(rp.rb_private);
		logger.info("Private radio button is clicked #Pass");
	}
	
	public void mandatory_Assertion() {
		Assert.assertTrue(ElementisPresent(req_progName));
		Assert.assertTrue(ElementisPresent(req_startDate));
		Assert.assertTrue(ElementisPresent(req_endDate));
		Assert.assertTrue(ElementisPresent(req_student));
		Assert.assertTrue(ElementisPresent(req_title));
		Assert.assertTrue(ElementisPresent(req_fields));
		logger.info("Mandatory field validations are in place for Private program #Pass");
		
	}
	
	public void failureMsgvalidation() {
		System.out.println("Inside failure msg validation");
		if(ElementisPresent(rp1.failureMsg)) {
			logger.info("Failure message is displayed #Pass");
			Assert.assertEquals(ElementisPresent(rp1.failureMsg),true);
		}
		else if(ElementisPresent(rp1.successMsg)) {
			logger.info("Success message is displayed #Fail");
			Assert.assertEquals(ElementisPresent(rp1.failureMsg),true);
		}
	}
	public void pastStartDate() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		waitFor(3000);
		javascriptScroll(rp.btn_startDate);
		ClickOnWebElement(rp.btn_startDate);
		logger.info("Start date calander is opened #Pass");
		waitFor(1000);
		String startDate = testData.get(1).get("Startdate");
	//	ElementisPresent(driver.findElement(By.xpath("//div[text()=' " + startDate + " ']/parent::td[@aria-disabled='true']")));
		logger.info("Past date for the RP Start date is disabled #Pass");
	}
	
	public void pastEndDate() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		waitFor(3000);
		javascriptScroll(rp.btn_startDate);
		ClickOnWebElement(rp.btn_startDate);
		waitFor(1000);
		String startDate = testData.get(0).get("Startdate");
		WebElement sd = driver.findElement(By.xpath("//div[text()=' " + startDate + " ']"));
		jsClick(sd);
		ClickOnWebElement(rp.btn_endDate);
		logger.info("End date calander is opened #Pass");
		waitFor(1000);
		String endDate = testData.get(1).get("EndDate");
	//	ElementisPresent(driver.findElement(By.xpath("//div[text()=' " + endDate + " ']/parent::td[@aria-disabled='true']")));
		logger.info("Past date for the RP End date is disabled #Pass");
	}
	
	public void programSearch(String progName) {
		for (int i = 0; i <= 5; i++) {
			waitFor(3000);
			javaScriptScrollToEnd();
			waitFor(3000);
			javascriptScroll(rp.lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javaScriptScrollToEnd();
				//javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javaScriptScrollToEnd();
				//javascriptScroll(footer);
				waitFor(2000);
			}
		}
	}
	
	public void programSearch() {
		for (int i = 0; i <= 13; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_Activeprogram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
		logger.info(ss.getText() + " is found in My Program listing screen and opened #Pass");
		jsClick(ss);
	}
	
	public String duplicateProgram() throws IOException {
		waitFor(18000);
//		Assert.assertEquals(ElementisPresent(Rwdduplicateprg), true);
		logger.info("Duplicate program button available #Pass");
		jsClick(Rwdduplicateprg);
		waitFor(6000);
		Assert.assertEquals(Rwddublicatescreen.getText().trim(), "Create Reading Program");
		logger.info("User able to navigated to the Duplicate Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingProgram/duplicateProgram.png");
		waitFor(3000);
		lastPrgName = rp.inp_progName.getText();
		SendKeysOnWebElement(rp.inp_progName, progName+"duplicate");
		WaitForWebElement(rp.btn_publish);
		ClickOnWebElement(rp.btn_publish);
		return lastPrgName;
		}
	
	public void navigatetoProgram() throws IOException {
		System.out.println("Searsch------->"+progName);
		programSearch();
		waitFor(8000);
		Assert.assertEquals(ElementisPresent(Rwdeditprg), true);
		logger.info("Edit Program button available #Pass");
		jsClick(Rwdeditprg);
		waitFor(1000);
		logger.info("User able to navigated to the Edit Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingProgram/editProgram.png");
	}
	
	public void addsameStudent() throws IOException {
		waitFor(2000);
		jsClick(rp.btn_addfriendprg);
		jsClick(txt_SearchStudentName);
		SendKeysOnWebElement(txt_SearchStudentName, "ams");
		waitFor(18000);
		rp.btn_InviteFriendLists.get(1).click();
		jsClick(rp.btn_InviteToPrgrm);
		logger.info("Verify User is not able to add same Student more than once #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/program/addsameStudent.png");
	}

	public void addStudent() throws IOException {
		waitFor(2000);
		jsClick(rp.btn_addfriendprg);
		jsClick(txt_SearchStudentName);
		SendKeysOnWebElement(txt_SearchStudentName, "ams5");
		waitFor(4000);
		rp.btn_InviteFriendLists.get(0).click();
		jsClick(rp.btn_InviteToPrgrm);
		logger.info("Verify User is not able to add same Student more than once #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/program/addsameStudent.png");
	}
	
	public void removeStudent() {
		waitFor(3000);
		javascriptScroll(rp.RWDsetReminder);
		waitFor(1000);
		btn_addedStudents.get(0).click();
		logger.info("try to Remove Student #Pass");
		waitFor(2000);
		Assert.assertEquals(removeconfirm.isDisplayed(), true);
		ClickOnWebElement(removeconfirm);
		logger.info("Verify User is able to Remove the student from RP #Pass");
		
	}
	
	public void addsameTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Add title assertion started--");
		jsClick(rp.btn_AddTitle);
		WaitForWebElement(rp.txt_SearchInput);
		logger.info("Title search header is available #Pass");
		SendKeysOnWebElement(rp.txt_SearchInput, testData1.get(0).get("titleName"));
		waitFor(5000);
		SendKeysEnter(rp.txt_SearchInput);
		waitFor(1000);
		WaitForWebElement(rp.RWDMoreMenu);
		jsClick(rp.RWDMoreMenu);
		Assert.assertEquals(ElementisPresent(rp.AddToprgrmTitle),false);
		logger.info("Verify User is not able to add same Title more than once #Pass");
	}

	public void addTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Add title assertion started--");
		jsClick(rp.btn_AddTitle);
		WaitForWebElement(rp.txt_SearchInput);
		logger.info("Title search header is available #Pass");
		SendKeysOnWebElement(rp.txt_SearchInput, testData1.get(0).get("titleName"));
		waitFor(5000);
		SendKeysEnter(rp.txt_SearchInput);
		waitFor(1000);
		WaitForWebElement(rp.RWDMoreMenu);
		jsClick(rp.RWDMoreMenu);
		waitFor(7000);
		jsClick(AddToprgrmTitle);
		logger.info("Verify User is not able to add same Title more than once #Pass");
	}

	public void removeTitle() {
        waitFor(2000);
        javascriptScroll(rp.RWDsetReminder);
        if(removeTitle.isEnabled())
        {
        ClickOnWebElement(removeTitle);    
        }
        waitFor(3000);
        ClickOnWebElement(removeconfirm);
        logger.info("Verify User is able to Remove the Title from RP #Pass");
    }

	
	public void addTitlefromCheckout() {
		
		waitFor(3000);
		ClickOnWebElement(mystuffmenu);
		waitFor(1000);
		ClickOnWebElement(Checkouts);
		waitFor(3000);
		if(ElementisPresent(notitleCheckout))
		{
			logger.info("No title are avilable to add program");
		}else
		{
			waitFor(3000);
			WaitForWebElement(rp.RWDMoreMenu);
			jsClick(rp.RWDMoreMenu);
			waitFor(1000);
			ClickOnWebElement(includeNewprg);
			waitFor(1000);
			Assert.assertEquals(rp.lbl_CreateProgrm.isDisplayed(), true);
			logger.info("add titles in new program from mystuff checkout page #Pass");
			ClickOnWebElement(btn_close);
				
		}
	}
	
	public void addTitlefromhistory() {
		waitFor(3000);
		ClickOnWebElement(mystuffmenu);
		waitFor(1000);
		ClickOnWebElement(History);
		waitFor(3000);
		if(ElementisPresent(notitlehistory))
		{
			logger.info("No title are avilable to add program");
		}else
		{
			WaitForWebElement(rp.RWDMoreMenu);
			jsClick(rp.RWDMoreMenu);
			waitFor(1000);
			ClickOnWebElement(includeNewprg);
			waitFor(1000);
			Assert.assertEquals(rp.lbl_CreateProgrm.isDisplayed(), true);
			logger.info("add titles in new program from history checkout page #Pass");
			ClickOnWebElement(btn_close);	
		}	
	}
	
	public void addTitlefromholds() {
		waitFor(3000);
		ClickOnWebElement(mystuffmenu);
		waitFor(1000);
		ClickOnWebElement(Holds);
		waitFor(3000);
		if(ElementisPresent(notitleholds))
		{
			logger.info("No title are avilable to add program");
		}else
		{
			WaitForWebElement(rp.RWDMoreMenu);
			jsClick(rp.RWDMoreMenu);
			waitFor(1000);
			ClickOnWebElement(includeNewprg);
			waitFor(1000);
			Assert.assertEquals(rp.lbl_CreateProgrm.isDisplayed(), true);
			logger.info("add titles in new program from holds checkout page #Pass");
			ClickOnWebElement(btn_close);
		}
	}
	
	public void addTitlefromfavorite() {
		waitFor(3000);
		ClickOnWebElement(mystuffmenu);
		waitFor(1000);
		ClickOnWebElement(Favorites);
		waitFor(3000);
		if(ElementisPresent(notitleFavorites))
		{
			logger.info("No title are avilable to add program");
		}else
		{
			
			WaitForWebElement(rp.RWDMoreMenu);
			waitFor(3000);
			jsClick(rp.RWDMoreMenu);
			waitFor(1000);
			ClickOnWebElement(includeNewprg);
			waitFor(1000);
			Assert.assertEquals(rp.lbl_CreateProgrm.isDisplayed(), true);
			logger.info("add titles in new program from favorite checkout page #Pass");
			ClickOnWebElement(btn_close);
		}		
	}
	
	public void addTitlefromfines() {
		waitFor(3000);
		ClickOnWebElement(mystuffmenu);
		waitFor(1000);
		ClickOnWebElement(Fines);
		waitFor(3000);
		if(ElementisPresent(notitlefines))
		{
			logger.info("No title are avilable to add program");
		}else
		{
			WaitForWebElement(rp.RWDMoreMenu);
			jsClick(rp.RWDMoreMenu);
			waitFor(1000);
			ClickOnWebElement(includeNewprg);
			waitFor(1000);
			Assert.assertEquals(rp.lbl_CreateProgrm.isDisplayed(), true);
			logger.info("add titles in new program from fines checkout page #Pass");
			ClickOnWebElement(btn_close);
		}
	}
	
	public void discoverPageNavigation() throws IOException {
		ClickOnWebElement(RWD_discoverPage);
		WaitForWebElement(RWD_discoverBreadCrum);
		logger.info(getData("platformName")+" - User Navigated to discover Page");
		Screenshots.takeScreenshot(driver, "Screenshots/DiscoverPage/discoverPage.png");
	}

	public  void homePageNavigation() throws IOException {	
		home.logoValidation();
		home.homepageValidation();
	}
	
	public void addTitleFromDiscoverPage() throws IOException {
		
		waitFor(5000);
        for (int i = 0; i<=RWD_MoreIcon.size()-1; i++) {
            try {
                jsClick(RWD_MoreIcon.get(i));
                ClickOnWebElement(includeNewprg);
                logger.info(getData("platformName")+" - User Clicked on Include in new program option in Discover Page");
                break;
            } catch (Exception e) {
                logger.info(getData("platformName")+" - Add to new program option is not available for this title");
            }
        }
//		jsClick(RWD_MoreIcon.get(15));
//		waitFor(1000);
//		jsClick(includeNewprg);
//		logger.info(getData("platformName")+" - User Clicked on Include in new prg option in Discover Page");
        waitFor(3000);
		WaitForWebElement(rp.lbl_CreateProgrm);
		Assert.assertTrue(rp.lbl_CreateProgrm.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Program Screen");
		waitFor(2000);
		javascriptScroll(rp.RWDsetReminder);
		waitFor(3000);
		Assert.assertTrue(RWD_addedTitle.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/DiscoverPage/AddNewTitle.png");
		waitFor(3000);
	}
	
	public void addTitleFromHomePage() throws IOException {
		
		javascriptScroll(basedOnPrefCarousel);
//      WaitForWebElement(homePageMoreIcon);
      for (int i = 0; i<=homePageMoreIcon.size()-1; i++) {
          try {
              jsClick(homePageMoreIcon.get(i));
              jsClick(includeNewprg);
              logger.info(getData("platformName")+" - User Clicked on Include in new Challenge option in Home Page");
              break;
          } catch (Exception e) {

          }
      }
		logger.info(getData("platformName")+" - User Clicked on Include in new prg option in Home Page");
		WaitForWebElement(rp.lbl_CreateProgrm);
		Assert.assertTrue(rp.lbl_CreateProgrm.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Program Screen");
		waitFor(3000);
		javascriptScroll(rp.RWDsetReminder);
		waitFor(3000);
		Assert.assertTrue(RWD_addedTitle.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/HomePage/AddNewTitle.png");
		waitFor(3000);

	}
	
	public void searchPageNavigation() throws IOException {
		WaitForWebElement(home.HomeMenu);
		ClickOnWebElement(home.SearchMenu);
		WaitForWebElement(searchPageHeader);
		Assert.assertTrue(searchPageHeader.isDisplayed());
		logger.info(getData("platformName")+" - User able to Navigate to Search Page #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/SearchPage/SearchPage.png");
	}
	
	public void addTitleFromSearchPage() throws IOException {
		ClickOnWebElement(RWD_MoreIcon.get(0));
		ClickOnWebElement(includeNewprg);
		logger.info(getData("platformName")+" - User Clicked on Include in new prg option in Search Page");
		WaitForWebElement(rp.lbl_CreateProgrm);
		Assert.assertTrue(rp.lbl_CreateProgrm.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Program Screen");
		javascriptScroll(rp.RWDsetReminder);
		Assert.assertTrue(RWD_addedTitle.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/SearchPage/AddNewTitle.png");
		waitFor(3000);
	}
	
	public void searchResultNavigation() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		searchPageNavigation();
		SendKeysOnWebElement(rp.txt_SearchInput, testData1.get(0).get("titleName"));
		waitFor(5000);
		Screenshots.takeScreenshot(driver,"Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_SuggestedResult.png");
		logger.info("Suggested result header is available #Pass");
		SendKeysEnter(rp.txt_SearchInput);
		waitFor(5000);
	}
	
	public void addTitleFromSearchResultPage() throws IOException {
		javascriptScroll(RWD_MoreIcon.get(0));
		ClickOnWebElement(RWD_MoreIcon.get(0));
		ClickOnWebElement(includeNewprg);
		logger.info(getData("platformName")+" - User Clicked on Include in new prg option in Search Result Page");
		WaitForWebElement(rp.lbl_CreateProgrm);
		Assert.assertTrue(rp.lbl_CreateProgrm.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Program Screen");
		javascriptScroll(rp.RWDsetReminder);
		Assert.assertTrue(RWD_addedTitle.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Program Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/SearchPage/AddNewTitle.png");
		waitFor(3000);
	}
	
	//_____________Saranya_______
	
	
	//______________sakthi_______________
	
	public String createPublicProgramType(int num,boolean progType, boolean access, boolean multiStud, boolean multiTitle, boolean save) throws Exception {
		FileInputStream fis = new FileInputStream(ConfigurationFile);
		Properties prop = new Properties();
		prop.load(fis);
		progName = "Automation_RP_"+ generateRandomNumber();
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		logger.info("-- Create Program validation started--");
		ClickOnWebElement(rp.btn_createProgram);
		WaitForWebElement(rp.lbl_CreateProgrm);
		System.out.println(rp.lbl_CreateProgrm.getText());
		Assert.assertEquals(rp.lbl_CreateProgrm.getText(), testData.get(0).get("lbl_CreateProgram"));
		logger.info("Create program header is available #Pass");
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		SendKeysOnWebElement(rp.inp_progName, progName);
		logger.info("Program name entered #Pass");
		Assert.assertEquals(rp.lbl_progDesc.getText(), testData.get(0).get("lbl_progDescTxt"));
		logger.info("Program Description text box is available #Pass");
		SendKeysOnWebElement(rp.inp_progDesc, testData.get(0).get("progDesc"));
		logger.info("Program Description entered #Pass");
		
		if(access == true) {
			logger.info("Public radio button is available #Pass");
			ClickOnWebElement(rp.rb_public);
			logger.info("Public radio button is clicked #Pass");
		}
		else if(access == false) {
			logger.info("Private radio button is available #Pass");
			ClickOnWebElement(rp.rb_private);
			logger.info("private radio button is clicked #Pass");
		}
		
		if(progType==true) {
			setProgTypeXofY();
		}
		else if(progType==false) {
			setProgTypeBooksInOrder();
		}
		
		rp.startDate();
		rp.endDate();
		logger.info("Set Remainder text box is available #Pass");
		rp.setRemainder();
		waitFor(1000);
		if(multiStud == true) {
			ClickOnWebElement(rp.btn_addfriendprg);
			ClickOnWebElement(txt_SearchStudentName);
			if(prop.getProperty("Env").equalsIgnoreCase("QAT")) {
			SendKeysOnWebElement(txt_SearchStudentName, testData.get(3).get("studentName"));
			}else
			{
			SendKeysOnWebElement(txt_SearchStudentName, testData.get(2).get("studentName"));	
			}
//			SendKeysEnter(txt_SearchStudentName);
			logger.info("Entered student name in search box #Pass");
			rc1.addMultipleStudent(num);
			jsClick(rp.btn_InviteToPrgrm);
			waitFor(3000);
		}
		else if(multiStud == false) {
			rp.assignStudent();
		}
		
		logger.info("Add title header is available is available #Pass");
		if(multiTitle == true) {
			addMultipleTitle();
		}
		else if(multiTitle ==  false) {
			rp.addTitle();
		}
		waitFor(3000);
		if(save==true) {
			Assert.assertEquals(ElementisPresent(rp.btn_save), true);
			ClickOnWebElement(rp.btn_save);
			logger.info("Save button is available and clicked #Pass");
			WaitForWebElement(rp.lbl_ActiveChallenge);
			waitFor(5000);
		}else if(save==false) {
			Assert.assertEquals(ElementisPresent(rp.btn_publish), true);
			ClickOnWebElement(rp.btn_publish);
			logger.info("Public program x of y created #Pass");
			WaitForWebElement(rp.lbl_myPrograms);
		}
		return progName;
	}
	
	public void pagination_validation() {
		javascriptScroll(rp.lbl_participantlist);
		if(participantList.size()>=9) {
			Assert.assertTrue(ElementisPresent(paginator),"Paginator is not displayed #Fail");
			logger.info("Participant list is more than 10 so pagination is displayed #Pass");
		}
		else {
			Assert.assertTrue(participantList.size()>=9,"Participants is less than 10 #Fail");
			logger.info("Participant list is less than 10 so pagination is not displayed #Fail");
		}
	}
	public void students_Progress_metrics() {
		WaitForWebElement(rp.lbl_participantlist);
		javascriptScroll(rp.lbl_participantlist);
		for(int i=0; i<=participantList.size(); i++) {
			/*
			 * System.out.println("Paricipant list: "+participantList.size());
			 * System.out.println("book progress list: "+Book_progressList.size());
			 * System.out.println("total progress list: "+total_progressList.size());
			 */
			if(participantList.size()==Book_progressList.size()) {
				Assert.assertEquals(participantList.size(),Book_progressList.size(),"Particular book Progress not available #Fail");
				if(Book_progressList.size()==total_progressList.size()) {
					Assert.assertEquals(Book_progressList.size(),total_progressList.size(),"Total progress is not available for particular student #Fail");
					if(total_progressList.size()==participantList.size()){
						Assert.assertEquals(total_progressList.size(),participantList.size(),"Participant list and Total progress list is not equal #Fail");
						logger.info("list of students along with their progress metrics is displayed #Pass");
						break;
					}
					else {
						Assert.assertEquals(total_progressList.size(),participantList.size(),"Participant list and Total progress list is not equal #Fail");
					}
				}
				else {
					Assert.assertEquals(Book_progressList.size(),total_progressList.size(),"Total progress is not available for particular student #Fail");
				}
			}
			else {
				Assert.assertEquals(participantList.size(),Book_progressList.size(),"Particular book Progress not available #Fail");
			}
		}
	}
	
	public void max_students(Integer num) {
		if(participantList.size()>=num) {
			logger.info("User able to view "+participantList.size()+" students listed at a time ");
		}
	}
	
	public void navigate_right() {
		ClickOnWebElement(paginator_right);
		waitFor(5000);
		Assert.assertTrue(participantList.size()>0,"Participant list is not displayed in next page #Fail");
		logger.info("User able to view rest of the students #Pass");
	}
	
	public void programSearch_diff_Admin() {
		for (int i = 0; i <= 9; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(rp.lbl_ActiveProgram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		try {
			Assert.assertFalse(ElementisPresent(driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"))));
		} catch (NoSuchElementException e) {
			logger.info("First admin created program is not displayed for another admin #Pass");
		}
	}
	
	public void active_prog_validation() {
		for(int i=0; i<ActiveProg_name.size(); i++) {
			if(ActiveProg_name.get(i).getText().equalsIgnoreCase(progName)) {
				Assert.assertEquals(ActiveProg_name.get(i).getText(), progName,"Published program is not present under Active program #Fail");
				logger.info("Published program present under Active program for the participant #Pass");
			}
		}
	}
	
	public void LoginAsInvitedUser() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		String username= testData.get(0).get("studentName");
		String password= testData.get(0).get("studentName");
		logger.info("-- Login Web Page Validation Start --");
		waitFor(5000);
		WaitForWebElement(Login_RWD.menu_Login);
		logger.info("Login Button is displayed #Pass");
		waitFor(5000);
		waitForElementClick(Login_RWD.menu_Login);
		waitFor(5000);
		SendKeysOnWebElement(Login_RWD.userName, username);
		SendKeysOnWebElement(Login_RWD.Password, password);
		logger.info("Username and password entered #Pass");
		ClickOnWebElement(Login_RWD.RWD_DLX_Submit);
		logger.info("Successfully Logged in as: " + username +"#Pass");
		WaitForWebElement(Login_RWD.menu_SignedInUser);
		logger.info("-- Login Web Page Validation End --");

	    }
	
	public void noAction() {
		WaitForWebElement(chlgName);
		Assert.assertEquals(chlgName.getText(), RWD_RC_Smoke.chlngName);
		ClickOnWebElement(btn_noAction);
		WaitForWebElement(Rwd_RC.RWDaddCTAWeb);
	}
	
	public void delete_Report() {
		WaitForWebElement(chlgName);
		Assert.assertEquals(chlgName.getText(), RWD_RC_Smoke.chlngName);
		ClickOnWebElement(btn_delete);
		WaitForWebElement(Rwd_RC.RWDaddCTAWeb);
	}	
	
	@FindBy(id="accept-btn")
	public WebElement btn_delete;
	
	@FindBy(xpath="//*[text()='No Action Needed']")
	public WebElement btn_noAction;
	
	@FindBy(xpath="//*[@class='mat-card-subtitle challenge-name']")
	public WebElement chlgName;

	@FindBy(xpath="//tr[@class='ng-star-inserted']/td[3]")
	public List<WebElement> total_progressList;
	
	@FindBy(xpath="//tr[@class='ng-star-inserted']/td[2]")
	public List<WebElement> Book_progressList;
	
	@FindBy(xpath="//tr[@class='ng-star-inserted']/td[1]")
	public List<WebElement> participantList;
	
	@FindBy(xpath="//div[@class='paginator ng-star-inserted']")
	public WebElement paginator;
	
	@FindBy(xpath="//mat-icon[text()='chevron_right']")
	public WebElement paginator_right;
	
	@FindBy(xpath="//*[@aria-label='Active challenge']/mat-card/mat-card-header/div/mat-card-title")
	public List<WebElement> ActiveProg_name;
	
	//______________selvi_______________
	public void setProgTypeXofY() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		jsClick(rp.programType);
		logger.info("Selected reminder type :" + rp.progTypes.get(1).getText() + "#Pass");
		rp.progTypes.get(1).click();
	}
	
	public void setProgTypeBooksInOrder() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		jsClick(rp.programType);
		logger.info("Selected reminder type :" + rp.progTypes.get(1).getText() + "#Pass");
		rp.progTypes.get(0).click();
	}
	
	public void booksInOrderCreator() {
		waitFor(8000);
		jsClick(lbl_ReadingList);
		javascriptScroll(lbl_ReadingList);
		if (ReadingList_moreIcon.size()>=1) {
		Assert.assertTrue(true);
		logger.info("Books in order functionality #Pass");
		}
		else {
		logger.info("Books in order functionality #Fail");
		Assert.assertTrue(false);
		}
		}
	
	public void addMultipleTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Add title assertion started--");
		Assert.assertEquals(addTitleHeader.getText(), testData.get(0).get("lbl_addTitle"));
		logger.info("Add title to challenge header is present #Pass");
		javascriptScroll(rp.btn_AddTitle);
		ClickOnWebElement(rp.btn_AddTitle);
		//Screenshots.takeScreenshot(driver, "Screenshots/ReadingChallenge/CreateChallenge/AddTitle1.png");
		SendKeysOnWebElement(rp.txt_SearchInput, testData1.get(3).get("titleName"));
		waitFor(5000);
		SendKeysEnter(rp.txt_SearchInput);
		logger.info("Title name is entered #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChallenge/CreateChallenge/AddTitlce_SearchResult.png");
		waitFor(21000);
		for(int i=0;i<=3;i++) {
			jsClick(RWDMoreMenulist.get(i));
			waitFor(1000);
			jsClick(titleAddtoProgram);
		}
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChallenge/CreateChallenge/AddTitle_ToProgramMultipleTitles.png");
		Assert.assertEquals(ElementisPresent(rp.btn_publish), true);
		logger.info("Private program Multiple titles Added  #Pass");
		waitFor(5000);
	}
	
	public void CreatorPrgDetailsPageValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");	
		waitFor(9000);
//		WaitForWebElement(rp.readingProgramHeader);
		
		Assert.assertTrue(prgDetailsPg_Breadcrum.isDisplayed());
		logger.info("Breadcrum is displayed #Pass");
		
		Assert.assertEquals(PrgcreatorAvatar.isDisplayed(),true);
		logger.info("Program creator Avatar is Displayed #Pass");
		
		Assert.assertEquals(lbl_PrgcreatorName.isDisplayed(),true);
		logger.info("Program creator name is Displayed #Pass");
		
		Assert.assertEquals(lbl_PrgcreatedDt.isDisplayed(),true);
		logger.info("Program created date is Displayed #Pass");
		
/*		String sd = rp.lbl_startDate.getText().substring(1, 1);
		Assert.assertEquals(sd, testData.get(0).get("Startdate"));
		logger.info("Start date is available #Pass");

		String ed = rp.lbl_endDate.getText().substring(1, 1);
		Assert.assertEquals(ed, testData.get(0).get("Enddate"));
		logger.info("Start date is available #Pass");
*/
		Assert.assertEquals(lbl_PrgStatus.isDisplayed(),true);
		logger.info("Program Status is Displayed #Pass");
				
		Assert.assertEquals(lbl_PrgVisibility.isDisplayed(),true);
		logger.info("Program Visibility is Displayed #Pass");
		
		Assert.assertEquals(lbl_PrgType.isDisplayed(),true);
		logger.info("Program Type is Displayed #Pass");
		
		waitFor(2000);
		Assert.assertEquals(lbl_PrgReminder.isDisplayed(),true);
		logger.info("Program reminder frequency is Displayed #Pass");
		
		Assert.assertEquals(lbl_ReadingPrg.isDisplayed(),true);
		logger.info("Reading Program lbl is Displayed #Pass");
		
		Assert.assertEquals(rp.programName.isDisplayed(),true);
		logger.info("Program Name is available #Pass");
		
		Assert.assertEquals(lbl_Prgdesc.getText(),testData.get(0).get("progDesc"));
		logger.info("Program Description is available #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/PrgDetailPg/RP_Detail_page.png");
	}
	
	public void activePrgValidation() throws IOException, Exception {
		WaitForWebElement(Lbl_activeProgram);
		if (activePrograms.size()!=0) {
			ClickOnWebElement(activePrograms.get(0));
			WaitForWebElement(detailsPg_StartDate);
			String displayDate = detailsPg_StartDate.getText();
			System.out.println(displayDate);
			SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = s.parse(displayDate);
			LocalDate dateObj = LocalDate.now();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			String currentDate = dateObj.format(formatter);
			System.out.println(currentDate);
			Date date2 = s.parse(currentDate);
			System.out.println("currentDate:"+date2);
			if (date1.compareTo(date2) < 0 || date1.compareTo(date2) == 0) {
				logger.info(" - Program start date should be past or present date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/Active_Program.png");
			} else {
				Assert.assertTrue(false);
			}
			logger.info("User able to see the active programs under active programs section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/ActivePrograms.png");
		}else {
			logger.info("User not able to see the active programs under active programs section #Fail");
			Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/ActivePrograms.png");
			Assert.assertTrue(false);
		}
	}
	
	public void draftPrgValidation() throws IOException {
		waitFor(5000);
		rp.programSearch();
		javascriptScroll(lbl_draftPrograms);
		if (draftPrograms.size()!=0) {
			logger.info("User able to see the draft programs under Drafts programs section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/DraftPrograms.png");
		}
	}
	
	public void closedPrgValidation() throws IOException, Exception {
//		waitFor(5000);
//		rp.programSearch();
		for (int i = 0; i<=20; i++) {
			waitFor(3000);
			javaScriptScrollToEnd();
			waitFor(3000);
			javascriptScroll(lbl_Activeprogram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedPrograms + "')]"));
				javascriptScroll(rp.footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javascriptScroll(rp.footer);
				waitFor(2000);
			}
		}	
//		javascriptScroll(lbl_closedPrograms);
		if (closedPrograms.size()!=0) {
			ClickOnWebElement(closedPrograms.get(0));
			WaitForWebElement(detailsPg_endDate);
			String displayDate = detailsPg_endDate.getText();
			System.out.println(displayDate);
			SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = s.parse(displayDate);
			
			LocalDate dateObj = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			String currentDate = dateObj.format(formatter);
			System.out.println(currentDate);
			Date date2 = s.parse(currentDate);
			System.out.println("currentDate:"+date2);
			if (date1.compareTo(date2) < 0) {
				logger.info( " - Program end date should be past date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/closed_Program.png");
			} else {
				Assert.assertTrue(false);
			}
			logger.info("User able to see the Closed programs under closed programs section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/MyProgram/ClosedPrograms.png");
		}
	}
public String createPublicProgramTypeMsg(int num,boolean progType, boolean access, boolean multiStud, boolean multiTitle, boolean save) throws Exception {
		FileInputStream fis = new FileInputStream(ConfigurationFile);
		Properties prop = new Properties();
		prop.load(fis);
		progName = "Automation_RP_"+ generateRandomNumber();
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		logger.info("-- Create Program validation started--");
		ClickOnWebElement(rp.btn_createProgram);
		WaitForWebElement(rp.lbl_CreateProgrm);
		System.out.println(rp.lbl_CreateProgrm.getText());
		Assert.assertEquals(rp.lbl_CreateProgrm.getText(), testData.get(0).get("lbl_CreateProgram"));
		logger.info("Create program header is available #Pass");
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		waitFor(3000);
		ClickOnWebElement(rp.inp_progName);
		waitFor(3000);
		SendKeysOnWebElement(rp.inp_progName, progName);
		System.out.println("Created Program: "+progName);
		logger.info("Program name entered #Pass");
		Assert.assertEquals(rp.lbl_progDesc.getText(), testData.get(0).get("lbl_progDescTxt"));
		logger.info("Program Description text box is available #Pass");
		SendKeysOnWebElement(rp.inp_progDesc, testData.get(0).get("progDesc"));
		logger.info("Program Description entered #Pass");
		
		if(access == true) {
			logger.info("Public radio button is available #Pass");
			ClickOnWebElement(rp.rb_public);
			logger.info("Public radio button is clicked #Pass");
		}
		else if(access == false) {
			logger.info("Private radio button is available #Pass");
			ClickOnWebElement(rp.rb_private);
			logger.info("private radio button is clicked #Pass");
		}
		
		if(progType==true) {
			setProgTypeXofY();
		}
		else if(progType==false) {
			setProgTypeBooksInOrder();
		}
		
		rp.startDate();
		rp.endDate();
		logger.info("Set Remainder text box is available #Pass");
		rp.setRemainder();
		waitFor(1000);
		if(multiStud == true) {
			ClickOnWebElement(rp.btn_addfriendprg);
			ClickOnWebElement(txt_SearchStudentName);
			if(prop.getProperty("Env").equalsIgnoreCase("QAT")) {
			SendKeysOnWebElement(txt_SearchStudentName, testData.get(1).get("studentName"));
			}else
			{
			waitFor(12000);
			SendKeysOnWebElement(txt_SearchStudentName, testData.get(3).get("studentName"));	
			}
//			SendKeysEnter(txt_SearchStudentName);
			logger.info("Entered student name in search box #Pass");
			rc1.addMultipleStudent(num);
			jsClick(rp.btn_InviteToPrgrm);
			waitFor(3000);
		}
		else if(multiStud == false) {
			rp.assignStudentMsg();
		}
		
		logger.info("Add title header is available is available #Pass");
		if(multiTitle == true) {
			addMultipleTitle();
		}
		else if(multiTitle ==  false) {
			rp.addTitle();
		}
		waitFor(3000);
		if(save==true) {
			Assert.assertEquals(ElementisPresent(rp.btn_save), true);
			ClickOnWebElement(rp.btn_save);
			logger.info("Save button is available and clicked #Pass");
			WaitForWebElement(rp.lbl_ActiveChallenge);
			waitFor(5000);
		}else if(save==false) {
			Assert.assertEquals(ElementisPresent(rp.btn_publish), true);
			ClickOnWebElement(rp.btn_publish);
			logger.info("Public program x of y created #Pass");
			WaitForWebElement(rp.lbl_myPrograms);
		}
		return progName;
	}
	public void ongoingPrgValidation() throws IOException, Exception {
		ClickOnWebElement(rp.RwdOpenPrograms);
		WaitForWebElement(lbl_ongoingPrograms);	
		if (ongoingPrograms.size()!=0) {
			ClickOnWebElement(ongoingPrograms.get(0));
			WaitForWebElement(ongoingPrg_startDate);
			String[] createdt = ongoingPrg_startDate.getText().split(" ");
			String displayDate = createdt[0];
			System.out.println(displayDate);
			SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = s.parse(displayDate);
			LocalDate dateObj = LocalDate.now();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			String currentDate = dateObj.format(formatter);
			System.out.println(currentDate);
			Date date2 = s.parse(currentDate);
			System.out.println("currentDate:"+date2);
			if (date1.compareTo(date2) < 0 || date1.compareTo(date2) == 0) {
				logger.info(" - Program start date should be past or present date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/OpenProgram/ongoing_Program.png");
			} else {
				Assert.assertTrue(false);
			}
			logger.info("User able to see the active programs under active programs section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/OpenProgram/ongoingPrograms.png");
		}else {
			logger.info("User not able to see the active programs under active programs section #Fail");
			Screenshots.takeScreenshot(driver, "Screenshots/OpenProgram/ongoingPrograms.png");
			Assert.assertTrue(false);
		}
	}
	
	public void upcomingPrgValidation() throws IOException {
		ClickOnWebElement(rp.RwdOpenPrograms);
		WaitForWebElement(lbl_ongoingPrograms);	
		for (int i = 0; i <= 5; i++) {
			waitFor(3000);
			javaScriptScrollToEnd();
			waitFor(3000);
			javascriptScroll(lbl_ongoingPrograms);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + rp.progName + "')]"));
				javascriptScroll(rp.footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javascriptScroll(rp.footer);
				waitFor(2000);
			}
		}
		javascriptScroll(lbl_upcomingPrograms);
		if (upcomingPrograms.size()!=0) {
			logger.info("User able to see the upcoming programs under Upcoming programs section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/OpenProgram/UpcomingPrograms.png");
		}
	}
	
	public void prgCardValidation() {
		WaitForWebElement(Lbl_activeProgram);
		Assert.assertTrue(Lbl_activeProgram.isDisplayed());
        logger.info("MY program tab -> lbl_ActiveProgram  is visible #Pass");
        String[] split = Readingname.get(0).getText().split("BY ");
        Assert.assertTrue(Readingname.get(0).isDisplayed());
        logger.info(" Readyby Date is visible #Pass");
        Assert.assertTrue( programname.get(0).isDisplayed());
        logger.info("MY program name is visible on active program #Pass");
        Assert.assertTrue( Cardcontent.get(0).isDisplayed());
        logger.info("MY program Description  is visible on active program #Pass");
	}
	
	public String unpublishPrg() {
		waitFor(9000);
		WaitForWebElement(detailsPg_unPublishbtn);
		unpublishPrg = rp.programName.getText();
		System.out.println(unpublishPrg);
		ClickOnWebElement(detailsPg_unPublishbtn);
		waitFor(5000);
		ClickOnWebElement(confirmunpublish);
		waitFor(5000);
		return unpublishPrg;
	}
	
	public void unpublishPrgValidation() {
		rp.programSearch();
		waitFor(2000);
		javascriptScroll(lbl_draftPrograms);
		javascriptScroll(Lbl_activeProgram);
		int size = Unpublish_TitlecardprgName.size();
		System.out.println("Title Size:"+ size);
		System.out.println(unpublishPrg);
		for (int i = 0; i<Unpublish_TitlecardprgName.size(); i++) {
			logger.info("unpublished program Name : " + Unpublish_TitlecardprgName.get(i).getText() );
			if(Unpublish_TitlecardprgName.get(i).getText().equalsIgnoreCase(unpublishPrg)){
				logger.info("unpublished program found in unpublish program section #Pass");
				break;
			}
		}
	}
	
	public void publishprogram() {

		waitFor(2000);
		WaitForWebElement(btn_ublish);
		jsClick(btn_ublish);
		logger.info("publish the program  #Pass");

	}
	
	public void unpublishProgram() {

		waitFor(2000);
		jsClick(btn_ublish);
		Assert.assertEquals(removeconfirmpopup.isDisplayed(), true);
		logger.info("unpublish the program  #Pass");
		jsClick(confirmunpublish);

	}

	public void editProgram() {
		waitFor(6000);
		SendKeysOnWebElement(inp_progName, progName + "Edit");
		waitFor(1000);
		WaitForWebElement(btn_save);
		ClickOnWebElement(btn_save);

	}

	public void editdrftProgram() {

		waitFor(4000);
		SendKeysOnWebElement(inp_progName, progName + "Draft");
		waitFor(1000);
		WaitForWebElement(btn_publish);
		ClickOnWebElement(btn_publish);

	}

	public void programlandingValidation() {

		waitFor(5000);
		Assert.assertEquals(subTitle.isDisplayed(), true);
		logger.info("Program subtitle is visible #Pass");
		Assert.assertEquals(subprogram.isDisplayed(), true);
		logger.info("Program name is visible #Pass");
	}

	public void editProgramValidation() {

		waitFor(6000);
		jsClick(Rwdeditprg);
		waitFor(2000);
		
	}
	
	public void CheckmandatoryFileds() {
		waitFor(2000);
		javascriptScroll(RWDsetReminder);
		waitFor(1000);
		ClickOnWebElement(removeTitle);
		waitFor(2000);
		ClickOnWebElement(removeconfirm);
		logger.info("Remove button clicked");
		waitFor(2000);
		Assert.assertEquals(errorTitlemsg.isDisplayed(), true);
		logger.info("Mandatory field validations are in place for Private program #Pass");

	}
	
	public void unPublishedSection() throws IOException {

		 for (int i = 0; i <= 9; i++) {
	            waitFor(2000);
	            javaScriptScrollToEnd();
	            waitFor(2000);
	            javascriptScroll(lbl_Activeprogram);
	            try {
	                WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
	                javascriptScroll(footer);
	                waitFor(2000);
	                javascriptScroll(ss);
	                break;
	            } catch (Exception e) {
	                javascriptScroll(footer);
	                waitFor(2000);
	            }
	        }

	        WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
	        logger.info(ss.getText() + " is found in My Program listing screen and opened #Pass");
	}

	public void bookClub() throws InvalidFormatException, IOException {
		waitFor(2000);
		WaitForWebElement(menu_profileIcon);
		WaitForWebElement(RWDbookClubOptionWeb);
		jsClick(RWDbookClubOptionWeb);
		WaitForWebElement(lbl_myPrograms);
		Screenshots.takeScreenshot(driver, "Screenshots/DestinyDiscover/BookClub.png");
		logger.info("My Programs tab is available #Pass");
		waitFor(8000);
		WaitForWebElement(lbl_myPrograms);
		jsClick(lbl_myPrograms);
		waitFor(4000);
		WaitForWebElement(lbl_Activeprogram);
		logger.info(" --Book club validation Completed-- ");
	}

	public void programDetailsValidationAdmin() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		waitFor(8000);
		Assert.assertEquals(programName.isDisplayed(), true);
		logger.info("Program is available #Pass");
		Assert.assertEquals(ElementisPresent(lbl_readinglist), true);
		logger.info("Reading list header is available #Pass");
		Assert.assertEquals(ElementisPresent(lbl_participantlist), true);
		logger.info("Participant list header is available #Pass");
		//	String sd = lbl_startDate.getText().substring(3, 5);
		Assert.assertEquals(lbl_startDate.isDisplayed(), true);
		logger.info("Start date is available #Pass");
		String ed = lbl_endDate.getText().substring(3, 5);
		Assert.assertEquals(lbl_endDate.isDisplayed(), true);
		logger.info("Start date is available #Pass");
	}
	
	
	public void programSearchwithoutClick() {
		for (int i = 0; i <= 9; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_Activeprogram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
		logger.info(ss.getText() + " is found in My Program listing screen and opened #Pass");
	}
	public void programSearchwithoutClick(String progName) {
		for (int i = 0; i <= 9; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_Activeprogram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
		logger.info(ss.getText() + " is found in My Program listing screen and opened #Pass");
	}
	
	public void createProgram() throws InvalidFormatException, IOException,Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		ClickOnWebElement(rp.btn_createProgram);
		WaitForWebElement(rp.lbl_CreateProgrm);
		SendKeysOnWebElement(inp_progName, progName);
		waitFor(1000);
		SendKeysOnWebElement(rp.inp_progDesc, testData.get(0).get("progDesc"));
		ClickOnWebElement(rp.rb_public);
		rp.setProgType();
		rp.startDate();
		rp.endDate();
		logger.info("Set Remainder text box is available #Pass");
		rp.setRemainder();
		rp.assignStudent();
		logger.info("Add title header is available is available #Pass");
		rp.addTitle();
		waitFor(3000);
		jsClick(btn_publish);

	}
	
	public void navigateToBookclub() {
		waitFor(3000);
		ClickOnWebElement(RWD_bookClubTab);
		waitFor(5000);
	}
	
	public void challengeTabAssertion() throws IOException {	
		Assert.assertEquals(lbl_ActiveChallenge.isDisplayed(),true);
		logger.info("Challenges tab is selected by Default #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/BookClub_landing.png");
	}
	
	public void navToCreateChallengePage() throws IOException {
		WaitForWebElement(rc1.RWDaddCTAWeb);
		ClickOnWebElement(rc1.RWDaddCTAWeb);
		WaitForWebElement(rc1.lbl_createChlgTitle);
		logger.info("User Navigates to Create chalenge Page #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge.png");
	}
	
	public String createChallenge() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		
		rc.searchInviteFriends();
		rc.setReminder(false);
		chlngEndDate(true);
		rc.addTitle();
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Create challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Challenge created Sucessfully #Pass");
		}
		return chlngName;
	}
	public void receiveMessageUpdate(String message) throws InvalidFormatException, IOException {
		rc1.checkInviteMessageprogram(updatedprogname,message);

	}
	public void chlngEndDate(Boolean date) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		waitFor(3000);
		jsClick(rc.RWDcalenderImage);
		logger.info("End date calander is opened #Pass");
		waitFor(1000);
		if(date==true) {
			String endDate = Integer.toString(getNextDate());
			WebElement ed = driver.findElement(By.xpath("//div[text()=' " + endDate + " ']"));
			waitFor(1000);
			jsClick(ed);
			waitFor(1000);
		}
		if (date==false) {
			String startDate = Integer.toString(getCurrentDate());
			WebElement sd = driver.findElement(By.xpath("//div[text()=' " + startDate + " ']"));
			waitFor(1000);
			jsClick(sd);
			waitFor(1000);
		}
	}
		
	public int getCurrentDate()
	{
	    Calendar calendar = Calendar.getInstance();
	    Date today = calendar.getTime();
	    calendar.add(Calendar.DAY_OF_YEAR, 0);
	    Date tomorrow = calendar.getTime();
		return tomorrow.getDate();	
	}
	
	public int getNextDate()
	{
	    Calendar calendar = Calendar.getInstance();
	    Date today = calendar.getTime();
	    calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrow = calendar.getTime();
		return tomorrow.getDate();	
	}
	
	public void clickOnCrossIcon() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		ClickOnWebElement(RWD_CloseIcon);
		ClickOnWebElement(RWD_CloseOkButton);
		waitFor(2000);
		try {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("clicking on close icon close the CC page #Fail");		
			Assert.assertTrue(false);
		} catch (Exception e) {
			logger.info(" clicking on close icon close the CC page #Pass");
		}
	}
	
	public void saveChallengeMandatoryFieldcheck() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		javascriptScroll(rp.btn_AddTitle);
		ClickOnWebElement(rc1.RWDstartChalnge);
		Assert.assertEquals(errorTitlemsg.isDisplayed(), true);
		logger.info("Mandatory field validations are in place for Saving challenges #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/MandatoryFieldI/P.png");

	}
	
	public void saveChallenge() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		chlngEndDate(true);
		rc.addTitle();
		ClickOnWebElement(rc1.save);
		waitFor(4000);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/SaveChallenge.png");
		logger.info("save challenge button is clicked #Pass");
		if(lbl_CreateChallenge.isDisplayed()==true) {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("Save challenge clicked but Challenge not Saved ");		
			Assert.assertTrue(false);
		} else {
			Assert.assertTrue(lbl_rcDetailsPageHeader.isDisplayed());
			ClickOnWebElement(RWD_bookClubTab);
			waitFor(5000);
			for (int i = 0; i <= 10; i++) {
				waitFor(2000);
				javaScriptScrollToEnd();
				waitFor(2000);
				javascriptScroll(lbl_ActiveChallenge);
				try {
					WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedPrograms + "')]"));
					javascriptScroll(footer);
					waitFor(2000);
					javascriptScroll(ss);
					break;
				} catch (Exception e) {
					javascriptScroll(footer);
					waitFor(2000);
				}
			}
		}	
		javascriptScroll(lbl_draftChallenges);
		for (int i = 0; i<=draftChallenges.size()-1; i++) {
			try {
				if(draftChallenges.get(i).getText().equals(chlngName)) {
					logger.info("Save challenge is Displayed in listing page #Pass ");
					break;
				}
				else {
					logger.info("Searching again for Saved challenge ");
				}
			}catch (Exception e) {
				
			}
		}
	}
	
	public void duplicateChallenegNameValidation(Boolean type) throws InvalidFormatException, IOException {
		waitFor(2000);
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		chlngEndDate(true);
		rc.addTitle();
		if(type==true) {
			ClickOnWebElement(rc1.save);
		}
		if (type==false) {
			ClickOnWebElement(rc1.RWDstartChalnge);
		}
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/duplicateChallengeToast.png");
		try {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("User Not able to save the challenge with duplicate name");		
		} catch (Exception e) {
			Assert.assertTrue(lbl_rcDetailsPageHeader.isDisplayed());
			logger.info("User able to save the challenge with duplicate name");
			Assert.assertTrue(false);
		}

	}
	
	public String getNotificationCount() {

		if (ElementisPresent(msgNotificationCount)) {
			Assert.assertTrue(msgNotificationCount.isEnabled());
			logger.info("Message Center Bell icon Displayed #Pass");
			logger.info("Unread Messages Displayed in top of hamburger Menu #Pass");

		} else {
			logger.info("Message Center Bell icon Not Displayed");
		}
		return msgNotificationCount.getText();

	}

	public void readMessage() {
		RWDInviteText.get(1).click();
		logger.info("Open the message #Pass");
		waitFor(2000);
		jsClick(btn_msgclose);

	}

	public void verifymsgCount() {

		beforemsgCount = Integer.parseInt(getNotificationCount());
		waitFor(1000);
		int afterCont = Integer.parseInt(msgNotificationCount.getText());
		Assert.assertTrue(beforemsgCount >= afterCont);
	}

	public void modifyEndDate() throws InvalidFormatException, IOException {
		waitFor(3000);
		jsClick(btn_endDate);
		logger.info("End date calander is opened #Pass");
		waitFor(1000);
		String endDate = Integer.toString(getCurrentpreDate());
		WebElement ed = driver.findElement(By.xpath("//div[text()=' " + endDate + " ']"));
		waitFor(1000);
		jsClick(ed);
		waitFor(1000);
	}

	public int getCurrentpreDate() {
		Calendar calendar = Calendar.getInstance();
		Date today = calendar.getTime();
		calendar.add(Calendar.DAY_OF_YEAR, 2);
		Date tomorrow = calendar.getTime();
		return tomorrow.getDate();

	}

	public String updateprgName() {
		logger.info("Modify the program Name #Pass");
		waitFor(2000);
		SendKeysOnWebElement(inp_progName, progName + "updated");
		waitFor(2000);
		updatedprogname = inp_progName.getAttribute("value");
		System.out.println("Update Program Name:" + updatedprogname);
		waitFor(2000);
		return updatedprogname;

	}

	public void markUnreadmsg() {

		waitFor(1000);
		RWDmsgChkbox.get(3).click();
		waitFor(1000);
		ClickOnWebElement(moremenu);
		ClickOnWebElement(markUnread);
		logger.info("Mark message as Unread #Pass");

	}
	
	public void markreadmsg() {

		waitFor(1000);
		RWDmsgChkbox.get(2).click();
		waitFor(1000);
		ClickOnWebElement(moremenu);
		ClickOnWebElement(markread);
		logger.info("Mark message as read #Pass");

	}

	public void modifyReminder() {
		javascriptScroll(RWDsetReminder);
		jsClick(RWDsetReminder);
		List<WebElement> remindertype = RWDReminderTypes;
		waitFor(2000);
		switch ("Weekly") {
		case "Daily":
			waitFor(1000);
			logger.info("Selected reminder type :" + remindertype.get(1).getText());
			remindertype.get(1).click();
			break;
		case "Weekly":
			waitFor(1000);
			logger.info("Selected reminder type :" + remindertype.get(2).getText());
			remindertype.get(2).click();
			break;
		case "Monthly":
			waitFor(1000);
			logger.info("Selected reminder type :" + remindertype.get(3).getText());
			remindertype.get(3).click();
			break;
		}
	}

	public void saveProgram() {
		ClickOnWebElement(rp.btn_save);
		logger.info("Save the program");
	}

	public void verifyinceasemsgCount() {
		beforemsgCount = Integer.parseInt(getNotificationCount());
		waitFor(1000);
		int afterCont = Integer.parseInt(msgNotificationCount.getText());
		Assert.assertTrue(beforemsgCount <= afterCont);
		logger.info("Verify that message center notification count increase after change into the challenge #Pass");
	}

	public void receiveMessage(String message) throws InvalidFormatException, IOException {
		rc1.checkInviteMessageprogram(progName,message);

	}
	
	public void activeprogramsection() {
		// TODO Auto-generatesd method stubs
		Assert.assertTrue(rp.lbl_ActiveProgram.isDisplayed());
    	logger.info("MY program tab -> lbl_ActiveProgram  is visible #Pass");
    	
    	Assert.assertTrue(Readingname.get(0).isDisplayed());
    	logger.info(" is visible #Pass");
    	
    	Assert.assertTrue( programname.get(0).isDisplayed());
    	logger.info("MY program name is visible on active program #Pass");
    	Assert.assertTrue( Cardcontent.get(0).isDisplayed());
    	logger.info("MY program Description  is visible on active program #Pass");
    	

    	 String Sub1 = Readingname.get(0).getText();
    		 System.out.println(Sub1);
    		String Sub2 = "READ BY";
    		 
    		if (Sub1.contains("READ BY ")) {

    	     logger.info("Reading Program name contains as READ By in active Program #Pass");
    	     }
    	     else
    	     	logger.info("Reading Program name contains as READ By in active Program #Fail");
    	     	
    	     }
	
public void removeParticipant() {
		
		waitFor(13000);
		javascriptScroll(RWDsetReminder);
		jsClick(close);
		jsClick(removeconfirm);
		waitFor(3000);
		jsClick(rc1.save);
		
	}
	
	public void onGoingProgramValidation() throws IOException {
		waitFor(12000);
		ClickOnWebElement(RwdBookClub);
		waitFor(12000);
		ClickOnWebElement(RwdOpenPrograms);
		waitFor(16000);
		Assert.assertEquals(RWDOnGoing.getText(), "ONGOING PROGRAMS");
		logger.info("ONGOING PROGRAMS Tab Availble  #Pass");
		javascriptScroll(footer);
		waitFor(10000);
		try {
			WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
			javascriptScroll(ss);
		} catch (Exception e) {
			System.out.println("Scrolling again");
			javascriptScroll(footer);
			javaScriptScrollToEnd();
		}
		programSearchwithclick(RWDOnGoing);
		logger.info("created ongoing Program Availble #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/OnGoing/ongoingPrg.png");
		waitFor(8000);
		waitFor(3000);
		logger.info("Clicking on the created program card should show Program details on open program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/createProgram/showProgram.png");
	}
	public void programSearchwithclick(WebElement ele) {
		for (int i = 0; i <= 5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(ele);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName + "')]"));
		logger.info(ss.getText() + " is found in challenge listing screen and opened #Pass");
		jsClick(ss);
	}
	public void joinProgram() throws InvalidFormatException, IOException {
		waitFor(3000);
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		jsClick(btn_JoinProgram);
		WaitForWebElement(welcome);
		Assert.assertEquals(welcome.getText().trim(), testData.get(0).get("welcomeMsg").trim());
		logger.info(welcome + " is dispplayed #Pass");
		if (letStart.getText().contains("Let's Get Started")) {
			logger.info(letStart + " is displayed #Pass");
		}
		Assert.assertEquals(ElementisPresent(gotoProgram), true);
		ClickOnWebElement(gotoProgram);
		logger.info("Go To Program button is available and clicked #Pass");
	}

	public void checkunpublish() {
		rc1.checkunpublishMessage(progName);
		
	}
	
/**********************************Locators******************************************/
	@FindBy(xpath = "//*[@aria-label='Next month']")
	public WebElement calenderNextMonthArrow;
	
	@FindBy (xpath=" //*[text()=' Add to Program ']")
	public WebElement titleAddtoProgram;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public List<WebElement> RWDMoreMenulist;
	
	@FindBy(xpath = "//*[text()='Add Titles ']")
	public WebElement addTitleHeader;
	
	@FindBy(xpath = ".//*[@id='prog-main-create' or contains(text(),'CREATE PROGRAM')]")
    public WebElement RWD_CreateProgramLink;
	
	@FindBy(xpath="//*[contains(text(),'My Programs')]")
    public WebElement RWD_myProgramTab;
	
	@FindBy(xpath="//*[text()='Challenges']")
	public WebElement RWD_challengesTab;

	@FindBy(xpath = "//*[contains(text(),'Book Club')]")
    public WebElement RWD_bookClubTab;
	
	@FindBy(xpath="//*[text()='Search']")
	public static WebElement searchPageHeader;
	
	@FindBy(xpath="(//div[@class='carousel-header ng-star-inserted'])[1]//following::mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public static List<WebElement> homePageMoreIcon;
	
	@FindBy(xpath="//*[@class='carousel-header ng-star-inserted'][1]")
	public static WebElement firstCarousel;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public static List<WebElement> RWD_MoreIcon;
	
	@FindBy(xpath = "(//*[@class='user-image'])[2]")
	public static WebElement RWD_addedTitleRC;
	
	@FindBy(xpath = "//*[text()='Create Reading Challenge']")
	public static WebElement lbl_CreateChallenge;
	
	@FindBy(xpath = "//*[text()='ACTIVE CHALLENGES ']")
	public static WebElement lbl_ActiveChallenge;
	
	@FindBy(xpath = "//*[text()=' Include in a New Challenge ']")
	public static WebElement RWD_includeInNewChallenge;
	
	@FindBy(xpath = "(//*[@class='user-image'])[2]")
	public static WebElement RWD_addedTitle;
	
	@FindBy(xpath = "(//*[text()='close'])[2]")
	public static WebElement RWD_CloseIcon;
	
	@FindBy(xpath ="//button/span[text()='OK']")
	public static WebElement RWD_CloseOkButton;
	
	@FindBy(xpath = "(//*[text()='Discover'])[2]")
	public static WebElement RWD_discoverBreadCrum;
	
	@FindBy(xpath = "//*[text()=' Discover ']")
        public static WebElement RWD_discoverPage;
	
	@FindBy(xpath = "//*[text()=' Fines ']")
	public WebElement  Fines;

	@FindBy(xpath = "//*[text()='You currently have no fines']")
	public WebElement notitlefines;
	
	@FindBy(xpath = "//*[text()=' Favorites ']")
	public WebElement  Favorites;
	
	@FindBy(xpath = "//*[text()='You have no books Favorites']")
	public WebElement notitleFavorites;
	
	@FindBy(xpath = "//*[text()=' Holds ']")
	public WebElement  Holds;
	
	@FindBy(xpath = "//*[text()='You currently have no titles on hold']")
	public WebElement notitleholds;
	
	@FindBy(xpath = "//*[text()='You have no books history']")
	public WebElement notitlehistory;
	
	@FindBy(xpath = "//*[text()=' History ']")
	public WebElement  History;
	
	@FindBy(id = "cprog-close-2")
	public WebElement btn_close;
	
	@FindBy(xpath = "//*[text()=' Include in a New Program ']")
	public WebElement includeNewprg;
	
	@FindBy(xpath = "//*[text()='You currently have no titles checked out']")
	public WebElement notitleCheckout;
	
	@FindBy(xpath = "//*[text()=' Checkouts ']")
	public WebElement  Checkouts;

	@FindBy(xpath = "//*[@aria-label='my stuff menu']")
	public WebElement mystuffmenu;

	@FindBy(xpath = "//*[@class='addedBooks ng-star-inserted']//button[1]/mat-icon")
	public WebElement removeTitle;
	
	@FindBy(xpath = "//div[@class='dd-stud-info ng-star-inserted']")
	public List<WebElement> btn_addedStudents;
	
	@FindBy(xpath = "//*[text()='Remove']")
	public WebElement removeconfirm;
	
	@FindBy(id = "ivite-chlg-search")
	public WebElement txt_SearchStudentName;
	
	@FindBy(id = "pd-editprg")
	public WebElement Rwdeditprg;
	
	@FindBy(xpath = "//h2[contains(text(),'Create Reading Program')]")
	public static WebElement Rwddublicatescreen;
	
	@FindBy(id = "pd-duplcate")
	public static WebElement Rwdduplicateprg;
	
	@FindBy(xpath="(//*[@class='mat-card-header-text']/mat-card-title)[1]")
	public static WebElement existing_RP_Name;
	
	@FindBy(xpath="//*[text()='Program name is required. ']")
	public WebElement req_progName;
	
	@FindBy(xpath="//*[text()='Start date is required. ']")
	public WebElement req_startDate;
	
	@FindBy(xpath="//*[text()='End date is required.']")
	public WebElement req_endDate;
	
	@FindBy(xpath="//*[text()='At least one student is required.']")
	public WebElement req_student;
	
	@FindBy(xpath="//*[text()='At least one title is required.']")
	public WebElement req_title;
	
	@FindBy(xpath="//*[text()=' Please fill required fields. ']")
	public WebElement req_fields;
	
	@FindBy(xpath = "//h1[text()='ACTIVE PROGRAMS']")
	public WebElement lbl_Activeprogram;
	
	//@FindBy(xpath = "//p[contains(text(),'© 2021 Follett School Solutions.')]")
	@FindBy(xpath ="//*[@class='text-left']")
	public WebElement footer;
	
	@FindBy( xpath = "//*[@id='pd-readlist-head']//following::button[2]//child::mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")     
	public List<WebElement> ReadingList_moreIcon;      
	
	@FindBy( xpath = "//*[@id='pd-readlist-head']")     
	public WebElement lbl_ReadingList;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[1]")
	public static WebElement HomeMenu;
	
	@FindBy(xpath="(//h2[text()='Learning Resources']//preceding::div[@class='carousel-header ng-star-inserted'])")
	public static WebElement basedOnPrefCarousel;
	
	@FindBy(xpath="//*[@class='breadcrumb-item']")
	public static WebElement prgDetailsPg_Breadcrum;
	
	@FindBy(xpath="//h5[@class='bookclubactive']")
	public static WebElement lbl_ReadingPrg;
	
	@FindBy(xpath="//span[@class='createon']")
	public static WebElement lbl_PrgcreatedDt;
	
	@FindBy(xpath="//span[@class='createinfo']")
	public static WebElement lbl_PrgcreatorName;
	
	@FindBy(xpath="//div[@class='challenge-detail-avatar']")
	public static WebElement PrgcreatorAvatar;
	
	@FindBy(xpath="//p[@id='pd-status']")
	public static WebElement lbl_PrgStatus;
	
	@FindBy(xpath="//p[text()='Public']")
	public static WebElement lbl_PrgVisibility;
	
	@FindBy(xpath="//p[text()='Books in Order']")
	public static WebElement lbl_PrgType;
	
	@FindBy(xpath="//p[@class='ng-star-inserted']")
	public static WebElement lbl_PrgReminder;
	
	@FindBy(xpath="//p[@class='challenge-desc']")
	public static WebElement lbl_Prgdesc;
	
	@FindBy(xpath="//*[@aria-label='ACTIVE PROGRAMS']//following::div[@id='dd-Active-contain']")
	public static List<WebElement> activePrograms;
	
	@FindBy(xpath="//*[@aria-label='DRAFT PROGRAMS']//following::div[@id='dd-Save-contain']")
	public static List<WebElement> draftPrograms;
		
	@FindBy(xpath="//*[@aria-label='CLOSED PROGRAMS']//following::div[@id='dd-Complete-contain']")
	public static List<WebElement> closedPrograms;
		
	@FindBy(xpath="//*[@aria-label='ONGOING PROGRAMS']//following::div[@id='dd-Ongoing-contain']")
	public static List<WebElement> ongoingPrograms;
	
	@FindBy(xpath="//*[@aria-label='UPCOMING PROGRAMS']//following::div[@id='dd-Upcoming-contain']")
	public static List<WebElement> upcomingPrograms;
	
	@FindBy(xpath="//*[@aria-label='ACTIVE PROGRAMS']")
	public static WebElement Lbl_activeProgram;
	
	@FindBy(xpath="//*[@aria-label='DRAFT PROGRAMS']")
	public static WebElement lbl_draftPrograms;
	
	@FindBy(xpath="//*[@aria-label='CLOSED PROGRAMS']")
	public static WebElement lbl_closedPrograms;
	
	@FindBy(xpath="//*[@aria-label='ONGOING PROGRAMS']")
	public static WebElement lbl_ongoingPrograms;
	
	@FindBy(xpath="//*[@aria-label='UPCOMING PROGRAMS']")
	public static WebElement lbl_upcomingPrograms;
	
	//@FindBy(xpath="//*[@class='challenge-created']")
	@FindBy(xpath="//*[@id='mat-dialog-0']/fss-ms-join-program/div/div/div[1]/div[3]/div[1]/div[2]")
	public static WebElement ongoingPrg_startDate;
	
	@FindBy(xpath="//*[@id='pd-strt-date']")
	public static WebElement detailsPg_StartDate;
	
	@FindBy(xpath="//*[@id='pd-end-date']")
	public static WebElement detailsPg_endDate;
	
	@FindBy(xpath="//*[@id='pd-ubplish']")
	public static WebElement detailsPg_unPublishbtn;
	
	@FindBy(xpath = "//*[@class = 'mat-card-subtitle subtitle1']")
	public List<WebElement> Readingname;

	@FindBy(xpath = "//*[@class = 'mat-card-title header-title txt-elipsishead']")
	public List<WebElement>  programname;
	
	@FindBy( xpath = "//*[@class ='dd-desc-txt txt-elipsis']")
	public List<WebElement> Cardcontent;
	
	@FindBy( xpath = "//*[@class='mat-focus-indicator submit-btn mat-button mat-button-base']//child::span[text()='OK']")
	public WebElement unPublish_Okbtn;
	
	@FindBy( xpath = "//*[@aria-label='ACTIVE PROGRAMS']//following::div[@id='dd-Active-contain']//following::mat-card-title")
	public List<WebElement> prgName_Titlecard;
	
	@FindBy( xpath = "//*[@aria-label='UNPUBLISHED PROGRAMS']//following::div[@class='mat-card-header-text']//following::mat-card-title")
	public List<WebElement> Unpublish_TitlecardprgName;
	
	@FindBy(xpath = "//*[@class='mat-card-title header-title txt-elipsishead']")
	public WebElement subprogram;
	
	@FindBy(xpath = "//*[@class='mat-card-subtitle subtitle1']")
	public WebElement subTitle;
	
	@FindBy(xpath = "//span[text()='Save']")
	public WebElement btn_save;
	
	@FindBy(xpath = "//*[text()='At least one title is required.']")
	public WebElement errorTitlemsg;
	
	@FindBy(xpath = "//*[@aria-label='Set Reminders'][1]")
	public WebElement RWDsetReminder;
	
	@FindBy(id = "cp-enter-name")
	public WebElement inp_progName;
	
	@FindBy(xpath = "//*[text()='Program name is required. ']")
	public WebElement errorProgrammsg;
	
	@FindBy(xpath = "//*[text()='UNPUBLISHED PROGRAMS']")
	public WebElement unpublished;
	
	@FindBy(xpath = "//*[text()='Open profile options window']")
	public static WebElement menu_profileIcon;
	
	@FindBy(xpath = "//*[text()=' Book Club ']")
	public WebElement RWDbookClubOptionWeb;

	@FindBy(xpath = "//a[@id='tab-myprog-btn']")
	public WebElement lbl_myPrograms;
	
	@FindBy(xpath = "//h1[@id='prog-det-heading']")
	public WebElement programName;
	
	@FindBy(xpath = "//p[@id='pd-strt-date']")
	public WebElement lbl_endDate;

	@FindBy(xpath = "//p[@id='pd-end-date']")
	public WebElement lbl_startDate;
	
	@FindBy(xpath = "//h2[@id='pd-partip-head']")
	public WebElement lbl_participantlist;

	@FindBy(xpath = "//h2[@id='pd-readlist-head']")
	public WebElement lbl_readinglist;
	
	@FindBy(id = "pd-ubplish")
	public WebElement btn_ublish;

	@FindBy(xpath = "//*[@aria-label='Add to Program']")
	public WebElement AddToprgrmTitle;

	@FindBy(xpath = "//*[@class='mat-dialog-content mat-typography']")
	public WebElement removeconfirmpopup;
	
	@FindBy(xpath = "//span[text()='OK']")
	public WebElement confirmunpublish;

	@FindBy(xpath = "//*[@aria-label='More menu']")
	public WebElement moremenu;

	@FindBy(xpath = "//span[text()='Mark as Unread']")
	public WebElement markUnread;
	
	@FindBy(xpath = "//span[text()='Mark as Read']")
	public WebElement markread;

	@FindBy(xpath = "//mat-icon[text()='close']")
	public WebElement btn_msgclose;

	@FindBy(xpath = "//span[text()='Publish Program']")
	public WebElement btn_publish;
	
	@FindBy(xpath = "//h3[text()='DRAFT CHALLENGES ']//following::mat-card/mat-card-header[@class='mat-card-header']")
	public List<WebElement> draftChallenges;
	
	@FindBy(xpath = "//h3[text()='DRAFT CHALLENGES ']")
	public WebElement lbl_draftChallenges;
	
	@FindBy(xpath = "//*[text()='Reading Challenge']")
	public WebElement lbl_rcDetailsPageHeader;
	
	@FindBy(xpath = "//div[3]/button[1]//span[@class='msg-badge-count ng-star-inserted']")
	public WebElement msgNotificationCount;

	@FindBy(xpath = "//div[@class='content-name-head']")
	public List<WebElement> RWDInviteText;

	@FindBy(xpath = "//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")
	public List<WebElement> RWDmsgChkbox;

	@FindBy(xpath = "//*[@id=\"end-date-cp\"]/button")
	public WebElement btn_endDate;
	
	@FindBy(id = "cp-astud-close")
	public WebElement btn_removestudent;

	@FindBy(xpath = "//mat-icon[@class='mat-icon notranslate dd-invite-close material-icons mat-icon-no-color']")
	public WebElement close;
	
	@FindBy(xpath = "//*[@class='mat-option-text']")
	public List<WebElement> RWDReminderTypes;
	
	@FindBy(id = "head-menu-list-book")
	public WebElement RwdBookClub;
	
	@FindBy(id = "tab-open-prog-btn")
	public WebElement RwdOpenPrograms;
	
	@FindBy(xpath = "//*[@aria-label='ONGOING PROGRAMS']")
	public WebElement RWDOnGoing;
	
	@FindBy(xpath = "//*[text()=' Welcome to the Program! ']")
	public WebElement welcome;

	@FindBy(xpath = "//*[@class='card-message']/span")
	public WebElement letStart;

	@FindBy(xpath = "//*[@id='join-prg-btn']")
	public WebElement btn_JoinProgram;
	
	@FindBy(xpath = "//button[text()='Go to Program']")
	public WebElement gotoProgram;
	

		/**** Set Goal button is disabled*******/
		@FindBy(xpath = "//span[text()='Remove Goal']")
		public WebElement Rwdremovegoal;
		
		@FindBy(xpath = "//span[text()='Set Goal']")
		public WebElement Rwdsetgoal;
		
		
		

		@FindBy(xpath = "//h2[text()='Insights']")
		public WebElement Rwdinsights;
		@FindBy(xpath = "//*[@class='insight-item ng-star-inserted']")
		public WebElement RwdInsights;
		
		@FindBy(id = "goal-input")
		public WebElement RwdgoalInput;
		
		public void SetGoalbutton() throws IOException {
			// TODO Auto-generated method stub
			
				waitFor(3000);
				if (ElementisPresent(Rwdinsights)) {
					for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
						if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
							ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
							waitFor(1000);
							Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
									true);
							RwdgoalInput.clear();
							//logger.info("Remove button enabled #Pass");
							//ClickOnWebElement(Rwdremovegoal);
							//logger.info("personal goal removed  #Pass");
							//waitFor(5000);
					
							//Assert.assertFalse(Rwdsetgoal.isEnabled()," Set goal button is not enabled #Pass");
							logger.info(" Set goal button  is not enabled #Pass");
							 ClickOnWebElement(Rwdgoalclose);
			            							
							Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
							waitFor(3000);
							
							}

					}
				} else {
					logger.info("Set goal is set for the insights  #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
				}
			}
		// TODO Auto-generated method stub

		 
		 @FindBy(xpath = "//*[@class='mat-icon notranslate icon-keyboard material-icons mat-icon-no-color']")
			public WebElement Rwdgoalclose;
			@FindBy(xpath = "//*[@class='modal-header']")
			public WebElement RwdModalheader;

			@FindBy(xpath = "//*[@class='modal-info']")
			public WebElement Rwdmodalinfo;

			@FindBy(xpath = "//*[@class='goal-disclamr']")
					public WebElement goaldiscl;	
			
			/******sep 25 2021**/
			public void checkgoal() throws IOException {
				waitFor(3000);
				if (ElementisPresent(Rwdinsights)) {
					for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
						if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
							ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
							Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
									true);
							Assert.assertEquals(RwdModalheader.isDisplayed(), true);
							logger.info("Goal header is showing #Pass");
							Assert.assertEquals(goaldiscl.isDisplayed(), true);
							logger.info("disclaimer text info is showing #Pass");
							
							Assert.assertEquals(Rwdsetgoal.isDisplayed(), true);
							logger.info(" Set goal button  is present #Pass");
							 
							Assert.assertEquals(Rwdmodalinfo.isDisplayed(), true);
							logger.info("Goal header info is showing #Pass");
							
							Assert.assertEquals(Rwdgoalclose.isDisplayed(), true);
							logger.info("closeicon is seen on the showing #Pass");
							ClickOnWebElement(Rwdgoalclose);
													
							logger.info(
									"verify user able to click on the close icon to close the set reading goal pop-up #Pass");
							Screenshots.takeScreenshot(driver, "Screenshots/setgoal/popuppage.png");
							waitFor(3000);
							

						}

					}
				} else {
					logger.info("No Insights are displayed #Pass");
					Screenshots.takeScreenshot(driver, "Screenshots/insights/Noinsights.png");
				}
			}
			
			
			
			
			
			
			
			
			}
			 


	

	


