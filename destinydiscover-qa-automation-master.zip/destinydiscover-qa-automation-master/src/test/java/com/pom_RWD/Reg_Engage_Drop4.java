package com.pom_RWD;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.base.CapabilitiesAndWebDriverUtils;

public class Reg_Engage_Drop4 extends CapabilitiesAndWebDriverUtils{
	
	public Reg_Engage_Drop4() {
		PageFactory.initElements(driver, this);
	}

	public void schoolname() {
		Assert.assertTrue(ElementisPresent(schoolname),
				" School name should show above the news and announcements widget is not displayed #Fail");
		logger.info("School name should show above the news and announcements widget is displayed #Pass");
		Assert.assertTrue(ElementisPresent(newsWidget_header), "News and Announcement header is not displayed #Fail");
		logger.info("News and Announcement header is displayed #Pass");

	}

	public void seeall() {
		Assert.assertTrue(ElementisPresent(seeall),
				" user able to see all in Learning Resources  is not displayed #Fail");
		logger.info("user able to see all in Learning Resources  is displayed #Pass");
		Assert.assertTrue(ElementisPresent(learn), "Learning Resources header is not displayed #Fail");
		logger.info(" Learning Resources is displayed #Pass");

	}

	public void viewlearningname() {
		Assert.assertTrue(ElementisPresent(view),
				" user able to see all in Learning Resources  is not displayed #Fail");
		logger.info("user able to see all in Learning Resources  is displayed #Pass");
		Assert.assertTrue(ElementisPresent(learn), "Learning Resources header is not displayed #Fail");
		logger.info(" Learning Resources is displayed #Pass");

	}
	
	public void Addicon() {
		waitFor(7000);
		// TODO Auto-generated method stub
		ClickOnWebElement(RWDMessagecenter);
		waitFor(6000);
		logger.info("Login into message Center! You have  Messages! #Pass");
		ClickOnWebElement(xclose);
		logger.info("clicked on + close into message Center! #Pass");
		waitFor(6000);
		
	}

	public void nomsg() throws IOException {

		waitFor(7000);
		ClickOnWebElement(RWDMessagecenter);
		if (ElementisPresent(RWDnoMessages.get(0))) {
			ClickOnWebElement(msgclose);
		} else {
			logger.info("Login into Message Center #Pass");
			
		}

	}
	
	public void popupclose() throws IOException {
		// TODO Auto-generated method stub
		waitFor(3000);
		if (ElementisPresent(Rwdinsights)) {
			for (int i = 0; i < RwdInsights.findElements(By.tagName("fss-ms-insights")).size(); i++) {
				if (RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed()) {
					ClickOnWebElement(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i));
					Assert.assertEquals(RwdInsights.findElements(By.tagName("fss-ms-insights")).get(i).isDisplayed(),
							true);
					ClickOnWebElement(Rwdgoalclose);
					logger.info(
							"verify user able to click on the close icon to close the set reading goal pop-up #Pass");
					waitFor(3000);
				}
			}
		} else {
			logger.info("No Insights are displayed #Pass");
			
		}
	}
	
	
	@FindBy(xpath = "//h2[text()='Insights']")
	public WebElement Rwdinsights;
	
	@FindBy(xpath = "//*[@class='insight-item ng-star-inserted']")
	public WebElement RwdInsights;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate icon-keyboard material-icons mat-icon-no-color']")
	public WebElement Rwdgoalclose;
	
	@FindBy(xpath = "//*[@class='lng-lnk-title'][1]")
	public WebElement view;

	@FindBy(xpath = "//*[@id='mat-expansion-panel-header-0']/span[2]")
	public WebElement xclose;

	@FindBy(xpath = "//*[@id='msg-view-chlgdetail']")
	public WebElement viewchanllege;

	@FindBy(xpath = "//*[@class='msg-icon-button icon-bg mr-rgt ng-star-inserted']")
	public WebElement RWDMessagecenter;

	@FindBy(xpath = "//*[contains(text(),'You have no messages')]")
	public List<WebElement> RWDnoMessages;

	@FindBy(xpath="//*[@class='msg-close']")
	public WebElement msgclose;

	@FindBy(xpath = " //*[@class='school-name']")
	public WebElement schoolname;

	@FindBy(xpath = " //h2[text()='Learning Resources']")
	public WebElement learn;

	@FindBy(xpath = "//*[@class='see-all-link ng-star-inserted']")
	public WebElement seeall;

	@FindBy(xpath = "//*[@class='news-banner']/h2")
	public WebElement newsWidget_header;
}
