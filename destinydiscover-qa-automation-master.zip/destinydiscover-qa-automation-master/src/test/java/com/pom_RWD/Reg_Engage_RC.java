package com.pom_RWD;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.joda.time.field.RemainderDateTimeField;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

public class Reg_Engage_RC extends CapabilitiesAndWebDriverUtils {

/*Class reference*/
	
	private static final Logger logger = LogManager.getLogger();
	static ExcelReader reader = new ExcelReader();
	RWD_RP_Smoke rp= new RWD_RP_Smoke();
	RWD_RP rp1= new RWD_RP();
	RWD_RC_Smoke rc = new RWD_RC_Smoke();
	Rwd_RC rc1 = new Rwd_RC();
	RWD_Drop4_ULP home = new RWD_Drop4_ULP();
	Reg_Engage_RP rps=new Reg_Engage_RP();
	
/*Global Varialbles*/	
	
	static String chlngName;
	
	
	public Reg_Engage_RC() {
		PageFactory.initElements(driver, this);
	}
	
/********************************************Reusable Action Methods*************************************************/	
		
	public void navigateToBookclub() {
		waitFor(3000);
		jsClick(RWD_bookClubTab);
		waitFor(5000);
	}
	
	public void challengeTabAssertion() throws IOException {	
		Assert.assertEquals(rc1.RWDaddCTAWeb.isDisplayed(),true);
		logger.info("Challenges tab is selected by Default #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/BookClub_landing.png");
	}
	
	public void navToCreateChallengePage() throws IOException {
		waitFor(5000);
		WaitForWebElement(rc1.RWDaddCTAWeb);
		jsClick(rc1.RWDaddCTAWeb);
		WaitForWebElement(rc1.lbl_createChlgTitle);
		logger.info("User Navigates to Create chalenge Page #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge.png");
	}
	
	public String createChallenge(Boolean multiFriend,Boolean multiTitle) throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		if (multiFriend==false) {
			rc.searchInviteFriends();
		}
		if (multiFriend==true) {
			addMultipleStudent();
		}
		rc.setReminder(false);
		chlngEndDate(true);
		if (multiTitle==false) {
			rc.addTitle();
		}
		if (multiTitle==true) {
			addMultipleTitle();
		}
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		waitFor(13000);
		jsClick(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Create challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Challenge created Sucessfully #Pass");
		}
		return chlngName;
	}
	
	public void chlngEndDate(Boolean date) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		waitFor(3000);
		jsClick(rc.RWDcalenderImage);
		logger.info("End date calander is opened #Pass");
		waitFor(1000);
		if(date==true) {
			String futureDate = Integer.toString(getNextDate());
			WebElement ed = driver.findElement(By.xpath("//div[text()=' " + futureDate + " ']"));
			waitFor(1000);
			jsClick(ed);
			waitFor(1000);
		}
		if (date==false) {
			String currenttDate = Integer.toString(getCurrentDate());
			WebElement sd = driver.findElement(By.xpath("//div[text()=' " + currenttDate + " ']"));
			waitFor(1000);
			jsClick(sd);
			waitFor(1000);
		}
	}
		
	public int getCurrentDate()
	{
	    Calendar calendar = Calendar.getInstance();
	    Date today = calendar.getTime();
	    calendar.add(Calendar.DAY_OF_YEAR, 0);
	    Date tomorrow = calendar.getTime();
		return tomorrow.getDate();	
	}
	
	public int getNextDate()
	{
	    Calendar calendar = Calendar.getInstance();
	    Date today = calendar.getTime();
	    calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrow = calendar.getTime();
		return tomorrow.getDate();	
	}
	
	public void clickOnCrossIcon() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		ClickOnWebElement(RWD_CloseIcon);
		ClickOnWebElement(RWD_CloseOkButton);
		waitFor(2000);
		try {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("clicking on close icon close the CC page #Fail");		
			Assert.assertTrue(false);
		} catch (Exception e) {
			logger.info(" clicking on close icon close the CC page #Pass");
		}
	}
	
	public void saveChallengeMandatoryFieldcheck() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		javascriptScroll(rc1.RWD_AddTitleCTA);
		ClickOnWebElement(rc1.RWDstartChalnge);
		Assert.assertEquals(errorTitlemsg.isDisplayed(), true);
		logger.info("Mandatory field validations are in place for Saving challenges #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/MandatoryFieldI/P.png");

	}
	
	public void saveChallenge() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		chlngEndDate(true);
		rc.addTitle();
		ClickOnWebElement(rc1.save);
		waitFor(4000);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/SaveChallenge.png");
		logger.info("save challenge button is clicked #Pass");
	//	if(lbl_CreateChallenge.isDisplayed()==true) {
		try {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("Save challenge clicked but Challenge not Saved ");		
//			Assert.assertTrue(false);
		} 
//		else {
		catch (Exception a) {
			jsClick(RWD_bookClubTab);
			waitFor(5000);
			for (int i = 0; i <= 10; i++) {
				waitFor(2000);
				javaScriptScrollToEnd();
				waitFor(2000);
				javascriptScroll(lbl_ActiveChallenge);
				try {
					WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedPrograms + "')]"));
					javascriptScroll(footer);
					waitFor(2000);
					javascriptScroll(ss);
					break;
				} catch (Exception e) {
					javascriptScroll(footer);
					waitFor(2000);
				}
			}
		}	
		javascriptScroll(lbl_draftChallenges);
		for (int i = 0; i<=draftChallenges.size()-1; i++) {
			try {
				if(draftChallenges.get(i).getText().equals(chlngName)) {
					logger.info("Save challenge is Displayed in listing page #Pass ");
					break;
				}
				else {
					logger.info("Searching again for Saved challenge ");
				}
			}catch (Exception e) {
				
			}
		}
	}
	
	public void duplicateChallenegNameValidation(Boolean type) throws InvalidFormatException, IOException {
		waitFor(2000);
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		chlngEndDate(true);
		rc.addTitle();
		if(type==true) {
			ClickOnWebElement(rc1.save);
		}
		if (type==false) {
			ClickOnWebElement(rc1.RWDstartChalnge);
		}
		Screenshots.takeScreenshot(driver, "Screenshots/RC/SaveChallenge/duplicateChallengeToast.png");
		try {
			Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
			logger.info("User Not able to save the challenge with duplicate name");		
		} catch (Exception e) {
			Assert.assertTrue(lbl_rcDetailsPageHeader.isDisplayed());
			logger.info("User able to save the challenge with duplicate name");
			Assert.assertTrue(false);
		}
	}
	
	public void chlEndDtValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		chlngEndDate(false);
		try {
			Assert.assertTrue(RWD_CalenderMonth.isDisplayed());
			logger.info("User not able to set currentdate as end date");		
			Screenshots.takeScreenshot(driver, "Screenshots/RC/StartChallenge/currentDate.png");		
		} catch (Exception e) {
			logger.info("User able to set current date as end date");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/StartChallenge/currentDate.png");		
			Assert.assertTrue(false);
		}
	}
	
	public void addMultipleStudent() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Add multiple students to the challenge vaildation started--");
		waitFor(2000);
		ClickOnWebElement(rc1.RWDaddfriendCTA);
		jsClick(rc1.RWD_SearchStudentName);
		SendKeysOnWebElement(rc1.RWD_SearchStudentName, testData.get(0).get("studentName"));
		waitFor(15000);			
		for(int i=0;i<=rc1.btn_inviteList.size()-1;i++) {
			ClickOnWebElement(rc1.btn_inviteList.get(i));
		}
		if(rc1.addedStudentList.size()!=0) {
			logger.info("Multiple students to the challenge #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/MultiFriends.png");		
			ClickOnWebElement(rc1.RWDAddToChallenge);			
		}
	}
	
	public void addMultipleTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Add title assertion started--");
		waitFor(1000);
		logger.info("Add title to challenge header is present #Pass");
		jsClick(rc1.RWD_AddTitleCTA);
		waitFor(3000);
		SendKeysOnWebElement(rc1.RWDSearchInput, testData.get(3).get("titleName"));
		logger.info("Title name is entered #Pass");
		SendKeysEnter(rc1.RWDSearchInput);
		waitFor(19000);
		for (int i = 0; i<=5; i++) {
			jsClick(RWDMoreMenulist.get(i));
			ClickOnWebElement(rc1.AddToChallengeTitle);
		}
	}
	
	public void saveChanges()
	{
		waitFor(3000);
		ClickOnWebElement(rc1.save);
	}
		
	public void addTitleFromDiscoverPage_Rc() throws IOException {
		waitFor(5000);
		for (int i = 0; i<=RWD_MoreIcon.size()-1; i++) {
			try {
				jsClick(RWD_MoreIcon.get(i));
				ClickOnWebElement(RWD_includeInNewChallenge);
				logger.info(getData("platformName")+" - User Clicked on Include in new Challenge option in Discover Page");
				break;
			} catch (Exception e) {
				logger.info(getData("platformName")+" - Add to new Challenge option is not available for this title");
			}
		}
		WaitForWebElement(lbl_CreateChallenge);
		Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Challenge Screen");
		waitFor(3000);
		javascriptScroll(rc.RWDcalenderImage);
		waitFor(3000);
		Assert.assertTrue(RWD_addedTitleRC.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Challenge Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/DiscoverPage/AddNewTitle_RC.png");
		waitFor(3000);
	}
	
	public void addTitleFromHomePage_Rc() throws IOException {
		javascriptScroll(basedOnPrefCarousel);
//		WaitForWebElement(homePageMoreIcon);
		for (int i = 0; i<=homePageMoreIcon.size()-1; i++) {
			try {
				jsClick(homePageMoreIcon.get(i));
				ClickOnWebElement(RWD_includeInNewChallenge);
				logger.info(getData("platformName")+" - User Clicked on Include in new Challenge option in Home Page");
				break;
			} catch (Exception e) {

			}
		}
		WaitForWebElement(lbl_CreateChallenge);
		Assert.assertTrue(lbl_CreateChallenge.isDisplayed());
		logger.info(getData("platformName")+" - User navigates to Create Challenge Screen");
		waitFor(3000);
		javascriptScroll(rc.RWDcalenderImage);
		waitFor(3000);
		Assert.assertTrue(RWD_addedTitleRC.isDisplayed());
		logger.info(getData("platformName")+" - User Able to see the added title Create Challenge Screen #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/HomePage/AddNewTitle_RC.png");
		waitFor(3000);
	}
	
	public void ReportAbusevalidation() throws InvalidFormatException, IOException {
	    List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "MessageCenter");
	    waitFor(3000);
	    for (int i = 0; i <= msgHeader.size(); i++) {
	        waitFor(3000);
	        try {
	            if (msgHeader.get(i).getText().equalsIgnoreCase("Abuse report submitted")) {
	                Assert.assertEquals(msgHeader.get(i).getText(), testData.get(7).get("InviteMessage"));
	                ClickOnWebElement(msgHeader.get(i));
	                waitFor(7000);
	                if (RwdmsgDetails.get(i).getText()
	                        .contains(chlngName)) {
	                    logger.info("User is able to view message for Scenario- RC Abuse reported #Pass");
	                    ClickOnWebElement(msgHeader.get(i));
	                    break;
	                } else {
	                    ClickOnWebElement(msgHeader.get(i));
	                }
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {

	            System.out.println("The index you have entered is invalid skip ");
	        }
	    }
	}
	
	public void addNewPariticipantMsg() throws InvalidFormatException, IOException {
	    List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "MessageCenter");
	    waitFor(3000);
	    for (int i = 0; i <= msgHeader.size(); i++) {
	        waitFor(3000);
	        try {
	            if (msgHeader.get(i).getText().equalsIgnoreCase("You've been invited!")) {
	            	System.out.println("inside abuse validation");
	                Assert.assertEquals(msgHeader.get(i).getText(), testData.get(0).get("InviteMessage"));
	                ClickOnWebElement(msgHeader.get(i));
	                waitFor(7000);
	                System.out.println("1 :"+RWD_RC_Smoke.chlngName);
	                if (RwdmsgDetails.get(i).getText()
	                        .contains(RWD_RC_Smoke.chlngName)) {
	                	System.out.println(RWD_RC_Smoke.chlngName);
	                    logger.info("User is able to view message for added new participant- RC New Participant #Pass");
	                    ClickOnWebElement(msgHeader.get(i));
	                    break;
	                } else {
	                    ClickOnWebElement(msgHeader.get(i));
	                }
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {

	            System.out.println("The index you have entered is invalid skip ");
	        }
	        if(i==msgHeader.size()) {
	        	break;
	        }
	    }
	}
	
	public void removePariticipantMsg() throws InvalidFormatException, IOException {
	    List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "MessageCenter");
	    waitFor(3000);
	    for (int i = 0; i <= msgHeader.size(); i++) {
	        waitFor(3000);
	        try {
	            if (msgHeader.get(i).getText().equalsIgnoreCase("Removed from Reading Challenge")) { //need to paste the proper message
	            	System.out.println("inside abuse validation");
	                Assert.assertEquals(msgHeader.get(i).getText(), testData.get(11).get("InviteMessage"));
	                ClickOnWebElement(msgHeader.get(i));
	                waitFor(7000);
	                if (RwdmsgDetails.get(i).getText()
	                        .contains(RWD_RC_Smoke.chlngName)) {
	                	System.out.println(RWD_RC_Smoke.chlngName);
	                    logger.info("User is able to view message for removed the participant- RC Participant removed #Pass");
	                    ClickOnWebElement(msgHeader.get(i));
	                    break;
	                } else {
	                    ClickOnWebElement(msgHeader.get(i));
	                }
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {

	            System.out.println("The index you have entered is invalid skip ");
	        }
	        if(i==msgHeader.size()) {
	        	break;
	        }
	    }
	}

	public void ReportAbuseDelete() throws InvalidFormatException, IOException {
		System.out.println("report abuse delete");
	    waitFor(3000);
	    for (int i = 0; i <= msgHeader.size(); i++) {
	        waitFor(3000);
	        try {
	            if(msgHeader.get(i).getText().equalsIgnoreCase(RWD_RC_Smoke.chlngName)) {
	               ClickOnWebElement(msgHeader.get(i));
	               waitFor(7000);
	               Assert.assertTrue(msgDelete.get(i).getText().contains("This reading challenge has been deleted."));
	               logger.info("User is able to view message for Scenario- Abuse report Deleted #Pass");
	               break;
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("The index you have entered is invalid skip ");
	        }
	    }
	}
	
	public void noActionNeedMsg() throws InvalidFormatException, IOException {
	    List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "MessageCenter");
	    waitFor(3000);
	    for (int i = 0; i <= msgHeader.size(); i++) {
	        waitFor(3000);
	        try {
	            if (msgHeader.get(i).getText().equalsIgnoreCase("Participant Removed")) { //need to paste the proper message
	            	System.out.println("inside No Action Needed validation");
	                Assert.assertEquals(msgHeader.get(i).getText(), testData.get(11).get("InviteMessage"));
	                ClickOnWebElement(msgHeader.get(i));
	                waitFor(7000);
	                if (RwdmsgDetails.get(i).getText()
	                        .contains(RWD_RC_Smoke.chlngName)) {
	                	System.out.println(RWD_RC_Smoke.chlngName);
	                    logger.info("User is able to view message received for No action needed- Admin #Pass");
	                    ClickOnWebElement(msgHeader.get(i));
	                    break;
	                } else {
	                    ClickOnWebElement(msgHeader.get(i));
	                }
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {

	            System.out.println("The index you have entered is invalid skip ");
	        }
	        if(i==msgHeader.size()) {
	        	break;
	        }
	    }
	}
	
	public String createChallengeWithOutAddingStudents() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		
		rc.setReminder(false);
		chlngEndDate(true);
		rc.addTitle();
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Create challenge with out adding student validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/CCwithoutStudents.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/CCWithoutStudents.png");
			logger.info("Challenge created Sucessfully #Pass");
		}
		return chlngName;
	}
	
	public String addTitlesinNewChallengefromMystuffCheckout() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(rps.Mystuff);
		waitFor(3000);
		ClickOnWebElement(rps.checkout);
		waitFor(13000);
		rps.searchrecommendtitles = rps.checkouttitlelist.get(0).getText();
		int count = rps.checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" +rps.searchrecommendtitles);
		jsClick(rps.moreMenuSearchPage.get(0));
		jsClick(includeNewChallenge_btn);
		waitFor(3000);
		
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		rc.searchInviteFriends();
		rc.setReminder(false);
		chlngEndDate(true);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Titles Added from mystuff-checkout and creating new challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Titles Added from mystuff-checkout and creating new challenge validation Completed #Pass");
		}
		return chlngName;	
	}
	
	public String addTitlesinNewChallengefromMystuffHistory() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(rps.Mystuff);
		waitFor(3000);
		ClickOnWebElement(rps.history);
		waitFor(3000);
		rps.searchrecommendtitles = rps.checkouttitlelist.get(0).getText();
		int count = rps.checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" +rps.searchrecommendtitles);
		jsClick(rps.moreMenuSearchPage.get(0));
		jsClick(includeNewChallenge_btn);
		waitFor(3000);
		
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		rc.searchInviteFriends();
		rc.setReminder(false);
		chlngEndDate(true);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Titles Added from mystuff-history and creating new challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Titles Added from mystuff-history and creating new challenge validation Completed #Pass");
		}
		return chlngName;	
	}
	
	public String addTitlesinNewChallengefromMystuffFavorites() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(rps.Mystuff);
		waitFor(3000);
		ClickOnWebElement(rps.favourites);
		waitFor(3000);
		rps.searchrecommendtitles = rps.checkouttitlelist.get(0).getText();
		int count = rps.checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" +rps.searchrecommendtitles);
		jsClick(rps.moreMenuSearchPage.get(0));
		jsClick(includeNewChallenge_btn);
		waitFor(3000);
		
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		rc.searchInviteFriends();
		rc.setReminder(false);
		chlngEndDate(true);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Titles Added from mystuff-history and creating new challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Titles Added from mystuff-history and creating new challenge validation Completed #Pass");
		}
		return chlngName;	
	}
	
	public String addTitlesinNewChallengefromMystuffHold() throws Exception {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(rps.Mystuff);
		waitFor(3000);
		ClickOnWebElement(hold);
		waitFor(3000);
		rps.searchrecommendtitles = rps.checkouttitlelist.get(0).getText();
		int count = rps.checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" +rps.searchrecommendtitles);
		jsClick(rps.moreMenuSearchPage.get(0));
		jsClick(includeNewChallenge_btn);
		waitFor(3000);
		
		logger.info("-- Create challenge validation started--");	
		Assert.assertEquals(rc1.ChallengenamePlaceholder.getText(), testData.get(0).get("defval_ChlgNamTxtBox"));
		chlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, chlngName);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeName.png");
		logger.info("Challenge name text box is available and Challenge name is Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngNameChar), true);
		logger.info("Challenge name character count is present #Pass");
		Assert.assertEquals(rc1.ChallengedescPlaceholder.getText(), testData.get(0).get("defval_ChlgDescTxtBox"));
		SendKeysOnWebElement(rc1.RWDChallengedescriptiontextbar, testData.get(0).get("Challenge Desc"));
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/ChallengeDescription.png");
		logger.info("Challenge Description text box is available and Challenge Description Entered #Pass");
		Assert.assertEquals(ElementisPresent(rc1.chlngDescChar), true);
		logger.info("Challenge description character count is present #Pass");
		rc.searchInviteFriends();
		rc.setReminder(false);
		chlngEndDate(true);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
		ClickOnWebElement(rc1.RWDstartChalnge);
		Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge1.png");
		logger.info("Start challenge button is clicked #Pass");
		logger.info("-- Titles Added from mystuff-history and creating new challenge validation Completed--");
		waitFor(3000);
		try {
			Assert.assertTrue(rc1.RWDstartChalnge.isDisplayed());
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Start button clicked but Challenge is not created Sucessfully #Fail");
			Assert.assertTrue(false);
		} catch (Exception e) {
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/StartChallenge.png");
			logger.info("Titles Added from mystuff-history and creating new challenge validation Completed #Pass");
		}
		return chlngName;	
	}
	
	public void challengeSearchAdmin() {
		for(int i=0; i<= 5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_reportedChallenges);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			}
			catch (Exception e){
				System.out.println("Scrolling again for click");
				javascriptScroll(footer);
				waitFor(2000);
			}	
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
		logger.info(ss.getText()+" is found in challenge listing screen and opened #Pass");
		jsClick(ss);
	}
	
	public void readingProgress() throws IOException {
		waitFor(10000);
		javascriptScroll(detailsPglbl_ReadingList);
		if(detailsPgReadingList.size()==readingTitleProgress.size()) {
			Assert.assertTrue(true);
			logger.info("Progress percentage is shown Under titles #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/Progress.png");			
		}
		else {
			logger.info("Progress percentage is Not shown for all the titles");
// 			Assert.assertTrue(false);
		}
		javascriptScroll(lbl_Participants);
		Assert.assertEquals(participantsList.get(0).isDisplayed(), true);
		Assert.assertEquals(participantProgress.get(0).isDisplayed(), true);		
		logger.info("Creator can able to see his progress #Pass");
		if(participantsList.size()==participantProgress.size()) {
			Assert.assertTrue(true);
			logger.info("Progress is shown for both creator and participants #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/CreateChallenge/Progress.png");			
		}
		else {
			logger.info("Progress is Not shown for all the participants");
			Assert.assertTrue(false);
		}
	}
	
	public void closeChallenge() {
		waitFor(5000);
		Assert.assertTrue(closeChallengeBtn.isDisplayed());
		ClickOnWebElement(closeChallengeBtn);
		waitFor(5000);
		ClickOnWebElement(closeChallengePopUpOKBtn);
		waitFor(2000);
	}
	
	public void closedChallengeDisplayChcek() {
		jsClick(RWD_bookClubTab);
		waitFor(15000);
		for (int i = 0; i<=5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_draftChallenges + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		javascriptScroll(lbl_ActiveChallenge);
		for (int i = 0; i<= activeChallenges.size()-1; i++) {
			System.out.println("searching for: "+chlngName);
			if (activeChallenges.get(i).getText().equals(chlngName)) {	
				logger.info("Closed Challenge seen in Active challenges list");
				Assert.assertTrue(false);	
			} else {
				System.out.println("Found : "+activeChallenges.get(i).getText());
				Assert.assertTrue(true);
			}
		}	
		
		logger.info("Closed Challenge Not seen in Active challenges list #Pass");
	}	
	
	public void leaveChallenge() {
		waitFor(5000);
		Assert.assertTrue(leaveChallengeBtn.isDisplayed());
		ClickOnWebElement(leaveChallengeBtn);
		waitFor(5000);
		ClickOnWebElement(closeChallengePopUpOKBtn);
		waitFor(2000);
	}
	
	public void searchandClickActiveChallenge() {
		ClickOnWebElement(RWD_bookClubTab);
		waitFor(15000);
		for (int i = 0; i<=5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedChallenges + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		for (int i = 0; i<=activeChallenges.size()-1 ; i++) {
			System.out.println("searching for: "+chlngName);
			System.out.println("Found: "+activeChallenges.get(i).getText());			
			if (activeChallenges.get(i).getText().equals(chlngName)) {
				jsClick(activeChallenges.get(i));
				logger.info("Challenge found and clicked to navigate #Pass");		
				waitFor(5000);
			}
		}
	}
	
	public void editChallenge(Boolean type) throws IOException {
		waitFor(3000);
		if (type==true) {
			WaitForWebElement(editChallengeBtn);
			ClickOnWebElement(editChallengeBtn);
			waitFor(2000);
		}
		ClickOnWebElement(rc1.RWDChallengenametextbar);
		rc1.RWDChallengenametextbar.clear();
		String editedChlngName = challengeName();
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, editedChlngName);
		if (type==true) {
			ClickOnWebElement(rc1.RWDsaveChallenges);
		}
		if (type==false) {
			ClickOnWebElement(rc1.RWDstartChalnge);
		}
		waitFor(10000);
		Assert.assertTrue(detailsPgChallengeName.isDisplayed());
		Assert.assertEquals(detailsPgChallengeName.getText(), editedChlngName);
		logger.info("Edited content is reflected in Details page #Pass");		
		Screenshots.takeScreenshot(driver, "Screenshots/RC/EditChallenge/edited.png");			
	}
	
	public void searchandClickDraftChallenge() {
		ClickOnWebElement(RWD_bookClubTab);
		waitFor(15000);
		for (int i = 0; i<=5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedChallenges + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		for (int i=0; i<= draftChallengesList.size()-1 ; i++) {
			System.out.println("searching for: "+chlngName);
			System.out.println("Found: "+draftChallenges.get(i).getText());			
			if (draftChallengesList.get(i).getText().equals(chlngName)) {
				jsClick(draftChallengesList.get(i));
				logger.info("Challenge found and clicked to navigate #Pass");		
				waitFor(5000);
			}
		}
	}
	
	public void activechallengeValidation() throws IOException, Exception {
		if (activeChallenges.size()!=0) {
			jsClick(activeChallenges.get(0));
			waitFor(5000);
			String displayDate = detailsPgReadByDt.getText();
			System.out.println(displayDate);
			SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = s.parse(displayDate);
			LocalDate dateObj = LocalDate.now();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			String currentDate = dateObj.format(formatter);
			System.out.println(currentDate);
			Date date2 = s.parse(currentDate);
			System.out.println("currentDate:"+date2);
			if (date1.compareTo(date2) > 0) {
				logger.info(" -Active Challenge end date should be future date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/RC/ActiveChlng.png");
			} else {
				Assert.assertTrue(false);
			}
			logger.info("User able to see the active challenges under active challenges section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/ActiveChl.png");
		}
		else {
			logger.info("User dont have Active Challenge to navigate #Pass");		
			Screenshots.takeScreenshot(driver, "Screenshots/RC/NoActivechl.png");
		}
		
	}
	
	public void draftChallengeValidation() {
		waitFor(5000);
		for (int i = 0; i <=5; i++) {
			waitFor(1000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedChallenges + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		javascriptScroll(lbl_draftChallenges);
		jsClick(lbl_draftChallenges);
		if (draftChallenges.size()!=0) {
			logger.info("Draft Challenge : "+draftChallengesList.get(0).getText());					
			logger.info("User have Draft Challenge to Display #Pass");	
			Assert.assertTrue(true);

		} else {
			logger.info("User dont have Draft Challenge to Display #Pass");		
			Assert.assertTrue(false);
		}
		
	}
	
        public void closedChallengeValidation() throws Exception {
		waitFor(5000);
		for (int i = 0; i <=5; i++) {
			waitFor(1000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + lbl_closedChallenges + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			} catch (Exception e) {
				javascriptScroll(footer);
				waitFor(2000);
			}
		}
		javascriptScroll(lbl_closedChallenges);
		jsClick(lbl_closedChallenges);
		if (closedChallengesList.size()!=0) {
			jsClick(closedChallengesList.get(0));
			waitFor(5000);
			String displayDate = detailsPgReadByDt.getText();
			System.out.println(displayDate);
			SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = s.parse(displayDate);
			LocalDate dateObj = LocalDate.now();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			String currentDate = dateObj.format(formatter);
			System.out.println(currentDate);
			Date date2 = s.parse(currentDate);
			System.out.println("currentDate:"+date2);
			if (date1.compareTo(date2) < 0) {
				logger.info(" -Closed Challenge end date should be past date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/RC/ClosedChlng.png");
			} else if (date1.compareTo(date2) > 0){
				logger.info(" - Challenge closed before end date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/RC/ClosedChlng.png");
			}else {
				logger.info(" - Challenge closed before end date  #Pass");
				Screenshots.takeScreenshot(driver, "Screenshots/RC/ClosedChlng.png");
			}
			logger.info("User able to see the Closed challenges under closed challenges section #Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/RC/ClosedChl.png");
		}
		else {
			logger.info("User dont have closed Challenge to navigate #Pass");		
			Screenshots.takeScreenshot(driver, "Screenshots/RC/NoclosedChlng.png");
			Assert.assertTrue(false);
		}
	}
	
	public void addsameStudent() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(2000);
		jsClick(rc.RWDaddfriendCTA);
		jsClick(rc.RWD_SearchStudentName);
		SendKeysOnWebElement(rc.RWD_SearchStudentName, testData.get(6).get("studentName"));
		System.out.println("User entered: " + testData.get(6).get("studentName"));
		waitFor(12000);
		ClickOnWebElement(invite_btn.get(0));
		String addedcount = addtoChal_btn.getText();
		waitFor(2000);
		ClickOnWebElement(invite_btn.get(0));
		Screenshots.takeScreenshot(driver, "Screenshots/program/addsameStudent.png");
		waitFor(4000);
		String afteraddingsameusercount = addtoChal_btn.getText();
		Assert.assertEquals(addedcount, afteraddingsameusercount);
		logger.info("Verify User is not able to add same Student more than once #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/program/addsameStudent1.png");
	}

	public void removeStudentValidation() throws IOException, InvalidFormatException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(2000);
		jsClick(rc.RWDaddfriendCTA);
		jsClick(rc.RWD_SearchStudentName);
		SendKeysOnWebElement(rc.RWD_SearchStudentName, testData.get(6).get("studentName"));
		System.out.println("User entered: " + testData.get(6).get("studentName"));
		waitFor(4000);
		for (int i = 0; i < invite_btn.size(); i++) {
			ClickOnWebElement(invite_btn.get(i));
		}
		waitFor(3000);
		String beforeremove = addtoChal_btn.getText();
		ClickOnWebElement(studentremove_btn.get(0));
		waitFor(7000);
		String afterremove = addtoChal_btn.getText();
		if (afterremove.equalsIgnoreCase(beforeremove)) {
			logger.info("Remove Friend in Search Page ##Fail");
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudent.png");

		} else {
			if (beforeremove != afterremove)
				;
			logger.info("Remove Friend in Search Page ##Pass");
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudent.png");
		}
		ClickOnWebElement(addtoChal_btn);
		waitFor(8000);
		int beforeremovecount = stuentsremovebtninccpage.size();
		System.out.println("before:"+beforeremovecount);
		ClickOnWebElement(stuentsremovebtninccpage.get(0));
		Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudentpopup.png");
		waitFor(2000);
		Assert.assertTrue(popupdes.isDisplayed());
		Assert.assertTrue(popupcancel_btn.isDisplayed());
		ClickOnWebElement(popupremove_btn);
		waitFor(7000);
		int afterremovecount = stuentsremovebtninccpage.size();
		System.out.println("after:"+afterremovecount);
		if (afterremovecount == beforeremovecount) {
			logger.info("Remove Friend From Create Challenge Page ##Fail");
			Assert.assertTrue(false);
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudentfromccpage.png");
		} else {
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudentfromccpage.png");
			logger.info("Remove Friend From Ceate challenge Page ##Pass");
		}

	}

	public void addsameTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		jsClick(rc.RWD_AddTitleCTA);
		WaitForWebElement(rc.RWDSearchInput);
		waitFor(3000);
		// Assert.assertEquals(searchTitleHeader.getText(),
		// testData.get(0).get("defval_searchTitleHeader"));
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle.png");
		logger.info("Title search header is available #Pass");
		SendKeysOnWebElement(rc.RWDSearchInput, testData.get(0).get("titleName"));
		Screenshots.takeScreenshot(driver,
				"Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_SuggestedResult.png");
		logger.info("Suggested result header is available #Pass");
		SendKeysEnter(rc.RWDSearchInput);
		logger.info("Title name is entered #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_SearchResult.png");
		waitFor(3000);
		jsClick(rc.RWDMoreMenu);
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_MoreMenu.png");
		logger.info("More menu is clicked for the titile #Pass");
		ClickOnWebElement(rc.AddToChallengeTitle);
		waitFor(2000);
		jsClick(rc.RWDMoreMenu);
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_MoreMenu.png");
		try {
			rc.AddToChallengeTitle.isDisplayed();
			ClickOnWebElement(rc.AddToChallengeTitle);
			logger.info("Same title again added #Fail");
		} catch (Exception e) {
			removefromchalng_btn.isDisplayed();
			logger.info("Same title not able to add again  #Pass");

		}

	}
	
	public void removeTitleValidation() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		jsClick(rc.RWD_AddTitleCTA);
		WaitForWebElement(rc.RWDSearchInput);
		waitFor(3000);
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle.png");
		logger.info("Title search header is available #Pass");
		SendKeysOnWebElement(rc.RWDSearchInput, testData.get(3).get("titleName"));
		Screenshots.takeScreenshot(driver,
				"Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_SuggestedResult.png");
		logger.info("Suggested result header is available #Pass");
		SendKeysEnter(rc.RWDSearchInput);
		logger.info("Title name is entered #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/AddTitle_SearchResult.png");
		waitFor(17000);
		for(int i=0;i<2;i++) {
			jsClick(RWDMoreMenulist.get(i));
			ClickOnWebElement(rc.AddToChallengeTitle);
		}
		waitFor(8000);
		int beforeremovecount = titlesremovebtninccpage.size();
		System.out.println("Before: "+beforeremovecount);
		jsClick(titlesremovebtninccpage.get(0));
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/TitleRemovePopup.png");
		waitFor(4000);
		Assert.assertTrue(popupdes.isDisplayed());
		Assert.assertTrue(popupcancel_btn.isDisplayed());
		ClickOnWebElement(popupremove_btn);
		waitFor(7000);
		int afterremovecount = titlesremovebtninccpage.size();
		System.out.println("after:"+afterremovecount);
		if (afterremovecount == beforeremovecount) {
			logger.info("Remove Title From Create Challenge Page ##Fail");
			Assert.assertTrue(false);
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudentfromccpage.png");
		} else {
			if (afterremovecount != beforeremovecount);
			Screenshots.takeScreenshot(driver, "Screenshots/CC/removestudentfromccpage.png");
			logger.info("Remove Title From Ceate challenge Page ##Pass");
		}
		Screenshots.takeScreenshot(driver, "Screenshots/ReadingChalllenge/CreateChallenge/Removetitle.png");
	}
	public void participantDetailsPgValidation() {
		waitFor(5000);
		Assert.assertTrue(prgDetailsPg_Breadcrum.isDisplayed());
		logger.info("Breadcrum is displayed in the details page ##Pass");
		Assert.assertTrue(lbl_rcDetailsPageHeader.isDisplayed());
		logger.info("Reading Challenge text is displayed in the details page ##Pass");
		Assert.assertTrue(detailsPgChallengeName.isDisplayed());
		logger.info("Challenge Name is displayed in the details page ##Pass");
		Assert.assertTrue(detailsPgChallengeDesc.isDisplayed());
		logger.info("Challenge Description is displayed in the details page ##Pass");
		Assert.assertTrue(lbl_PrgcreatedDt.isDisplayed());
		logger.info("Challenge created date is displayed in the details page ##Pass");
		Assert.assertTrue(lbl_PrgcreatorName.isDisplayed());
		logger.info("Challenge Name is displayed in the details page ##Pass");
		Assert.assertTrue(PrgcreatorAvatar.isDisplayed());
		logger.info("Creator avatar is displayed in the details page ##Pass");
		Assert.assertTrue(detailsPgReadByDt.isDisplayed());
		logger.info("Challenge Readby date is displayed in the details page ##Pass");
		Assert.assertTrue(detailsPgChallengeReminder.isDisplayed());
		logger.info("Challenge reminder is displayed in the details page ##Pass");
		Assert.assertTrue(detailsPgChallengeStatus.isDisplayed());
		logger.info("Challenge Status is displayed in the details page ##Pass");
		
	}
	
 	public void you_ve_been_Challenged() {
		//challengeSearch();
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
		logger.info(ss.getText()+" is found in challenge listing screen #Pass");
		int reportedChlng = rc1.reportedChlngs.size();
		for(int i=0; i<=rc1.activeChlngs.size()+reportedChlng; i++) {
			//System.out.println(challengeName.get(i).getText())
			if(rc1.challengeName.get(i).getText().equalsIgnoreCase(ss.getText())) {
				try {
					javascriptScroll(rc1.challengeStatus.get(i-reportedChlng-rc1.acceptedClng.size()-1));
				//	System.out.println(challengeStatus.get(i-reportedChlng).getText());
					Assert.assertEquals(rc1.challengeStatus.get(i-reportedChlng-rc1.acceptedClng.size()-1).getText(),"You've been Invited!");
					logger.info("Challenge status before accept is "+rc1.challengeStatus.get(i-reportedChlng-rc1.acceptedClng.size()-1).getText()+" #Pass");
					jsClick(ss);
					
				}
				catch (ArrayIndexOutOfBoundsException e) {
					logger.info("Challenge status before accept validation is skipped #Fail");
					jsClick(ss);
					break;
				}	
		    }	
	      }
	}
	
	public void challengeSearch() {
		for(int i=0; i<= 5; i++) {
			waitFor(2000);
			javaScriptScrollToEnd();
			waitFor(2000);
			javascriptScroll(lbl_ActiveChallenge);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
				javascriptScroll(footer);
				waitFor(2000);
				javascriptScroll(ss);
				break;
			}
			catch (Exception e){
				System.out.println("Scrolling again for click");
				javascriptScroll(footer);
				waitFor(2000);
			}	
		}
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
		logger.info(ss.getText()+" is found in challenge listing screen and opened #Pass");
		//jsClick(ss);
	}
	
	public void validateAcceptChallenge(boolean accept) throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		logger.info("--Accept or Reject challenge validation started--");
		WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + chlngName + "')]"));
		jsClick(ss);
		WaitForWebElement(rc.readingChallengeName);
		waitFor(5000);
		logger.info("Created challenge details are available for Invited user #Pass");
		Assert.assertTrue(rc.createdDate.isDisplayed(), "Challenge created date is not available");
		logger.info("Challenge Created date is available for Invited user #Pass");
		Assert.assertTrue(rc.participantHeader.isDisplayed(), "Participants header is not available");
		logger.info("Paticipants header is available for Invited user #Pass");
		Assert.assertTrue(rc.Readinglist.isDisplayed(), "Reading list header is not available");
		logger.info("Reading list header is available for Invited user #Pass");
		Assert.assertTrue(rc.RWDchlgAccept.isDisplayed(), "Accept challenge button is not available");
		Assert.assertTrue(rc.RWDchlgNotAccept.isDisplayed(), "Accept challenge button is not available");
		if (accept == true) {
			ClickOnWebElement(rc.RWDchlgAccept);
			waitFor(2000);
			ClickOnWebElement(rc.GotoChlng);
		} else {
			ClickOnWebElement(rc.RWDchlgNotAccept);
		}
		logger.info("--Accept or Reject challenge validation Completed--");

	}
	
	public void editChlngName() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(7000);
		waitForElementClick(rc1.btn_EditChlg);
		logger.info("-- Edited Challenge assertion started --");
		WaitForWebElement(rc1.lbl_editchlgHeader);
		SendKeysOnWebElement(rc1.RWDChallengenametextbar, RWD_RC_Smoke.chlngName + testData.get(0).get("challengeNameEdit") );
		logger.info("Edited Challenge Name #Pass");
		ClickOnWebElement(rc1.save);
	//	Assert.assertEquals(rc1.lbl_readingChallengeName.getText(), chlngName + testData.get(0).get("challengeNameEdit"));
		logger.info("Edited Reading Challenge Name is available #Pass");
       }
	
	public void closeReportAbuse() {
		waitFor(2000);
		ClickOnWebElement(RWD_CloseIcon);
		waitFor(2000);	
	}
	
        public void editAddTitle() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(7000);
		WaitForWebElement(rc1.btn_EditChlg);
		ClickOnWebElement(rc1.btn_EditChlg);
		waitFor(3000);
		WaitForWebElement(rc1.lbl_editchlgHeader);
		logger.info("Add new title to challenge #Pass");
		jsClick(rc1.RWD_AddTitleCTA);
		WaitForWebElement(rc1.RWDSearchInput);
		waitFor(3000);
		SendKeysOnWebElement(rc1.RWDSearchInput, testData.get(4).get("titleName"));
		SendKeysEnter(rc1.RWDSearchInput);
		waitFor(3000);
		jsClick(rc1.RWDMoreMenu);
		ClickOnWebElement(rc1.AddToChallengeTitle);
		logger.info("New Title is added to the challenge #Pass");
		waitFor(3000);
		ClickOnWebElement(rc1.save);
		waitFor(5000);
		WaitForWebElement(rc1.lbl_readingChallengeHeader);
	}
	
	public void editRemoveTitle() throws InvalidFormatException, IOException{
		waitFor(7000);
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RC");
		WaitForWebElement(rc1.btn_EditChlg);
		ClickOnWebElement(rc1.btn_EditChlg);
		logger.info("-- Edited Challenge assertion started --");
		waitFor(3000);
		WaitForWebElement(rc1.lbl_editchlgHeader);
		javascriptScroll(RWDsetReminder);
		waitFor(3000);
		jsClick(removeTitle);
		waitFor(1000);
		WaitForWebElement(removeConfirm);
		ClickOnWebElement(removeConfirm);
		logger.info("Title is removed from the challenge #Pass");
		waitFor(2000);
		jsClick(rc1.RWD_AddTitleCTA);
		WaitForWebElement(rc1.RWDSearchInput);
		waitFor(3000);
		SendKeysOnWebElement(rc1.RWDSearchInput, testData.get(4).get("titleName"));
		SendKeysEnter(rc1.RWDSearchInput);
		waitFor(3000);
		jsClick(rc1.RWDMoreMenu);
		ClickOnWebElement(rc1.AddToChallengeTitle);
		logger.info("New Title is added to the challenge #Pass");
		waitFor(2000);
		jsClick(rc1.save);
		waitFor(5000);
		WaitForWebElement(rc1.lbl_readingChallengeHeader);	
	}
	
	public void editEndDate() throws InvalidFormatException, IOException {
		waitFor(7000);
		WaitForWebElement(rc1.btn_EditChlg);
		ClickOnWebElement(rc1.btn_EditChlg);
		logger.info("-- Edited Challenge assertion started --");
		waitFor(3000);
		WaitForWebElement(rc1.lbl_editchlgHeader);
		chlngEndDate(true);
		logger.info("Ready By date is updated #Pass");
		ClickOnWebElement(rc1.save);
		waitFor(5000);
		WaitForWebElement(rc1.lbl_readingChallengeHeader);
	}
	
	public void editchallenge()
	{
		waitFor(7000);
		WaitForWebElement(rc1.btn_EditChlg);
		ClickOnWebElement(rc1.btn_EditChlg);	
	}
	
	public void addRejectedUser() throws Exception {
		waitFor(7000);
		WaitForWebElement(rc1.btn_EditChlg);
		ClickOnWebElement(rc1.btn_EditChlg);
		logger.info("-- Edited Challenge assertion started --");
		waitFor(3000);
		WaitForWebElement(rc1.lbl_editchlgHeader);
		rc.searchInviteFriends();
		logger.info("Invited the same user who rejected the invitation #Pass");
		ClickOnWebElement(rc1.save);
		waitFor(5000);
		WaitForWebElement(rc1.lbl_readingChallengeHeader);
	}
	
/*****************************************************Locators**************************************************/
	
	@FindBy(xpath="//span[text()='Remove']")
	public WebElement removeConfirm;
	
	@FindBy(xpath="//div[7]//span/button[@class='dd-btnx center-img ng-star-inserted']/mat-icon")
	public WebElement removeTitle;
	
	@FindBy(xpath="//*[text()='Participants ']")
  	public WebElement lbl_Participants;
	
	@FindBy(xpath="//*[text()='Reading List '] ") 
	public WebElement detailsPglbl_ReadingList;
	
	@FindBy(xpath="//*[@class='mat-card mat-focus-indicator reader-poster vertical-poster ng-star-inserted']") //new
	public List<WebElement> detailsPgReadingList;
	
	@FindBy(xpath="//*[@class='progressbar-percentage']") 
	public List<WebElement> readingTitleProgress;
	
	@FindBy(xpath="//*[@class='progress-bar-container']") 
	public List<WebElement> readingTitleProgressBar;
		
	@FindBy(xpath="//*[@id='cd-usr-pertext']")
	public List<WebElement> participantsList;
	
	@FindBy(xpath="//*[@id='cd-user-numper']")
	public List<WebElement> participantProgress;
	
	@FindBy(xpath="//*[@id='close-chalge']")
	public WebElement closeChallengeBtn;
	
	@FindBy(xpath="//button/span[text()='OK']")
	public WebElement closeChallengePopUpOKBtn;
	
	@FindBy(xpath="//h3[text()='DRAFT CHALLENGES ']//preceding::mat-card-title[@class='mat-card-title header-title txt-elipsishead']")
	public List<WebElement> activeChallenges;
	
	@FindBy(xpath="//h3[text()='CLOSED CHALLENGES']//preceding::mat-card-title[@class='mat-card-title header-title txt-elipsishead']")
	public List<WebElement> draftChallengesList;
	
	@FindBy(xpath="//h3[text()='CLOSED CHALLENGES']//following::mat-card-title[@class='mat-card-title header-title txt-elipsishead']")
	public List<WebElement> closedChallengesList;
	
	@FindBy(xpath="//h3[text()='CLOSED CHALLENGES']")
	public WebElement lbl_closedChallenges;
	
	@FindBy(xpath="//*[@id='leave-chalge']")
	public WebElement leaveChallengeBtn;
	
	@FindBy(xpath="//*[@id='chlg-det-editchlge']")
	public WebElement editChallengeBtn;
	
	@FindBy(xpath="//*[@id='chlge-detail-heading']")
	public WebElement detailsPgChallengeName;
	
	@FindBy(xpath="//*[@class='challenge-desc']") 
	public WebElement detailsPgChallengeDesc;
		
	@FindBy(xpath="(//p[@id='cd-ready-rem'])[1]") 
	public WebElement detailsPgChallengeReminder;
	
	@FindBy(xpath="(//p[@id='cd-ready-rem'])[2]")
	public WebElement detailsPgChallengeStatus;
	
	@FindBy(xpath="//*[@id='cd-readby-det']")
	public WebElement detailsPgReadByDt;
	
	@FindBy(xpath="//h3[text()='REPORTED CHALLENGES ']")
	public WebElement lbl_reportedChallenges;
	
	@FindBy(xpath="//*[@class='accordion-msg ng-star-inserted']/h4")
  	public List<WebElement> RwdmsgDetails;
	
	@FindBy(xpath="//*[@class='accordion-msg ng-star-inserted']/p")
   	public List<WebElement> msgDelete;
	
	@FindBy(xpath="//div[@class='content-name-head']/h4")
   	public List<WebElement> msgHeader;
	
	@FindBy (xpath=" //*[text()=' Add to Program ']")
	public WebElement titleAddtoProgram;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public List<WebElement> RWDMoreMenulist;
	
	@FindBy(xpath = "//*[text()='Add Titles ']")
	public WebElement addTitleHeader;
	
	@FindBy(xpath = ".//*[@id='prog-main-create' or contains(text(),'CREATE PROGRAM')]")
   	public WebElement RWD_CreateProgramLink;
	
	@FindBy(xpath="//*[contains(text(),'My Programs')]")
   	public WebElement RWD_myProgramTab;
	
	@FindBy(xpath="//*[text()='Challenges']")
	public WebElement RWD_challengesTab;

	@FindBy(xpath = "//*[contains(text(),'Book Club')]")
	public WebElement RWD_bookClubTab;
	
	@FindBy(xpath="//*[text()='Search']")
	public static WebElement searchPageHeader;
	
	@FindBy(xpath="(//div[@class='carousel-header ng-star-inserted'])[1]//following::mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public static List<WebElement> homePageMoreIcon;
	
	@FindBy(xpath="//*[@class='carousel-header ng-star-inserted'][1]")
	public static WebElement firstCarousel;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public static List<WebElement> RWD_MoreIcon;
	
	@FindBy(xpath = "(//span[@class='mat-button-wrapper'])[2]")
	public static WebElement RWD_CalenderMonth;
	
	@FindBy(xpath = "(//*[@class='user-image'])[2]")
	public static WebElement RWD_addedTitleRC;
	
	@FindBy(xpath = "//*[text()='Create Reading Challenge']")
	public static WebElement lbl_CreateChallenge;
	
	@FindBy(xpath = "//*[text()='ACTIVE CHALLENGES ']")
	public static WebElement lbl_ActiveChallenge;
	
	@FindBy(xpath = "//*[text()=' Include in a New Challenge ']")
	public static WebElement RWD_includeInNewChallenge;
	
	@FindBy(xpath = "(//*[@class='user-image'])[2]")
	public static WebElement RWD_addedTitle;
	
	@FindBy(xpath = "(//*[text()='close'])[2]")
	public static WebElement RWD_CloseIcon;
	
	@FindBy(xpath ="//button/span[text()='OK']")
	public static WebElement RWD_CloseOkButton;
	
	@FindBy(xpath = "(//*[text()='Discover'])[2]")
	public static WebElement RWD_discoverBreadCrum;
	
	@FindBy(xpath = "//*[text()=' Discover ']")
   	public static WebElement RWD_discoverPage;
	
	@FindBy(xpath = "//*[text()=' Fines ']")
	public WebElement  Fines;

	@FindBy(xpath = "//*[text()='You currently have no fines']")
	public WebElement notitlefines;
	
	@FindBy(xpath = "//*[text()=' Favorites ']")
	public WebElement  Favorites;
	
	@FindBy(xpath = "//*[text()='You have no books Favorites']")
	public WebElement notitleFavorites;
	
	@FindBy(xpath = "//*[text()=' Holds ']")
	public WebElement  Holds;
	
	@FindBy(xpath = "//*[text()='You currently have no titles on hold']")
	public WebElement notitleholds;
	
	@FindBy(xpath = "//*[text()='You have no books history']")
	public WebElement notitlehistory;
	
	@FindBy(xpath = "//*[text()=' History ']")
	public WebElement  History;
	
	@FindBy(id = "cprog-close-2")
	public WebElement btn_close;
	
	@FindBy(xpath = "//*[text()=' Include in a New Program ']")
	public WebElement includeNewprg;
	
	@FindBy(xpath = "//*[text()='You have no books checked out']")
	public WebElement notitleCheckout;
	
	@FindBy(xpath = "//*[text()=' Checkouts ']")
	public WebElement  Checkouts;

	@FindBy(xpath = "//*[@aria-label='my stuff menu']")
	public WebElement mystuffmenu;

	
	@FindBy(xpath = "//div[@class='dd-stud-info ng-star-inserted']")
	public List<WebElement> btn_addedStudents;
	
	@FindBy(xpath = "//*[text()='Remove']")
	public WebElement removeconfirm;
	
	@FindBy(id = "ivite-chlg-search")
	public WebElement txt_SearchStudentName;
	
	@FindBy(id = "pd-editprg")
	public WebElement Rwdeditprg;
	
	@FindBy(xpath = "//h2[contains(text(),'Create Reading Program')]")
	public static WebElement Rwddublicatescreen;
	
	@FindBy(id = "pd-duplcate")
	public static WebElement Rwdduplicateprg;
	
	@FindBy(xpath="(//*[@class='mat-card-header-text']/mat-card-title)[1]")
	public static WebElement existing_RP_Name;
	
	@FindBy(xpath="//*[text()='Program name is required. ']")
	public WebElement req_progName;
	
	@FindBy(xpath="//*[text()='Start date is required. ']")
	public WebElement req_startDate;
	
	@FindBy(xpath="//*[text()='End date is required.']")
	public WebElement req_endDate;
	
	@FindBy(xpath="//*[text()='At least one student is required.']")
	public WebElement req_student;
	
	@FindBy(xpath="//*[text()='At least one title is required.']")
	public WebElement req_title;
	
	@FindBy(xpath="//*[text()=' Please fill required fields. ']")
	public WebElement req_fields;
	
	@FindBy(xpath = "//h1[text()='ACTIVE PROGRAMS']")
	public WebElement lbl_Activeprogram;
	
	//@FindBy(xpath = "//p[contains(text(),'© 2021 Follett School Solutions.')]")
	@FindBy(xpath ="//*[@class='text-left']")
	public WebElement footer;
	
	@FindBy( xpath = "//*[@id='pd-readlist-head']//following::button[2]//child::mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")     
	public List<WebElement> ReadingList_moreIcon;      
	
	@FindBy( xpath = "//*[@id='pd-readlist-head']")     
	public WebElement lbl_ReadingList;
	
	@FindBy(xpath="//*[@class='mat-toolbar header main-header mat-primary mat-toolbar-single-row']/mat-list/mat-list-item[1]")
	public static WebElement HomeMenu;
	
	@FindBy(xpath="(//h2[text()='Learning Resources']//preceding::div[@class='carousel-header ng-star-inserted'])")
	public static WebElement basedOnPrefCarousel;
	
	@FindBy(xpath="//*[@class='breadcrumb-item']")
	public static WebElement prgDetailsPg_Breadcrum;
	
	@FindBy(xpath="//h5[@class='bookclubactive']")
	public static WebElement lbl_ReadingPrg;
	
	@FindBy(xpath="//span[@class='createon']")
	public static WebElement lbl_PrgcreatedDt;
	
	@FindBy(xpath="//span[@class='createinfo']")
	public static WebElement lbl_PrgcreatorName;
	
	@FindBy(xpath="//div[@class='challenge-detail-avatar']")
	public static WebElement PrgcreatorAvatar;
	
	@FindBy(xpath="//p[@id='pd-status']")
	public static WebElement lbl_PrgStatus;
	
	@FindBy(xpath="//p[text()='Public']")
	public static WebElement lbl_PrgVisibility;
	
	@FindBy(xpath="//p[text()='Books in Order']")
	public static WebElement lbl_PrgType;
	
	@FindBy(xpath="//p[@class='ng-star-inserted']")
	public static WebElement lbl_PrgReminder;
	
	@FindBy(xpath="//p[@class='challenge-desc']")
	public static WebElement lbl_Prgdesc;
	
	@FindBy(xpath="//*[@aria-label='ACTIVE PROGRAMS']//following::div[@id='dd-Active-contain']")
	public static List<WebElement> activePrograms;
	
	@FindBy(xpath="//*[@aria-label='DRAFT PROGRAMS']//following::div[@id='dd-Save-contain']")
	public static List<WebElement> draftPrograms;
		
	@FindBy(xpath="//*[@aria-label='CLOSED PROGRAMS']//following::div[@id='dd-Complete-contain']")
	public static List<WebElement> closedPrograms;
		
	@FindBy(xpath="//*[@aria-label='ONGOING PROGRAMS']//following::div[@id='dd-Ongoing-contain']")
	public static List<WebElement> ongoingPrograms;
	
	@FindBy(xpath="//*[@aria-label='UPCOMING PROGRAMS']//following::div[@id='dd-Upcoming-contain']")
	public static List<WebElement> upcomingPrograms;
	
	@FindBy(xpath="//*[@aria-label='ACTIVE PROGRAMS']")
	public static WebElement Lbl_activeProgram;
	
	@FindBy(xpath="//*[@aria-label='DRAFT PROGRAMS']")
	public static WebElement lbl_draftPrograms;
	
	@FindBy(xpath="//*[@aria-label='CLOSED PROGRAMS']")
	public static WebElement lbl_closedPrograms;
	
	@FindBy(xpath="//*[@aria-label='ONGOING PROGRAMS']")
	public static WebElement lbl_ongoingPrograms;
	
	@FindBy(xpath="//*[@aria-label='UPCOMING PROGRAMS']")
	public static WebElement lbl_upcomingPrograms;
	
	@FindBy(xpath="//*[@class='challenge-created']")
	public static WebElement ongoingPrg_startDate;
	
	@FindBy(xpath="//*[@id='pd-strt-date']")
	public static WebElement detailsPg_StartDate;
	
	@FindBy(xpath="//*[@id='pd-end-date']")
	public static WebElement detailsPg_endDate;
	
	@FindBy(xpath="//*[@id='pd-ubplish']")
	public static WebElement detailsPg_unPublishbtn;
	
	@FindBy(xpath = "//*[@class = 'mat-card-subtitle subtitle1']")
	public List<WebElement> Readingname;

	@FindBy(xpath = "//*[@class = 'mat-card-title header-title txt-elipsishead']")
	public List<WebElement>  programname;
	
	@FindBy( xpath = "//*[@class ='dd-desc-txt txt-elipsis']")
	public List<WebElement> Cardcontent;
	
	@FindBy( xpath = "//*[@class='mat-focus-indicator submit-btn mat-button mat-button-base']//child::span[text()='OK']")
	public WebElement unPublish_Okbtn;
	
	@FindBy( xpath = "//*[@aria-label='ACTIVE PROGRAMS']//following::div[@id='dd-Active-contain']//following::mat-card-title")
	public List<WebElement> prgName_Titlecard;
	
	@FindBy( xpath = "//*[@aria-label='UNPUBLISHED PROGRAMS']//following::div[@class='mat-card-header-text']//following::mat-card-title")
	public List<WebElement> Unpublish_TitlecardprgName;
	
	@FindBy(xpath = "//*[@class='mat-card-title header-title txt-elipsishead']")
	public WebElement subprogram;
	
	@FindBy(xpath = "//*[@class='mat-card-subtitle subtitle1']")
	public WebElement subTitle;
	
	@FindBy(xpath = "//span[text()='Save']")
	public WebElement btn_save;
	
	@FindBy(xpath = "//*[text()='At least one title is required.']")
	public WebElement errorTitlemsg;
	
	@FindBy(xpath = "//*[@aria-label='Set Reminder'][1]")
	public WebElement RWDsetReminder;
	
	@FindBy(id = "cp-enter-name")
	public WebElement inp_progName;
	
	@FindBy(xpath = "//*[text()='Program name is required. ']")
	public WebElement errorProgrammsg;
	
	@FindBy(xpath = "//*[text()='UNPUBLISHED PROGRAMS']")
	public WebElement unpublished;
	
	@FindBy(xpath = "//*[@aria-label='Open profile options window']")
	public static WebElement menu_profileIcon;
	
	@FindBy(xpath = "//*[text()=' Book Club ']")
	public WebElement RWDbookClubOptionWeb;

	@FindBy(xpath = "//a[@id='tab-myprog-btn']")
	public WebElement lbl_myPrograms;
	
	@FindBy(xpath = "//h1[@id='prog-det-heading']")
	public WebElement programName;
	
	@FindBy(xpath = "//p[@id='pd-strt-date']")
	public WebElement lbl_endDate;

	@FindBy(xpath = "//p[@id='pd-end-date']")
	public WebElement lbl_startDate;
	
	@FindBy(xpath = "//h2[@id='pd-partip-head']")
	public WebElement lbl_participantlist;

	@FindBy(xpath = "//h2[@id='pd-readlist-head']")
	public WebElement lbl_readinglist;
	
	@FindBy(id = "pd-ubplish")
	public WebElement btn_ublish;
	
	@FindBy(xpath = "//*[@class='mat-dialog-content mat-typography']")
	public WebElement removeconfirmpopup;
	
	@FindBy(xpath = "//span[text()='OK']")
	public WebElement confirmunpublish;
	
	@FindBy(xpath = "//span[text()='Publish Program']")
	public WebElement btn_publish;
	
	@FindBy(xpath = "//h3[text()='DRAFT CHALLENGES ']//following::mat-card/mat-card-header[@class='mat-card-header']")
	public List<WebElement> draftChallenges;
	
	@FindBy(xpath = "//h3[text()='DRAFT CHALLENGES ']")
	public WebElement lbl_draftChallenges;
	
	@FindBy(xpath = "//*[text()='Reading Challenge']")
	public WebElement lbl_rcDetailsPageHeader;
	
	@FindBy(xpath = "//*[text()=' Include in a New Challenge ']")
	public WebElement includeNewChallenge_btn;
	
	@FindBy(xpath = "//*[text()=' Holds ']")
	public WebElement hold;
	
	@FindBy(xpath = "//*[@class='raise-invite']")
	public WebElement addtoChal_btn;

	@FindBy(xpath = "//*[@class='student-invite']")
	public List<WebElement> invite_btn;

	@FindBy(xpath = "//*[text()=' Remove from challenge ']")
	public WebElement removefromchalng_btn;

	@FindBy(xpath = "//*[text()='close ']")
	public List<WebElement> studentremove_btn;

	@FindBy(xpath = "//*[text()='Remove']")
	public WebElement popupremove_btn;

	@FindBy(xpath = "//*[@class='mat-dialog-content mat-typography']")
	public WebElement popupdes;

	@FindBy(xpath = "//*[text()='Cancel']")
	public WebElement popupcancel_btn;

	@FindBy(xpath = "//*[@aria-label='Challege friends']/following::*[@class='dd-btnx ng-star-inserted']")
	public List<WebElement> stuentsremovebtninccpage;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public List<WebElement> RWDMoreMenuList;
	
	@FindBy(xpath = "//*[@aria-label='add titles']/following::*[text()='close']")
	public List<WebElement> titlesremovebtninccpage;
	
	@FindBy(id= "start-chalge-btn")
	public WebElement startchal_btn;
	

}
