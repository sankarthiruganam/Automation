package com.pom_RWD;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.ExcelReader;
import com.base.Screenshots;

public class Reg_Engage_RP extends CapabilitiesAndWebDriverUtils {

	/* Class reference */

	static ExcelReader reader = new ExcelReader();
	// static String progName = "Automation_RP"+RandomStringGenerate(2);
	RWD_RP_Smoke rp = new RWD_RP_Smoke();
	RWD_RP r = new RWD_RP();
	Reg_Engage engage = new Reg_Engage();
	Rwd_RC rc=new Rwd_RC();

	/* Global Varialbles */

	public static String searchrecommendtitles;
	public static String activeprogramsearchpage;
	public static String draftprogramname;
	public static String progName1;

	public Reg_Engage_RP() {
		PageFactory.initElements(driver, this);
	}

	/********************************************
	 * Reusable Action Methods
	 ********************************************/

	public void onGoingProgramLeaveProgram() throws IOException {
		waitFor(8000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(6000);
		jsClick(rp.RwdOpenPrograms);
		waitFor(6000);
		Assert.assertEquals(rp.RWDOnGoing.getText(), "ONGOING PROGRAMS");
		logger.info("ONGOING PROGRAMS Tab Availble  #Pass");
		ClickOnWebElement(onGoingprogList.get(0));
		waitFor(7000);
		ClickOnWebElement(joinProgramBtn);
		waitFor(7000);
		ClickOnWebElement(goToProgram);
		waitFor(7000);
		ClickOnWebElement(leaveProgram);
		waitFor(7000);
		ClickOnWebElement(leaveProgramOkBtn);
		waitFor(7000);
		jsClick(rp.RwdBookClub);
		logger.info("Leave Program from ongoing program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/createProgram/showProgram.png");

	}

	public void onGoingProgrmRejectProgram() throws IOException {
		waitFor(8000);
		jsClick(rp.RwdBookClub);
		waitFor(6000);
		ClickOnWebElement(rp.RwdOpenPrograms);
		waitFor(6000);
		Assert.assertEquals(rp.RWDOnGoing.getText(), "ONGOING PROGRAMS");
		logger.info("ONGOING PROGRAMS Tab Availble  #Pass");
		ClickOnWebElement(onGoingprogList.get(0));
		waitFor(3000);
		ClickOnWebElement(nothanksBtn);
		waitFor(3000);
		waitForElementClick(rp.RwdBookClub);
		logger.info("Ongoing Program Reject Program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/OngoingProgram/RejectProgram.png");

	}

	public void onGoingProgramJoinProgram() throws IOException {
		waitFor(8000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(6000);
		ClickOnWebElement(rp.RwdOpenPrograms);
		waitFor(6000);
		Assert.assertEquals(rp.RWDOnGoing.getText(), "ONGOING PROGRAMS");
		logger.info("ONGOING PROGRAMS Tab Availble  #Pass");
		ClickOnWebElement(onGoingprogList.get(0));
		waitFor(3000);
		ClickOnWebElement(joinProgramBtn);
		waitFor(3000);
		ClickOnWebElement(goToProgram);
		waitFor(8000);
		Assert.assertTrue(ElementisPresent(ReadingProgram),
				" Reading Program is  not displayed #Fail");
		
		waitForElementClick(rp.RwdBookClub);
		logger.info("Ongoing Program Join Program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/OngoingProgram/JoinProgram.png");

	}
	
	public void navToMyProgram() {
        waitFor(8000);
        ClickOnWebElement(rp.RwdBookClub);
        waitFor(6000);
        ClickOnWebElement(rp.RwdMyPrograms);
        waitFor(9000);
    }

	public void upComingProgramJoinProgram() throws IOException {
        waitFor(8000);
        jsClick(rp.RwdBookClub);
        waitFor(6000);
        ClickOnWebElement(rp.RwdOpenPrograms);
        waitFor(9000);
        javaScriptScrollToEnd();
        for (int i = 0; i<=5; i++) {
            try {
                javascriptScroll(upcomingProgramlbl);
                jsClick(upcomingProgramlist.get(0));
                break;
            } catch (Exception e) {
                javascriptScroll(driver.findElement(By.xpath("//*[text()='ONGOING PROGRAMS']")));
                waitFor(3000);
                javaScriptScrollToEnd();
                waitFor(2000);
            }
        }
        logger.info("Upcoming Program card Clicked  #Pass");
        waitFor(7000);
        ClickOnWebElement(joinProgramBtn);
        waitFor(3000);
        ClickOnWebElement(goToProgram);
        waitFor(5000);
		Assert.assertTrue(ElementisPresent(ReadingProgram),
				" Reading Program is  not displayed #Fail");
		
//		waitForElementClick(rp.RwdBookClub);
		logger.info("UpComing Program Join Program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/UpcomingProgram/JoinProgram.png");

	}

	public void upComingProgramReject() throws IOException {
		waitFor(8000);
		jsClick(rp.RwdBookClub);
		waitFor(6000);
		ClickOnWebElement(rp.RwdOpenPrograms);
		waitFor(9000);
		javaScriptScrollToEnd();
		try {
			javascriptScroll(upcomingProgramlbl);
			jsClick(upcomingProgramlist.get(0));
		} catch (Exception e) {
			javaScriptScrollToEnd();
		}
		logger.info("Upcoming Program card Clicked  #Pass");
		waitFor(11000);
		ClickOnWebElement(nothanksBtn);
		waitFor(8000);
		waitForElementClick(rp.RwdBookClub);
		logger.info("Upcoming Program Reject Program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/UpcomingProgram/RejectProgram.png");

	}

	public void addTitlesinExsitingProgramfromSearchpage() throws IOException {
		waitFor(6000);
		ClickOnWebElement(searchIcon);
		waitFor(9000);
		javaScriptScrollToEnd();
		searchrecommendtitles = searchRecommendedTitles.get(0).getAttribute("alt");
		int count = searchRecommendedTitles.size();
		System.out.println("Count:" + count);
		System.out.println("Added title in search page:" + searchrecommendtitles);
		waitFor(3000);
		jsClick(moreMenuSearchPage.get(0));
		waitFor(3000);
		ClickOnWebElement(addToExistingProgram_btn);
		waitFor(3000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		WebElement sss = driver.findElement(By.xpath("//*[contains(text(),'" + activeprogramsearchpage + "')]"));
		System.out.println("ProgramName in search page:" + sss.getText());
		ClickOnWebElement(add_btn.get(0));
		waitFor(7000);
		ClickOnWebElement(close_btn);
		waitFor(5000);
		ClickOnWebElement(Searchclose_btn);
		waitFor(7000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(8000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(8000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDP:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			String addedtitle = activeProgramTDPReadingList.get(i).getAttribute("alt");
			System.out.println("SearchTitles:" + searchrecommendtitles);
			if (activeProgramTDPReadingList.get(i).getAttribute("alt").equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, addedtitle, "Titles Are same");
				logger.info("Search Page Add Titles To Existing Program #Pass");
			}
			if (i == activeProgramTDPReadingList.size() - 1) {
				logger.info("Search page Add Titles To Existing Program #Fail");
				Screenshots.takeScreenshot(driver, "Screenshots/AddToExistingProgram/search-addtoexistingprogram.png");
				Assert.assertTrue(false);

			}
		}
	}

	public void addTitlesinExsitingProgramfromSearchResultspage() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(searchIcon);
		waitFor(5000);
		SendKeysOnWebElement(txt_SearchInput, testData1.get(3).get("titleName"));
		txt_SearchInput.sendKeys(Keys.ENTER);
		waitFor(8000);
		// javaScriptScrollToEnd();
		searchrecommendtitles = searchResults.get(0).getText();
		System.out.println("Added title in search results page:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		waitFor(3000);
		jsClick(addToExistingProgram_btn);
		waitFor(8000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		System.out.println("Active program in search results page:" + activeprogramsearchpage);
		ClickOnWebElement(add_btn.get(0));
		waitFor(6000);
		jsClick(close_btn);
		waitFor(7000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(8000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(9000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(9000);
		activeProgramTDPReadingList.size();
		System.out.println("Title count: " + activeProgramTDPReadingList.size());

		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			System.out.println(activeReadingListTDP);
			try {
				if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
					Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
					logger.info("Search Results Add Titles To Existing Program #Pass");
				}
			} catch (Exception e) {
				System.out.println("Checking next title");

			}
//			else {
//				if(i == activeProgramTDPReadingList.size()-1) {
//					logger.info("Search Results Add Titles To Existing Program #Fail");
//					Screenshots.takeScreenshot(driver, "Screenshots/AddToExistingProgram/searchresults-addtoexistingprogram.png");
//					Assert.assertTrue(false);
//					
//				}
//			}
		}
	}

	public void addTitlesinExsitingProgramfromMystuffCheckout() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(Mystuff);
		waitFor(3000);
		ClickOnWebElement(checkout);
		waitFor(7000);
		if(ElementisPresent(engage.notitleCheckout))
		{
		logger.info("No titles are available !!");
		}else
		{
		searchrecommendtitles = checkouttitlelist.get(0).getText();
		int count = checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		jsClick(addToExistingProgram_btn);
		waitFor(8000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		ClickOnWebElement(add_btn.get(0));
		waitFor(8000);
		ClickOnWebElement(close_btn);
		waitFor(8000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(8000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(8000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			System.out.println(activeProgramTitleList.get(i).getText());
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDP:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			System.out.println("SearchTitles:" + searchrecommendtitles);
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
				logger.info("My Stuff Checkout Add Titles To Existing Program #Pass");
			} else {
				if (i == activeProgramTDPReadingList.size() - 1) {
					logger.info("Mystuff Add Titles To Existing Program #Fail");
					Screenshots.takeScreenshot(driver,
							"Screenshots/AddToExistingProgram/Mystuff-addtoexistingprogram.png");
					Assert.assertTrue(false);
				}
			}
		}
		}
	}

	public void addTitlesinExsitingProgramfromMystuffHistory() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(Mystuff);
		waitFor(3000);
		ClickOnWebElement(history);
		waitFor(7000);
		if(ElementisPresent(engage.notitlehistory))
		{
		logger.info("No titles are available");	
		}else {
		searchrecommendtitles = checkouttitlelist.get(0).getText();
		int count = checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		waitFor(3000);
		jsClick(addToExistingProgram_btn);
		waitFor(8000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		ClickOnWebElement(add_btn.get(0));
		waitFor(8000);
		ClickOnWebElement(close_btn);
		waitFor(8000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(8000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(8000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			System.out.println(activeProgramTitleList.get(i).getText());
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDP:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			System.out.println("SearchTitles:" + searchrecommendtitles);
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
				logger.info("My Stuff History Add Titles To Existing Program #Pass");
			} else {
				if (i == activeProgramTDPReadingList.size() - 1) {
					logger.info("Mystuff History Add Titles To Existing Program #Fail");
					Screenshots.takeScreenshot(driver,
							"Screenshots/AddToExistingProgram/mystuffhistory-addtoexistingprogram.png");
					Assert.assertTrue(false);
				}
			}
		}
		}
	}

	public void addTitlesinExsitingProgramfromMystuffFavourites() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(Mystuff);
		waitFor(3000);
		ClickOnWebElement(favourites);
		waitFor(7000);
		if(ElementisPresent(engage.notitleFavorites))
		{
		logger.info("No titles are available");	
		}else {
		searchrecommendtitles = checkouttitlelist.get(0).getText();
		int count = checkouttitlelist.size();
		System.out.println("Count:" + count);
		System.out.println("CheckoutTitle:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		waitFor(3000);
		jsClick(addToExistingProgram_btn);
		waitFor(7000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		ClickOnWebElement(add_btn.get(0));
		waitFor(5000);
		ClickOnWebElement(close_btn);
		waitFor(8000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(8000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(9000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			System.out.println(activeProgramTitleList.get(i).getText());
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDP:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			System.out.println("SearchTitles:" + searchrecommendtitles);
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
				logger.info("My Stuff Favorites Add Titles To Existing Program #Pass");
			} else {
				if (i == activeProgramTDPReadingList.size() - 1) {
					logger.info("Mystuff favorites Add Titles To Existing Program #Fail");
					Screenshots.takeScreenshot(driver,
							"Screenshots/AddToExistingProgram/favorites-addtoexistingprogram.png");
					Assert.assertTrue(false);

				}
			}
		}
		}
	}

	public void addTitlesinExsitingProgramfromDiscover() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(6000);
		ClickOnWebElement(discover);
		waitFor(3000);
		searchrecommendtitles = discoverlist.get(0).getAttribute("alt");
		System.out.println("Discover Title List:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		jsClick(addToExistingProgram_btn);
		waitFor(3000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		ClickOnWebElement(add_btn.get(0));
		waitFor(5000);
		ClickOnWebElement(close_btn);
		waitFor(3000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(3000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(5000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			System.out.println(activeProgramTitleList.get(i).getText());
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDPTitle:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			System.out.println("SearchTitles:" + searchrecommendtitles);
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
				logger.info("Discover page Add Titles To Existing Program #Pass");
			} else {
				if (i == activeProgramTDPReadingList.size() - 1) {
					logger.info("Discover Add Titles To Existing Program #Fail");
					Screenshots.takeScreenshot(driver,
							"Screenshots/AddToExistingProgram/discover-addtoexistingprogram.png");
					Assert.assertTrue(true);

				}
			}
		}
	}

	public void addTitlesinExsitingProgramfromHomePage() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData1 = reader.getData("./Data/WebData.xlsx", "RC");
		waitFor(9000);
		searchrecommendtitles = discoverlist.get(0).getAttribute("alt");
		System.out.println("Discover Title List:" + searchrecommendtitles);
		jsClick(moreMenuSearchPage.get(0));
		jsClick(addToExistingProgram_btn);
		waitFor(3000);
		activeprogramsearchpage = activeProgramsInSearchpage.get(0).getText();
		ClickOnWebElement(add_btn.get(0));
		waitFor(5000);
		ClickOnWebElement(close_btn);
		waitFor(3000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(3000);
		ClickOnWebElement(rp.RwdMyPrograms);
		waitFor(5000);
		while (draftProgramlbl.size() != 0 || lbl_closedPrograms.size() != 0) {
			javaScriptScrollToEnd();
			System.out.println("Scroll End");
		}
		for (int i = 0; i < activeProgramTitleList.size(); i++) {
			System.out.println(activeProgramTitleList.get(i).getText());
			if (activeProgramTitleList.get(i).getText().equalsIgnoreCase(activeprogramsearchpage)) {
				jsClick(activeProgramTitleList.get(i));
				break;
			}
		}
		waitFor(4000);
		for (int i = 0; i < activeProgramTDPReadingList.size(); i++) {
			System.out.println("Active ProgramTDPTitle:" + activeProgramTDPReadingList.get(i).getAttribute("alt"));
			System.out.println("SearchTitles:" + searchrecommendtitles);
			String activeReadingListTDP = activeProgramTDPReadingList.get(i).getAttribute("alt");
			if (activeReadingListTDP.equalsIgnoreCase(searchrecommendtitles)) {
				Assert.assertEquals(searchrecommendtitles, activeReadingListTDP, "Titles Are same");
				logger.info("Home page Add Titles To Existing Program #Pass");
			} else {
				if (i == activeProgramTDPReadingList.size() - 1) {
					logger.info("Home page Add Titles To Existing Program #Fail");
					Screenshots.takeScreenshot(driver,
							"Screenshots/AddToExistingProgram/home page-addtoexistingprogram.png");
					Assert.assertTrue(true);

				}
			}
		}
	}

	public String createProgramWithMAndatoryFields() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		logger.info("-- Create Program validation started--");
		ClickOnWebElement(rp.btn_createProgram);
		WaitForWebElement(rp.lbl_CreateProgrm);
		System.out.println(rp.lbl_CreateProgrm.getText());
		Assert.assertEquals(rp.lbl_CreateProgrm.getText(), testData.get(0).get("lbl_CreateProgram"));
		logger.info("Create program header is available #Pass");
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		progName1 = "Automation_RP" + RandomStringGenerate(2);
		SendKeysOnWebElement(rp.inp_progName, progName1);
		logger.info("Program name entered #Pass");
		ClickOnWebElement(rp.rb_public);
		logger.info("Public radio button is clicked #Pass");
		rp.startDate();
		rp.endDate();
		rp.addTitle();
		waitFor(3000);
		logger.info("Save button is available and clicked #Pass");
		ClickOnWebElement(rp.btn_publish);
		waitFor(5000);
		WaitForWebElement(rp.RwdBookClub);
		logger.info("Public program created with mandatory fields #Pass");
		return progName1;
	}

	public String createProgramWithOutAssigne() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "RP");
		logger.info("-- Create Program validation started--");
		waitFor(8000);
		ClickOnWebElement(rp.RWDbookClubOptionWeb);
		waitFor(12000);
		ClickOnWebElement(rp.lbl_myPrograms);
		waitFor(7000);
		ClickOnWebElement(rp.btn_createProgram);
		System.out.println(rp.lbl_CreateProgrm.getText());
		Assert.assertEquals(rp.lbl_CreateProgrm.getText(), testData.get(0).get("lbl_CreateProgram"));
		logger.info("Create program header is available #Pass");
		Assert.assertEquals(rp.lbl_progName.getText(), testData.get(0).get("lbl_progNameTxt"));
		logger.info("Program name text box is available #Pass");
		progName1 = "Automation_RP" + RandomStringGenerate(2);
		System.out.println("Created Program Name: "+progName1);
		ClickOnWebElement(rp.inp_progName);
		SendKeysOnWebElement(rp.inp_progName, progName1);
		logger.info("Program name entered #Pass");
		SendKeysOnWebElement(rp.inp_progDesc, testData.get(0).get("progDesc"));
		ClickOnWebElement(rp.rb_public);
		logger.info("Public radio button is clicked #Pass");
		rp.setProgType();
		rp.startDate();
		rp.endDate();
		rp.setRemainder();
		rp.addTitle();
		waitFor(3000);
		ClickOnWebElement(rp.btn_publish);
		waitFor(5000);
		WaitForWebElement(rp.RwdBookClub);
		logger.info("Public program created with out assignee  #Pass");
		return progName1;
	}

	public void onGoingProgramClick() throws IOException {
		waitFor(7000);
		ClickOnWebElement(rp.RwdBookClub);
		waitFor(7000);
		ClickOnWebElement(rp.RwdOpenPrograms);
		waitFor(9000);
		Assert.assertEquals(rp.RWDOnGoing.getText(), "ONGOING PROGRAMS");
		logger.info("ONGOING PROGRAMS Tab Availble  #Pass");
		for (int i = 0; i < 20; i++) {
			javaScriptScrollToEnd();
			try {
				System.out.println("SearchingProgramName:" + progName1);
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName1 + "')]"));
				jsClick(ss);
				waitFor(8000);
				break;
			} catch (Exception e) {
				javaScriptScrollToEnd();
			}
		}
		Screenshots.takeScreenshot(driver, "Screenshots/OnGoing/ongoingPrg.png");
		logger.info("Clicking on the created program card should show Program details on open program #Pass");
	}
	public void receiveMessageRP(String message) throws InvalidFormatException, IOException {
		checkInviteMessageprogramRP(progName1,message);

	}
	public void checkInviteMessageprogramRP(String prgname,String message) throws IOException, InvalidFormatException {
		if (ElementisPresent(rc.RWDnoMessages)) {
			Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/messagecenter.png");
			logger.info("Messages Center! You have No Messages! #Pass");
			 ClickOnWebElement(rc.msgclose);
		} else {
			List<Map<String, String>> testData = reader.getData("./Data/WebData.xlsx", "MessageCenter");
			logger.info("Messages are displayed in Message center #Pass");
			Screenshots.takeScreenshot(driver, "./Screenshots/MessageCenter/messagecenter.png");
			waitFor(3000);
			logger.info("--Message centre - Invite Message validation Started--");
			for (int i = 0; i <= 15; i++) {
				javaScriptScrollToEnd();
				try {
					if (rc.msgHeader.get(i).getText().equalsIgnoreCase(message)) {
						jsClick(rc.msgHeader.get(i));
						waitFor(7000);
						if (rc.RwdmsgDetails.get(i).getText()
								.contains(progName1)) {
							jsClick(rc.msgHeader.get(i));
							break;
						} else {
							ClickOnWebElement(rc.msgHeader.get(i));
						}
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					javaScriptScrollToEnd();
					System.out.println("The index you have entered is invalid skip ");
				}
				
			}
		}
	}
	public void joinOpenProgram() throws IOException {
		ClickOnWebElement(joinProgramBtn);
		waitFor(7000);
		ClickOnWebElement(goToProgram);
		waitFor(12000);
		logger.info("Ongoing Program Join Program #Pass");
		Screenshots.takeScreenshot(driver, "Screenshots/OngoingProgram/JoinProgram.png");
	}

	public void openprogramMetricsPercentageValidationDetailsPage() throws IOException {
		javaScriptScrollToEnd();
		javascriptScroll(participant_lbl);
		Assert.assertTrue(participant_lbl.isDisplayed());
		logger.info("Public program details page participant label displayed  #Pass");
		waitFor(9000);
		for (int i = 0; i < participantmetricts_th.size(); i++) {
			Assert.assertTrue(participantmetricts_th.get(i).isDisplayed());
			logger.info("OpenProgram Metrics Heading :" + participantmetricts_th.get(i).getText());
			System.out.println("Participant Header validated");
		}
		waitFor(15000);
		for (int i = 0; i < participantmetricts_td.size(); i++) {
			Assert.assertTrue(participantmetricts_td.get(i).isDisplayed());
			logger.info("OpenProgram Metrics Datas:" + participantmetricts_td.get(i).getText());
			System.out.println("Participant Header with progress data");
		}
		Screenshots.takeScreenshot(driver, "Screenshots/OngoingProgram/JoinProgramDetailsPage.png");
	}

	public void myProgramHrsSpentPercentageValidation() throws IOException {
		waitFor(9000);
		ClickOnWebElement(rp.RWDbookClubOptionWeb);
		waitFor(5000);
		ClickOnWebElement(rp.lbl_myPrograms);
		waitFor(4000);
		WaitForWebElement(rp.lbl_ActiveProgram);
		for (int i = 0; i <= 5; i++) {
			waitFor(000);
			javaScriptScrollToEnd();
			waitFor(3000);
			javascriptScroll(rp.lbl_ActiveProgram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + progName1 + "')]"));
				System.out.println("Prgog1:" + progName1);
				waitFor(2000);
				javascriptScroll(ss);
				WaitForWebElement(progrsspercentage.get(0));
				String spentHours = hrspent.get(0).getText();
				String[] split = spentHours.split(" ");
				boolean valid = false;
				SimpleDateFormat s = new SimpleDateFormat("HH:MM");
				try {
					Date hours = s.parse(split[0]);
					String formatValid = s.format(hours);
					System.out.println("valid format:" + formatValid);
					valid = true;
					Assert.assertTrue(valid);
					logger.info(getData("platformName") + " - Hours Spent time format is HH:MM #Pass");
				} catch (ParseException e) {
					logger.info(getData("platformName") + " - Hours Spent time format is HH:MM #Fail");
					break;
				}
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javaScriptScrollToEnd();
				waitFor(2000);
			}
		}
	}

	public void participantHrsSpentPercentageValidation() throws IOException {
		waitFor(9000);
		ClickOnWebElement(rp.RWDbookClubOptionWeb);
		waitFor(5000);
		ClickOnWebElement(rp.lbl_myPrograms);
		waitFor(4000);
		WaitForWebElement(rp.lbl_ActiveProgram);
		for (int i = 0; i <= 5; i++) {
			waitFor(000);
			javaScriptScrollToEnd();
			waitFor(3000);
			javascriptScroll(rp.lbl_ActiveProgram);
			try {
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + engage.progName + "')]"));
				System.out.println("Prgog1:" + engage.progName);
				waitFor(2000);
				javascriptScroll(ss);
				WaitForWebElement(progrsspercentage.get(0));
				String spentHours = hrspent.get(0).getText();
				String[] split = spentHours.split(" ");
				boolean valid = false;
				SimpleDateFormat s = new SimpleDateFormat("HH:MM");
				try {
					Date hours = s.parse(split[0]);
					String formatValid = s.format(hours);
					System.out.println("valid format:" + formatValid);
					valid = true;
					Assert.assertTrue(valid);
					logger.info(getData("platformName") + " - Hours Spent time format is HH:MM #Pass");
				} catch (ParseException e) {
					logger.info(getData("platformName") + " - Hours Spent time format is HH:MM #Fail");
					break;
				}
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javaScriptScrollToEnd();
				waitFor(2000);
			}
		}
	}

	public void deleteUnpublishedProgram() {
		for (int i = 0; i <= 5; i++) {
			waitFor(9000);
			javaScriptScrollToEnd();

			try {
				WaitForWebElement(unpublished_lbl);
				jsClick(Unpublish_TitlecardprgName.get(0));
				waitFor(7000);
				draftprogramname = programdetails_programname.getText();
				ClickOnWebElement(editprogram.get(0));
				waitFor(5000);
				jsClick(deleteprogram.get(0));
				waitFor(5000);
				ClickOnWebElement(deleteprogramok.get(0));
				waitFor(9000);
				WaitForWebElement(rp.lbl_myPrograms);
				logger.info("Unpublished program deleted #pass");
				break;
			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javaScriptScrollToEnd();
			}
		}
	}

	public void verifyingDeletedUnPublishedProgram() {
		waitFor(7000);
		for (int i = 0; i <= 5; i++) {
			javaScriptScrollToEnd();
			try {
				for (int j = 0; j <= Unpublish_TitlecardprgName.size(); j++) {
					if (Unpublish_TitlecardprgName.get(j).getText().equalsIgnoreCase(draftprogramname)) {
						logger.info("Unpublished Deleted program present in unpulished section #Fail");
						Assert.assertTrue(false);

					}
				}
			} catch (Exception e) {
				javaScriptScrollToEnd();
			}
		}
		logger.info("Unpublished Deleted program not present in unpulished section #Pass");
	}

	public void delteDraftProgram() {
		waitFor(5000);
		for (int i = 0; i <= 5; i++) {
			javaScriptScrollToEnd();
			try {
				jsClick(draft_TitlecardprgName.get(0));
				draftprogramname = draft_TitlecardprgName.get(0).getText();
				System.out.println("deleteDrafft:" + draftprogramname);
				waitFor(7000);
				WaitForWebElement(rp.btn_publish);
				jsClick(deleteprogram.get(0));
				waitFor(5000);
				ClickOnWebElement(deleteprogramok.get(0));
				waitFor(9000);
				WaitForWebElement(rp.lbl_myPrograms);
				logger.info("Draft program deleted #pass");
				break;

			} catch (Exception e) {
				System.out.println("Scrolling again for click");
				javaScriptScrollToEnd();
				waitFor(2000);
			}
		}
	}

	public void verifyingDeletedDraftProgram() {
		waitFor(7000);
		for (int i = 0; i <= 5; i++) {
			javaScriptScrollToEnd();
			try {
				for (int j = 0; j <= draft_TitlecardprgName.size(); j++) {
					System.out.println("confirmDelete" + draft_TitlecardprgName.get(0).getText());
					System.out.println("confirm:" + draftprogramname);
					if (draft_TitlecardprgName.get(j).getText().equalsIgnoreCase(draftprogramname)) {
						Assert.assertTrue(false);
						logger.info("Draft Deleted program present in draft section #Fail");
						break;
					}
				}
			} catch (Exception e) {
				javaScriptScrollToEnd();
			}
		}
		logger.info("Draft Deleted program not present in unpulished section #Pass");
	}

	public void activeParticipantListValidation() throws IOException {
		waitFor(8000);
		ClickOnWebElement(rp.RWDbookClubOptionWeb);
		waitFor(7000);
		ClickOnWebElement(rp.lbl_myPrograms);
		waitFor(7000);
		ClickOnWebElement(rp.activeList.get(0));
		waitFor(7000);
		javascriptScroll(participant_lbl);
		try {
			if (r.participantlist.size() == 10 && r.participantlist.size() > 10)
				logger.info("My Program participant list 10 displayed ##pass");
			ClickOnWebElement(r.partivipantnavigation_right);
			logger.info("My Program participant right arrow navigation ##pass");
			waitFor(1000);
			ClickOnWebElement(r.partivipantnavigation_left);
			logger.info("My Program participant left arrow navigation ##pass");
		} catch (Exception e) {
			logger.info("My Program participant list displayed less than 10 ##pass");
		}
		Screenshots.takeScreenshot(driver, "Screenshots/Web-RP/MyProgramParcipant/participantlist.png");
	}

	public void participantleavePrivateProgramValidation() {
		waitFor(8000);
		ClickOnWebElement(rp.RWDbookClubOptionWeb);
		waitFor(12000);
		ClickOnWebElement(rp.lbl_myPrograms);
		waitFor(7000);
		WaitForWebElement(rp.lbl_ActiveChallenge);
		for (int i = 0; i < 20; i++) {
			javaScriptScrollToEnd();
			try {
				System.out.println("SearchingProgramName:" + engage.progName);
				WebElement ss = driver.findElement(By.xpath("//*[contains(text(),'" + engage.progName + "')]"));
				javascriptScroll(ss);
				jsClick(ss);
				waitFor(7000);
				logger.info("Active program is clicked #Pass");
				break;

			} catch (Exception e) {
				javaScriptScrollToEnd();
				System.out.println("scroll again");
			}
		}

		try {
			if (leaveProgram_lbl.isDisplayed())
				;
			logger.info("Leave Program displayed for participant #Fail");

		} catch (Exception e) {
			programdetails_programname.isDisplayed();
			logger.info("Leave Program not displayed for participant #pass");
		}

	}
	// Thurday code

	public void closedProgramSectionValidation() throws IOException {
		waitFor(5000);
		for (int i = 0; i < 30; i++) {
			javaScriptScrollToEnd();
			try {
				Assert.assertTrue(lbl_closedPrograms.get(0).isDisplayed());
				for (int j = 0; j < closedProgramList.size(); j++) {
					Assert.assertTrue(closedProgramList.get(j).isDisplayed());
					logger.info("Closed programs are displayed under closed section  #pass");
					Screenshots.takeScreenshot(driver, "Screenshots/Web-RP/MyProgram/closedprogram.png");
					break;
				}
			} catch (Exception e) {
				javaScriptScrollToEnd();
			}
		}
		try {
			closedProgram_TitlecardprgName.get(0).isDisplayed();
			logger.info("Closed Program Program Name displayed  #pass");
		} catch (Exception e) {
			logger.info("Closed Program are not  displayed under closed section  #Fail");
			Assert.assertTrue(false);
			Screenshots.takeScreenshot(driver, "Screenshots/Web-RP/MyProgramParcipant/closedprogramFail.png");
		}

	}

	/***************************************************
	 * Locators
	 ***********************************************/

	@FindBy(xpath = "//*[@class='mat-card-title header-title txt-elipsishead']")
	public List<WebElement> myprogramactivelist;

	@FindBy(id = "head-menu-list-discv")
	public WebElement discover;

	@FindBy(xpath = "//*[@class='btn-no-bg color-link']")
	public List<WebElement> searchResults;

	@FindBy(id = "head-menu-list-mystuff")
	public WebElement Mystuff;

	@FindBy(xpath = "//*[text()=' Checkouts ']")
	public WebElement checkout;

	@FindBy(xpath = "//*[@class='btn-no-bg color-link']")
	public List<WebElement> checkouttitlelist;

	@FindBy(xpath = "//*[@class='mat-menu-trigger more-vert ng-star-inserted']")
	public List<WebElement> discoverlist;

	@FindBy(id = "mystuff-history")
	public WebElement history;

	@FindBy(id = "mystuff-favorites")
	public WebElement favourites;

	@FindBy(xpath = "//input[@id='searchInput']")
	public WebElement txt_SearchInput;

	@FindBy(id = "dd-Ongoing-contain")
	public List<WebElement> onGoingprogList;

	@FindBy(id = "//*[text()='DRAFT PROGRAMS']")
	public List<WebElement> draftProgramlbl;

	@FindBy(xpath = "//*[@aria-label='CLOSED PROGRAMS']")
	public static List<WebElement> lbl_closedPrograms;

	//@FindBy(xpath = "//*[text()='Join Program']")
	
	@FindBy(xpath =" //*[@name='Join_Prgm' ]")
	public WebElement joinProgramBtn;

	@FindBy(xpath = "//*[text()='No, Thanks']")
	public WebElement nothanksBtn;

	@FindBy(xpath = "//*[text()='Go to Program']")
	public WebElement goToProgram;

	@FindBy(xpath = "//*[text()='LEAVE PROGRAM ']")
	public WebElement leaveProgram;

	@FindBy(xpath = "//*[text()='OK']")
	public WebElement leaveProgramOkBtn;

	@FindBy(xpath = "//*[text()='UPCOMING PROGRAMS']")
	public WebElement upcomingProgramlbl;

	@FindBy(id = "dd-Upcoming-contain")
	public List<WebElement> upcomingProgramlist;

	@FindBy(xpath = "//*[@class='text-left']")
	public WebElement footer;

	@FindBy(xpath = "//*[@class='recommendations']//following::fss-ms-title-card/mat-card/div[2]/div[2]/img")
	public List<WebElement> searchRecommendedTitles;

	@FindBy(xpath = "//*[@class='search-Icon-Button icon-bg']")
	public WebElement searchIcon;

	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color ng-star-inserted']")
	public List<WebElement> moreMenuSearchPage;

	@FindBy(xpath = "//*[text()=' Add to Existing Program ']")
	public WebElement addToExistingProgram_btn;

	@FindBy(xpath = "//*[text()='ADD']")
	public List<WebElement> add_btn;

	@FindBy(xpath = "//*[@class='accord-img']")
	public List<WebElement> activeProgramsInSearchpage;

	@FindBy(id = "plp-tilte-modl-close")
	public WebElement close_btn;

	@FindBy(id = "search-title-close")
	public WebElement Searchclose_btn;

	@FindBy(xpath = "//*[@class='mat-card-title header-title txt-elipsishead']")
	public List<WebElement> activeProgramTitleList;

	@FindBy(xpath = "//mat-card/div[2]/div[2]/img")
	public List<WebElement> activeProgramTDPReadingList;

	@FindBy(id = "pd-partip-head")
	public WebElement participant_lbl;

	@FindBy(xpath = "//table/tr/th")
	public List<WebElement> participantmetricts_th;

	@FindBy(xpath = "//table/tr/td")
	public List<WebElement> participantmetricts_td;

	@FindBy(xpath = "//*[text()='Total Complete']")
	public WebElement totalcomplete_txt;

	@FindBy(xpath = "//*[@class='hrs ng-star-inserted']")
	public List<WebElement> hrspent;

	@FindBy(xpath = "//*[@class='ng-star-inserted']")
	public List<WebElement> progrsspercentage;

	@FindBy(xpath = "//*[text()='UNPUBLISHED PROGRAMS']")
	public WebElement unpublished_lbl;

	@FindBy(id = "dd-Unpublish-contain")
	public List<WebElement> unpublishedlist;

	@FindBy(id = "pd-editprg")
	public List<WebElement> editprogram;

	@FindBy(xpath = "//*[text()='DELETE PROGRAM']")
	public List<WebElement> deleteprogram;

	@FindBy(xpath = "//*[text()='OK']")
	public List<WebElement> deleteprogramok;

	@FindBy(id = "prog-det-heading")
	public WebElement programdetails_programname;

	@FindBy(xpath = "//*[text()='DRAFT PROGRAMS']")
	public WebElement draftprogram_lbl;

	@FindBy(id = "dd-Save-contain")
	public List<WebElement> draftlist;

	@FindBy(xpath = "//*[@aria-label='DRAFT PROGRAMS']//following::div[@class='mat-card-header-text']//following::mat-card-title")
	public List<WebElement> draft_TitlecardprgName;

	@FindBy(xpath = "//*[text()='LEAVE PROGRAM ']")
	public WebElement leaveProgram_lbl;

	@FindBy(xpath = "//*[@aria-label='UNPUBLISHED PROGRAMS']//following::div[@class='mat-card-header-text']//following::mat-card-title")
	public List<WebElement> Unpublish_TitlecardprgName;

	@FindBy(xpath = "//*[@aria-label='CLOSED PROGRAMS']//following::div[@class='mat-card-header-text']//following::mat-card-title")
	public List<WebElement> closedProgram_TitlecardprgName;

	@FindBy(xpath = "//*[@aria-label='CLOSED PROGRAMS']//following::div[@id='dd-Complete-contain']")
	public List<WebElement> closedProgramList;

	@FindBy(xpath ="//*[text()='Reading Program']")
	public WebElement ReadingProgram;

}
