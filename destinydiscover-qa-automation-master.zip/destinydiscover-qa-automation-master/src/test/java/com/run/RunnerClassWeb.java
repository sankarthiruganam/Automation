package com.run;

import java.io.IOException;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.base.JvmReportWeb;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)

@CucumberOptions(features= {"Web Features"},//Web Features
		glue= {"com.stepdefinitionWeb"},
		monochrome=true,
		dryRun=false,
		tags= {"@Reg_135,@Reg_146,@Reg_152,@Reg_137,@Reg_136"},
		//tags= {"@Reg_135","@Reg_152","@Reg_137","@Reg_136","@Reg_141","@Reg_142,Reg_144","@Reg_146"},
		
		//tags= {"@Reg_33,@Reg_47"},
		//tags= {"@Reg_Engage_RP_Creator"},
		//tags= {"@Reg_70,@Reg_72,@Reg_60,@Reg_63"},
		//tags= {"@Reg_39,@Reg_54,@Reg_48,@Reg_114,@Reg_50,@Reg_116,@Reg_52,@Reg_118"},
		//tags= {"@Reg_Engage_Drop4_Admin"},
		plugin= {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","json:target/Results/cucumber.json",
				"rerun:FailedTestCases//failed.txt","pretty"})
public class RunnerClassWeb {
	
	@AfterClass         
	   public static void afterClass() throws IOException {                 
		   JvmReportWeb.generateReport(System.getProperty("user.dir")+"/target/Results/cucumber.json");     
		   
		   } 
}
//@RC_Smoke_WEB = Smoke    
//RC functional  = @Rwd_CreateChallenge_Sc1,@Rwd_ChallengesListing_Sc2, @Rwd_ParticipantView_Sc3, @Rwd_MessageCenter_Sc4, @Rwd_ReportAbuse_Sc5, @Rwd_Messages_Validation_Sc6
//Rwd_RP_Smoke
//RC functional = @Rwd_CreateProgram_Sc1, @Rwd_publishProgram_Sc2
//Non-Engage: WebPageHit  
// drop 4 smoke: @drop4
