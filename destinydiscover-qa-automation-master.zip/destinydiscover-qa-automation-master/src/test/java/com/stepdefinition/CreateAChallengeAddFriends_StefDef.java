/*
 * package com.stepdefinition;
 * 
 * import java.io.IOException; import java.util.List;
 * 
 * import org.apache.poi.openxml4j.exceptions.InvalidFormatException; import
 * org.junit.Assert; import org.openqa.selenium.Keys;
 * 
 * import com.base.CapabilitiesAndWebDriverUtils; import
 * com.pom.BookClubLandingScreen; import
 * com.pom.CreateAChallengeBasicChallengeDetails; import
 * com.pom.CreateAChallengeSetReadbyDate; import
 * com.pom.CreateChallengeAddFriends; import com.pom.CreateChallengeAddTitles;
 * import com.pom.CreateChallengeSetReminders; import
 * com.pom.CreateaChallengeSearchTitleResultsListView;
 * 
 * import cucumber.api.java.en.Then; import cucumber.api.java.en.When; import
 * io.appium.java_client.MobileElement;
 * 
 * public class CreateAChallengeAddFriends_StefDef extends
 * CapabilitiesAndWebDriverUtils {
 * 
 * BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
 * CreateAChallengeBasicChallengeDetails createBasicChallenge = new
 * CreateAChallengeBasicChallengeDetails(); CreateChallengeAddFriends addfriends
 * = new CreateChallengeAddFriends(); CreateaChallengeSearchTitleResultsListView
 * searchTitles = new CreateaChallengeSearchTitleResultsListView();
 * CreateChallengeSetReminders setReminders = new CreateChallengeSetReminders();
 * CreateAChallengeSetReadbyDate setReadbyDate = new
 * CreateAChallengeSetReadbyDate(); CreateChallengeAddTitles addTitles = new
 * CreateChallengeAddTitles();
 * 
 * @When("User taps on the Add CTA under the Challenge Friends section") public
 * void user_taps_on_the_Add_CTA_under_the_Challenge_Friends_section() throws
 * InterruptedException, Exception { if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * ClickOnWebElement(createBasicChallenge.getAddFriendCTA()); //
 * SendKeysOnWebElement(addfriends.getSearchBox(), 30, 1, "Photon Student15"); }
 * else{
 * 
 * ClickOnWebElement(createBasicChallenge.getAddFriendCTA());
 * //SendKeysOnWebElement(addfriends.getSearchBox(), 30, 1, "Photon");
 * //addfriends.getSearchBox().sendKeys(Keys.ENTER); Thread.sleep(2000); } }
 * 
 * @Then("User should be able to add as many friends as required to the invitees list without any limit"
 * ) public void
 * user_should_be_able_to_add_as_many_friends_as_required_to_the_invitees_list_without_any_limit
 * () { List<MobileElement> userNamelist = addfriends.userNameText;
 * List<MobileElement> inviteOption = addfriends.inviteOptionList; for (int i =
 * 0; i < userNamelist.size(); i++) { inviteOption.get(i).click(); } }
 * 
 * @When("User adds few friends by tapping on Invite button") public void
 * user_adds_few_friends_by_tapping_on_Invite_button() throws
 * InterruptedException, IOException { if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * 
 * List<MobileElement> userNamelist = addfriends.userNameText;
 * List<MobileElement> inviteOption = addfriends.inviteOptionList; for (int i =
 * 0; i < userNamelist.size()-1; i++) { // for (int j = 0; j
 * <inviteOption.size(); j++) { inviteOption.get(i).click(); String
 * addChallengeTxt = addfriends.getAddToChallenge().getText(); int
 * addedFriendcount = i + 1; boolean lableTxt =
 * addChallengeTxt.equalsIgnoreCase("Add to Challenge(" + addedFriendcount +
 * ")"); System.out.println(addChallengeTxt); Assert.assertTrue(lableTxt);
 * 
 * }}
 * 
 * else{
 * 
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER); List<MobileElement>
 * userNamelist = addfriends.userNameText; int usersize = userNamelist.size()/2;
 * System.out.println(usersize);
 * 
 * List<MobileElement> inviteOption = addfriends.inviteOptionList; for (int i =
 * 0; i <usersize ; i++) { for (int j = 0; j <inviteOption.size(); j++) {
 * Thread.sleep(2000); inviteOption.get(j).click(); } } }}
 * 
 * @Then("User should be able to tap on the Add to challenge CTA to add invitees to the challenge"
 * ) public void
 * user_should_be_able_to_tap_on_the_Add_to_challenge_CTA_to_add_invitees_to_the_challenge
 * () { swipeDown(); ClickOnMobileElement(addfriends.getAddToChallenge());
 * waitFor(5000);
 * Assert.assertEquals(fluentWaitDisplayed(createBasicChallenge.getSetReadByText
 * (), 30, 5), true); }
 * 
 * @Then("User should be taken to the search page where friends can be invited to join the challenge"
 * ) public void
 * user_should_be_taken_to_the_search_page_where_friends_can_be_invited_to_join_the_challenge
 * () { Assert.assertTrue(fluentWaitDisplayed(addfriends.searchHeader, 30, 2));
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.recentsearchText, 30, 2));
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.addToChallenge, 30, 2));
 * System.out.println("User is on search friend screen");
 * 
 * }
 * 
 * @Then("User should be navigated to the Invite Friends screen") public void
 * user_should_be_navigated_to_the_Invite_Friends_screen() throws
 * InterruptedException, IOException {
 * 
 * if (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.searchHeader, 30, 2));
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.recentsearchText, 30, 2));
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.addToChallenge, 30, 2));
 * System.out.println("User is on search friend screen");
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * List<MobileElement> userNamelist = addfriends.userNameText;
 * List<MobileElement> inviteOption = addfriends.inviteOptionList; for (int i =
 * 0; i < userNamelist.size(); i++) { inviteOption.get(i).click(); }
 * ClickOnWebElement(addfriends.getAddToChallenge()); List<MobileElement>
 * removeFriendXIcon = createBasicChallenge.removeFriendXIcon; for (int i =
 * removeFriendXIcon.size()-1; i>=1; i--) {
 * createBasicChallenge.removeFriendXIcon.get(i).click();
 * createBasicChallenge.friendRemoveButton.click(); }
 * ClickOnWebElement(createBasicChallenge.getAddFriendCTA());
 * addfriends.getSearchBox().clear(); } else{
 * 
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.searchHeader, 30, 2));
 * //Assert.assertTrue(fluentWaitDisplayed(addfriends.recentsearchText, 30, 2));
 * Assert.assertTrue(fluentWaitDisplayed(addfriends.addToChallenge, 30, 2));
 * System.out.println("User is on search friend screen");
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER);
 * 
 * List<MobileElement> userNamelist = addfriends.userNameText; int usersize =
 * userNamelist.size()/2; List<MobileElement> inviteOption =
 * addfriends.inviteOptionList; for (int i = 1; i < usersize; i++) { for (int j
 * = 0; j <inviteOption.size(); j++) { inviteOption.get(j).click();
 * 
 * } }
 * 
 * Thread.sleep(2000);
 * 
 * ClickOnWebElement(addfriends.getAddToChallenge()); List<MobileElement>
 * removeFriendXIcon = createBasicChallenge.removeFriendXIcon;
 * System.out.println(removeFriendXIcon.size()); //int removefriiendsize =
 * removeFriendXIcon.size()/2;
 * 
 * for (int i = removeFriendXIcon.size()-1;i>=1; i--) {
 * createBasicChallenge.removeFriendXIcon.get(i).click();
 * createBasicChallenge.friendRemoveButton.click(); }
 * ClickOnWebElement(createBasicChallenge.getAddFriendCTA());
 * addfriends.getSearchBox().clear(); hideMobileKeyboard(); } }
 * 
 * @Then("User should be able to view the list of {int} recently searched friends"
 * ) public void
 * user_should_be_able_to_view_the_list_of_recently_searched_friends(Integer
 * int1) { logger.info("Verifying recently searched list"); boolean
 * searchListSize = true; if(addfriends.recentSearchfriendList.size()!=0) { if
 * (addfriends.recentSearchfriendList.size() <= 5) { for (int i = 0; i <
 * addfriends.recentSearchfriendList.size(); i++) {
 * Assert.assertTrue(addfriends.recentSearchfriendList.get(i).isDisplayed()); }
 * System.out.println("Recent Friend List is Less than or Equal to five"); }
 * else if (addfriends.recentSearchfriendList.size() > 5) { searchListSize =
 * false; Assert.assertTrue(searchListSize);
 * System.out.println("Recent Friend List size is greater than five"); } } }
 * 
 * @Then("User should be able to view only the recently searched friends")
 * public void user_should_be_able_to_view_only_the_recently_searched_friends()
 * throws Exception { addfriends.AddRecentFriends(5);
 * 
 * 
 * boolean searchListSize = true;
 * if(addfriends.recentSearchfriendList.size()!=0) { if
 * (addfriends.recentSearchfriendList.size() <= 5) { for (int i = 0; i <
 * addfriends.recentSearchfriendList.size(); i++) {
 * Assert.assertTrue(addfriends.recentSearchfriendList.get(i).isDisplayed()); }
 * System.out.println("Recent Friend List is Less than or Equal to five"); }
 * else if (addfriends.recentSearchfriendList.size() > 5) { searchListSize =
 * false; Assert.assertTrue(searchListSize);
 * System.out.println("Recent Friend List size is greater than five"); } }
 * 
 * }
 * 
 * @Then("User should be able to tap on Invite button and the specific friend should be added to the list of invitees"
 * ) public void
 * user_should_be_able_to_tap_on_Invite_button_and_the_specific_friend_should_be_added_to_the_list_of_invitees
 * () throws IOException, InvalidFormatException {
 * logger.info("Adding friends to challenge"); if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * addfriends.searchAddFriend(false, 0); if
 * (addfriends.recentSearchfriendList.size() != 0) { List<MobileElement>
 * inviteOption = addfriends.inviteOptionList; List<MobileElement>
 * recentSearchfriendList = addfriends.recentSearchfriendList; for (int i = 0; i
 * < recentSearchfriendList.size(); i++) { inviteOption.get(i).click();
 * Assert.assertTrue(addfriends.addedFriendInSearchPage.get(i).isDisplayed()); }
 * System.out.println("Added friends are Displyed at the top of the page"); } }
 * else{ if (addfriends.recentSearchfriendList.size() != 0) {
 * List<MobileElement> inviteOption = addfriends.inviteOptionList;
 * List<MobileElement> recentSearchfriendList =
 * addfriends.recentSearchfriendList; int searchsize =
 * recentSearchfriendList.size()/2; for (int i = 0; i < searchsize; i++) {
 * inviteOption.get(i).click();
 * Assert.assertTrue(addfriends.addedFriendInSearchPage.get(i).isDisplayed());
 * break; }
 * System.out.println("Added friends are Displyed at the top of the page"); }
 * else { System.out.println("No recent search friend available"); } }}
 * 
 * @Then("User can add the invites button clicking invite button")
 * 
 * public void user_can_add_the_invites_button_clicking_invite_button() {
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER);
 * 
 * List<MobileElement> userNamelist = addfriends.userNameText; int usersize =
 * userNamelist.size()/2; System.out.println(usersize);
 * 
 * List<MobileElement> inviteOption = addfriends.inviteOptionList;
 * 
 * for (int i = 0; i <usersize ; i++) { for (int j = 0; j <inviteOption.size();
 * j++) { inviteOption.get(j).click(); } break; } }
 * 
 * @When("User adds invitees by tapping on Add to challenge button") public void
 * user_adds_invitees_by_tapping_on_Add_to_challenge_button() { swipeDown();
 * Assert.assertTrue(addfriends.getAddToChallenge().isEnabled());
 * ClickOnMobileElement(addfriends.getAddToChallenge()); }
 * 
 * @Then("User should be navigated back to the Create challenge screen with the list of invitees added"
 * ) public void
 * user_should_be_navigated_back_to_the_Create_challenge_screen_with_the_list_of_invitees_added
 * () { waitFor(2000); for (int i = 0; i <
 * createBasicChallenge.addedFriendavatarList.size(); i++) {
 * Assert.assertTrue(createBasicChallenge.addedFriendavatarList.get(i).
 * isDisplayed()); } logger.info("Navigating back to create challenge page");
 * System.out.println("Added friends are displayed in Create challenge Page"); }
 * 
 * @Then("User should be allowed to remove the friend by clicking on the close button in search screen"
 * ) public void
 * user_should_be_allowed_to_remove_the_friend_by_clicking_on_the_close_button_in_search_screen
 * () throws IOException {
 * 
 * if (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * addfriends.removeFriend(true, 0);
 * 
 * SendKeysOnMobileElement(addfriends.getSearchBox(), 30, 1, "ph1");
 * ClickOnMobileElement(addfriends.getInviteOption()); List<MobileElement>
 * addedFriendInSearchFriendList = addfriends.addedFriendInSearchPage; int
 * before = addedFriendInSearchFriendList.size();
 * logger.info("added friend list size :"
 * +addedFriendInSearchFriendList.size()); for (int i = 0; i <
 * addedFriendInSearchFriendList.size(); i++) {
 * Assert.assertTrue(addfriends.addedFriendInSearchPage.get(i).isDisplayed()); }
 * ClickOnMobileElement(addfriends.removeFriendInSearchPage); int after =
 * addedFriendInSearchFriendList.size();
 * logger.info("added friend list size after removing :"
 * +addedFriendInSearchFriendList.size()); if(before==after) {
 * System.out.println("Selected user is not removed"); }else {
 * logger.info("invitee removed from the list"); }} }
 * 
 * else{ SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER);
 * 
 * ClickOnWebElement(addfriends.getInviteOption()); List<MobileElement>
 * addedFriendInSearchFriendList = addfriends.addedFriendInSearchPage; for (int
 * i = 0; i < addedFriendInSearchFriendList.size(); i++) {
 * Assert.assertTrue(addfriends.addedFriendInSearchPage.get(i).isDisplayed()); }
 * ClickOnWebElement(addfriends.removeFriendInSearchPage);
 * if(addedFriendInSearchFriendList.size()!=0) {
 * System.out.println("Selected user is not removed"); } } }
 * 
 * @Then("User should be able to view the Add to challenge CTA comprising of the number of invitees selected"
 * ) public void
 * user_should_be_able_to_view_the_Add_to_challenge_CTA_comprising_of_the_number_of_invitees_selected
 * () { // Assert.assertTrue(fluentWaitDisplayed(addfriends.friendSelectedCount,
 * 30, 2));
 * 
 * 
 * }
 * 
 * @When("User is on the Invite Friends screen of a Reading challenge") public
 * void user_is_on_the_Invite_Friends_screen_of_a_Reading_challenge() {
 * 
 * ClickOnMobileElement(bookClubLandingScreeen.getBookClubOption()); //
 * Assert.assertEquals(fluentWaitDisplayed(bookClubLandingScreeen.getChallenges(
 * ), 30, 2), true); ClickOnMobileElement(bookClubLandingScreeen.getAddCTA());
 * ClickOnMobileElement(createBasicChallenge.getAddFriendCTA());
 * 
 * }
 * 
 * @When("User enter characters for search in the search bar") public void
 * user_enter_characters_for_search_in_the_search_bar() throws IOException { if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * 
 * SendKeysOnMobileElement(addfriends.getSearchBox(),
 * getData("SearchFriendInput")); } else {
 * 
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Photon");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER); } }
 * 
 * @Then("User should be able to view the suggested search results based on the search input string When {int} characters minimum are entered"
 * ) public void
 * user_should_be_able_to_view_the_suggested_search_results_based_on_the_search_input_string_When_characters_minimum_are_entered
 * (Integer int1) throws IOException { if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * addfriends.getSearchBox().clear();
 * SendKeysOnMobileElement(addfriends.getSearchBox(),getData("SearchFriendInput"
 * )); List<MobileElement> userNamelist = addfriends.userNameText;
 * if(userNamelist.size()!=0) { Assert.assertTrue("list is Displayed",true); } }
 * else{
 * 
 * SendKeysOnWebElement(addfriends.getSearchBox(), "pho");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER); List<MobileElement>
 * userNamelist1 = addfriends.userNameText; if(userNamelist1.size()!=0) {
 * 
 * Assert.assertTrue("list is Displayed",true); } }
 * 
 * }
 * 
 * @Then("User should be able to edit the search input string as required and view the corresponding search suggestions updated"
 * ) public void
 * user_should_be_able_to_edit_the_search_input_string_as_required_and_view_the_corresponding_search_suggestions_updated
 * () throws IOException, InterruptedException { if
 * (getData("platformName").equalsIgnoreCase("android") ||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * addfriends.getSearchBox().clear();
 * SendKeysOnMobileElement(addfriends.getSearchBox(),
 * getData("SearchFriendeditInput")); List<MobileElement> userNamelist =
 * addfriends.userNameText; for (int i = 0; i < userNamelist.size(); i++) {
 * userNamelist.get(i).getText().contains(getData("SearchFriendeditInput"));
 * Assert.assertTrue(true); } addfriends.getSearchBox().clear();
 * SendKeysOnMobileElement(addfriends.getSearchBox(),
 * getData("SearchFriendInput2")); List<MobileElement> userNamelist1 =
 * addfriends.userNameText; for (int i = 0; i < userNamelist1.size(); i++) {
 * userNamelist1.get(i).getText().contains(getData("SearchFriendInput2"));
 * Assert.assertTrue(true); }
 * 
 * waitFor(5000); } else { addfriends.getSearchBox().clear();
 * SendKeysOnWebElement(addfriends.getSearchBox(), "Student");
 * addfriends.getSearchBox().sendKeys(Keys.ENTER); List<MobileElement>
 * userNamelist = addfriends.userNameText; for (int i = 0; i <
 * userNamelist.size(); i++) {
 * userNamelist.get(i).getText().equalsIgnoreCase("Student");
 * Thread.sleep(2000); Assert.assertTrue(true); } waitFor(5000); } }
 * 
 * @Then("When user enters {int} or more characters as the search string list of suggestions should be provided"
 * ) public void
 * when_user_enters_or_more_characters_as_the_search_string_list_of_suggestions_should_be_provided(
 * Integer int1) { Boolean search = true; List<MobileElement> userNamelist =
 * addfriends.userNameText; if (userNamelist.size() != 0) { for (int i = 0; i <
 * userNamelist.size(); i++) { userNamelist.get(i).getText().contains("Phot");
 * Assert.assertTrue(search); }
 * System.out.println("Search Suggestions displyed"); } }
 * 
 * @Then("Search suggestions should not be displayed When user has entered {int} or less characters in the search field"
 * ) public void
 * search_suggestions_should_not_be_displayed_When_user_has_entered_or_less_characters_in_the_search_field(
 * Integer int1) { Boolean search = true;
 * SendKeysOnMobileElement(addfriends.getSearchBox(), "Ph"); List<MobileElement>
 * userNamelist = addfriends.userNameText; int listSize = userNamelist.size();
 * if (listSize != 0) { search = false;
 * System.out.println("Search Result displayed"); Assert.assertTrue(search); }
 * else { System.out.println("Search Result is not displayed");
 * Assert.assertTrue(search); } }
 * 
 * @Then("User should be able to tap on Invite CTA to add the required friends from the search results to the list of invitees"
 * ) public void
 * user_should_be_able_to_tap_on_Invite_CTA_to_add_the_required_friends_from_the_search_results_to_the_list_of_invitees
 * () { Boolean search = true; List<MobileElement> userNamelist =
 * addfriends.userNameText; for (int i = 0; i < userNamelist.size(); i++) {
 * userNamelist.get(i).getText().contains("Phot"); Assert.assertTrue(search); }
 * }
 * 
 * @When("User adds a friend by tapping on Invite button") public void
 * user_adds_a_friend_by_tapping_on_Invite_button() {
 * 
 * List<MobileElement> inviteopt = addfriends.inviteOptionList; for (int i = 0;
 * i < 3; i++) { inviteopt.get(i).click(); }
 * ClickOnMobileElement(addfriends.getAddToChallenge()); }
 * 
 * @Then("User should be able to tap on the X icon next to each friend added and remove them from the list of invitees"
 * ) public void
 * user_should_be_able_to_tap_on_the_X_icon_next_to_each_friend_added_and_remove_them_from_the_list_of_invitees
 * () throws IOException { if
 * (getData("platformName").equalsIgnoreCase("android")||
 * getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * ClickOnMobileElement(addfriends.getInviteOption()); List<MobileElement>
 * addedFriendInSearchFriendList = addfriends.addedFriendInSearchPage; int
 * before = addedFriendInSearchFriendList.size();
 * logger.info("added friend list size :"
 * +addedFriendInSearchFriendList.size()); for (int i = 0; i <
 * addedFriendInSearchFriendList.size(); i++) {
 * Assert.assertTrue(addfriends.addedFriendInSearchPage.get(i).isDisplayed()); }
 * ClickOnMobileElement(addfriends.removeFriendInSearchPage1); int after =
 * addedFriendInSearchFriendList.size();
 * logger.info("added friend list size after removing :"
 * +addedFriendInSearchFriendList.size()); if(before==after) {
 * System.out.println("Selected user is not removed"); } else {
 * logger.info("invitee removed from the list"); } } else{ boolean removeFriend
 * = true; int beforeFriendListSize =
 * createBasicChallenge.addedFriendavatarList.size();
 * System.out.println("Before List Size: "+beforeFriendListSize); for (int i =
 * 0; i < createBasicChallenge.addedFriendavatarList.size(); i++) {
 * Assert.assertTrue(createBasicChallenge.addedFriendavatarList.get(i).
 * isDisplayed()); if(i>1) {
 * createBasicChallenge.removeFriendXIcon.get(i).click();
 * createBasicChallenge.friendRemoveButton.click(); } } int afterFrientListSize
 * = createBasicChallenge.addedFriendavatarList.size();
 * System.err.println("After List Size: "+afterFrientListSize); if
 * (beforeFriendListSize==afterFrientListSize) {
 * System.out.println("User is not removed Yet"); removeFriend =false;
 * Assert.assertTrue(removeFriend); } else {
 * System.out.println("User is removed Sucessfully");
 * Assert.assertTrue(removeFriend); } } }
 * 
 * 
 * }
 * 
 */