package com.stepdefinition;

public class CreateAChallengeSearchTitlesDefaultState_StepDef {

}
