package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.Screenshots;
import com.mongodb.gridfs.CLI;
import com.pom.BookClubLandingScreen;
import com.pom.CreateAChallengeBasicChallengeDetails;
import com.pom.CreateAChallengeCreatorRCDetailsScreen;
//import com.pom.CreateAChallengeCreatorRCDetailsScreen;
import com.pom.CreateAChallengeCreatorRCDetailsScreenMoreIcon;
import com.pom.CreateAChallengeSetReadbyDate;
import com.pom.CreateChallengeAddFriends;
import com.pom.CreateChallengeAddTitles;
import com.pom.CreateChallengeSetReminders;
import com.pom.CreateaChallengeSearchTitleResultsListView;
import com.pom.DD_Reg_RC;
import com.pom.EditChallengeUpDateRcDetailsScreen;
import com.pom.Login;
import com.pom.RC_SmokePage;
import com.pom.ReadingChallengeAcceptRejectChallenge;
import com.pom.ReadingChallengeReportAbuse;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.android.nativekey.PressesKey;

public class DD_Reg_RC_StepDef extends CapabilitiesAndWebDriverUtils{
	
	public static final Logger logger = LogManager.getLogger(Login.class);
	
	Login login = new Login();
	DD_Reg_RC reg = new DD_Reg_RC();
	
	Date date = java.util.Calendar.getInstance().getTime();
	
/********************************************** Reading Challenge - Creator *******************************************/	
	
	@Then("Validate user able to Save the Challenge without mandatory details")
	public void validate_user_able_to_Save_the_Challenge_without_mandatory_details() throws IOException {
	   reg.saveChMandatoryCheck();
	}
	
	@Then("Enter Duplicate Challenge Name")
	public void enter_Duplicate_Challenge_Name() throws IOException {
		reg.duplicateChallengeName();
	}
	
	@Then("Validate alert message saving challenge with duplicate name")
	public void validate_alert_message_saving_challenge_with_duplicate_name() throws InvalidFormatException, IOException {
	    reg.duplicateAlertCheck();
	}
	
	@Then("Tap on Save challenge")
	public void tap_on_Save_challenge() throws IOException {
	    reg.saveChallengeTap();
	}
	
	@Then("Tap on add friend CTA")
	public void tap_on_add_friend_CTA() throws InvalidFormatException, IOException {
		reg.addFriendCTATap();
	}
	
	@Then("Verify user not able to add same user twice")
	public void verify_user_not_able_to_add_same_user_twice() throws InvalidFormatException, IOException {
		reg.addSameFriendCheck();
	}
	
	@Then("Verify usere able to remove friend from the challenge")
	public void verify_usere_able_to_remove_friend_from_the_challenge() throws InvalidFormatException, IOException {
	   reg.removeFriend();
	}
	
	@Then("Tap on add title CTA")
	public void tap_on_add_title_CTA() {
	   reg.addTitleCTATap();
	}

	@Then("Verify user able to add same title twice to the challenge")
	public void verify_user_able_to_add_same_title_twice_to_the_challenge() throws InvalidFormatException, IOException {
		reg.addSameTitleCheck();
	}
	
	@Then("Navigate to MyStuff page")
	public void navigate_to_MyStuff_page() throws InvalidFormatException, IOException {
	   reg.myStuffNav();
	}

	@Then("Verify user is able to add title to challenge from all the tabs")
	public void verify_user_is_able_to_add_title_to_challenge_from_all_the_tabs() throws IOException {
		reg.addTitlefromMyStuff();
	}
	
	@Then("Navigate to Discover page")
	public void navigate_to_Discover_page() throws InvalidFormatException, IOException {
	    reg.discoverNav();
	}

	@Then("Verify user is able to add title to challenge from Discover page")
	public void verify_user_is_able_to_add_title_to_challenge_from_Discover_page() throws IOException {
	    reg.addTitlefromDiscover();	
	}
	
	@Then("Verify user is able to add title to challenge from home page")
	public void verify_user_is_able_to_add_title_to_challenge_from_home_page() throws IOException {
		reg.addTitlefromHome();
	}
	
	@Then("Verify user able to see Active challenges under active challenges section")
	public void verify_user_able_to_see_Active_challenges_under_active_challenges_section() throws IOException {
		reg.activeChallengeCheck();
	}
	
	@Then("Verify user able to see saved challenges under Draft challenges section")
	public void verify_user_able_to_see_saved_challenges_under_Draft_challenges_section() throws IOException {
	    reg.draftChallengesCheck();
	}

	@Then("Verify user able to see Closed challenges under Closed challenges section")
	public void verify_user_able_to_see_Closed_challenges_under_Closed_challenges_section() throws IOException {
	    reg.closedChallengesCheck();
	}
	
	@Then("Tap on Set Read By Date")
	public void tap_on_Set_Read_By_Date() throws IOException {
	    reg.setReadByDtTap();
	}

	@Then("Verify user able to start challenge with current date as challenge end date")
	public void verify_user_able_to_start_challenge_with_current_date_as_challenge_end_date() throws Exception {
	    reg.endDateCheck();
	}
	
/********************************************** Reading Challenge - Edit **********************************************/	

	@Then("Verify user able to close the challege")
	public void verify_user_able_to_close_the_challege() {
		reg.closeChallenge();
	}

	@Then("Verify Closed challenge is not displayed in Active challenges")
	public void verify_Closed_challenge_is_not_displayed_in_Active_challenges() throws IOException {
	   reg.closedChallengeValidation();
	}
	
/********************************************** Reading Challenge - Participant 
 * @throws IOException ***************************************/	
	
	@Then("Navigate to any Active challenge")
	public void navigate_to_any_Active_challenge() throws IOException {
	   reg.navToActiveChallenge();
	}

	@Then("Validate Participant Reading challenge preview screen")
	public void validate_Participant_Reading_challenge_preview_screen() throws Exception {
		reg.participantRCDetailScreen();
	}

	@Then("Verify creator able to Add the same user who rejects the Challenge")
	public void verify_creator_able_to_Add_the_same_user_who_rejects_the_Challenge() throws InvalidFormatException, IOException {
		reg.addSameUser();
	}

	@Then("logout from the application")
	public void logout_from_the_application() throws InvalidFormatException, IOException {
	    login.logOut();
	    waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
	    ClickOnMobileElement(login.Continue);
	}
	
/********************************************** Reading Challenge - Message Center ***************************************/	
	
	@When("Verify the naviagte inside message center page")
	public void verify_the_naviagte_inside_message_center_page() throws InvalidFormatException, IOException {    
		reg.messageCenterNav();
	}
	
	@Then("Verify user navigates to message detail page")
	public void verify_user_navigates_to_message_detail_page() throws IOException {
	    reg.messageCenterDetailScreenNav();
	}
	
	@Then("Verify that message center notification count decrease after read the notification")
	public void verify_that_message_center_notification_count_decrease_after_read_the_notification() throws IOException {
		reg.decreaseCount();
	}
	
	@When("Verify the naviagte inside message center page and scroll down inside message center page")
	public void verify_the_naviagte_inside_message_center_page_and_scroll_down_inside_message_center_page() throws InvalidFormatException, IOException {
		reg.msgCenterScroll();
	}

	@Then("Mark all messages as unread")
	public void mark_all_messages_as_unread() {
	    reg.markAsUnread();
	}

	@Then("Verify that message center notification count increase after change into the challenge")
	public void verify_that_message_center_notification_count_increase_after_change_into_the_challenge() throws IOException {
		reg.increaseCount();
	}
	
	@Then("Verify user able to Mark message as read")
	public void verify_user_able_to_Mark_message_as_read() throws IOException {
	   reg.markAsRead();
	   reg.increaseCount();
	}
	
	@Then("Verify user able to Mark message as unread")
	public void verify_user_able_to_Mark_message_as_unread() throws IOException {
	    reg.markAsUnread();
	    reg.increaseCount();	
	}
	
	
}
