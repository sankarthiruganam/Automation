package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubParticipantRPDetailsScreenPage;
import com.pom.DD_Reg_RP;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DD_Reg_RP_StepDef extends CapabilitiesAndWebDriverUtils {
	BookClubParticipantRPDetailsScreenPage bookclubRp = new BookClubParticipantRPDetailsScreenPage();
	MyPrograms myProgram=new MyPrograms();
	OpenProgram openProgram = new OpenProgram();
	Message_Center messageCenter = new Message_Center();
	DD_Reg_RP rpreg=new DD_Reg_RP();
	
	@Then("Verify user able to navigate to My Program Tab")
	public void verify_user_able_to_navigate_to_My_Program_Tab() throws InvalidFormatException, IOException {
		rpreg.navigateToMyProgram();
	}

	@Then("Verify user able to see Active programs under Active Program section")
	public void verify_user_able_to_see_Active_programs_under_Active_Program_section() throws IOException {
	   rpreg.activeProgramSection();
	}

	@Then("Verify user able to see Saved programs under Draft Program section")
	public void verify_user_able_to_see_Saved_programs_under_Draft_Program_section() throws IOException {
		rpreg.draftProgramSection();
	}

	@Then("Verify user able to see Closed programs under closed Program section")
	public void verify_user_able_to_see_Closed_programs_under_closed_Program_section() throws IOException {
		rpreg.closedProgramSection();;
	}

	@Then("Verify user can able to see ongoing programs")
	public void verify_user_can_able_to_see_ongoing_programs() throws IOException {
		rpreg.onGoingProgramSection();
	}

	@Then("Verify user can able to see Upcoming programs")
	public void verify_user_can_able_to_see_Upcoming_programs() throws IOException {
		rpreg.upComingProgramSection();
	}
	
	@Then("Verify user should be able to view the my program details page")
	public void verify_user_should_be_able_to_view_the_my_program_details_page() throws IOException {
		rpreg.myProgramsDetailsScreenValidation();
	}
	
	@When("Verify user able to Reject program")
	public void verify_user_able_to_Reject_program() throws IOException {
		openProgram.onGoingProgReject();
	   
	}

	@Then("Verify use able to join upcoming program and navigate to Program details page")
	public void verify_use_able_to_join_upcoming_program_and_navigate_to_Program_details_page() throws ParseException, IOException {
		openProgram.upComingProgramJoin();
	}

	@Then("Verify use able to Reject upcoming program")
	public void verify_use_able_to_Reject_upcoming_program() throws ParseException, IOException {
		openProgram.upComingProgramReject();
	}
	
	@When("Verify user able to view Program name Read by date and description in program card")
	public void verify_user_able_to_view_Program_name_Read_by_date_and_description_in_program_card() throws IOException {
		rpreg.adminMyPrgcardValidation();
	}

	@Then("Verify user should be able to view the my program details page for Paticipant View")
	public void verify_user_should_be_able_to_view_the_my_program_details_page_for_Paticipant_View() throws IOException {
	   myProgram.myProgramsDetailsScreenValidation();
	}
		
}
