package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.Screenshots;
import com.pom.Login;
import com.pom.Message_Center;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MessageCenter_StepDef extends CapabilitiesAndWebDriverUtils{
	
	public static final Logger logger = LogManager.getLogger(MessageCenter_StepDef.class);
	
	Login login = new Login();
	Message_Center mc = new Message_Center();
	
	@When("Verify the message centre icon contains number of unread messages")
	public void verify_the_message_centre_icon_contains_number_of_unread_messages() throws IOException {   
		mc.unreadMessageCount();
	}

	@When("Verify the naviagtion forth and back to Message center and scroll up and down inside message center page")
	public void verify_the_naviagtion_forth_and_back_to_Message_center_and_scroll_up_and_down_inside_message_center_page() throws InvalidFormatException, IOException {
	   mc.messageCenternavigation();;
	}

	@When("Verify user navigates to message detail screen when the tap on any message")
	public void verify_user_navigates_to_message_detail_screen_when_the_tap_on_any_message() throws IOException, InvalidFormatException {
	    mc.messageDetailScreen();
	}

	@When("Verify edit option in message centre")
	public void verify_edit_option_in_message_centre() throws IOException, InvalidFormatException {
	   mc.messagecenterEdit();
	}

	@When("Verify user able to left swipe the messages to view options Mark as Read or unread")
	public void verify_user_able_to_left_swipe_the_messages_to_view_options_Mark_as_Read_or_unread() throws InvalidFormatException, IOException {
	    mc.swipeLeftMarkOptionValidation();
	}

	@When("Verify user able to left swipe the messages to view delete option to delete that particular messages")
	public void verify_user_able_to_left_swipe_the_messages_to_view_delete_option_to_delete_that_particular_messages() throws IOException, Throwable {
	   mc.swipeLeftDeleteOptionValidation();
	}
	
	@When("Login as user {string} and {string} click submit button")
	public void login_as_user_and_click_submit_button(String UserName, String Password) throws InvalidFormatException, IOException, InterruptedException {
		ClickOnMobileElement(login.btn_SearchSchoolCont);
		ClickOnMobileElement(login.Continue);
		login.login(UserName, Password);
	}

	@When("Verify the inline message when user has no message to display")
	public void verify_the_inline_message_when_user_has_no_message_to_display() throws InvalidFormatException, IOException {
		mc.inlineMessgaeValidation();
	}
	@Then("Verify the Mark as unread option user able to click on message details")
	public void verify_the_Mark_as_unread_option_user_able_to_click_on_message_details() throws InvalidFormatException, IOException {
		 mc.swipeLeftMarkOptionValidation();
	}
}
