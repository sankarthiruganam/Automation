package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.base.CapabilitiesAndWebDriverUtils;
import com.mongodb.gridfs.CLI;
import com.pom.BookClubLandingScreen;
import com.pom.CreateAChallengeBasicChallengeDetails;
import com.pom.CreateAChallengeCreatorRCDetailsScreen;
//import com.pom.CreateAChallengeCreatorRCDetailsScreen;
import com.pom.CreateAChallengeCreatorRCDetailsScreenMoreIcon;
import com.pom.CreateAChallengeSetReadbyDate;
import com.pom.CreateChallengeAddFriends;
import com.pom.CreateChallengeAddTitles;
import com.pom.CreateChallengeSetReminders;
import com.pom.CreateaChallengeSearchTitleResultsListView;
import com.pom.EditChallengeUpDateRcDetailsScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.RC_SmokePage;
import com.pom.ReadingChallengeAcceptRejectChallenge;
import com.pom.ReadingChallengeReportAbuse;

import cucumber.api.java.en.When;

public class RC_Notifications_StepDef extends CapabilitiesAndWebDriverUtils{
	
	public static final Logger logger = LogManager.getLogger(Login.class);
	
	Login login	= new Login();
	BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
	CreateAChallengeBasicChallengeDetails createBasicChallenge = new CreateAChallengeBasicChallengeDetails();
	Message_Center mc = new Message_Center();
	
	@When("Create New challenge")
	public void create_New_challenge() throws Exception {
		createBasicChallenge.createChallenge();
		waitFor(5000);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		waitFor(3000);
		login.logOut();
		waitFor(3000);
	}

	@When("Verify invited user recieved challenge invite")
	public void verify_invited_user_recieved_challenge_invite() throws InvalidFormatException, IOException {
	   ClickOnMobileElement(bookClubLandingScreeen.messageCenterIcon);
	   mc.rcInviteNotification();
	}

	@When("Accept challenge from message center")
	public void accept_challenge_from_message_center() throws InvalidFormatException, IOException {
		mc.rcAccept();
		waitFor(2000);
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
		ClickOnMobileElement(login.Continue);
	}

	@When("Verify creator recieved challenge accepted notification")
	public void verify_creator_recieved_challenge_accepted_notification() throws InvalidFormatException, IOException {
	   mc.inviteAcceptedNotification();
		
	}

	@When("Add new title to the challenge")
	public void add_new_title_to_the_challenge() throws InvalidFormatException, IOException {
	   mc.addNewTitleToChallenge();
	   login.logOut();
	   waitFor(3000);
	}

	@When("Verify invited user recieved title added notification")
	public void verify_invited_user_recieved_title_added_notification() throws InvalidFormatException, IOException {
		mc.titleAddedNotification();
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
	    ClickOnMobileElement(login.Continue);
	}

	@When("Remove title from challenge")
	public void remove_title_from_challenge() throws IOException, InvalidFormatException {
		mc.removeTitleFromChallenge();
		login.logOut();
		waitFor(3000);
	}

	@When("Verify invited user recieved title removed notification")
	public void verify_invited_user_recieved_title_removed_notification() throws InvalidFormatException, IOException {
		mc.titleRemovedNotification();
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
	    ClickOnMobileElement(login.Continue);
	}

	@When("update challenge end date")
	public void update_challenge_end_date() throws IOException, InvalidFormatException {
		mc.updateChallengeEndDate();
		login.logOut();
		waitFor(3000);
	}

	@When("Verify invited user recieved challenge end date updated notification")
	public void verify_invited_user_recieved_challenge_end_date_updated_notification() throws InvalidFormatException, IOException {
		mc.chDateUpdatedNotification();
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
	    ClickOnMobileElement(login.Continue);

	}

	@When("update challenge Name")
	public void update_challenge_Name() throws IOException, InvalidFormatException {
		mc.updateChallenegeName();
		login.logOut();
		waitFor(3000);
	}

	@When("Verify invited user recieved challenge Name updated notification")
	public void verify_invited_user_recieved_challenge_Name_updated_notification() throws InvalidFormatException, IOException {
		mc.chNameUpdateNotification();
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
	    ClickOnMobileElement(login.Continue);
	}

	@When("Add New Participant to challenge")
	public void add_New_Participant_to_challenge() throws InvalidFormatException, IOException {
		mc.addNewUserToChallenge();
		login.logOut();
		waitFor(3000);
	}

	@When("Verify New participant recieved challenge invite notification")
	public void verify_New_participant_recieved_challenge_invite_notification() throws InvalidFormatException, IOException {
		
		ClickOnMobileElement(bookClubLandingScreeen.messageCenterIcon);
		mc.newUserRCInviteNotification();
	}
	
	@When("Verify New Participant can able to Accept challenge from message center")
	public void verify_New_Participant_can_able_to_Accept_challenge_from_message_center() throws InvalidFormatException, IOException {
		mc.rcAccept();
		waitFor(2000);
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
		ClickOnMobileElement(login.Continue);
	}

	@When("Remove friend from challenge")
	public void remove_friend_from_challenge() throws InvalidFormatException, IOException {
		mc.removeFriendFromChallenge();
		login.logOut();
		waitFor(3000);
	}

	@When("Verify Removed friend recieved Participant Removed notification")
	public void verify_Removed_friend_recieved_Participant_Removed_notification() throws InvalidFormatException, IOException {
	   mc.paricipantRemovedNotification();
	}	
	
	
	/**************************************************** Invite Rejected****************************************************/
	
	@When("Reject challenge from message center")
	public void reject_challenge_from_message_center() throws InvalidFormatException, IOException {
		mc.rcReject();
		login.logOut();
		waitFor(3000);
		ClickOnMobileElement(login.btn_SearchSchoolCont);
		ClickOnMobileElement(login.Continue);
	}

	@When("Verify creator recieved challenge rejected notification")
	public void verify_creator_recieved_challenge_rejected_notification() throws InvalidFormatException, IOException {
	   mc.inviteRejectNotification();
	}
	
}
