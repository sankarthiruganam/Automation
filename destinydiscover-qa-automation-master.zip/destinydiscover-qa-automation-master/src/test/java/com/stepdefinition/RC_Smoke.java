package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.base.Screenshots;
import com.pom.BookClubLandingScreen;
import com.pom.CreateAChallengeBasicChallengeDetails;
import com.pom.CreateAChallengeCreatorRCDetailsScreen;
import com.pom.Login;
import com.pom.RC_SmokePage;

import cucumber.api.java.en.And;

public class RC_Smoke extends CapabilitiesAndWebDriverUtils{
	
	BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
	CreateAChallengeBasicChallengeDetails createBasicChallenge = new CreateAChallengeBasicChallengeDetails();
	Login login = new Login();

	
	@And("Validate Create Challenge Icon")
	public void validate_Create_Challenge_Icon() throws InvalidFormatException, IOException {
		RC_SmokePage.addCreateChallengeButton();
	}

	@And("Validate Enter Challenge Name")
	public void validate_Enter_Challenge_Name() throws Exception {
		RC_SmokePage.enterChallengeName();
	}

	@And("Validate Enter Challenge Description")
	public void validate_Enter_Challenge_Description() throws InvalidFormatException, IOException {
		RC_SmokePage.enterChallengeDescName();
	}

	@And("Validate Search and add invite Friend")
	public void validate_Search_and_add_invite_Friend() throws InvalidFormatException, IOException {
		RC_SmokePage.searchAndAddFriend();
	}

	@And("Validate Set Reminder")
	public void validate_Set_Reminder() throws InvalidFormatException, IOException {
		RC_SmokePage.setReminder();
	}

	@And("Validate Set Read By Date")
	public void validate_Set_Read_By_Date() throws InvalidFormatException, IOException {
		RC_SmokePage.setDate();
	}

	@And("Validate Search and Add Title")
	public void validate_Search_and_Add_Title() throws InvalidFormatException, IOException {
		RC_SmokePage.searchAndAddTitle();
	}

	@And("Validate Save the Challenge with details")
	public void validate_Save_the_Challenge_with_details() throws IOException, InterruptedException { 
		RC_SmokePage.saveChallenge();
	}

	@And("Validate Create Challenge")
	public void validate_Create_Challenge() throws IOException, InvalidFormatException {
		RC_SmokePage.startChallengeButton();
	}

	@And("Validate Edit Challenge")
	public void validate_Edit_Challenge() throws InvalidFormatException, IOException {
		RC_SmokePage.editChallenge();
	}

	@And("Validate Verify the created challenge in creater challenge dashboard")
	public void validate_Verify_the_created_challenge_in_creater_challenge_dashboard() throws InvalidFormatException, IOException, InterruptedException {
		waitFor(5000);
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		RC_SmokePage.challengeDisplayCheck();
		waitFor(3000);
		login.logOut();
	}
	
	@And("Accept challenge and challenge confirmation page")
	public void accept_challenge_and_challenge_confirmation_page() throws IOException, InterruptedException {
		RC_SmokePage.acceptChallenge();
	}

	@And("Validate the challenge details when participant click on it on Challenge dashboard")
	public void validate_the_challenge_details_when_participant_click_on_it_on_Challenge_dashboard() throws InvalidFormatException, IOException {
		RC_SmokePage.rcPageValiation();
		
	}
	@And("Verify the message related to RC invite")
	public void verify_the_message_related_to_RC_invite() throws InvalidFormatException, IOException {
		RC_SmokePage.rcInviteValidation();
		
	}

	/*
	 * @And("Verify the unread message appears in top order of the page") public
	 * void verify_the_unread_message_appears_in_top_order_of_the_page() {
	 * 
	 * }
	 * 
	 * @And("Verify the read message appears below the unread message") public void
	 * verify_the_read_message_appears_below_the_unread_message() {
	 * 
	 * }
	 * 
	 * @And("Verify latest message appears on top of the message list") public void
	 * verify_latest_message_appears_on_top_of_the_message_list() {
	 * 
	 * }
	 */

	@And("Verify user able to navigate inside the message details screen")
	public void verify_user_able_to_navigate_inside_the_message_details_screen() throws IOException, InvalidFormatException {
		RC_SmokePage.msgDetailsScreen();
	}
}
