package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.base.CapabilitiesAndWebDriverUtils;
import com.mongodb.gridfs.CLI;
import com.pom.BookClubLandingScreen;
import com.pom.CreateAChallengeBasicChallengeDetails;
import com.pom.CreateAChallengeCreatorRCDetailsScreen;
//import com.pom.CreateAChallengeCreatorRCDetailsScreen;
import com.pom.CreateAChallengeCreatorRCDetailsScreenMoreIcon;
import com.pom.CreateAChallengeSetReadbyDate;
import com.pom.CreateChallengeAddFriends;
import com.pom.CreateChallengeAddTitles;
import com.pom.CreateChallengeSetReminders;
import com.pom.CreateaChallengeSearchTitleResultsListView;
import com.pom.EditChallengeUpDateRcDetailsScreen;
import com.pom.Login;
import com.pom.ReadingChallengeAcceptRejectChallenge;
import com.pom.ReadingChallengeReportAbuse;

import cucumber.api.java.en.When;

public class RC_View_Challenge_StepDef extends CapabilitiesAndWebDriverUtils{
	
	public static final Logger logger = LogManager.getLogger(Login.class);
	
	Login login	= new Login();
	BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
	CreateAChallengeBasicChallengeDetails createBasicChallenge = new CreateAChallengeBasicChallengeDetails();
	
	@When("Verify if user is able to view the challenges that they are participating")
	public void verify_if_user_is_able_to_view_the_challenges_that_they_are_participating() {
		bookClubLandingScreeen.challengeDisplay();
	}

	@When("Verify if percentage of completion is provided based on the progress made")
	public void verify_if_percentage_of_completion_is_provided_based_on_the_progress_made() throws IOException {
		bookClubLandingScreeen.progressPercentageValidation();
	}

	@When("Verify the icon of the percentage completion according to the value")
	public void verify_the_icon_of_the_percentage_completion_according_to_the_value() throws IOException {
		bookClubLandingScreeen.progressPercentBarValidation();
	}

	@When("Verify if user can view the time spent on the particular challenge")
	public void verify_if_user_can_view_the_time_spent_on_the_particular_challenge() throws IOException {
	   bookClubLandingScreeen.hrsSpentValidation();
	}

	@When("Verify the UI when the user has not accepted")
	public void verify_the_UI_when_the_user_has_not_accepted() throws IOException {
	   bookClubLandingScreeen.challengeInviteValidation();
	}

	@When("Verify user should not be able to view the progress percentage or hours spent for Draft Challenges and Closed Challenges")
	public void verify_user_should_not_be_able_to_view_the_progress_percentage_or_hours_spent_for_Draft_Challenges_and_Closed_Challenges() throws IOException, InvalidFormatException {
	   bookClubLandingScreeen.DraftClosedChallengeValidation();
	   login.logOut();
	}
	
	@When("Validate book club landing page when there are no reading challenges")
	public void validate_book_club_landing_page_when_there_are_no_reading_challenges() throws InvalidFormatException, IOException {
		bookClubLandingScreeen.ChlandingScreenValidation();
	}
	
}
