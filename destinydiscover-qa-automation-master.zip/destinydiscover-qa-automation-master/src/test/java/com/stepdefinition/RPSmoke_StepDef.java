package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;

import cucumber.api.java.en.When;

public class RPSmoke_StepDef  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	MyPrograms myProgram=new MyPrograms();
	OpenProgram openProgram = new OpenProgram();
	Message_Center messageCenter = new Message_Center();
	
	@When("Verify and Handle Set Preference Page")
	public void verify_and_Handle_Set_Preference_Page() throws InvalidFormatException, IOException {
	    login.setPreference();
	}
	
	@When("Click the book club option and verify the challenges,myprogram,openprogram tabs")
	public void click_the_book_club_option_and_verify_the_challenges_myprogram_openprogram_tabs() throws IOException {
		myProgram.headerValidation();
	}
	
	@When("Verify the my program detail page")
	public void verify_the_my_program_detail_page() throws IOException {
		myProgram.myProgramsDetailsScreenValidation();
	}

	@When("Click the myprograms and verify the active draft closed programs list")
	public void click_the_myprograms_and_verify_the_active_draft_closed_programs_list() throws IOException {
		myProgram.validatingActiveDraftClosedPrograms();
	}

	@When("Click ongoing tab and verify the detail screen")
	public void click_ongoing_tab_and_verify_the_detail_screen() throws IOException {
	    openProgram.onGoingProgramDetailPageValidation();
	}
	
	@When("Click the join program button and verify the rp detail page")
	public void click_the_join_program_button_and_verify_the_rp_detail_page() throws IOException {
		openProgram.joinProgramDetailPageValidation();
	}

	@When("Verify the ongoing and upcoming programs list")
	public void verify_the_ongoing_and_upcoming_programs_list() throws IOException {
	    openProgram.onGoingupComingPrg();
	}
	
	@When("Verify user should be able to see RP invite message under message center")
	public void verify_user_should_be_able_to_see_RP_invite_message_under_message_center() throws IOException, InvalidFormatException {  
//		messageCenter.rpMessageValdation();
	}

	@When("Verify user navigates to message detail screen")
	public void verify_user_navigates_to_message_detail_screen() throws IOException {
//		messageCenter.rpMessageDetailScreenValidation();
	}
	
}
