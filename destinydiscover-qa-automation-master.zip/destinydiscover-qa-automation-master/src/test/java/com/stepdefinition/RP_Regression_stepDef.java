package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubParticipantRPDetailsScreenPage;
import com.pom.Login;

import cucumber.api.java.en.Then;

public class RP_Regression_stepDef extends CapabilitiesAndWebDriverUtils {
	Login login = new Login();
	BookClubParticipantRPDetailsScreenPage bookclubRp = new BookClubParticipantRPDetailsScreenPage();
	
	@Then("Verify the Set preference screen")
	public void verify_the_Set_preference_screen() throws InvalidFormatException, IOException {
	    // Write code here that turns the phrase above into concrete actions
	    login.setPreference();
	}

	@Then("Validate Home screen title and whether the Book Club menu is present or not in the Bottom Navigation Menu")
	public void validate_Home_screen_title_and_whether_the_Book_Club_menu_is_present_or_not_in_the_Bottom_Navigation_Menu() throws InvalidFormatException, IOException {
		bookclubRp.homeAssertion();
	}

	@Then("Verify the all the mandatory elements in Book Club Landing screen")
	public void verify_the_all_the_mandatory_elements_in_Book_Club_Landing_screen() throws InvalidFormatException, IOException {
	    ClickOnMobileElement(bookclubRp.bookclubMenu);
		bookclubRp.bookclubAssertion();
	}

	@Then("Click on my programs tab and validate all the mandatory elements in My Programs tab")
	public void click_on_my_programs_tab_and_validate_all_the_mandatory_elements_in_My_Programs_tab() throws InvalidFormatException, IOException {
	   ClickOnMobileElement(bookclubRp.myPrograms);
		bookclubRp.myProgramAssertion();
	}

	@Then("Click on open programs tab and validate all the mandatory elements in Open Programs tab")
	public void click_on_open_programs_tab_and_validate_all_the_mandatory_elements_in_Open_Programs_tab() throws InvalidFormatException, IOException {
	   ClickOnMobileElement(bookclubRp.openPrograms); 
	   bookclubRp.openProgramAssertion();
	   
	}
	
	@Then("Open any on-going program in open programs tab and verify all the mandatory elements in program details screen")
	public void open_any_on_going_program_in_open_programs_tab_and_verify_all_the_mandatory_elements_in_program_details_screen() throws InvalidFormatException, IOException {
		ClickOnMobileElement(bookclubRp.OpenprogramBook);
		bookclubRp.programDetailAssertion(true);
		//logger.info("OpenProgram > On-going Program Assertion successfully completed.");
		//ClickOnMobileElement(bookclubRp.noThanksButton);
		return;
	}

	@Then("Verify the join program and no,thanks functionality of on-going program details screen")
	public void verify_the_join_program_and_no_thanks_functionality_of_on_going_program_details_screen() throws InvalidFormatException, IOException {
	    bookclubRp.joinProgram(2);
	}
	
	@Then("Open any active program in my programs tab and verify all the mandatory elements in program details screen")
	public void open_any_active_program_in_my_programs_tab_and_verify_all_the_mandatory_elements_in_program_details_screen() throws InvalidFormatException, IOException {
		WaitForMobileElement(bookclubRp.myPrograms);
		ClickOnMobileElement(bookclubRp.myPrograms);
		WaitForMobileElement(bookclubRp.myprogramBook);
		ClickOnMobileElement(bookclubRp.myprogramBook);
		bookclubRp.programDetailAssertion(false);
		return;
	}
	
	@Then("Validate that the user should able to leave the any active program")
	public void validate_that_the_user_should_able_to_leave_the_any_active_program() throws InvalidFormatException, IOException {
	    bookclubRp.leaveProgram(0);
	}
	
	@Then("Validate user should able to join program by given name program name")
	public void validate_user_should_able_to_join_program_by_given_name_program_name() {
	    // Write code here that turns the phrase above into concrete actions
		
	}

}
