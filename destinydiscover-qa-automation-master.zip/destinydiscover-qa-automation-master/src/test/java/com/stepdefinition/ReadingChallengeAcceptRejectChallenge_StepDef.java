/*
 * package com.stepdefinition;
 * 
 * import java.io.IOException;
 * 
 * import org.junit.Assert; import com.base.CapabilitiesAndWebDriverUtils;
 * import com.pom.BookClubLandingScreen; import
 * com.pom.CreateAChallengeBasicChallengeDetails; import
 * com.pom.CreateAChallengeCreatorRCDetailsScreen; import com.pom.Login; import
 * com.pom.ReadingChallengeAcceptRejectChallenge; import
 * com.pom.ReadingChallengeChallengeAcceptedConfirmation;
 * 
 * import cucumber.api.java.en.When;
 * 
 * public class ReadingChallengeAcceptRejectChallenge_StepDef extends
 * CapabilitiesAndWebDriverUtils {
 * 
 * Login login = new Login(); ReadingChallengeAcceptRejectChallenge
 * accecptChallenge = new ReadingChallengeAcceptRejectChallenge();
 * BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
 * CreateAChallengeBasicChallengeDetails createBasicChallenge = new
 * CreateAChallengeBasicChallengeDetails();
 * ReadingChallengeAcceptRejectChallenge acceptChallegePage = new
 * ReadingChallengeAcceptRejectChallenge();
 * ReadingChallengeChallengeAcceptedConfirmation acceptconfirmation = new
 * ReadingChallengeChallengeAcceptedConfirmation();
 * CreateAChallengeBasicChallengeDetails_StepDef createChallenge = new
 * CreateAChallengeBasicChallengeDetails_StepDef();
 * CreateAChallengeCreatorRCDetailsScreen creatorRCDetailsScreeen = new
 * CreateAChallengeCreatorRCDetailsScreen();
 * 
 * @When("User is on the Book Club landing screen") public void
 * user_is_on_the_Book_Club_landing_screen() {
 * 
 * ClickOnWebElement(bookClubLandingScreeen.getBookClubOption()); }
 * 
 * @When("User has been invited to participate in a Reading Challenge") public
 * void user_has_been_invited_to_participate_in_a_Reading_Challenge() {
 * 
 * //
 * Assert.assertEquals(createBasicChallenge.searchChallengeName.isDisplayed(),
 * true); // String expected =
 * createBasicChallenge.searchChallengeName.getText(); //
 * Assert.assertEquals(CreateAChallengeBasicChallengeDetails_StepDef.
 * actualchallenegeName, expected); }
 * 
 * @When("User taps on the You have been challenged CTA") public void
 * user_taps_on_the_You_have_been_challenged_CTA() throws IOException,
 * InterruptedException {
 * 
 * String ChallengeName = createChallenge.actualchallenegeName;
 * 
 * if (getData("platformName").equalsIgnoreCase("android")
 * 
 * || getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
 * 
 * // scrollNClick(createBasicChallenge.ChallengeNameEle, ChallengeName);
 * 
 * } else { System.out.println("Searching for the Challenge Name : "+
 * ChallengeName );
 * scrollAndClick(CreateAChallengeBasicChallengeDetails.ChallengeNameEle,
 * ChallengeName);
 * 
 * } }
 * 
 * @When("User should be able to view Reading Challenge bottom drawer") public
 * void user_should_be_able_to_view_Reading_Challenge_bottom_drawer() {
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.getReadImage(
 * ), 30, 2), true); System.out.println("ActualChallenge:" +
 * createChallenge.actualchallenegeName);
 * System.out.println("ExpectedChallenge:" +
 * CapabilitiesAndWebDriverUtils.ChallengeName);
 * 
 * Assert.assertEquals(createChallenge.actualchallenegeName,
 * CapabilitiesAndWebDriverUtils.ChallengeName);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.
 * getChallengeDesc(), 30, 2), true);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.
 * getChallengeDesc(), 30, 2), true);
 * 
 * int paticipantsize =
 * CreateAChallengeCreatorRCDetailsScreen.ParticipantsList.size();
 * 
 * if (paticipantsize != 0) {
 * 
 * logger.info("Invited User Displayed");
 * 
 * }
 * 
 * int readinglistsize =
 * CreateAChallengeCreatorRCDetailsScreen.readingList.size();
 * 
 * if (readinglistsize != 0) {
 * 
 * logger.info("Reading List Displayed");
 * 
 * } }
 * 
 * @When("User should be able to view Reading Challenge details such as Name Read By Date Description Challenge icon and Challenge Text"
 * ) public void
 * user_should_be_able_to_view_Reading_Challenge_details_such_as_Name_Read_By_Date_Description_Challenge_icon_and_Challenge_Text
 * () {
 * 
 * Assert.assertEquals(createBasicChallenge.searchChallengeName.isDisplayed(),
 * true); String expectedChallengeName =
 * createBasicChallenge.searchChallengeName.getText();
 * Assert.assertEquals(CreateAChallengeBasicChallengeDetails_StepDef.
 * actualchallenegeName, expectedChallengeName); String expectedChallengeDesc =
 * acceptChallegePage.getDescription().getText();
 * Assert.assertEquals(CreateAChallengeBasicChallengeDetails_StepDef.
 * actualchallenegeDesc, expectedChallengeDesc);
 * Assert.assertEquals(accecptChallenge.getChallengeicon().isDisplayed(), true);
 * Assert.assertEquals(accecptChallenge.getCreatorName().isDisplayed(), true);
 * Assert.assertEquals(acceptChallegePage.getReadByDateText().isDisplayed(),
 * true); if (accecptChallenge.getParticipantsList().size() != 0) { for (int i =
 * 0; i < accecptChallenge.getParticipantsList().size(); i++) {
 * Assert.assertTrue(acceptChallegePage.getParticipantsList().get(i).isDisplayed
 * ()); }
 * 
 * System.out.println("Participant list is Displayed "); } }
 * 
 * @When("User should be able to tap on Accept Challenge CTA to accept the reading challenge invite"
 * ) public void
 * user_should_be_able_to_tap_on_Accept_Challenge_CTA_to_accept_the_reading_challenge_invite
 * () {
 * 
 * ClickOnWebElement(accecptChallenge.getAccpetChallegeButton());
 * 
 * }
 * 
 * @When("User should be navigated to the accept challenge confirmation screen")
 * public void
 * user_should_be_navigated_to_the_accept_challenge_confirmation_screen() throws
 * InterruptedException { Thread.sleep(4000);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(acceptconfirmation.getAccpetedText(),
 * 30, 2), true);
 * 
 * ClickOnMobileElement(acceptconfirmation.getCloseicon());
 * 
 * scrollAndClick(CreateAChallengeBasicChallengeDetails.ChallengeNameEle,
 * ChallengeName);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.
 * readImageafteraccept, 30, 2), true);
 * 
 * System.out.println("ActualChallenge:" +
 * createChallenge.actualchallenegeName);
 * 
 * System.out.println("ExpectedChallenge:" +
 * CapabilitiesAndWebDriverUtils.ChallengeName);
 * 
 * Assert.assertEquals(createChallenge.actualchallenegeName,
 * CapabilitiesAndWebDriverUtils.ChallengeName);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.
 * getChallengeDesc(), 30, 2), true);
 * 
 * Assert.assertEquals(fluentWaitDisplayed(creatorRCDetailsScreeen.
 * reminderValue, 30, 2), true);
 * 
 * int paticipantsize =
 * CreateAChallengeCreatorRCDetailsScreen.participantListafteraccept.size();
 * 
 * if (paticipantsize != 0) {
 * 
 * logger.info("Invited User Displayed");
 * 
 * }
 * 
 * int readinglistsize =
 * CreateAChallengeCreatorRCDetailsScreen.readingListafteraccept.size();
 * 
 * if (readinglistsize != 0) {
 * 
 * logger.info("Reading List Displayed");
 * 
 * } }
 * 
 * @When("User should be able to tap on No thanks CTA to reject the reading challenge invite"
 * ) public void
 * user_should_be_able_to_tap_on_No_thanks_CTA_to_reject_the_reading_challenge_invite
 * () {
 * 
 * ClickOnWebElement(accecptChallenge.getNoThanksButton());
 * Assert.assertEquals(fluentWaitDisplayed(bookClubLandingScreeen.getAddCTA(),
 * 30, 2), true);
 * 
 * }
 * 
 * }
 */