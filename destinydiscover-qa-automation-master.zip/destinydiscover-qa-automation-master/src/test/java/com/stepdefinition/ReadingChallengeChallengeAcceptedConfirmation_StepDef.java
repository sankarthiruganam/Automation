package com.stepdefinition;

import com.base.CapabilitiesAndWebDriverUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReadingChallengeChallengeAcceptedConfirmation_StepDef extends CapabilitiesAndWebDriverUtils{

	@When("User is on the reading challenge bottom drawer")
	public void user_is_on_the_reading_challenge_bottom_drawer() {
	   
	    
	}

	@When("User taps on the Accept Challenge CTA")
	public void user_taps_on_the_Accept_Challenge_CTA() {
	   
	    
	}

	@Then("User should be navigated to the challenge accepted screen")
	public void user_should_be_navigated_to_the_challenge_accepted_screen() {
	   
	    
	}

	@Then("User views the confirmation for accepting challenge with positive reinforcement message")
	public void user_views_the_confirmation_for_accepting_challenge_with_positive_reinforcement_message() {
	   
	    
	}

	@When("User should be able to tap on Go to challenge CTA to navigate to Reading Challenge details screen")
	public void user_should_be_able_to_tap_on_Go_to_challenge_CTA_to_navigate_to_Reading_Challenge_details_screen() {
	   
	    
	}

	@When("User should able to tap on the X icon and navigate back to the Book Club Landing Screen with the challenge added to the users list of participating challenge")
	public void user_should_able_to_tap_on_the_X_icon_and_navigate_back_to_the_Book_Club_Landing_Screen_with_the_challenge_added_to_the_users_list_of_participating_challenge() {
	   
	    
	}
	
	
}
