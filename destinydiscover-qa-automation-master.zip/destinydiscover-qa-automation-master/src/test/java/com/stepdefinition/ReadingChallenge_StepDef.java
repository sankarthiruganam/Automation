package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.base.CapabilitiesAndWebDriverUtils;
import com.mongodb.gridfs.CLI;
import com.pom.BookClubLandingScreen;
import com.pom.CreateAChallengeBasicChallengeDetails;
import com.pom.CreateAChallengeCreatorRCDetailsScreen;
//import com.pom.CreateAChallengeCreatorRCDetailsScreen;
import com.pom.CreateAChallengeCreatorRCDetailsScreenMoreIcon;
import com.pom.CreateAChallengeSetReadbyDate;
import com.pom.CreateChallengeAddFriends;
import com.pom.CreateChallengeAddTitles;
import com.pom.CreateChallengeSetReminders;
import com.pom.CreateaChallengeSearchTitleResultsListView;
import com.pom.EditChallengeUpDateRcDetailsScreen;
import com.pom.Login;
import com.pom.ReadingChallengeAcceptRejectChallenge;
import com.pom.ReadingChallengeReportAbuse;

import cucumber.api.java.en.When;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.android.nativekey.PressesKey;

public class ReadingChallenge_StepDef extends CapabilitiesAndWebDriverUtils{
	
	public static final Logger logger = LogManager.getLogger(Login.class);
	
	Login login	= new Login();
	BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();
	CreateAChallengeBasicChallengeDetails createBasicChallenge = new CreateAChallengeBasicChallengeDetails();
	CreateChallengeAddFriends addFriend = new CreateChallengeAddFriends();
	CreateaChallengeSearchTitleResultsListView searchTitles = new CreateaChallengeSearchTitleResultsListView();
	CreateChallengeSetReminders setReminders = new CreateChallengeSetReminders();
	CreateAChallengeSetReadbyDate setReadbyDate = new CreateAChallengeSetReadbyDate();
	//CreateAChallengeCreatorRCDetailsScreen creatorRCDetailsScreeen = new CreateAChallengeCreatorRCDetailsScreen();
	CreateChallengeAddTitles addTitles = new CreateChallengeAddTitles();
	CreateAChallengeCreatorRCDetailsScreenMoreIcon creatorRCDetailsScreenMoreIcon = new CreateAChallengeCreatorRCDetailsScreenMoreIcon();
	EditChallengeUpDateRcDetailsScreen editchallenge = new EditChallengeUpDateRcDetailsScreen();
	ReadingChallengeAcceptRejectChallenge acceptChallenge = new ReadingChallengeAcceptRejectChallenge();
	
	
	Date date = java.util.Calendar.getInstance().getTime();
	
	/********************************************** Reading Challenge coverage ***************************************************/	
	
	@When("Validate Book Club landing page")
	public void validate_Book_Club_landing_page() throws InvalidFormatException, IOException {
		
		bookClubLandingScreeen.bookClubAssertion();
	}

	@When("Validate create challenge page")
	public void validate_create_challenge_page() throws Exception {
		
		createBasicChallenge.createChallenge();   	
	}
	
	@When("Validate alert message for duplicate challenge name")
	public void validate_alert_message_for_duplicate_challenge_name() throws InvalidFormatException, IOException {
		createBasicChallenge.duplicateChNameValidation();
	}

	@When("Validate Reading challenge preview screen and Verify the challenge in Challenge dashboard")
	public void validate_Reading_challenge_preview_screen_and_Verify_the_challenge_in_Challenge_dashboard() throws Exception {
		CreateAChallengeCreatorRCDetailsScreen.creatorRCDetailScreenValidation();
	}
	
	@When("Validate Edit challenge")
	public void validate_Edit_challenge() throws IOException, InvalidFormatException {
		EditChallengeUpDateRcDetailsScreen.editReadingChalleng();
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		waitFor(3000);
		login.logOut();
		ClickOnMobileElement(login.selectSchool_Xicon);
		waitFor(3000);
	}

	@When("Login as Invited user {string} and {string} click submit button")
	public void login_as_Invited_user_and_click_submit_button(String UserName, String Password) throws InvalidFormatException, IOException, InterruptedException {
		if (getData("platformName").equalsIgnoreCase("android")
				|| getData("platformName").equalsIgnoreCase("BrowserStackandroid")) {
		ClickOnMobileElement(login.btn_SearchSchoolCont);
		ClickOnMobileElement(login.Continue);
		login.login(UserName, Password);	
		}
		if (getData("platformName").equalsIgnoreCase("iOS")
				|| getData("platformName").equalsIgnoreCase("BrowserStackiOS")) {
			waitFor(2000);
			ClickOnMobileElement(login.IOSContinue);
			ClickOnMobileElement(login.btn_SearchSchoolCont);
			waitFor(4000);
			login.login(UserName, Password);	
		}
		
	}

	@When("Validate Accept challenge and challenge confirmation page")
	public void validate_Accept_challenge_and_challenge_confirmation_page() throws IOException, Exception {
		
		acceptChallenge.acceptChallenge();
	}

	@When("Validate the Report Abuse")
	public void validate_the_Report_Abuse() throws Exception {
		
		ReadingChallengeReportAbuse.submitReportAbuse();
	    
	}
	
	/********************************************** Reading Challenge Rejection *************************************************/
	
	@When("Navigate to book club landing page and logout")
	public void navigate_to_book_club_landing_page_and_logout() throws InvalidFormatException, IOException {
		
		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
		waitFor(3000);
		login.logOut();
		waitFor(3000);
		
	}
	
	@When("Validate Challenge rejection page")
	public void validate_Challenge_rejection_page() throws IOException {
		acceptChallenge.rejectChallenge();
		
	}
	
	/*********************************************** Leave Reading challenge from RC page ****************************************/
	
	@When("Validate leave Challenege")
	public void validate_leave_Challenege() throws IOException, InterruptedException {

		CreateAChallengeCreatorRCDetailsScreen.leaveChallenge();
	}
      
	/*********************************************** RC Functional *************************************************/
	
	@When("Validate Discard challenge")
	public void validate_Discard_challenge() throws IOException {
		createBasicChallenge.discardChallenge();   
	}

	@When("Validate save and start button without description and mandatory fields input")
	public void validate_save_and_start_button_without_description_and_mandatory_fields_input() throws InvalidFormatException, IOException {
	   ClickOnMobileElement(bookClubLandingScreeen.addCTA);
	   createBasicChallenge.startButtonValidation();
	}

	@When("Validate add friend page for new user")
	public void validate_add_friend_page_for_new_user() throws IOException {
		waitFor(5000);
		createBasicChallenge.description.clear();
		ClickOnMobileElement(createBasicChallenge.addFriendCTA);
	    addFriend.addFriendPageForNewUser();
	}

	@When("Validate adding already added friend and remove friend cancel button in CC page")
	public void validate_adding_already_added_friend_and_remove_friend_cancel_button_in_CC_page() throws InvalidFormatException, IOException {
		addFriend.alreadyAddedFriend();
	}

	@When("Validate title search page for new user and search page for invalid input")
	public void validate_title_search_page_for_new_user_and_search_page_for_invalid_input() throws InvalidFormatException, IOException {
	   swipeDown();
	   setReadbyDate.androidSetReadByDate();
	   ClickOnMobileElement(createBasicChallenge.addTitlesCTA);
	   addTitles.addTitleNewUser();
	}

	@When("Validate search result pagination cancel Read Checkout Add to challenege button")
	public void validate_search_result_pagination_cancel_Read_Checkout_Add_to_challenege_button() throws InvalidFormatException, IOException {
		addTitles.moreOptionValidation();
	}

	@When("Validate the title list view datas")
	public void validate_the_title_list_view_datas() throws IOException {
		addTitles.listViewDataValidation();;
	}

	@When("Validate More action buttons for non follet books")
	public void validate_More_action_buttons_for_non_follet_books() throws InvalidFormatException, IOException {
	    addTitles.moreOptionNonFollet();
	}

	@When("Validate Title detail page content and Add to chalenge button")
	public void validate_Title_detail_page_content_and_Add_to_chalenge_button() throws InvalidFormatException, IOException {
	    addTitles.tdpValidation();
	}

	@When("Validate title remove pop up cancel button from CC page")
	public void validate_title_remove_pop_up_cancel_button_from_CC_page() throws IOException {
		addTitles.removeTitleCancelValidation();
	}

	@When("Validate Update challenge Name Reminder Date add friend")
	public void validate_Update_challenge_Name_Reminder_Date_add_friend() throws InvalidFormatException, IOException {
		createBasicChallenge.updateChallangeDetails();
//		ClickOnMobileElement(CreateAChallengeCreatorRCDetailsScreen.pageBackButton);
	}

	@When("Validate More action buttons when user search from global search")
	public void validate_More_action_buttons_when_user_search_from_global_search() throws InvalidFormatException, IOException {
		addTitles.globalTitleSearch();
	}
	
	@When("Verify user should be able to view the Remove Friend confirmation modal with corresponding friend name")
	public void verify_user_should_be_able_to_view_the_Remove_Friend_confirmation_modal_with_corresponding_friend_name() throws InvalidFormatException, IOException {
	   addFriend.removeFriendConfMsgValidation();
	   swipeDown();
	}

	@When("Verify the message when there no search results")
	public void verify_the_message_when_there_no_search_results() throws InvalidFormatException, IOException {
		addTitles.invalidInputMsgValidation();
	}

	@When("Verify whether the User should be able to view the pagination details of the search results")
	public void verify_whether_the_User_should_be_able_to_view_the_pagination_details_of_the_search_results() throws InvalidFormatException, IOException {
		addTitles.paginationDetailsValidation();
	}

	@When("Verify whether the application should display twenty five search results")
	public void verify_whether_the_application_should_display_twenty_five_search_results() throws IOException {
		addTitles.searchResultValidation();
	}

	@When("Verify application should display the search results in lazy loading fashion")
	public void verify_application_should_display_the_search_results_in_lazy_loading_fashion() throws IOException {
		addTitles.lazyloadingValidation();
	}

	@When("Verify Filter cancel button")
	public void verify_Filter_cancel_button() throws InvalidFormatException, IOException {
		addTitles.filterCancelBtnValidation();
	}
	
	@When("Add title and start the challenge and logout")
	public void add_title_and_start_the_challenge_and_logout() throws InvalidFormatException, IOException {
	    addTitles.addSingleTitle();
	    login.logOut();
	}

	@When("Accept challenge and validate the close icon in challenge accepted conformation page")
	public void accept_challenge_and_validate_the_close_icon_in_challenge_accepted_conformation_page() throws IOException, Exception {
		acceptChallenge.acceptChCloseIconValidation();
	}
	
}
