package com.stepdefinition;

import java.io.IOException;
import java.text.ParseException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.MyPrograms;
import com.pom.OpenProgram;

import cucumber.api.java.en.When;

public class ReadingProgram_StepDef extends CapabilitiesAndWebDriverUtils {
	
	Login login = new Login();
	MyPrograms myprogram=new MyPrograms();
	OpenProgram openprogram=new OpenProgram();
	BookClubLandingScreen bookClubLandingScreeen = new BookClubLandingScreen();

	/**************************************************** Join Program  ********************************************************/
	
	@When("Verify the join program page and rp detail page")
	public void verify_the_join_program_page_and_rp_detail_page() throws IOException {
	   openprogram.onGoingProgramDetailPageValidation();
	   openprogram.joinProgramDetailPageValidation();
	}
	
	@When("Verify the navigation from title details page to listing page")
	public void verify_the_navigation_from_title_details_page_to_listing_page() throws IOException {
	   openprogram.joingProgramToListingPageNavigation();
	}

	@When("verify the navigation fron rp confirmation to listing page")
	public void verify_the_navigation_fron_rp_confirmation_to_listing_page() throws IOException {
		openprogram.rpConfirmationPageToListingPgaeNavigation();
	}
	
	 /********************************************** Creator view RP detail page  *********************************************/
	
	@When("Verify user should be able to view the program details")
	public void verify_user_should_be_able_to_view_the_program_details() throws IOException, InvalidFormatException {
	    
		myprogram.headerValidation();
		myprogram.myProgramsDetailsScreenValidation();
		login.logOut();
	}
	
	@When("Validate book club landing page when there are no reading program")
	public void validate_book_club_landing_page_when_there_are_no_reading_program() throws InvalidFormatException, IOException {   
		bookClubLandingScreeen.myProgramLandingScreenValidation();
	}
	
	/****************************************************** Open program *******************************************************/	
	
	@When("Verify Navigation to Open Programs tab")
	public void verify_Navigation_to_Open_Programs_tab() throws IOException {
	  myprogram.headerValidation();
	  ClickOnMobileElement(myprogram.openProgram_tab);
	}

	@When("Verify user can able see the title name default program icon book cover image description")
	public void verify_user_can_able_see_the_title_name_default_program_icon_book_cover_image_description() throws IOException {
	   openprogram.openProgramlistingPage();
	}

	@When("Verify user can able to see ongoing and upcoming programs")
	public void verify_user_can_able_to_see_ongoing_and_upcoming_programs() throws IOException, ParseException {
		openprogram.onGoingupComingPrg();
		openprogram.upComingProgramValidation();
		openprogram.onGoingProgramValidation();
	}

	@When("Verify user should not see private programs in ongoing programs")
	public void verify_user_should_not_see_private_programs_in_ongoing_programs() throws IOException {
	   openprogram.publicProgramValidation();
	}
	
	/****************************************************** Leave program *******************************************************/

	@When("Verify user can able to leave program")
	public void verify_user_can_able_to_leave_program() throws IOException {
		 openprogram.onGoingProgramDetailPageValidation();
		 openprogram.leaveProgram();
		 
	}
	
	/****************************************************** program Screen *****************************************************/

	@When("Verify myprogram listing page")
	public void verify_myprogram_listing_page() throws IOException {
	    myprogram.myProgramListingPageValidation();
	}
	
	@When("Verify the closed program card and verify the details page")
	public void verify_the_closed_program_card_and_verify_the_details_page() throws IOException {
	    myprogram.ClosedProgramDetailsPageValidation();
	}
	
	
}
