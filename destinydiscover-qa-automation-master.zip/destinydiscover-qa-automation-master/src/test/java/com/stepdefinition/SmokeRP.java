package com.stepdefinition;

import com.base.CapabilitiesAndWebDriverUtils;

public class SmokeRP  extends CapabilitiesAndWebDriverUtils{
	

}
