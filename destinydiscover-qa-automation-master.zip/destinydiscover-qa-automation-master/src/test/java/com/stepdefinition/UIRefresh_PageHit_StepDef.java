package com.stepdefinition;

import java.awt.AWTException;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.Login;
import com.pom.UIRefresh_PageHit;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UIRefresh_PageHit_StepDef extends CapabilitiesAndWebDriverUtils {
	Login login = new Login();
	UIRefresh_PageHit refresh = new UIRefresh_PageHit();
	@Then("Validate Set Preference")
	public void validate_Set_Preference() throws InvalidFormatException, IOException {
		login.setPreference();
	}

	@Then("Validate User Landing page")
	public void validate_User_Landing_page() throws InvalidFormatException, IOException {
		refresh.userLandingAssertion();
	    //refresh.more();
	    refresh.navigationMenu();
	}

	@Then("Validate Product listing Ebook page")
	public void validate_Product_listing_Ebook_page() throws InvalidFormatException, IOException {
		ClickOnMobileElement(refresh.homeSeeAllEbook);
		refresh.productListEbook();
		ClickOnMobileElement(refresh.back);
	}
	

	@Then("Validate Product listing AudioBoks page")
	public void validate_Product_listing_AudioBoks_page() throws InvalidFormatException, IOException {
		ClickOnMobileElement(refresh.homeSeeAllAudiobook);
		refresh.productListAudioBook();
		ClickOnMobileElement(refresh.back);
	}

	@Then("Validate Search page") 
	public void validate_Search_page() throws InvalidFormatException, IOException, AWTException {
		ClickOnMobileElement(refresh.search_text);
		refresh.searchPageAssertion();
		refresh.search_suggestion();
		refresh.search_Results(true);
	}
	
	@When("Validate checkout functions for ebook")
	public void validate_checkout_functions_for_ebook() throws InvalidFormatException, IOException {
	    refresh.checkoutValidation();
	    
	}
	
	@When("Validate Ebook Details page")
	public void validate_Ebook_Details_page() throws InvalidFormatException, IOException {
	   refresh.titleDetails(true);
	}
	
	@When("Validate Ebook Reading Page")
	public void validate_Ebook_Reading_Page() throws Throwable {
		refresh.eBookReading();
	}
	
	@When("Validate Audio book Details page")
	public void validate_Audio_book_Details_page() throws InvalidFormatException, IOException, AWTException {
		refresh.search_Results(false);
		refresh.titleDetails(false);
	}
	
	@When("Validate Audio book Reading Page")
	public void validate_Audio_book_Reading_Page() throws IOException, InvalidFormatException, AWTException {
		refresh.audioBookReading();
	}
	

	@Then("Validate My Stuff - Checkouts")
	public void validate_My_Stuff_Checkouts() throws InvalidFormatException, IOException {
	   refresh.checkout();
	}

	@Then("Validate My Stuff - Recents with functional validation")
	public void validate_My_Stuff_Recents() throws InvalidFormatException, IOException {
	   //	refresh.recents(recentBookName);
	    
	}

	@Then("Validate My Stuff - Holds")
	public void validate_My_Stuff_Holds() throws InvalidFormatException, IOException {
	    refresh.holds();
	}

	@Then("Validate My Stuff - Assigned")
	public void validate_My_Stuff_Assigned() throws InvalidFormatException, IOException {
	    refresh.assigned();
	}

	@Then("Validate Search Filters")
	public void validate_Search_Filters() throws IOException, InvalidFormatException {
		refresh.search_filter();
	}

	@Then("Validate Downloads")
	public void validate_Downloads() throws InvalidFormatException, IOException {
		refresh.downloads();
	  
	}

}
