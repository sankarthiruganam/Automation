package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;
import com.pom.User_Landing_Page;
import com.pom.User_Landing_Page_Badges;
import com.pom.User_Landing_Page_Goals;
import com.pom.User_Landing_Page_Insights;
import com.pom.User_Landing_Page_Recommendations;

import cucumber.api.java.en.When;

public class ULP_Badges  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	User_Landing_Page_Badges badges = new User_Landing_Page_Badges();
	
	@When("Verify user able to view the earned badged on User Landing Page")
	public void verify_user_able_to_view_the_earned_badged_on_User_Landing_Page() throws InvalidFormatException, IOException {
		badges.badgesCarousel();	
	}

	@When("Verify user able to view the See All button in Badges Carousel")
	public void verify_user_able_to_view_the_See_All_button_in_Badges_Carousel() throws InvalidFormatException, IOException {
		badges.badgesSeeAllBtn();
	}

	@When("Verify the award same badge twice to an individual user")
	public void verify_the_award_same_badge_twice_to_an_individual_user() throws IOException {
		badges.badgeDuplicationValidation();
	}
	
}
