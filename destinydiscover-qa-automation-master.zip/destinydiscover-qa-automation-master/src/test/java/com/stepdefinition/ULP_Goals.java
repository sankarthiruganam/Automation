package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;
import com.pom.User_Landing_Page;
import com.pom.User_Landing_Page_Goals;
import com.pom.User_Landing_Page_Insights;

import cucumber.api.java.en.When;

public class ULP_Goals  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	User_Landing_Page_Insights insights = new User_Landing_Page_Insights();
	User_Landing_Page_Goals goals = new User_Landing_Page_Goals();
	
	@When("Verify insights should be displayed as zero if no data is available")
	public void verify_insights_should_be_displayed_as_zero_if_no_data_is_available() throws InvalidFormatException, IOException {
	    goals.defaultGoalValidation();
	    
	}

	@When("Verify user able to view the set goal pop-up for corresponding insight")
	public void verify_user_able_to_view_the_set_goal_pop_up_for_corresponding_insight() throws InvalidFormatException, IOException {
	    insights.setGoalPageValidation();
	    
	}

	@When("Verify user able to click on Set Goal CTA only when user enters a valid numerical input")
	public void verify_user_able_to_click_on_Set_Goal_CTA_only_when_user_enters_a_valid_numerical_input() throws InvalidFormatException, IOException {
		 goals.setGoalWithValidInput();
	    
	}

	@When("Verify user able to close the pop-up and return to the landing page with no change in goal")
	public void verify_user_able_to_close_the_pop_up_and_return_to_the_landing_page_with_no_change_in_goal() throws IOException {
		goals.closeSetGoalPage();
		
	}

	@When("Verify application display an error if user tries to click on Set Goal CTA by entering an invalid value")
	public void verify_application_display_an_error_if_user_tries_to_click_on_Set_Goal_CTA_by_entering_an_invalid_value() throws InvalidFormatException, IOException {
	  goals.errorMsgValidation();
	  
	}

	@When("Verify application start tracking the goal progress and display it on the User landing page once the goal is set")
	public void verify_application_start_tracking_the_goal_progress_and_display_it_on_the_User_landing_page_once_the_goal_is_set() throws InvalidFormatException, IOException {
		goals.goalTrackValidation();
	}

	@When("Verify Goal metrics are different from Insight metrics as both are independent entities")
	public void verify_Goal_metrics_are_different_from_Insight_metrics_as_both_are_independent_entities() throws InvalidFormatException, IOException {
		goals.metricValidation();
	    
	}

	@When("Verify user able to view view the Set Reading goal pop-up comprising of the Title, text describing the current metric")
	public void verify_user_able_to_view_view_the_Set_Reading_goal_pop_up_comprising_of_the_Title_text_describing_the_current_metric() throws InvalidFormatException, IOException {
		insights.setGoalPageValidation();
	    
	}

	@When("Verify user able to click on Set Goal CTA to set the new or current value entered in the textbox as the goal")
	public void verify_user_able_to_click_on_Set_Goal_CTA_to_set_the_new_or_current_value_entered_in_the_textbox_as_the_goal() throws InvalidFormatException, IOException {
	    goals.setGoalNewTarget();
	    
	}

	@When("Verify user able to click on the remove goal CTA to remove the personal goal value set and revert to the default")
	public void verify_user_able_to_click_on_the_remove_goal_CTA_to_remove_the_personal_goal_value_set_and_revert_to_the_default() throws InvalidFormatException, IOException {
	    insights.defaultInsightValidation();
	    
	}
	
	
}
