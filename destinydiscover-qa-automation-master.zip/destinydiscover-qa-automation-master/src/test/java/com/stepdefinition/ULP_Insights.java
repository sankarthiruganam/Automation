package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;
import com.pom.User_Landing_Page;
import com.pom.User_Landing_Page_Insights;

import cucumber.api.java.en.When;

public class ULP_Insights  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	User_Landing_Page_Insights insights = new User_Landing_Page_Insights();
	
	@When("Verify user able to view the Various types of insights in ULP")
	public void verify_user_able_to_view_the_Various_types_of_insights_in_ULP() throws InvalidFormatException, IOException {
	  insights.insight();
		
	}

	@When("Verify user able to click on each insight to set personal goals for themselves in the goals pop-up")
	public void verify_user_able_to_click_on_each_insight_to_set_personal_goals_for_themselves_in_the_goals_pop_up() throws InvalidFormatException, IOException {  
		insights.setGoalPageValidation();
	}
	
	@When("Verify user able to view the default insights for themselves")
	public void verify_user_able_to_view_the_default_insights_for_themselves() throws InvalidFormatException, IOException {
		insights.defaultInsightValidation();		
	}
}
