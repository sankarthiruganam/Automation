package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;
import com.pom.User_Landing_Page;
import com.pom.User_Landing_Page_Goals;
import com.pom.User_Landing_Page_Insights;
import com.pom.User_Landing_Page_Recommendations;

import cucumber.api.java.en.When;

public class ULP_Recommendation  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	User_Landing_Page_Insights insights = new User_Landing_Page_Insights();
	User_Landing_Page_Goals goals = new User_Landing_Page_Goals();
	User_Landing_Page_Recommendations recommendation =new User_Landing_Page_Recommendations();
	
	@When("Verify user can able to See the recommendations by based on default user preference")
	public void verify_user_can_able_to_See_the_recommendations_by_based_on_default_user_preference() throws IOException {
	    recommendation.defaultRecommendation();
	    
	}

	@When("Verify user can able to view the Intrest Title and Description")
	public void verify_user_can_able_to_view_the_Intrest_Title_and_Description() throws IOException {
	    recommendation.intrestTitleValidation();;
	    
	}

	@When("Verify user can able to select preference of their choice")
	public void verify_user_can_able_to_select_preference_of_their_choice() throws IOException {
	    recommendation.intrestSelection();
	    
	}

	@When("Verify user can able to submit the preference by tapping Save Intrest CTA")
	public void verify_user_can_able_to_submit_the_preference_by_tapping_Save_Intrest_CTA() throws IOException {
	    recommendation.submitPreference();
	    
	}

	@When("Verify user can able to view title carousel in home based on recommendation")
	public void verify_user_can_able_to_view_title_carousel_in_home_based_on_recommendation() {
	    
	    recommendation.afterSaveIntrest();
	}

	@When("Verify user can able to Scroll through the title carousel")
	public void verify_user_can_able_to_Scroll_through_the_title_carousel() throws IOException {
	    
	    recommendation.recommendatioCarouselSwipe();
	}

	@When("Verify user can able to view IN and OUT status in each title diaplayed in the carousel")
	public void verify_user_can_able_to_view_IN_and_OUT_status_in_each_title_diaplayed_in_the_carousel() throws IOException {
	    
	    recommendation.matTypeValidation();
	}

	@When("Verify More options on the title to perform more actions on the specific title")
	public void verify_More_options_on_the_title_to_perform_more_actions_on_the_specific_title() throws IOException {
	    recommendation.titleMoreOptions();
	    
	}

	@When("Verify user can able to view the Based on your preference carousel in home page")
	public void verify_user_can_able_to_view_the_Based_on_your_preference_carousel_in_home_page() throws InvalidFormatException, IOException {
	    recommendation.basedonPreferenceCarousel();
	    
	}

	@When("Verify user can able to view the Because you enjoyed carousel in home page")
	public void verify_user_can_able_to_view_the_Because_you_enjoyed_carousel_in_home_page() throws InvalidFormatException, IOException {
	    recommendation.becauseyouEnjoyedCarousel();
	    
	}

	@When("Verify user can able to view list of selected preference highlighted")
	public void verify_user_can_able_to_view_list_of_selected_preference_highlighted() throws IOException {
	    recommendation.preferenceHighlightValidation();
	    
	}

	@When("Verify atleast one preference is selected to save and update the preference")
	public void verify_atleast_one_preference_is_selected_to_save_and_update_the_preference() throws IOException {
	    recommendation.savebuttonValidation();
	    
	}

	@When("Verify user able to unselect a preference by tapping on selected item")
	public void verify_user_able_to_unselect_a_preference_by_tapping_on_selected_item() throws IOException {
	    recommendation.unselectPreference();
	    
	}

	@When("Verify user able to Select a new preference by tapping on unselected item")
	public void verify_user_able_to_Select_a_new_preference_by_tapping_on_unselected_item() throws IOException {
	    recommendation.newPreferenceSelection();
	    
	}
	
}
