package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;

import cucumber.api.java.en.When;

public class ULP_Smoke_StepDef  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	ULP_Smoke ulp = new ULP_Smoke();
	
	
	@When("Verify Insights carousel is displayed in ULP page")
	public void verify_Insights_carousel_is_displayed_in_ULP_page() throws IOException {
	   ulp.inSightCarousel();
	}

	@When("Verify Goal card is displayed when user taps on any insight")
	public void verify_Goal_card_is_displayed_when_user_taps_on_any_insight() throws InvalidFormatException, IOException {
	    ulp.goalSetting();
	}

	@When("Verify Badges carousel is displayed in ULP page")
	public void verify_Badges_carousel_is_displayed_in_ULP_page() throws IOException, InvalidFormatException {
		ulp.badgesCarousel();
	}

	@When("Verify RC RP carousel is displayed in ULP page")
	public void verify_RC_RP_carousel_is_displayed_in_ULP_page() throws IOException {
	   ulp.challengeandprogramCarousel();
	}

	@When("Verify user navigtes to corresponding challenge program when they tap on it from ULP page")
	public void verify_user_navigtes_to_corresponding_challenge_program_when_they_tap_on_it_from_ULP_page() throws IOException {
	    ulp.challengeNavigation();
	}

	@When("Verify our suggestion section is displayed with two sub section in ULP page")
	public void verify_our_suggestion_section_is_displayed_with_two_sub_section_in_ULP_page() throws InvalidFormatException, IOException {
		ulp.ourSuggestionCarousel();
	}

	@When("Verify user able to view material type icon and more icon for the titles under our suggestions")
	public void verify_user_able_to_view_material_type_icon_and_more_icon_for_the_titles_under_our_suggestions() throws IOException {
	   ulp.matTypeAndMoreIconValidation();
	}
	
}
