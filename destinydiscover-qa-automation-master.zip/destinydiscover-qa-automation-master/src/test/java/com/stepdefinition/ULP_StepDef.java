package com.stepdefinition;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom.BookClubLandingScreen;
import com.pom.Login;
import com.pom.Message_Center;
import com.pom.MyPrograms;
import com.pom.OpenProgram;
import com.pom.ULP_Smoke;
import com.pom.User_Landing_Page;

import cucumber.api.java.en.When;

public class ULP_StepDef  extends CapabilitiesAndWebDriverUtils{
	
	Login login = new Login();
	ULP_Smoke ulp = new ULP_Smoke();
	User_Landing_Page homePage = new User_Landing_Page();
	
	@When("verify user able to view the global header Destiny Discover logo and Notifications icon and Global search icon")
	public void verify_user_able_to_view_the_global_header_Destiny_Discover_logo_and_Notifications_icon_and_Global_search_icon() throws IOException, InvalidFormatException {
		homePage.headerAssertion();
	}

	@When("Verify user able to click on the Notifications icon and view the list of notifications received")
	public void verify_user_able_to_click_on_the_Notifications_icon_and_view_the_list_of_notifications_received() throws InvalidFormatException, IOException {   
		homePage.msgCenterNavigation();
	}

	@When("Verify user able to view their insights details")
	public void verify_user_able_to_view_their_insights_details() throws IOException, InvalidFormatException {
	    ulp.inSightCarousel();
	    ulp.goalSetting();
	}

	@When("Verify user able to click on See all CTA and view the User profile screen's Badges tab")
	public void verify_user_able_to_click_on_See_all_CTA_and_view_the_User_profile_screen_s_Badges_tab() throws InvalidFormatException, IOException {
	    ulp.badgesCarousel();
	}

	@When("Verify user able to view the RC RP carousel")
	public void verify_user_able_to_view_the_RC_RP_carousel() throws IOException {
		homePage.rcrpCarouselValidation();    
	}

	@When("Verify user able to view the primary title image, progress percentage and RC RP name for each entry")
	public void verify_user_able_to_view_the_primary_title_image_progress_percentage_and_RC_RP_name_for_each_entry() throws IOException {
		homePage.rcrpNameValidation();
	}

	@When("Verify user able to tap on the See All CTA on the RC RP carousel and be navigated to the Book Club landing page")
	public void verify_user_able_to_tap_on_the_See_All_CTA_on_the_RC_RP_carousel_and_be_navigated_to_the_Book_Club_landing_page() throws IOException {
		homePage.rcrpSeeAllNavigation(); 
	}

	@When("Verify user able to tap on an RC RP and be navigated to the RC RP details screen")
	public void verify_user_able_to_tap_on_an_RC_RP_and_be_navigated_to_the_RC_RP_details_screen() throws IOException {
	    ulp.challengeNavigation(); 
	}

	@When("Verify user able to view the Recommendations carousel displayed based on the recommendation engine input")
	public void verify_user_able_to_view_the_Recommendations_carousel_displayed_based_on_the_recommendation_engine_input() throws InvalidFormatException, IOException {   
		homePage.recommendationOneCarousel();
	}

	@When("Verify user able to view the Because You enjoyed carousel displayed based on the recommendation engine input")
	public void verify_user_able_to_view_the_Because_You_enjoyed_carousel_displayed_based_on_the_recommendation_engine_input() throws InvalidFormatException, IOException {
		homePage.recommendationTwoCarousel();
	}
	
	@When("Verify user able to view the Title image material type icon and more icon for each title listed")
	public void verify_user_able_to_view_the_Title_image_material_type_icon_and_more_icon_for_each_title_listed() throws IOException {
		homePage.moreAndMAtTypeIconValidation();
	}
	
	
	
	@When("Verify user able to click on the global bottom navigation menu items and view the corresponding landing pages")
	public void verify_user_able_to_click_on_the_global_bottom_navigation_menu_items_and_view_the_corresponding_landing_pages() throws InvalidFormatException, IOException {
		homePage.bottomMenuNavigation();
	}

	@When("Verify user able to see the recent read book that they were reading in a minimized fashion")
	public void verify_user_able_to_see_the_recent_read_book_that_they_were_reading_in_a_minimized_fashion() {
		homePage.recentReadBook();
	}

	@When("Verify recently read book sticky will disappear when user scrolls down and appear again when they scroll up")
	public void verify_recently_read_book_sticky_will_disappear_when_user_scrolls_down_and_appear_again_when_they_scroll_up() throws IOException {
		homePage.recentBookDisappear();
	}

	@When("Verify tapping on in to view the book opened in eReader")
	public void verify_tapping_on_in_to_view_the_book_opened_in_eReader() throws IOException, InterruptedException {
		homePage.openRecentReadBook();
	}

	@When("Verify user able to navigate to Discover Page")
	public void verify_user_able_to_navigate_to_Discover_Page() throws InvalidFormatException, IOException {
	    homePage.discoverPageNavigation();
	}
	
	@When("Verify user able to scroll left or right to view the books in the carousel")
	public void verify_user_able_to_scroll_left_or_right_to_view_the_books_in_the_carousel() throws IOException {
		homePage.carouselValidation();
	}

	@When("Verify user able to click on see all to navigate to PLP with the list of books for that carousel")
	public void verify_user_able_to_click_on_see_all_to_navigate_to_PLP_with_the_list_of_books_for_that_carousel() throws InvalidFormatException, IOException {
	   homePage.listingPageValidation();
	}

	@When("Verify user able to see ellipsis as fifth option on bottom navigation menu")
	public void verify_user_able_to_see_ellipsis_as_fifth_option_on_bottom_navigation_menu() throws IOException {
	   homePage.moreIconValidation();
	}

	@When("Verify Downloads is an existing functionality in the Destiny Discover native app")
	public void verify_Downloads_is_an_existing_functionality_in_the_Destiny_Discover_native_app() throws IOException {
	   homePage.moreOptionValidation();
	}

	@When("Verify user able to tap on Downloads and navigate to Downloads screen")
	public void verify_user_able_to_tap_on_Downloads_and_navigate_to_Downloads_screen() throws InvalidFormatException, IOException {
	   homePage.downLoadsValidation();
	}

}
