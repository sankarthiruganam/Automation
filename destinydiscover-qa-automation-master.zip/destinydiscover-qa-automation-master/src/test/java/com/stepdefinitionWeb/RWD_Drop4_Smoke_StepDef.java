package com.stepdefinitionWeb;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.pom_RWD.RWD_Drop4_Smoke;
import com.pom_RWD.Rwd_RC;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RWD_Drop4_Smoke_StepDef {
	
	private  final static Logger logger = LogManager.getLogger();
	
	RWD_Drop4_Smoke drop4 = new RWD_Drop4_Smoke();
	Rwd_RC rc= new Rwd_RC();
	
	@Given("Verify user should be able to view the RC carousel")
	public void verify_user_should_be_able_to_view_the_RC_carousel() throws InvalidFormatException, IOException {
	    drop4.RP_RC_Carousel();
	    logger.info("User is able to view the RC carousel");
	}

	@When("Verify user should be able to view the primary title image for each entry in the RC carousel")
	public void verify_user_should_be_able_to_view_the_primary_title_image_for_each_entry_in_the_RC_carousel() throws InvalidFormatException, IOException {
		drop4.RP_RC_details(true, false, false);
		logger.info("User is able to view the primary title image for each entry in the RC carousel");
	}

	@Then("Verify user should be able to view the progress percentage for each entry in the RC carousel")
	public void verify_user_should_be_able_to_view_the_progress_percentage_for_each_entry_in_the_RC_carousel() throws InvalidFormatException, IOException {
		drop4.RP_RC_details(false, false, true);
		logger.info("User is able to view the progress percentage for each entry in the RC carousel");
	}

	@Then("Verify user should be able to view the RC name for each entry in the RC carousel")
	public void verify_user_should_be_able_to_view_the_RC_name_for_each_entry_in_the_RC_carousel() throws InvalidFormatException, IOException {
		drop4.RP_RC_details(false, true, false);
		logger.info("User is able to view the RC name for each entry in the RC carousel");
	}

	@Then("Verify user should be able to tap on an RC and be navigated to the RC details screen")
	public void verify_user_should_be_able_to_tap_on_an_RC_and_be_navigated_to_the_RC_details_screen() throws InvalidFormatException, IOException {
		drop4.rc_Details();
		logger.info("User is able to view the RC name for each entry in the RC carousel");
	}

	@Given("Verify user should be able to view the RP carousel")
	public void verify_user_should_be_able_to_view_the_RP_carousel() throws InvalidFormatException, IOException {
		drop4.RP_RC_Carousel();
		logger.info("User is able to view the RP carousel");
	}

	@When("Verify user should be able to view the primary title image for each entry in the RP carousel")
	public void verify_user_should_be_able_to_view_the_primary_title_image_for_each_entry_in_the_RP_carousel() {
		drop4.RP_RC_details(true, false, false);
		logger.info("User is able to view the primary title image for each entry in the RP carousel");
	}

	@Then("Verify user should be able to view the progress percentage for each entry in the RP carousel")
	public void verify_user_should_be_able_to_view_the_progress_percentage_for_each_entry_in_the_RP_carousel() {
		drop4.RP_RC_details(false, false, true);
		logger.info("User is able to view the progress percentage for each entry in the RP carousel");
	}

	@Then("Verify user should be able to view the RP name for each entry in the RP carousel")
	public void verify_user_should_be_able_to_view_the_RP_name_for_each_entry_in_the_RP_carousel() {
		drop4.RP_RC_details(false, true, false);
		logger.info("User is able to view the RP name for each entry in the RP carousel");
	}

	@Then("Verify user should be able to tap on an RP and be navigated to the RP details screen")
	public void verify_user_should_be_able_to_tap_on_an_RP_and_be_navigated_to_the_RP_details_screen() throws InvalidFormatException, IOException {
	    drop4.rp_Details();
	    logger.info("User is able to tap on an RP and be navigated to the RP details screen");
	}
	
	@Given("Go to Message center and validate")
	public void go_to_Message_center_and_validate() throws IOException {
	    rc.loginMessagecenter();
	    logger.info("Go to Message center and validate");
	}
	
	@When("verify messages related to awarded badges")
	public void verify_messages_related_to_awarded_badges() throws InvalidFormatException, IOException {
	   drop4.badgemsg();
	   logger.info("User is able to view messages related to awarded badges");
	}
	
	@And("Verify user able to update interest survey")
	public void Verify_user_able_to_update_interest_survey() throws Exception {
		drop4.updateInterestSurvey();
		logger.info("User is able to update interest survey #Pass");
		
		
	}
	@And("Verify user should be able to view the news and announcements widget")
	public void Verify_user_should_be_able_to_view_the_news_and_announcements_widget() throws IOException
	{
		drop4.viewnewsAnnouncements();
		logger.info("User is able to view the news and announcements widget #Pass");
	}
	
	@And("To verify user able to search Books in Home screen")
	public void To_verify_user_able_to_search_Books_in_Home_screen() throws InvalidFormatException, IOException
	{
		drop4.searchBooks();
		logger.info("User is able to search Books in Home screen #Pass");
	}
	
	@And("Verify user should be able to view the progress of the insights")
	public void Verify_user_should_be_able_to_view_the_progress_of_the_insights() throws InvalidFormatException, IOException
	{
		drop4.checkprogressofInsights();
		logger.info("User is able to view the progress of the insights  #Pass");
	}
	@And("To verify user able to click on each insight to set personal goals for themselves in the goals pop-up")
	public void To_verify_user_able_to_click_on_each_insight_to_set_personal_oals() throws InvalidFormatException, IOException
	{
		drop4.setgoal();
		logger.info("User is able to click on each insight to set personal goals for themselves in the goals pop-up  #Pass");
	}
	@And("Verify user should be able to remove goal")
	public void Verify_user_should_be_able_to_remove_goal() throws InvalidFormatException, IOException
	{
		drop4.removegoal();
		logger.info("User is able to remove goal  #Pass");
	}
	@And("Verify user should be able to view the badges awarded for the user")
	public void Verify_user_should_be_able_to_view_the_badges_awarded() throws InvalidFormatException, IOException
	{
		drop4.viewbadges();
		logger.info("User is able to view the badges awarded for the user  #Pass");
	}
	@And("Verify user should be able to click on the see all option and view all the badges awarded for the user")
	public void Verify_user_should_be_able_to_click_on_the_see_all_option_and_view_all_the_badges() throws InvalidFormatException, IOException
	{
		drop4.seeallviewbadges();
		logger.info("User is able to click on the see all option and view all the badges awarded for the user  #Pass");
	}

}
