package com.stepdefinitionWeb;

import com.pom_RWD.RWD_Drop4;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class RWD_Drop4_StepDef {
	
	RWD_Drop4 rwd_drop4= new RWD_Drop4();
	
	@And("verify able to view the badges earned badges section in the landing page")
	public void verify_able_to_view_the_badges_earned_badges_section_in_the_landing_page() throws Exception {
		rwd_drop4.viewEarnedbadges();
	}
	@And("verify able to click on See all Badges CTA")
	public void verify_able_to_click_on_See_all_Badges_CTA() throws Exception {
		rwd_drop4.seeallBadges();
	}
	@And("verify award same badges twice")
	public void verify_award_same_badges_twice() throws Exception {
		rwd_drop4.verifydublicatebadges();
	}
	@And("To verify user should be navigated to the message details screen")
	public void To_verify_user_should_be_navigated_to_the_message_details_screen() throws Exception {
		rwd_drop4.messageDetails();
	}
	@And("verify user able to click on each insight to set personal goals for themselves in the goals pop-up")
	public void verify_user_able_to_click_on_each_insight_to_set_personal_goals_for_themselves_in_the_goals_pop_up() throws Exception {
		rwd_drop4.setpersonalgoal();
	}
	@And("user able to view the default insights for themselves if they have not set any personal goals")
	public void user_able_to_view_the_default_insights_for_themselves_if_they_have_not_set_any_personal_goals() throws Exception {
		rwd_drop4.checkDefaultInsights();
	}
	@And("user able to view the goal set and progress made towards the goal on the User landing page")
	public void user_able_to_view_the_goal_set_and_progress_made_towards_the_goal_on_the_User_landing_page() throws Exception {
		rwd_drop4.viewgoal();
	}
	@And("To verify user able to view the progress made in the progress indicator for each goal")
	public void To_verify_user_ableto_view_the_progress_made_in_the_progress_indicator_for_each_goal() throws Exception {
		rwd_drop4.checkprogress();
	}
	@And("verify user able to click on a goal card and view the Set Reading goal pop-up")
	public void To_verify_user_able_to_click_on_a_goal_card_and_view_the_Set_Reading_goal_pop_up() throws Exception {
		rwd_drop4.checkgoal();
	}
	@And("To verify user able to view Enter goal textbox with the value set as goal by the user")
	public void To_verify_user_able_to_view_Enter_goal_textbox_with_the_value_set_as_goal_by_the_user() throws Exception {
		rwd_drop4.setgoal();
	}
	@And("verify user able to Set Goal entered in the textbox as the goal")
	public void verify_user_able_to_Set_Goal_entered_in_the_textbox_as_the_goal() throws Exception {
		rwd_drop4.setgoal();
	}
	@And("verify user able to Remove Goal personal goal value and revert to the default insight")
	public void verify_user_able_to_Remove_Goal_personal_goal_value_and_revert_to_the_default_insight() throws Exception {
		rwd_drop4.removegoal();
	}
	@And("To verify application display an error if user tries to click on Set Goal CTA by entering an invalid value")
	public void To_verify_application_display_an_error_if_user_tries_to_click_on_Set_Goal_CTA_by_entering_an_invalid_value() throws Exception {
		rwd_drop4.checkinvalidsetgoal();
	}
	@And("To verify mins of reading per day")
	public void To_verify_mins_of_reading_per_day() throws Exception {
		rwd_drop4.readingperday();
	}
	@And("To verify Mins of Listening per day")
	public void To_verify_Mins_of_Listening_per_day() throws Exception {
		rwd_drop4.listeningperday();
	}
	@And("To verify Streak goal")
	public void To_verify_Streak_goal() throws Exception {
		rwd_drop4.streakgoal();
	}
	
	@And("To verify Monthly goal")
	public void To_verify_Monthly_goal() throws Exception {
		rwd_drop4.monthlygoal();
	}
	@And("To verify yearly goal")
	public void To_verify_yearly_goal() throws Exception {
		rwd_drop4.yearlygoal();
	}
	@And("To verify the select new preferences by tapping on each unselected item")
	public void To_verify_the_select_new_preference_by_tapping_on_each_unselected_item() throws Exception {
		rwd_drop4.updateInterestSurvey();
	}
	@And("To verify  able to view the Interests Title and Description")
	public void To_verify_able_to_view_the_Interests_Title_and_Description() throws Exception {
		rwd_drop4.viewtitledesc();
	}
	@And("To verify the ​IN and OUT status of each title in the carousel")
	public void To_verify_the_IN_and_OUT_status_of_each_title_in_the_carousel() throws Exception {
		rwd_drop4.checkInOutbadges();
	}
	@And("To verify the more options on the title to perform more actions on the specific title ​")
	public void To_verify_the_more_options_on_the_title_to_perform_more_actions_on_the_specific_title​() throws Exception {
		rwd_drop4.checkMoreoptions();
	}
	@And("To verify list of preference topics displayed")
	public void To_verify_list_of_preference_topics_displayed​() throws Exception {
		rwd_drop4.listofpreferencedisplay();
	}
	@And("To verify the recommendations carousel")
	public void To_verify_the_recommendations_carousel() throws Exception {
		rwd_drop4.recommendationcarousel();
	}
}
