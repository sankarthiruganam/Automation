package com.stepdefinitionWeb;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.pom_RWD.RWD_Drop4_ULP;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RWD_Drop4_ULP_StepDef {
	
	RWD_Drop4_ULP d4 = new RWD_Drop4_ULP();

	@Then("Validate home page")
	public void validate_home_page() throws IOException {
	    d4.homepageValidation();
	}
	
	@Given("To verify User able to view the global header")
	public void to_verify_User_able_to_view_the_global_header() {
		d4.headerValidaion();
	}

	@When("To verify User able to view the header with all menu")
	public void to_verify_User_able_to_view_the_header_with_all_menu() {
	    d4.headerMenuValidation();
	}

	@Then("To verify on tappin on hamburger menu user able to view the menu options")
	public void to_verify_on_tappin_on_hamburger_menu_user_able_to_view_the_menu_options() {
	    
	}

	@Then("To verify on tapping on any option to be navigated to the corresponding landing page")
	public void to_verify_on_tapping_on_any_option_to_be_navigated_to_the_corresponding_landing_page() {
	    
	}

	@Then("To verify ​on tapping on X icon on the expanded hamburger menu close the menu")
	public void to_verify_​on_tapping_on_X_icon_on_the_expanded_hamburger_menu_close_the_menu() {
	    
	}

	@Then("To verify user navigate to the Homepage​, on clicking on Destiny Discover logo")
	public void to_verify_user_navigate_to_the_Homepage​_on_clicking_on_Destiny_Discover_logo() {
	    d4.logoValidation();
	}

	@Then("To verify user able to view corresponding landing pages on clicking on the global menu items")
	public void to_verify_user_able_to_view_corresponding_landing_pages_on_clicking_on_the_global_menu_items() throws InvalidFormatException, IOException {
	    d4.globalMenuValidation();
	}

	@Then("To verify user able to click on the Notifications icon and view the list of notifications received")
	public void to_verify_user_able_to_click_on_the_Notifications_icon_and_view_the_list_of_notifications_received() throws IOException {
	    d4.Messagecenter();
	}

	@Then("To verify user able to view their insights details")
	public void to_verify_user_able_to_view_their_insights_details() {
	    d4.insightValidation();
	} 
	
	@Then("To verify user ble to view their recent badges details")
	public void to_verify_user_ble_to_view_their_recent_badges_details() throws IOException {
		d4.badgesValidation();
	}

	@Then("To verify user able to click on “See all Badges” CTA and view the Badges tab")
	public void to_verify_user_able_to_click_on_See_all_Badges_CTA_and_view_the_Badges_tab() throws IOException {
	    d4.badgeSeeAllvalidation();
	}
	
	@Then("To verify user able to view the news and announcements widget")
	public void to_verify_user_able_to_view_the_news_and_announcements_widget() {
	    d4.newsWidgetValidation();
	}
	
	@Then("To verify ​user able to view the primary title image, progress percentage and RC\\/RP name for each entry in the RC\\/RP carousel​")
	public void to_verify_​user_able_to_view_the_primary_title_image_progress_percentage_and_RC_RP_name_for_each_entry_in_the_RC_RP_carousel​() {
	    d4.RP_RC_details(true, true, true);
	}

	@Then("To verify user able to tap on the See All CTA on the RC\\/RP carousel and be navigated to the Book Club landing page")
	public void to_verify_user_able_to_tap_on_the_See_All_CTA_on_the_RC_RP_carousel_and_be_navigated_to_the_Book_Club_landing_page() {
	  //  d4.RP_RC_SeeAll();
	}
	
	@Then("To verify user able to view the custom carousel of titles displayed")
	public void to_verify_user_able_to_view_the_custom_carousel_of_titles_displayed() {
	    d4.customCarouselValidation();
	}

	@Then("To verify user able to view the Recommendations carousel displayed")
	public void to_verify_user_able_to_view_the_Recommendations_carousel_displayed() {
	    d4.recommendationCarouselValidation();
	}
	
	@Then("To verify user able to view the global footer, comprising of the copyright information")
	public void to_verify_user_able_to_view_the_global_footer_comprising_of_the_copyright_information() {
	    d4.footerValidation();
	}
	
	@Then("TO verify user able to view the global header with Discover option highlighted")
	public void to_verify_user_able_to_view_the_global_header_with_Discover_option_highlighted() {
	    d4.discoverValidation();
	}
	
	@Then("To verify user able to click on see all to navigate to product listing page with the list of books for that carousel")
	public void to_verify_user_able_to_click_on_see_all_to_navigate_to_product_listing_page_with_the_list_of_books_for_that_carousel() {
	    d4.carouselSeeAllValidation();
	}
	
	@Then("To Verify that user able to see the Salutation text with user’s First Name")
	public void to_Verify_that_user_able_to_see_the_Salutation_text_with_user_s_First_Name() throws InvalidFormatException, IOException {
	    d4.salutationValidation();
	}
	
	@Then("To verify whether user able to view the global header comprising of the ‘More’ link, clicking on which displays the More menu")
	public void to_verify_whether_user_able_to_view_the_global_header_comprising_of_the_More_link_clicking_on_which_displays_the_More_menu() {
	    d4.moreMenuValidation();
	}

	@Then("To verify whether user able to view more menu options Back Office and Help")
	public void to_verify_whether_user_able_to_view_more_menu_options_Back_Office_and_Help() {
		d4.moreOptionsValidation();
	}
	
	@Then("To verify user able to click on the links in the more menu and be navigated to the corresponding landing page")
	public void to_verify_user_able_to_click_on_the_links_in_the_more_menu_and_be_navigated_to_the_corresponding_landing_page() {
	    d4.moreMenuLandingValidation();
	}

}
