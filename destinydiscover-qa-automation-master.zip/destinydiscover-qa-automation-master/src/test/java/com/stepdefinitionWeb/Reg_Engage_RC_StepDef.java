package com.stepdefinitionWeb;

import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom_RWD.Login_RWD;
import com.pom_RWD.RWD_RC_Smoke;
import com.pom_RWD.RWD_RP;
import com.pom_RWD.RWD_RP_Smoke;
import com.pom_RWD.Reg_Engage;
import com.pom_RWD.Reg_Engage_RC;
import com.pom_RWD.Reg_Engage_RP;
import com.pom_RWD.Rwd_RC;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Reg_Engage_RC_StepDef extends CapabilitiesAndWebDriverUtils {
	
	RWD_RP rp= new RWD_RP();
	Reg_Engage reg = new Reg_Engage();
	Reg_Engage_RC reg1 = new Reg_Engage_RC();
	RWD_RP_Smoke rp1=new RWD_RP_Smoke();
	Rwd_RC rc=new Rwd_RC();
        Reg_Engage_RP rps=new Reg_Engage_RP();
	RWD_RC_Smoke rcsmoke=new RWD_RC_Smoke();
	
/********************************************Method Implementations*************************************************/	
		
	@Then("Log into the app and navigate to reading challenge")
	public void log_into_the_app_and_navigate_to_reading_challenge() {	
	    reg1.navigateToBookclub();
	}

	@Then("Verify challenges Tab is open by default")
	public void verify_challenges_Tab_is_open_by_default() throws IOException {
	   reg1.challengeTabAssertion();	
	}
	
	@Then("Navigate to Create Challenge Page")
	public void navigate_to_Create_Challenge_Page() throws IOException {
	   reg1.navToCreateChallengePage();
	}

	@Then("Verify user able to create challenge sucessfully")
	public void verify_user_able_to_create_challenge_sucessfully() throws Exception {
	    reg1.createChallenge(false,false);
	}
	
	@Then("Enter challenge name and Click Cross icon in challenge creation page")
	public void enter_challenge_name_and_Click_Cross_icon_in_challenge_creation_page() throws InvalidFormatException, IOException {
	   reg1.clickOnCrossIcon();
	}
	
	@Then("Verify user not able to save the challene without mandatory inputs")
	public void verify_user_not_able_to_save_the_challene_without_mandatory_inputs() throws InvalidFormatException, IOException {
	    reg1.saveChallengeMandatoryFieldcheck();
	}
	
	@Then("Verify user able to save the challenge after providing inputs for all mandatory fields")
	public void verify_user_able_to_save_the_challenge_after_providing_inputs_for_all_mandatory_fields() throws InvalidFormatException, IOException {
	   reg1.saveChallenge();
	}
	
	@Then("Verify user not able to save challenge with duplicate name")
	public void verify_user_not_able_to_save_challenge_with_duplicate_name() throws InvalidFormatException, IOException {
	    reg1.duplicateChallenegNameValidation(true);
	}
	
	@Then("Verify user not able to Start challenge with duplicate name")
	public void verify_user_not_able_to_Start_challenge_with_duplicate_name() throws InvalidFormatException, IOException {
	    reg1.duplicateChallenegNameValidation(false);
	}
	
	@Then("Verify user not able to set todays date as challenge end date")
	public void verify_user_not_able_to_set_todays_date_as_challenge_end_date() throws InvalidFormatException, IOException {
		reg1.chlEndDtValidation();
	}
	
	@Then("Verify user able to Start challenge with Multiple titles")
	public void verify_user_able_to_Start_challenge_with_Multiple_titles() throws Exception {
	    reg1.createChallenge(false, true);
	}

	@Then("Verify user able to Start challenge with Multiple friends invited to the challenge")
	public void verify_user_able_to_Start_challenge_with_Multiple_friends_invited_to_the_challenge() throws Exception {	    
		reg1.createChallenge(true, false);
	}
		
	@When("Verify user is able to add title to new challenge from Discover page")
	public void verify_user_is_able_to_add_title_to_new_challenge_from_Discover_page() throws IOException {
		reg1.addTitleFromDiscoverPage_Rc();
	}
	
	@When("Verify user is able to add title to new challenge from Home page")
	public void verify_user_is_able_to_add_title_to_new_challenge_from_Home_page() throws IOException {
	    reg1.addTitleFromHomePage_Rc();
	}
	
	@Then("Verify user is able to create challenge without adding students")
	public void verify_user_is_able_to_create_challenge_without_adding_students() throws Exception {
	    reg1.createChallengeWithOutAddingStudents();
	}
	
	@Then("Verify the user able to add titles and creating new challenge from checkout")
	public void verify_the_user_able_to_add_titles_and_creating_new_challenge_from_checkout() throws Exception {
	    reg1.addTitlesinNewChallengefromMystuffCheckout();
	}
	
	@Then("Verify the user able to add titles and creating new challenge from history")
	public void verify_the_user_able_to_add_titles_and_creating_new_challenge_from_history() throws Exception {
	   reg1.addTitlesinNewChallengefromMystuffHistory();
	}

	@Then("Verify the user able to add titles and creating new challenge from hold")
	public void verify_the_user_able_to_add_titles_and_creating_new_challenge_from_hold() throws Exception {
	  reg1.addTitlesinNewChallengefromMystuffHold();
	}

	@Then("Verify the user able to add titles and creating new challenge from favorites")
	public void verify_the_user_able_to_add_titles_and_creating_new_challenge_from_favorites() throws Exception {
	   reg1.addTitlesinNewChallengefromMystuffFavorites();
	}
	
	@Then("Verify user able to create his and participant progress in Challenge Details page")
	public void verify_user_able_to_create_his_and_participant_progress_in_Challenge_Details_page() throws IOException {
	    reg1.readingProgress();
	}

	@Then("Verify user able to Close the challenge from details screen")
	public void verify_user_able_to_Close_the_challenge_from_details_screen() {
	    reg1.closeChallenge();
	}
	
	@Then("Verify the Closed Challenge is moved to Close Challenge Section")
	public void verify_the_Closed_Challenge_is_moved_to_Close_Challenge_Section() {
	   reg1.closedChallengeDisplayChcek();
	}
	
	@Then("Verify user able to Leave the challenge from details screen")
	public void verify_user_able_to_Leave_the_challenge_from_details_screen() {
	   reg1.leaveChallenge();
	}

	@Then("Verify the Left Challenge is moved to Closed challenge")
	public void verify_the_Left_Challenge_is_moved_to_Closed_challenge() {
	    reg1.closedChallengeDisplayChcek();	
	}
	
	@Then("Navigate to created challenge from book club landing page")
	public void navigate_to_created_challenge_from_book_club_landing_page() {
		reg1.searchandClickActiveChallenge();
	}

	@Then("Verify user able to edit the challenge")
	public void verify_user_able_to_edit_the_challenge() throws IOException {
	   reg1.editChallenge(true);
	}
	
	@Then("Navigate to Saved challenge from book club landing page")
	public void navigate_to_Saved_challenge_from_book_club_landing_page() {
	   reg1.searchandClickDraftChallenge();
	}

	@Then("Verify user able to edit the saved challenge")
	public void verify_user_able_to_edit_the_saved_challenge() throws IOException {
	   reg1.editChallenge(false);	
	}
	
	@Then("Verify active challenges are displayed under Active Challenges section")
	public void verify_active_challenges_are_displayed_under_Active_Challenges_section() throws IOException, Exception {
	   reg1.activechallengeValidation();
	}
	
	@Then("Verify draft challenges are displayed under draft Challenges section")
	public void verify_draft_challenges_are_displayed_under_draft_Challenges_section() {
	   reg1.draftChallengeValidation();
	}
	
	@Then("Verify closed challenges are displayed under closed Challenges section")
	public void verify_closed_challenges_are_displayed_under_closed_Challenges_section() throws Exception {
		reg1.closedChallengeValidation();
	}
	
        @Then("Verify User is not able to add same Student more than once in create challenge page")
	public void verify_User_is_not_able_to_add_same_Student_more_than_once_in_create_challenge_page()
			throws InvalidFormatException, IOException {
		reg1.addsameStudent();
	}
	
	@Then("Verify User is not able to add same Title more than once in create challenge page")
	public void verify_User_is_not_able_to_add_same_Title_more_than_once_in_create_challenge_page()
			throws InvalidFormatException, IOException {
		reg1.addsameTitle();
	}

	@Then("Verify User able to remove student from search stusent and create challenge page")
	public void verify_User_able_to_remove_student_from_search_stusent_and_create_challenge_page()
			throws InvalidFormatException, IOException {
		reg1.removeStudentValidation();
	}
	
	@Then("Verify User able to remove titles from search stusent and create challenge page")
	public void verify_User_able_to_remove_titles_from_search_stusent_and_create_challenge_page() throws InvalidFormatException, IOException {
		reg1.removeTitleValidation();
	}
	
	@Then("Click start challenge button")
	public void click_start_challenge_button() {
	    ClickOnWebElement(reg1.startchal_btn);
	}
	
	@Then("Validate Reject challenge and challenge confirmation page")
	public void validate_Reject_challenge_and_challenge_confirmation_page() throws InvalidFormatException, IOException {
	   rcsmoke.validateAcceptChallenge(false);
	}

	@Then("Verify the Challenge Details in the Participant RC screen")
	public void verify_the_Challenge_Details_in_the_Participant_RC_screen() {
	    reg1.participantDetailsPgValidation();
	}

	@Then("Verify the challenge Progress is displayed in the Participant RC screen")
	public void verify_the_challenge_Progress_is_displayed_in_the_Participant_RC_screen() throws IOException {
	    reg1.readingProgress();		
	}

	@Then("Verify Participant can able to leave the challenge after accepting it")
	public void verify_Participant_can_able_to_leave_the_challenge_after_accepting_it() {
	    reg1.leaveChallenge();	
	}
  
  @Then("Search and find the challenge")
	public void search_and_find_the_challenge() {
		reg1.challengeSearch();
	}

	@When("Validate the you-ve been challenged text for the created challenge")
	public void validate_the_you_ve_been_challenged_text_for_the_created_challenge() {
		reg1.you_ve_been_Challenged();
	}
	
	@Then("Add new title to challenge")
	public void add_new_title_to_the_challenge() throws InvalidFormatException, IOException {
		reg1.editAddTitle();
	}

	@Then("Remove title from the challenge")
	public void remove_title_from_the_challenge() throws InvalidFormatException, IOException {
		reg1.editRemoveTitle();
	}

	@Then("Update name to the challenge")
	public void update_name_to_the_challenge() throws InvalidFormatException, IOException {
		reg1.editChlngName();
	}
	
	@Then("Validate Set ReadBy Date")
	public void validate_Set_ReadBy_Date() throws InvalidFormatException, IOException {
	    reg1.chlngEndDate(false);
	}

	@Then("Update End date to the challenge")
	public void update_End_date_to_the_challenge() throws InvalidFormatException, IOException {
		reg1.editEndDate();
	}
	
	@Given("Create Challenge")
	public void create_Challenge() throws Exception {
	    reg1.createChallenge(false, false);
	}
	
	@Then("Validate Accept challenge")
	public void validate_Accept_challenge() throws InvalidFormatException, IOException {
		rcsmoke.validateAcceptChallenge(true);
	}

	@Then("Validate Reject challenge")
	public void validate_Reject_challenge() throws InvalidFormatException, IOException {
	    reg1.validateAcceptChallenge(false);
	}

	@Then("Edit and add the same user who already rejected")
	public void edit_and_add_the_same_user_who_already_rejected() throws Exception {
	    reg1.addRejectedUser();
	}

	@When("Validate the message received for the update")
	public void validate_the_message_received_for_the_update() throws InvalidFormatException, IOException {
	    rc.checkInviteMessage();
	}
}
