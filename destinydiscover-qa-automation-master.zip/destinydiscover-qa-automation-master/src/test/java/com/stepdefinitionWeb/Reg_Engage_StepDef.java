package com.stepdefinitionWeb;

import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.base.CapabilitiesAndWebDriverUtils;
import com.pom_RWD.Login_RWD;
import com.pom_RWD.RWD_Drop4;
import com.pom_RWD.RWD_Drop4_Smoke;
import com.pom_RWD.RWD_Drop4_ULP;
import com.pom_RWD.RWD_RC_Smoke;
import com.pom_RWD.RWD_RP;
import com.pom_RWD.RWD_RP_Smoke;
import com.pom_RWD.Reg_Engage;
import com.pom_RWD.Reg_Engage_Drop4;
import com.pom_RWD.Reg_Engage_RC;
import com.pom_RWD.Reg_Engage_RP;
import com.pom_RWD.Rwd_RC;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Reg_Engage_StepDef extends CapabilitiesAndWebDriverUtils {
	
	RWD_RP rp= new RWD_RP();
	Reg_Engage reg = new Reg_Engage();
	RWD_RP_Smoke rp1=new RWD_RP_Smoke();
	RWD_RC_Smoke rwd_rc_smoke=new RWD_RC_Smoke();
	Rwd_RC rc=new Rwd_RC();
    Reg_Engage_RP rps=new Reg_Engage_RP();
    Reg_Engage_RC rcs = new Reg_Engage_RC();
    Reg_Engage_Drop4 reg_d4 = new Reg_Engage_Drop4();
    
    RWD_Drop4_Smoke r4 = new RWD_Drop4_Smoke();
	RWD_Drop4_ULP d4 = new RWD_Drop4_ULP();
	RWD_Drop4 rwd_drop4= new RWD_Drop4();

	public String progName = "Automation_RP_"+ generateRandomNumber(); 
	public String inviteMessage="You've been invited!";
	public String titleadded="Title Added to Program";
	public String prgrenamed="Program Renamed";
	public String prgredate="Program Date Changed";
	public String titleprogramremoved="Title Removed from Program";
	public String participantremoved="Removed from Program";
	public String participantLeft="Participant Left";
	public String newParticipant="New Participant";
	
	@Given("Go to Create program section and validate")
	public void go_to_Create_program_section_and_validate() throws InvalidFormatException, IOException {
	    reg.Create_RP();
	}

	@When("Enter the existing program name to the new program")
	public void enter_the_existing_program_name_to_the_new_program() throws InvalidFormatException, IOException {
	    reg.RP_Name(reg.name1);
	}
	
	@When("Enter Program Name")
	public void validate_Program_Name() throws InvalidFormatException, IOException {
		reg.RP_Name(progName);
	}
	
	@Given("Enter a Program Name")
	public void enter_a_Program_Name() throws InvalidFormatException, IOException {
	    reg.Enter_RP_Name(progName);
	}

	@When("Enter all the mandatory details")
	public void enter_all_the_mandatory_details() throws InvalidFormatException, IOException {
	    reg.mandatoryDetails();
	}
	
	@Then("Click on Publish program button")
	public void click_on_Publish_program_button() {
		reg.publishRP();
	}

	@Then("Vaildate the duplicate name message")
	public void vaildate_the_duplicate_name_message() {
	   reg.failureMsgvalidation();
	}
	
	@Given("Select private program")
	public void select_private_program() throws InvalidFormatException, IOException {
	    reg.private_RP();
	}

	@Then("Verify mandatory validation")
	public void verify_mandatory_validation() {
	    reg.mandatory_Assertion();
	}
	
	@When("Select Start date as past date and vaildate")
	public void select_Start_date_as_past_date_and_vaildate() throws InvalidFormatException, IOException {
	   reg.pastStartDate();
	}

	@When("Select End date before than start date and vaildate")
	public void select_End_date_before_than_start_date_and_vaildate() throws InvalidFormatException, IOException {
	    reg.pastEndDate();
	}
	
	//___________________Sankar_________________
	
	@And("Verify the functionality for duplicate program in program detail page")
	public void Verify_the_functionality_for_duplicate_program_in_program_detail_page() throws Exception {
		reg.duplicateProgram();
		
	}
	@And("Navigate to Program")
	public void Navigate_to_edit_Program() throws Exception {
		reg.navigatetoProgram();
		
	}
	@And("Verify User is not able to add same Student more than once")
	public void Verify_User_is_not_able_to_add_same_Student_more_than_once() throws Exception {
		reg.addsameStudent();
		
	}
	@And("Verify User is able to Remove the student from RP")
	public void Verify_User_is_able_to_Remove_the_student_from_RP() throws Exception {
		reg.removeStudent();
		
	}
	@And("Verify User is not able to add same Title more than once")
	public void Verify_User_is_not_able_to_add_same_Title_more_than_once() throws Exception {
		reg.addsameTitle();
		
	}
	@And("Verify User is able to Remove the Title from RP")
	public void Verify_User_is_able_to_Remove_the_Title_from_RP() throws Exception {
		reg.removeTitle();
		
	}
	@And("add titles in new program from mystuff checkout page")
	public void add_titles_in_new_program_from_mystuff_checkout_page() throws Exception {
		reg.addTitlefromCheckout();
		
	}
	@And("add titles in new program from mystuff history page")
	public void add_titles_in_new_program_from_mystuff_history_page() throws Exception {
		reg.addTitlefromhistory();
		
	}
	@And("add titles in new program from mystuff holds page")
	public void add_titles_in_new_program_from_mystuff_holds_page() throws Exception {
		reg.addTitlefromholds();
		
	}
	@And("add titles in new program from mystuff favorites page")
	public void add_titles_in_new_program_from_mystuff_favorite_page() throws Exception {
		reg.addTitlefromfavorite();
		
	}
	@And("add titles in new program from mystuff fines page")
	public void add_titles_in_new_program_from_mystuff_fines_page() throws Exception {
		reg.addTitlefromfines();
		
	}
	
	@And("Verify the admin able to create public program")
	public void Verify_the_admin_able_to_create_public_program() throws Exception {
		reg.createPublicProgramType(0,true, true, false, false,false);;
		
	}
	//___________________Sarath_________________
	
	@When("Verify user is able to navigate to Discover page")
	public void verify_user_is_able_to_navigate_to_Discover_page() throws IOException {
		reg.discoverPageNavigation(); 
	}
	
	@When("Verify user is able to add title to new program from Discover page")
	public void verify_user_is_able_to_add_title_to_new_program_from_Discover_page() throws IOException {
		reg.addTitleFromDiscoverPage();
	}

	@When("Verify user is able to navigate to Home page")
	public void verify_user_is_able_to_navigate_to_Home_page() throws IOException {   
	    reg.homePageNavigation();
	}
	
	@When("Verify user is able to add title to new program from Home page")
	public void verify_user_is_able_to_add_title_to_new_program_from_Home_page() throws IOException {
	    reg.addTitleFromHomePage();
	}
	
	@When("Verify user is able to navigate to Search page")
	public void verify_user_is_able_to_navigate_to_Search_page() throws IOException {
	    
	    reg.searchPageNavigation();
	}

	@When("Verify user is able to add title to new program from Search page")
	public void verify_user_is_able_to_add_title_to_new_program_from_Search_page() throws IOException {
	    
	    reg.addTitleFromSearchPage();
	}

	@When("Verify user is able to navigate to Search results page")
	public void verify_user_is_able_to_navigate_to_Search_results_page() throws InvalidFormatException, IOException {    
	    reg.searchResultNavigation();
	}

	@When("Verify user is able to add title to new program from Search results page")
	public void verify_user_is_able_to_add_title_to_new_program_from_Search_results_page() throws IOException {
	    reg.addTitleFromSearchResultPage();
	}
	
	@When("Verify the created program in dashboard and validate Program details in the My program tab")
	public void verify_the_created_program_in_dashboard_and_validate_Program_details_in_the_My_program_tab() throws InvalidFormatException, IOException {
		reg.CreatorPrgDetailsPageValidation();
	}
	
	@When("Verify user able to view active programs under Active program section")
	public void verify_user_able_to_view_active_programs_under_Active_program_section() throws IOException,Exception {
	   reg.activePrgValidation();
	}

	@When("Verify user able to view saved programs under Draft program section")
	public void verify_user_able_to_view_saved_programs_under_Draft_program_section() throws IOException {
	   reg.draftPrgValidation();
	}

	@When("Verify user able to view closed programs under closed program section")
	public void verify_user_able_to_view_closed_programs_under_closed_program_section() throws IOException,Exception {
	    reg.closedPrgValidation();
	}

	@When("Verify user able to view active public programs under ongoing program section")
	public void verify_user_able_to_view_active_public_programs_under_ongoing_program_section() throws IOException,Exception {
		reg.ongoingPrgValidation();
	}
	
	@When("Verify user able to view upcoming public programs under upcoming program section")
	public void verify_user_able_to_view_upcoming_public_programs_under_upcoming_program_section() throws IOException {
	    reg.upcomingPrgValidation();
	}
	
	@When("Verify user able to view basic details on programs cards under Active Programs")
	public void verify_user_able_to_view_basic_details_on_programs_cards_under_Active_Programs() {
		reg.prgCardValidation();
	}
	
	@When("Verify user able to unpublish the program")
	public void verify_user_able_to_unpublish_the_program() {
		reg.unpublishPrg();
	}

	@When("Verify user not able to see unpublished program in active program section")
	public void verify_user_not_able_to_see_unpublished_program_in_active_program_section() {
		reg.unpublishPrgValidation();
	}
	
	@When("Verify creator is able see more icon for all the added titles")
	public void verify_creator_is_able_see_more_icon_for_all_the_added_titles() {
		reg.booksInOrderCreator();
	}
	
	//________________________Saranya_________________
	
	@When("Create a Public Program with X of Y")
	public void create_a_Public_Program_with_X_of_Y() throws Exception {
	  
	   reg.createPublicProgramType(0,true, true, false, false,false);
	}
		
	@When("Create new Public Program with Books in Order")
	public void create_new_Public_Program_with_Books_in_Order() throws Exception {
	    reg.createPublicProgramType(0,false, true, false, false,false);
	}
	
	@Then("Create a new public program with multiple titles")
	public void create_a_new_public_program_with_multiple_titles() throws Exception {
		reg.createPublicProgramType(0,false,true,false,true,false);
	}

	@Then("Create a new public program with multiple participants")
	public void create_a_new_public_program_with_multiple_participants() throws Exception {
		reg.createPublicProgramType(5,false,true,true,false,false);
	}
	
	//________________________Selvi_________________
	
	@Then("Verify admin able to create and save the program successfully")
	public void verify_admin_able_to_create_and_save_the_program_successfully() throws Exception {
		reg.createPublicProgramType(0,false, true,false,false,true);
	}

	@When("Verify the admin able to create private program with x of y book type")
	public void verify_the_admin_able_to_create_private_program_with_x_of_y_book_type() throws Exception {
		reg.createPublicProgramType(0,false, true,false,false,false);
	}
	
	@When("Verify the admin able to create private program with books in order type")
	public void verify_the_admin_able_to_create_private_program_with_books_in_order_type() throws Exception {
		reg.createPublicProgramType(0,false, false,false,false,false);
	}
	
	@When("Verify the admin able to create private program with multiple students")
	public void verify_the_admin_able_to_create_private_program_with_multiple_students() throws Exception {
	    reg.createPublicProgramType(5,false,false,true,false,false);
	}
	
	@When("Verify the admin able to create private program with multiple titles")
	public void verify_the_admin_able_to_create_private_program_with_multiple_titles() throws Exception {
	    reg.createPublicProgramType(0,false,false,false,true,false);
	}
	@Then("Verify creator is able to see more icon for all the added title")
	public void verify_creator_is_able_to_see_more_icon_for_all_the_added_title() {
		reg.booksInOrderCreator();
	}
	
	@And("Verify that User is able to edit a program from program details page after published")
	public void Verify_that_User_is_able_to_edit_a_program_from_program_details_page_after_published() throws Exception {
		reg.programSearch();
		reg.editProgram();
		
	}
	@And("Verify that User is able to edit a program from Draft section")
	public void Verify_that_User_is_able_to_edit_a_program_from_Draft_section() throws Exception {
		reg.programSearch();
		reg.editdrftProgram();
		
	}
	@And("Verify the changes made in edit pages are updated correctly in program details page")
	public void Verify_the_changes_made_in_edit_pages_are_updated_correctly_in_program_details_page() throws Exception {
		reg.programDetailsValidationAdmin();
		
	}
	@And("Verify the changes made in edit pages are updated correctly in program cards in landing page")
	public void Verify_the_changes_made_in_edit_pages_are_updated_correctly_in_program_cards_in_landing_page() throws Exception {
		reg.programSearchwithoutClick();
		reg.programlandingValidation();
		
	}
	
	/*@When("Verify the admin able to create private program with x of y book type")
	public void verify_the_admin_able_to_create_private_program_with_x_of_y_book_type() throws InvalidFormatException, IOException {
	   
		rp1.createPrivateProgramTypeXofY();
		
	}
	@When("Verify the admin able to create private program with books in order type")
	public void verify_the_admin_able_to_create_private_program_with_books_in_order_type() throws InvalidFormatException, IOException {
	   rp1.createPrivateProgramBooksInOrder();
	}
	@When("Verify the admin able to create private program with multiple students")
	public void verify_the_admin_able_to_create_private_program_with_multiple_students() throws Exception {
	    rp1.createPrivateProgramMultipleStudentsAndMultipleTitles();
	}
	
	@When("Verify the admin able to create private program with multiple titles")
	public void verify_the_admin_able_to_create_private_program_with_multiple_titles() throws Exception {
	    rp1.createPrivateProgramMultipleStudentsAndMultipleTitles();
	}
	*/
	
	@When("Verify the leave program functionality of ongoing programs")
	public void verify_the_leave_program_functionality_of_ongoing_programs() throws IOException {
	    rps.onGoingProgramLeaveProgram();
	}

	@When("Verify join program functionality of ongoing programs")
	public void verify_join_program_functionality_of_ongoing_programs() throws IOException {
	    rps.onGoingProgramJoinProgram();
	}
	@When("Verify reject program functionality of ongoing programs")
	public void verify_reject_program_functionality_of_ongoing_programs() throws IOException {
	   rps.onGoingProgrmRejectProgram();
	}
	@When("Verify join program functionality of upcoming programs")
	public void verify_join_program_functionality_of_upcoming_programs() throws IOException {
	   rps.upComingProgramJoinProgram();
	}

	@When("Verify reject program functionality of upcoming programs")
	public void verify_reject_program_functionality_of_upcoming_programs() throws IOException {
		 rps.upComingProgramReject();
	}
	
	@When("Verify that user able to add titles in exsiting program from Search page")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_Search_page() throws IOException {
	    rps.addTitlesinExsitingProgramfromSearchpage();
	}
	
	@When("Verify that user able to add titles in exsiting program from Search results")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_Search_results() throws InvalidFormatException, IOException {
	   rps.addTitlesinExsitingProgramfromSearchResultspage();
	}

	@When("Verify that user able to add titles in exsiting program from my stuff checkouts")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_my_stuff_checkouts() throws InvalidFormatException, IOException {
	   rps.addTitlesinExsitingProgramfromMystuffCheckout();
	}

	@When("Verify that user able to add titles in exsiting program from my stuff history")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_my_stuff_history() throws InvalidFormatException, IOException {
	   rps.addTitlesinExsitingProgramfromMystuffHistory();
	}

	@Then("Verify that user able to add titles in exsiting program from my stuff favorites")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_my_stuff_favorites() throws InvalidFormatException, IOException {
	    rps.addTitlesinExsitingProgramfromMystuffFavourites();
	}
	@When("Verify that user able to add titles in exsiting program from discover page")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_discover_page() throws InvalidFormatException, IOException {
	    rps.addTitlesinExsitingProgramfromDiscover();
	}
	@When("Verify that user able to add titles in exsiting program from home page")
	public void verify_that_user_able_to_add_titles_in_exsiting_program_from_home_page() throws InvalidFormatException, IOException {
	   rps.addTitlesinExsitingProgramfromHomePage();
	}
	@When("Create publicnprogram with mandatory fields")
	public void create_publicnprogram_with_mandatory_fields() throws InvalidFormatException, IOException {
	    rps.createProgramWithMAndatoryFields();
	}

	@When("Create public program without assignee")
	public void create_public_program_without_assignee() throws InvalidFormatException, IOException {
	    rps.createProgramWithOutAssigne();
	}

	@When("Join the program and verify the progress percentage in details page")
	public void join_the_program_and_verify_the_progress_percentage_in_details_page() throws IOException {
		rps.onGoingProgramClick();
	    rps.joinOpenProgram();
	    rps.openprogramMetricsPercentageValidationDetailsPage();
	}

	@When("Veryfy the hrs spent and progress percentage in my program listing page")
	public void veryfy_the_hrs_spent_and_progress_percentage_in_my_program_listing_page() throws IOException {
	   rps.myProgramHrsSpentPercentageValidation();
	}
	@When("Click unpublished program and verify the user able to detele the program")
	public void click_unpublished_program_and_verify_the_user_able_to_detele_the_program() {
	    rps.deleteUnpublishedProgram();
	}

	@Then("Verify the deleted program not in unpublished list")
	public void verify_the_deleted_program_not_in_unpublished_list() {
		rps.verifyingDeletedUnPublishedProgram();;
	}
	@When("Click draft program and verify the user able to detele the program")
	public void click_draft_program_and_verify_the_user_able_to_detele_the_program() {
	    rps.delteDraftProgram();
	}

	@Then("Verify the deleted program not in draft list")
	public void verify_the_deleted_program_not_in_draft_list() {
	    rps.verifyingDeletedDraftProgram();
	}
	@Then("Verify ten students listed at time with for active list")
	public void verify_ten_students_listed_at_time_with_for_active_list() throws IOException {
	    rps.activeParticipantListValidation();
	}
	
	@When("Logout and login as invited user  {string} and {string} click Submit button")
	public void logout_and_login_as_invited_user_and_click_Submit_button(String UserName, String Password) throws InvalidFormatException, IOException {
		rp1.logout();
		Login_RWD.rwd_Login(UserName, Password);
	}

	@When("Verify participants  should not have option to leave Private program")
	public void verify_participants_should_not_have_option_to_leave_Private_program() {
	    rps.participantleavePrivateProgramValidation();
	}
	
	
	@And("Verify mandatory validations are in place for Public program while edit exsiting program")
	public void Verify_mandatory_validations_are_in_place_for_Public_program_while_edit_exsiting_program() throws Exception {
		reg.programSearch();
		
	}
	@And("Verify  mandatory validations are in place for Private program while edit exsiting program")
	public void Verify_mandatory_validations_are_in_place_for_Private_program_while_edit_exsiting_program() throws Exception {
		reg.programSearch();
		reg.editProgramValidation();
		
	}
	
	@And("unpublish the program")
    public void unpublish_the_program() throws Exception {
        reg.unpublishProgram();  
    }

    @And("Verify unpublished program is remove from active programs and move to unpublished section in landing page")
    public void Verify_unpublished_program_is_remove_from_active_programs_and_move_to_npublished_section_in_landing_page() throws Exception {
        reg.unPublishedSection();
    }

    @And("publish the program")
    public void publish_the_program() throws Exception {
        reg.programSearch();
        reg.publishprogram();
    }
    
    @And("Verify published program is remove from unpublished programs and move to active  section in landing page")
    public void Verify_published_program_is_remove_from_unpublished_programs_and_move_to_active_section_in_landing_page() throws Exception {
        reg.bookClub();
        reg.programSearchwithoutClick();
    }
    
	@Then("Verify mandatory validations are in place for Public program")
	public void Verify_mandatory_validations_are_in_place_for_Public_program() throws Exception {
		reg.editProgramValidation();
		reg.CheckmandatoryFileds();
	}
	@Given("Get notificationCount")
	public void Get_notificationCount() throws Exception {
		reg.getNotificationCount();
	}
	@And("Read the message")
	public void Read_the_message() throws Exception {
		reg.readMessage();
	}
	@Then("Verify that message center notification count decrease after read the notification")
	public void Verify_that_message_center_notification_count_decrease_after_read_the_notification() throws Exception {
		reg.verifymsgCount();
	}
	@And("Modify end Date")
	public void Modify_start_Date() throws Exception {
		reg.modifyEndDate();
	}
	@And("add Student")
	public void add_Student() throws Exception {
		reg.addStudent();;
	}
	@And("add Title")
	public void add_Title() throws Exception {
		reg.addTitle();;
	}
	@And("update ProgramName")
	public void update_ProgramName() throws Exception {
		reg.updateprgName();;
	}
	@And("User should able select and expand messages mark as unread")
	public void User_should_able_select_and_expand_messages_mark_as_unread() throws Exception {
		reg.markUnreadmsg();;
	}
	@And("Click Edit program")
	public void Click_Edit_program() throws Exception {
		reg.editProgramValidation();
	}
	@And("modify Remainder")
	public void modify_Remainder() throws Exception {
		reg.modifyReminder();
	}
	@And("save the Program")
	public void save_the_Program() throws Exception {
		reg.saveProgram();
	}
	@And("Verify that message center notification count increase after change into the challenge")
	public void Verify_that_message_center_notification_count_increase_after_change_into_the_challenge() throws Exception {
		reg.verifyinceasemsgCount();
	}
	@And("Verify all participants able to receive message when RP Published")
	public void Verify_all_participants_able_to_receive_message_when_RP_Published() throws Exception {
		reg.receiveMessageUpdate(inviteMessage);
	}
	@And("Verify new participant able to receive message when new participant added")
	public void Verify_new_participant_able_to_receive_message_when_new_participant_added() throws Exception {
		reg.receiveMessage(inviteMessage);
		logger.info("New parcipant received message validation ##pass");
	}
	@And("Verify new message received when Add new title")
	public void Verify_new_message_received_when_Add_new_title() throws Exception {
		reg.receiveMessageUpdate(titleadded);
		logger.info("New title added message validation #pass");
	}
	@And("Verify new message received for Update name")
	public void Verify_new_message_received_for_Update_name() throws Exception {
                reg.receiveMessageUpdate(prgrenamed);
		logger.info("Program name changed message validation #pass");		
	}
	@Then("Verify participants  should see progress percentage and hrs spent in landing page")
	public void verify_participants_should_see_progress_percentage_and_hrs_spent_in_landing_page() throws IOException {
	  rps.participantHrsSpentPercentageValidation();
	}
	
	@Then("Verify closed program displayed in closed program section")
	public void verify_closed_program_displayed_in_closed_program_section() throws IOException {
	    rps.closedProgramSectionValidation();
	}
	@And("Verify new message received for Update end date")
	public void Verify_new_message_received_for_Update_end_date() throws Exception {
		reg.receiveMessageUpdate(prgredate);
		logger.info("Update Date Message Validation ##Pass");
	}
	@And("Verify new message received for Removing title")
	public void Verify_new_message_received_for_Removing_title() throws Exception {
               reg.receiveMessageUpdate(titleprogramremoved);
		logger.info("Remove Title Message Validation ##Pass");	}
	@And("Search Program")
	public void Search_Program() throws Exception {
		reg.programSearch();
		reg.editProgramValidation();
	}
	@And("Remove Participants")
	public void Remove_Participants() throws Exception {
		reg.removeParticipant();
	}
	@And("edit Challenge")
	public void edit_Challenge() throws Exception {
		rcs.editchallenge();
	}
	@And("Verify Participant receive message when Removing any participant")
	public void Verify_Participant_receive_message_when_Removing_any_participant() throws Exception {
		reg.receiveMessage(participantremoved);
		logger.info("Remove participant receive message validation ##pass");
		
	}
	@And("Navigate to ongoing Program and validate")
	public void Navigate_to_ongoing_Program_and_validate() throws Exception {
		reg.onGoingProgramValidation();
		
	}
	@And("Join the program")
	public void Join_the_program() throws Exception {
		reg.joinProgram();
		
	}
	@And("Leave the Program")
	public void Leave_the_Program() throws Exception {
		rp.leaveProgram();
		
	}
	@And("Verify new message received for  Leave RP")
	public void Verify_new_message_received_for_Leave_RP() throws Exception {
		rps.receiveMessageRP(participantLeft);
		logger.info("Leave RP Message Validation ##pass");
		
	}
	@And("Verify new message received for joining RP")
	public void Verify_new_message_received_for_joining_RP () throws Exception {
               rps.receiveMessageRP(newParticipant);
		logger.info("Join RP Message Validation ##pass");		
	}
	@And("Verify new message received for  Un Publish RP")
	public void Verify_new_message_received_for_Un_Publish_RP() throws Exception {
                reg.checkunpublish();
		logger.info("Unpublish RP Message Validation ##pass");
		waitFor(3000); 		
	}
	@And("delete the Program")
	public void delete_the_Program() throws Exception {
		reg.programSearch();
		reg.editProgramValidation();
		rp.deleteProg();
		
	}
	@And("Verify new message received for  Delete RP")
	public void Verify_new_message_received_for_Delete_RP() throws Exception {
               reg.checkunpublish();
		logger.info("Delete RP Message Validation ##pass");		
	}
	//_________________Sakthi 
			//___________21 
			@When("Verify the admin able to create private program with more then {int} students")
			public void verify_the_admin_able_to_create_private_program_with_more_then_students(Integer int1) throws Exception {
			    reg.createPublicProgramType(int1,true,false,true,false,false);
				
			}
	@Then("Verify participant click on X icon then Report Abuse page should closed without save")
	public void verify_participant_click_on_X_icon_then_Report_Abuse_page_should_closed_without_save() {
		rcs.closeReportAbuse();
	}
			
			@Given("User should be able to view the list of students along with their progress metrics")
			public void user_should_be_able_to_view_the_list_of_students_along_with_their_progress_metrics() {
			    reg.students_Progress_metrics();
			}

			@Then("User should be able to view the reading list and Overall progress for each book")
			public void user_should_be_able_to_view_the_reading_list_and_Overall_progress_for_each_book() {
			    //Covered in above step
			}

			@When("User should be able to view {int} students listed at a time")
			public void user_should_be_able_to_view_students_listed_at_a_time(Integer int1) {
				reg.max_students(int1);
			}

			@When("User should be able to view pagination icons displayed below the students list to navigate")
			public void user_should_be_able_to_view_pagination_icons_displayed_below_the_students_list_to_navigate() {
			    reg.pagination_validation();
			}

			@When("User should be able to view the rest of the students")
			public void user_should_be_able_to_view_the_rest_of_the_students() {
			    reg.navigate_right();
			}
			
			@When("Verify the above created program should not display for another admin")
			public void verify_the_above_created_program_should_not_display_for_another_admin() {
			    reg.programSearch_diff_Admin();
			}
			
			@Then("Login as a invited user")
			public void login_as_a_invited_user() throws InvalidFormatException, IOException {
				reg.LoginAsInvitedUser();
			}
			
			@When("Verify that above Published Program is available for the assigned student under Active programs section")
			public void verify_that_above_Published_Program_is_available_for_the_assigned_student_under_Active_programs_section() {
				reg.programSearchwithoutClick(progName);
				reg.active_prog_validation();
			}
			
			@Then("Report Abuse Submit")
			public void report_Abuse_Submit() throws InvalidFormatException, IOException {
				rc.maxlengthchar();
			}
			
			@When("Validate report abuse notification for the above challenge")
			public void validate_report_abuse_notification_for_the_above_challenge() throws InvalidFormatException, IOException {
				rwd_rc_smoke.ReportAbusevalidation();
			}
			
			@Then("Validate and Click on NoActionNeeded button")
			public void validate_and_Click_on_NoActionNeeded_button() {
				reg.noAction();
			}

			@When("Validate the message received to No action needed")
			public void validate_the_message_received_to_No_action_needed() throws Exception, IOException {
			    rcs.noActionNeedMsg();
			}
			
			@Then("Admin should navigate to the challenge Name")
			public void admin_should_navigate_to_the_challenge_Name() {
				 rc.challengeSearchReportAbuse();
			}

			@Then("Validate and Click on Delete button")
			public void validate_and_Click_on_Delete_button() {
			    reg.delete_Report();
			}

			@When("Validate the message received for Delete")
			public void validate_the_message_received_for_Delete() throws InvalidFormatException, IOException {
				rcs.ReportAbuseDelete();
			}
			
			@Then("Add new participant to the challenge")
			public void add_new_participant_to_the_challenge() throws IOException, InvalidFormatException {
			    rwd_rc_smoke.addedParticipanttochallenge();
			}

			@Then("save the changes")
			public void save_the_changes() throws IOException, InvalidFormatException {
			    rcs.saveChanges();
			}
			
			@When("Check the message for added new participant- RC New Participant")
			public void check_the_message_for_added_new_participant_RC_New_Participant() throws InvalidFormatException, IOException {
			    rcs.addNewPariticipantMsg();
			}

			@Then("Remove participant from the challenge")
			public void remove_participant_from_the_challenge() {
			    
			}

			@When("Check the message for removed the participant- RC Participant removed")
			public void check_the_message_for_removed_the_participant_RC_Participant_removed() throws Exception, IOException {
			    rcs.removePariticipantMsg();
			}
			
			@When("Navigate to my program in book club lading page")
		    public void navigate_to_my_program_in_book_club_lading_page() {
		        rps.navToMyProgram();
		    }
			
			@When("user able to view Program name Ready by date and description in program card in Active program section")
			public void user_able_to_view_Program_name_Ready_by_date_and_description_in_program_card_in_Active_program_section() {
			   reg.activeprogramsection();
			}
			@Given("User able to view dropdown option in message center")
			public void user_able_to_view_dropdown_option_in_message_center() throws InvalidFormatException, IOException {
				rc.dropdownMsg();
			}

			@Given("user able to delete message from message center")
	                public void user_able_to_delete_message_from_message_center() throws InvalidFormatException, IOException {
		        rc.clearMessages();
		       logger.info("Delete Message Validation #Pass");
	}

			@Given("Verify user able to view message details screen after clicking on + icon")
			public void verify_user_able_to_view_message_details_screen_after_clicking_on_icon() {
			    // Write code here that turns the phrase above into concrete actions
				reg_d4.Addicon();
			}

			@Given("Verify the no message screen")
			public void verify_the_no_message_screen() throws IOException, InvalidFormatException {
				rc.clearMessages();
			}
			
			
			
			@Given("Verify user is able to view more menu options  Back Office, Help")
			public void verify_user_is_able_to_view_more_menu_options_Back_Office_Help() {
				d4.moreMenuLandingValidation();
				
			}

			@Given("User is able to click tap on the links in the more menu and be navigated to the  corresponding landing pages\\/ screens")
			public void user_is_able_to_click_tap_on_the_links_in_the_more_menu_and_be_navigated_to_the_corresponding_landing_pages_screens() {
				d4.moreMenuLandingValidation();
			}

				
			@When("Verify school name should show above the news and announcements widget")
			public void verify_school_name_should_show_above_the_news_and_announcements_widget() {
				reg_d4.schoolname();
			}


			@When("user able to see all in Learning Resources")
			public void user_able_to_see_all_in_Learning_Resources() {
				reg_d4.seeall();
			}

			@When("user  user able to viewlearning resources name")
			public void user_user_able_to_viewlearning_resources_name() {
				reg_d4.viewlearningname();
			}

			@When("Insights & Goals-> Default Setting-> click on each insight to set personal goals for themselves in the goals pop-up")
			public void insights_Goals_Default_Setting_click_on_each_insight_to_set_personal_goals_for_themselves_in_the_goals_pop_up() throws IOException {
				rwd_drop4.setpersonalgoal();
			}

			@When("user is able to view the default insights for themselves if they have not set any personal goals")
			public void user_is_able_to_view_the_default_insights_for_themselves_if_they_have_not_set_any_personal_goals() throws IOException {
				rwd_drop4.checkDefaultInsights();
			}
			
			@When("user is able to view the set goal pop-up for the corresponding insight")
			public void user_is_able_to_view_the_set_goal_pop_up_for_the_corresponding_insight() throws IOException {
			rwd_drop4.setgoal();
			}
			
			@When("Application is display an error if user tries to click on Set Goal CTA by entering an invalid value")
			public void application_is_display_an_error_if_user_tries_to_click_on_Set_Goal_CTA_by_entering_an_invalid_value() throws IOException {
			rwd_drop4.checkinvalidsetgoal();
			}

			@When("user is able to click on Close icon to close the pop-up")
			public void user_is_able_to_click_on_Close_icon_to_close_the_pop_up() throws IOException {
				reg_d4.popupclose();
			}
			
			@When("Verify the Mark as read option user able to click on message details")
			public void Verify_the_Mark_as_read_option_user_able_to_click_on_message_details() throws IOException {
				reg.markUnreadmsg();
			}
			
			@When("Verify the Mark as unread option user able to click on message details")
			public void Verify_the_Mark_as_unread_option_user_able_to_click_on_message_details() throws IOException {
				reg.markreadmsg();
			}
			
			@When("user is able to view only active challenges and programs that they are participating in in the RC\\/RP carousel")
			public void user_is_able_to_view_only_active_challenges_and_programs_that_they_are_participating_in_in_the_RC_RP_carousel() throws InvalidFormatException, IOException {
				r4.RP_RC_Carousel();
			}
			
			@When("user is able to click on Set Goal CTA \\(enabled only when user enters a valid input) to set the value entered as goal")
			public void user_is_able_to_click_on_Set_Goal_CTA_enabled_only_when_user_enters_a_valid_input_to_set_the_value_entered_as_goal() throws IOException {
			   reg.SetGoalbutton();
			}

			
			@When("user is able to view the title, text, disclaimer text , Set Goal CTA")
			public void user_is_able_to_view_the_title_text_disclaimer_text_Set_Goal_CTA() throws IOException {
			    reg.checkgoal();
			}
			
			@When("Average Read time _in minutes_ Average Listened time_in minutes_ Books Read this year_Current Streak_Booksreadthis_month")
			public void average_Read_time__in_minutes__Average_Listened_time_in_minutes__Books_Read_this_year_Current_Streak_Booksreadthis_month() throws IOException {
			  
				rwd_drop4.streakgoal();
				rwd_drop4.listeningperday();
				rwd_drop4.readingperday();
				rwd_drop4.monthlygoal();
				rwd_drop4.yearlygoal();}


			@When("User should be able to view the ?Reading Program? text, Program Name, Description")
			public void user_should_be_able_to_view_the_Reading_Program_text_Program_Name_Description() {
				reg.prgCardValidation();
    
			}

			@When("User should be able to view program details page with breadcrumb with the CreatorProgramDetailsPageValidation")
			public void user_should_be_able_to_view_program_details_page_with_breadcrumb_with_the_CreatorProgramDetailsPageValidation() throws InvalidFormatException, IOException {
				reg.CreatorPrgDetailsPageValidation();
			}
	@Then("Navigate Open Programs")
	public void navigate_Open_Programs() throws IOException {
		rps.onGoingProgramClick();
	}

	
	@Then("Create program for message center validation")
	public void create_program_for_message_center_validation() throws Exception {
		reg.createPublicProgramTypeMsg(0, true, true, false, false, false);
	}
	
	@Given("Click mesage center icon")
	public void click_mesage_center_icon() {
		waitFor(9000);
		ClickOnWebElement(rc.RWDMessagecenter);
	}

	
}
