package com.reusableMethods;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.google.common.collect.ImmutableMap;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.android.nativekey.PressesKey;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class CommonActions {
	public String platformName = null;
//	public  Properties props;
	public  Logger logger = Logger.getLogger(String.valueOf(CommonActions.class));
//	public  RemoteWebDriver driver = DriverManager.getDriver();
	public String ConfigurationFile = System.getProperty("user.dir") + "/Configs/Configuration.properties";
	public WebElement element = null;
	public  String mainWindow = null;
//	 WebDriverWait browserWithElementWait = null;
//	 Date date = java.util.Calendar.getInstance().getTime();
//	public WebDriverWait exwait = null;
	ExcelReader reader = new ExcelReader();
	
	public CommonActions() {
		platformName = System.getProperty("platform");//getData("platformName");
	}
	
	public  String getData(String data) throws IOException {
//		loadData();
		Properties props = new Properties();
		File file = new File(System.getProperty("user.dir") + "/src/test/resources/config/config.properties");
		FileReader fileInput = new FileReader(file);
		props.load(fileInput);
		data = props.getProperty(data);
		return data;
	}
	
	
//	public  void loadData() throws IOException {
//		
//		props = new Properties();
//		File file = new File(System.getProperty("user.dir") + "/src/test/resources/config/config.properties");
//		FileReader fileInput = new FileReader(file);
//		props.load(fileInput);
//	}
	public  boolean fluentWaitDisplayed(MobileElement element, long t, long ts) {
		try {
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(DriverManager.getDriver()).withTimeout(Duration.ofSeconds(t))
					.pollingEvery(Duration.ofMillis(ts)).ignoring(Exception.class);
			wait.until(ExpectedConditions.visibilityOf(element));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isToastMessageDisplayed(String message) {
		boolean isDisplayed = false;
		int count = 0;
		do {
			if (DriverManager.getDriver().getPageSource().contains(message)) {
				isDisplayed = true;
				break;
			}
			count++;
		} while (count < 10);
		return isDisplayed;
	}

	public  void keyBoardSearch() {
		DriverManager.getDriver().executeScript("mobile: performEditorAction", ImmutableMap.of("action", "search"));
	}

	public  void androidKeyBack() {
		((PressesKey) DriverManager.getDriver()).pressKey(new KeyEvent(AndroidKey.BACK));
	}

	public  void WaitForMobileElement(MobileElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		exwait.until(ExpectedConditions.visibilityOf(element));
	}
	

	public  void swipeDown() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getHeight() * 0.4);
		int scrollEnd = (int) (dimension.getHeight() * 0.2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(0, scrollEnd))
				.release().perform();
	}
	
	public void swipeScreen(String dir) {
	   
	    final int ANIMATION_TIME = 200; // ms

	    final int PRESS_TIME = 200; // ms

	    int edgeBorder = 10; // better avoid edges
	    PointOption pointOptionStart, pointOptionEnd;

	    // init screen variables
	    Dimension dims = DriverManager.getDriver().manage().window().getSize();

	    // init start point = center of screen
	    pointOptionStart = PointOption.point(dims.width / 2, dims.height / 2);

	    switch (dir) {
	        case "DOWN": // center of footer
	            pointOptionEnd = PointOption.point(dims.width / 2, dims.height - edgeBorder);
	            break;
	        case "UP": // center of header
	            pointOptionEnd = PointOption.point(dims.width / 2, edgeBorder);
	            break;
	        case "LEFT": // center of left side
	            pointOptionEnd = PointOption.point(edgeBorder, dims.height / 2);
	            break;
	        case "RIGHT": // center of right side
	            pointOptionEnd = PointOption.point(dims.width - edgeBorder, dims.height / 2);
	            break;
	        default:
	            throw new IllegalArgumentException("swipeScreen(): dir: '" + dir + "' NOT supported");
	    }

	    // execute swipe using TouchAction
	    try {
	        new TouchAction(DriverManager.getDriver())
	                .press(pointOptionStart)
	                // a bit more reliable when we add small wait
	                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(PRESS_TIME)))
	                .moveTo(pointOptionEnd)
	                .release().perform();
	    } catch (Exception e) {
	        System.err.println("swipeScreen(): TouchAction FAILED\n" + e.getMessage());
	        return;
	    }

	    // always allow swipe action to complete
	    try {
	        Thread.sleep(ANIMATION_TIME);
	    } catch (InterruptedException e) {
	        // ignore
	    }
	}
	
	public  void scrollAndClick(By listItems, String Text) throws InterruptedException {
		boolean flag = false;
		WebDriver driver = DriverManager.getDriver();
		while (true) {
			for (WebElement el : driver.findElements(listItems)) {
				if (el.getText().equals(Text)) {
					el.click();
					flag = true;
					break;
				} else {
					swipeDown();
				}
			}
		}
	}

	public  void horizontalSwipe(List<MobileElement> e) {
		MobileElement firdelement = e.get(0);
		MobileElement secondElement = e.get(1);
		MobileElement thirdElement = e.get(2);

		int midOfY = thirdElement.getLocation().y + (thirdElement.getSize().height / 2);
		int fromXLocation = thirdElement.getLocation().x;
		int toXLocation = firdelement.getLocation().x;

		TouchAction action = new TouchAction((PerformsTouchActions) DriverManager.getDriver());
		action.press(PointOption.point(fromXLocation, midOfY))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
				.moveTo(PointOption.point(toXLocation, midOfY)).release().perform();

	}

	public  void horizontalSwipeAndriod(List<MobileElement> e) {

		MobileElement firstElement = e.get(0);
		MobileElement secondElement = e.get(1);
		int midOfY = secondElement.getLocation().y + (secondElement.getSize().height / 2);
		int fromXLocation = secondElement.getLocation().x;
		int toXLocation = firstElement.getLocation().x;
		TouchAction action = new TouchAction((PerformsTouchActions) DriverManager.getDriver());
		action.press(PointOption.point(fromXLocation, midOfY))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
				.moveTo(PointOption.point(toXLocation, midOfY)).release().perform();

	}

	public  boolean hidemobileKeyboard(AndroidDriver app) {
		boolean isKeyboardHideResult = false;
		try {
			app.hideKeyboard();
			isKeyboardHideResult = true;
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return isKeyboardHideResult;
	}
	
	
	public boolean isElementPresent(WebElement e)
    {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 13);
        boolean flag = false;
        try {
        	exwait.until(ExpectedConditions.visibilityOf(e)).isDisplayed();
            flag=true;
        }
        catch(Exception a)
        {
            flag=false;
        }
        return flag;
    }
	
	public  void takeScreenshot(WebDriver driver, String filename) throws IOException
	{
		File sc = (File)((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sc, new File(filename));
	}
	public  void hideMobileKeyboard() {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hidemobileKeyboard((AndroidDriver) DriverManager.getDriver());
		} else {
			int isPresent = DriverManager.getDriver().findElements(By.xpath("//XCUIElementTypeButton[@name='Return']")).size();
			if (isPresent == 1) {
				DriverManager.getDriver().findElement(By.xpath("//XCUIElementTypeButton[@name='Return']")).click();
			}
			int isElement = DriverManager.getDriver().findElements(By.xpath("//XCUIElementTypeButton[@name=\"Done\"]")).size();
			if (isElement ==1 ) {
				DriverManager.getDriver().findElement(By.xpath("//XCUIElementTypeButton[@name=\"Done\"]")).click();
			}
		}
	}

	public void ScrollTo(String Scroll, String direction, MobileElement element) {
		if ("ANDROID".equalsIgnoreCase(platformName)) {
			DriverManager.getDriver().findElement(MobileBy.AndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text(" + Scroll
							+ ").instance(0))"));
		} else if ("IOS".equalsIgnoreCase(platformName)) {
			for (int i = 0; i < 5; i++) {
				boolean isElementPresent = element.isDisplayed();
				if (!isElementPresent) {
					Map<String, Object> args = new HashMap<>();
					args.put("direction", direction);
					DriverManager.getDriver().executeScript("mobile: swipe", args);
				} else {
					break;
				}
			}
		}
	}
	
	public void ScrollToMobileElement(String Scroll) {
		MobileElement element = (MobileElement) DriverManager.getDriver().findElement(
				MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).instance(0)"
						+ ".scrollIntoView(new UiSelector().text(" + Scroll + "))"));
		element.click();
	}

	public  void waitFor (int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public  boolean isSelected(MobileElement e) {
		boolean b = e.isSelected();
		return b;
	}

	public  boolean isEnabled(MobileElement e) {
		boolean result = e.isEnabled();
		return result;
	}

	public  boolean isDisplayed(MobileElement e) {
		boolean d = e.isDisplayed();
		return d;
	}

	public  int  generateRandomNumber()
	{
		Random rand = new Random();
		int randNumber = rand.nextInt(100000);
		return randNumber;
		
	}

	public String RandomStringGenerate() {
		return RandomStringUtils.randomAlphanumeric(5);
	}

	public String RandomStringGenerateAscii() {
		return RandomStringUtils.randomAscii(10);
	}
	
	public  void highlightElement(WebElement element, WebDriver webDriver) {
		for (int i = 0; i < 1; i++) {
			JavascriptExecutor js = (JavascriptExecutor) webDriver;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
					"color: black; border: 3px solid black;");
		}
	}

	public  String getMainWindow() throws Throwable {
		String mainWindow = null;
		try {
			mainWindow = DriverManager.getDriver().getWindowHandle();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mainWindow;
	}

	public  void switchToMainWindow() throws Throwable {
		// killChromeSession();
		try {
			DriverManager.getDriver().switchTo().window(mainWindow);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public  void switchToNewWindow() throws Throwable {
		try {
			Set<String> windowNames = DriverManager.getDriver().getWindowHandles();
			for (String windowName : windowNames) {

				if (windowName != null) {
					DriverManager.getDriver().switchTo().window(windowName);
				} else {
					throw new Exception("New window could not be retrived");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public  String RandomStringGenerate(int count) {

		return RandomStringUtils.randomAlphanumeric(count);

	}

	public  void javascriptScroll(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');", element);
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
		js.executeScript("arguments[0].scrollIntoView();", element);

	}

	public  void swipeDownw() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getHeight() * 0.5);
		int scrollEnd = (int) (dimension.getHeight() * 0.2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(0, scrollEnd))
				.release().perform();
	}
	
	public  void swipeUp() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart_x = (int) (dimension.getHeight() * 0.20);
		int scrollStart_y = (int) (dimension.getHeight() * 0.80);
//		int scrollEnd_x = (int) (dimension.width * 0.2);
//		int scrollEnd_y = (int) (dimension.height * 0.2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart_x))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(2, scrollStart_y))
				.release().perform();
	}

	public  void swiperight(MobileElement e) {
		
		//Swipe Right to Left
		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getWidth() * 0.70);
		int scrollEnd = (int) (dimension.getWidth() * 0.30);
		int y = (int) (dimension.getHeight() / 2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(scrollEnd, y))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(scrollStart, y))
				.release().perform();
	}
	
	public  void swipeleft(MobileElement e) {

//		new TouchAction(DriverManager.getDriver())
//				.press(PointOption.point(scrollStart, y))
//				.waitAction(300)
//				.moveTo(0,100)
//				.release()
//				.perform();

		//Swipe Left to Right
		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getWidth() * 0.8);
		int scrollEnd = (int) (dimension.getWidth() * 0.4);
		int y = (int) (dimension.getHeight() / 2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(scrollStart, y))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(scrollEnd, y))
				.release().perform();
	}

	public void ClickOnMobileElement(MobileElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
		mobelement.click();
	}

//	public  void SendKeysOnMobileElement(MobileElement element, String Value) {
//		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
//		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
////		mobelement.clear();
//		mobelement.sendKeys(Value);
//	}

	// Method to perform a swipe from right to left
    public static void swipeRightToLeft(MobileElement element) {
        org.openqa.selenium.Point location = element.getLocation();
        org.openqa.selenium.Dimension size = element.getSize();

        int start_x = location.getX() + size.getWidth() - 10; // Adjust the 10 as needed
        int end_x = location.getX() + 20; // Adjust the 10 as needed
        int y = location.getY() + size.getHeight() / 2;

        new TouchAction<>(DriverManager.getDriver())
                .press(PointOption.point(start_x, y))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))) // Adjust duration as needed
                .moveTo(PointOption.point(end_x, y))
                .release()
                .perform();
    }

	public void swipeUntilElementIsVisible(MobileElement element) {
		int maxSwipes = 5;  
		int swipeDuration = 1000;
	
		for (int i = 0; i < maxSwipes; i++) {
			swipeRightToLeft(element);  
	
			if (isElementPresent(element)) {
				break;  
			}	
			// Wait for a short duration before the next swipe
			waitFor(swipeDuration);
		}
	}
	

	public  void SendKeysOnMobileElement(MobileElement element, String value) {
		// WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		// MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
		// mobelement.clear();
		// exwait.until(ExpectedConditions.elementToBeClickable(element));
		// mobelement.sendKeys(Value);
		try {
			WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
			MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));	
			// Check if the element is enabled and clear it only if needed
			if (mobelement.isEnabled() && mobelement.getText() != null && !mobelement.getText().isEmpty()) {
				mobelement.clear();
			}
			exwait.until(ExpectedConditions.elementToBeClickable(element));
			mobelement.sendKeys(value);
		} catch (Exception e) {
			logger.log(Level.INFO,"Element interaction failed: " + e.getMessage());
		}
	}

	public  void SendKeysOnMobileElementList(MobileElement mobileElement, String Value) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		MobileElement mobelement = (MobileElement) exwait
				.until(ExpectedConditions.visibilityOf((WebElement) mobileElement));
		// mobelement.clear();
		mobelement.sendKeys(Value);
	}

	public  void SendKeysWithoutClear(MobileElement element, String Value) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
		mobelement.sendKeys(Value);
	}

	public  void MobileElement(MobileElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		exwait.until(ExpectedConditions.visibilityOf(element));

	}

	public  void MobileElementList(List<MobileElement> title_MoreOptions) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		exwait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy((By) title_MoreOptions));

	}

	public  void TouchActionClick(MobileElement element) throws InterruptedException {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
		TouchActions act = new TouchActions(DriverManager.getDriver());
		act.click(mobelement).build().perform();

	}

	public  boolean IsDisplayedMobileElement(MobileElement element) {
		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(element));
		return mobelement.isDisplayed();

	}

	public  void changeDriverContextToWeb(AppiumDriver driver) {
		Set<String> allContext = DriverManager.getDriver().getContextHandles();
		for (String context : allContext) {
			logger.info(context);
			if (context.contains("WEBVIEW"))
				DriverManager.getDriver().context(context);
		}
	}

	public  void changeDriverContextToNative(AppiumDriver driver) {
		Set<String> allContext = DriverManager.getDriver().getContextHandles();
		for (String context : allContext) {
			if (context.contains("NATIVE"))
				DriverManager.getDriver().context(context);
		}
	}

	public void IosButtonClick(String string) {
		MobileElement element = (MobileElement) DriverManager.getDriver()
				.findElementByXPath("//XCUIElementTypeButton[@name='" + string + "']");
		element.click();
	}

	public  void ClickUsingXandYCords(MobileElement element) {
		Point point = element.getLocation();
		int xcord = point.getX();
		int ycord = point.getY();
		new TouchAction((PerformsTouchActions)DriverManager.getDriver()).tap(PointOption.point(xcord, ycord)).perform();
	}

	public  void MobDragAndDrop(MobileElement element1, MobileElement element2) {
		Actions act = new Actions(DriverManager.getDriver());
		act.clickAndHold(element1).moveToElement(element2).release().build().perform();

	}
	
	public  void touchCenter() {
		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getHeight() * 0.20);
		int scrollEnd = (int) (dimension.getHeight() * 0.50);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(2, scrollStart))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(2, scrollEnd))
				.release().perform();
	}
	
	public  void navBack() {
		((PressesKey) DriverManager.getDriver()).pressKey(new KeyEvent(AndroidKey.BACK));
	}
	
	public  void jsClick(WebElement element) {
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 60);
		WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');", webelement);
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", webelement, "");
		js.executeScript("arguments[0].click();", webelement);
	}
	
	public  void switchToIframe(WebElement element) {
	    WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 120);
		WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
		DriverManager.getDriver().switchTo().defaultContent();
		DriverManager.getDriver().switchTo().frame(webelement);
	}
	public  boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	public void scrollandCheck(MobileElement ele) {
		HashMap<String, String> scrollObject = new HashMap<>();
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
        try {
            scrollObject.put("direction", "down");
            scrollObject.put("xpath",ele.getText());
            js.executeScript("mobile: scroll", scrollObject);
        } catch (Exception e) {

        }

    }

	public void scrollandCheckUp(MobileElement ele) {
		HashMap<String, String> scrollObject = new HashMap<>();
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		try {
			scrollObject.put("direction", "Up");
			scrollObject.put("xpath",ele.getText());
			js.executeScript("mobile: scroll", scrollObject);
		} catch (Exception e) {

		}

	}
//	public enum Direction {
//	    UP,
//	    DOWN,
//	    LEFT,
//	    RIGHT;
//	}

	public boolean switchToWebAppContext(AndroidDriver<?> driver) throws InterruptedException {
		boolean flag = true;
//		try {
		System.out.println("**********************Started switching to web context********************");
		Set<String> contextHandles = driver.getContextHandles();
		for (String context : contextHandles) {
			if (context.contains("WEBVIEW_Terrace")) {
				driver.context(context);
			}
		}
		return flag;
	}
//					Thread.sleep(200L);
//				}
//			}
//			flag = false;
//			System.out.println("**********************Successfully switching to web context***************");
//		} catch (Exception e) {
//			System.err.println("********************Not able to switching to web context******************");
//			logger.info(e.getMessage());
//		} finally {
//			System.out.println("flag Value : " + flag);
//			if (flag) {
//				System.out.println("Finally Block Executed : Switch to Native App Method Called ");
//				switchToNativeAppContext(driver);
//				System.out.println("********************** switching back to Native App context***************");
//			}
//		}


				public void switchToNativeAppContext (AppiumDriver < ? > driver){
					try {
						Set<String> contextHandles = driver.getContextHandles();
						for (String context : contextHandles) {
							if (context.contains("NATIVE")) {
								driver.context(context);
								Thread.sleep(200L);
							}
						}
					} catch (Exception e) {
						logger.info(e.getMessage());
					}
				}

	public  void swipeDownMore() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getHeight() * 0.6);
		int scrollEnd = (int) (dimension.getHeight() * 0.2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(0, scrollEnd))
				.release().perform();
	}

	public void scroll(AppiumDriver driver, double start_xd, double start_yd, double end_xd, double end_yd) {
		Dimension dimension = driver.manage().window().getSize();

		int start_x = (int) (dimension.getWidth() * start_xd);
		int start_y = (int) (dimension.getHeight() * start_yd);

		int end_x = (int) (dimension.getWidth() * end_xd);
		int end_y = (int) (dimension.getHeight() * end_yd);


		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(start_x, start_y))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
				.moveTo(PointOption.point(end_x, end_y)).release().perform();
	}

	public  void swipeUpLess() {

		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart_x = (int) (dimension.getHeight() * 0.20);
		int scrollStart_y = (int) (dimension.getHeight() * 0.60);
//		int scrollEnd_x = (int) (dimension.width * 0.2);
//		int scrollEnd_y = (int) (dimension.height * 0.2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(0, scrollStart_x))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(2, scrollStart_y))
				.release().perform();
	}

}
