package pom.kidszone;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Agerangemapping extends CommonActions {
	public Agerangemapping(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(xpath="//XCUIElementTypeScrollView/XCUIElementTypeOther[4]/XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//android.widget.LinearLayout[@content-desc=\"Card Number*\"]")
	public MobileElement libraryId_txt_libId;

	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name=\"Login\"]")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/btn_login")
	public MobileElement login_btn_libId;

	@iOSXCUITFindBy(accessibility="resource-id")
	@AndroidFindBy(xpath = "//*[@resource-id = 'SEARCH_TEXT_BOX']")
	public MobileElement clickSearchbar;
	
	public boolean verifyLibraryHeader() {
		boolean match = false;
		waitFor(500);
		try {
			if (isElementPresent(libraryId_txt_libId)) {
				logger.info("User verified the library header");
				match = true;
			} else if (isElementPresent(libraryId_txt_libId)) {
				logger.info("User verified the library header");
				match = true;

			}

		} catch (Exception e) {
			logger.severe("Error while verifing profiles header : " + e.getMessage());
			match = false;
		}

		return match;

	}

	public boolean clickProfiles() {
		boolean match = false;
		try {
			if (isElementPresent(libraryId_txt_libId)) {
				ClickOnMobileElement(libraryId_txt_libId);
				logger.info("User clicked profiles");
				match = true;
			} else if (isElementPresent(libraryId_txt_libId)) {
				ClickOnMobileElement(libraryId_txt_libId);
				logger.info("User clicked profiles");
				match = true;
			}

		} catch (Exception e) {
			logger.severe("Error while clicking profiles : " + e.getMessage());
			match = false;
		}
		return match;
	}

	public void clicksearch() {
		ClickOnMobileElement(clickSearchbar);
		SendKeysOnMobileElement(clickSearchbar, "Adult");
	}
	public void clicksearchicon() {
		
	}
}
