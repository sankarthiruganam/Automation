package pom.kidszone;

import java.io.IOException;
import java.util.List;

import com.driverfactory.DriverManager;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class GoalsandInsights extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(GoalsandInsights.class);
	public GoalsandInsights(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement homePg_btn_myShelfFooter;

	@iOSXCUITFindBy(accessibility = "My Shelf")
	@AndroidFindBy(xpath = "//*[@text='My Shelf']")
	private MobileElement homePg_btn_myShelfFooter1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"My Stuff\"]")
	@AndroidFindBy(xpath = "//*[@text='My Shelf']")
	private MobileElement homePg_old_myShelfFooter;

	@iOSXCUITFindBy(accessibility = "My Library")
	@AndroidFindBy(xpath = "//*[@text='My Library']")
	private MobileElement homePg_btn_myLibFooter;

	@iOSXCUITFindBy(accessibility = "txtHeaderCard")
	@AndroidFindBy(xpath = "//*[@resource-id='txtHeaderCard']")
	private MobileElement myShelfPg_lbl_GoalsHeader;

	@iOSXCUITFindBy(accessibility = "btnToggle")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[1]/android.widget.Button/android.widget.ImageView)[2]")
	private MobileElement myShelfPg_btn_GoalsCollapse;

	@iOSXCUITFindBy(accessibility = "rowInsightCard0")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard0']")
	private MobileElement myShelfPg_btn_AvgReadInsight;

	@iOSXCUITFindBy(accessibility = "rowInsightCard0")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard0']")
	private MobileElement myShelfPg_btn_AvgRead;

	@iOSXCUITFindBy(accessibility = "rowInsightCard1")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard1']")
	private MobileElement myShelfPg_btn_AvgListenInsight;

	@iOSXCUITFindBy(accessibility = "rowInsightCard2")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard2']")
	private MobileElement myShelfPg_btn_currentStreakInsight;

	@iOSXCUITFindBy(accessibility = "rowInsightCard3")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard3']")
	private MobileElement myShelfPg_btn_bookperMonthInsight;

	@iOSXCUITFindBy(accessibility = "rowInsightCard4")
	@AndroidFindBy(xpath = "//*[@resource-id='rowInsightCard4']")
	private MobileElement myShelfPg_btn_bookPerYearInsight;

	@iOSXCUITFindBy(accessibility = "insightreadLbl")
	@AndroidFindBy(id = "insightreadLbl")
	private List<MobileElement> myShelfPg_lbl_insightMetric;

	@iOSXCUITFindBy(accessibility = "insightreadLbl")
	@AndroidFindBy(id = "insightreadLbl")
	private List<MobileElement> myShelfPg_lbl_GoalTrack;

	@iOSXCUITFindBy(accessibility = "insightreadLbl")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup/preceding::android.view.ViewGroup/android.widget.TextView[1])[6]")
	private MobileElement myShelfPg_lbl_GoalTrackNum;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"scrollViewGoalsContainer\"]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.HorizontalScrollView[1]/android.view.ViewGroup/android.view.ViewGroup")
	private List<MobileElement> myShelfPg_icon_Goal;

	@iOSXCUITFindBy(accessibility = "txtGoalHeader")
	@AndroidFindBy(xpath = "//*[@resource-id='txtGoalHeader']")
	private MobileElement setGoalPg_lbl_Header;

	@iOSXCUITFindBy(accessibility = "HeaderDesc")
	@AndroidFindBy(id = "HeaderDesc")
	private MobileElement setGoalPg_lbl_HeaderDesc;

	@iOSXCUITFindBy(accessibility = "wrap_textInputGoalDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_textInputGoalDrawer']")
	private MobileElement setGoalPg_txt_setGoal;

	@iOSXCUITFindBy(accessibility = "wrap_textInputGoalDrawer")
	@AndroidFindBy(xpath = "(//*[@resource-id='wrap_textInputGoalDrawer']/following::android.widget.TextView)[1]")
	private MobileElement setGoalPg_lbl_metric;

	@iOSXCUITFindBy(accessibility = "btnSaveGoal")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSaveGoal']")
	private MobileElement setGoalPg_btn_SetGoal;

	@iOSXCUITFindBy(accessibility = "btnRemoveGoal")
	@AndroidFindBy(xpath = "//*[@resource-id='txtRemoveGoal']")
	private MobileElement setGoalPg_btn_RemoveGoal;

	@iOSXCUITFindBy(accessibility = "Error Message Please enter a whole number between 1 and 999.")
	@AndroidFindBy(xpath = "(//*[@resource-id='wrap_textInputGoalDrawer']/following::android.widget.TextView)[1]")
	private MobileElement setGoalPg_lbl_WrongMetricError;

	@iOSXCUITFindBy(accessibility = "Error Message Please enter a whole number between 1 and 365")
	@AndroidFindBy(xpath = "(//*[@resource-id='wrap_textInputGoalDrawer']/following::android.widget.TextView)[1]")
	private MobileElement setstreakGoalPg_lbl_WrongMetricError;

	@iOSXCUITFindBy(accessibility = "Please enter a whole number between 1 and 9999.")
	@AndroidFindBy(xpath = "(//*[@resource-id='wrap_textInputGoalDrawer']/following::android.widget.TextView)[1]")
	private MobileElement setyearlyGoalPg_lbl_WrongMetricError;

	@iOSXCUITFindBy(accessibility = "Successpop")
	@AndroidFindBy(id = "Successpop")
	private MobileElement setGoalPg_pop_success;

	@iOSXCUITFindBy(accessibility = "txtBadgeHeaderText")
	@AndroidFindBy(xpath = "//*[@text='BADGES']")
	private MobileElement badgesPg_lbl_header;

	@iOSXCUITFindBy(accessibility = "badge_image")
	@AndroidFindBy(xpath = "//*[@resource-id='badge_image']")
	private List<MobileElement> badgesPg_icon_badges;

	@iOSXCUITFindBy(accessibility = "badgesName")
	@AndroidFindBy(id = "badgesName")
	private List<MobileElement> badgesPg_lbl_badgesName;

	public MobileElement getSetstreakGoalPg_lbl_WrongMetricError() {
		return setstreakGoalPg_lbl_WrongMetricError;
	}

	public MobileElement getSetyearlyGoalPg_lbl_WrongMetricError() {
		return setyearlyGoalPg_lbl_WrongMetricError;
	}

	public MobileElement getBadgesPg_lbl_header() {
		return badgesPg_lbl_header;
	}

	public List<MobileElement> getBadgesPg_icon_badges() {
		return badgesPg_icon_badges;
	}

	public List<MobileElement> getBadgesPg_lbl_badgesName() {
		return badgesPg_lbl_badgesName;
	}

	public MobileElement getHomePg_btn_myLibFooter() {
		return homePg_btn_myLibFooter;
	}

	public MobileElement getHomePg_btn_myShelfFooter() {
		return homePg_btn_myShelfFooter;
	}

	public MobileElement getMyShelfPg_lbl_GoalsHeader() {
		return myShelfPg_lbl_GoalsHeader;
	}

	public MobileElement getMyShelfPg_btn_GoalsCollapse() {
		return myShelfPg_btn_GoalsCollapse;
	}

	public MobileElement getMyShelfPg_btn_AvgReadInsight() {
		return myShelfPg_btn_AvgReadInsight;
	}

	public List<MobileElement> getmyShelfPg_lbl_insightMetric() {
		return myShelfPg_lbl_insightMetric;
	}

	public List<MobileElement> getMyShelfPg_lbl_GoalTrack() {
		return myShelfPg_lbl_GoalTrack;
	}

	public MobileElement getMyShelfPg_lbl_GoalTrackNum() {
		return myShelfPg_lbl_GoalTrackNum;
	}

	public List<MobileElement> getMyShelfPg_icon_Goal() {
		return myShelfPg_icon_Goal;
	}

	public MobileElement getSetGoalPg_lbl_Header() {
		return setGoalPg_lbl_Header;
	}

	public MobileElement getSetGoalPg_lbl_HeaderDesc() {
		return setGoalPg_lbl_HeaderDesc;
	}

	public MobileElement getSetGoalPg_txt_setGoal() {
		return setGoalPg_txt_setGoal;
	}

	public MobileElement getSetGoalPg_lbl_metric() {
		return setGoalPg_lbl_metric;
	}

	public MobileElement getSetGoalPg_btn_SetGoal() {
		return setGoalPg_btn_SetGoal;
	}

	public MobileElement getSetGoalPg_btn_RemoveGoal() {
		return setGoalPg_btn_RemoveGoal;
	}

	public MobileElement getSetGoalPg_lbl_WrongMetricError() {
		return setGoalPg_lbl_WrongMetricError;
	}

	public MobileElement getSetGoalPg_pop_success() {
		return setGoalPg_pop_success;
	}

	/******************** Action methods *************************/

	public void clickOnMyshelfFooter() {
		if (isElementPresent(homePg_btn_myShelfFooter)) {
			ClickOnMobileElement(homePg_btn_myShelfFooter);
		}
		if (isElementPresent(homePg_btn_myShelfFooter1)) {
			ClickOnMobileElement(homePg_btn_myShelfFooter1);
		}
		if (isElementPresent(homePg_old_myShelfFooter)) {
			ClickOnMobileElement(homePg_old_myShelfFooter);
		}
	}

	public void clickOnInsight() {
		if (isElementPresent(myShelfPg_btn_AvgReadInsight)) {
			ClickOnMobileElement(myShelfPg_btn_AvgReadInsight);
		}
	}

	public void clickOnReadInsight() {
		WaitForMobileElement(myShelfPg_btn_AvgRead);
			ClickOnMobileElement(myShelfPg_btn_AvgRead);
	}

	public Boolean setGoalsDrawerCheck() {
		boolean drawer = false;
		if (isElementPresent(setGoalPg_lbl_Header)) {
			drawer = true;
			logger.info("User is able to see setGoal page");
		}
		return drawer;
	}

	public void setgoal() throws InvalidFormatException, IOException {
//		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/MobileData.xlsx", "data");
		setGoalPg_txt_setGoal.clear();
		ClickOnMobileElement(setGoalPg_txt_setGoal);
//		SendKeysOnMobileElement(setGoalPg_txt_setGoal, testData.get(0).get("setGoal"));
		SendKeysOnMobileElement(setGoalPg_txt_setGoal, "7");
		ClickOnMobileElement(setGoalPg_btn_SetGoal);
	}

	public void clickOnRemoveGoalBtn() {
		if (isElementPresent(setGoalPg_btn_RemoveGoal)) {
			ClickOnMobileElement(setGoalPg_btn_RemoveGoal);
		}
	}

	public void hideGoalandInsight() {
		if (isElementPresent(myShelfPg_btn_GoalsCollapse)) {
			ClickOnMobileElement(myShelfPg_btn_GoalsCollapse);
		}
	}

	public void removeGoal() {
		if (isElementPresent(setGoalPg_btn_RemoveGoal)) {
			clickOnRemoveGoalBtn();
		} else {
			swipeDown();
			logger.info("Goal is not set yet, exited");
		}
	}
	
	public boolean checkstreak()
	{
		boolean streak =false;
		horizontalSwipe(getMyShelfPg_icon_Goal());
		if(isElementPresent(myShelfPg_btn_currentStreakInsight));
		{
			streak=true;
		}
		return streak;
	}
	public boolean checkyearlyGoal()
	{
		boolean yearlyGoal =true;
		horizontalSwipe(getMyShelfPg_icon_Goal());
		if(isElementPresent(myShelfPg_btn_bookPerYearInsight));
		{
			yearlyGoal=true;
		}
		return yearlyGoal;
	}
	public boolean checkMonthygoal()
	{
		boolean monthlygoal =true;
		horizontalSwipe(getMyShelfPg_icon_Goal());
		if(isElementPresent(myShelfPg_btn_bookperMonthInsight));
		{
			monthlygoal=true;
		}
		return monthlygoal;
	}

	public void clickOnInsight(String insight) {
		switch (insight) {
		case "Average Read":
			waitFor(2000);
			ClickOnMobileElement(myShelfPg_btn_AvgReadInsight);
			break;
		case "Average Listened":
			ClickOnMobileElement(myShelfPg_btn_AvgListenInsight);
			break;
		case "Current Streak":
			waitFor(3000);
			scroll(DriverManager.getDriver(),0.8,0.4,0.2,0.4);
			ClickOnMobileElement(myShelfPg_btn_currentStreakInsight);
			break;
		case "MonthlyGoal":
			horizontalSwipe(getMyShelfPg_icon_Goal());
			if (isElementPresent(myShelfPg_btn_bookperMonthInsight)) {
				ClickOnMobileElement(myShelfPg_btn_bookperMonthInsight);
			}
			break;

		case "YearlyGoal":
			if (isElementPresent(myShelfPg_btn_bookPerYearInsight)) {
				horizontalSwipe(getMyShelfPg_icon_Goal());
				horizontalSwipe(getMyShelfPg_icon_Goal());
				ClickOnMobileElement(myShelfPg_btn_bookPerYearInsight);
				break;
			}
		}
	}

	public void enterWrongMetric() throws Exception {
//		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/MobileData.xlsx", "data");
		if (isElementPresent(setGoalPg_txt_setGoal)) {
			getSetGoalPg_txt_setGoal().clear();
			ClickOnMobileElement(getSetGoalPg_txt_setGoal());
//		SendKeysOnMobileElement(getSetGoalPg_txt_setGoal(), testData.get(0).get("wrongGoalInput"));
			SendKeysOnMobileElement(getSetGoalPg_txt_setGoal(), "1456");
		}
	}

}
