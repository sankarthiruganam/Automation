package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Hold extends CommonActions {

	public Hold(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/************************************
	 * Locators
	 ************************************************/

	@iOSXCUITFindBy(accessibility = "txtRightMenuTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtRightMenuTitle']")
	private MobileElement email_Not_Available;
	
	@iOSXCUITFindBy(accessibility = "primaryButtonTestId")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'primaryButtonTestId')]")
	private MobileElement remove_Hold;
	
	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_btnCheckout')]")
	private MobileElement primary_CTA;
	
	@iOSXCUITFindBy(accessibility = "checkout_button")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'checkout_button')]")
	private MobileElement program_Primary_CTA;
	
	@iOSXCUITFindBy(accessibility = "primaryButton")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'primaryButton')]")
	private MobileElement remove_CTA;
	
	@iOSXCUITFindBy(accessibility = "PROGRAMS")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'PROGRAMS')]")
	private MobileElement clickPrograms;
	
	@iOSXCUITFindBy(accessibility = "myProgram")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'myProgram')]")
	private MobileElement myPrograms;
	
	@iOSXCUITFindBy(accessibility = "openProgram")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'openProgram')]")
	private MobileElement openPrograms;
	
	@iOSXCUITFindBy(accessibility = "activeProgramList0")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'activeProgramList0')]")
	private MobileElement program_Card;
	
	@iOSXCUITFindBy(accessibility = "onGoingProgramList0")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'onGoingProgramList0')]")
	private MobileElement openProgram_Card;
	
	@iOSXCUITFindBy(accessibility = "Other Normals Book")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Other Normals Book')]")
	private MobileElement openProgram_EBook;
	
	@iOSXCUITFindBy(accessibility = "loc_btnWishlist")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_btnWishlist')]")
	private MobileElement secondary_CTA;
	
	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
	private MobileElement select_EBook;

	/************************************************************
	 * Methods
	 **************************/
	

	public MobileElement get_Primary_CTA() {
		return primary_CTA;
	}
	
	public MobileElement get_Program_Primary_CTA() {
		return program_Primary_CTA;
	}
	
	public MobileElement get_Secondary_CTA() {
		return secondary_CTA;
	}
	
	public void select_EBook() {
		ClickOnMobileElement(select_EBook);
	}
	
	public void click_Primary_CTA() {
		if(isElementPresent(primary_CTA))
		{
		ClickOnMobileElement(primary_CTA);
		}else if(isElementPresent(remove_Hold))
		{
			ClickOnMobileElement(remove_Hold);
		}
	}
	
	public void remove_Hold()
	{
		if(isElementPresent(remove_Hold))
		{
			ClickOnMobileElement(remove_Hold);
		}
	}
	
	public void click_Program_Primary_CTA() {
		ClickOnMobileElement(program_Primary_CTA);
	}

	public void remove_Program_Hold_CTA() {
		if(isElementPresent(primary_CTA))
		{
		ClickOnMobileElement(primary_CTA);
		}else if(isElementPresent(remove_Hold))
		{
			ClickOnMobileElement(remove_Hold);
		}
	}
	
	public void clickPrograms() {
		ClickOnMobileElement(clickPrograms);
	}
	
	public void clickMyPrograms() {
		ClickOnMobileElement(myPrograms);
	}
	
	public void clickOpenPrograms() {
		ClickOnMobileElement(openPrograms);
	}
	
	public void clickProgram_Card() {
		ClickOnMobileElement(program_Card);
	}
	
	public void clickOpenProgram_Card() {
		ClickOnMobileElement(openProgram_Card);
	}
	
	public void select_OpenProgram_EBook() {
		ClickOnMobileElement(openProgram_EBook);
	}
}
