package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class MyCheckouts extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(MyCheckouts.class);

	public MyCheckouts(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement myShelf_lbl_checkouts;

	@iOSXCUITFindBy(accessibility = "txtNoDataFound")
	@AndroidFindBy(xpath = "//*[@resource-id='txtNoDataFound']")
	private MobileElement checkout_title_notfound;

	@iOSXCUITFindBy(accessibility = "Filter_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Filter_icon_test_id']")
	private MobileElement checkout_title_sort;
	
	@iOSXCUITFindBy(accessibility = "START_BY_LATEST")
	@AndroidFindBy(xpath = "//*[@resource-id='START_BY_LATEST']")
	private MobileElement latest_added_sort;

	@iOSXCUITFindBy(accessibility = "READ_AS_EBOOK")
	@AndroidFindBy(xpath = "//*[@resource-id='READ_AS_EBOOK']")
	private MobileElement checkout_title_ebook_sort;

	@iOSXCUITFindBy(accessibility = "FILTER_FOR_ALL")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_ALL']")
	private MobileElement checkout_title_all_sort;

	@iOSXCUITFindBy(accessibility = "READ_AS_AUDIO")
	@AndroidFindBy(xpath = "//*[@resource-id='READ_AS_AUDIO']")
	private MobileElement checkout_title_audio_sort;

	@iOSXCUITFindBy(accessibility = "START_BY_LATEST")
	@AndroidFindBy(xpath = "//*[@resource-id='START_BY_LATEST']")
	private MobileElement checkout_title_latest;

	@iOSXCUITFindBy(accessibility = "SORT_BY_RATING")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_DUEDATE']")
	private MobileElement checkout_title_DueDate;

	@iOSXCUITFindBy(accessibility = "SORT_BY_RATING")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_RATING']")
	private MobileElement checkout_title_Ratings;

	@iOSXCUITFindBy(accessibility = "SORT_BY_ATOZ")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_ATOZ']")
	private MobileElement checkout_title_atoz;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mystuffListView\"])")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup")
	private List<MobileElement> checkedout_titles_hdr;
	
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mystuffListView\"])")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']/android.view.ViewGroup/android.view.ViewGroup")
	private List<MobileElement> downloads_titles_hdr;

	@iOSXCUITFindBy(accessibility = "Sort_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Sort_icon_test_id']")
	private MobileElement checkout_Filter;

	@iOSXCUITFindBy(accessibility = "viewGridContainer0")
	@AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
	private MobileElement checkout_gridView;

	@iOSXCUITFindBy(accessibility = "List_Grid_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
	private MobileElement checkout_listView;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeCell[@name=\"Checkouts, 0\"]")
	@AndroidFindBy(xpath = "MyCheckouts")
	private MobileElement mystuff_checkout;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Horizontal scroll bar, 1 page\"]")
	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup']")
	private MobileElement checkout_hide;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"CHECKOUT HISTORYPage\"]")
	@AndroidFindBy(xpath = "//*[@content-desc='CHECKOUT HISTORY heading, ']")
	private MobileElement checkoutsHistory;

	@iOSXCUITFindBy(accessibility = "mystuffListView0")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement mystuff_program;
	
	@iOSXCUITFindBy(accessibility = "SORT_BY_RATING")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_BY_RATING']")
	private MobileElement sort_ratingview;

	public List<MobileElement> getCheckedout_titles_hdr() {
		return checkedout_titles_hdr;
	}
	
	public List<MobileElement> getDownloads_titles_hdr() {
		return downloads_titles_hdr;
	}

	public MobileElement getSort_ratingview() {
		return sort_ratingview;
	}
	
	public MobileElement getCheckout_title_ebook_sort() {
		return checkout_title_ebook_sort;
	}

	public MobileElement getCheckout_title_all_sort() {
		return checkout_title_all_sort;
	}

	public MobileElement getCheckout_title_audio_sort() {
		return checkout_title_audio_sort;
	}

	public MobileElement getCheckout_title_latest() {
		return checkout_title_latest;
	}

	public MobileElement getCheckout_title_DueDate() {
		return checkout_title_DueDate;
	}

	public MobileElement getCheckout_Ratings() {
		return checkout_title_Ratings;
	}

	public MobileElement getCheckout_title_atoz() {
		return checkout_title_atoz;
	}

	public MobileElement getMyShelf_lbl_checkouts() {
		return myShelf_lbl_checkouts;
	}

	public MobileElement getCheckout_title_notfound() {
		return checkout_title_notfound;
	}

	public MobileElement getCheckout_title_sort() {
		return checkout_title_sort;
	}

	public MobileElement getCheckout_Filter() {
		return checkout_Filter;
	}

	public MobileElement getCheckout_gridView() {
		return checkout_gridView;
	}

	public MobileElement getCheckout_listView() {
		return checkout_listView;
	}

	/******************** Action methods *************************/

	public void navigateCheckout() {
		waitFor(5000);
		if(isElementPresent(myShelf_lbl_checkouts)) {
		ClickOnMobileElement(myShelf_lbl_checkouts);
		}
	}

	public void clickSort() {
		if(isElementPresent(checkout_title_sort))
		{
			ClickOnMobileElement(checkout_title_sort);	
		}
		else
		{
			logger.info("Program details Not available");
		}
	}
	
	public void clickLatestAdded() {
		if(isElementPresent(latest_added_sort))
		{
			ClickOnMobileElement(latest_added_sort);	
		}
		else
		{
			logger.info("Program details Not available");
		}
	}

	public void clickcheckout() {
		ClickOnMobileElement(mystuff_checkout);
	}

	public void filter(String options) {
		if (isElementPresent(mystuff_program)) {
			switch (options) {
			case "ebook":
				ClickOnMobileElement(checkout_title_ebook_sort);
				break;
			case "audioBook":
				ClickOnMobileElement(checkout_title_audio_sort);
				break;
			case "all":
				ClickOnMobileElement(checkout_title_all_sort);
				break;
			}
		} else {
			logger.info("program not available");
		}
	}

	public void clickCheckoutView() {
		if (isElementPresent(checkout_gridView)) {
			ClickOnMobileElement(checkout_gridView);
		} else if (isElementPresent(checkout_listView)) {
			ClickOnMobileElement(checkout_listView);
		}
	}

	public void clickcheckoutFilter() {
		if (isElementPresent(checkout_Filter)) {
			ClickOnMobileElement(checkout_Filter);
		}
	}

	public void sort(String options) {

		if (isElementPresent(mystuff_program)) {
			switch (options) {
			case "latest":
				ClickOnMobileElement(checkout_title_latest);
				break;
			case "duedate":
				ClickOnMobileElement(checkout_title_DueDate);
				break;
			case "atoz":
				ClickOnMobileElement(checkout_title_atoz);
				break;
			}
		}else
		{
			logger.info("Program not available");
		}
		
	}
	public void hidepopup() {
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			if (isElementPresent(checkout_title_all_sort)) {
				ClickOnMobileElement(checkout_title_all_sort);
			}if (isElementPresent(checkout_title_latest)) {
				ClickOnMobileElement(checkout_title_latest);
			}
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			if (isElementPresent(checkout_hide)) {
				ClickOnMobileElement(checkout_hide);
			}
		}
	}
	public MobileElement getcheckoutsHistory() {
		return checkoutsHistory;
	}
}
