package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class MyProfile extends CommonActions{

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public MyProfile(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		
	}
	@iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
	@AndroidFindBy(id = "loc_txtLibraryId")
	private MobileElement autoCheckout_checkbox;

	@iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
	@AndroidFindBy(id = "loc_txtLibraryId")
	private MobileElement autoCheckout_btn_save;

	public void autoCheckoutTitles() {
		swipeDown();
	if (isElementPresent(autoCheckout_checkbox)) {
		if (isEnabled(autoCheckout_checkbox)) {
		ClickOnMobileElement(autoCheckout_checkbox);
		ClickOnMobileElement(autoCheckout_btn_save);
	} 
	}else {
		System.out.println("Checkbox not found");
	}
}
}
