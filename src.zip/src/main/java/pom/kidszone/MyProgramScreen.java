package pom.kidszone;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class MyProgramScreen extends CommonActions {

    public MyProgramScreen(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    
    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU']")
    public MobileElement bottom_Menu;
    
    @iOSXCUITFindBy(accessibility = "Reading Program Heading")
    @AndroidFindBy(xpath = "//*[contains(@text,'Reading Program')]")
    public MobileElement programDetails;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement progress_Bar;

    @iOSXCUITFindBy(accessibility = "Checkout_button")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'Checkout_button')])[1]")
    public MobileElement checkout_CTA;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement title_Details;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement progress_Percentage;
    
    @iOSXCUITFindBy(accessibility = "Testing")
    @AndroidFindBy(xpath = "//*[contains(@text,'Testing')]")
    public MobileElement title_Name;
    
    @iOSXCUITFindBy(xpath = "//*[@label='Add a Title']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Add a Title')]")
    public MobileElement add_Title_CTA;
    
    @iOSXCUITFindBy(accessibility = "program_title")
    @AndroidFindBy(xpath = "//*[@resource-id='program_title']")
    public MobileElement program_Title;
    
    @iOSXCUITFindBy(accessibility = "program_title")
    @AndroidFindBy(xpath = "//*[@resource-id='program_title']")
    public MobileElement program_Description;
    
    @iOSXCUITFindBy(accessibility = "START DATE")
    @AndroidFindBy(id = "dummy")
    public MobileElement program_Start_Date;
    
    @iOSXCUITFindBy(accessibility = "END DATE")
    @AndroidFindBy(id = "dummy")
    public MobileElement program_End_Date;
    
    @iOSXCUITFindBy(accessibility = "loc_addOwnTitleAuthor")
    @AndroidFindBy(id = "dummy")
    public MobileElement authors_Name;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'OK, ')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'OK, ')]")
    public MobileElement confirm_OK;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement title_CoverImage;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement eAudioOption;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement videoOption;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'First Read')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'First Read')]")
    public MobileElement firstReadBadge;
    
    @iOSXCUITFindBy(accessibility = "PROGRAMS")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'PROGRAMS')]")
    public MobileElement bottom_Programs;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement profile_from_Menu;
    
    @iOSXCUITFindBy(accessibility = "myProgram")
    @AndroidFindBy(xpath = "//*[@resource-id='myProgram']")
    public MobileElement clickMyPrograms;
    
    @iOSXCUITFindBy(accessibility = "openProgram")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'openProgram')]")
    public MobileElement clickOpenPrograms;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'MilestoneProg')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'MilestoneProg')]")
    public MobileElement clickMileStoneProgram;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'upcomingprogram')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'upcomingprogram')]")
    public MobileElement clickMileStoneUpcomingProgram;
    @iOSXCUITFindBy(accessibility = "join_program")
    @AndroidFindBy(xpath = "//*[@resource-id = 'join_program']")
    public MobileElement joinProgram;
    
    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id = 'btnBackIcon']")
    public MobileElement back_Btn;
    
    @iOSXCUITFindBy(accessibility = "Joined,Banner")
    @AndroidFindBy(xpath = "//*[contains(@text,'Joined')]")
    public MobileElement joined_Title;
    
    @iOSXCUITFindBy(accessibility = "reading_list_title")
    @AndroidFindBy(xpath = "//*[contains(@text,'Reading Program')]")
    public MobileElement milestone_Program_Details_Screen;
    
    @iOSXCUITFindBy(accessibility = "join_program")
    @AndroidFindBy(xpath = "//*[@resource-id='join_program']")
    public MobileElement view_LeaveProgram_CTA;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement first_Title;
    
    @iOSXCUITFindBy(accessibility = "join_program")
    @AndroidFindBy(xpath = "//*[@resource-id='join_program']")
    public MobileElement milestone_Join_Program_CTA;
    
    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id, 'EBT_Title')])[1]")
    public MobileElement view_Book_Reading_List;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
    public MobileElement audioBookTitle;

    @iOSXCUITFindBy(accessibility = "Checkout_button")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'Checkout_button')])[1]")
    public MobileElement checkout_Button;

    @iOSXCUITFindBy(accessibility = "bookTitle")
    @AndroidFindBy(xpath = "dummy")
    public MobileElement videoTitle;

    @iOSXCUITFindBy(accessibility = "bookTitle")
    @AndroidFindBy(xpath = "dummy")
    public MobileElement vBookTitle;
    
    @iOSXCUITFindBy(accessibility = "program_title")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'program_title')]")
    public MobileElement milestone_program_title;
    
    @iOSXCUITFindBy(accessibility = "program_desc')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'program_desc')]")
    public MobileElement milestone_program_description;
    
    @iOSXCUITFindBy(accessibility = "start_date")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'start_date')]")
    public MobileElement milestone_start_date;
    
    @iOSXCUITFindBy(accessibility = "JOIN DATE")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'JOIN DATE')]")
    public MobileElement milestone_join_date;
    
    @iOSXCUITFindBy(accessibility = "end_date")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'end_date')]")
    public MobileElement milestone_end_date;

    @iOSXCUITFindBy(accessibility = "Suggested Titles Heading")
    @AndroidFindBy(xpath = "//*[contains(@text,'Suggested Titles')]")
    public MobileElement suggested_Titles_Reading_List;
    @iOSXCUITFindBy(accessibility = "GOAL")
    @AndroidFindBy(id = "dummy")
    public MobileElement edit_Reading_List;


    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label=\"edit\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='reding_list_milestone']")
    public MobileElement milestone_edit_icon;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement milestone_All_Titles_Sorted;

    @iOSXCUITFindBy(accessibility = "deleteButton")
    @AndroidFindBy(xpath = "//*[@resource-id='deleteButton']")
    public MobileElement milestone_Program_CancelCTA;

    @iOSXCUITFindBy(accessibility = "saveButton")
    @AndroidFindBy(xpath = "//*[@resource-id='saveButton']")
    public MobileElement milestone_Program_RemoveCTA;

    @iOSXCUITFindBy(accessibility = "deleteNo")
    @AndroidFindBy(xpath = "//*[@resource-id='deleteNo']")
    public MobileElement cancelCTA;

    @iOSXCUITFindBy(accessibility = "deleteYes")
    @AndroidFindBy(xpath = "//*[@resource-id='deleteYes']")
    public MobileElement okCTA;

    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
    public MobileElement alertMessagePopup;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement milestone_All_Titles_Filtered;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement All_FilterOption;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement eBook_FilterOption;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement eAudio_FilterOption;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement externalTitle_FilterOption;

    @iOSXCUITFindBy(accessibility = "loc_TitleCheckbox_Programdetails")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_TitleCheckbox_Programdetails']")
    public MobileElement milestone_Program_TitlesCheckbox;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement title_Not_Found;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement cancel_CTA_Popup;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement non_Edit_Mode;
    
    @iOSXCUITFindBy(accessibility = "Image_Cover")
    @AndroidFindBy(xpath = "//*[@resource-id='Image_Cover']")
    public List<MobileElement> view_Titles_List;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement view_Cancel_CTA;

    @iOSXCUITFindBy(xpath = "(//*[@label=\"Checkout\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='Checkout_button'])[1]")
    public MobileElement primaryCTA;

    @iOSXCUITFindBy(accessibility = "markas_Notdone_button")
    @AndroidFindBy(xpath = "//*[@resource-id='markas_Notdone_button']")
    public MobileElement markAsNotDoneCTA;

    @iOSXCUITFindBy(accessibility = "markas_Done_button")
    @AndroidFindBy(xpath = "//*[@text='Mark as Done']")
    public MobileElement markAsDoneCTA;

    @iOSXCUITFindBy(accessibility = "100%")
    @AndroidFindBy(xpath = "//*[@text='100%']")
    public MobileElement progressBar;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement view_Save_CTA;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement cancel_Popup;
    
    @iOSXCUITFindBy(accessibility = "sortButton")
    @AndroidFindBy(xpath = "//*[@resource-id='sortButton']")
    public MobileElement view_Sort_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement rating_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement AtoZ_Option;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement ZtoA_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement due_Date;
    
    @iOSXCUITFindBy(accessibility = "filterButton")
    @AndroidFindBy(xpath = "//*[@resource-id='filterButton']")
    public MobileElement view_Filter_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement view_Delete_Option;
    
    @iOSXCUITFindBy(accessibility = "GOAL")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'GOAL')]")
    public MobileElement milestone_title_goal;
    
    @iOSXCUITFindBy(accessibility = "SeeAll_Button")
    @AndroidFindBy(xpath = "//*[@resource-id='SeeAll_Button']")
    public MobileElement milestone_Program_SeeAll;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement selectCheckout;
    
    @iOSXCUITFindBy(xpath = "//*[@label='Add a Title']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Add a Title')]")
    public MobileElement edit_Reading_List_CTA;
    
    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
    public MobileElement individual_Title;
    
    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
    public MobileElement delete_Option;
    
    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
    public MobileElement save_CTA;
    
    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
    public MobileElement cancel_CTA;
    
    @iOSXCUITFindBy(accessibility = "Dummy")
    @AndroidFindBy(xpath = "Dummy")
    public MobileElement clickDelete_Title;
    
    @iOSXCUITFindBy(accessibility = "Started,Banner")
    @AndroidFindBy(xpath = "//*[contains(@text,'Started')]")
    public MobileElement started_Title;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement completed_Title;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement notCompleted_Title;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement myProgram;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement done_Status_Title;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement confirmation_Message;
    
    @iOSXCUITFindBy(accessibility = "join_program")
    @AndroidFindBy(xpath = "//*[@resource-id='join_program']")
    public MobileElement leave_Program_CTA;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement titles_Order;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement titles_eContent;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement titles_External;
    
    @iOSXCUITFindBy(accessibility = "loc_advance_search_close_btn")
    @AndroidFindBy(xpath = "//*[@resource-id=\"loc_advance_search_close_btn\"]")
    public MobileElement close_Icon;

    @iOSXCUITFindBy(xpath = "//*[@label='Add a Title']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Add a Title,')]")
    public MobileElement title_Closed_Program;
    
    @iOSXCUITFindBy(accessibility = "searchYourLibrary")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'searchYourLibrary')]")
    public MobileElement your_Library;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_search_advance_search_refiner_icon']")
    public MobileElement filter_Icon;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement addedByYou_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement ebook_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement audio_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement vbook_Option;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement video_Option;

    @iOSXCUITFindBy(xpath = "//*[@label='Add a Title']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Add a Title')]")
    public MobileElement add_A_Title_Text;
      
    @iOSXCUITFindBy(accessibility = "addOwnTitle")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'addOwnTitle')]")
    public MobileElement yourOwn_TitleOption;
    
    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(id = "dummy")
    public MobileElement own_Title;
    
    @iOSXCUITFindBy(accessibility = "addOwnTitleType")
    @AndroidFindBy(id = "dummy")
    public MobileElement drop_DownOption;
    
    @iOSXCUITFindBy(accessibility = "loc_addOwnTitleName")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_addOwnTitleName')]")
    public MobileElement enter_Title_Name;
    
    @iOSXCUITFindBy(accessibility = "loc_addOwnTitleAuthor")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_addOwnTitleAuthor')]")
    public MobileElement enter_Author_Name;

    @iOSXCUITFindBy(accessibility = "addOwnTitleType")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'addOwnTitleType')]")
    public MobileElement title_Type;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public List<MobileElement> title_Type_Selection;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement enterTitle_Name;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement enterAuthor_Name;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'1  of 1 Titles')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Titles,')]")
    public MobileElement done_Status_Count;
    
    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "//*[@content-desc='My Shelf, ']")
    public MobileElement myShelf_from_Menu;
    
    @iOSXCUITFindBy(accessibility = "openProgram")
    @AndroidFindBy(xpath = "//*[@resource-id='openProgram']")
    public MobileElement openPrograms_from_Menu_Programs;
    
    @iOSXCUITFindBy(accessibility = "myProgram")
    @AndroidFindBy(xpath = "//*[@resource-id='My Programs']")
    public MobileElement myPrograms_from_Menu_Programs;
    
    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Completed_Badge')])[1]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Completed_Badge')]")
    public MobileElement closedPrograms;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement completedPrograms;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'Completed_Badge')])[1]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Completed_Badge')]")
    public MobileElement program_Completed;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement titles_to_the_Programs;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'MilestoneProg')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'MilestoneProg')]")
    public MobileElement ongoingPrograms_from_OpenPrograms;
    
    @iOSXCUITFindBy(xpath = "(//*[@name='add_cta'])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@text,'Add')])[2]")
    public MobileElement eBookSearchResult;

    @iOSXCUITFindBy(accessibility = "add_cta")
    @AndroidFindBy(xpath = "//*[@resource-id='add_cta']")
    public MobileElement add_CTA;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'eBook')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'eBook')]")
    public MobileElement eBookSearchResultHeading;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'eAudio')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'eAudio')]")
    public MobileElement eAudioSearchResultHeading;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement eAudioSearchResult;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement videoSearchResult;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement vBookSearchResult;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement eBookSelectionInAdvanceSearch;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement milestone_Program_Title;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'add_cta')])[1]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Add')]")
    public MobileElement ereading_Title_To_Program;

    @iOSXCUITFindBy(accessibility = "secondary menu")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'secondary menu')]")
    public MobileElement ereading_Title_Remove;
    @iOSXCUITFindBy(accessibility = "activeProgramTitle")
    @AndroidFindBy(xpath="//*[@resource-id = 'activeProgramTitle']")
    public MobileElement active_Programs;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement closed_Programs;
    
    @iOSXCUITFindBy(accessibility = "START DATE")
    @AndroidFindBy(xpath = "//*[contains(@text,'START DATE')]")
    public MobileElement label_Start_Date;
    
    @iOSXCUITFindBy(accessibility = "END DATE")
    @AndroidFindBy(xpath = "//*[contains(@text,'END DATE')]")
    public MobileElement label_End_Date;
    
    @iOSXCUITFindBy(accessibility = "program_title")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'program_title')]")
    public MobileElement label_Milestone_Program_Title;
    
    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(id = "dummy")
    public MobileElement milestone_Program;

    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
    public MobileElement leave_Program_Alert;
    
    @iOSXCUITFindBy(accessibility = "ok_button")
    @AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
    public MobileElement clickMilestoneJoinOk;

    @iOSXCUITFindBy(accessibility = "deleteYes")
    @AndroidFindBy(xpath = "//*[@resource-id='deleteYes']")
    public MobileElement click_Remove_Ok;

    @iOSXCUITFindBy(accessibility = "ok_button")
    @AndroidFindBy(xpath = "//*[@text='OK']")
    public MobileElement click_Success_Ok;

    @iOSXCUITFindBy(accessibility = "PROGRAM_REMOVE")
    @AndroidFindBy(xpath = "//*[@resource-id='PROGRAM_REMOVE']")
    public MobileElement click_Remove_Program;

    @iOSXCUITFindBy(accessibility = "cancel_button")
    @AndroidFindBy(id = "dummy")
    public MobileElement clickMilestoneJoinCancel;
    
    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
    public MobileElement joinMilestoneAlertMsg;
    
    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(id = "dummy")
    public MobileElement joinConfirmationPopup;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Yes')]")
    @AndroidFindBy(xpath = "//*[@resource-id='update_profile_modal']")
    public MobileElement joinConfirmationYesBtn;
    
    @iOSXCUITFindBy(accessibility = "cancel_button")
    @AndroidFindBy(id = "dummy")
    public MobileElement joinConfirmationNoBtn;
    
    @iOSXCUITFindBy(accessibility = "activeProgramList0")
    @AndroidFindBy(xpath = "//*[@resource-id='activeProgramList0']")
    public MobileElement programSelectMyPrograms;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Automation_upcoming')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'AUTOMATION_UPCOMING')]")
    public MobileElement upcomingProgram;
    
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Automation_upcomingProgram')]")
    @AndroidFindBy(id = "dummy")
    public MobileElement addATitle;

    @iOSXCUITFindBy(accessibility = "eBook")
    @AndroidFindBy(xpath = "//*[contains(@text,'eBook')]")
    public MobileElement titleTypeOptionEbook;

    @iOSXCUITFindBy(accessibility = "eAudio/Audiobook")
    @AndroidFindBy(xpath = "//*[contains(@text,'eAudio/Audiobook')]")
    public MobileElement titleTypeOptionEaudio;

    @iOSXCUITFindBy(accessibility = "addOwnTitleAddButton")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'addOwnTitleAddButton')]")
    public MobileElement addButtonOwnTitle;

    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'ALERT_TITLE')]")
    public MobileElement addTitleSuccessPopup;

    @iOSXCUITFindBy(xpath = "//*[@name='ok_button']")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'ok_button')]")
    public MobileElement addTitleSuccessPopupOk;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'secondary menu')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'secondary menu,')]")
    public MobileElement titleSettingDots;

    @iOSXCUITFindBy(accessibility = "PROGRAM_REMOVE")
    @AndroidFindBy(xpath = "//*[contains(@text,'Remove')]")
    public MobileElement removetitle;

    @iOSXCUITFindBy(accessibility = "deleteYes")
    @AndroidFindBy(xpath = "//*[contains(@text,'OK')]")
    public MobileElement titleRemovePopupOk;

    @iOSXCUITFindBy(xpath = "//*[@label='Advanced Search Options Heading']")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_advance_search_title_text')]")
    public MobileElement advanceSearchHeading;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'eAudio')])[1]")
    public MobileElement eAudio_radio;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Completed')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Completed')]")
    public MobileElement programCompleted;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Automation_up')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Automation_up')]")
    public MobileElement joinUpcomingProgram;

    @iOSXCUITFindBy(accessibility = "btnInsightAndBadgesDisplay")
    @AndroidFindBy(xpath = "//*[@resource-id=\"checkbox_three\"]")
    public MobileElement insightsBadgesCheckboxEnabled;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Notifications bell')]")
    @AndroidFindBy(xpath = "//*[@resource-id='program-navBar']")
    public MobileElement notificationBellIcon;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Automation_upcoming')]")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'Automation_upcoming')])[2]")
    public MobileElement notificationProgramJoined;

    @iOSXCUITFindBy(xpath = "//*[@label='Edit Button']")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnEdit']")
    public MobileElement notificationEditBtn;

    @iOSXCUITFindBy(accessibility = "PROGRAN_BADGES_LIST_ITEM_DELETE_BUTTON")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Delete')]")
    public MobileElement notificationDeleteBtn;

    @iOSXCUITFindBy(accessibility = "loc_btnDelete")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnDelete']")
    public MobileElement notificationDeleteYes;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'add_cta')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@text,'Add')])[1]")
    public MobileElement suggestedTitleAddBtn;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'New Title Added')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'New Title Added')])[1]")
    public MobileElement titleAddedNotification;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Title Removed')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Title Removed')]")
    public MobileElement titleRemoveNotification;

    @iOSXCUITFindBy(accessibility = "close_icon")
    @AndroidFindBy(xpath = "//*[@content-desc=', ']")
    public MobileElement profileDetailCloseBtn;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Confirmation')]")
    @AndroidFindBy(xpath = "//*[@content-desc='Confirmation, ']")
    public MobileElement confirmationPopup;
    
  //-------------------------------Methods--------------------------------------------//
    
    public MobileElement checkProgramDetails() {
		return programDetails;
	}
    
    public MobileElement checkProgress_Bar() {
		return progress_Bar;
	}
    
    public MobileElement viewCheckout_CTA() {
		return checkout_CTA;
	}
    
    public MobileElement viewTitle_Details() {
		return title_Details;
	}
    
    public MobileElement viewProgress_Percentage() {
		return progress_Percentage;
	}
    
    public MobileElement viewTitle_Name() {
		return title_Name;
	}
    
    public MobileElement view_Authors_Name() {
		return authors_Name;
	}
    


    public MobileElement view_Title_CoverImage() {
		return title_CoverImage;
	}
    
    public MobileElement view_Title_Name() {
		return title_Name;
	}
    
    public MobileElement view_Add_Title_CTA() {
		return add_Title_CTA;
	}
    
    public MobileElement viewProgram_Title() {
		return program_Title;
	}
    
    public MobileElement viewProgram_Description() {
		return program_Description;
	}
    
    public MobileElement viewProgram_Start_Date() {
		return program_Start_Date;
	}
    
    public MobileElement viewProgram_End_Date() {
		return program_End_Date;
	}
    
    public void click_Add_Title_CTA() {
        ClickOnMobileElement(add_Title_CTA);
    }
    
    public MobileElement view_eAudioOption() {
		return eAudioOption;
	}
    
    public MobileElement view_VideoOption() {
		return videoOption;
	}
    
    public MobileElement firstReadBadge() {
		return firstReadBadge;
	}
    
    public void clickBottom_Menu() {
        ClickOnMobileElement(bottom_Menu);        
    }
    
    public void clickOpenPrograms_from_Menu_Programs() {
        ClickOnMobileElement(openPrograms_from_Menu_Programs);        
    }
    
    public void clickMyPrograms_from_Menu_Programs() {
        ClickOnMobileElement(myPrograms_from_Menu_Programs);   
    }

    public MobileElement getConfirm_OK() {
        return confirm_OK;
    }

    public void clickClosedPrograms() {
        ClickOnMobileElement(closedPrograms);   
    }
    
    public void selectCompletedPrograms() {
        ClickOnMobileElement(completedPrograms);   
    }
    
    public void view_Program_Completed() {
        for (int i = 0; i < 6; i++) {
            if (isElementPresent(program_Completed)) {
                break;
            } else {
                swipeDown();
            }
            ClickOnMobileElement(program_Completed);
        }
    }
    
    public void add_Titles_to_the_Programs() {
        ClickOnMobileElement(titles_to_the_Programs);   
    }
    
    public void clickCheckout_CTA() {
        ClickOnMobileElement(checkout_CTA);        
    }

    public void clickBottom_Programs() {
        ClickOnMobileElement(bottom_Programs);        
    }

    public void selectMilestone_Program_Title() {
        ClickOnMobileElement(milestone_Program_Title);
    }
    
    public void clickProfile_from_Menu() {
        ClickOnMobileElement(profile_from_Menu);       
    }
    
    public void addTitle_Closed_Program() {
        ClickOnMobileElement(title_Closed_Program);       
    }

    public void addTitle() {
        for(int i =0;i<3;i++) {
            if (isElementPresent(title_Closed_Program)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(title_Closed_Program);
    }
    
    public void click_search_Your_Library() {
        ClickOnMobileElement(your_Library);       
    }
    
    public void clickFilter_Icon() {
        ClickOnMobileElement(filter_Icon);       
    }
        
    public void clickAddedByYou_Option() {
        ClickOnMobileElement(addedByYou_Option);       
    }
    
    public void clickEbook_Option() {
        ClickOnMobileElement(ebook_Option);       
    }
    
    public void clickAudio_Option() {
        ClickOnMobileElement(audio_Option);       
    }
    
    public void clickVbook_Option() {
        ClickOnMobileElement(vbook_Option);       
    }

    public MobileElement getCheckout_CTA() {
        return checkout_CTA;
    }

    public void clickVideo_Option() {
        ClickOnMobileElement(video_Option);       
    }
    
    public MobileElement search_Your_Library() {
        return your_Library;
    }

    public MobileElement add_A_Title_Popup_Text() {
        return add_A_Title_Text;
    }
    
    public void click_Add_YourOwn_TitleOption() {
        ClickOnMobileElement(yourOwn_TitleOption);       
    }
    
    public void click_add_Own_Title() {
        ClickOnMobileElement(own_Title);       
    }

    public MobileElement add_Own_Title() {
        return yourOwn_TitleOption;
    }
    
    public void select_Drop_DownOption() {
        ClickOnMobileElement(drop_DownOption);       
    }
    
    public void add_Title_Values() {
        ClickOnMobileElement(enter_Title_Name);  
        SendKeysOnMobileElement(enter_Title_Name, "ss1");
        
        ClickOnMobileElement(enter_Author_Name);  
        SendKeysOnMobileElement(enter_Author_Name, "ss1");
    }
    
    public void selectTitle_Type() {
    	System.out.println("size : " + title_Type_Selection.size());
		ClickOnMobileElement(title_Type_Selection.get(0));
    }
    
    public void enter_Values_Mandatory(String userName, String password) {
        ClickOnMobileElement(enterTitle_Name);
        SendKeysOnMobileElement(enterTitle_Name, userName);
        ClickOnMobileElement(enterAuthor_Name);
        SendKeysOnMobileElement(enterAuthor_Name, password);
        ClickOnMobileElement(drop_DownOption);
    }
    
    public void deleteTitle_Closed_Program() {
        ClickOnMobileElement(title_Closed_Program);       
    }
    
    public void viewDone_Status_Count() {
        ClickOnMobileElement(done_Status_Count);       
    }
    
    public void clickMyShelf_from_Menu() {
        ClickOnMobileElement(myShelf_from_Menu);       
    }
    
    public void clickMyPrograms() {
        ClickOnMobileElement(clickMyPrograms);
    }
    
    public void clickOpenPrograms() {
        ClickOnMobileElement(clickOpenPrograms);
    }
    
    public void clickMileStoneProgram() {
    	 for(int i= 0;i<10;i++) {
             if(isElementPresent(clickMileStoneProgram)) {
                 break;
             }
             else {
                 swipeDown();
             }
         }
        ClickOnMobileElement(clickMileStoneProgram);
    }

    public void clickMileStoneUpcomingProgram() {
        for(int i= 0;i<10;i++) {
            if(isElementPresent(clickMileStoneUpcomingProgram)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(clickMileStoneUpcomingProgram);
    }

    public void selectOngoingPrograms_from_OpenPrograms() {
        for(int i= 0;i<10;i++) {
            if(isElementPresent(ongoingPrograms_from_OpenPrograms)) {
                break;
            }
            else {
                swipeDown();
                swipeDown();
            }
        }
        ClickOnMobileElement(ongoingPrograms_from_OpenPrograms);
    }

    public void clickSort_Option() {
        ClickOnMobileElement(view_Sort_Option);
    }
    
    public void clickRating_Option() {
        ClickOnMobileElement(rating_Option);
    }
    
    public void clickAtoZ_Option() {
        ClickOnMobileElement(AtoZ_Option);
    }

    public MobileElement verifyZtoA_Option() {
        return ZtoA_Option;
    }

    public MobileElement verifyAtoZ_Option() {
       return AtoZ_Option;
    }
    
    public void clickDue_Date() {
        ClickOnMobileElement(due_Date);
    }
    
    public void clickMilestone_Program_SeeAll() {
        ClickOnMobileElement(milestone_Program_SeeAll);
    }
    
    public void selectCheckout() {
   	 for(int i= 0;i<4;i ++) {
            if(isElementPresent(selectCheckout)) {
                break;
            }
            else {
                swipeDown();
            }
        }
       ClickOnMobileElement(selectCheckout);
    }
    
    public void clickJoinProgram() {
        ClickOnMobileElement(joinProgram);
    }
    
    public void clickOkButton() {
        ClickOnMobileElement(clickMilestoneJoinOk);
    }

    public void click_Remove_Ok() {
        ClickOnMobileElement(click_Remove_Ok);
    }

    public void click_Remove_Program() {
        ClickOnMobileElement(click_Remove_Program);
    }

    public void click_Success_Ok() {
        ClickOnMobileElement(click_Success_Ok);
    }

    public void clickLeave_Program() {
        ClickOnMobileElement(leave_Program_CTA);
    }
    
    public void clickBack_Btn() {
        ClickOnMobileElement(back_Btn);
    }
    
    public MobileElement joined_Title() {
		return joined_Title;
	}
    
    public MobileElement milestone_Program_Details_Screen() {
		return milestone_Program_Details_Screen;
	}
    
    public MobileElement view_LeaveProgram_CTA() {
		return view_LeaveProgram_CTA;
	}
    
    public MobileElement view_First_Title() {
		return first_Title;
	}
    
    public MobileElement milestone_Join_Program_CTA() {
		return milestone_Join_Program_CTA;
	}
    
    public MobileElement view_Book_Reading_List() {
		return view_Book_Reading_List;
	}
    
    public MobileElement milestone_program_title() {
		return milestone_program_title;
	}
    
    public MobileElement milestone_program_description() {
		return milestone_program_description;
	}
    
    public MobileElement milestone_start_date() {
		return milestone_start_date;
	}
    
    public MobileElement milestone_join_date() {
		return milestone_join_date;
	}
    
    public MobileElement milestone_end_date() {
		return milestone_end_date;
	}

    public MobileElement view_Suggested_Titles_Reading_List() {
        for(int i= 0;i<9;i ++) {
            if(isElementPresent(suggested_Titles_Reading_List)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        return (suggested_Titles_Reading_List);
    }

    public MobileElement edit_Reading_List() {
		return edit_Reading_List;
	}

    public MobileElement milestone_editIcon() {
        return milestone_edit_icon;
    }

    public void click_milestone_editIcon() {
        ClickOnMobileElement(milestone_edit_icon);
    }
    public MobileElement milestone_All_Titles_Sorted() {
		return milestone_All_Titles_Sorted;
	}

    public MobileElement verify_milestone_Program_CancelCTA() {
        return milestone_Program_CancelCTA;
    }

    public void click_milestone_Program_CancelCTA() {
        ClickOnMobileElement(milestone_Program_CancelCTA);
    }

    public boolean verify_milestone_Program_RemoveCTA_Disabled() {
        boolean RemoveCTAEnabled = false;
        if(milestone_Program_RemoveCTA.getAttribute("enabled").equalsIgnoreCase("false")) {
            return RemoveCTAEnabled= true;
        }
        return RemoveCTAEnabled;
    }

    public void click_milestone_Program_RemoveCTA() {
        ClickOnMobileElement(milestone_Program_RemoveCTA);
    }

    public void click_CancelCTA() {
        ClickOnMobileElement(milestone_Program_RemoveCTA);
    }

    public String verifyAlertMessagePopup() {
        return alertMessagePopup.getText();
    }

    public boolean verify_milestone_Program_RemoveCTA_Enabled() {
        boolean RemoveCTAEnabled = false;
        if(milestone_Program_RemoveCTA.getAttribute("enabled").equalsIgnoreCase("true")) {
            return RemoveCTAEnabled= true;
        }
        return RemoveCTAEnabled;
    }

    public MobileElement verify_All_FilterOption() {
        return All_FilterOption;
    }

    public MobileElement verify_eBook_FilterOption() {
        return eBook_FilterOption;
    }

    public MobileElement verify_eAudio_FilterOption() {
        return eAudio_FilterOption;
    }

    public MobileElement verify_externalTitle_FilterOption() {
        return externalTitle_FilterOption;
    }
    
    public MobileElement milestone_All_Titles_Filtered() {
		return milestone_All_Titles_Filtered;
	}

    public MobileElement verify_milestone_Program_TitlesCheckbox() {
        return milestone_Program_TitlesCheckbox;
    }

    public void click_milestone_Program_TitlesCheckbox() {
         ClickOnMobileElement(milestone_Program_TitlesCheckbox);
    }

    public void clickCancelCTA() {
        ClickOnMobileElement(cancelCTA);
    }

    public MobileElement verifyCancelCTA() {
        return cancelCTA;
    }

    public void clickOkCTA() {
        ClickOnMobileElement(okCTA);
    }

    public MobileElement verifyOKCTA() {
        return okCTA;
    }

    public MobileElement title_Not_Found() {
		return title_Not_Found;
	}
    
    public MobileElement cancel_CTA_Popup() {
		return cancel_CTA_Popup;
	}
    
    public MobileElement non_Edit_Mode() {
		return non_Edit_Mode;
	}
    
    public List<MobileElement> view_Titles_List() {
		return view_Titles_List;
	}

    public MobileElement verifyPrimaryCTA() {
        for(int i =0;i<8;i++) {
            if (isElementPresent(primaryCTA)) {
            break;
            }
            else {
                swipeDown();
            }
        }
        return primaryCTA;
    }

    public boolean verifyExternalTitleCTA() {
        boolean externalTitleCTA = false;
        for (int i = 0; i < 4; i++) {
            if (isElementPresent(markAsDoneCTA)) {
                externalTitleCTA = true;
                break;
            } else if (isElementPresent(markAsNotDoneCTA)) {
                externalTitleCTA = true;
                break;
            } else {
                swipeDown();
            }
        }
        return externalTitleCTA;
    }

    public MobileElement verifyMarkAsNotDoneCTA() {
        return markAsNotDoneCTA;
    }

    public MobileElement verifyProgressBar() {
        return progressBar;
    }

    public MobileElement verifyMarkAsDoneCTA() {
        return markAsDoneCTA;
    }

    public MobileElement view_Cancel_CTA() {
		return view_Cancel_CTA;
	}
    
    public MobileElement view_Save_CTA() {
		return view_Save_CTA;
	}
    
    public MobileElement view_Cancel_Popup() {
		return cancel_Popup;
	}
    
    public MobileElement view_Sort_Option() {
		return view_Sort_Option;
	}
    
    public MobileElement view_Filter_Option() {
		return view_Filter_Option;
	}

    public void click_view_Filter_Option() {
        ClickOnMobileElement(view_Filter_Option);
    }

    public MobileElement view_Delete_Option() {
		return view_Delete_Option;
	}
    
    public MobileElement milestone_title_goal() {
		return milestone_title_goal;
	}
    
    public MobileElement viewMilestone_Program_SeeAll() {
		return milestone_Program_SeeAll;
	}
    
    public MobileElement viewEdit_Reading_List_CTA() {
		return edit_Reading_List_CTA;
	}

    public MobileElement viewJoined_Program() {
        return edit_Reading_List_CTA;
    }
    public MobileElement viewAdd_Title_CTA() {
		return add_Title_CTA;
	}
    
    public MobileElement started_Title() {
		return started_Title;
	}
    
    public MobileElement completed_Title() {
		return completed_Title;
	}
    
    public MobileElement notCompleted_Title() {
		return notCompleted_Title;
	}
    
    public MobileElement myProgram() {
		return myProgram;
	}
    
    public MobileElement view_Done_Status_Title() {
		return done_Status_Title;
	}
    
    public MobileElement view_Confirmation_Message() {
		return confirmation_Message;
	}
    
    public MobileElement view_Leave_Program_CTA() {
		return leave_Program_CTA;
	}
    
    public MobileElement view_Titles_Order() {
		return titles_Order;
	}
    
    public MobileElement view_Titles_eContent() {
		return titles_eContent;
	}
    
    public MobileElement view_Titles_External() {
		return titles_External;
	}
    
    public MobileElement verifyClose_Icon() {
		return close_Icon;
	}

    public boolean verifyTitleSearchResultsScreen() {
        boolean title = false;
        if(isElementPresent(eBookSearchResultHeading)) {
            title = true;
        }
        else if(isElementPresent(eAudioSearchResultHeading)) {
            title = true;
        }
        else if(isElementPresent(videoSearchResult)) {
            title = true;
        }
        else if(isElementPresent(vBookSearchResult)) {
            title = true;
        }
        return title;
    }

    public void addTitleFromSearchResultsScreen() {
        if(isElementPresent(add_CTA)) {
            ClickOnMobileElement(add_CTA);
        }

    }

    public void selecteBookInAdvanceSearch() {
        for(int i =0;i<5;i++) {
            if (isElementPresent(eBookSelectionInAdvanceSearch)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(eBookSelectionInAdvanceSearch);
    }
    
    public void navigate_To_Program_Details() {
        for(int i =0;i<10;i++) {
            if (isElementPresent(ongoingPrograms_from_OpenPrograms)) {
                break;
            }
            else {
                swipeDown();
            }
        }
        ClickOnMobileElement(ongoingPrograms_from_OpenPrograms);
    }

    public void add_ereading_Title_To_Program() {
        for(int i =0;i<5;i++) {
            if (isElementPresent(ereading_Title_To_Program)) {
                break;
            }
            else {
                swipeDown();
                swipeDown();
            }

        }
        ClickOnMobileElement(ereading_Title_To_Program);
    }

    public void ereading_Title_Remove() {
        for(int i =0;i<5;i++) {
            if (isElementPresent(ereading_Title_Remove)) {
                break;
            }
            else {
                swipeDown();
            }

        }
        ClickOnMobileElement(ereading_Title_Remove);
    }

    public void clickEdit_Reading_List_CTA() {
            ClickOnMobileElement(edit_Reading_List_CTA);
    }
    
    public void selectIndividual_Title() {
        ClickOnMobileElement(individual_Title);
    }
    
    public void selectDelete_Option() {
        ClickOnMobileElement(delete_Option);
    }
    
    public void selectSave_CTA() {
        ClickOnMobileElement(save_CTA);
    }
    
    public void selectCancel_CTA() {
        ClickOnMobileElement(cancel_CTA);
    }
    
    public void clickDelete_Title() {
        ClickOnMobileElement(clickDelete_Title);
    }
    
    public MobileElement active_Programs() {
		return active_Programs;
	}
    
    public MobileElement closed_Programs() {
		return closed_Programs;
	}
    
    public MobileElement label_Start_Date() {
		return label_Start_Date;
	}
    
    public MobileElement label_End_Date() {
		return label_End_Date;
	}
    
    public MobileElement label_Milestone_Program_Title() {
		return label_Milestone_Program_Title;
	}
    
    public void clickMilestoneProgram() {
        ClickOnMobileElement(label_Milestone_Program_Title);
        
    }
    
    public MobileElement milestone_Program() {
		return milestone_Program;
	}

    public MobileElement milestone_Leave_Program_Alert() {
        return leave_Program_Alert;
    }

    public void clickMilestoneJoinOk() {
        ClickOnMobileElement(clickMilestoneJoinOk);
        
    }
    
    public void clickMilestoneJoinCancel() {
        ClickOnMobileElement(clickMilestoneJoinCancel);
        
    }
    
    public MobileElement joinMilestoneAlertMsg() {
         return joinMilestoneAlertMsg;
        
    }
    
    public MobileElement joinConfirmationPopup() {
        return joinConfirmationPopup;
       
   }
    
    public MobileElement joinConfirmationYesBtn() {
        return joinConfirmationYesBtn;
       
   }
    
    public MobileElement joinConfirmationNoBtn() {
        return joinConfirmationNoBtn;
       
   }
    
    public void clickjoinConfirmationYes() {
    if (isElementPresent(joinConfirmationPopup)) {
    	
    	ClickOnMobileElement(joinConfirmationYesBtn);
      }
   }
    
    public void clickProgramMyPrograms() {
        ClickOnMobileElement(programSelectMyPrograms);
        
    }
    public MobileElement upcomingProgram() {
        return upcomingProgram;
       
   }
    
    public void clickUpcomingProgram() {
    	for(int i =0;i<6;i++) {
            if (isElementPresent(upcomingProgram)) {
                break;
            }
            else {
                swipeDown();
            }

        }
        ClickOnMobileElement(upcomingProgram);
        
    }
    
    public void addATitle() {
        ClickOnMobileElement(drop_DownOption);       
    }

    public MobileElement titleType() {
        return title_Type;
    }

    public MobileElement titleName() {
        return enter_Title_Name;
    }

    public MobileElement authorName() {
        return enter_Author_Name;
    }

    public void sendKeysTitleName() {
        SendKeysOnMobileElement(enter_Title_Name, "Testing");
    }

    public void sendKeysAuthorName() {
        SendKeysOnMobileElement(enter_Author_Name, "Ramji");
    }

    public void clickTitleTypeBox() {
        ClickOnMobileElement(title_Type);
    }

    public void clickTitleTypeOptionEbook() {
        ClickOnMobileElement(titleTypeOptionEbook);
    }

    public void clickTitleTypeOptionEaudio() {
        ClickOnMobileElement(titleTypeOptionEaudio);
    }

    public void clickAddButtonOwnTitle() {
        ClickOnMobileElement(addButtonOwnTitle);
    }

    public MobileElement addButton() {
        return addButtonOwnTitle;
    }

    public MobileElement addTitleSuccessPopup() {
        return addTitleSuccessPopup;
    }

    public void clickAddTitleSuccessPopupOk() {
        ClickOnMobileElement(addTitleSuccessPopupOk);
    }

    public MobileElement addTitleProgram() {
        return add_A_Title_Text;
    }

    public MobileElement titleSettingDots() {
        return titleSettingDots;
    }

    public void clickTitleSettingDots() {
        ClickOnMobileElement(titleSettingDots);
    }

    public void clickRemoveTitle() {
        ClickOnMobileElement(removetitle);
    }

    public void clickTitleRemoveOkPopup() {
        ClickOnMobileElement(titleRemovePopupOk);
    }

    public MobileElement advanceSearchHeading() {
        return advanceSearchHeading;
    }

    public void clickCloseAdvanceSearch() {
        ClickOnMobileElement(close_Icon);
    }

    public MobileElement programCompleted() {
        return programCompleted;
    }

    public MobileElement completedCount() {
        return done_Status_Count;
    }



    public void joinUpcomingProgram() {
        for(int i =0;i<15;i++) {
            if (isElementPresent(joinUpcomingProgram)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(joinUpcomingProgram);
    }

    public MobileElement verifyInsightsBadgesCheckboxEnabled() {
        return insightsBadgesCheckboxEnabled;
    }

    public void clickNotificationBellIcon() {
        ClickOnMobileElement(notificationBellIcon);
    }

    public MobileElement notificationProgramJoined() {
        return notificationProgramJoined;
    }

    public void clickNotificationEdit() {
        ClickOnMobileElement(notificationEditBtn);
    }

    public void clickNotificationDelete() {
        ClickOnMobileElement(notificationDeleteBtn);
    }

    public void clickNotificationDeleteYes() {
        ClickOnMobileElement(notificationDeleteYes);
    }

    public void clickSuggestedTitleAdd() {
        for (int i = 0; i < 4; i++) {
            if (isElementPresent(suggestedTitleAddBtn)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(suggestedTitleAddBtn);
    }

    public MobileElement titleAddedNotification() {
        return titleAddedNotification;
    }

    public MobileElement titleRemoveNotification() {
        return titleRemoveNotification;
    }

    public void clickprofileDetailClose() {
        ClickOnMobileElement(profileDetailCloseBtn);
    }

    public void joinOngoingProgram() {
        for(int i =0;i<10;i++) {
            if (isElementPresent(ongoingPrograms_from_OpenPrograms)) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(ongoingPrograms_from_OpenPrograms);
    }

    public MobileElement eaudioTitle() {
        return audioBookTitle;
    }

    public MobileElement videoTitle() {
        return videoTitle;
    }

    public MobileElement vbookTitle() {
        return vBookTitle;
    }

    public MobileElement confirmationPopup() {
        return confirmationPopup;
    }

    public void scrollToMileStoneUpcomingProgram() {
        for(int i= 0;i<5;i++) {
            if(isElementPresent(clickMileStoneUpcomingProgram)) {
                break;
            }
            else {
                swipeDown();
            }
        }
    }
}

   
       
  
