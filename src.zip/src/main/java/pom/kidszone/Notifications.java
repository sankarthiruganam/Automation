package pom.kidszone;

import java.util.List;

import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream;
import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Notifications extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public Notifications(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/******************* Locators **********************/

	@iOSXCUITFindBy(accessibility = "MENU_ITEM_NEW")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU_ITEM_NEW']")
	private MobileElement navigation_menu_librarymenu;

	@iOSXCUITFindBy(accessibility = "btnSearchMenu")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ImageView)[1]")
	private MobileElement navigation_icon_search;

	@iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
	private MobileElement navigation_icon_Advancesearch;

	@iOSXCUITFindBy(accessibility = "btnSearchMenu")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSearchMenu']")
	private MobileElement navigation_txt_searchBox;

	@iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
	@AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
	private MobileElement navigation_txt_library_searchBox;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private List<MobileElement> navigation_suggestion_Advancesearchlistofsuggestion;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='Close']")
	private MobileElement navigation_MyprofileCloseCta;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_close_AdvancesearchCloseCta;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_navHome_homepage;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_bottomNavigation_navigationbar;

	@iOSXCUITFindBy(accessibility = "MENU_FLAT_LIST")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_topNavigation_navigationbar;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement navigation_txt_Libraryname;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement navigation_bottommenu_myshelf;

	@iOSXCUITFindBy(accessibility = "txtHeaderCard")
	@AndroidFindBy(xpath = "//*[@text='GOALS & INSIGHTS']")
	private MobileElement navigation_navMyshelf_myshelfscreen;

	@iOSXCUITFindBy(accessibility = "MYLIBRARY")
	@AndroidFindBy(xpath = "//*[@resource-id='MYLIBRARY']")
	private MobileElement navigation_bottommenu_Library;

	@iOSXCUITFindBy(accessibility = "MENU_ITEM_NEW")
	@AndroidFindBy(xpath = "//*[@text='New']")
	private MobileElement navigation_navLib_libscreen;

	@iOSXCUITFindBy(accessibility = "BROWSE")
	@AndroidFindBy(xpath = "//*[@resource-id='BROWSE']")
	private MobileElement navigation_bottommenu_Browse;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Browse\"]")
	@AndroidFindBy(xpath = "(//*[@text='Browse'])[1]")
	private MobileElement navigation_navBrowse;

	@iOSXCUITFindBy(accessibility = "PROGRAMS")
	@AndroidFindBy(xpath = "//*[@resource-id='PROGRAMS']")
	private MobileElement navigation_bottommenu_programs;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Programs\"]")
	@AndroidFindBy(xpath = "(//*[@text='Programs'])[1]")
	private MobileElement navigation_navPrograms;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement navigation_bottommenu_menu;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@text='© 2022 Baker & Taylor']")
	private MobileElement navigation_navMenu_Menuscreen;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement navigation_img_avatarimg;

	@iOSXCUITFindBy(accessibility = "txtLibraryName")
	@AndroidFindBy(xpath = "//*[@resource-id='txtLibraryName']")
	private MobileElement myProfile_lbl_libName;

	@iOSXCUITFindBy(accessibility = "Back_Button")
	@AndroidFindBy(xpath = "//*[@resource-id='Back_Button']")
	private MobileElement navigation_icon_notification;

	@iOSXCUITFindBy(accessibility = "loc_btnAlert")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnAlert']")
	private MobileElement notification_alert_tab;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"txtRightMenuTitle\"]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//*[@text='Notification']")
	private MobileElement navigation_lbl_notificationcenter;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"txtRightMenuTitle\"]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//*[@text='Edit']")
	private MobileElement navigation_lbl_edit_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_SwipeLeft_Unread_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Swipeleft_Markas_Unread_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Swipeleft_Markas_read_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Swipeleft_Delete_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Select_One_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_SelectAll_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_UnSelectAll_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Cancel_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Delete_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Delete_Confirmation_msg_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Delete_Confirmation_msg_Yes_notification;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_Delete_Confirmation_msg_No_notification;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"PROGRAM_BADGES_LIST_ITEM\"])")
	@AndroidFindBy(xpath = "//*[@resource-id='PROGRAM_BADGES_LIST']/android.view.ViewGroup/android.view.ViewGroup")
	private List<MobileElement> notification_alert_messages;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement notification_details;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"PROGRAM_BADGES_LIST_ITEM\"])")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"unread, \"])")
	private List<MobileElement> notification_msg_details;

	@iOSXCUITFindBy(accessibility = "NOTIFICATION_DETAIL_DELETE_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='NOTIFICATION_DETAIL_DELETE_BUTTON']")
	private MobileElement delete_CTA;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	private MobileElement alert_Message;

	@iOSXCUITFindBy(accessibility = "NOTIFICATION_DETAIL_DELETE_CANCEL")
	@AndroidFindBy(xpath = "//*[@resource-id='NOTIFICATION_DETAIL_DELETE_CANCEL']")
	private MobileElement alert_Message_cancel;

	@iOSXCUITFindBy(accessibility = "NOTIFICATION_DETAIL_DELETE_OK")
	@AndroidFindBy(xpath = "//*[@resource-id='NOTIFICATION_DETAIL_DELETE_OK']")
	private MobileElement alert_Message_ok;

	@AndroidFindBy(xpath = "//*[@resource-id='TimeLine']/android.widget.TextView")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='dd_messagetime']")
	public List<MobileElement> timeStamp;

	 
	public MobileElement getAlert_Message() {
		return alert_Message;
	}


	public MobileElement getAlert_Message_cancel() {
		return alert_Message_cancel;
	}


	public MobileElement getAlert_Message_ok() {
		return alert_Message_ok;
	}


	public List<MobileElement> getNotification_msg_details() {
		return notification_msg_details;
	}

	public MobileElement getNotification_details() {
		return notification_details;
	}

	public List<MobileElement> getNotification_alert_messages() {
		return notification_alert_messages;
	}

	public MobileElement getNotification_alert_tab() {
		return notification_alert_tab;
	}

	public MobileElement getNavigation_icon_search() {
		return navigation_icon_search;
	}

	public MobileElement getNavigation_txt_Libraryname() {
		return navigation_txt_Libraryname;
	}

	public MobileElement getNavigation_topNavigation_navigationbar() {
		return navigation_topNavigation_navigationbar;
	}

	public MobileElement getNavigation_bottommenu_menu() {
		return navigation_bottommenu_menu;
	}

	public MobileElement getNavigation_bottommenu_programs() {
		return navigation_bottommenu_programs;
	}

	public MobileElement getNavigation_bottommenu_Browse() {
		return navigation_bottommenu_Browse;
	}

	public MobileElement getNavigation_bottommenu_Library() {
		return navigation_bottommenu_Library;
	}

	public MobileElement getNavigation_bottommenu_myshelf() {
		return navigation_bottommenu_myshelf;
	}

	public MobileElement getNavigation_bottomNavigation_navigationbar() {
		return navigation_bottomNavigation_navigationbar;
	}

	public MobileElement getNavigation_navHome_homepage() {
		return navigation_navHome_homepage;
	}

	public MobileElement getNavigation_menu_librarymenu() {
		return navigation_menu_librarymenu;
	}

	public MobileElement getNavigation_icon_Advancesearch() {
		return navigation_icon_Advancesearch;
	}

	public MobileElement getNavigation_txt_searchBox() {
		return navigation_txt_searchBox;
	}

	public List<MobileElement> getNavigation_suggestion_Advancesearchlistofsuggestion() {
		return navigation_suggestion_Advancesearchlistofsuggestion;
	}

	public MobileElement getNavigation_AdvancesearchCloseCta() {
		return navigation_MyprofileCloseCta;
	}

	public MobileElement getNavigation_close_AdvancesearchCloseCta() {
		return navigation_close_AdvancesearchCloseCta;
	}

	public MobileElement getNavigation_navMyshelf_myshelfscreen() {
		return navigation_navMyshelf_myshelfscreen;
	}

	public MobileElement getNavigation_navLib_libscreen() {
		return navigation_navLib_libscreen;
	}

	public MobileElement getNavigation_navBrowse() {
		return navigation_navBrowse;
	}

	public MobileElement getNavigation_navPrograms() {
		return navigation_navPrograms;
	}

	public MobileElement getNavigation_navMenu_Menuscreen() {
		return navigation_navMenu_Menuscreen;
	}

	public MobileElement getNavigation_img_avatarimg() {
		return navigation_img_avatarimg;
	}

	public MobileElement getNavigation_txt_profilescreen() {
		return myProfile_lbl_libName;
	}

	public MobileElement getNavigation_icon_notification() {
		return navigation_icon_notification;
	}

	public MobileElement getNavigation_txt_notificationcenter() {
		return navigation_lbl_notificationcenter;
	}

	public MobileElement getNavigation_txt_Edit_notification() {
		return navigation_lbl_edit_notification;
	}

	public MobileElement getnavigation_lbl_SwipeLeft_Unread_notification() {
		return navigation_lbl_SwipeLeft_Unread_notification;
	}

	public MobileElement getnavigation_lbl_Swipeleft_Markas_Unread_notification() {
		return navigation_lbl_Swipeleft_Markas_Unread_notification;
	}

	public MobileElement getnavigation_lbl_Swipeleft_Markas_read_notification() {
		return navigation_lbl_Swipeleft_Markas_read_notification;
	}

	public MobileElement getnavigation_lbl_Swipeleft_Delete_notification() {
		return navigation_lbl_Swipeleft_Delete_notification;
	}

	public MobileElement getnavigation_lbl_Select_One_notification() {
		return navigation_lbl_Select_One_notification;
	}

	public MobileElement getnavigation_lbl_SelectAll_notification() {
		return navigation_lbl_SelectAll_notification;
	}

	public MobileElement getnavigation_lbl_UnSelectAll_notification() {
		return navigation_lbl_UnSelectAll_notification;
	}

	public MobileElement getnavigation_lbl_Cancel_notification() {
		return navigation_lbl_Cancel_notification;
	}

	public MobileElement getnavigation_lbl_Delete_notification() {
		return navigation_lbl_Delete_notification;
	}

	public MobileElement getnavigation_lbl_Delete_Confirmation_msg_notification() {
		return navigation_lbl_Delete_Confirmation_msg_notification;
	}

	public MobileElement getnavigation_lbl_Delete_Confirmation_msg_Yes_notification() {
		return navigation_lbl_Delete_Confirmation_msg_Yes_notification;
	}

	public MobileElement getnavigation_lbl_Delete_Confirmation_msg_No_notification() {
		return navigation_lbl_Delete_Confirmation_msg_No_notification;
	}

	public MobileElement getDelete_CTA() {
		return delete_CTA;
	}

	/*********************** Action Methods ***************************/

	public void delete_msg() {
		ClickOnMobileElement(delete_CTA);
	}

	public void verifyingLatestMessage() {
		waitFor(3000);
		for (int i = 1; i <= timeStamp.size() - 1; i++) {
			String d1 = timeStamp.get(0).getText();
			String d2 = timeStamp.get(1).getText();
			if (d1.compareTo(d2) < 0) {
				logger.info("Latest message not displayed at top");
				break;
			} else if (d1.compareTo(d2) > 0) {
				logger.info("Latest message displayed at top");
				break;
			}
		}
	}

	public boolean validate_read() {
		boolean read_msg = true;
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (notification_msg_details.get(0).getAttribute("enabled").contains("true")) {
				read_msg = true;
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (notification_msg_details.get(0).isDisplayed()) {
				read_msg = true;
			}

		}
		return read_msg;
	}

	public void navigate_message_details() {
		for (int i = 0; i < notification_alert_messages.size(); i++) {
			ClickOnMobileElement(notification_alert_messages.get(1));

			break;
		}

	}

	public void titleSearch() {
		if (isElementPresent(navigation_txt_library_searchBox)) {
			ClickOnMobileElement(navigation_txt_library_searchBox);
			SendKeysOnMobileElement(navigation_txt_library_searchBox, "books");

		}
		ClickOnMobileElement(navigation_txt_searchBox);
		SendKeysOnMobileElement(navigation_txt_searchBox, "books");

	}

	public void click_advanceSearch() {
		ClickOnMobileElement(navigation_icon_Advancesearch);
	}

	public boolean view_avatar() {
		boolean avatar = false;
		if (isElementPresent(navigation_img_avatarimg)) {
			logger.info("user is able to view user avatar");
			avatar = true;
		}
		return avatar;
	}

	public void navigate_back() {
		ClickOnMobileElement(navigation_img_avatarimg);
	}

	public void verify_minimumInputcount() {
		for (int i = 0; i < navigation_suggestion_Advancesearchlistofsuggestion.size(); i++) {
			if (navigation_suggestion_Advancesearchlistofsuggestion.size() != 0) {
				SendKeysOnMobileElement(navigation_txt_searchBox, "a");
				logger.info("minimum input count is lessthen 1 ");
				navigation_txt_searchBox.clear();
				if (navigation_suggestion_Advancesearchlistofsuggestion.size() == 1) {
					SendKeysOnMobileElement(navigation_txt_searchBox, "aa");
					logger.info("minimum input count is greaterthen 1 ");
					navigation_txt_searchBox.clear();
					if (navigation_suggestion_Advancesearchlistofsuggestion.size() == 2) {
						SendKeysOnMobileElement(navigation_txt_searchBox, "aaa");
						logger.info("minimum input count is greaterthen 1 ");
						navigation_txt_searchBox.clear();
					} else {
						logger.info("suggestion not displayed ");
					}
				}

			}
		}
	}

	public boolean verify_closeCTA() {
		boolean b = true;
		if (isElementPresent(navigation_txt_library_searchBox)) {
			SendKeysOnMobileElement(navigation_txt_library_searchBox, "aaa");
		} else if (isElementPresent(navigation_txt_searchBox)) {
			SendKeysOnMobileElement(navigation_txt_searchBox, "aaa");
		}
		if (isDisplayed(navigation_close_AdvancesearchCloseCta)) {
			logger.info("cancel cta should be displayed when user input keyword in search bar ");
		} else {
			logger.info("cancel cta should not be displayed when user input keyword in search bar ");
		}
		return b;
	}

	public boolean click_NavmyshelfScreen() {
		boolean myshelf = false;
		ClickOnMobileElement(navigation_bottommenu_myshelf);
		if (navigation_navMyshelf_myshelfscreen.isDisplayed()) {
			logger.info("user navigate to myshelf screen ");
			myshelf = true;
		}
		return myshelf;
	}

	public boolean click_NavLibraryscreen() {
		boolean myLib = false;
		ClickOnMobileElement(navigation_bottommenu_Library);
		if (navigation_navLib_libscreen.isDisplayed()) {
			logger.info("user navigate to Library screen ");
			myLib = true;
		}
		return myLib;
	}

	public boolean click_NavBrowsescreen() {
		boolean browse = false;
		ClickOnMobileElement(navigation_bottommenu_Browse);
		if (navigation_navBrowse.isDisplayed()) {
			logger.info("user navigate to browse screen ");
			browse = true;
		}
		return browse;
	}

	public boolean click_Navprogramsscreen() {
		boolean prg = false;
		ClickOnMobileElement(navigation_bottommenu_Browse);
		if (navigation_navPrograms.isDisplayed()) {
			logger.info("user navigate to browse screen ");
			prg = true;
		}
		return prg;
	}

	public boolean click_NavMenuscreen() {
		boolean menu = false;
		ClickOnMobileElement(navigation_bottommenu_menu);
		if (navigation_navMenu_Menuscreen.isDisplayed()) {
			logger.info("user navigate to Menu screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_Nav_Notification_Editscreen() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_edit_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification Edit screen ");
			menu = true;
		}
		return menu;
	}

	public void view_notificationicon() {
		if (navigation_icon_notification.isDisplayed()) {
			logger.info("user is able to view notification ");
		} else {
			logger.info("user is not able to view notification");
		}
	}

	public void view_deleteicon() {
		if (navigation_icon_notification.isDisplayed()) {
			logger.info("user is able to view delete icon in notification ");
		} else {
			logger.info("user is not able to view delete icon in notification");
		}
	}

	public void view_notificationicon_Markas_Unread() {
		if (navigation_lbl_Swipeleft_Markas_Unread_notification.isDisplayed()) {
			logger.info("user is able to view Markasread option in notification screen ");
		} else {
			logger.info("user is not able to view Markasread option in notification screen");
		}
	}

	public void view_notificationicon_Markas_read() {
		if (navigation_lbl_Swipeleft_Markas_read_notification.isDisplayed()) {
			logger.info("user is able to view Markasread option in notification screen ");
		} else {
			logger.info("user is not able to view Markasread option in notification screen");
		}
	}

	public void view_notificationicon_Delete() {
		if (navigation_lbl_Delete_notification.isDisplayed()) {
			logger.info("user is able to view Delete option in notification screen ");
		} else {
			logger.info("user is not able to view Delete optionin notification screen");
		}
	}

	public void view_notification_Delete_Confirmation_msg() {
		if (navigation_lbl_Delete_Confirmation_msg_notification.isDisplayed()) {
			logger.info("user is able to view Delete confirmation message ");
		} else {
			logger.info("user is not able to view Delete confirmation message");
		}
	}

	public void view_notification_Delete_Confirmation_msg_Yes_Button() {
		if (navigation_lbl_Delete_Confirmation_msg_Yes_notification.isDisplayed()) {
			logger.info("user is able to view notification Delete confirmation message Yes Button ");
		} else {
			logger.info("user is not able to view notification Delete confirmation message Yes Button");
		}
	}

	public void view_notification_Delete_Confirmation_msg_No_Button() {
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user is able to view notification Delete confirmation message No Button ");
		} else {
			logger.info("user is not able to view notification Delete confirmation message No Button");
		}
	}

	public void view_notification_Edit_icon() {
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user is able to view notification Edit icon ");
		} else {
			logger.info("user is not able to view notification Edit icon");
		}
	}

	public void Nav_notificationcenterpage() {
			WaitForMobileElement(navigation_icon_notification);
			ClickOnMobileElement(navigation_icon_notification);
	}

	public void Swipeleft_On_Unread_read_Notification() {
		swipeleft(navigation_lbl_SwipeLeft_Unread_notification);
	}

	public boolean click_Markasread_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Swipeleft_Markas_Unread_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification markas read screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_MarkasUnread_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Swipeleft_Markas_read_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification markas read screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_Delete_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Swipeleft_Delete_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification Delete popup screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_Select_One_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Select_One_notification);
		if (navigation_lbl_Select_One_notification.isDisplayed()) {
			logger.info("user navigate to Select One Notification Delete or markas read or unread  screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_SelectAll_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Select_One_notification);
		if (navigation_lbl_Select_One_notification.isDisplayed()) {
			logger.info("user navigate to Select One Notification Delete or markas read or unread  screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_UnSelectAll_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_UnSelectAll_notification);
		if (navigation_lbl_Select_One_notification.isDisplayed()) {
			logger.info("user navigate to Select One Notification Delete or markas read or unread  screen ");
			menu = true;
		}
		return menu;
	}

	public void view_UnSelectAll_Notification() {
		if (navigation_lbl_UnSelectAll_notification.isDisplayed()) {
			logger.info("user is able to view UnSelectall notification in Edit screen ");
		} else {
			logger.info("user is not able to view UnSelectall notification in Edit screen");
		}
	}

	public void view_SelectAll_Notification() {
		if (navigation_lbl_SelectAll_notification.isDisplayed()) {
			logger.info("user is able to view Selectall notification in Edit screen ");
		} else {
			logger.info("user is not able to view Selectall notification in Edit screen");
		}
	}

	public void view_Cancel_Notification() {
		if (navigation_lbl_Cancel_notification.isDisplayed()) {
			logger.info("user is able to view Cancel icon  in Edit screen notification ");
		} else {
			logger.info("user is not able to view SCancel icon  in Edit screen notification");
		}
	}

	public boolean click_Cancel_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Cancel_notification);
		if (navigation_lbl_Select_One_notification.isDisplayed()) {
			logger.info("user navigate to Select One Notification Delete or markas read or unread  screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_Delete_Confirmation_Yes_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Delete_Confirmation_msg_Yes_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification markas read screen ");
			menu = true;
		}
		return menu;
	}

	public boolean click_Delete_Confirmation_No_Notification() {
		boolean menu = false;
		ClickOnMobileElement(navigation_lbl_Delete_Confirmation_msg_No_notification);
		if (navigation_lbl_edit_notification.isDisplayed()) {
			logger.info("user navigate to Notification markas read screen ");
			menu = true;
		}
		return menu;
	}
}