package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class PurchaseRequest extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(PurchaseRequest.class);

	public PurchaseRequest(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
	@AndroidFindBy(xpath = "//*[@resource-id = 'btnPurchaseRequest']")
	private MobileElement purchase_request_btn;

	@iOSXCUITFindBy(accessibility = "Filter_icon_test_id")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Sort, \"]")
	private MobileElement purchase_sort_btn;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Purchase RequestsPage\"]")
	@AndroidFindBy(xpath = "//*[@text = 'PURCHASE REQUESTS']")
	private MobileElement purchase_page;

	@iOSXCUITFindBy(accessibility = "Checkout_title_hours_diff_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id = 'Checkout_title_hours_diff_test_id']")
	private MobileElement recommended_page;

	@iOSXCUITFindBy(accessibility = "Checkout_title_hours_diff_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id = 'Checkout_title_hours_diff_test_id']")
	private MobileElement purchase_sortpage;

	@iOSXCUITFindBy(accessibility = "Sort_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id = 'Sort_icon_test_id']")
	private MobileElement sort_purchase;

	@iOSXCUITFindBy(accessibility = "Filter_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id = 'Filter_icon_test_id']")
	private MobileElement filter_purchase;

	@iOSXCUITFindBy(accessibility = "START_BY_LATEST")
	@AndroidFindBy(xpath = "//*[@resource-id = 'START_BY_LATEST']")
	private MobileElement sort_latestTitle;

	@iOSXCUITFindBy(accessibility = "List_Grid_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
	private MobileElement purchase_gridView;

	@iOSXCUITFindBy(accessibility = "checkout_title_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_title_test_id0']")
	private MobileElement purchase_titleName;

	@iOSXCUITFindBy(accessibility = "mystuffListView0")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement title_btn;

	@iOSXCUITFindBy(accessibility = "txtNoDataFound")
	@AndroidFindBy(xpath = "//*[@resource-id='txtNoDataFound']")
	private MobileElement nopurchase_request;

	@iOSXCUITFindBy(accessibility = "List_Grid_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='List_Grid_test_id']")
	private MobileElement purchase_listView;

	@iOSXCUITFindBy(accessibility = "Download_toggle_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='Download_toggle_test_id0']")
	private MobileElement clickRemoveCta;

	@iOSXCUITFindBy(accessibility = "CANCEL_PURCHASE_REQUEST")
	@AndroidFindBy(xpath = "//*[@resource-id='CANCEL_PURCHASE_REQUEST']")
	private MobileElement cancelRecommend;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement close_btn;

	@iOSXCUITFindBy(accessibility = "secondaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='secondaryButtonTestId']")
	private MobileElement click_Options;

	@iOSXCUITFindBy(accessibility = "emptySpaceCloseAreaTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='emptySpaceCloseAreaTestId']")
	private MobileElement clickEmptySpace;

	@iOSXCUITFindBy(accessibility = "mystuffListView0")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement click_Card;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement click_Back;

	public MobileElement getPurchase_request_btn() {
		return purchase_request_btn;
	}

	public MobileElement getPurchase_page() {
		return purchase_page;
	}

	public MobileElement getRecommended() {
		return recommended_page;
	}

	public MobileElement getSortLatestTitles() {
		return sort_latestTitle;
	}

	public MobileElement getPurchaseRequest_SortTitles() {
		return purchase_sortpage;
	}

	public MobileElement getPurchaseRequest_Sort() {
		return sort_purchase;
	}

	public MobileElement getPurchaseRequest_Filter() {
		return filter_purchase;
	}

	public MobileElement getPurchase_listView() {
		return purchase_listView;
	}

	public MobileElement getPurchase_gridView() {
		return purchase_gridView;
	}

	public MobileElement getTitlename() {
		return purchase_titleName;
	}

	public MobileElement getTitle_btn() {
		return title_btn;
	}

	public MobileElement getNoPurchaseRequest() {
		return nopurchase_request;
	}

	/******************** Action methods *************************/

	public void clickPurchaseRequest() {
		ClickOnMobileElement(purchase_request_btn);
	}

	public void clickSort() {
		ClickOnMobileElement(purchase_sort_btn);
	}

	public void clickSortLatest() {

		ClickOnMobileElement(sort_latestTitle);
	}

	public void clickPurchaseView() {
		if (isElementPresent(purchase_gridView)) {
			ClickOnMobileElement(purchase_gridView);
		} else if (isElementPresent(purchase_listView)) {
			ClickOnMobileElement(purchase_listView);
		}
	}

	public void removeRecommend() {
		ClickOnMobileElement(clickRemoveCta);
		ClickOnMobileElement(cancelRecommend);
	}

	public void closeButton() {
		ClickOnMobileElement(close_btn);

	}

	public void clickMoreOptions() {
		if (isElementPresent(click_Options)) {
			ClickOnMobileElement(click_Options);
		}
	}

	public void closepopup() {
		if (isElementPresent(clickEmptySpace)) {
			ClickOnMobileElement(clickEmptySpace);
		}
	}

	public void clickCard() {
		if (isElementPresent(click_Card)) {
			ClickOnMobileElement(click_Card);
		}
	}

	public void clickBack() {
		if (isElementPresent(click_Back)) {
			ClickOnMobileElement(click_Back);
		}
	}

	public void swipetoCheckout() {
		swipeleft(purchase_request_btn);

	}
}
