package pom.kidszone;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class RatingReview extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(RatingReview.class);

	public RatingReview(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/**************************** Locators ****************************/
	
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[4]/android.widget.ImageView")
	private MobileElement RatingReview_btn_bookHasNotRated;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[7]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]/android.widget.ImageView")
	private MobileElement RatingReview_btn_bookHasReview;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[4]/android.widget.ImageView")
	private MobileElement RatingReview_btn_eBookNotReviewed;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[4]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[1]/android.widget.ImageView")
	private MobileElement RatingReview_btn_AudioBookNotReviewed;
	
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[18]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[2]")
	private MobileElement eBook_Not_Reviewed;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[5]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]/android.widget.ImageView")
	private MobileElement RatingReview_btn_bookReviewHasBeenApproved;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[2]/android.widget.ImageView")
	private MobileElement RatingReview_btn_bookReviewHasNotBeenApproved;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[8]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[3]/android.widget.ImageView")
	private MobileElement RatingReview_btn_bookReviewRejected;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[54]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[2]/android.widget.ImageView")
	private MobileElement RatingReview_btn_audioBookReviewRejected;

	/**************************** 146968 ****************************/

	@iOSXCUITFindBy(accessibility = "averageRatingTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='averageRatingTestId']")
	private MobileElement RatingReview_lbl_averageRating;
	
	@iOSXCUITFindBy(accessibility = "averageRatingTestId")
	@AndroidFindBy(xpath = "//*[contains(@text,'Reviews')]")
	private MobileElement NotRated;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionOne")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_txtRatingOptionOne, \"]")
	private MobileElement RatingReview_lbl_ratingwithOneStar;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionFive")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_txtRatingOptionFive, \"]")
	private MobileElement RatingReview_lbl_ratingwithFiveStar;

	/**************************** 146970 ****************************/

	@iOSXCUITFindBy(accessibility = "ratingCTATestId")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRating']")
	private MobileElement RatingReview_btn_Ratingstar;
	
	@iOSXCUITFindBy(accessibility ="ratingModalBackGroundTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='ratingModalBackGroundTestId']")
	private MobileElement RatingReview_btn_drawerRatingBackground;

	@iOSXCUITFindBy(accessibility ="loc_txtRatingsDrawer")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"loc_txtRatingsDrawer, \"]")
	private MobileElement RatingReview_txt_drawerrating;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionOne")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionOne']")
	private MobileElement RatingReview_btn_ratingOptionOneStar;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionTwo")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionTwo']")
	private MobileElement RatingReview_btn_ratingOptionTwoStar;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionThree")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionThree']")
	private MobileElement RatingReview_btn_ratingOptionThreeStar;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionFour")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionFour']")
	private MobileElement RatingReview_btn_ratingOptionFourStar;

	@iOSXCUITFindBy(accessibility = "loc_txtRatingOptionFive")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionFive']")
	private MobileElement RatingReview_btn_ratingOptionFiveStar;

	@iOSXCUITFindBy(accessibility = "message_snackbar_view")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement RatingReview_lbl_MessageSuccessfulSubmission;

	@iOSXCUITFindBy(accessibility = "message_snackbar_view")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement RatingReview_lbl_MessageFailureSubmission;

	/**************************** 146971 ****************************/

	@iOSXCUITFindBy(accessibility = "loc_txtDetailsCountReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtDetailsCountReview']")
	private MobileElement RatingReview_lbl_ReviewSubmitted;

	@iOSXCUITFindBy(accessibility = "loc_txtDetailsCountReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtDetailsCountReview']")
	private MobileElement RatingReview_lbl_NumberReadersReviews;

	@iOSXCUITFindBy(accessibility = "loc_txtWhatDoYouThink")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtWhatDoYouThink']")
	private MobileElement RatingReview_lbl_WriteReviewScreen;

	@iOSXCUITFindBy(accessibility = "loc_btnSubmitReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnSubmitReview']")
	private MobileElement RatingReview_btn_SubmitBtn;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement view_adultProfile;
	@iOSXCUITFindBy(accessibility = "loc_txtReviewField")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtReviewField']")
	private MobileElement RatingReview_lbl_ReviewField;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your review has been submitted to your library for approval.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your review has been submitted to your library for approval.']")
	private MobileElement RatingReview_lbl_ConfirmMessageSuccessReview;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement RatingReview_btn_CloseCTA;

	/**************************** 146972 ****************************/

	@iOSXCUITFindBy(accessibility = "loc_btnDetailsWriteReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDetailsWriteReview']")
	private MobileElement RatingReview_btn_WriteReviewCTA;
	
	@iOSXCUITFindBy(accessibility = "loc_btnDetailsWriteReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDetailsWriteReview']")
	private MobileElement btn_WriteReviewCTA;

	@iOSXCUITFindBy(accessibility = "Details")
	@AndroidFindBy(xpath = "//*[@resource-id='Details']")
	private MobileElement eBook_Details;
	/**************************** 146974 ****************************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"A review from you is already applied to this title. You can only post one review per title. Thank you.\"]")
	@AndroidFindBy(xpath = "//*[@text='You already submitted a review for this title, which is approved.']")
	private MobileElement RatingReview_btn_MessageReviewApproved;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"You already submitted a review for this title. The library has not yet approved it for posting.\"]")
	@AndroidFindBy(xpath = "//*[@text='You already submitted a review for this title, which is pending for approval.']")
	private MobileElement RatingReview_btn_MessageReviewNotApproved;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement RatingReview_btn_EditReview;

	/**************************** 146975 ****************************/

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement RatingReview_btn_rejectSubmission;

	public MobileElement getAverageRating() {
		return RatingReview_lbl_averageRating;
	}
	
	public MobileElement getNotRated() {
		return NotRated;
	}
	
	public MobileElement getRatingOneStar() {
		return RatingReview_lbl_ratingwithOneStar;
	}
	
	public MobileElement getRatingFiveStar() {
		return RatingReview_lbl_ratingwithFiveStar;
	}
	
	public MobileElement getRatingDrawer() {
		return RatingReview_txt_drawerrating;
	}
	
	public MobileElement getSuccessRatingMsg() {
		return RatingReview_lbl_MessageSuccessfulSubmission;
	}
	
	public MobileElement getFailureRatingMsg() {
		return RatingReview_lbl_MessageFailureSubmission;
	}
	
	public MobileElement getWriteReviewScreen() {
		return RatingReview_lbl_WriteReviewScreen;
	}
	
	public MobileElement getReviewField() {
		return RatingReview_lbl_ReviewField;
	}
	
	public MobileElement getReviewSubmitted() {
		return RatingReview_lbl_ReviewSubmitted;
	}
	
	public MobileElement getNoOfReviewSubmitted() {
		return RatingReview_lbl_NumberReadersReviews;
	}
	
	public MobileElement getSubmitBtnEnabled() {
		return RatingReview_btn_SubmitBtn;
	}

	public MobileElement getAdultProfile() {
		return view_adultProfile;
	}
	public MobileElement getSuccessReviewMsg() {
		return RatingReview_lbl_ConfirmMessageSuccessReview;
	}
	
	public MobileElement getApprovedReviewMsg() {
		return RatingReview_btn_MessageReviewApproved;
	}
	
	public MobileElement getNotApprovedReviewMsg() {
		return RatingReview_btn_MessageReviewNotApproved;
	}

	public MobileElement getCloseCTA() {
		return RatingReview_btn_CloseCTA;
	}

	/********************* Actions ***********************/

	public Boolean scrollAndTapBookNotRated() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {	
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookHasNotRated);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookHasNotRated);
		}
		return book;
    }

	public Boolean scrollAndTapBookHasReview() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookHasReview);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookHasReview);
		}
		return book;
    }

	public Boolean scrollAndTapeBookNotReviewed() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_eBookNotReviewed);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if(isElementPresent(RatingReview_btn_eBookNotReviewed)) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_eBookNotReviewed);
			}
		}
		return book;
    }

	public void eBookNotReviewed() {
		swipeDown();
		
		swipeDown();
		
		swipeDown();
		
		swipeDown();

		swipeDown();

		swipeDown();
		
		if (isElementPresent(eBook_Not_Reviewed)) {
			ClickOnMobileElement(eBook_Not_Reviewed);
		} 
    }
	public Boolean scrollAndTapAudioBookNotReviewed() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_AudioBookNotReviewed);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_AudioBookNotReviewed);
		}
		return book;
    }

	public Boolean scrollAndTapBookReviewHasBeenApproved() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewHasBeenApproved);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewHasBeenApproved);
		}
		return book;
    }

	public Boolean scrollAndTapBookReviewHasNotBeenApproved() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewHasNotBeenApproved);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewHasNotBeenApproved);
		}
		return book;
    }

	public Boolean scrollAndTapBookReviewRejected() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewRejected);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_bookReviewRejected);
		}
		return book;
    }

	public Boolean scrollAndTapAudioBookReviewRejected() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_audioBookReviewRejected);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(RatingReview_btn_audioBookReviewRejected);
		}
		return book;
    }

	public String verifyAverageRating() {
		String averageRating = RatingReview_lbl_averageRating.getText();
		System.out.println("Average Rating is : " + averageRating);
		return averageRating;
	}

	public void startRating() {
		//waitFor(5000);
//		swipeDown();
		for(int i = 0; i<=5 ;i++) {
			if(isElementPresent(RatingReview_btn_Ratingstar)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(RatingReview_btn_Ratingstar);
	}

	public void selectRating() {
		ClickOnMobileElement(RatingReview_btn_ratingOptionThreeStar);
	}

	public void dismissDrawer() {
		ClickOnMobileElement(RatingReview_btn_drawerRatingBackground);
	}
	
	public Boolean scrollToSubmittedReview() {		
		Boolean submittedReview = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"Reviews\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Submitted review is available");
			} else {
				submittedReview = false;
				logger.info("Submitted review is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			if (isElementPresent(RatingReview_lbl_ReviewSubmitted)) {
				logger.info("Submitted review is available");
			}
		}
		return submittedReview;
	}
	
	public String viewNumberOfReviewSubmitted() {
		String noOfReview = RatingReview_lbl_NumberReadersReviews.getText();
		System.out.println("Number of Review Submitted : " + noOfReview);
		return noOfReview;
	}
	
	public void tapWriteReviewButton() {
		//details.tapDetailsTab();
		//scrollToSubmittedReview();
		ClickOnMobileElement(RatingReview_btn_WriteReviewCTA);
	}

	public void click_eBook_Details() {
		ClickOnMobileElement(eBook_Details);
	}
	public void writeReview() {
		swipeDown();
		swipeDown();
		ClickOnMobileElement(btn_WriteReviewCTA);
	}
	public void verifyWriteReviewField(String character){
		try {
			inputReview(character);
			
		}
		catch(Exception e) {
			viewReviewFieldwithSubmittedReview();
		}
	}

	public void inputReview(String character){
		ClickOnMobileElement(RatingReview_lbl_ReviewField);
		SendKeysOnMobileElement(RatingReview_lbl_ReviewField, character);
		swipeDown();
		hideMobileKeyboard();
	}

	public void tapSubmitReviewBtn(){
		ClickOnMobileElement(RatingReview_btn_SubmitBtn);
	}

	public void tapCloseBtn(){
		ClickOnMobileElement(RatingReview_btn_CloseCTA);
	}

	public String viewReviewFieldwithSubmittedReview(){
		String reviewField = RatingReview_lbl_ReviewField.getText();
		System.out.println("Submitted review : " + reviewField);
		return reviewField;
	}
	
	public void deleteCharacters(String character) {
		ClickOnMobileElement(RatingReview_lbl_ReviewField);
		SendKeysOnMobileElement(RatingReview_lbl_ReviewField, character);
		String str = character;
		String strNew = str.replace("f","");
		ClickOnMobileElement(RatingReview_lbl_ReviewField);
		SendKeysOnMobileElement(RatingReview_lbl_ReviewField, strNew);
		swipeDown();
	}
	
	public void clickSubmitBtn() {
		ClickOnMobileElement(RatingReview_btn_SubmitBtn);
	}

	public MobileElement get_eBook_Details() {
		return eBook_Details;
	}

}
