package pom.kidszone;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class RegisterScreen extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());

	public RegisterScreen(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
	@AndroidFindBy(id = "loc_txtLibraryId")
	public MobileElement loc_txt_libraryId;

	@AndroidFindBy(id = "not_now")
	public MobileElement logo_btn_faceIDnotNow;

	@AndroidFindBy(id = "yes_disable")
	public MobileElement logo_btn_faceIDdisablePeremanent;

	@iOSXCUITFindBy(accessibility = "loc_txtboxSigninPIN")
	// @AndroidFindBy(id = "loc_txtSigninPin")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_txtSigninPin')]")
	private MobileElement loc_txt_libraryPin;

	@iOSXCUITFindBy(accessibility = "Done")
	public MobileElement logo_btn_Done;

	@iOSXCUITFindBy(accessibility = "loc_btnRegister")
	@AndroidFindBy(id = "new_reg_btnRegister")
	private MobileElement library_btn_Register;

	@iOSXCUITFindBy(accessibility = "loc_btnSignin")
	@AndroidFindBy(id = "loc_btnSigninButton")
	public MobileElement logo_btn_signin;

	@iOSXCUITFindBy(accessibility = "loc_txtboxSigninCardnumber")
	@AndroidFindBy(id = "loc_txtLibraryId")
	private MobileElement signIn_txt_libId;

	@iOSXCUITFindBy(accessibility = "loc_txtRegisterTitle")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Register Page heading\"]")
	private MobileElement register_lbl;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterDisplayName")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'display_name')]")
	private MobileElement register_txt_DisplayName;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterEmail")
	@AndroidFindBy(xpath = "//*[@text='Email']")
	private MobileElement register_txt_Email;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterCardnumber")
	@AndroidFindBy(id = "new_reg_tvLibraryId")
	public MobileElement register_txt_CardName;

	@iOSXCUITFindBy(accessibility = "loc_dropRegisterSecurityQuest")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Security Question')]")
	private MobileElement securityQuestion_drpd;

	@iOSXCUITFindBy(accessibility = "loc_dropRegisterSecurityQuest")
	@AndroidFindBy(xpath = "(//*[@resource-id='android:id/content']//android.widget.LinearLayout)")
	private List<MobileElement> sec_drpd_question;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Close page\"]")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/secQues_tvQuestions")
	public MobileElement sec_lbl_close;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterSecurityAns")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'new_reg_etSecAns')]")
	private MobileElement securityAnswer_drpd;

	@AndroidFindBy(id = "adult_layout")
	@iOSXCUITFindBy(accessibility = "loc_btnRegisterAdult")
	public MobileElement reg_btn_adult;

	@AndroidFindBy(id = "teen_layout")
	@iOSXCUITFindBy(accessibility = "loc_btnRegisterTeen")
	public MobileElement reg_btn_teen;

	@AndroidFindBy(id = "kids_layout")
	@iOSXCUITFindBy(accessibility = "loc_btnRegisterKid")
	public MobileElement reg_btn_kid;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'new_reg_temp_pwd')]")
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterPIN")
	public MobileElement reg_pin;

	@AndroidFindBy(xpath = "//*[contains(@text,'PIN')]")
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterPIN")
	public MobileElement reg_pinCheck;

	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"New user?  Click here to register\"]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"New User? Click here to register\"]")
	public MobileElement reg_newuser;

	@iOSXCUITFindBy(accessibility = "loc_btnRegister")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Register\"]")
	private MobileElement registerBtn;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Profiles\"]")
	@AndroidFindBy(xpath = "//*[@text='Profiles']")
	private MobileElement profileLandingScreen;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']/android.widget.TextView[@text='Admin']")
	private MobileElement adultProfileWithoutDisplayName;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='listItemProfileListRow0']")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']/android.widget.TextView[@text='Tester']")
	private MobileElement adultProfileWithDisplayName;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']")
	public MobileElement adultProfile;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow1")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName1']")
	private MobileElement teenProfile1;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'NewTeen')]")
	@AndroidFindBy(xpath = "//*[contains(@text,'NewTeen')]")
	private MobileElement teenProfile2;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName2']")
	private MobileElement kidProfile1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='NewKidprofile']")
	@AndroidFindBy(xpath = "//*[contains(@text,'NewKidprofile')]")
	private MobileElement kidProfile2;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Teen')]")
	@AndroidFindBy(xpath = "(//*[contains(@text,'Teen')])[1]")
	private MobileElement teenProfile1DisplayName;

	@iOSXCUITFindBy(accessibility = "DUMMY")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement teenProfile2DisplayName;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,' Kid')]")
	@AndroidFindBy(xpath = "(//*[contains(@text,'Kid')])[1]")
	private MobileElement kidProfile1DisplayName;

	@iOSXCUITFindBy(accessibility = "DUMMY")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement kidProfile2DisplayName;

	@iOSXCUITFindBy(accessibility = "user_profile_add_avatar")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_add_avatar']")
	public MobileElement profile_txt_add;

	@iOSXCUITFindBy(accessibility = "profile_teen_type")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_teen_type']")
	private MobileElement profile_btn_teen;

	@iOSXCUITFindBy(accessibility = "profile_adult_type")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_adult_type']")
	private MobileElement profile_btn_adult;

	@iOSXCUITFindBy(accessibility = "profile_child_type")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_child_type']")
	public MobileElement profile_btn_child;

	@iOSXCUITFindBy(accessibility = "btnSelectAvatar")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSelectAvatar']")
	public MobileElement profile_btn_avatar;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"avatar_view\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='avatar_view'])[1]")
	public MobileElement profile_img_avatar;

	@iOSXCUITFindBy(accessibility = "loc_edit_profile_name")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_name']")
	public MobileElement profile_txt_displayname;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterDisplayName")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'new_reg_display_name')]")
	public MobileElement profile_txt_displayname1;

	@iOSXCUITFindBy(accessibility = "btnDone")
	@AndroidFindBy(xpath = "//*[@resource-id='btnDone']")
	public MobileElement profile_btn_done;

	@iOSXCUITFindBy(accessibility = "btnAddProfileYes")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAddProfileYes']")
	public MobileElement profile_btn_addconfirm;

	@iOSXCUITFindBy(accessibility = "btnAddProfileNo")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAddProfileNo']")
	public MobileElement profile_btn_confirm;

	@iOSXCUITFindBy(accessibility = "DUMMY")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement profileLimitHeaderText;

	@iOSXCUITFindBy(accessibility = "DUMMY")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement profileLimitMessage;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement profileCreation_OKbtn;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	private MobileElement profileCreationConfirmationText;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']")
	private MobileElement profile_txt_profile1;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow1']")
	private MobileElement profile_txt_profile2;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName2']")
	private MobileElement profile_txt_profile3;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement profileIcon;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeTable/XCUIElementTypeCell")
	@AndroidFindBy(id = "//*[@resource-id='dummy']")
	public MobileElement logo_txt_IndependentLibrary;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeButton")
	@AndroidFindBy(id = "//*[@resource-id='dummy']")
	public MobileElement logo_txt_matchingLibrary;

	@iOSXCUITFindBy(accessibility = "view_toggle")
	@AndroidFindBy(xpath = "//*[@resource-id='view_toggle']")
	public MobileElement profilePinIsDisabled;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	public MobileElement profileEditOption;

	@iOSXCUITFindBy(accessibility = "Enable My Profile PIN")
	@AndroidFindBy(xpath = "//*[@content-desc='Enable My Profile PIN, ']")
	public MobileElement enableProfilePinText;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement disableProfilePinText;

	@iOSXCUITFindBy(accessibility = "Profile Management PIN heading")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Profile Management PIN heading, \"]")
	public MobileElement parentalPinSetupText;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement parentalPinSetup;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement confirmPinSetup;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement doneButton;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement confirmPinSetupText;

	@iOSXCUITFindBy(accessibility = "//*[@label='PIN FAILED']")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'PIN FAILED')]")
	public MobileElement wrongPinMessage;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement correctPinMessage;

	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterEmail")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'new_reg_email')]")
	public MobileElement profileEmailField;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"New User? Click here to register.\"]")
	@AndroidFindBy(id = "enter_your_lib_password")
	private MobileElement reg_lbl_librarypasswordLink;

	@iOSXCUITFindBy(accessibility = "edit_profile_save")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'edit_profile_save')]")
	public MobileElement editprofile_btn_save;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	public MobileElement DoneButton;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Information\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Information, \"])[1]")
	public MobileElement adultCheckoutToolTipIcon;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id= 'ALERT_MESSAGE']")
	public MobileElement adultCheckoutToolTipText;

	@iOSXCUITFindBy(accessibility = "ok_button")
	@AndroidFindBy(xpath = "//*[@resource-id= 'ok_button']")
	public MobileElement dismissOptionInCheckout;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"viewTitleHistory\"]")
	@AndroidFindBy(xpath = "//*[contains(@text,'Auto checkout available holds')]")
	public MobileElement checkoutHoldCheckbox;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"viewTitleHistory\"]")
	@AndroidFindBy(xpath = "(//*[@resource-id='viewTitleHistory'])[1]")
	public MobileElement verifycheckoutHoldCheckbox;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	public MobileElement emailVerificationPopup;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement library_Card_Id;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement login_Pin;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement security_Question;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement user_Name;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement login_Password;
	
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterPIN")
	@AndroidFindBy(xpath = "//*[@text=\"[PIN/Password]*\"]")
	public MobileElement reg_txt_pin;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement security_Answer;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement display_Name;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	public MobileElement myProfile_Screen;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	public MobileElement profiles_btn_back;

	@iOSXCUITFindBy(accessibility = "My Profile Heading")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	public MobileElement profiles_title;

	@iOSXCUITFindBy(accessibility = "loc_edit_profile_name")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_name']")
	public MobileElement profiles_displayName;

	@AndroidFindBy(id = "enable_face_id")
	public MobileElement logo_btn_enableFaceID;

	@iOSXCUITFindBy(accessibility = "view_toggle")
	@AndroidFindBy(xpath = "//*[@resource-id='toggle_change']")
	public MobileElement enablePin;
	
	
	@AndroidFindBy(id = "new_reg_tvLibraryId")
	public MobileElement newReg_txt_libraryId;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	public MobileElement disablePinConfirmationPopupText;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	public MobileElement disablePinConfirmationPopupText1;

	@iOSXCUITFindBy(accessibility = "parentail_disabled_alert_no")
	@AndroidFindBy(xpath = "//*[@content-desc='Cancel, ']")
	public MobileElement cancelInDisablePopup;

	@iOSXCUITFindBy(accessibility = "parentail_disabled_alert_yes")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Are you sure you want to disable PIN for this profile? Yes, \"]/android.widget.TextView")
	public MobileElement yesInDisablePopup;
	
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterPIN")
	@AndroidFindBy(xpath="//*[@text=\"Password*\"]")
	private MobileElement reg_txt_libraryPassword;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement new_User;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@content-desc='Profile picture, button, ']")
	public MobileElement profile_Icon;

	@iOSXCUITFindBy(accessibility = "imgUserListIcon0")
	@AndroidFindBy(id = "//*[@resource-id='imgUserListIcon0']")
	public MobileElement profile_Icon_Image;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement save_Btn;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeTextField")
	@AndroidFindBy(id = "//*[@resource-id='dummy']")
	public MobileElement logo_txt_search;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(id = "dummy")
	private MobileElement login_txt_validationError;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	public MobileElement bottom_Menu;

	@iOSXCUITFindBy(accessibility = "Profiles_Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Profiles_Menu']")
	public MobileElement profile_Option;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Teen')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Teen')]")
	public MobileElement teen_Profile;

	@iOSXCUITFindBy(accessibility = "loc_edit_profile_name")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_name']")
	public MobileElement edit_Display_Name;

	@iOSXCUITFindBy(accessibility = "txtRightMenuTitle")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Edit')]")
	public MobileElement profile_Edit_Btn;
	
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterPIN")
	@AndroidFindBy(xpath="//*[@text=\"[PIN/Password]*\"]")
	private MobileElement reg_txt_libraryPassword1;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement clickTitle;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement pinDisableText;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement myLibraryHomeScreen;

	@iOSXCUITFindBy(accessibility = "Also Available")
	@AndroidFindBy(xpath = "//*[@content-desc='Also Available, ']")
	public MobileElement alsoAvailable;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement alternateFormatSameTitle;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement profile_Selection_Registration;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement back_btn;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	public MobileElement success_Toast_Msg;

	@iOSXCUITFindBy(accessibility = "btnTeenEmailAddress")
	@AndroidFindBy(xpath = "//*[@resource-id= 'btnTeenEmailAddress']")
	public MobileElement teen_Same_Email_Adult;

	@iOSXCUITFindBy(accessibility = "txtProfileListName2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName2']")
	public MobileElement teen_Profile_Check;

	@iOSXCUITFindBy(accessibility = "txtProfileListName2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName2']")
	public MobileElement kid_Profile_Check;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	public MobileElement pinSubmitBtn;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@label,'Display Name')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Display Name text')]")
	public MobileElement displayNameText;

	@iOSXCUITFindBy(accessibility = "Availability")
	@AndroidFindBy(xpath = "//*[@text='Availability']")
	public MobileElement lib_Availability;

	@iOSXCUITFindBy(accessibility = "Profile Type")
	@AndroidFindBy(xpath = "//*[@content-desc='Profile Type, ']")
	public MobileElement profile_Details_Type;

	@iOSXCUITFindBy(accessibility = "Format")
	@AndroidFindBy(xpath = "//*[@text='Format']")
	public MobileElement lib_Format;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"btnEmailNotifications\"])[2]")
//	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Enable PINs for all profiles')]//android.widget.CheckBox")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'profile pinToggle CTA,')]")
	public MobileElement clickEnablePinAllProfiles;

	@iOSXCUITFindBy(xpath = "(//*[@name='btnEmailNotifications'])[4]")
	@AndroidFindBy(xpath = "//*[@name='Format']")
	public MobileElement clickEnablePinAllProfilesToolTip;

	@iOSXCUITFindBy(accessibility = "onTtooltipHandle")
	@AndroidFindBy(xpath = "//*[@resource-id='onTtooltipHandle']")
	public MobileElement enableProfilePinToolTip;

	@iOSXCUITFindBy(accessibility = "learnmore")
	@AndroidFindBy(xpath = "//*[@resource-id='learnmore']")
	public MobileElement learnMoreProfile;
	
	@iOSXCUITFindBy(accessibility = "Invalid Registration Password.")
	@AndroidFindBy(id="error_text")
	private MobileElement reg_lbl_invalidlibraryPassword;

	@iOSXCUITFindBy(accessibility = "About Profiles")
	@AndroidFindBy(xpath = "//*[@text='About Profiles']")
	public MobileElement aboutProfiles;
	
	@iOSXCUITFindBy(accessibility = "loc_txtboxRegisterCardnumber")
	@AndroidFindBy(xpath ="//android.widget.TextView[@content-desc=\"Register Page heading\"]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout//android.widget.EditText")
	private MobileElement reg_txt_reglibraryId;

	@iOSXCUITFindBy(accessibility = "Enter a valid email")
	@AndroidFindBy(xpath = "//*[@text='Enter a valid email']")
	public MobileElement invalidEmailWarningTxt;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'e Book')])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='imgCardIconRecommendationBook0']")
	public MobileElement unavailableTitle;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	public MobileElement titleDetails;

	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Add to Wishlist')]")
	public MobileElement addToWishlistCTA;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'Remove from Wishlist')])")
	@AndroidFindBy(xpath = "//*[contains(@text,'Remove from Wishlist')]")
	public MobileElement removeFromWishlistCTA;

	@iOSXCUITFindBy(accessibility = "//*[@text='Close']")
	@AndroidFindBy(xpath = "//*[@text='Close']")
	public MobileElement readingPopupClose;

	// -------------------------------Methods--------------------------------------------//

	public MobileElement lib_Availability() {
		return lib_Availability;
	}

	public MobileElement lib_Format() {
		return lib_Format;
	}

	public MobileElement getProfiles_title() {
		return profiles_title;
	}

	public void edit_displayName(String dispalyname) {
		ClickOnMobileElement(profiles_displayName);
		profiles_displayName.clear();
		SendKeysOnMobileElement(profiles_displayName, dispalyname);
	}

	public void enterPrefixandpin(String prefixid, String pin) {
		ClickOnMobileElement(loc_txt_libraryId);
		SendKeysOnMobileElement(loc_txt_libraryId, prefixid + RandomStringGenerate());
		ClickOnMobileElement(loc_txt_libraryPin);
		SendKeysOnMobileElement(loc_txt_libraryPin, pin);

		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
			ClickOnMobileElement(logo_btn_signin);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			try {
				ClickOnMobileElement(logo_btn_signin);
				logger.info("Keyboard is not hiding Sigin button its visible");
			} catch (Exception e) {
				logger.info("Hiding Keyboard");
				DriverManager.getDriver().navigate().back();
				ClickOnMobileElement(logo_btn_signin);
			}
		}

	}

	public void enterPrefixLogin(String libraryid) {
		ClickOnMobileElement(signIn_txt_libId);
		String newUserName = libraryid + RandomStringGenerate();
		SendKeysOnMobileElement(signIn_txt_libId, newUserName);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(2000);
			ClickOnMobileElement(logo_btn_Done);
			ClickOnMobileElement(logo_btn_signin);
		} else {
			swipeDown();
			ClickOnMobileElement(logo_btn_signin);
		}
	}

	public MobileElement getRegister_lbl() {
		return register_lbl;
	}

	public MobileElement checkCardNumberField() {
		return register_txt_CardName;
	}
	
	public MobileElement getReg_txt_libraryPassword1() {
		return reg_txt_libraryPassword1;
	}

	public MobileElement checkDisplayNameField() {
		return register_txt_DisplayName;
	}

	public void enterDisplayNameValue(String displayName) {
		ClickOnMobileElement(register_txt_DisplayName);
		SendKeysOnMobileElement(register_txt_DisplayName, displayName);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			hideMobileKeyboard();
		} else {
			DriverManager.getDriver().navigate().back();
		}
	}

	public void enterEmailFieldValue() {
		ClickOnMobileElement(register_txt_Email);
		SendKeysOnMobileElement(register_txt_Email, "test@gmail.com");
	}

	public MobileElement checkSecurityAnswerField() {
		return securityAnswer_drpd;
	}

	public MobileElement getNewregister_txt_Email() {
		return register_txt_Email;
	}
	
	public MobileElement getReg_txt_reglibraryId() {
		return reg_txt_reglibraryId;
	}

	public MobileElement getLibrary_btn_Register() {
		return library_btn_Register;
	}

	public MobileElement checkAdultInRegScreen() {
		return reg_btn_adult;
	}

	public MobileElement getRegister_txt_DisplayName() {
		return register_txt_DisplayName;
	}
	
	public MobileElement getRegisterseq_txt_DisplayName() {
		return register_txt_DisplayName;
	}

	public MobileElement getRegister_txt_Email() {
		return register_txt_Email;
	}

	public MobileElement checkTeenInRegScreen() {
		return reg_btn_teen;
	}

	public MobileElement checkKidInRegScreen() {
		return reg_btn_kid;
	}

	public MobileElement checkPinField() {
		return reg_pinCheck;
	}

	public void clickNewUserLink() {
		ClickOnMobileElement(reg_newuser);
	}

	public void enterpassword(String newpassword) {
		ClickOnMobileElement(reg_pin);
		waitFor(0);
		SendKeysOnMobileElement(reg_pin, newpassword);
		hideMobileKeyboard();
	}

	public void clickBackIcon() {
		ClickOnMobileElement(back_btn);
	}

	public void clickRegisterButton() {
		ClickOnMobileElement(registerBtn);
	}

	public void selectSecurityQuestion() {
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			ClickOnMobileElement(securityQuestion_drpd);
			ClickOnMobileElement(sec_lbl_close);
			SendKeysOnMobileElement(securityAnswer_drpd, "dog");
		} else {
			waitFor(2000);
			ClickOnMobileElement(securityQuestion_drpd);
			ClickOnMobileElement(sec_drpd_question.get(2));
			ClickOnMobileElement(securityAnswer_drpd);
			SendKeysOnMobileElement(securityAnswer_drpd, "blue");
			DriverManager.getDriver().navigate().back();
			swipeDown();
		}
	}

	public void completeRegistration() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(logo_btn_Done)) {
				ClickOnMobileElement(logo_btn_Done);
			}
			ClickOnMobileElement(library_btn_Register);
		} else {
			swipeDown();
			ClickOnMobileElement(library_btn_Register);
		}
	}

	public MobileElement checkProfilelandingScreen() {
		return profileLandingScreen;
	}

	public String checkAdultProfileWithoutDisplayName() {
		return adultProfileWithoutDisplayName.getText();
	}

	public MobileElement checkAdultProfile() {
		return adultProfile;
	}

	public boolean checkAdultProfileWithDisplayName(String DisplayName) {
		boolean result = false;

		if (adultProfileWithDisplayName.getText().contains(DisplayName)) {
			result = true;
		}
		return result;
	}

	public MobileElement checkTeenProfile1() {
		return teenProfile1;
	}

	public MobileElement checkTeenProfile2() {
		return teenProfile2;
	}

	public MobileElement checkKidProfile1() {
		return kidProfile1;
	}

	public MobileElement checkKidProfile2() {
		return kidProfile2;
	}

	public MobileElement checkTeenProfile1DisplayName() {
		return teenProfile1DisplayName;
	}

	public MobileElement checkTeenProfile2DisplayName() {
		return teenProfile2DisplayName;
	}

	public MobileElement checkKidProfile1DisplayName() {
		return kidProfile1DisplayName;
	}

	public MobileElement checkKidProfile2DisplayName() {
		return kidProfile2DisplayName;
	}

	public void addProfileCta() {
		ClickOnMobileElement(profile_txt_add);
	}

	public MobileElement checkProfileCta() {
		return profile_txt_add;
	}

	public void selectProfile(String profileType) {
		if (profileType.contains("Kid")) {
			ClickOnMobileElement(profile_btn_child);
		}
		else if (profileType.contains("Teen"))
		{
			ClickOnMobileElement(profile_btn_teen);
		}
		else if(profileType.contains("Adult"))
		{
			ClickOnMobileElement(profile_btn_teen);
		}
	}

	public void selectAvatar() {
		if (isElementPresent(profile_btn_avatar)) {
			ClickOnMobileElement(profile_btn_avatar);
		}
		if (isElementPresent(profile_img_avatar)) {
			ClickOnMobileElement(profile_img_avatar);
		}
	}

	public void setDisplayName(String displayname) {
		ClickOnMobileElement(profile_txt_displayname);
		SendKeysOnMobileElement(profile_txt_displayname, displayname);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			hideMobileKeyboard();
		} else {
			DriverManager.getDriver().navigate().back();
		}
	}

	public void setDisplayName1(String displayname) {
		ClickOnMobileElement(profile_txt_displayname1);
		SendKeysOnMobileElement(profile_txt_displayname1, displayname);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			hideMobileKeyboard();
		} else {
			DriverManager.getDriver().navigate().back();
		}
	}

	public void clickDonebutton() {
		ClickOnMobileElement(profile_btn_done);
//        if (isElementPresent(profile_btn_addconfirm)) {
//            ClickOnMobileElement(profile_btn_addconfirm);
//        }
//        if (isElementPresent(profile_btn_addconfirm)) {
//            ClickOnMobileElement(profile_btn_addconfirm);
//        }
//        if(isElementPresent(profileCreationConfirmationText)) {
//            ClickOnMobileElement(profileCreation_OKbtn);
//        }
	}

	public void clickProfileConfirmationPopup() {
		ClickOnMobileElement(profile_btn_confirm);
		if (isElementPresent(profile_btn_confirm)) {
			ClickOnMobileElement(profile_btn_confirm);
		}
	}

	public void enterPin() {
		ClickOnMobileElement(reg_pinCheck);
		SendKeysOnMobileElement(reg_pinCheck, "1234");
	}

	public void enterCardNumber(String username) {
		ClickOnMobileElement(register_txt_CardName);
		String newUserName = username + RandomStringGenerate();
		SendKeysOnMobileElement(register_txt_CardName, newUserName);
	}

	public String checkProfileLimitHeadertext() {
		return profileLimitHeaderText.getText();
	}

	public String checkProfileLimitMessage() {
		return profileLimitMessage.getText();
	}

	public void adultprofileSelection() {
		ClickOnMobileElement(profile_txt_profile1);
	}

	public void teenprofileSelection() {
		if(isElementPresent(profile_txt_profile2)) {
			ClickOnMobileElement(profile_txt_profile2);
		}
	}

	public void teen_1profileSelection() {
		if(isElementPresent(profile_txt_profile2)) {
			ClickOnMobileElement(profile_txt_profile2);
		}
	}

	public void kid_1profileSelection() {
		if(isElementPresent(profile_txt_profile2)) {
			ClickOnMobileElement(profile_txt_profile2);
		}
	}

	public void kidprofileSelection() {
		if(isElementPresent(profile_txt_profile3)) {
			ClickOnMobileElement(profile_txt_profile3);
		}
	}

//	public void kid_1profileSelection() {
//		if(isElementPresent(profile_txt_profile3)) {
//			ClickOnMobileElement(profile_txt_profile3);
//		}
//	}

	public MobileElement getRegister_txt_CardName() {
		return register_txt_CardName;
	}

	public void clickProfileImage() {
		ClickOnMobileElement(profileIcon);

	}

	public MobileElement checkProfilePinIsDisabled() {
		return profilePinIsDisabled;
	}

	public MobileElement verifyEnableProfilePinText() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(enableProfilePinText)) {
				break;
			} else {
				swipeDown();
			}
		}
		return enableProfilePinText;
	}

	public MobileElement enableProfilePinText() {
		return enableProfilePinText;
	}

	public MobileElement manageProfiles() {
		return profileEditOption;
	}

	public void clickEditOption() {
		ClickOnMobileElement(profileEditOption);
	}
	public void clickDisabledProfilePin() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(profilePinIsDisabled)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(profilePinIsDisabled);
	}

	public MobileElement verifyDisableProfilePinText() {
		return disableProfilePinText;
	}

	public MobileElement verifyParentalPinSetupText() {
		return parentalPinSetupText;
	}

	public void enterParentPin(String ParentPin) {
		ClickOnMobileElement(parentalPinSetup);
		SendKeysOnMobileElement(parentalPinSetup, ParentPin);
		ClickOnMobileElement(doneButton);
	}

	public MobileElement verifyConfirmPinSetupText() {
		return confirmPinSetupText;
	}

	public void enterConfirmPin(String pin) {
		ClickOnMobileElement(confirmPinSetup);
		SendKeysOnMobileElement(confirmPinSetup, pin);
		ClickOnMobileElement(doneButton);
	}

	public String verifyWrongPinMessage() {
		return wrongPinMessage.getText();
	}

	public MobileElement verifySuccessPinSetupMessage() {
		return correctPinMessage;
	}

	public void clearEmailValue() {
		profileEmailField.clear();
	}

	public MobileElement saveInPrfileSreen() {
		return editprofile_btn_save;
	}

	public void scrollToSaveButton() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(editprofile_btn_save)) {
				break;
			} else {
				swipeDown();
			}
		}
	}

	public void clickSaveButton() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(editprofile_btn_save)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(editprofile_btn_save);
	}

	public void clickDoneButton() {
		ClickOnMobileElement(DoneButton);
	}

	public MobileElement verifyAdultCheckoutToolTipIcon() {
		return adultCheckoutToolTipIcon;
	}

	public void clickAdultCheckoutToolTipIcon() {
		ClickOnMobileElement(adultCheckoutToolTipIcon);
	}

	public String verifyAdultCheckoutToolTipText() {
		return adultCheckoutToolTipText.getText();
	}

	public String verifyCheckoutToolTipText() {
		return adultCheckoutToolTipText.getText();
	}

	public void clickDismissOptionInCheckout() {
		ClickOnMobileElement(dismissOptionInCheckout);
	}

	public void clickCheckoutHoldCheckbox() {
		ClickOnMobileElement(checkoutHoldCheckbox);
	}

	public MobileElement verifyCheckoutHoldCheckbox() {
		return verifycheckoutHoldCheckbox;
	}

	public void enterEmailValue(String email) {
		ClickOnMobileElement(profileEmailField);
		SendKeysOnMobileElement(profileEmailField, email);
	}

	public void clickCloseButton() {
		ClickOnMobileElement(profiles_btn_back);
	}

	public void clickEnabledPin() {
		ClickOnMobileElement(enablePin);
	}

	public MobileElement getLogin_txt_validationError() {
		return login_txt_validationError;
	}

	public String checkDisablePinConfirmationPopupText() {
		return disablePinConfirmationPopupText.getText();
	}

	public String checkDisablePinConfirmationPopupTextTeen() {
		return disablePinConfirmationPopupText1.getText();
	}

	public void clickCancelInDisablePopup() {
		ClickOnMobileElement(cancelInDisablePopup);
	}

	public void clickYesInDisablePopup() {
		ClickOnMobileElement(yesInDisablePopup);
	}

	public void click_New_User() {
		ClickOnMobileElement(new_User);
	}

	public void click_Profile_Icon() {
		ClickOnMobileElement(profile_Icon);
	}

	public void click_Profile_Edit_Btn() {
		ClickOnMobileElement(profile_Edit_Btn);
	}

	public void select_Profile_Icon_Image() {
		ClickOnMobileElement(profile_Icon_Image);
	}

	public void click_Save_Btn() {
		ClickOnMobileElement(save_Btn);
	}

	public void click_Bottom_Menu() {
		waitFor(2000);
		ClickOnMobileElement(bottom_Menu);
	}

	public void select_Teen_Profile() {
		ClickOnMobileElement(profile_Option);
		waitFor(2000);
		ClickOnMobileElement(teen_Profile);
	}

	public void select_Teen() {
		ClickOnMobileElement(teen_Profile);
	}

	public void enter_Display_Name(String Display_Name) {
		ClickOnMobileElement(edit_Display_Name);
		SendKeysOnMobileElement(edit_Display_Name, Display_Name);
		hideMobileKeyboard();
		waitFor(2000);
		swipeDown();
		waitFor(2000);
		swipeDown();
	}

	public void enter_Valid_Pin(String validpin) {
		ClickOnMobileElement(edit_Display_Name);
		SendKeysOnMobileElement(edit_Display_Name, validpin);
		hideMobileKeyboard();
		waitFor(2000);
		swipeDown();
		waitFor(2000);
		swipeDown();
	}

	public void ClickTitle() {
		ClickOnMobileElement(clickTitle);
	}

	public MobileElement verifyPinDisableText() {
		return pinDisableText;
	}

	public MobileElement MyLibraryHomeScreen() {
		return myLibraryHomeScreen;
	}

	public MobileElement alsoAvailable() {
		return alsoAvailable;
	}

	public MobileElement alternateFormatSameTitle() {
		return alternateFormatSameTitle;
	}

	public MobileElement alternateFormatTitleCard() {
		return alternateFormatSameTitle;
	}

	public MobileElement profile_Selection_Registration() {
		return profile_Selection_Registration;
	}

	public MobileElement checkSecurityQuestionField() {
		return securityQuestion_drpd;
	}

	public MobileElement checkEmailField() {
		return register_txt_Email;
	}

	public String checkEmailVerificationPopup() {
		return emailVerificationPopup.getText();
	}

	public MobileElement get_Library_Card_Id() {
		return library_Card_Id;
	}

	public MobileElement get_Login_Pin() {
		return login_Pin;
	}

	public MobileElement get_Security_Question() {
		return security_Question;
	}

	public MobileElement get_User_Name() {
		return user_Name;
	}

	public MobileElement get_Login_Password() {
		return login_Password;
	}

	public MobileElement get_Security_Answer() {
		return security_Answer;
	}

	public MobileElement get_Display_Name() {
		return display_Name;
	}

	public MobileElement get_MyProfile_Screen() {
		return myProfile_Screen;
	}

	public String displayNameText() {
		return displayNameText.getText();
	}

	public MobileElement pinSubmitBtn() {
		return pinSubmitBtn;
	}

	public boolean checkAdminValue() {
		boolean result = false;

		if (adultProfileWithoutDisplayName.getText().contains("Admin")) {
			result = true;
		}
		return result;
	}

	public MobileElement success_Toast_Msg() {
		return success_Toast_Msg;
	}

	public MobileElement getNewregister_txt_DisplayName() {
		return register_txt_DisplayName;
	}

	public MobileElement teen_Same_Email_Adult() {
		return teen_Same_Email_Adult;
	}
	
	public MobileElement getReg_lbl_invalidlibraryPassword() {
		return reg_lbl_invalidlibraryPassword;
	}

	public MobileElement teen_Profile_Check() {
		return teen_Profile_Check;
	}

	public MobileElement kid_Profile_Check() {
		return kid_Profile_Check;
	}

	public void clickAdultProfile() {
		ClickOnMobileElement(adultProfile);
	}

	public void clickTeenProfile() {
		ClickOnMobileElement(teenProfile1);
	}

	public void clickKidProfile() {
		ClickOnMobileElement(kidProfile1);
	}

	public MobileElement profileDetailsType() {
		return profile_Details_Type;
	}

	public void enablePinAllProfiles() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(clickEnablePinAllProfiles)) {
				break;
			} else {
				swipeDown();
			}
		}

	}

	public void clickEnablePinAllProfiles() {
		ClickOnMobileElement(clickEnablePinAllProfiles);
	}

	public void enablePinAllProfilesToolTip() {
		ClickOnMobileElement(clickEnablePinAllProfilesToolTip);
	}

	public MobileElement enablePinToolTip() {
		return clickEnablePinAllProfilesToolTip;
	}

	public MobileElement enableToggleToolTip() {
		return adultCheckoutToolTipText;
	}

	public MobileElement enableProfilePinToolTip() {
		return enableProfilePinToolTip;
	}

	public MobileElement profile_Btn_Back() {
		return profiles_btn_back;
	}

	public void clickLearnMoreProfiles() {
		for(int i =0;i<5;i++) {
			if (isElementPresent(learnMoreProfile)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(learnMoreProfile);
	}

	public MobileElement aboutProfile() {
		return aboutProfiles;
	}

	public MobileElement profileSaveBtn() {
		return editprofile_btn_save;
	}

	public MobileElement invalidEmailWarningTxt() {
		return invalidEmailWarningTxt;
	}

	public void clickUnavailableTitle() {
		ClickOnMobileElement(unavailableTitle);
	}

	public MobileElement checkTitleDetails() {
		return titleDetails;
	}

	public MobileElement checkAddToWishlistCTA() {
		return addToWishlistCTA;
	}

	public void clickAddToWishlistCTA() {
		ClickOnMobileElement(addToWishlistCTA);
	}

	public MobileElement checkRemovefromWishlistCTA() {
		return removeFromWishlistCTA;
	}

	public void clickRemovefromWishlistCTA() {
		ClickOnMobileElement(removeFromWishlistCTA);
	}

	public void enablePinForProfiles() {

		if (!isElementPresent(enableProfilePinText)) {
			for (int i = 0; i < 4; i++) {
				if (isElementPresent(clickEnablePinAllProfiles)) {
					break;
				} else {
					swipeDown();
				}
			}
			ClickOnMobileElement(clickEnablePinAllProfiles);
			clickSaveButton();
		}
	}

	public void disablePinForProfiles() {
		if (isElementPresent(enableProfilePinText)) {
			clickEnablePinAllProfiles();
			clickSaveButton();
		}
	}

	public void readingPopupClose() {
		ClickOnMobileElement(readingPopupClose);
	}

	public void enterLibraryId(String libraryid) {
		SendKeysOnMobileElement(loc_txt_libraryId, libraryid);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
			ClickOnMobileElement(logo_btn_signin);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			try {
				ClickOnMobileElement(logo_btn_signin);
				logger.info("Keyboard is not hiding Sigin button its visible");
			} catch (Exception e) {
				logger.info("Hiding Keyboard");
				DriverManager.getDriver().navigate().back();
				ClickOnMobileElement(logo_btn_signin);
			}
		}
	}

	public void clicksigin() {
		ClickOnMobileElement(login.getLogo_btn_signin());
	}

	public void enterEmailandDisplayname(String email, String displayname) {
		ClickOnMobileElement(register_txt_DisplayName);
		SendKeysOnMobileElement(register_txt_DisplayName, displayname);
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			DriverManager.getDriver().navigate().back();
			swipeDown();
		}
		ClickOnMobileElement(register_txt_Email);
		SendKeysOnMobileElement(register_txt_Email, email);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			hideMobileKeyboard();
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			DriverManager.getDriver().navigate().back();
			swipeDown();
		}
	}

	public void enterLibCardId(String libID) {
		register_txt_CardName.clear();
		SendKeysOnMobileElement(register_txt_CardName, libID);
	}

	public void clickRegister() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(library_btn_Register);
		} else {
			ClickOnMobileElement(library_btn_Register);
		}
	}

	public void onlylibrarywithEmailandDisplayname(String email, String displayname) {
		ClickOnMobileElement(register_txt_DisplayName);
		SendKeysOnMobileElement(register_txt_DisplayName, displayname);
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			DriverManager.getDriver().navigate().back();
			swipeDown();
		}
		ClickOnMobileElement(register_txt_Email);
		SendKeysOnMobileElement(register_txt_Email, email);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			hideMobileKeyboard();
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			DriverManager.getDriver().navigate().back();
			swipeDown();
		}
	}

	public void removeCardName() {
		ClickOnMobileElement(register_txt_CardName);
		register_txt_CardName.clear();
		swipeDown();
	}

	public void enterUserNamePassword(String userName, String password) {
//		SendKeysOnMobileElement(login_txt_username, "");
//		SendKeysOnMobileElement(login_txt_password, "");
	}

	public void skipEmailandDisplayname(String email, String displayname) {
		ClickOnMobileElement(register_txt_DisplayName);
		SendKeysOnMobileElement(register_txt_DisplayName, "");
		ClickOnMobileElement(register_txt_Email);
		SendKeysOnMobileElement(register_txt_Email, "");
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			DriverManager.getDriver().navigate().back();
		}
	}

	public void existingUserLibraryId(String libraryid) {
		SendKeysOnMobileElement(login.getSignIn_txt_libId(), libraryid);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
		}
		swipeDown();
	}

	public void faceIdPopHandle() {
		try {
			ClickOnMobileElement(logo_btn_enableFaceID);
			ClickOnMobileElement(logo_btn_faceIDnotNow);
			ClickOnMobileElement(logo_btn_faceIDdisablePeremanent);
		} catch (Exception e) {
			logger.info("Enable faceID pop not displayed");
		}
	}

	public void selectAgegroup(String agegrp) {
		swipeDown();
		System.out.println(agegrp);
		if (agegrp.equalsIgnoreCase("Adult")) {
			ClickOnMobileElement(reg_btn_adult);
		} else if (agegrp.equalsIgnoreCase("teen")) {
			ClickOnMobileElement(reg_btn_teen);
		} else if (agegrp.equalsIgnoreCase("kid")) {
			ClickOnMobileElement(reg_btn_kid);
		}
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			// DriverManager.getDriver().navigate().back();
			swipeDown();
		}
	}

	public void editCardNumber(String cardnumber) {
		WaitForMobileElement(register_txt_CardName);
		register_txt_CardName.clear();
		SendKeysOnMobileElement(register_txt_CardName, cardnumber);
	}

	public void clickRegisterCTA() {

		WaitForMobileElement(library_btn_Register);
		ClickOnMobileElement(library_btn_Register);
	}
	
	public void clickPasswordLink() {
		ClickOnMobileElement(reg_lbl_librarypasswordLink);
	}
	
	public MobileElement getLib_btn_Register() {
		return library_btn_Register;
	}

	public void enterLibraryPassword(String password) {
		ClickOnMobileElement(reg_txt_libraryPassword);
		SendKeysOnMobileElement(reg_txt_libraryPassword, password);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")){
			ClickOnMobileElement(logo_btn_Done);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")){
			DriverManager.getDriver().navigate().back();
		}
	}
	
	public void enterinvalidLibraryPassword(String password) {
		ClickOnMobileElement(reg_txt_libraryPassword);
		SendKeysOnMobileElement(reg_txt_libraryPassword, password);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")){
			ClickOnMobileElement(logo_btn_Done);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")){
			DriverManager.getDriver().navigate().back();
		}
	}
	
	public void searchLibraryName(String libraryid) {
		SendKeysOnMobileElement(logo_txt_search, libraryid);
		ClickOnMobileElement(logo_txt_IndependentLibrary);
		ClickOnMobileElement(logo_txt_matchingLibrary);
		if (isElementPresent(logo_txt_matchingLibrary)) {
			ClickOnMobileElement(logo_txt_matchingLibrary);
		}
	}
	

	public void enterRegisterpin(String pin) {
		ClickOnMobileElement(reg_txt_pin);
		SendKeysOnMobileElement(reg_txt_pin, pin);
	}
	
	public void enterlibrarycardandpassword(String librarycard, String password) {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			WaitForMobileElement(register_txt_CardName);
			SendKeysOnMobileElement(register_txt_CardName, librarycard+RandomStringGenerate());
			ClickOnMobileElement(reg_txt_libraryPassword);
			SendKeysOnMobileElement(reg_txt_libraryPassword, password);
		}
		else {
			ClickOnMobileElement(newReg_txt_libraryId);
			SendKeysOnMobileElement(newReg_txt_libraryId, librarycard+RandomStringGenerate());
			try {
				ClickOnMobileElement(loc_txt_libraryPin);
				SendKeysOnMobileElement(loc_txt_libraryPin, password);
			}
			catch (Exception e) {
				System.out.println("password field element not visible");
				ClickOnMobileElement(reg_txt_pin);
				SendKeysOnMobileElement(reg_txt_pin, password);
			}		
			swipeDown();
			swipeDown();
		}
	}

	public void enterRandomPrefixandpin(String prefixid, String pin, String special) {
		ClickOnMobileElement(loc_txt_libraryId);
		SendKeysOnMobileElement(loc_txt_libraryId, prefixid + RandomStringGenerateAscii() + special);
		ClickOnMobileElement(loc_txt_libraryPin);
		SendKeysOnMobileElement(loc_txt_libraryPin, pin);

		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			ClickOnMobileElement(logo_btn_Done);
			ClickOnMobileElement(logo_btn_signin);
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			try {
				ClickOnMobileElement(logo_btn_signin);
				logger.info("Keyboard is not hiding Sigin button its visible");
			} catch (Exception e) {
				logger.info("Hiding Keyboard");
				DriverManager.getDriver().navigate().back();
				ClickOnMobileElement(logo_btn_signin);
			}
		}
	}

}
