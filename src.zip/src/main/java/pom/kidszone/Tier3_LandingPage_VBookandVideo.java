package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Tier3_LandingPage_VBookandVideo extends CommonActions {

	public Tier3_LandingPage_VBookandVideo(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);


	String title ="";

	// ***************************Locators************************************************//

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Video \"]/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther//XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Video')]/parent::android.view.ViewGroup/parent::android.view.ViewGroup")
	private MobileElement videoTitleImageInTier3;

	// @iOSXCUITFindBy(accessibility = " Vbook")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"adp_card_footer_title_text\"]/parent:: XCUIElementTypeOther/parent::XCUIElementTypeOther//XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'adp_card_footer_title_text')]/parent::android.view.ViewGroup/preceding-sibling::android.view.ViewGroup")
	private MobileElement vBookTitleImageInTier3;

	@iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='tier_3_txtTitle']")
	private MobileElement tier3TitleHeader;

	@iOSXCUITFindBy(accessibility = "txtCheckoutHeader")
	@AndroidFindBy(xpath = "//*[@resource-id='txtCheckoutHeader']")
	private MobileElement currentlyCheckedOutSection;

	@iOSXCUITFindBy(accessibility = "txtBookTitle0")
	@AndroidFindBy(xpath = "//*[@resource-id='txtBookTitle0']")
	private MobileElement currentlyCheckedOutTitleName;

	@iOSXCUITFindBy(accessibility = "txtAuthorName0")
	@AndroidFindBy(xpath = "//*[@resource-id='txtAuthorName0']")
	private MobileElement currentlyCheckedOutAuthorName;

	@iOSXCUITFindBy(accessibility = "txtAuthorName0")
	@AndroidFindBy(xpath = "//*[@id='btnVideoPrevious']")
	private WebElement videoBackwardIcon;

	@iOSXCUITFindBy(accessibility = "txtAuthorName0")
	@AndroidFindBy(xpath = "//*[@id='btnVideoNext']")
	private WebElement videoForwardIcon;

	// @iOSXCUITFindBy(accessibility = " Vbook")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='adp_card_footer_title_text']/parent::XCUIElementTypeOther/preceding-sibling::XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='adp_card_footer_title_text']")
	private MobileElement vBookTitleIconInTier3;

	// @iOSXCUITFindBy(accessibility = " Video")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='adp_card_footer_title_text']/parent::XCUIElementTypeOther/preceding-sibling::XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='adp_card_footer_title_text']")
	private MobileElement videoTitleIconInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_author")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"AUTHOR\"]")
	private MobileElement authortextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_author_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"AUTHOR\"]")
	private MobileElement authorValueInTier3;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkout')]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Checkout\"])[1]")
	private MobileElement checkoutBtnInTier3;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_title_details_play_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Play\"])[1]")
	private MobileElement playBtnInTier3;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_title_details_resume_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Resume\"])[1]")
	private MobileElement resumeBtnInTier3;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_title_details_renew_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Renew\"])[1]")
	private MobileElement renewBtnInTier3;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_title_details_return_cta')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Return\"])[1]")
	private MobileElement returnBtnInTier3;

	@iOSXCUITFindBy(accessibility = "Renew")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"NARRATOR\"]")
	private MobileElement narratortextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_edition")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"EDITION\"]")
	private MobileElement editiontextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_edition_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"EDITION\"]")
	private MobileElement editionValueInTier3;

	@iOSXCUITFindBy(accessibility = "Renew")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"VIDEO LENGTH\"]")
	private MobileElement videoLengthtextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_file_size")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"FILE SIZE\"]")
	private MobileElement fileSizetextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_file_size_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"FILE SIZE\"]")
	private MobileElement fileSizeValueInTier3;

	@iOSXCUITFindBy(accessibility = "Renew")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"ATTRIBUTE\"]")
	private MobileElement attributetextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_audience_type")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"AUDIENCE TYPE\"]")
	private MobileElement audienceTypetextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_audience_type_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"AUDIENCE TYPE\"]")
	private MobileElement audienceTypeValueInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_series")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"SERIES\"]")
	private MobileElement seriestextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_series_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"SERIES\"]")
	private MobileElement seriesValueInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_format")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"FORMAT\"]")
	private MobileElement formattextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_format_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"FORMAT\"]")
	private MobileElement formatValueInTier3;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_title_details_language')]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"LANGUAGE CODE\"]")
	private MobileElement languageCodetextInTier3;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_title_details_language_value')]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"LANGUAGE CODE\"]")
	private MobileElement languageCodeValueInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_isbn")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"ISBN\"]")
	private MobileElement isbntextInTier3;

	@iOSXCUITFindBy(accessibility = "adp_card_title_details_isbn_value")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"ISBN\"]")
	private MobileElement isbnValueInTier3;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_header_')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'third_party_header_')]")
	private MobileElement titleSeriesHeaderInTier3;

	@iOSXCUITFindBy(accessibility = "third_party_see_all_link")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'third_party_see_all_link')])[1]")
	private MobileElement vBookSeeAllCTAInTier3;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header\"]")
	private MobileElement tier2vBookTitleHeader;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header\"]")
	private MobileElement tier2VideoTitleHeader;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header\"]")
	private MobileElement tier2vBookTitlesList;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header\"]")
	private MobileElement tier2VideoTitlesList;

	@iOSXCUITFindBy(accessibility = "third_party_see_all_link")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'third_party_see_all_link')])[1]")
	private MobileElement videoSeeAllCTAInTier3;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name,'third_party_header')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'third_party_header')])[1]")
	private MobileElement title3RelatedCarouselHeader;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name,'adp_card_book_title')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.TextView[contains(@resource-id,'adp_card_book_title')])[1]")
	private MobileElement title3Relatedvbook;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.Button[contains(@resource-id,'adp_card_image')])[1]")
	private MobileElement title3Relatedvbook1;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Video\"])[1]/following-sibling::XCUIElementTypeOther[2]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Videos')]")
	private MobileElement title3RelatedVideo;

	@iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id=\"tier_3_txtTitle\"]")
	private MobileElement confirmTitle;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id=\"btnBackIcon\"]")
	private MobileElement backIcon;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "//*[@content-desc='Title in this Seriesheading.(10 results), ']")
	private MobileElement tier3VideoTitlesList;

	@iOSXCUITFindBy(accessibility = "third_party_header")
	@AndroidFindBy(xpath = "(//*[contains(@content-desc,'More Like ThisHeading, ')])[1]")
	private MobileElement tier3VideoHeadingListMore;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Title in this Series')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Title in this series')]")
	private MobileElement tier3VideoHeadingListTitle;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Title in this Series')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Title in this series')]")
	private MobileElement tier3TitleInThisSeriesText;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Title in this Series')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Title in this series')]")
	private MobileElement tier3TitleInThisSeriesSeeAllLink;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'third_party_see_all_link')])[1]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'More Like Thisheading')]")
	private MobileElement tier3MoreLikeThisText;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'third_party_see_all_link_Recommend')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'More Like Thisheading')]")
	private MobileElement tier3MoreLikeThisSeeAllLink;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Video']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'video, ')]")
	private MobileElement Video_pasue;

	@iOSXCUITFindBy(accessibility = "Play/Pause")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'video play or pause, ')]")
	private MobileElement play_pasue;

	@iOSXCUITFindBy(accessibility = "Skip Forward")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'video forward, ')]")
	private MobileElement skip_Forward;

	@iOSXCUITFindBy(accessibility = "Skip Backward")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'video backward, ')]")
	private MobileElement skip_Backward;

	@iOSXCUITFindBy(accessibility = "Fullscreen Button")
	@AndroidFindBy(xpath = "//*[@resource-id=\"Fullscreen Button\"]")
	private MobileElement full_ScreenButton;

	@iOSXCUITFindBy(accessibility = "Mute/Unmute")
	@AndroidFindBy(xpath = "//*[@resource-id=\"Mute/Unmute\"]")
	private MobileElement mute_Unmute;

	@iOSXCUITFindBy(accessibility = "Elapsed Time")
	@AndroidFindBy(xpath = "//*[@resource-id=\"Elapsed Time\"]")
	private MobileElement elapsed_Time;

	@iOSXCUITFindBy(accessibility = "Current position")
	@AndroidFindBy(xpath = "//*[@resource-id=\"Current position\"]")
	private MobileElement current_Position;

	@iOSXCUITFindBy(accessibility = "Remaining Time")
	@AndroidFindBy(xpath = "//*[@resource-id=\"Remaining Time\"]")
	private MobileElement remaining_Time;
	
	

	public MobileElement getVideo_pasue() {
		return Video_pasue;
	}

	public MobileElement getSkip_Forward() {
		return skip_Forward;
	}

	public MobileElement getSkip_Backward() {
		return skip_Backward;
	}

	public MobileElement getFull_ScreenButton() {
		return full_ScreenButton;
	}

	public MobileElement getMute_Unmute() {
		return mute_Unmute;
	}

	public MobileElement getElapsed_Time() {
		return elapsed_Time;
	}

	public MobileElement getRemaining_Time() {
		return remaining_Time;
	}

	public MobileElement getPlay_pasue() {
		return play_pasue;
	}

	public MobileElement checkVideoTitleImageInTier3() {
		return videoTitleImageInTier3;
	}

	public MobileElement checkvBookTitleImageInTier3() {
		return vBookTitleImageInTier3;
	}

	public MobileElement checkTier3TitleHeader() {
		return tier3TitleHeader;
	}

	public MobileElement checkvBookTitleIconInTier3() {
		return vBookTitleIconInTier3;
	}

	public MobileElement checkvideoTitleIconInTier3() {
		return videoTitleIconInTier3;
	}

	public MobileElement checkAuthortextInTier3() {
		return authortextInTier3;
	}

	public MobileElement checkAuthorValueInTier3() {
		return authorValueInTier3;
	}

	public MobileElement checkCheckoutBtnInTier3() {
		return checkoutBtnInTier3;
	}

	public void clickCheckoutBtnInTier3() {
		ClickOnMobileElement(checkoutBtnInTier3);
	}

	public MobileElement checkPlayBtnInTier3() {
		return playBtnInTier3;
	}

	public void clickPlayBtnInTier3() {
		ClickOnMobileElement(playBtnInTier3);
	}

	public MobileElement checkResumeBtnInTier3() {
		return resumeBtnInTier3;
	}

	public void clickResumeBtnInTier3() {
		ClickOnMobileElement(resumeBtnInTier3);
	}

	public MobileElement checkRenewBtnInTier3() {
		return renewBtnInTier3;
	}

	public MobileElement clickRenewBtnInTier3() {
		return renewBtnInTier3;
	}

	public MobileElement checkReturnBtnInTier3() {
		return returnBtnInTier3;
	}

	public void clickReturnBtnInTier3() {
		swipeDown();
		ClickOnMobileElement(returnBtnInTier3);
	}

	public MobileElement checkNarratortextInTier3() {
		return narratortextInTier3;
	}

	public MobileElement checkEditiontextInTier3() {
		return editiontextInTier3;
	}

	public MobileElement checkEditionValueInTier3() {
		return editionValueInTier3;
	}

	public MobileElement checkVideoLengthtextInTier3() {
		return videoLengthtextInTier3;
	}

	public MobileElement checkFileSizetextInTier3() {
		return fileSizetextInTier3;
	}

	public MobileElement checkFileSizeValueInTier3() {
		return fileSizeValueInTier3;
	}

	public MobileElement checkAttributetextInTier3() {
		return attributetextInTier3;
	}

	public MobileElement checkAudienceTypetextInTier3() {
		return audienceTypetextInTier3;
	}

	public MobileElement checkAudienceTypeValueInTier3() {
		return audienceTypeValueInTier3;
	}

	public MobileElement checkSeriestextInTier3() {
		return seriestextInTier3;
	}

	public MobileElement checkSeriesValueInTier3() {
		return seriesValueInTier3;
	}

	public MobileElement checkFormattextInTier3() {
		return formattextInTier3;
	}

	public MobileElement checkFormatValueInTier3() {
		return formatValueInTier3;
	}

	public MobileElement checkLanguageCodetextInTier3() {
		return languageCodetextInTier3;
	}

	public MobileElement checkLanguageCodeValueInTier3() {
		return languageCodeValueInTier3;
	}

	public MobileElement checkISBNtextInTier3() {
		return isbntextInTier3;
	}

	public MobileElement checkISBNValueInTier3() {
		return isbnValueInTier3;
	}

	public MobileElement checkTitleSeriesInTier3() {
		return titleSeriesHeaderInTier3;
	}

	public void clickvBookSeeAllCTAInTier3() {
		ClickOnMobileElement(vBookSeeAllCTAInTier3);
	}

	public MobileElement checkTier2vBookTitleHeader() {
		return tier2vBookTitleHeader;
	}

	public MobileElement checkTier2vBookTitlesList() {
		return tier2vBookTitlesList;
	}

	public void clickVideoSeeAllCTAInTier3() {
		ClickOnMobileElement(videoSeeAllCTAInTier3);
	}

	public MobileElement checkvBookSeeAllCTAInTier3() {
		return vBookSeeAllCTAInTier3;
	}

	public MobileElement checkVideoSeeAllCTAInTier3() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(videoSeeAllCTAInTier3)) {
				break;
			} else {
				swipeDown();
			}
		}
		return videoSeeAllCTAInTier3;
	}

	public MobileElement checkTier2VideoTitleHeader() {
		return tier2VideoTitleHeader;
	}

	public MobileElement checkTier2VideoTitlesList() {
		return tier2VideoTitlesList;
	}

	public void videoPasue() {
		if(!isElementPresent(play_pasue))
		{
		ClickOnMobileElement(Video_pasue);	
		}
		ClickOnMobileElement(Video_pasue);	
		
	}

	public boolean checkTitle3RelatedCarouselHeader() {
		boolean relatedTitle = true;
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(title3RelatedCarouselHeader)) {
				relatedTitle = true;
				swipeDown();
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		return relatedTitle;
	}

	public void verifyTitle3RelatedVBook() {
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			String vBookTitle = title3Relatedvbook.getText().trim();
			ClickOnMobileElement(title3Relatedvbook1);
			waitFor(4000);
//			String confirmvBookTitle = confirmTitle.getText().trim();
//			logger.info(vBookTitle);
//			logger.info(confirmvBookTitle);
//			Assert.assertTrue(vBookTitle.equalsIgnoreCase(confirmvBookTitle));
		} else {
//			String vBookTitle = title3Relatedvbook.getAttribute("value");
			ClickOnMobileElement(title3Relatedvbook1);
			waitFor(4000);
//			String confirmvBookTitle = confirmTitle.getText();
//			logger.info(vBookTitle);
//			Assert.assertTrue(
//					vBookTitle.equalsIgnoreCase(confirmvBookTitle.substring(0, confirmvBookTitle.length() - 7)));
		}
	}

	public void verifyTitle3RelatedVideo() {
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			String[] videoTitle = title3RelatedVideo.getAttribute("content-desc").split(" ", 2);
			logger.info(videoTitle[1]);
			ClickOnMobileElement(title3RelatedVideo);
			waitFor(4000);
			String confirmvideoTitle = confirmTitle.getText();
			Assert.assertTrue(videoTitle[1].equalsIgnoreCase(confirmvideoTitle));
		} else {

		}
	}

	public MobileElement checkTier3VideoTitlesList() {
		return tier3VideoTitlesList;
	}

	public MobileElement tier3VideoHeadingListMore() {
		return tier3VideoHeadingListMore;
	}

	public MobileElement tier3VideoHeadingListTitle() {
		return tier3VideoHeadingListTitle;
	}

	public MobileElement checkTier3TitleInThisSeriesText() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(tier3TitleInThisSeriesText)) {
				break;
			} else {
				swipeDown();
			}
		}
		return tier3TitleInThisSeriesText;
	}

	public void clickTier3TitleInThisSeeAllLink() {
		ClickOnMobileElement(tier3TitleInThisSeriesSeeAllLink);
	}

	public void clickBackIcon() {
		ClickOnMobileElement(backIcon);
	}

	public MobileElement verifyTier3TitleInThisSeeAllLink() {
		return tier3TitleInThisSeriesSeeAllLink;
	}

	public void clickTier3MoreLikeThisSeeAllLink() {
		ClickOnMobileElement(tier3MoreLikeThisSeeAllLink);
	}

	public MobileElement verifyTier3MoreLikeThisSeeAllLink() {
		return tier3MoreLikeThisSeeAllLink;
	}

	public MobileElement checkTier3TMoreLikeThisText() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(tier3MoreLikeThisText)) {
				break;
			} else {
				swipeDown();
			}
		}
		return tier3MoreLikeThisText;
	}

	public String getTitle() {
		String getTitle = tier3TitleHeader.getText();
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			title = getTitle.trim();
		} else {
			title = getTitle.substring(0, getTitle.length() - 7).trim();
		}
		logger.info(title);
		return getTitle;
	}

	public MobileElement checkCurrentlyCheckedOutSection() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(currentlyCheckedOutSection)) {
				break;
			} else {
				swipeDown();
			}
		}
		return currentlyCheckedOutSection;
	}

	public void verifyCheckedOutTitle() {
		String confirmTitle = currentlyCheckedOutTitleName.getText().trim();
		System.out.println("kdkdkd"+confirmTitle);
		System.out.println("Tillr"+title);
		Assert.assertTrue(title.contains(confirmTitle));
	}

	public MobileElement verifyCheckedOutTitleAuthorName() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(currentlyCheckedOutAuthorName)) {
				break;
			} else {
				swipeDown();
			}
		}
		return currentlyCheckedOutAuthorName;
	}

	public void clickVideoForwardIcon() {
		jsClick(videoForwardIcon);
	}

	public void clickVideoBackwardIcon() {
		jsClick(videoBackwardIcon);
	}


	public void checkoutTitle() {
		if(isElementPresent(checkCheckoutBtnInTier3())) {
			 title=getTitle();
			ClickOnMobileElement(checkCheckoutBtnInTier3());
			waitFor(5000);
			clickBackIcon();
		}
		else {
			clickReturnBtnInTier3();
			 title= getTitle();
			ClickOnMobileElement(checkCheckoutBtnInTier3());
			waitFor(5000);
			clickBackIcon();
		}
	}
}
