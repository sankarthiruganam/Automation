package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class WishList extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(WishList.class);

	public WishList(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(id = "//*[@text='WISHLIST']")
	private MobileElement wishList_lbl_title;

	@iOSXCUITFindBy(accessibility = "btnWishList")
	@AndroidFindBy(xpath = "//*[@resource-id='btnWishList']")
	private MobileElement wishlist_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_atoz']")
	private MobileElement sort_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_atoz']")
	private MobileElement sort_lbl_atoz;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_defaultlatest']")
	private MobileElement sort_lbl_defaultlatest;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='sort_lbl_latestadded']")
	private MobileElement sort_lbl_latestadded;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='sortTitles_lbl']")
	private MobileElement sortTitles_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement sort_lbl_viewTitles;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement ratingOption_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement ratingSelected_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement optionAtoZ_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement viewTitlesAtoZ_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement viewOptionSelected_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement checkoutTitle_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement updateWishlist_lbl;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "DUMMY")
	private MobileElement countMatchTitle_lbl;

	@iOSXCUITFindBy(accessibility = "Download_toggle_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='Download_toggle_test_id0']")
	private MobileElement primary_button;
	
	@iOSXCUITFindBy(accessibility = "ADD_TO_WISH_LIST")
	@AndroidFindBy(xpath = "//*[@resource-id='ADD_TO_WISH_LIST']")
	private MobileElement addtoWishList;
	
	@iOSXCUITFindBy(accessibility = "REMOVE_WISHLIST")
	@AndroidFindBy(xpath = "//*[@resource-id='REMOVE_WISHLIST']")
	private MobileElement removeWishList;

	@iOSXCUITFindBy(accessibility = "Download_handler_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='Download_handler_test_id0']")
	private MobileElement secondary_button;

	@iOSXCUITFindBy(accessibility = "REMOVE_WISHLIST")
	@AndroidFindBy(xpath = "//*[@resource-id='REMOVE_WISHLIST']")
	private MobileElement remove_wishList;
	
	@iOSXCUITFindBy(accessibility = "ADD_TO_WISH_LIST")
	@AndroidFindBy(xpath = "//*[@resource-id='ADD_TO_WISH_LIST']")
	private MobileElement add_wishList;
	
//	REMOVE_HOLD
	
//	WISH_SUSPEND_NOW

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"loc_txtImageCoverBook loc_lnkAuthor\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='REMOVE_WISHLIST']")
	private MobileElement image_coverDetails;
	
	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement close_btn;
	
	@iOSXCUITFindBy(accessibility = "READ_ONLINE")
	@AndroidFindBy(xpath = "//*[@resource-id='READ_ONLINE']")
	private MobileElement Checkout_Read_Online_btn;
	
	@iOSXCUITFindBy(accessibility = "RETURN_CHECKOUT")
	@AndroidFindBy(xpath = "//*[@resource-id='RETURN_CHECKOUT']")
	private MobileElement Checkout_Return_Checkout_btn;
	
	@iOSXCUITFindBy(accessibility = "RENEW_CHECKOUT")
	@AndroidFindBy(xpath = "//*[@resource-id='RENEW_CHECKOUT']")
	private MobileElement Checkout_Renew_Checkout_btn;
	
	
	public MobileElement getCheckout_Renew_Checkout_btn() {
		return Checkout_Renew_Checkout_btn;
	}
	
	public MobileElement getCheckout_Read_Online_btn() {
		return Checkout_Read_Online_btn;
	}
	
	
	public MobileElement getCheckout_Return_Checkout_btn() {
		return Checkout_Return_Checkout_btn;
	}
	
	
	public MobileElement getImage_coverDetails() {
		return image_coverDetails;
	}


	public MobileElement getPrimary_button() {
		return primary_button;
	}

	public MobileElement getSecondary_button() {
		return secondary_button;
	}

	public MobileElement getWishList_lbl_title() {
		return wishList_lbl_title;
	}
	
	public MobileElement getadd_wishList() {
		return add_wishList;
	}

	/******************** Action methods *************************/

	public void clickMoreoptions() {
		if (isElementPresent(primary_button)) {
			ClickOnMobileElement(primary_button);
		}
	}
	
	public void clickReadonline() {
		if (isElementPresent(Checkout_Read_Online_btn)) {
			ClickOnMobileElement(Checkout_Read_Online_btn);
		}
	}
	
	public void clickReturn_checkout() {
		if (isElementPresent(Checkout_Return_Checkout_btn)) {
			ClickOnMobileElement(Checkout_Return_Checkout_btn);
		}
	}
	public void clickRenew_Checkout() {
		if (isElementPresent(Checkout_Renew_Checkout_btn)) {
			ClickOnMobileElement(Checkout_Renew_Checkout_btn);
		}
	}
	
	
	public void clickSecondaryButton() {
		if (isElementPresent(secondary_button)) {
			ClickOnMobileElement(secondary_button);
		}
	}

	public void removeList() {
		if (isElementPresent(remove_wishList)) {
			ClickOnMobileElement(remove_wishList);
		}
		else{
			ClickOnMobileElement(add_wishList);
		}
	}

	public void clickWishList() {
		WaitForMobileElement(wishlist_lbl);
		ClickOnMobileElement(wishlist_lbl);
	}

	public void clickSort() {
		ClickOnMobileElement(sort_lbl);
	}

	public void sortatoz() {
		ClickOnMobileElement(sort_lbl_atoz);
	}

	public void sortDefaultLatest() {
		ClickOnMobileElement(sort_lbl_defaultlatest);
	}

	public void sortLatestadded() {
		ClickOnMobileElement(sort_lbl_latestadded);
	}

	public void sortViewTitles() {
		ClickOnMobileElement(sort_lbl_viewTitles);
	}

	public void sortTitles() {
		ClickOnMobileElement(sortTitles_lbl);
	}

	public void ratingOption() {
		ClickOnMobileElement(ratingOption_lbl);
	}

	public void ratingSelected() {
		ClickOnMobileElement(ratingSelected_lbl);
	}

	public void optionAtoZ() {
		ClickOnMobileElement(optionAtoZ_lbl);
	}

	public void viewTitlesAtoZ() {
		ClickOnMobileElement(viewTitlesAtoZ_lbl);
	}

	public void viewOptionSelected() {
		ClickOnMobileElement(viewOptionSelected_lbl);
	}

	public void checkoutTitle() {
		ClickOnMobileElement(checkoutTitle_lbl);
	}

	public void updateWishlist() {
		ClickOnMobileElement(updateWishlist_lbl);
	}

	public void countMatchTitle() {
		ClickOnMobileElement(countMatchTitle_lbl);
	}

	public void clickprimaryoptions() {
		if(isElementPresent(primary_button))
		{
			ClickOnMobileElement(primary_button);
		}
	}
	
	public void clickaddtoWishList() {
		if(isElementPresent(addtoWishList))
		{
			ClickOnMobileElement(addtoWishList);
		}
		swipeDown();
	}
	
	public void clickremoveWishList() {
		if(isElementPresent(removeWishList))
		{
			ClickOnMobileElement(removeWishList);
		}
	}
	
	public void closeBtnOption(){
		if(isElementPresent(close_btn)) {
				ClickOnMobileElement(close_btn);
		}
}
}
