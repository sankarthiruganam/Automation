package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pom.kidszone.*;

public class AboutandLegel_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	AboutandLegel about = new AboutandLegel(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	MyLibrary myLib = new MyLibrary(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/********************** 125198 ******************************/

	@Then("user clicks on adult profile and get redirected to the home page")
	public void user_clicks_on_adult_profile_and_get_redirected_to_the_home_page() {
		login.homePgNav();
	}

	@Then("user clicks on teen profile and get redirected to the home page")
	public void user_clicks_on_teen_profile_and_get_redirected_to_the_home_page() {
		login.homePgNav();
	}

	@Then("user clicks on kid profile and get redirected to the home page")
	public void user_clicks_on_kid_profile_and_get_redirected_to_the_home_page() {
		login.homePgNav();
	}

	@Then("user click the about option")
	public void user_click_the_about_option() {
		about.clickonAbout();
		logger.info("User is on My Library screen");
	}

	@Then("user navigates to library screen")
	public void user_navigates_to_library_screen() {
		myLib.clickMylibrary();
		logger.info("User is on My Library screen");
	}

	@Then("user should be able to view always available collection carousel with adult profile specific theme")
	public void user_should_be_able_to_view_always_available_collection_carousel_with_adult_profile_specific_theme() {
		logger.info("Theaming Validation");
	}

	@Then("user should be able to view featured titles in always available collection carousel")
	public void user_should_be_able_to_view_featured_titles_in_always_available_collection_carousel() {
		for(int i = 0;i<=10;i++) {
			if(isElementPresent(myLib.getMyLib_lbl_alwaysAvlHeader())) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(myLib.getMyLib_lbl_alwaysAvlHeader());
		if(isElementPresent(myLib.getMyLib_lbl_alwaysAvlHeader())) {
		Assert.assertEquals(myLib.getMyLib_lbl_alwaysAvlHeader().isDisplayed(), true);
		}
		logger.info("user is able to see list of titles in alwys avl carousel");
	}

	@Then("user should be able to view brief description for the carousel")
	public void user_should_be_able_to_view_brief_description_for_the_carousel() {
		logger.info("user is able to see brief description");
	}

	@Then("user should view titles in the always available section based on user adult profile type only")
	public void user_should_view_titles_in_the_always_available_section_based_on_user_adult_profile_type_only() {
		logger.info("user should view titles in the always available section");
	}

	@Then("user should be able to click on view all cta and navigate to always available collection list screen")
	public void user_should_be_able_to_click_on_view_all_cta_and_navigate_to_always_available_collection_list_screen() {
		myLib.clickOnalwaysAvlViewAll();
	}
	@Then("user should not view always available collection if not enabled for the library")
	public void user_should_not_view_always_available_collection_if_not_enabled_for_the_library() {
		swipeDown();
		swipeDown();
		if(isElementPresent(myLib.getMyLib_lbl_alwaysAvlListingPgHeader())) {
		Assert.assertEquals((myLib.alwaysAvailablecheck()), false);
		}
	}
	@Then("user should view always available collection if enabled for the library")
	public void user_should__view_always_available_collection_if_enabled_for_the_library() {
		swipeDown();
		swipeDown();
		if(isElementPresent(myLib.getMyLib_lbl_alwaysAvlListingPgHeader())) {
		Assert.assertEquals((myLib.alwaysAvailablecheck()), true);
		}
	}
}
