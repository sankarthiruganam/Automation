package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Downloads;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;
import pom.kidszone.PurchaseRequest;

public class Downloads_StepDef extends CommonActions{
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MyCheckouts checkout=new MyCheckouts(DriverManager.getDriver());
	PurchaseRequest purchase = new PurchaseRequest(DriverManager.getDriver());
	Downloads download = new Downloads(DriverManager.getDriver());
	
	public static final Logger logger = LoggerFactory.getLogger(WishList_StepDef.class);
	
    @When("user clicks on Download quick CTA in the My shelf screen")
    public void user_clicks_on_download_quick_cta_in_the_my_shelf_screen() throws Throwable {
    	login.handleNothankspopup();
		goals.clickOnMyshelfFooter();
		purchase.clickPurchaseRequest();
		download.clickDownloadsCta();
    }

    @Then("user should be able to view titles or publications listed as grid view by and sorted by latest publication or title downloaded first by default")
    public void user_should_be_able_to_view_titles_or_publications_listed_as_grid_view_by_and_sorted_by_latest_publication_or_title_downloaded_first_by_default() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_gridView()), true);
    }

    @And("user lands on Downloads screen")
    public void user_lands_on_downloads_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(download.getDownload_page()), true);
    }

    @And("user switch to grid view for Downloads screen")
    public void user_switch_to_grid_view_for_downloads_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_listView()), true);
		purchase.clickPurchaseView();
    }

    @And("user should be able to view each publication listed as a tile")
    public void user_should_be_able_to_view_each_publication_listed_as_a_tile() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getTitlename()), true);
    }

    @And("user should be able view issue cover image with title format icon")
    public void user_should_be_able_view_issue_cover_image_with_title_format_icon() throws Throwable {
    	logger.info("User able view issue cover image with title format icon");
    }

    @And("user should be able view title due date")
    public void user_should_be_able_view_title_due_date() throws Throwable {
    	Assert.assertEquals(isElementPresent(download.getTitleduedate()), true);
    }

    @And("user should be able to view number of days remaining for title return or checkout expiry")
    public void user_should_be_able_to_view_number_of_days_remaining_for_title_return_or_checkout_expiry() throws Throwable {
    	logger.info("User able view number of days remaining for title return");
    }

    @And("user should be able to view number of hours remaining for title return or checkout expiry when only one day is left")
    public void user_should_be_able_to_view_number_of_hours_remaining_for_title_return_or_checkout_expiry_when_only_one_day_is_left() throws Throwable {
    	logger.info("User able view number of hours remaining for title return");
    }
    @And("user should be able to view reading progress of the title as a progress bar and percentage on the card")
    public void user_should_be_able_to_view_reading_progress_of_the_title_as_a_progress_bar_and_percentage_on_the_card() throws Throwable {
    	logger.info("User able to view reading progress of the title as a progress bar");
    }

    @And("user should be able to click on image other than primary and secondary CTA area to navigate to title details screen")
    public void user_should_be_able_to_click_on_image_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() throws Throwable {
    	logger.info("User able to click on image other than primary and secondary CTA");
    }

}


