package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.Holds;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.Navigationbars;
import pom.kidszone.ProfileCreation;

public class Holds_StepDef extends CommonActions {
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(Holds_StepDef.class);

	@When("user should navigated to {string} screen by tapping on {string} cta from quick navigation")
	public void user_should_navigated_to_screen_by_tapping_on_cta_from_quick_navigation(String string, String string2) {
		holds.clickHolds();
	}

	@When("user lands on Holds screen")
	public void user_lands_on_holds_screen() {
		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}

	@Then("user should be able to view the hold position for each title on the card")
	public void user_should_be_able_to_view_the_hold_position_for_each_title_on_the_card() {
		holds.viewHoldsPosition();
		logger.info("user able to view holds position");
	}

	@Then("user should be able to view tool tip icon for the hold position {string}")
	public void user_should_be_able_to_view_tool_tip_icon_for_the_hold_position(String string) {
		Assert.assertEquals(isElementPresent(holds.getTooltip()), true);
	}

	@Then("user should be able to click on tool tip icon to view the description")
	public void user_should_be_able_to_click_on_tool_tip_icon_to_view_the_description() {
		holds.clickTooltip();
	}

	@Then("user should be able to view the {string} alert popup message with Ok button")
	public void user_should_be_able_to_view_the_alert_popup_message_with_ok_button(String string) {
		Assert.assertEquals(isElementPresent(holds.getTooltipAlertOk()), true);
	}

	@Then("user should be able to view the {string} description {string}")
	public void user_should_be_able_to_view_the_description(String string, String string2) {
		Assert.assertEquals(isElementPresent(holds.getTooltipAlertMsg()), true);
	}

	@Then("user should be able to click on {string} button to close the popup")
	public void user_should_be_able_to_click_on_button_to_close_the_popup(String string) {
		holds.clickOk();
	}

	@Then("user should logout the application by tapping on signout button from hamburger menu")
	public void user_should_logout_the_application_by_tapping_on_signout_button_from_hamburger_menu() {
		profile.clickBackbutton();
		login.logOut();
	}

	@Given("user taps on {string} option from hamburger menu")
	public void user_taps_on_option_from_hamburger_menu(String string) {
		holds.clickProfileHamberger();

	}

	@Given("user taps on Edit icon.")
	public void user_taps_on_edit_icon() {
		Assert.assertEquals(isElementPresent(holds.getEditIcon()), true);
	}

	@Given("user taps on Pencil icon.")
	public void user_taps_on_pencil_icon() {
		Assert.assertEquals(isElementPresent(holds.getPencilIcon()), true);
	}

	@Given("user should navigated to my Profile page based on edit profile selection")
	public void user_should_navigated_to_my_profile_page_based_on_edit_profile_selection() {
		Assert.assertEquals(isElementPresent(holds.getMyProfile_page()), true);
	}

	@Given("user should view the checkbox for {string} option is checked or not")
	public void user_should_view_the_checkbox_for_option_is_checked_or_not(String string) {
		swipeDown();
		swipeDown();
		swipeDown();
		profile.selectCheckoutTitles();
	}

	@Given("user should checked the {string} option by selecting the checkbox")
	public void user_should_checked_the_option_by_selecting_the_checkbox(String string) {
		profile.selectCheckoutTitles();
	}

	@Given("user should click on Save button")
	public void user_should_click_on_save_button() {
		holds.saveBtnOption();
		holds.clickBack();
	}

	@Given("user taps on {string} button in successful alert popup message")
	public void user_taps_on_button_in_successful_alert_popup_message(String string) {
		logger.info("Able to see the profile changes saved");
	}

	@Given("user is on {string} page")
	public void user_is_on_page_with_adult_theme(String string) {
		myshelf.clickMyself();
		Assert.assertEquals(isElementPresent(myshelf.getMyShelf_lbl_footer()), true);
	}

	@Given("user has checked out maximum number of titles as per library limit set")
	public void user_has_checked_out_maximum_number_of_titles_as_per_library_limit_set() {
		logger.info("user has checked out maximum number of titles as per library limit set");
	}

	@Given("auto checkout titles on holds is enabled in the user preferences")
	public void auto_checkout_titles_on_holds_is_enabled_in_the_user_preferences() {
		logger.info("auto checkout titles on holds is enabled");
	}

	@When("title put on hold is available for user")
	public void title_put_on_hold_is_available_for_user() {
		Assert.assertEquals(isElementPresent(holds.getHold_title()), true);
	}

	@Then("system should not auto checkout the title")
	public void system_should_not_auto_checkout_the_title() {
		logger.info("system should not auto checkout the title");
	}

	@Then("user should get the notification in message center and via email for the title available for checkout")
	public void user_should_get_the_notification_in_message_center_and_via_email_for_the_title_available_for_checkout() {
		logger.info("user should get the notification in message center");
	}

	@Then("user should view the title in the holds screen with updated cta for checkout")
	public void user_should_view_the_title_in_the_holds_screen_with_updated_cta_for_checkout() {
		logger.info("user should view the title in the holds screen with updated cta for checkout");
	}

	@Then("user should be able to view the expiry for the title reserved")
	public void user_should_be_able_to_view_the_expiry_for_the_title_reserved() {
		logger.info("user should be able to view the expiry for the title reserved");
	}

	@Given("auto checkout titles on holds is disabled in the user preferences")
	public void auto_checkout_titles_on_holds_is_disabled_in_the_user_preferences() {
		logger.info("auto checkout titles on holds is disabled in the user preferences");
	}

	@Given("user taps on hold CTA in the my shelf screen")
	public void user_taps_on_hold_cta_in_the_my_shelf_screen() {
		login.handleNothankspopup();
		goals.clickOnMyshelfFooter();
		holds.clickHolds();
	}

	@Given("user lands on the hold screen")
	public void user_lands_on_the_hold_screen() {
		holds.clickHolds();
		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}

	@When("title put on hold is available for user and user has not checked out the title in the available duration")
	public void title_put_on_hold_is_available_for_user_and_user_has_not_checked_out_the_title_in_the_available_duration() {
		logger.info("title put on hold is available for user");
	}

	@Then("user should not be able title removed from the hold if not checked out")
	public void user_should_not_be_able_title_removed_from_the_hold_if_not_checked_out() {
		logger.info("user should not be able title removed from the hold");
	}

	@Then("system should auto checkout the title")
	public void system_should_auto_checkout_the_title() {
		logger.info("auto checkout the title");
	}

	@Then("user should not view the title checked out in the holds screen")
	public void user_should_not_view_the_title_checked_out_in_the_holds_screen() {
		logger.info("user should not view the title checked out in the holds screen");
	}

	@Then("user taps on back button and navigate to the {string} screen")
	public void user_taps_on_back_button_and_navigate_to_the_screen(String string) {
		profile.clickBackbutton();
	}

	@Then("user should view the title auto checked out in the checkout screen")
	public void user_should_view_the_title_auto_checked_out_in_the_checkout_screen() {
		logger.info("user should view the title auto checked out");
	}

	@Given("user should unchecked the {string} option by selecting the checkbox")
	public void user_should_unchecked_the_option_by_selecting_the_checkbox(String string) {
		logger.info("user should unchecked the option by selecting the checkbox");
	}

	@Given("user should know the duration for which title is reserved for the user is set in library admin portal")
	public void user_should_know_the_duration_for_which_title_is_reserved_for_the_user_is_set_in_library_admin_portal() {
		logger.info("user should know the duration for which title is reserved for the user");
	}

	@Then("user should be able to view the updated status on title icon is enabled for the title and hold position")
	public void user_should_be_able_to_view_the_updated_status_on_title_icon_is_enabled_for_the_title_and_hold_position() {
		Assert.assertEquals(isElementPresent(holds.getHold_title()), true);
	}

	@Then("user should be able to view the {string} option to checkout the title")
	public void user_should_be_able_to_view_the_option_to_checkout_the_title(String string) {
		Assert.assertEquals(isElementPresent(myshelf.getCheckout_page()), true);
	}

	@Then("user should be able to view the title reserve duration to user for the title to be checked out")
	public void user_should_be_able_to_view_the_title_reserve_duration_to_user_for_the_title_to_be_checked_out() {
		logger.info("user should be able to view the title reserve duration to user for the title to be checked out");
	}

	@And("user should navigated to 'My Shelf' screen on login when 'My Shelf' is set as default landing")
	public void user_should_navigated_to_My_Shelf_screen_on_login_when_My_Shelf_is_set_as_default_landing()
			throws Throwable {
		waitFor(1000);
		myshelf.clickMyself();
		Assert.assertEquals(myshelf.getMyShelf_lbl_footer().isDisplayed(), true);
		logger.info("User lands on MyShelf page");
	}

	@Then("user should be able to view Holds screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_Holds_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type()
			throws Throwable {
		logger.info("theaming check");
	}

	@And("user should be able to view quick navigation ctas as a carousel on top with Holds highlighted and number of titles on hold")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_Holds_highlighted_and_number_of_titles_on_hold()
			throws Throwable {
		logger.info("highlighted font not to check");
	}

	@And("user should be able to view titles put on hold by that user only")
	public void user_should_be_able_to_view_titles_put_on_hold_by_that_user_only() throws Throwable {
		for (int i = 1; i <= holds.getHolds_titles_hdr().size(); i++) {
			if (i == 1)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_titles_hdr().get(i)), true);
		}
//		 holds.viewholds_title();
	}

	@And("user should be able to view titles sorted by latest title put on hold first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_put_on_hold_first_by_default()
			throws Throwable {
		logger.info("titles sorted by latest title checked out first by default");
	}

	@And("user should be able to click on List view icon and titles are listed as list view format")
	public void user_should_be_able_to_click_on_List_view_icon_and_titles_are_listed_as_list_view_format()
			throws Throwable {
		Assert.assertEquals(isElementPresent(holds.getHolds_listView()), true);
//		holds.clickHoldView();
//		Assert.assertEquals(isElementPresent(holds.getHolds_listView()), true);
	}

	@And("user should be able to click on Grid view icon and titles are listed as grid view format")
	public void user_should_be_able_to_click_on_Grid_view_icon_and_titles_are_listed_as_grid_view_format()
			throws Throwable {
//		Assert.assertEquals(isElementPresent(holds.getHolds_gridView()), true);
		holds.clickHoldView();
		Assert.assertEquals(isElementPresent(holds.getHolds_gridView()), true);
	}

	@And("user click on login button after user enters {string} that library has kidszone subscription")
	public void user_click_on_login_button_after_user_enters_libraryid_that_library_has_kidszone_subscription(
			String libraryid) {

	}

	@And("user navigates to My Stuff bottom navigation and navigates to Holds screen and user is on 'My Stuff' page")
	public void user_navigates_to_My_Stuff_bottom_navigation_and_navigates_to_Holds_screen_and_user_is_on_My_Stuff_page() {
		holds.clickMyShelf();
	}

	@And("user is not able to view the hold titles for these users in hold screen")
	public void user_is_not_able_to_view_the_hold_titles_for_these_users_in_hold_screen() {
		logger.info("Hold titles not avilable for this user if hold is disabled");
	}

	@And("And user should be able to view no title on hold screen You currently have no Holds")
	public void And_user_should_be_able_to_view_no_title_on_hold_screen_You_currently_have_no_Holds() {
		Assert.assertEquals(isElementPresent(holds.getHolds_Notitle()), true);
		Assert.assertEquals("You currently have no Holds.", holds.getHolds_Notitle().getText(), true);

	}

	@And("user should navigated 'Holds' screen by tapping on 'Holds' cta from quick navigation")
	public void user_should_navigated_holds_screen_by_tapping_on_holds_cta_from_quick_navigation() {
		holds.clickHolds();
	}

	@And("user should be able view hold position for the title")
	public void user_should_be_able_view_hold_position_for_the_title() throws Throwable {
//    	 holds.ClickonHoldsGridview();
		Assert.assertEquals(isElementPresent(holds.getHolds_Position()), true);

	}

	@And("user should be able to view tool tip icon and tool tip for the hold position if applicable")
	public void user_should_be_able_to_view_tool_tip_icon_and_tool_tip_for_the_hold_position_if_applicable()
			throws Throwable {
		Assert.assertEquals(isElementPresent(holds.getTooltip()), true);

	}

     @Then("user should be able to view no title on hold screen {string}")
     public void user_should_be_able_to_view_no_title_on_hold_screen(String string) {
    	 // System.out.println(holds.getHolds_Notitle().getText());
    	 // Assert.assertEquals(string, holds.getHolds_Notitle().getText());
    	  Assert.assertEquals(isElementPresent(holds.getHolds_Notitle()), true);
//    	  interest.clickBack();
     }
     
     @Then("user should be able to click on card other than primary and secondary cta area to navigate to title details screen in hold page")
     public void user_should_be_able_to_click_on_card_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen_in_hold_page() throws Throwable {
    	 holds.closeBtnOption();
 	 }
    
     @And("user should be able to view sort options: Latest Hold, Rating, A-Z sort based on title name")
     public void user_should_be_able_to_view_sort_options_Latest_Hold_Rating_A_Z_sort_based_on_title_name() throws Throwable {
     
    	// holds.getHolds_title_sort();
  		Assert.assertEquals(isElementPresent(holds.getSORT_BY_LATEST_HOLD()), true);
  		Assert.assertEquals(isElementPresent(holds.getSORT_BY_RATING()), true);
  		Assert.assertEquals(isElementPresent(holds.getSORT_BY_ATOZ()), true);
  		holds.clickSortByLatestHold();
 	}
     
	@When("user should navigated to 'Holds' screen")
	public void user_should_navigated_to_Holds_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}

	@Then("user is able to view titles in holds screen")
	public void user_is_able_to_view_titles_in_holds_screen() throws Throwable {
		for (int i = 1; i <= holds.getHolds_titles_hdr().size(); i++) {
			if (i == 2)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_titles_hdr().get(i)), true);
		}

	}

	@Given("user has put titles on hold by tapping on {string} button from titles details page")
	public void user_has_put_titles_on_hold_by_tapping_on_button_from_titles_details_page(String string) {
		holds.clickHolds();
		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}

	@Then("user should be able to view tool tip icon and tool tip for the hold position {string}")
	public void user_should_be_able_to_view_tool_tip_icon_and_tool_tip_for_the_hold_position(String string) {
		Assert.assertEquals(isElementPresent(holds.getTooltip()), true);
	}

	@When("user should navigated to {string} screen by tapping on {string} option")
	public void user_should_navigated_to_screen_by_tapping_on_option(String string, String string2) {
		holds.clickHolds();
		WaitForMobileElement(holds.getHolds_lbl_footer());
		Assert.assertEquals(isElementPresent(holds.getHolds_lbl_footer()), true);
	}

	@When("user switch to grid view for holds screen")
	public void user_switch_to_grid_view_for_holds_screen() {
		Assert.assertEquals(isElementPresent(holds.getHolds_gridView()), true);
		holds.ClickonHoldsGridview();
	}

	@Then("user should be able to view titles listed as grid view and sorted by latest title put on hold first by default")
	public void user_should_be_able_to_view_titles_listed_as_grid_view_and_sorted_by_latest_title_put_on_hold_first_by_default() {
		for (int i = 1; i <= holds.getHolds_Gridview_titles_hdr().size(); i++) {
			if (i == 2)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_Gridview_titles_hdr().get(i)), true);
		}
	}

	@Then("user should be able to view each title listed as a tile")
	public void user_should_be_able_to_view_each_title_listed_as_a_tile() {
		logger.info("Hold title displayed");

	}

	@Then("user should be able view title cover image with title format icon")
	public void user_should_be_able_view_title_cover_image_with_title_format_icon() {
		for (int i = 1; i <= holds.getHolds_Gridview_ImageTitle_hdr().size(); i++) {
			if (i == 2)
				break;
			Assert.assertEquals(isElementPresent(holds.getHolds_Gridview_ImageTitle_hdr().get(i)), true);
		}

		holds.ClickonHoldsGridview();
	}

	@Then("user should be able to view tool tip icon and tool tip for the hold position")
	public void user_should_be_able_to_view_tool_tip_icon_and_tool_tip_for_the_hold_position() {
		Assert.assertEquals(isElementPresent(holds.getTooltip()), true);

	}

	@Given("No title is on hold when count is {string}")
	public void no_title_is_on_hold_when_count_is(String string) {
		logger.info("Hold count is zero");
	}

	@Then("user should be able to sort options by rating and titles are sorted based on rating")
	public void user_should_be_able_to_sort_options_by_rating_and_titles_are_sorted_based_on_rating() {
//    	 holds.clickFilterHold();
		holds.clickRatingHold();
		holds.closeBtnOption();
	}

	@Then("user should be able to sort options by A-Z and titles are sorted based on name order from a-z")
	public void user_should_be_able_to_sort_options_by_a_z_and_titles_are_sorted_based_on_name_order_from_a_z() {
		holds.clickATOZHold();
		holds.closeBtnOption();
	}

}
