package parallel;

import java.io.File;

import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverFactory;
import com.driverfactory.DriverFactory.Target;
import com.driverfactory.DriverManager;
import com.utilities.ConfigReader;
import com.utilities.JvmReport;

import eyesmanager.EyesManager;
import eyesmanager.EyesSetup;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {

	String screenshotdir = System.getProperty("user.dir") + "/target/test-output/Screenshots/";

	@Before(order = 0)
	public void launchBrowser(Scenario scenario) throws IOException {
		try {
			String target = ConfigReader.getData("target");
			if ((new File(screenshotdir)).exists())
				FileUtils.cleanDirectory(new File(screenshotdir));
			DriverFactory driverFactory = new DriverFactory();
			AppiumDriver<?> driver = driverFactory.getDriver(Target.valueOf(target.toUpperCase()), scenario.getName());
			DriverManager.setDriver(driver);
			System.out.println("scenario name : " + scenario.getId());
			long threadId = Thread.currentThread().getId();
	        System.out.println("Current thread ID: " + threadId);
			if (ConfigReader.getData("executionFor").equalsIgnoreCase("visualUI")) {
				// MARK: Eyes setup
				Eyes eyes = new EyesSetup().getEyes(driver, scenario);
				EyesManager.setEyes(eyes);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After(order = 0)
	public void attach_screenshot(Scenario scenario) throws Throwable {
		if (scenario.isFailed()) {
			byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", "MyscreenShot");
		}
		DriverManager.quit();
	}
	
}
