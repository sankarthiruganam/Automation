package parallel;

import java.util.Properties;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import com.utilities.JsonReader;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;

public class LoginWithLibraryid_StepDef extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(LoginWithLibraryid_StepDef.class);

    LoginPage login = new LoginPage(DriverManager.getDriver());
    ManageProfile manage = new ManageProfile(DriverManager.getDriver());

    @Given("user is in the login page")
    public void user_is_in_the_login_page() {
        if (isElementPresent(login.boundlessAllow())) {
            login.clickBoundlessAllow();
        }
        Assert.assertEquals(login.getLogo_txt_Welcome().isDisplayed(), true);
    }

    @When("user enters the {string} and click on sign in")
    public void user_enters_the_something_and_click_on_sign_in(String libraryid) throws Throwable {
        login.loginwithId(libraryid);
    }

    @Then("system should validate the user credentials")
    public void system_should_validate_the_user_credentials() throws Throwable {

    }

    @And("user should be redirected to the home page")
    public void user_should_be_redirected_to_the_home_page() throws Throwable {

        //	 login.handleNothankspopup();
        Assert.assertEquals(login.homePgNav(), true);
        logger.info("User is on home Page");
    }
    @And("user should not be redirected to the home page")
    public void user_should_not_be_redirected_to_the_home_page() throws Throwable {

        Assert.assertEquals(login.homePgNav(), false);
        logger.info("User is on Register Page");
    }

    @When("user enters the invalid {string} and click on sign in")
    public void user_enters_the_invalid_something_and_click_on_sign_in(String libraryid) throws Throwable {
        login.loginwithInvalidId(libraryid);
    }

    @Then("user should not login into the application and error message should displayed")
    public void user_should_not_login_into_the_application_and_error_message_should_displayed() throws Throwable {

        if (System.getProperty("platform").equalsIgnoreCase("android")) {
            Assert.assertEquals(login.getLogin_lbl_invalidprefixerror().isDisplayed(), true);
        } else {
            Assert.assertEquals(login.errorPopup(), true);
        }
    }

    @And("user search the library {string}")
    public void user_search_the_library(String libraryName) throws Throwable {
        if (isElementPresent(login.boundlessAllow())) {
            login.clickBoundlessAllow();
        }        
        login.searchLibrary(libraryName);
        login.initiateSearch();
        login.select_library();
        System.out.println("Library selected");

    }

	@And("user search the library")
	public void user_search_the_libraryName() throws Throwable {
		if (isElementPresent(login.boundlessAllow())) {
			login.clickBoundlessAllow();
		}
			login.searchLibrary(JsonReader.readData().get("libraryName"));
			login.initiateSearch();
			login.select_library();
			System.out.println("Library selected");	
	}

//	@And("user enters the prefix {string} login")
//	public void user_enters_the_prefix(String libraryid) throws Throwable {
//		login.enterPrefixLogin(libraryid);
//	}

    @And("user enters the invalid {string} with prefix")
    public void user_enters_the_invalid_prefix(String libraryid) throws Throwable {
        login.invalidLibraryidSearch(libraryid);
    }

    @And("system should displays the error message")
    public void system_should_displays_the_error_message() throws Throwable {
        Assert.assertEquals(login.errorPopup(), true);
        // Assert.assertTrue(login.logo_lbl_onlyIdLibInvalidloginError.isDisplayed());
        logger.info("User not able to create the new acc with invalid LibId");
    }

    @When("user skips libraryid field blank")
    public void user_skips_libraryid_field_blank() {
        login.emptyLibraryidSearch();
    }

    @And("user should be able to view cancel account button for library which has Prefix and Password registration type")
    public void user_should_be_able_to_view_cancel_account_button_for_library_which_has_prefix_and_password_registration_type() throws Throwable {
        Assert.assertEquals(isElementPresent(manage.getEditprofile_btn_deltProfile()), true);
    }

    @And("user should not be able to view cancel account button for SSO libraries")
    public void user_should_not_be_able_to_view_cancel_account_button_for_sso_libraries() throws Throwable {
        swipeDown();
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(manage.getEditprofile_btn_deltProfile()), false);
    }

    @And("user enters {string} and {string} credentials for SSO libraries user")
    public void user_enters_something_and_something_credentials_for_sso_libraries_user(String username, String password) throws Throwable {
        login.enterssopassword(password);
        login.enterssoUsername(username);
        login.clickLogin();
        login.clickContinue();
    }

    @And("user should not be able to view cancel account button for ILS libraries")
    public void user_should_not_be_able_to_view_cancel_account_button_for_ils_libraries() throws Throwable {
        swipeDown();
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(manage.getEditprofile_btn_deltProfile()), false);
    }

}
