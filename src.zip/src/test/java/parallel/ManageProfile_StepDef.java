package parallel;

import java.io.IOException;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ConfigReader;
import com.utilities.JsonReader;

import io.cucumber.java.Before;
import io.cucumber.java.PendingException;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.ProfileCreation;
import pom.kidszone.SetParentPin;

public class ManageProfile_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	MenuList menu =new MenuList(DriverManager.getDriver());
    private Scenario scenario;

    @Before
    public void setup(Scenario scenario) {
        this.scenario = scenario;
    }

	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);

	/****************************** 109548 *********************************/

	@Given("user launches the apps")
	public void user_launches_the_apps() {
		Assert.assertEquals(login.getLogo_txt_Welcome().isDisplayed(), true);
	}

	@And("user enters the prefix {string} and {string} shared by the client")
	public void user_enters_the_prefix_and_shared_by_the_client(String libraryid, String pin) throws IOException {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, libraryid);
		System.out.println("TestData==="+testData);
		login.loginwithidandPin(testData.getLibraryId(), testData.getPassword());
//		login.loginwithidandPin(libraryid, pin);
//		login.closepopup();
		login.handleNothankspopup();
	}

	@And("user enters the prefix username and password shared by the client")
	public void user_enters_the_prefix_and_shared_by_theclient() throws IOException {

		login.loginwithidandPin(JsonReader.readData().get("userName"), JsonReader.readData().get("password"));
	}

	@Then("user is clicking on Profiles from Menu")
	public void user_is_clicking_on_profiles_from_menu() {
		manageProf.manageprofielScreenNav();
		profile.clickpenicon();
	}

	@Then("enter the parent pin {string}")
	public void enter_the_parent_pin(String pin) {
		// manageProf.setupParentPin(pin);
	}

	@Then("user click axis360 menu")
	public void user_click_axis360_menu() {
		login.clickFooterMenu();
	}

	@Then("user logout from the application")
	public void user_logout_from_the_application() {
		login.logOut();
	}

	/*************************************
	 * 109549
	 ***************************************/

	@Then("user should be redirected to the profile pages")
	public void user_should_be_redirected_to_the_profile_page() {
		login.handleNothankspopup();
		login.clickFooterMenu();
		login.clickMenuprofile();
	}

	/*************************************
	 * 109550
	 ******************************************/

	@Then("user should able to view the existing profile list")
	public void user_should_able_to_view_the_existing_profile_list() {
		manageProf.manageprofielScreenNav();
	}

	@Then("user should see edit pen icon option in each of the profile available")
	public void user_should_see_edit_pen_icon_option_in_each_of_the_profile_available() {
//		Assert.assertEquals(manageProf.editIconCheck(), true);
	}

	@Then("system should be able to redirect the user to profile detail page")
	public void system_should_be_able_to_redirect_the_user_to_profile_detail_page() {
		Assert.assertEquals(manageProf.profDtlPgNav(), true);
	}

	@Then("user should be able to view the profile details auto populated in the edit profile page")
	public void user_should_be_able_to_view_the_profile_details_auto_populated_in_the_edit_profile_page() {
		Assert.assertEquals(isElementPresent(manageProf.getEditprofile_btn_close()), true);
	}

	/********************************
	 * 109551
	 **********************************************/

	@When("user clicks on the create new profile cta")
	public void user_clicks_on_the_create_new_profile_cta() {
		profile.addProfileCta();
	}

	@Then("user views the profile creation page with options Add a teen")
	public void user_views_the_profile_creation_page_with_options_add_a_teen() {
		Assert.assertTrue(manageProf.getAddprofile_btn_kidProf().isDisplayed());
		Assert.assertTrue(manageProf.getAddprofile_btn_teenProf().isDisplayed());
	}

	@Then("user taps on Add a teen button")
	public void user_taps_on_add_a_teen_button() {
		manageProf.selectProfType("teen");
	}

	@Then("user enters the profile details like display name and select avatar")
	public void user_enters_the_profile_details_like_display_name_and_select_avatar() {
		manageProf.enterProfDetail();
	}

	@Then("user clicks on the done button")
	public void user_clicks_on_the_done_button() {
		manageProf.doneBtnClick();
	}

	@Then("user can view the profile listed in manage profile page")
	public void user_can_view_the_profile_listed_in_manage_profile_page() {
//		Assert.assertTrue(manageProf.createdProfDisplayCheck());
	}

	@Then("user views the profile creation page with options Add a kid")
	public void user_views_the_profile_creation_page_with_options_add_a_kid() {
		Assert.assertTrue(manageProf.getAddprofile_btn_kidProf().isDisplayed());
	}

	@Then("user taps on Add a kid button")
	public void user_taps_on_add_a_kid_button() {
		manageProf.selectProfType("kid");
	}

	/************************ 109552 ***************************/

	@Then("user already created five profile")
	public void user_already_created_five_profile() {
		Assert.assertEquals(isElementPresent(manageProf.getManageProf_lbl_MaxuserNotifi()), false);
		logger.info("Five user created");
	}

	@Then("user should not see the add profile cta")
	public void user_should_not_see_the_add_profile_cta() {
//	   Assert.assertEquals(manageProf.getManageProf_btn_add().isDisplayed(),false);
		Assert.assertEquals(isElementPresent(manageProf.getManageProf_lbl_MaxuserNotifi()), false);
	}

	/************************ 109555 ***************************/

	@When("user enters the invalid {string}")
	public void user_enters_the_invalid(String patronpin) {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			setPin.wrongParentPin();
		} else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			setPin.wrongParentPin();
		}
	}

	@Then("user should not be able to create profile and pin doesnot match error message should be displayed")
	public void user_should_not_be_able_to_create_profile_and_pin_doesnot_match_error_message_should_be_displayed() {
		Assert.assertEquals(manageProf.manageprofielScreenNav(), false);
		logger.info("User not able to nav to manage profile page to create a profile");
	}

}
