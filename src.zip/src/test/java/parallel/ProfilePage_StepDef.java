package parallel;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

public class ProfilePage_StepDef extends CommonActions {

	ProfilePage profile = new ProfilePage(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profileCreate = new ProfileCreation(DriverManager.getDriver());

	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	MyLibrary myLib = new MyLibrary(DriverManager.getDriver());

	@And("user clicks on the Profiles option in the menu screen")
	public void user_clicks_on_the_profiles_option_in_the_menu_screen() throws Throwable {
		profile.clickMenuProfile();
	}

	@When("user is on profile screen")
	public void user_is_on_profile_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_Page()), true);
	}

	@Then("user should be able to view edit icon on all the profiles")
	public void user_should_be_able_to_view_edit_icon_on_all_the_profiles() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getAdult_Profile_Edit_Icon()), true);
		Assert.assertEquals(isElementPresent(profile.getTeen_Profile_Edit_Icon()), true);
	}

	@And("user should be navigated to profile details screen")
	public void user_should_be_navigated_to_profile_details_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_Details()), true);
		// profile.provideValid_Pin_DeleteProfile();
	}

	@And("user should be see restricted from deleting the first teen profile")
	public void user_should_be_see_restricted_from_deleting_the_first_teen_profile() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_UnabletoDelete_Msg()), true);
	}

//    @And("user logout from the application")
//    public void user_logout_from_the_application() throws Throwable {
//    }

	@And("user select the first kid profile")
	public void user_select_the_first_kid_profile() throws Throwable {
		profile.clickEditPenIcon_FirstKid();
		setPin.parentPin();
	}

	@And("user select the first kid profile with no pin")
	public void user_select_the_first_kid_profile_with_no_pin() throws Throwable {
		profile.clickEditPenIcon_FirstKid();
	}

	@And("user should be see restricted from deleting the first kid profile")
	public void user_should_be_see_restricted_from_deleting_the_first_kid_profile() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_UnabletoDelete_Msg()), true);
	}

	@And("user should be see restricted from deleting the new kid profile")
	public void user_should_be_see_restricted_from_deleting_the_new_kid_profile() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_UnabletoDelete_Msg()), true);
	}

	@And("user should be see the first teen profile deleted in profile screen")
	public void user_should_be_see_the_first_teen_profile_deleted_in_profile_screen() throws Throwable {
		profile.clickProfile_Delete_Ok();
		// Assert.assertEquals(isElementPresent(profile.getProfile_Deleted_Msg()),
		// true);
	}

	@And("user should be able to view the toast message 'Your Profile has been deleted'")
	public void user_should_be_able_to_view_the_toast_message_your_profile_has_been_deleted() throws Throwable {
		logger.info("User able to view the success toast message");
	}

	@And("user should be navigates into the profile list screen")
	public void user_should_be_navigates_into_the_profile_list_screen() throws Throwable {
//    	if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
//    		register.click_Profile_Icon();
//    	}else {
		Assert.assertEquals(isElementPresent(profile.getProfile_Page()), true);
//    	}

	}

	@And("user select the new kid profile")
	public void user_select_the_new_kid_profile() throws Throwable {
		profile.clickEditPenIcon_FirstKid();

	}

	@Given("user select the adult profile in the profile landing screen")
	public void user_select_the_adult_profile_in_the_profile_landing_screen() throws Throwable {
		profile.adultProfileSelection();
		// setPin.parentPin();
		// waitFor(2000);
		// setPin.getSetParentPin_btn_submit();
	}

	@Given("user select the adult profile in the profile landing screen with pin")
	public void user_select_the_adult_profile_in_the_profile_landing_screen_with_pin() throws Throwable {
		profile.clickManageProfile();
		profile.adultProfileSelection();
		setPin.parentPin();
		waitFor(2000);
		setPin.getSetParentPin_btn_submit();
	}

	@When("user navigate to the profile detail page")
	public void user_navigate_to_the_profile_detail_page() throws Throwable {
		login.handleNothankspopup();
		profile.navigateProfileDetail();
	}

	@Then("user should be able to enable an already set Pin by toggling {string} CTA")
	public void user_should_be_able_to_enable_an_already_set_pin_by_toggling_something_cta(String strArg1)
			throws Throwable {
		profile.enablePIN();
	}

	@And("user should be able to view {string} CTA only,it should not show Disable Pin CTA")
	public void user_should_be_able_to_view_something_cta_onlyit_should_not_show_disable_pin_cta(String strArg1)
			throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getEnable_PIN()), true);
	}

	@When("user clicks on the back button")
	public void user_clicks_on_the_back_button() {
		profile.closeProfile();
	}

	@When("user navigates to profile list screen")
	public void user_navigates_to_profile_list_screen() {
		Assert.assertEquals(isElementPresent(profile.profile_List_Screen()), true);
	}

	@And("user clicks on manage profile cta")
	public void user_clicks_on_manage_profile_cta() {
		waitFor(6000);
		register.clickEditOption();
	}

	@When("user should be able to view the {string} cta")
	public void user_should_be_able_to_view_the_cta(String string) {
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(profile.cancel_Boundless())) {
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(isElementPresent(profile.cancel_Boundless()), true);
	}

	@Then("user should be able to click the {string} cta")
	public void user_should_be_able_to_click_the_cta(String string) {
		profile.cancel_Boundless().click();

	}

	@And("all other profiles should be deleted and the account will be disabled")
	public void all_other_profiles_should_be_deleted_and_the_account_will_be_disabled() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(profile.boundless_lib()), true);
	}

	@Given("user selects Adult profile")
	public void user_selects_adult_profile() {
		waitFor(2000);
		register.adultprofileSelection();
	}

	@And("user clicks on edit option")
	public void user_clicks_on_edit_option() throws Throwable {
		waitFor(3000);
		profile.clickEdit_Option();
	}

	@And("user should be able to view cancel option")
	public void user_should_be_able_to_view_cancel_option() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_Cancel_Option()), true);
	}

	@And("user select the first teen profile")
	public void user_select_the_first_teen_profile() throws Throwable {
		profile.clickEditPenIcon_FirstTeen();
		setPin.parentPin();
	}

	@And("user select the first teen profile with no pin")
	public void user_select_the_first_teen_profile_with_no_pin() throws Throwable {
		profile.clickEditPenIcon_FirstTeen();
	}

	@And("user clicks on the delete profile cta")
	public void user_clicks_on_the_delete_profile_cta() throws Throwable {
		profile.clickDelete_Profile();
		// profile.clickDelete_Profile_Ok();
	}

	@And("user provides the {string} in pin screen")
	public void user_provides_the_something_in_pin_screen(String adultinvalidpin, String strArg1) throws Throwable {
		profile.provideInvalid_Pin_DeleteProfile();
	}

	@And("user should be see restricted from deleting the profile with no pin")
	public void user_should_be_see_restricted_from_deleting_the_profile_with_no_pin() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getDelete_Profile_Msg()), true);
		profile.clickDelete_Cancel();
	}

	@And("user should be able to view the blue color 'Enable Profile Pin' toggle")
	public void user_should_be_able_to_view_the_blue_color_enable_profile_pin_toggle() throws Throwable {
		logger.info(" color code not feasible to check");
	}

	@Given("user select the teen profile in the profile landing screen")
	public void user_select_the_teen_profile_in_the_profile_landing_screen() throws Throwable {
		profile.teenprofileSelection();
		waitFor(2000);
	}

	@Then("user should be able to disable an already set Pin by toggling {string} CTA")
	public void user_should_be_able_to_disable_an_already_set_pin_by_toggling_something_cta(String strArg1)
			throws Throwable {
		profile.enablePIN();
	}

	@And("user should be able to view the greyed out 'Enable Profile Pin' toggle")
	public void user_should_be_able_to_view_the_greyed_out_enable_profile_pin_toggle() throws Throwable {
		logger.info(" color code not feasible to check");
	}

	@Given("user select the kid profile in the profile landing screen")
	public void user_select_the_kid_profile_in_the_profile_landing_screen() throws Throwable {
		profile.kidprofileSelection();
	}

	@Then("user should be able to view profile detail page with set my shelf as my default landing page checkbox")
	public void user_should_be_able_to_view_profile_detail_page_with_set_my_shelf_as_my_default_landing_page_checkbox()
			throws Throwable {
		waitFor(1000);
		login.handleNothankspopup();
		Assert.assertEquals(isElementPresent(profile.getMyshelf_homePage()), true);
	}

	@And("user should be able to view updated verbiage from Set My Shelf page as my default landing page,to this {string}")
	public void user_should_be_able_to_view_updated_verbiage_from_set_my_shelf_page_as_my_default_landing_pageto_this_set_my_shelf_as_my_home_page(
			String text) throws Throwable {		
		for (int i = 0; i <= 3; i++) {
            if (profile.checkMyshelfVerbiage(text)) {
                break;
            } else {
                swipeDown();
            }
        }
       Assert.assertTrue(profile.checkMyshelfVerbiage(text));
	   profile.closeProfile();
	}

	@Then("user should be able to view profile detail page with Automatically checkout checkbox")
	public void user_should_be_able_to_view_profile_detail_page_with_automatically_checkout_checkbox()
			throws Throwable {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(profile.getCheckout_Available()), true);
	}

	@And("user should be able to view updated verbiage from Automatically check out on hold once they become available,to this {string}")
	public void user_should_be_able_to_view_updated_verbiage_from_automatically_check_out_on_hold_once_they_become_availableto_this_automatically_check_out_available_holds(
			String text) throws Throwable {
		swipeDown();
		Assert.assertTrue(profile.checkcheckoutVerbiage(text));

	}

	@And("user should be able to chcek and unchcek the 'Auto checkout available holds' chcekbox")
	public void user_should_be_able_to_chcek_and_unchcek_the_auto_checkout_available_holds_chcekbox() throws Throwable {
		profile.checkUncheck();
		swipeDown();
		swipeDown();
		profile.save_profile();
		profile.closeProfile();
	}

	@And("user should not have a edit access for this field for the teen user")
	public void user_should_not_have_a_edit_access_for_this_field_for_the_teen_user() throws Throwable {
		Assert.assertTrue(profile.checkEditAccess());
	}

	@And("user should not have a edit access for this field for the kid user")
	public void user_should_not_have_a_edit_access_for_this_field_for_the_kid_user() throws Throwable {
		Assert.assertTrue(profile.checkEditAccess());
	}

	@When("user enters invalid mail id {string} into the check box")
	public void user_enters_invalid_mail_id_into_the_check_box(String mailid) throws Throwable {
		profile.editEmail(mailid);
	}

	@Then("user should be able to view the in line error message {string}")
	public void user_should_be_able_to_view_the_in_line_error_message_something(String strArg1) throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getInvalid_email_msg()), true);
	}

	@And("user clicks profile icon from the top navigation")
	public void user_clicks_profile_icon_from_the_top_navigation() throws Throwable {
		waitFor(4000);
		profile.closeProfile();
		logger.info("Profile icon clicked");
	}

	@When("user should be able to click the save cta")
	public void user_should_be_able_to_click_the_save_cta() throws Throwable {
		profile.save_profile();
	}

	@Then("user should be able to recive title available from hold email notification by enabling the 'Enable email notification' flag from my profile screen if the title is available to checkout")
	public void user_should_be_able_to_recive_title_available_from_hold_email_notification_by_enabling_the_enable_email_notification_flag_from_my_profile_screen_if_the_title_is_available_to_checkout()
			throws Throwable {

	}

	@And("user placed hold any title which is not available to checkout")
	public void user_placed_hold_any_title_which_is_not_available_to_checkout() throws Throwable {
		logger.info("Placed hold any title which is not available to checkout");
	}

	@And("user navigate to edit profile screen")
	public void user_navigate_to_edit_profile_screen() throws Throwable {
		profile.navigateProfileDetail();
	}

	@And("user should be able to click the flag to enable the notification")
	public void user_should_be_able_to_click_the_flag_to_enable_the_notification() throws Throwable {

	}

	@When("user clicks on flag for enable email notification")
	public void user_clicks_on_flag_for_enable_email_notification() throws Throwable {
		waitFor(2000);
		profile.clickEmailNotification();
	}

	@Then("user should be able to recive the title added to the library from puchase request notification by enabling the 'Enable email notification' flag from my profile screen if the title was added into the library")
	public void user_should_be_able_to_recive_the_title_added_to_the_library_from_puchase_request_notification_by_enabling_the_enable_email_notification_flag_from_my_profile_screen_if_the_title_was_added_into_the_library()
			throws Throwable {
	}

	@Then("user should be able to view the error popup with {string} with {string} cta")
	public void user_should_be_able_to_view_the_error_popup_with_something_with_something_cta(String strArg1,
			String strArg2) throws Throwable {
//    Assert.assertEquals(isElementPresent(profile.getEnable_notification_popup()), true);
		Assert.assertEquals(profile.getEnable_notification_popup().getText(),
				"Please add your email to enable email notifications");
		profile.clickCancel();
	}

	@Then("user should not be able to view the notifications by the email")
	public void user_should_not_be_able_to_view_the_notifications_by_the_email() throws Throwable {
		logger.info("Notifications by the email is not feasible to check");
	}

	@And("user request to purchase for the library")
	public void user_request_to_purchase_for_the_library() throws Throwable {
	}

	@And("user navigates to edit perofile screen")
	public void user_navigates_to_edit_perofile_screen() throws Throwable {
		profile.navigateProfileDetail();
	}

	@And("user should be able to disable the flag that enable the email notification")
	public void user_should_be_able_to_disable_the_flag_that_enable_the_email_notification() throws Throwable {
		profile.clickEmailNotification();
	}

	@When("user enable the 'Add same email as adult' flag from my profile screen")
	public void user_enable_the_add_same_email_as_adult_flag_from_my_profile_screen() throws Throwable {
		profile.addsameEmail();
	}

	@Then("teen user should be able to view the adult email id in the check box")
	public void teen_user_should_be_able_to_view_the_adult_email_id_in_the_check_box() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getEdit_profile_email()), true);
	}

	@And("user should be able to enable the email notification for the teen user using adult mail id")
	public void user_should_be_able_to_enable_the_email_notification_for_the_teen_user_using_adult_mail_id()
			throws Throwable {
		profile.clickEmailNotification();
	}

	@And("teen user should be able to view their notification to adult mail id")
	public void teen_user_should_be_able_to_view_their_notification_to_adult_mail_id() throws Throwable {
		logger.info("Mail notification not feasible to check ");
	}

	@And("select teen profile in manage profile screen")
	public void select_teen_profile_in_manage_profile_screen() throws Throwable {
		login.clickFooterMenu();
		profile.clickMenuProfile();
		profile.teenprofileSelection();
		waitFor(2000);
	}

	@Given("user select kid profile in manage profile screen")
	public void user_select_kid_profile_in_manage_profile_screen() {
		login.clickFooterMenu();
		profile.clickMenuProfile();
		profile.kidprofileSelection();
	}

	@And("user selects Teen profile")
	public void user_selects_teen_profile() throws Throwable {
		profile.teenprofileSelection();
	}

	@And("user enters the parental pin")
	public void user_enters_the_parental_pin() throws Throwable {
		profile.parentPin();
	}

	@And("user navigates to landing screen")
	public void user_navigates_to_landing_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfileIcon()), true);
	}

	@And("user navigates to manage profile screen by clicking profile option from menu list")
	public void user_navigates_to_manage_profile_screen_by_clicking_profile_option_from_menu_list() throws Throwable {
		login.clickFooterMenu();
		profile.clickMenuProfile();
	}

	@And("user selects manage profile cta")
	public void user_selects_manage_profile_cta() throws Throwable {
		profile.clickManageProfile();
	}

	@And("user selects pencil cta on Teen profile")
	public void user_selects_pencil_cta_on_teen_profile() throws Throwable {
		profile.teenprofileSelection();
	}

	@And("user selects pencil cta on Kid profile")
	public void user_selects_pencil_cta_on_kid_profile() throws Throwable {
		profile.kidprofileSelection();
	}

	@Then("user able to view the adult mail id by default in edit profile screen with non editable state")
	public void user_able_to_view_the_adult_mail_id_by_default_in_edit_profile_screen_with_non_editable_state() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(profile.adultMailId()), true);
	}

	@And("user should be navigated to landing screen for Teen")
	public void user_should_be_navigated_to_landing_screen_for_teen() throws Throwable {
	}

	@Then("user should not be able to view the plus icon")
	public void user_should_not_be_able_to_view_the_plus_icon() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.addProfile()), false);
	}

	@And("user should be able to view edit option on the top")
	public void user_should_be_able_to_view_edit_option_on_the_top() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.editProfileCTA()), true);
	}

	@Then("user should able to view equidistance between profile and Add icon")
	public void user_should_able_to_view_equidistance_between_profile_and_add_icon() {
		logger.info("Profile UI Validation");
	}

	@When("User should be able to see the new verbiage Enable Profile Pin text")
	public void user_should_be_able_to_see_the_new_verbiage_Enable_Profile_Pin_text() {
		waitFor(2000);
//    	swipeDown();
//        swipeDown();
		login.handleNothankspopup();
		Assert.assertEquals(profile.getEnablePINText().getText(), "Enable My Profile PIN");
	}

	@When("user selects Adult profile in")
	public void user_selects_adult_profile_in() {
		waitFor(2000);
		register.adultprofileSelection();
		login.handleNothankspopup();
	}

	@When("user selects teen profile in manage profile screen")
	public void user_selects_teen_profile_in_manage_profile_screen() {
		register.teenprofileSelection();
		login.handleNothankspopup();
	}

	@When("user selects teen1 profile in manage profile screen")
	public void user_selects_teen1_profile_in_manage_profile_screen() {
		register.teen_1profileSelection();
		login.handleNothankspopup();
	}

	@When("user selects kid profile in manage profile screen")
	public void user_selects_kid_profile_in_manage_profile_screen() {
		register.kidprofileSelection();
		login.handleNothankspopup();
	}

	@When("user selects kid1 profile in manage profile screen")
	public void user_selects_kid1_profile_in_manage_profile_screen() {
		register.kid_1profileSelection();
		login.handleNothankspopup();
	}

	@Then("user should be able to view {string} cta to delete the profile")
	public void user_should_be_able_to_view_cta_to_delete_the_profile(String string) {
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(profile.delete__Profile())) {
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(isElementPresent(profile.delete__Profile()), true);
	}

	@Then("user clicks the Delete profile cta")
	public void user_clicks_the_delete_profile_cta() {
		profile.clickDelete_Profile();
	}

	@Then("user should not be able to view the profile in profile list screen")
	public void user_should_not_be_able_to_view_the_profile_in_profile_list_screen() {
		Assert.assertEquals(isElementPresent(register.teen_Profile_Check()), false);
	}

	@Then("user should not be able to view the kid profile in profile list screen")
	public void user_should_not_be_able_to_view_the_kid_profile_in_profile_list_screen() {
		Assert.assertEquals(isElementPresent(register.kid_Profile_Check()), false);
	}

	@When("user land on Profile Detail Page")
	public void user_land_on_profile_detail_page() {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(profile.profile_details_page()), true);

	}

	@Then("user land on {string} and user click the Edit button")
	public void user_land_on_something_and_user_click_the_edit_button(String strArg1) throws Throwable {
		profile.clickManageProfile();
	}

	@Then("User lands on Manage Profile Page and user click the {string} button")
	public void user_lands_on_manage_profile_page_and_user_click_the_button(String string) {
		Assert.assertEquals(isElementPresent(profile.manage_profile_page()), true);
		profile.clickManageProfile();

	}

	@When("user land on {string} page")
	public void user_land_on_page(String string) {
//    	profile.clickProfile();
		Assert.assertEquals(isElementPresent(register.get_MyProfile_Screen()), true);
	}

	@When("user land on manage profile page")
	public void user_land_on_manage_profile_page() {
		Assert.assertEquals(isElementPresent(profile.manage_profile_page()), true);
	}

	@And("user enters the {string} and {string} click on sign in button")
	public void user_enters_the_something_and_something_click_on_sign_in_button(String newcardnumber,
			String newpinnumber, String strArg1, String strArg2) throws Throwable {
	}

	@And("user enters the {string} and click on sign in button")
	public void user_enters_the_something_and_click_on_sign_in_button(String newcardnumber) throws Throwable {
		login.loginwithId(newcardnumber);
		waitFor(2000);
		register.selectSecurityQuestion();
		waitFor(2000);
		register.setDisplayName1("DrSankar");
		waitFor(2000);
		register.enterEmailValue("sankar@gmail.com");
		waitFor(2000);
		register.completeRegistration();

	}

	@And("User enter the Invalid Email Id {string} in Email field")
	public void user_enter_the_invalid_email_id_in_email_field(String mailid) throws Throwable {
		profile.editEmail(mailid);
	}

	@And("User should able to see the Inline Error message as {string} under email field")
	public void user_should_able_to_see_the_inline_error_message_as_something_under_email_field(String strArg1)
			throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getInvalid_email_msg()), true);
	}

	@And("User should not able to enable the {string}")
	public void user_should_not_able_to_enable_the_something(String strArg1) throws Throwable {
//    	profile.click_EnablePIN_Checkbox();
//    	profile.click_EnablePIN_toggle();
		logger.info("Since the save button is disabled for invalid email, User unable to enable");
	}

	@And("User should able to see the Pop Up Message as {string}")
	public void user_should_able_to_see_the_pop_up_message_as_something(String strArg1) throws Throwable {
		logger.info("Since the save button is disabled for invalid email, User unable to enable");
	}

	@And("User tap on Okay on {string}")
	public void user_tap_on_okay_on_something(String strArg1) throws Throwable {
		logger.info("Since the save button is disabled for invalid email, User unable to enable");
	}

	@And("User tap on HamBurger menu and tap on {string}")
	public void user_tap_on_hamburger_menu_and_tap_on_something(String strArg1) throws Throwable {

	}

	@Then("User click the Adult profile")
	public void user_click_the_adult_profile() {
		profile.clickEditPenIcon_Adult();
		login.handleNothankspopup();
	}

	@Then("User click the Teen profile")
	public void user_click_the_teen_profile() {
		profile.clickEditPenIcon_FirstTeen();
	}

	@Then("User click the Kid profile")
	public void user_click_the_kid_profile() {
		profile.clickEditPenIcon_FirstKid();
	}

	@Then("User should verify in Profile Type field {string} should be mentioned")
	public void user_should_verify_in_profile_type_field_should_be_mentioned(String string) {
		Assert.assertEquals(isElementPresent(profile.profile_type()), true);
	}

	@Then("user click the plus icon")
	public void user_click_the_plus_icon() {
		profile.clickAdd_Profile();
	}

	@Then("User navigate to {string} page")
	public void user_navigate_to_page(String string) {
		Assert.assertEquals(isElementPresent(profile.add_profile_page()), true);
	}

	@Then("User tap on close option from header of profile detail screen")
	public void user_tap_on_close_option_from_header_of_profile_detail_screen() {
		profile.clickClose_Btn();
	}

	@Given("user able to view adult profile in manage profile screen")
	public void user_able_to_view_adult_profile_in_manage_profile_screen() {
		Assert.assertEquals(isElementPresent(register.checkAdultProfile()), true);
	}

	@When("user click on the adult profile")
	public void user_click_on_the_adult_profile() {
		register.clickAdultProfile();
		login.handleNothankspopup();
	}

	@Then("user should be able to land on my library screen")
	public void user_should_be_able_to_land_on_my_library_screen() {
		login.handleNothankspopup();
		Assert.assertEquals(isElementPresent(register.lib_Availability()), true);
		Assert.assertEquals(isElementPresent(register.lib_Format()), true);
	}

	@Given("user able to view Teen profile in manage profile screen")
	public void user_able_to_view_teen_profile_in_manage_profile_screen() {
		Assert.assertEquals(isElementPresent(register.checkTeenProfile1()), true);
	}

	@When("user click on the Teen profile")
	public void user_click_on_the_teen_profile() {
		register.clickTeenProfile();
		login.handleNothankspopup();
	}

	@When("user should be able to view the {string} checkbox")
	public void user_should_be_able_to_view_the_checkbox(String string) {
		register.enablePinAllProfiles();
	}

	@Then("user should be able to enable the {string} checkbox")
	public void user_should_be_able_to_enable_the_checkbox(String string) {
		swipeDown();
		register.clickEnablePinAllProfiles();
	}

	@Then("User should be able to view Tooltip for the Enable CTA")
	public void user_should_be_able_to_view_tooltip_for_the_enable_cta() {
		swipeDown();
		swipeDown();
		waitFor(2000);
		Assert.assertEquals(isElementPresent(register.verifyEnableProfilePinText()), true);
		register.enableProfilePinToolTip().click();
		register.clickDismissOptionInCheckout();
	}

	@Then("user should be able to save the changes by clicking the {string} CTA")
	public void user_should_be_able_to_save_the_changes_by_clicking_the_cta(String string) {
		register.clickSaveButton();
	}

	@Given("user should able to view {string} toggle button in the disabled state")
	public void user_should_able_to_view_toggle_button_in_the_disabled_state(String string) {
		Assert.assertEquals(isElementPresent(register.checkProfilePinIsDisabled()), true);
		Assert.assertEquals(isElementPresent(register.verifyEnableProfilePinText()), true);
	}

	@Given("user clicks on the Teen profile")
	public void user_clicks_on_the_teen_profile() {
		register.clickTeenProfile();
		login.handleNothankspopup();
	}

	@Then("user should be able to view the {string} option in the disabled state by default")
	public void user_should_be_able_to_view_the_option_in_the_disabled_state_by_default(String string) {
		Assert.assertEquals(isElementPresent(register.checkProfilePinIsDisabled()), true);
	}

	@When("user should be able to view the {string} toggle button in active state")
	public void user_should_be_able_to_view_the_toggle_button_in_active_state(String string) {
		Assert.assertEquals(isElementPresent(register.verifyEnableProfilePinText()), true);
	}

	@Then("User should be able to NOT view any close or back button CTAs for the first time they land on the profile homepage after registering as they have to enter through a profile")
	public void user_should_be_able_to_not_view_any_close_or_back_button_ct_as_for_the_first_time_they_land_on_the_profile_homepage_after_registering_as_they_have_to_enter_through_a_profile() {
		Assert.assertEquals(isElementPresent(register.profile_Btn_Back()), false);
	}

	@Then("user click the {string}")
	public void user_click_the(String string) {
		register.clickLearnMoreProfiles();
	}

	@Then("user receive the pop up message it should be as per mock")
	public void user_receive_the_pop_up_message_it_should_be_as_per_mock() {
		Assert.assertEquals(isElementPresent(register.aboutProfile()), true);
	}

	@Then("user navigate to Create a Profile PIN page")
	public void user_navigate_to_create_a_profile_pin_page() {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(profile.create_Profile_PIN()), true);
	}

	@Then("user click the back button in Create a Profile PIN page")
	public void user_click_the_back_button_in_create_a_profile_pin_page() {
//		profile.clickClose_Btn();
		profile.click_Prof_PIN_Close_Btn();
	}

	@Then("user leave Page by click the close button in Profile detail page")
	public void user_leave_page_by_click_the_close_button_in_profile_detail_page() {
		profile.clickClose_Btn();
	}

	@Given("user click the {string} option in Manage Profile page")
	public void user_click_the_option_in_manage_profile_page(String string) {
		profile.clickManageProfile();
	}

	@Given("user navigate to Manage Profile page")
	public void user_navigate_to_manage_profile_page() {
		Assert.assertEquals(isElementPresent(profile.manage_profile_page()), true);
	}

	@Given("user click the General Adult icon in Manage Profile page")
	public void user_click_the_general_adult_icon_in_manage_profile_page() {
		profile.adultProfileSelection();
	}

	@Then("User verify the verbiage {string}")
	public void user_verify_the_verbiage(String string) {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			Assert.assertEquals(profile.verbiage_teen().getText(), "Add a teen. 12 to 18");
			Assert.assertEquals(profile.verbiage_kid().getText(), "Add a kid. 0 to 11");
		} else {
			Assert.assertEquals(profile.verbiage_teen().getText(), "12-18");
			Assert.assertEquals(profile.verbiage_kid().getText(), "0-11");
		}
	}

	@Given("user able to view Kid profile in manage profile screen")
	public void user_able_to_view_kid_profile_in_manage_profile_screen() {
		Assert.assertEquals(isElementPresent(register.checkKidProfile1()), true);
	}

	@When("user click on the Kid profile")
	public void user_click_on_the_kid_profile() {
		waitFor(2000);
		register.clickKidProfile();
		login.handleNothankspopup();
	}

	@Given("user able to view general adult,Teen,kid profiles created by default")
	public void user_able_to_view_general_adult_teen_kid_profiles_created_by_default() {
		Assert.assertEquals(isElementPresent(register.checkAdultProfile()), true);
		Assert.assertEquals(isElementPresent(register.checkTeenProfile1()), true);
		Assert.assertEquals(isElementPresent(register.checkKidProfile1()), true);
	}

	@Given("user should able to view Add icon")
	public void user_should_able_to_view_add_icon() {
		Assert.assertEquals(isElementPresent(register.checkProfileCta()), true);
	}

	@Given("user click on the {string} option in the manage profile screen")
	public void user_click_on_the_option_in_the_manage_profile_screen(String string) {
		waitFor(4000);
		register.clickEditOption();
		waitFor(2000);
	}

	@Given("user clicks on the adult profile")
	public void user_clicks_on_the_adult_profile() {
		register.clickAdultProfile();
		login.handleNothankspopup();
	}

	@When("user navigates to the edit profile details screen")
	public void user_navigates_to_the_edit_profile_details_screen() {
		login.handleNothankspopup();
		Assert.assertEquals(isElementPresent(register.profileDetailsType()), true);
	}

	@When("user delete the Email ID in Email field")
	public void user_delete_the_email_id_in_email_field() {
		swipeUp();
		waitFor(1000);
		swipeUp();
		waitFor(1000);
		register.clearEmailValue();
		hideMobileKeyboard();
		swipeDown();
		waitFor(1000);
		swipeDown();
		waitFor(1000);
		profile.clickSave_Button();
	}

	@When("user enable the Enable Profile PIN toggle")
	public void user_enable_the_enable_profile_pin_toggle() {
//		swipeUp();
		waitFor(3000);
		profile.enablePIN();
		waitFor(3000);
	}

	@Then("user able to view Pop Up {string} in Profile Detail Page and click ok button")
	public void user_able_to_view_pop_up_in_profile_detail_page_and_click_ok_button(String string) {
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			Assert.assertEquals(profile.getEnable_notification_popup().getText(),
					"Please add an email to enable your Profile PIN");
		}
		else{
			Assert.assertEquals(profile.getEnable_notification_popup().getAttribute("label"),
					"Please add an email to enable your Profile PINDialogue");
		}
	}

	@Then("user able to view teen Pop Up {string} in Profile Detail Page and click ok button")
	public void user_able_to_view_teen_pop_up_in_profile_detail_page_and_click_ok_button(String string) {
		Assert.assertEquals(profile.getEnable_notification_popup().getText(),
				"Please add an email to enable your Profile PINDialogue");
	}

	@Then("user leave the profile detail page without save CTA")
	public void user_leave_the_profile_detail_page_without_save_cta() {
		profile.clickAlert_Close_Btn();
		profile.clickClose_Btn();
	}

	@Then("user enter the create profile PIN {string}")
	public void user_enter_the_create_profile_pin(String string) {
		profile.enterNewPIN();
	}

	@Then("user enter the confirm profile PIN {string}")
	public void user_enter_the_confirm_profile_pin(String string) {
		profile.confirmNewPIN();
	}

	@Then("user enter the wrong PIN {string}")
	public void user_enter_the_wrong_pin(String string) {
		profile.confirmWrongPIN();
	}

	@Then("user verify the error messages as {string}")
	public void user_verify_the_error_messages_as(String string) {
		waitFor(1000);
		Assert.assertEquals(profile.PIN_Not_Match().getText(), "The PINs you entered do not match. Please retry.");
	}

	@Then("user verify the error message as {string}")
	public void user_verify_the_error_message_as(String string) {
		waitFor(1000);
//    	Assert.assertEquals(profile.wrong_PIN_Failure().getText(), "PIN Not Valid. Please try again.");
		Assert.assertEquals(isElementPresent(profile.wrong_PIN_Failure()), true);
	}

	@Then("user click the Back button in {string} page")
	public void user_click_the_back_button_in_page(String string) {
		profile.clickBack_Btn();
	}

	@Then("user navigate to profile detail page")
	public void user_navigate_to_profile_detail_page() {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(profile.profile_details_page()), true);
	}

	@Then("user should see the toggle on for the Enable Profile PIN and click the save CTA")
	public void user_should_see_the_toggle_on_for_the_enable_profile_pin_and_click_the_save_cta() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(profile.toggle_on_button()), true);
		waitFor(1000);
		swipeDown();
		profile.clickSave_Button();
		waitFor(2000);
	}

	@Then("user disable the Enable Profile PIN toggle")
	public void user_disable_the_enable_profile_pin_toggle() {
//		swipeUp();
		waitFor(3000);
		profile.disablePIN();
		waitFor(3000);
	}

	@Then("user receive the Disable Profile PIN with {string} and {string} CTA")
	public void user_receive_the_disable_profile_pin_with_and_cta(String string, String string2) {
		Assert.assertEquals(isElementPresent(profile.disable_profile_pin_alert()), true);
	}

	@Then("user click the {string} CTA")
	public void user_click_the_cta(String string) {
		profile.click_Alert_Yes();
	}

	@Then("user navigate to Disable Profile PIN page")
	public void user_navigate_to_disable_profile_pin_page() {
		Assert.assertEquals(isElementPresent(profile.disable_Profile_PIN()), true);
	}

	@Then("user enter the {string} and click the Disable CTA")
	public void user_enter_the_and_click_the_disable_cta(String string) {
		profile.enterNewPIN();
		profile.click_Disable_CTA();
	}

	@Then("user enable the Enable Profile PIN toggle in profile detail page")
	public void user_enable_the_enable_profile_pin_toggle_in_profile_detail_page() {
		waitFor(3000);
		profile.enablePIN();
		waitFor(3000);
	}

	@Then("user navigate to profile detail page and click the save CTA")
	public void user_navigate_to_profile_detail_page_and_click_the_save_cta() {
		waitFor(2000);
		profile.clickSave_Button();
		waitFor(2000);
	}

	@Then("user click the close CTA in Profile Detail Page")
	public void user_click_the_close_cta_in_profile_detail_page() {
//		profile.clickClose_Btn();
		profile.click_Prof_PIN_Close_Btn();
	}

	@Then("user click the Back CTA in Manage Profile Page")
	public void user_click_the_back_cta_in_manage_profile_page() {
		logger.info("User is in Manage Profile page");
	}

	@Given("user click the Teen icon in Manage Profile page")
	public void user_click_the_teen_icon_in_manage_profile_page() {
		profile.teenprofileSelection();
		login.handleNothankspopup();
	}

	@Then("user enter the {string} and click the {string} CTA")
	public void user_enter_the_and_click_the_cta(String string, String string2) {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Given("user click the {string} icon in Manage Profile page")
	public void user_click_the_icon_in_manage_profile_page(String string) {
		profile.kidprofileSelection();
	}

	@Then("user enable the {string} toggle")
	public void user_enable_the_toggle(String string) {
		// register.checkProfilePinIsDisabled().click();
		profile.click_EnablePIN_toggle();
	}

	@When("user disable the {string} toggle")
	public void user_disable_the_toggle(String string) {
		register.clickEnabledPin();
	}

	@When("user receive the {string} with {string} and {string} CTA")
	public void user_receive_the_with_and_cta(String string, String string2, String string3) {
		Assert.assertEquals(register.checkDisablePinConfirmationPopupText(),
				"Are you sure you want to disable PIN for this profile?");
	}

	@Then("user navigate to Confirm Profile PIN page")
	public void user_navigate_to_confirm_profile_pin_page() {
		Assert.assertEquals(isElementPresent(profile.confirm_Profile_PIN()), true);
	}

	@Then("user click the {string} in {string} page")
	public void user_click_the_in_page(String string, String string2) {
		profile.clickForgotPin();
	}

	@Then("user navigate to Reset Profile PIN page")
	public void user_navigate_to_reset_profile_pin_page() {
		Assert.assertEquals(isElementPresent(profile.resetProfilePinTxt()), true);
	}

	@Then("user click the {string} , then adult user receive the PIN")
	public void user_click_the_then_adult_user_receive_the_pin(String string) {
		profile.clickSendEmail();
	}

	@Then("user enter the PIN {string}")
	public void user_enter_the_pin(String string) {
		logger.info(" Cannot retrive pin from email");
	}

	@Then("user enter the {string}")
	public void user_enter_the(String string) {
		logger.info(" Cannot retrive pin from email");
	}

	@Given("user navigates to profiles landing screen")
	public void user_navigates_to_profiles_landing_screen() {
//    	if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
//    		register.click_Profile_Icon();
//    	}else {
		Assert.assertEquals(isElementPresent(register.manageProfiles()), true);
//    	}
	}

	@When("user enable the Enable Pin for all profiles checkbox button")
	public void user_enable_the_enable_pin_for_all_profiles_checkbox_button() {
		waitFor(2000);
		profile.click_EnablePIN_Checkbox();
		swipeDown();
		waitFor(2000);
		profile.clickSave_Button();
		waitFor(3000);
	}

	@Then("user should have an option to use {string} CTA in the pop up at any point if required")
	public void user_should_have_an_option_to_use_cta_in_the_pop_up_at_any_point_if_required(String string) {
//		Assert.assertEquals(isElementPresent(profile.forgotPin()), true);
	}

	@Given("user selects Adult and switches back to Teen")
	public void user_selects_adult_and_switches_back_to_teen() {
		register.clickAdultProfile();
		// profile.commonPIN();
		profile.clickProfile();
	}

	@Given("user selects Adult and switches back to Kid")
	public void user_selects_adult_and_switches_back_to_Kid() {
		register.clickAdultProfile();
		// profile.commonPIN();
		profile.clickProfile();
	}

	@When("user clicks teen profile and enter the unlimited incorrect pin attempts profile pin")
	public void user_click_teen_enter_the_unlimited_incorrect_pin_attempts_profile_pin() {
		register.clickTeenProfile();
//		profile.commonPIN();
		profile.enterNewPIN();
	}

	@When("user clicks kid profile and enter the unlimited incorrect pin attempts profile pin")
	public void user_click_kid_enter_the_unlimited_incorrect_pin_attempts_profile_pin() {
		register.clickKidProfile();
//		profile.commonPIN();
		profile.enterNewPIN();
	}

	@When("user clicks adult profile and enter the valid pin of the profile")
	public void user_clicks_adult_profile_and_enter_the_valid_pin_of_the_profile() {
		register.clickEditOption();
		register.clickAdultProfile();
		profile.commonPIN();
	}

	@When("user clicks kid profile and enter the valid pin of the profile")
	public void user_clicks_kid_profile_and_enter_the_valid_pin_of_the_profile() {
		register.clickEditOption();
		register.clickKidProfile();
		profile.commonPIN();
	}

	@When("user clicks adult profile and enter the unlimited incorrect pin attempts profile pin")
	public void user_enter_the_unlimited_incorrect_pin_attempts_profile_pin() {
		register.clickAdultProfile();
		profile.enterNewPIN();
//		profile.commonPIN();
		Assert.assertEquals(isElementPresent(profile.checkForgotPinErrorMessage()), true);
	}

	@Given("user selects Teen and switches back to Adult")
	public void user_selects_teen_and_switches_back_to_adult() {
		register.clickTeenProfile();
		profile.commonPIN();
		waitFor(3000);
		login.handleNothankspopup();
		profile.clickProfile();
	}

	@When("user navigates to teen profile details page")
	public void user_navigates_to_teen_profile_details_page() {
		login.clickFooterMenu();
		profile.clickMenuProfile();
	}

	@Then("user should be able to allow to enter the unlimited PIN attempts for the profile")
	public void user_should_be_able_to_allow_to_enter_the_unlimited_pin_attempts_for_the_profile() {
		Assert.assertEquals(isElementPresent(profile.checkForgotPinErrorMessage()), true);
	}

	@Then("user should be able to see inline error within the pop up stating {string} verbiage")
	public void user_should_be_able_to_see_inline_error_within_the_pop_up_instead_stating_verbiage(String string) {
//		profile.commonPIN();
		login.handleNothankspopup();
		if (isElementPresent(profile.Disable_CTA())) {
			profile.click_Disable_CTA();
		}
		Assert.assertEquals(isElementPresent(profile.checkForgotPinErrorMessage()), true);
		profile.commonPIN();
		if (isElementPresent(profile.Disable_CTA())) {
			profile.click_Disable_CTA();
		}
//		Assert.assertEquals(isElementPresent(profile.checkForgotPinErrorMessage()), true);
	}

	@When("user disbale the profile pin toggle")
	public void user_disbale_the_profile_pin_toggle() {
		profile.click_EnablePIN_toggle();
	}

	@When("user navigate into the enter profile pin screen")
	public void user_navigate_into_the_enter_profile_pin_screen() {
		profile.click_EnablePIN_toggle();
	}

	@When("user enter the incorrect profile pin")
	public void user_enter_the_incorrect_profile_pin() {
//		profile.commonPIN();
		profile.enterNewPIN();
	}

	@When("user navigates to adult profile details page")
	public void user_navigates_to_adult_profile_details_page() {
		login.clickFooterMenu();
		profile.clickMenuProfile();
	}

	@When("user clicks teen profile and enter the valid pin of the profile")
	public void user_clicks_teen_profile_and_enter_the_valid_pin_of_the_profile() {
		register.clickEditOption();
		register.clickTeenProfile();
		profile.commonPIN();
	}

	@When("user navigates to kid profile details page")
	public void user_navigates_to_kid_profile_details_page() {
		login.clickFooterMenu();
		profile.clickMenuProfile();
	}

	@Then("user click the Adult profile in Manage Profile page")
	public void user_click_the_adult_profile_in_manage_profile_page() {
		profile.adultProfileSelection();
		login.handleNothankspopup();
	}

	@When("user should see the Profile Management PIN page")
	public void user_should_see_the_profile_management_pin_page() {
		Assert.assertEquals(isElementPresent(profile.profile_Management_PIN()), true);
	}

	@When("user enter the valid PIN {string}")
	public void user_enter_the_valid_pin(String string) {
		profile.confirmNewPIN();
		login.handleNothankspopup();
		waitFor(2000);
	}

	@Then("user click the Teen profile in Manage Profile page")
	public void user_click_the_teen_profile_in_manage_profile_page() {
		profile.teenprofileSelection();
	}

	@When("user enter the Invalid PIN {string}")
	public void user_enter_the_invalid_pin(String string) {
		profile.confirmWrongPIN();
	}

	@Then("user click the close CTA in Profile Management PIN page")
	public void user_click_the_close_cta_in_profile_management_pin_page() {
		profile.clickBack_Btn();
	}

	@Then("user selects the Teen profile and back to profiles page")
	public void user_selects_the_teen_profile_and_back_to_profiles_page() {
		register.clickTeenProfile();
		login.handleNothankspopup();
		register.clickProfileImage();
	}

	@Then("user selects the kid profile and back to profiles page")
	public void user_selects_the_kid_profile_and_back_to_profiles_page() {
		register.clickKidProfile();
		login.handleNothankspopup();
		register.clickProfileImage();
	}

	@Then("user should be able to view the profile name has mandatory")
	public void user_should_be_able_to_view_the_profile_name_has_mandatory() {
		register.scrollToSaveButton();
//		Assert.assertFalse(register.profileSaveBtn().isEnabled());
		Assert.assertEquals(register.profileSaveBtn().isEnabled(),false);
		swipeUp();
		swipeUp();
	}

	@Then("User should able to see the Inline Error message as {string} under email fields")
	public void user_should_able_to_see_the_inline_error_message_as_under_email_field(String string) {
		hideMobileKeyboard();
		Assert.assertEquals(isElementPresent(register.invalidEmailWarningTxt()), true);
	}

	@When("click the close button")
	public void click_the_close_button() {
		swipeUp();
		swipeUp();
		waitFor(2000);
		profile.clickClose_Btn();
	}

//	@Given("user clicks on the profile icon")
//	public void user_clicks_on_the_profile_icon() {
////        profile.clickProfile();
//		// logger.info("Logged in and navigated to Manage Profile page");
//	}

	@And("user click on the profile")
	public void user_click_on_the_profile() {
		profile.clickProfile();
	}

	@When("user navigate to the title details screen of the unavailable title")
	public void userNavigateToTheTitleDetailsScreenOfTheUnavailableTitle() {
		register.clickUnavailableTitle();
		Assert.assertEquals(isElementPresent(register.checkTitleDetails()), true);
	}

	@Then("user should be able to view Add to Wishlist CTA as primary CTA")
	public void userShouldBeAbleToViewAddToWishlistCTAAsPrimaryCTA() {
		if (isElementPresent(register.checkAddToWishlistCTA())) {
			Assert.assertEquals(isElementPresent(register.checkAddToWishlistCTA()), true);
			register.clickAddToWishlistCTA();
			Assert.assertEquals(isElementPresent(register.checkRemovefromWishlistCTA()), true);
		} else {
			Assert.assertEquals(isElementPresent(register.checkRemovefromWishlistCTA()), true);
			register.clickRemovefromWishlistCTA();
			Assert.assertEquals(isElementPresent(register.checkAddToWishlistCTA()), true);
		}

	}

	@Given("user clicks the manage profile icon")
	public void user_clicks_the_manage_profile_icon() {
		profile.clickEdit_Option();
		waitFor(2000);
	}

	@And("user select the first teen profile with pin")
	public void userSelectTheFirstTeenProfileWithPin() {
		profile.clickEditPenIcon_FirstTeen();
	}

	@And("user should be navigated to the pin confirmation screen")
	public void userShouldBeNavigatedToThePinConfirmationScreen() {
		Assert.assertEquals(isElementPresent(profile.profile_Management_PIN()), true);
		Assert.assertEquals(isElementPresent(profile.checkForgotPin()), true);
//		profile.clickClose_Btn();
		profile.click_Prof_PIN_Close_Btn();
	}

	@And("user select the first kid profile with pin")
	public void userSelectTheFirstKidProfileWithPin() {
		profile.clickEditPenIcon_FirstKid();
	}

	@And("user clicks on Teen profile and enter the correct pin")
	public void userClicksOnTeenProfileAndEnterTheCorrectPin() {
		profile.selectTeenProfile();
//		profile.confirmNewPIN();
		profile.commonPIN();
		login.handleNothankspopup();
//		profile.clickClose_Btn();
		profile.click_Prof_PIN_Close_Btn();
	}

	@And("user select the first adult profile with pin")
	public void userSelectTheFirstAdultProfileWithPin() {
		profile.clickEditPenIcon_Adult();
	}

	@And("user clicks on Kid profile and enter the correct pin")
	public void userClicksOnKidProfileAndEnterTheCorrectPin() {
		profile.selectKidProfile();
		profile.confirmNewPIN();
		profile.commonPIN();
		login.handleNothankspopup();
//		profile.clickClose_Btn();
		profile.click_Prof_PIN_Close_Btn();
	}

	@And("user clicks on Disable Button")
	public void userClicksOnDisableButton() {
		profile.click_Disable_CTA();
	}

	@Then("user should be able to enable the {string} checkbox and save it")
	public void userShouldBeAbleToEnableTheCheckboxAndSaveIt(String arg0) {
		swipeDown();
		swipeDown();
		swipeDown();
//        register.enablePinForProfiles();
	}

	@Then("user should not enable the {string} checkbox")
	public void userShouldNotEnableTheCheckbox(String arg0) {
		swipeDown();
		swipeDown();
		swipeDown();
		register.disablePinForProfiles();

	}

	@And("User should be not able to view the Enable Profile Pin Toogle CTA")
	public void userShouldBeNotAbleToViewTheEnableProfilePinToogleCTA() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(register.enableProfilePinText()), false);
	}

	@Given("user navigates to adult my profile screen")
	public void userNavigatesToAdultMyProfileScreen() {
		waitFor(1000);
		profile.clickManageProfile();
		profile.adultProfileSelection();
	}

	@Given("user navigates to teen my profile screen")
	public void userNavigatesToTeenMyProfileScreen() {
		waitFor(1000);
		profile.clickManageProfile();
		profile.teenprofileSelection();
	}

	@Given("user navigates to Kid my profile screen")
	public void userNavigatesToKidMyProfileScreen() {
		waitFor(1000);
		profile.kidprofileSelection();
		login.handleNothankspopup();
	}

	@Then("user able to view Pop Up Message {string} in Profile Detail Page and click ok button")
	public void userAbleToViewPopUpMessageInProfileDetailPageAndClickOkButton(String arg0) {
		Assert.assertEquals(profile.getEnable_notification_popup1().getText(),
				"The Primary Profile must enter an email address in their profile to enable a Profile PIN");
	}

	@Then("user validates the warning popup adult")
	public void uservalidatesthewarningpopupadult() {
		Assert.assertEquals(isElementPresent(profile.getDelete_Profile_Msg()), true);
		Assert.assertEquals(profile.deleteWarningMsg().getText(),
				"Upon confirming here, your account will be removed and related data, profiles will be removed, log you out from all the devices using Kidszone. You will not be able to log back in.");
	}

	@Then("user clicks the Ok button")
	public void userclickstheOkbutton() {
		profile.okDeleteBtnClick();
	}

	@Then("user validates the warning popup teen")
	public void uservalidatesthewarningpopupteen() {
		Assert.assertEquals(isElementPresent(profile.getDelete_Profile_Msg()), true);
		Assert.assertEquals(profile.deleteWarningMsgteen().getText(),
				"Upon confirmation, all the associated checkouts and holds will be returned and profile will be deleted.");
	}

	@Given("user clicks on the profile icons")
	public void user_clicks_on_the_profile_icon_() {
		profile.clickProfile();
	}

	@When("user click the view interest link")
	public void user_click_the_view_interest_link() {
		profile.clickViewMyInterest();
		myShelf.clickReadingPreference();
	}

	@When("user click on the interest topic")
	public void user_click_on_the_interest_topic() {
		myShelf.clickReadingPreference();
	}

	@Then("user clicks any of the preferred age levels")
	public void user_clicks_any_of_the_preferred_age_levels() {
		profile.clickAdult();
	}

	@Given("user should be able to land in profile list screen")
	public void user_should_be_able_to_land_in_profile_list_screen() {
		Assert.assertEquals(isElementPresent(profile.editProfileCTA()), true);
	}

	@When("user Clicks add profile cta")
	public void user_clicks_add_profile_cta() {
		profile.checkprofileCount();
		profile.clickAdd_Profile();
	}

	@Then("user should be able to view add Adult profile option")
	public void user_should_be_able_to_view_add_adult_profile_option() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(profile.addProfileIcon()), true);
	}

	@Then("user clicks on add an adult option")
	public void user_clicks_on_option() {
		profile.clickAddAnAdult();
	}

	@Then("user should be navigated to profile details screen to enter the details")
	public void user_should_be_navigated_to_profile_details_screen_to_enter_the_details() {
		Assert.assertEquals(isElementPresent(profile.profile_type()), true);
	}

	@Then("user should be able to enter the mandatory details")
	public void user_should_be_able_to_enter_the_mandatory_details() {
		manageProf.displayName();
	}

	@Then("user should save the settings")
	public void user_should_save_the_settings() {
		profile.navigateProfileSave();
	}

	@Given("user navigated to profile list screen by clicking profile image in header")
	public void user_navigated_to_profile_list_screen_by_clicking_profile_image_in_header() {
		profile.clickProfile();
	}

	@Then("user verify new adult profile has been created")
	public void user_verify_new_adult_profile_has_been_created() {
		Assert.assertEquals(isElementPresent(profile.adultProfileTwo()), true);
		profile.clickEdit_Option();
		profile.click_AdultProfileTwo();
		profile.clickDelete_Profile();
		profile.clickProfile_Delete_Ok();
	}

	@Given("user should able to view add a profile screen with Teen and kid option")
	public void user_should_able_to_view_add_a_profile_screen_with_teen_and_kid_option() {
		Assert.assertEquals(isElementPresent(profile.verbiage_kid()), true);
		Assert.assertEquals(isElementPresent(profile.verbiage_teen()), true);
	}

	@Then("user should able to save the profile setting after all mandatory fileds are filled")
	public void user_should_able_to_save_the_profile_setting_after_all_mandatory_fileds_are_filled() {
		for (int i = 0; i <= 9; i++) {
			swipeDown();
			if (isElementPresent(profileCreate.profile_btn_editprofilesave)) {
				break;
			} else {
				swipeDown();
			}
		}
		profileCreate.clickonSaveCTA();

	}

	@Given("user selects {string}")
	public void user_selects(String profiles) {
		profile.selectProfile(profiles);
	}

	@Given("user lands on profile setting screen")
	public void user_lands_on_profile_setting_screen() {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(profile.profile_details_page()), true);

	}
	@And("user lands on manage profile")
	public void user_lands_on_manage_profile()
	{
		profile.clickBack_Btn();
		profile.closeProfile();
	}

	@Then("user able to fill up the profile setting screen {string}")
	public void user_able_to_fill_up_the_profile_setting_screen(String displayname) {
		profileCreate.setDisplayName(displayname);

	}

	@Then("user should lands on manage profile screen")
	public void user_should_lands_on_manage_profile_screen() {
		Assert.assertEquals(isElementPresent(profile.editProfileCTA()), true);
	}

	@When("user selects back CTA in the profile setting screen")
	public void user_selects_back_cta_in_the_profile_setting_screen() {
	profile.closeProfile();
	}

	@Then("user should view a Popup with {string} with {string} and {string} CTA")
	public void user_should_view_a_popup_with_with_and_cta(String string, String string2, String string3) {
		Assert.assertEquals(isElementPresent(profile.deleteWarningMsg()), true);
	}

	@Then("user should stay back in same screen opon selecting {string} CTA")
	public void user_should_stay_back_in_same_screen_opon_selecting_cta(String string) {
	profile.clickCancelCTA();
	Assert.assertEquals(isElementPresent(profile.profile_details_page()), true);
	
	}

	@Then("user selects {string} CTA")
	public void user_selects_cta(String string) {
		profile.closeProfile();
		profile.leavePage();
	}

	@Then("user should navigate to add a profile screen")
	public void user_should_navigate_to_add_a_profile_screen() {
		Assert.assertEquals(isElementPresent(profile.editProfileCTA()), true);
	}
	@Then("user clicks any of the preferred age levels Teen")
	public void user_clicks_any_of_the_preferred_age_levels_Teen() {
		profile.clickTeen();
	}
	@And("user needs to navigate to the libaray search screen")
	public void userNeedsToNavigateToTheLibaraySearchScreen() {
		Assert.assertEquals(isElementPresent(profile.boundless_lib()), true);
	}

	@And("user delete the created profile")
	public void userDeleteTheCreatedProfile() {
		waitFor(2000);
		profile.click_AdultProfileTwo();
		login.handleNothankspopup();
		profile.clickDelete_Profile();
		profile.okDeleteBtnClick();
	}

	@And("user clicks the Adult profile of learning activity")
	public void userClicksTheAdultProfileOfLearningActivity() {
		waitFor(1000);
		register.adultprofileSelection();
		login.handleNothankspopup();
		myLib.clickMylibrary();
		details.scrollToResourceHubSeeall();
		Assert.assertEquals(isElementPresent(details.resoruceDesc()), true);
		details.clickResourceHubSeeAll();
		Assert.assertTrue(isElementPresent(details.resourceHubRefine()));
		details.clickResourceHubRefine();
		Assert.assertTrue(isElementPresent(details.resourceFilterSortby()));
		Assert.assertTrue(isElementPresent(details.resourceFilterType()));
		Assert.assertTrue(isElementPresent(details.resourceFilterAudience()));
	}

	@And("user clicks the Adult profile of learning activity download")
	public void userClicksTheAdultProfileOfLearningActivityDownload() {
		waitFor(1000);
		register.adultprofileSelection();
		login.handleNothankspopup();
		myLib.clickMylibrary();
		details.scrollToResourceHubSeeall();
		Assert.assertEquals(isElementPresent(details.resoruceDesc()), true);
		details.clickResourceHubSeeAll();
		Assert.assertTrue(isElementPresent(details.resourceHubRefine()));
		details.clickResourceHubRefine();
		details.clickResourceFilterSortby();
		Assert.assertTrue(isElementPresent(details.resourceFilterLinkedtitlee()));
		details.clickResourceFilterType();
		details.clickResourceFilterTypeAll();
		details.clickResourceFilterTypeEducator();
		details.clickResourceFilterTypeActivities();
		details.clickResourceFilterAudience();
		details.clickResourceFilterTypeAll();
		details.clickResourceFilterAudienceTeen();
		details.clickResourceFilterSearch();
		Assert.assertTrue(isElementPresent(details.resourcePillActivities()));
		Assert.assertTrue(isElementPresent(details.resourcePillEducator()));
		waitFor(1000);
		Assert.assertTrue(isElementPresent(details.resourcePillTeen()));
		Assert.assertTrue(isElementPresent(details.resourcePillClearAll()));
		details.clickResourcePillClearAll();
		Assert.assertFalse(isElementPresent(details.resourcePillActivities()));
		Assert.assertFalse(isElementPresent(details.resourcePillEducator()));

	}
}
