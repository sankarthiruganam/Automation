package parallel;

import com.utilities.JvmReport;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/Features" },
                glue = {"parallel" }, 
                dryRun = false,
                plugin = { "pretty","json:target/ResultsMobile/Run4CucumberSmokeTest.json","html:target/ResultsMobile/Run4CucumberSmokeTest.html" }, 
				monochrome = true,
                tags="@Run4CucumberSmokeTest and @SmokeE2E")


  public class Run4CucumberSmokeTest {
	@BeforeClass
	public static void beforeClass() throws IOException {
		// String tag = System.getProperty("tag4");
        // if (tag != null) {
        //     System.setProperty("cucumber.filter.tags", String.format("@Run4CucumberTest and %s", tag));
        // }
		LocalDateTime instance = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy kk:mm:ss");
		String start_time = format.format(instance);
		System.setProperty("start_time", start_time);
	}
	@AfterClass
	public static void afterClass() throws IOException {
		LocalDateTime instance = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy kk:mm:ss");
		String Endtime_time = format.format(instance);
		System.setProperty("Endtime_time", Endtime_time);
		JvmReport.generateReport(System.getProperty("user.dir") + "/target/ResultsMobile/Run4CucumberSmokeTest.json");
	}
}
