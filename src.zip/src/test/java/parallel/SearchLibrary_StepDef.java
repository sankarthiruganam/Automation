package parallel;

import com.reusableMethods.CommonActions;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.SearchPage;

public class SearchLibrary_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	SearchPage search = new SearchPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);

	@Then("user should be able to view search suggestions based on the zipcode")
	public void user_should_be_able_to_view_search_suggestions_based_on_the_zipcode() {
		login.searchLibSuggestion();
		Assert.assertTrue(login.getLogo_lbl_libSearchResult().get(0).isDisplayed());
		logger.info("User able to see search result for entered zipcode");
	}

	@When("user enters the invalid {string} and initiate search")
	public void user_enters_the_invalid_and_initiate_search(String libSearch) {
		login.searchLibrary(libSearch);
		login.initiateSearch();
	}

	@When("user should be able to view no search results when no matching results are found")
	public void user_should_be_able_to_view_no_search_results_when_no_matching_results_are_found() {
		Assert.assertEquals(login.getLogo_list_MatchingLibraries().size() != 0, false);
		logger.info("user not able to see suggestions for invalid ");
	}

	@When("user views the list of library form the search results")
	public void user_views_the_list_of_library_form_the_search_results() {
		login.libSuggestionAfterSearch();
		Assert.assertTrue(login.libSuggestionAfterSearch());
	}

	@When("user selects the libraryname from the result")
	public void user_selects_the_libraryname_from_the_result() {
		login.navigateSearchResult();
	}

	@Then("system should be navigated to the user login page based on authentication method defined for the library in the B&T admin portal")
	public void system_should_be_navigated_to_the_user_login_page_based_on_authentication_method_defined_for_the_library_in_the_b_t_admin_portal() {
		logger.info("User able to see login page after selecting library");
	}

	@Then("user should not get any results and system throws an error message like no results found")
	public void user_should_not_get_any_results_and_system_throws_an_error_message_like_no_results_found() {
		Assert.assertTrue(login.getLogo_lbl_librarieserror().isDisplayed());
		logger.info("user is able to see the error message");
	}


	@When("user navigated to landing screen")
	public void userNavigatedToLandingScreen() {
		Assert.assertEquals(isElementPresent(search.getProfile_Landing_Page()), true);
	}

	@Then("User should able initiate a search with a valid Keyword {string} and search")
	public void userShouldAbleInitiateASearchWithAValidKeywordAndSearch(String arg0) {
		search.globalSearch(arg0);
	}
}
