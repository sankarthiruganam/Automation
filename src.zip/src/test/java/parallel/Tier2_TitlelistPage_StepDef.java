package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.Tier1_LandingPage_VBookandVideo;
import pom.kidszone.Tier2_TitlelistPage_VBookandVideo;

public class Tier2_TitlelistPage_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	Tier2_TitlelistPage_VBookandVideo Tier2_TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(
			DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(Tier2_TitlelistPage_StepDef.class);

	@Then("user navigate to tier 2 screen")
	public void user_navigate_to_tier_2_screen() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@And("library should have VBook carousel configured in drupal")
	public void library_should_have_vbook_carousel_configured_in_drupal() throws Throwable {
		logger.info("Admin - Drupal configuration");
	}

	@And("library should have subscription to VBook third party")
	public void library_should_have_subscription_to_vbook_third_party() throws Throwable {
		logger.info("Admin - vBook Subscription");
	}

	@And("library should have VBook carousel enabled in library admin")
	public void library_should_have_vbook_carousel_enabled_in_library_admin() throws Throwable {
		logger.info("Admin configuration for vBook");
	}

	@And("library should have VBook title without title image")
	public void library_should_have_vbook_title_without_title_image() throws Throwable {
		logger.info("Drupal configuration");
	}

	@And("user navigate to VBook title detail screen by tapping on VBook title card")
	public void user_navigate_to_vbook_title_detail_screen_by_tapping_on_vbook_title_card() throws Throwable {
		Tier2_TitlelistPage.navigatetoVbookdetail();
	}

	@And("user should be able to view VBook title detail attribute based on the metadata")
	public void user_should_be_able_to_view_vbook_title_detail_attribute_based_on_the_metadata() throws Throwable {
		logger.info("Drupal configuration");
	}

	@Then("user should be able to view publishers, Age range, language, author, illustrator, series,session name under refine section")
	public void user_should_be_able_to_view_publishers_age_range_language_author_illustrator_seriessession_name_under_refine_section()
			throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_AgeRange()), true);
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_Language()), true);
		logger.info("(publishers,author,illustrator,series,session name) these are not in scope as of PBI 182549");
	}

	@And("user navigate to refine section by tapping refine icon at top right of the list screen")
	public void user_navigate_to_refine_section_by_tapping_refine_icon_at_top_right_of_the_list_screen()
			throws Throwable {
		Tier2_TitlelistPage.navigatetoRefine_section();
	}

	@And("user should be able to view 1st bisac, 2nd bisac, 3rd bisac under refine section")
	public void user_should_be_able_to_view_1st_bisac_2nd_bisac_3rd_bisac_under_refine_section() throws Throwable {
		logger.info("Not in scope - 1st bisac, 2nd bisac, 3rd bisac under refine section");
	}

	@And("user should able to get result by select filter checkbox option and tap search CTA")
	public void user_should_able_to_get_result_by_select_filter_checkbox_option_and_tap_search_cta() throws Throwable {
		Tier2_TitlelistPage.select_filter_checkbox();
		Tier2_TitlelistPage.clickSearch_CTA();
	}

	@And("user result should match with API response")
	public void user_result_should_match_with_api_response() throws Throwable {
		logger.info("Api Response check");
	}

	@Then("user should be able to view VBook list screen")
	public void user_should_be_able_to_view_vbook_list_screen() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@Then("user should able to view title, pub date, popularity, relavance under sort by section")
	public void user_should_able_to_view_title_pub_date_popularity_relavance_under_sort_by_section() throws Throwable {
		if(!isElementPresent(Tier2_TitlelistPage.getView_Relevance()))
		{
			Tier2_TitlelistPage.expand_SorrtBy();
		}
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_Publication_Date()), true);
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_Popularity()), true);
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_Relevance()), true);
		logger.info("title option - out of scope");
	}

	@And("user should be able to view relevance sort by default")
	public void user_should_be_able_to_view_relevance_sort_by_default() throws Throwable {
	if(!isElementPresent(Tier2_TitlelistPage.getView_Relevance()))
		{
			Tier2_TitlelistPage.expand_SorrtBy();
		}
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getView_Relevance()), true);
		logger.info("Relevance is selected as default");
	}

	@And("user should be able to view refine section at top right of the screen")
	public void user_should_be_able_to_view_refine_section_at_top_right_of_the_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvideo_Refiner()), true);
	}

	@And("user should be able to navigate to refine section by tapping refine icon")
	public void user_should_be_able_to_navigate_to_refine_section_by_tapping_refine_icon() throws Throwable {
		Tier2_TitlelistPage.navigatetoRefine_section();
	}

	@And("user should able to get result by select sort option and tap search CTA")
	public void user_should_able_to_get_result_by_select_sort_option_and_tap_search_cta() throws Throwable {
		Tier2_TitlelistPage.select_SortBy_Publication();
		Tier2_TitlelistPage.clickSearch_CTA();
	}

	@And("user should be able to view default title image if the VBook title image is not available")
	public void user_should_be_able_to_view_default_title_image_if_the_vbook_title_image_is_not_available()
			throws Throwable {
		logger.info("Default Image check");
	}

	@Then("user should be able to view the VBooks Title Icon for the VBook title")
	public void user_should_be_able_to_view_the_vbooks_title_icon_for_the_vbook_title() throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvBook_icon()), true);
	}

	@And("user should be able to view the blue background icon for available Vbook title")
	public void user_should_be_able_to_view_the_blue_background_icon_for_available_vbook_title() throws Throwable {
		logger.info("Backround color check.");
	}

	@And("user lands on library screen by default")
	public void user_lands_on_library_screen_by_default() throws Throwable {
		login.clickmylibrary();
	}

	@And("user should be able to view the title list screen based on the configuration in Drupal")
	public void user_should_be_able_to_view_the_title_list_screen_based_on_the_configuration_in_drupal()
			throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@And("user should be able to view the VBooks title listed with Title Image")
	public void user_should_be_able_to_view_the_vbooks_title_listed_with_title_image() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@And("user should be able to view the VBooks icon in the title card")
	public void user_should_be_able_to_view_the_vbooks_icon_in_the_title_card() throws Throwable {		
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvBook_icon()), true);
	}

	@And("user should be able to view the action CTA for VBook title")
	public void user_should_be_able_to_view_the_action_cta_for_vbook_title() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2page_ActionCTA(), true);
	}

	@And("user should be able to view the refine section to filter the titles")
	public void user_should_be_able_to_view_the_refine_section_to_filter_the_titles() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@And("user should be able to view the match of result with API response")
	public void user_should_be_able_to_view_the_match_of_result_with_api_response() throws Throwable {
		logger.info("API Response check");
	}

	@And("User should not able to view vbook title carousel")
	public void user_should_not_able_to_view_vbook_title_carousel() throws Throwable {
//		Assert.assertEquals(Tier2_TitlelistPage.getvBook_icon(), false);
		logger.info("user should not able to view vbook title carousel");
	}

	@And("user should be able to view the Video title listed with Title Image")
	public void user_should_be_able_to_view_the_video_title_listed_with_title_image() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@And("user should be able to view the Video icon in the title card")
	public void user_should_be_able_to_view_the_video_icon_in_the_title_card() throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvideo_icon()), true);
	}

	@And("user should be able to view the action CTA for video title")
	public void user_should_be_able_to_view_the_action_cta_for_video_title() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2page_ActionCTA(), true);
	}
	
	@And("^user should able to view bottom drawer by clicking secondary CTA for that video title$")
    public void user_should_able_to_view_bottom_drawer_by_clicking_secondary_cta_for_that_video_title() throws Throwable {
		Tier2_TitlelistPage.clickBottomDrawer();
    }

    @And("^user should able to view return and renew in bottom drawer$")
    public void user_should_able_to_view_return_and_renew_in_bottom_drawer() throws Throwable {
    	Assert.assertEquals(Tier2_TitlelistPage.verifyReturnInBottomDrawer(), true);
    	Assert.assertEquals(Tier2_TitlelistPage.verifyRenewInBottomDrawer(), true);
    }

	@Then("user should able to view resume action CTA for that video title")
	public void user_should_able_to_view_resume_action_cta_for_that_video_title() throws Throwable {
		logger.info("Unable to check - Resume cta check for the video title");
	}

	@And("user should able to view checkout action CTA for available video title")
	public void user_should_able_to_view_checkout_action_cta_for_available_video_title() throws Throwable {
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2page_ActionCTA(), true);

	}
	
	@And("^user should not able to view secondary cta$")
    public void user_should_not_able_to_view_secondary_cta() throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.verifySecondary_CTA()), false);
    }

	@And("user not started watching the checkout video title")
	public void user_not_started_watching_the_checkout_video_title() throws Throwable {
		logger.info("Watching video is not feasible");
	}

	@And("user started watching and exit from checkout video title")
	public void user_started_watching_and_exit_from_checkout_video_title() throws Throwable {
		logger.info("Unable to check play and resume of the video");
	}

	@Then("user should be able to view the Videos Title Icon for the video title")
	public void user_should_be_able_to_view_the_videos_title_icon_for_the_video_title() throws Throwable {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvideo_icon()), true);
	}

	@And("user should be able to view the blue background icon for available Video title")
	public void user_should_be_able_to_view_the_blue_background_icon_for_available_video_title() throws Throwable {
		logger.info("Backround color check");
	}

	@And("user should be able to view default title image if the Video title image is not available")
	public void user_should_be_able_to_view_default_title_image_if_the_video_title_image_is_not_available()
			throws Throwable {
		logger.info("title image check");
	}

	@Then("user is navigated to the Tier {int} screen of the video widgets")
	public void userIsNavigatedToTheTierScreenOfTheVideoWidgets(int arg0) {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvideo_icon()), true);
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}

	@Then("user is navigated to the Tier {int} screen of the vBooks widgets")
	public void userIsNavigatedToTheTierScreenOfTheVBooksWidgets(int arg0) {
		Assert.assertEquals(isElementPresent(Tier2_TitlelistPage.getvideo_icon()), true);
		Assert.assertEquals(Tier2_TitlelistPage.verifyTier2Page(), true);
	}
}
