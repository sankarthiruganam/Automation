package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class ProfileEdit {

	Eyes eyes = EyesManager.getEyes();	
	
	@Then("capture the screenshot of edit icon on all the profiles")
	public void capture_the_screenshot_of_edit_icon_on_all_the_profiles() {
	    eyes.checkWindow("EditIconONAllProfiles");
	}

	@Then("capture the screenshot of pin confirmation screen")
	public void capture_the_screenshot_of_pin_confirmation_screen() {
	    eyes.checkWindow("PinConfirmationScreen");
	}
}
