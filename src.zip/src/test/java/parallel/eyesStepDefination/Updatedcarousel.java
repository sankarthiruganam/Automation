package parallel.eyesStepDefination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pom.kidszone.SearchPage;
public class Updatedcarousel {

	Eyes eyes = EyesManager.getEyes();
	public static final Logger logger = LoggerFactory.getLogger(Updatedcarousel.class);
	SearchPage search = new SearchPage(DriverManager.getDriver());

	
	//168227
	
//	@Given("capture the screenshot of Also Available in the title")
//	public void user_launch_the_app_and_select_the_library() throws InterruptedException {
//	search.relatedItems().click();
//	eyes.checkWindow("Alsoavilable");
//	}

	//168597
	
	@Then("capture the screenshot of Titles Like This section unser More Like This tab")
	public void capture_the_screenshot_of_titles_like_this_section_unser_more_like_this_tab() {
	    eyes.checkWindow("TitlesLikeThis");
	}
	
	//168601
	
	@Then("capture the screenshot of Other Titles in Series section")
	public void capture_the_screenshot_of_other_titles_in_series_section() {
	    eyes.checkWindow("OtherTitlesInSeries");
	}
}
